# mod14 import failure propagation patch

This is a proposed drop-in source replacement for `mod14_ImportPD6Power`. It has not been compiled or executed in Microsoft Excel. It does not modify the uploaded XLSM or certify that any Excel freeze is resolved.

## What changed

- The path-based import entry captures error number, description and source before best-effort cleanup, then raises that original error to its caller. The existing `PowerRT_4D_Import_Power_FAST` handler can now stop before `PowerRT_BackfillFinalPowerAssignments` when the PD6 import fails.
- The direct-button entry handles that propagated error and displays the existing user-facing failure message. Cancellation and successful completion retain their existing behavior.
- The failure handler is enabled after capturing prior application settings but before disabling screen updating/events/calculation/alerts, so failures during that setup attempt also use cleanup.
- Public signatures, field merge policies, part/identity selection, append algorithm, all helper procedures and normal successful import output are unchanged.

The patch does **not** roll back worksheet cells already changed before an error, change Excel workbook ownership, fix duplicate PSU append counts, or resolve duplicate return identities. Cleanup restores application settings on a best-effort basis as before. Those are separate findings in the audit.

The BAS file uses CRLF line endings and Windows-1252 encoding for import compatibility. The companion unified diff shows the exact source changes.

## Installation on a disposable validation copy

1. Back up the original workbook and retain its exported `mod14_ImportPD6Power` module. Do not import this as a second same-name module.
2. In the VBA editor, replace only the original `mod14_ImportPD6Power` source with the patched source, preserving the module's name. When pasting code into the editor, omit the first exported `Attribute VB_Name` line. Alternatively remove the original module after exporting it, then import this BAS.
3. Compile with `Debug > Compile VBAProject`. Resolve no unrelated errors by guesswork; record any failures separately. Save the validation copy under a new filename.

## Required manual validation in Excel

Use copied master/Power workbooks and snapshots of `SIS_TAG_PD5`, `Estimated_Power_Supply`, `PD4_Estimate_PSU`, and `Power Supply Bus` before each failure case.

- **Successful run:** run Phase 4D with the known compatible return. Confirm PD6 row/assignment outputs match the unpatched baseline and backfill still occurs. Check the normal completion message appears.
- **Inner schema failure:** on the Power copy, rename a mandatory return header such as `Panel` to an unrecognized name while retaining a valid `SIS_SEQUENCE`. Run Phase 4D. Confirm one outer `Phase 4D failed` error, original meaningful error number/description, no success message, and **no source-sheet backfill**. The existing inner operation may create missing destination headers before detecting a later source defect; the patch intentionally does not claim a full transaction rollback.
- **Direct button:** run `Fill_PD6_From_PowerCalculation_RELEASED` using that invalid source. Confirm the existing `Power Calculation PD6 Update` error message appears once, without an unhandled VBA error prompt.
- **Missing PD6 output:** on a disposable master copy, rename `PD6 System Designed`. Run Phase 4D and confirm failure is raised to the wrapper before any backfill.
- **State restore:** record `Application.ScreenUpdating`, `.EnableEvents`, `.Calculation` and `.DisplayAlerts` before both success and schema failure. Confirm they match afterward, including starting in manual calculation mode.
- **Cancel:** cancel file selection; confirm no changes and no failure message.
- **Resource ownership:** verify a Power workbook that was already open remains open; a source opened solely by the outer wrapper is closed on failure according to its existing `openedHere` cleanup rule.

## Static validation performed here

`python analysis/test_vba_power_patch.py`: 5 checks passed. These verify preserved interfaces/helpers, handler placement, capture/cleanup/propagation order, and the direct UI handler. They do not substitute for compilation or live Excel tests.
