# Proposed Field Devices → IO Generator replacement

This replaces only `EXPORT_TO_IOGEN` in a **copy** of ONGEN Field Devices Specification v2.1.7.1. It is source code, not a rebuilt/compiled XLSM. Microsoft Excel compilation and run acceptance have not been performed here.

1. Back up both workbooks. Use copies, not the live engineering files.
2. Open the Field Devices copy in desktop Excel. In the VBA editor export the existing `EXPORT_TO_IOGEN` module to a backup, remove that module, then import this `EXPORT_TO_IOGEN.bas`. Keep its module name; do not add a second module with the same procedure.
3. Run Debug → Compile VBAProject, resolve any pre-existing compile/reference problems, save the copy.
4. Test a one-row `EM Designed function` export into a B05 IO Generator copy. Both Conv.ID/Items Type and DEVICE NAME/ITEM TYPE aliases are accepted. Required destination fields are the real eleven-column B05 contract.
5. Test two items sharing a conveyor ID but having different item types. Both must survive. Test duplicate `(device name,item type)` rows; export must stop before changing output.
6. Test zero, blank, negative, fractional and nonnumeric IO counts. Blank/zero are allowed; invalid values must stop the export.
7. Test existing PNL/PWG/LOCATION and Standard/Safety Block assignments. These columns and unrelated existing devices must survive. New appended devices need assignment review.
8. Exercise overwrite, skip, cancel, protected/read-only target, missing header, duplicated header and induced save failure. Check original application state and verify failed writes roll back or report an unconfirmed rollback. Opened-here targets close; pre-open targets remain open.

Changes: header aliases; composite dictionary identity; nonnegative integer checks; source preflight; one overwrite choice; bounded array writes for six mapped columns; state snapshot/restore; target formula rejection; best-effort rollback and explicit errors. Destination macros are not executed on opening and application automation security is restored. Previously-open dirty targets are rejected to avoid saving unrelated edits.

The accompanying diff records the source change. `tests/test_field_export_model.py` validates the transfer model and source expectations in Python; its twelve passing tests do not establish VBA compilation or Excel execution.
