# Proposed ONGEN master VBA source replacements

These three BAS replacements are supplied separately from the uploaded workbook. **No original XLSM or embedded VBA project was changed. VBA has not been compiled or run in Excel here.** Python tests below check source structure and algorithm models only; Windows/Excel acceptance is still required.

| Replacement | Reason | Exact behavior changed | Verification performed |
|---|---|---|---|
| mod09_GeneratePD2.bas | Phase 3A unnecessarily clears to row 1,048,576 for each copied column | Capture the existing destination last-used row once; clear only row 2 through that row before copying each matching column. | Source assertions and bounded-clear coverage model. No measured Excel timing claim. |
| mod20_DeviceWorkflow.bas | Phase 5A can truncate/overwrite trailing devices when refreshing an existing VFD | Keep outRow as total output count. Use a separate targetRow for existing/new VFD assignments. | Existing bug reproduced in a Python model; update/append/multiple-update regression models pass. |
| mod14_ImportPD6Power.bas | Phase 4D can continue backfill after an inner import failure | Capture original error, restore app state best effort, and rethrow to the existing Phase 4D wrapper. Direct-button wrapper catches and shows existing error UI. | Five static source checks; public interfaces and helper tail preserved. See mod14_PATCH_NOTES.md. |

Files use CRLF line endings and Windows-1252 source encoding. Unified diffs show all code changes. Existing performance wrappers, pulse checkpoints, cancellation behavior, public macro names and workbook conventions are retained. The mod20 patch changes only the Phase 5A row index; it does not replace a running IO generator or alter the 11-column B05 handoff.

## Apply to a disposable copy

1. Back up the master workbook. Work only on a clearly named validation copy. Keep the Power and IO copies separate from live project deliverables.
2. Open the validation copy in Microsoft Excel for Windows and open the VBA editor (Alt+F11). Export the original modules as backups.
3. Replace each same-name module rather than importing duplicates. Either remove the exported original module and import its BAS replacement, or replace its editor contents while omitting the exported `Attribute VB_Name` line when pasting. The existing name must stay unchanged.
4. Run **Debug > Compile VBAProject**. Record any compile failures; this package does not assert that the entire legacy project compiles.
5. Save the validation copy as XLSM. A changed VBA project invalidates any existing VBA signature; apply your normal internal signing/release process after acceptance.

## Acceptance cases

Before every case, record Excel Calculation, EnableEvents, ScreenUpdating and DisplayAlerts. They must return to their entry values through the normal dashboard wrapper. Use row/identity comparisons rather than only the completion message.

### Phase 3A

- Start with fewer PD2 rows than PD5; verify every source row copies and BOQ/function enrichment is identical to baseline.
- Start with more existing PD2 rows than PD5; put marker values near the old final used row in a copied column. Verify old trailing values clear and new source rows remain.
- Exercise a one-row destination and an existing destination with formulas returning empty strings. Verify no invalid reversed range is constructed and the last-used-row snapshot covers stale formulas.
- Compare headers, row counts, CFN, TYPE, POWER/VOLTAGE, parent IO and ML against an unpatched successful baseline. The patch intentionally retains existing behavior for destination-only columns and empty-source conditions; it does not redesign the whole import.
- Record phase duration and peak Excel memory over several runs on the same machine/data. Report observed timings only; no percentage improvement has been established here.

### Phase 5A

- Place an existing VFD near the start of FUNCTION DEVICE pd2 followed by beacon/scanner rows. Ensure a matching eligible parent VFD exists in SIS_TAG_IMPORT_PD2. Verify the final Specification Devices count does not shrink and trailing rows remain.
- Include both an existing VFD update and a new parent VFD append. Verify no existing row is overwritten and final count equals normal rows plus unique appended VFDs.
- Update two existing VFDs in reverse order. Verify row count/order stays intact and IO/PD6 assignments change only on the intended rows.
- Confirm Standard Block/Safety Block preservation, explicit-zero IO treatment, final Panel/SwitchGroup/Area mappings, VFD-suffix de-duplication and missing-sequence counters match intended legacy rules.

### Phase 4D

Follow the success/failure/cancellation/state-restore matrix in mod14_PATCH_NOTES.md. Especially confirm a failed inner import cannot change SIS_TAG_PD5/Estimated_Power_Supply/PD4_Estimate_PSU/Power Supply Bus through subsequent backfill. This patch does not roll back PD6 cells changed before failure.

## Deliberately not patched

- Phase 3B deserves indexed in-memory definitions, buffered output and staged commit. A large uncompiled rewrite would be less reviewable than a tested replacement engine. Its existing nested COM access is reported as a performance risk; no Excel freeze fix is asserted.
- The Power Calculation workbook exceeded the transfer limit and was not inspected. Internal Power callbacks/formulas and versions remain unverified.
- The B05 input workbook has exactly 11 columns and no HANDLE-consuming macro was found. Phase 5C A:K is retained; adding a twelfth column silently would change its contract. Preserve HANDLE as separate provenance in the combined suite.
- Missing CFN in the specification push, ambiguous return identities, function-only BOM fallback, duplicate PSU append counting, broader state restoration and rollback issues require further controlled changes documented in the audit.

Run the model/static checks from the suite root:

```text
python analysis/test_vba_patch_models.py
python analysis/test_vba_power_patch.py
```
