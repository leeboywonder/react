# ONGEN Engineering Suite 0.1.0

A local engineering workspace for the supplied PD, Field Devices, IO, EAS and function-library files. The browser and Windows desktop versions use one Python engine and the same project format.

**Delivery status:** runnable engineering preview. Browser behavior and Python engine/API are tested on Linux. Windows desktop source/launch/build scripts are included; no Windows executable or native Excel/VBA run was produced here. Power Calculation V4.6 exceeded the attachment transfer limit and remains uninspected. See [the audit](analysis/ONGEN_AUDIT_REPORT.md) before relying on generated data.

## Start on Windows

Install Python 3.11 or newer (3.12 was tested). Unzip into a writable folder. Open PowerShell in that folder.

Browser:

    powershell -NoProfile -File .\windows\Start-ONGEN.ps1

Desktop:

    powershell -NoProfile -File .\windows\Start-ONGEN.ps1 -Desktop

The first launch installs dependencies into .venv; Internet access is required. Later launches can use -NoInstall. Respect your organization's PowerShell policy; if local script execution is restricted, use the manual Python commands below. The desktop needs pywebview's Windows prerequisites, including Edge WebView2. It starts the same local engine inside a native window. Both Windows launcher modes use `%LOCALAPPDATA%\ONGEN\data`. Close one mode before opening the other. Existing data is never overwritten by the sample seed.

Manual/portable browser:

    python -m venv .venv
    .venv\Scripts\python -m pip install -r requirements.txt
    .venv\Scripts\python run.py --browser

On Linux/macOS use `.venv/bin/python` instead. Default portable data location is ./data. Set ONGEN_DATA_DIR explicitly to choose a different workspace. Set ONGEN_EMPTY_PROJECT=1 before first startup to create an empty workspace instead of loading the sample. The server binds loopback only. Do not expose it publicly.

## What works

- Browse/search all accessible source sheets, preserve original files by SHA-256 and retain exact row trace.
- Validate missing/duplicate identities, BOQ collisions, cached formula errors, library status and lookup gaps.
- Generate Phase 3 enrichment/function-device review data using indexed joins.
- Preview normalized function/component/variant/part BOMs with explicit component selection and multiplied quantities.
- Calculate transparent electrical load estimates; assumptions and limits are shown.
- Review device names/exclusions before IO export. Duplicate legacy names block export until explicitly resolved.
- Preview and confirm whitelisted return assignments; ambiguous and duplicate targets are blocked.
- Download XLSX/CSV review packets, an issue register, HTML report and JSON audit snapshot.

No Excel macros execute. Worksheet formulas are imported as saved caches and are not recalculated. The IO packet contains function-derived devices, not a complete replacement for every direct equipment/IO rule. Original Power finalization, native IO allocation, EAS/CAD generation, full purchasing release and electrical engineering approval remain outside this preview's validated capabilities.

## Included project and outputs

sample_project contains a seeded SQLite database and unchanged accessible originals. It is copied once into a new working data folder. Back up the **whole data folder** to preserve the working project and VBA originals. project.json is an audit export, not a complete restorable Office project.

The supplied review XLSX has 4,559 Phase 3 parents, 1,564 function-derived devices and 4,210 Power exchange rows. It deliberately omits IO_DEVICE_LIST because actual legacy device names are ambiguous. The READ_ME sheet gives the reason. 3,777 parent rows have no function assignment or need review; many direct/mechanical records may intentionally have no function code. Use phase3_review.csv rather than assuming these rows are all defects.

Rebuilding Phase 3 resets generated device reviews and return modifications. Importing a new source invalidates derived outputs. Export/backup reviewed work before rebuilding or importing revisions.

## Proposed Excel-source fixes

[vba/patched/README.md](vba/patched/README.md) describes three master replacements and native acceptance cases. [The Field exporter notes](vba/patched/field/README.md) cover the fourth replacement. Import named modules into **copies** of the XLSM files after backing up/exporting old modules. Do not add duplicate module/procedure names. Compile and test in desktop Excel before release. These are source patches, not modified/validated XLSM binaries.

## Build Windows desktop

On Windows, run `powershell -NoProfile -File .\windows\Build-Desktop.ps1`. It produces a PyInstaller folder distribution at dist/ONGEN. Distribute the complete folder. This has not been built or tested on Windows here and is not a signed installer. Validate start/close/reopen, WebView2, downloads, data persistence, antivirus policy and engineering acceptance before distributing it.

## Verification

    python -m pip install -r test-requirements.txt
    python -m unittest discover -s tests -v
    python analysis/test_vba_patch_models.py
    python analysis/test_vba_power_patch.py

Current results: 27 engine/API/library tests plus 12 Field transfer-model tests pass; 12 additional master model/source checks pass. Nine browser action/navigation checks pass with no JavaScript errors in Linux Chromium. None of these execute VBA or validate a Windows EXE. Logs and original-source audits are in analysis/. validate_real_data.py can repeat original-data validation using sample_project/inputs when the original attachment folder is unavailable. Browser-check instructions are in tests/README.md.

See CHANGELOG.md, the full PDF/Markdown audit and detailed per-workbook evidence for changes, limitations and the Windows/Excel release checklist.
