"""Repeatable read-only-source integration run on supplied workbooks; uses a temporary workspace."""
import csv,hashlib,io,json,platform,tempfile,time,zipfile
from pathlib import Path
from openpyxl import load_workbook
from app.engine import Workspace
from app import exports
from app.library import expand
inputs=Path('/workspace/attachments')
if not inputs.exists():
    inputs=Path('sample_project/inputs')
original_sources=Workspace('data').sources() if Path('data/ongen.sqlite3').exists() else []
name_by_hash={s['sha256']:s['name'] for s in original_sources}
if Path('analysis/original_hashes.csv').exists():
    with open('analysis/original_hashes.csv',newline='') as manifest:
        name_by_hash.update({r['sha256']:r['name'] for r in csv.DictReader(manifest)})
results={'platform':platform.platform(),'python':platform.python_version(),'timing_scope':'Python execution on this Linux machine, not Excel/VBA or Windows measurements','imports':[]}
with tempfile.TemporaryDirectory() as tmp:
    w=Workspace(tmp)
    for p in sorted(inputs.rglob('*')):
        if p.suffix.lower() not in ('.xlsm','.xlsx','.csv'):continue
        sha=hashlib.sha256(p.read_bytes()).hexdigest();name=name_by_hash.get(sha,p.name)
        start=time.perf_counter();r=w.import_file(p,name)
        results['imports'].append({'name':name,'sha256':sha,'seconds':round(time.perf_counter()-start,4),'sheets':len(r.get('sheets',[])),'rows':sum(s['rows'] for s in r.get('sheets',[]))})
        assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
    start=time.perf_counter();w.validate();results['validation_seconds']=round(time.perf_counter()-start,4)
    start=time.perf_counter();results['phase3']=w.build_phase3();results['phase3_seconds']=round(time.perf_counter()-start,4)
    start=time.perf_counter();content=exports.xlsx_bytes(w);results['xlsx_seconds']=round(time.perf_counter()-start,4)
    output=load_workbook(io.BytesIO(content),read_only=True,data_only=False)
    assert len(next(output['PD5_IMPORT'].values))==41
    results['xlsx_sheets']=output.sheetnames
    results['power_packet']={'rows':len(exports.phase4(w)['rows']),'columns':41,'native_roundtrip_verified':False}
    try:
        packet=exports.io_packet(w);results['io_export']={'status':'generated','rows':len(packet['rows'])}
    except ValueError as e:results['io_export']={'status':'blocked pending identity review','reason':str(e)}
    c=expand(w,{'function_code':'CF-B-010'})['components'][0]['COMPONENT_CODE']
    bom=expand(w,{'function_code':'CF-B-010','quantity':2,'component_codes':[c]})
    assert all(r['TOTAL_QTY']==r['INSTANCE_QTY']*r['COMPONENT_QTY']*r['PART_QTY'] for r in bom['rows'])
    results['bom_preview']={'function':'CF-B-010','component':c,'rows':len(bom['rows']),'quantity_conservation':True}
    results['project_summary']=w.project()['summary']
    results['unassigned_or_unresolved_parent_records']=len(w.generated('phase3_review')['rows'])
Path('analysis/validation_results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
