"""ONGEN Windows desktop host. Uses exactly the same local API and workspace as the browser app."""
import logging, os, socket, sys, threading, time, urllib.request
from pathlib import Path

def main():
    try:
        import webview
    except ImportError:
        raise SystemExit('Install desktop-requirements.txt, or run python run.py --browser for the browser version.')
    base=Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / 'ONGEN'
    base.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('ONGEN_DATA_DIR',str(base/'data'))
    logging.basicConfig(filename=str(base/'desktop.log'),level=logging.INFO)
    import uvicorn
    from app import server as application
    # Reserve the socket through server startup to avoid a port-selection race.
    listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(128)
    port=listener.getsockname()[1]
    config=uvicorn.Config(application.app,host='127.0.0.1',port=port,log_config=None)
    service=uvicorn.Server(config)
    thread=threading.Thread(target=lambda:service.run(sockets=[listener]),daemon=True);thread.start()
    url=f'http://127.0.0.1:{port}'
    ready=False
    for _ in range(150):
        if not thread.is_alive():break
        try:
            with urllib.request.urlopen(url+'/api/project',timeout=.3) as response:
                ready=response.status==200
                if ready:break
        except Exception:time.sleep(.1)
    if not ready:
        service.should_exit=True
        raise RuntimeError(f'Local engine could not start. See {base / "desktop.log"}')
    webview.settings['ALLOW_DOWNLOADS']=True
    webview.create_window('ONGEN | Engineering Workspace',url,width=1440,height=960,min_size=(1000,680))
    try:webview.start()
    finally:
        service.should_exit=True;thread.join(timeout=5);listener.close()

if __name__=='__main__':
    try:main()
    except Exception as exc:
        logging.exception('ONGEN desktop startup failed')
        if sys.platform=='win32':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,str(exc),'ONGEN could not start',0x10)
        else:print(str(exc),file=sys.stderr)
        sys.exit(1)
