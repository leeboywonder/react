# ONGEN Function Library audit

All 18 extracted modules inspected: one substantive 1,851-line standard module and 17 eight-line attribute-only classes. Static VBA analysis and read-only workbook data cross-checks; no Windows Excel runtime tests.

Counts: {'functions': 31, 'approved_functions': 6, 'migration_review_functions': 25, 'components': 44, 'variants': 209, 'bom_rows': 335, 'parts': 218, 'lookup_csv_rows': 30}

No supplied-data orphan references or duplicate primary keys were found. A normalized part duplicate and four duplicate variant signature groups require engineering review.

## LIB-01 — Duplicate part identity already exists

Severity: high; evidence class: verified supplied-data inconsistency.

PART_MASTER rows 168 and 216: normalized EUCHNER + 92898 maps to both PK-CBL-0087 and PK-CBL-0095. Source FindExactPartRow returns first match (1687–1698).

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_FindExactPartRow lines 1687–1698

Impact: A cost update can target only the first duplicate; BOMs may reference either identity. Do not automatically merge historical part keys.

Recommended correction: Raise a controlled duplicate review, select canonical identity and create explicit retired/replaced-by mapping only after engineering review.

## LIB-02 — Lookup CSV is stale versus the supplied library

Severity: high; evidence class: verified supplied-data inconsistency.

Supplied CSV has 30 functions; library has 31 active functions. Approved active CF-STD-002 is absent.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ExportFunctionLookupCSV lines 1550–1568

Impact: PD function validation/selection using the CSV cannot see a valid approved library function.

Recommended correction: Generate lookup from one approved library snapshot; include library version, source digest, export time and row count in a manifest.

## LIB-03 — Lookup export includes active functions still awaiting engineering review

Severity: high; evidence class: static release-gating gap plus verified data exposure.

FUNCTION_MASTER contains 25 MIGRATION - REVIEW BEFORE PRODUCTION functions and 6 APPROVED functions. Export tests only ACTIVE, not STATUS, at 1563.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ExportFunctionLookupCSV lines 1550–1564

Impact: Unreviewed migrated definitions become selectable as though released. Whether downstream consumers independently gate these entries requires integration validation.

Recommended correction: Export only APPROVED and ACTIVE=YES for released lookups, with a separate explicitly marked review catalog.

## LIB-04 — Every action repeats whole-sheet protection and locking work

Severity: high; evidence class: static performance hazard; Excel freeze not reproduced.

Most public actions call PrepareWorkbook, which calls ApplyWorkbookSecurity. That loops all worksheets and sets ws.Cells.Locked for the entire worksheet, unprotecting/reprotecting system sheets. RefreshBrowser and RefreshReview and ValidateBulkImport each prepare again, adding repeated passes.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_PrepareWorkbook lines 131–154; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ApplyWorkbookSecurity lines 185–234; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_RefreshReview lines 1300–1320

Impact: Avoidable Excel object-model calls and full-sheet formatting/protection at each button press; risk of long UI stalls independent of row count.

Recommended correction: Apply protection once at workbook open/install and only update changed sheets; lock bounded input/data regions and use a nested-safe operation context for state restoration.

## LIB-05 — Bulk import repeatedly scans worksheets and writes one cell at a time

Severity: high; evidence class: static performance hazard.

Import clears A11:R100000 (1,799,820 cells), scans existing parts per row, performs 18 cell writes per imported row and calls ConfigValue per row. Validation repeats full scans; commit validates again and refresh review validates again.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ImportPartsFromWorkbook lines 629–695; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ValidateBulkImport lines 721–755; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_FindExactPartRow lines 1687–1698; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_PartNumberExistsUnderDifferentManufacturer lines 1642–1653; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_GetAtHeader lines 1835–1839

Impact: Approximate O(import rows × existing parts) identity search plus repeated header scanning and COM traffic; especially costly with large BOMs.

Recommended correction: Read bounded ranges into arrays once; cache normalized-key and part-number indexes and header maps; validate in memory, batch-write staging/results, and clear only previous populated staging extent.

## LIB-06 — Bulk additions and cost updates do not validate mandatory identity or price fields

Severity: high; evidence class: static validation gap.

cMfg and cDesc are optional aliases returning zero (618–619); import still stages rows. ValidateBulkImport requires only nonblank part number and a valid type/action, not nonblank manufacturer/description or finite nonnegative numeric cost. AddNewPartRecord validates only type (1338–1339). SavePart requires identity text but not numeric/nonnegative cost.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ImportPartsFromWorkbook lines 618–625; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ValidateBulkImport lines 722–746; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_AddNewPartRecord lines 1330–1369; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_SavePart lines 475–483

Impact: A typed import can create parts with empty manufacturer/description or accept invalid prices; missing cost column can overwrite an existing cost with blank.

Recommended correction: Require manufacturer/part/description for new records; distinguish missing/blank cost from zero and from clear-price intent; reject invalid prices/currencies before any write.

## LIB-07 — Library writes are incremental with no rollback on later failure

Severity: high; evidence class: static atomicity gap.

SaveFunction inactivates current components at 1158, appends variants/components at 1174–1181, and only later overwrites master row and exports CSV at 1187–1208. EH merely displays an error. BulkCommit similarly mutates records incrementally (812–861) and EH only resets screen state.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_SaveFunction lines 1153–1214; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_CommitBulkImport lines 812–875

Impact: An error mid-operation can leave partial revisions, inactive original components, orphaned outputs, or only part of a bulk commit.

Recommended correction: Validate all records before write, stage an immutable candidate snapshot, use database transactions in combined suite, and publish files with temporary-file plus atomic replacement.

## LIB-08 — Function edit round trip does not preserve component quantity or validate consistent group metadata

Severity: medium; evidence class: static data-loss edge case; current supplied component quantities are all 1.

LoadSelectedFunction copies BOM row quantity but not FUNCTION_COMPONENTS.QTY (970–980). SaveFunction hardcodes componentQty=1 (1178); metadata is taken only from first row of each group (1113–1126). AssemblyIsValid validates rows individually and does not compare grouped type/block/I/O/notes values (1226–1240).

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_LoadSelectedFunction lines 970–980; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_SaveFunction lines 1110–1130,1178–1181; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_AssemblyIsValid lines 1217–1244

Impact: Future component quantities other than 1 would be reset; conflicting metadata in later rows is silently discarded. Existing supplied 44 component rows all have quantity 1.

Recommended correction: Make component-level quantity explicit and preserve it through load/save; reject conflicting values within one component group.

## LIB-09 — JoinUnique fails deduplication after multiple tokens have been joined

Severity: medium; evidence class: static duplicate-token defect.

JoinUnique writes tokens using " | " at 1769 but tests membership using unspaced delimiters at 1768. After currentText="B | PBL", a repeated "B" or "PBL" is not found as the exact "|TOKEN|" substring.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_JoinUnique lines 1764–1770

Impact: Repeated tag/block/conveyor values can accumulate in newly saved function metadata. No such duplicated tokens were observed in current supplied FUNCTION_MASTER fields.

Recommended correction: Use a case-insensitive dictionary or split/trim token comparison; serialize once after collecting unique tokens.

## LIB-10 — CSV export is not atomic and does not close its file handle on error

Severity: medium; evidence class: static output-integrity gap.

Export opens the final target For Output at 1559, truncating it before writing. It has no local error handler around writes/Close (1550–1568), no UTF-8 encoding control, no revision/status columns.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ExportFunctionLookupCSV lines 1550–1568

Impact: An interruption or malformed cell error can leave a partial lookup; ANSI output may not preserve non-ASCII descriptions on all Windows locales.

Recommended correction: Write UTF-8 to same-directory temporary file, verify row count and digest, then replace final file after closing.

## LIB-11 — Variant identity duplicates remain after migration

Severity: medium; evidence class: verified data review item.

Four active type+signature duplicate groups: DV-PBL-002/DV-PBL-003; DV-PBB-001/DV-PBB-002; DV-PBL-006/DV-PBL-007; DV-B-005/DV-B-006.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_FindMatchingVariant lines 1518–1531

Impact: New assembly matching returns the first matching variant while historical component references can use either. This is a review issue rather than proof the assemblies differ.

Recommended correction: Review aliases and migration history; retain historical identifiers and map canonical aliases without silently rewriting historical BOMs.

## LIB-12 — Currency-only cost changes and backdated imports are not represented faithfully in cost history

Severity: medium; evidence class: static audit-trail gap.

Cost history is appended only when numeric/text cost value changes (525,846); currency changes alone are ignored. COST_HISTORY.DATE always uses Date (1469), while PART_MASTER.COST_AS_OF_DATE uses staging B4 (838,1355). AppendRevision hardcodes an author instead of recording the actual operator (1577).

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_SavePart lines 516–525; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_CommitBulkImport lines 835–846; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_AppendCostHistory lines 1463–1475; modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_AppendRevision lines 1570–1580

Impact: History omits some economic changes, conflates effective and recorded dates, and is not a reliable per-operator audit trail.

Recommended correction: Track effective date and recorded timestamp separately; compare amount/currency/vendor tuple and record authenticated or explicit operator identity.

## LIB-13 — Opening a selected workbook does not locally suppress source macro events or restore prior Excel state

Severity: medium; evidence class: static import isolation gap.

Import calls Workbooks.Open(...ReadOnly:=True,UpdateLinks:=0) at 611 without local AutomationSecurity or EnableEvents context. ScreenUpdating is restored to True rather than the previous value (610,700–708). Calculation and events are not bracketed during bulk cell writes.

References: modONGEN_MasterLibraryAdminV3.bas / ONGEN_ML3_ImportPartsFromWorkbook lines 610–611,700–708

Impact: Read-only/link-disabled does not itself mean a source workbook open event cannot run; nested calls can change caller state and trigger unrelated event work. No source macro was executed in this audit.

Recommended correction: Use a guarded import context preserving and restoring calculation/events/display/security state on all exits; open sources with automation macros disabled and never lower security globally.

## Tested and untested

Verified: read-only extraction, all module inventory, record counts, primary-key and reference checks, supplied CSV/library mismatch, normalized identity/signature duplicate checks.

Untested: VBA compile in Windows Excel, button dispatch, Excel UI timing, macro error handling at runtime, native VBA execution, workbook file save/open behavior. No measured Excel speedup is claimed.
