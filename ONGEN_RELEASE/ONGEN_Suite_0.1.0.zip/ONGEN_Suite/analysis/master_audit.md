# ONGEN PD master static code audit

All extracted source modules in master inspected statically; no ExcelVBA runtime or compile available. PowerCalculation workbook unavailable due32MiBtransferlimit.

Coverage: 42 modules/classes/forms, 17,031 extracted source lines, 662 procedure declarations. Coverage means static inspection, not compilation, execution, or phase acceptance.

## Phase map

- **0**: `Build_Main_Dashboard -> Validate_Definition_Workflow -> UI_RefreshAll -> NAV_Open_Worksheet_Launcher`. Control/navigation only; validation currently sheetname-only.
- **1A**: `Import_CSV_To_SIS_TAG_EXPORT`. CAD CSV -> SIS_TAG_EXPORT; literal identifiers require text-aware import.
- **1B**: `BOQ_Import`. External BOQ ->23 standard headers in BOQ.
- **1C**: `Verify_SIS_TAG_EXPORT_From_BOQ_v2`. BOQ/CAD LPN dictionaries ->MISSING_LPN QA only.
- **1D**: `Build_PD5_From_BOQ`. CAD+BOQ ->SIS_TAG_PD5 with directelectrical exceptions and excluded supports.
- **2A**: `Build_SIS_TAG_PD5_Manifest_Using_MotorVoltage`. PD5+DATA_POWER ->Power Supply Bus,Estimated_Power_Supply,PSU_Terminal_Assignment.
- **2B–2D**: `PD4_ESTIMATE -> FillBlockFromLibraryWorkbook -> Export_PD4_Estimate_PSU_To_HWE_PSU_CSV`. EstimatedPSU+PD5 ->PD4_Estimate_PSU ->Library TYPE/BLOCK ->HWE_PSU.csv.
- **3A**: `Copy_PD5_To_Import_And_Fill_From_BOQ`. PD5+BOQ+FUNCTION DEFINITION ->SIS_TAG_IMPORT_PD2, CFN and parentIO enrichment.
- **3B**: `Build_Function_Device_Clean`. PD2+functioncomponents ->FUNCTION DEVICE pd2, parts1..10 and rowIO.
- **4A**: `PowerRT_4A_Send_PD5_FAST`. PD5+estimatedPSU ->external41column PD5_IMPORT; external PC_Refresh_Definition_From_PD5.
- **4B**: `PowerRT_4B_Build_PD6_FAST`. Master PD5/PD4/function/IO ->PD6 System Designed.
- **4C**: `PowerRT_4C_Send_PD6_FAST`. External PC_Finalize_PD_Return; PC_LastFinalizationOK and PC_LastFinalizationMessage; Export PD6 Designed Definition.
- **4D**: `PowerRT_4D_Import_Power_FAST`. External finalPowerreturn ->PD6 assignments +power metadata backfill.
- **5A**: `DeviceWF_5A_Update_Specification_FAST`. FUNCTION DEVICE pd2 +PD2 VFD +PD6 ->Specification Devices12 columns; preserveblockselections.
- **5B**: `DeviceWF_5B_Build_FieldIO_FAST`. Specification+PD6+PD2VFD ->Field Device IO ONGEN12 columns inclHANDLE.
- **5C**: `DeviceWF_5C_Send_Run_B03`. FieldDevice A:K ->IO_DEVICE_LIST11 columns in B05; external Run_IO_Generator_V6.
- **5D**: `DeviceWF_5D_Import_B03_Return_FAST -> IOReturn_Update_IO_DEVICE_EM_From_PD2_And_FunctionDefinition`. External IO_Block_Summary ->IO DEVICE EM24 columns +master metadata/BOM.
- **5E–5G**: `GoSheet_SpecificationDevices -> Fill_IO_BlockFromLibraryWorkbook -> Step05G_Backfill_IO_PSU_Terminals`. ManualIO review,TYPE/BLOCK mapping,existingBUS2/terminal backfill; no fresh redesign.
- **6A–6D**: `Build_PD6_System_Designed_RELEASED -> Fill_PD6_From_PowerCalculation_RELEASED -> Export_PD6_Export_System_To_CSV -> Export_IOBLOCK_To_CSV`. FinalPD6 rebuild+Powerreturn; frozen41columnPD6 CSV and IOBlockCSV.
- **7A–7D**: `Export_Function_Device_PD2_To_CSV -> Export_PD6_Export_System_To_CSV -> GoSheet_PD6_System_Designed -> Validate_Definition_Workflow`. Combinedfunction/PSU/IO CADCSV; finalPD6review; structuralvalidation.

## Findings

### M01 — CRITICAL: 5A existing VFD update resets total row counter
Evidence: `mod20_DeviceWorkflow.bas:189`, `mod20_DeviceWorkflow.bas:229`. confirmed source defect; Python regression model reproduces loss.
Existing VFD before final output row truncates trailing rows; later additions can overwrite them.
Correction: Separate targetRow from total outRow; drop-in source and diff delivered.

### M02 — HIGH: 3A clears full worksheet-height for each copied column
Evidence: `mod09_GeneratePD2.bas:190`. confirmed code behavior; runtime duration unmeasured.
Expands ClearContents scope to1048575 cells per column instead of existing data extent.
Correction: Snapshot existing last used row and bound stale-data clear; drop-in source and diff delivered.

### M03 — HIGH: 3B source-by-definition COM scan and early delete
Evidence: `mod10_FunctionDevices.bas:124`, `mod10_FunctionDevices.bas:147`, `mod10_FunctionDevices.bas:171`, `mod10_FunctionDevices.bas:186`, `mod10_FunctionDevices.bas:224`. confirmed code structure; freeze duration unverified.
O(source rows x definition rows) scan, per-cell reads/writes, prior output deleted before success.
Correction: Read both sheets once, preindex normalizedCFN to component rows, build/deduplicate in memory, stage output then commit. Preserve per-component IO and single-device parent fallback.

### M04 — HIGH: Specification push selects source without required function code
Evidence: `mod20_DeviceWorkflow.bas:126`, `modONGEN_CentralFunctionSystem.bas:262`, `modONGEN_CentralFunctionSystem.bas:276`, `modONGEN_CentralFunctionSystem.bas:285`. confirmed producer/consumer schema defect.
Normal5A creates12 columns withoutCFN; central push selects it then rejects missingCFN.
Correction: Carry function+component+variant identities in canonical data; choose validated source or explicit join. Not automatically patched because identity policy needs contract validation.

### M05 — HIGH: 4D failed import can be followed by metadata backfill
Evidence: `mod11_PowerRoundTrip.bas:251`, `mod11_PowerRoundTrip.bas:252`, `mod14_ImportPD6Power.bas:127`. confirmed source control-flow defect.
Inner failure is displayed then swallowed; wrapper cannot detect it.
Correction: Capture and rethrow error after restoring application state; narrow source patch delivered.

### M06 — HIGH: IO BOM fallback keyed only on function code
Evidence: `mod15_IOReturnMerge.bas:81`, `mod15_IOReturnMerge.bas:177`. confirmed source defect with actual multi-componentCFN example.
CF-B-010 includes beacon and PBL; function-only map can supply wrong component part.
Correction: Composite function+component/variant+tag key; ambiguity blocks merge. No automatic engineering-part reassignment.

### M07 — MEDIUM: Global refresh forces full calculation and suppresses errors
Evidence: `mod01_UI.bas:33`, `mod01_UI.bas:34`, `mod01_UI.bas:35`. confirmed source behavior; runtime freeze unverified.
RefreshAll followed by CalculateFull applies beyond currently required phase and hides refresh/calculation errors.
Correction: Refresh required connections only; explicit completion and error checks; calculate affected ranges.

### M08 — MEDIUM: Existing wrapper cannot establish all inner step success
Evidence: `mod26_Performance.bas:37`, `mod26_Performance.bas:91`, `mod09_GeneratePD2.bas:456`. confirmed source structure.
Several inner procedures display dialogs/return without signaling failure; log may say RETURNED with detectederror=False. Direct unwrapped calls reset settings instead of preserving snapshots.
Correction: Return explicit status/raise errors and gate nextphase; retain existing guard rather than replacing with simplistic DoEvents.

### M09 — MEDIUM: CAD family fallback lacks unique-parent proof
Evidence: `mod20_DeviceWorkflow.bas:834`, `mod20_DeviceWorkflow.bas:848`, `mod17_FunctionCSV.bas:619`. confirmed fallback behavior; affected assignment depends on data.
Firstfour-digit family can match a different suffix conveyor and assign its handle/geometry.
Correction: Use exact parent identities, require unique fallback and report ambiguity; do not invent geometry.

### M10 — MEDIUM: Parts1..10 produced but frozen exports retain only1..5
Evidence: `mod10_FunctionDevices.bas:5`, `mod17_FunctionCSV.bas:172`, `mod19_PD6CSV.bas:109`. confirmed contract limitation.
New BOM slots6..10 do not reach those existing CAD exports.
Correction: Version export schema; preserve frozen legacy contract and offer explicit extended export.

### M11 — MEDIUM: IO CSV export has empty-sheet dereference and no local cleanup handler
Evidence: `mod18_IOBlockCSV.bas:24`, `mod18_IOBlockCSV.bas:26`, `mod18_IOBlockCSV.bas:27`. confirmed source defect on empty existing sheet.
Find returnsNothing on empty sheet; .Row dereference errors after disablingUI; direct execution may leave settings changed.
Correction: Preflight nonempty range, stage output, capture/restore settings in one cleanup path.

### M12 — MEDIUM: Master sync uses cleanup snapshots captured after fallible open
Evidence: `modONGEN_CentralFunctionSystem.bas:122`, `modONGEN_CentralFunctionSystem.bas:126`, `modONGEN_CentralFunctionSystem.bas:145`, `modONGEN_CentralFunctionSystem.bas:161`. confirmed source control-flow hazard.
Early open/version error jumps to cleanup with default oldCalc=0; cleanup can itself fail and obscure primary error.
Correction: Capture appstate before first fallible operation or track stateCaptured Boolean; preserve original error.

### M13 — LOW: Workbook validation is structural only
Evidence: `mod00_MainDashboard.bas:230`, `mod00_MainDashboard.bas:235`. confirmed scope limitation.
Five sheetnames do not prove correct headers, data, uniqueness,Powerreturn freshness or device assignments.
Correction: Phase prerequisites, schema contracts, duplicate/orphan checks, rowcounts and transferrunIDs.

### M14 — LOW: Workbook-open library scan can block startup
Evidence: `ThisWorkbook.cls:12`, `modONGEN_CentralFunctionSystem.bas:822`, `modONGEN_CentralFunctionSystem.bas:932`. static runtime risk; actual startup duration unmeasured.
Folder/ancestor search and workbookopen/versioncheck run synchronously; network/OneDrive latency is possible.
Correction: Cached local metadata/explicit sync; time/checkpoint each filesystem boundary; startup should not silently synchronize.

## Existing protections to retain

The original already uses bulk arrays/dictionary joins extensively in PD5,PD4,Powerreturn,PD6 and FieldIO pathways. mod26_Performance already provides a busylock, timed cooperative DoEvents, cancellation checkpointing, TEMP logs and restoration of calculation/events/screen/alerts/status/cancelkey. No result here supports claiming these were newly added or that a percentage speedup was measured.

## Module-by-module coverage

| Module | Lines | Procedures | Static assessment |
|---|---:|---:|---|
| Sheet1.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet10.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet11.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet2.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet3.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet4.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet5.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet6.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet7.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet8.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| Sheet9.cls | 8 | 0 | Sheet class attributes only; no procedures present. |
| ThisWorkbook.cls | 14 | 1 | Workbook_Open calls master-library check; BUILD_INFO startup-events-none text is stale. |
| frmPDLauncher.frm | 536 | 17 | Embedded modal worksheet list/search/navigation form; no engineering import/export execution found. |
| mod00_MainDashboard.bas | 549 | 69 | Phase wiring checked. Validation checks five sheet names only, not phase data/schema/freshness. Dashboard uses PDPerf_EntryFor wrappers. |
| mod01_UI.bas | 43 | 4 | RefreshAll + CalculateFull are unconditional synchronous operations; errors suppressed. Launcher uses permanent embedded form. |
| mod02_ImportCAD.bas | 78 | 1 | CSV opened with Excel automatic type inference, then copy/paste; loses literal identifier fidelity before transfer. Resets Boolean settings to True. |
| mod03_ImportBOQ.bas | 165 | 9 | Detects header among first30 rows across sheets; column-array imports; replaces destination before all target requirements checked. Resets app settings rather than entry snapshots. |
| mod04_VerifyCAD_BOQ.bas | 119 | 6 | Dictionary QA intentionally leaves PD5 unchanged. Identifier normalization removes spaces/underscore/hyphens; duplicates collapse silently. |
| mod05_BuildPD5.bas | 408 | 23 | Bulk arrays and dictionaries; output built before writes, cancellation disabled during two-sheet commit. Electrical direct-device exceptions preserved. No rollback across two writes. |
| mod06_EstimatePSU.bas | 2510 | 80 | Long synchronous cell-driven allocator with family lookahead, XYZ reuse, sorting helper columns, per-type DATA_POWER loads and guarded cycle traversal. 40A/35ft/20A/20ft are explicit engineering assumptions, not independently certified limits. |
| mod07_PD4Estimate.bas | 328 | 14 | Bulk dictionary joins restore metadata; best-source priority and LPN token fallback; unqualified duplicates can select first highest-scored row. |
| mod08_PSUBlockLibrary.bas | 162 | 2 | Dictionary library lookup, but cell-driven loop and unconditional close of opened/read-only workbook. Snapshot state not preserved for direct calls. |
| mod09_GeneratePD2.bas | 758 | 15 | 3A array enrichment already present. Full-height ClearContents per copied column is unnecessary. CFN IO summed across function rows while 3B deduplicates BOM rows; requires consistency reconciliation. |
| mod10_FunctionDevices.bas | 366 | 5 | 3B nested source-by-definition scanning with worksheet COM reads before match; 39 per-device writes. Deletes previous output before build; no active local error handler during build. |
| mod11_PowerRoundTrip.bas | 786 | 36 | 4A bulk PD5_IMPORT;4C requires named external callbacks;4D outer wrapper can continue backfill after inner failure. Power workbook unavailable. |
| mod12_BuildPD6.bas | 764 | 21 | Bulk source integration. ONGEN_MECH suppression by SIS sequence may remove a parent whenever any child shares sequence; verify intended grouping. |
| mod13_ExportPD6Power.bas | 852 | 31 | Legacy source export validates too late/permits absent fields and can clear/save target. Already substantial per-column bulk reads/writes. |
| mod14_ImportPD6Power.bas | 1030 | 22 | Bulk power merge; first-wins duplicate SIS identity, blank-only AREA update; errors displayed and swallowed. Duplicate missing PSU append count can exceed actual unique appends. |
| mod15_IOReturnMerge.bas | 271 | 14 | Bulk return merge. Function-code-only fallback loses component identity and can attach a different component part. See power_paths_audit.md. |
| mod16_IOBlockLibrary.bas | 164 | 2 | Dictionary TYPE->BLOCK, but duplicate type first-wins and many COM calls. Direct-call error cleanup resets settings to True. |
| mod17_FunctionCSV.bas | 948 | 27 | Combined function/PSU/IO export. CAD progressive/family fallback can choose geometry/handle without unique parent proof; index family keys, report ambiguity. Selected exports retain only parts1..5 although 3B carries1..10. |
| mod18_IOBlockCSV.bas | 73 | 1 | Find dereference on empty output; no local general error handler after app state changes; saved temporary workbook remains open on success. |
| mod19_PD6CSV.bas | 137 | 5 | Frozen41-column CAD contract verified; checks required headers and nonzero SIS rows. Cell-driven collection but array output; omits extra parts by contract. |
| mod20_DeviceWorkflow.bas | 1137 | 29 | 5A row-counter reassignment can truncate/overwrite devices. 5B bulk arrays but linear existing-VFD refresh + per-device four-digit-family CAD fallback. 5C11-column IO contract matches supplied B05. 5D bulk return but downstream errors may be swallowed. |
| mod21_CSVTraceability.bas | 482 | 19 | Session caches reset before per-export enrichment; source sheets read-only; standard ML/ZL export fills. Parent fallback may be ambiguous; keep resolved provenance. |
| mod22_PSUTerminalAllocator.bas | 416 | 23 | Four-terminal capacity checks and center-span increments explicit. Negative load/length clamped to0; warn/reject invalid input before allocation rather than accepting invalid data. |
| mod23_WorksheetNavigation.bas | 578 | 24 | Forms-button architecture with snapshot state; repair path mutates sheet buttons/legacy launcher sheet. Not main computation bottleneck. |
| mod24_WorksheetLauncherForm.bas | 222 | 5 | One-time form copy installer; disables automatic macros on selected source open and restores security. VBProject Trust access only relevant to installer, not ordinary launcher. |
| mod25_EASV25_8_Alignment.bas | 648 | 27 | 5G existing-BUS2-only IO load backfill, no redesign; capacity conflicts reported. Existing records skipped, so changed existing module current may remain stale unless explicitly rebuilt. |
| mod25_FinalCADReturnExport.bas | 642 | 24 | Union PD5/PSU CSV, real error captured before cleanup, text handle wrapper. Uses For Output ANSI writer; not guaranteed UTF8. Direct output file can remain partial on failure/cancel. |
| mod26_Performance.bas | 329 | 41 | Existing busy lock, 0.25s DoEvents, log/checkpoints, cancellation, full settings restore. Cannot interrupt blocked synchronous workbook open/save or external macro without cooperative yield; inner handlers may swallow errors and bypass mHadError. |
| modONGEN_CentralFunctionSystem.bas | 1428 | 65 | Workbook-open synchronous library path scan/version check. Sync copies BOM/component metadata. Push selects Specification Devices lacking CFN after5A. Sync captures app snapshots after library open, so early failures use uninitialized cleanup snapshots. |

## Validation and remaining boundaries

Python regression models demonstrate the existing5A counter defect and correctedcount/index behavior; sourceassertions check the proposed replacements. They do not compile or executeVBA. Run Debug>Compile VBAProject in WindowsExcel, then follow vba/patched/README.md on a copy.

PowerCalculation V4.6.xlsm was not read; its callbacks, internal calculation formulas, PSUcapacity logic and timing remain unverified. B05IO_DEVICE_LIST matches the master11columnhandoff; HANDLE is intentionally retained only in mastermetadata and must not be added silently to the legacycontract.

See power_paths_audit.md for detailed Power/IOmerge evidence, including duplicate return identity/PSUappend risks and legacyexport preflight deficiencies.

No original XLSM or embedded VBA binary was altered. Drop-in source patches are separate reviewable deliverables.
