"""Static checks only. These do not compile or execute VBA in Excel."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = ROOT / 'analysis/vba/ONGEN PD_DEFINITION_MASTER_WORKFLOW_V5.1.6.5/mod14_ImportPD6Power.bas'
PATCHED = ROOT / 'vba/patched/mod14_ImportPD6Power.bas'


def procedure(source, name):
    match = re.search(r'(?mi)^Public Sub ' + re.escape(name) + r'\([^\n]*\)\s*\n', source)
    if not match:
        raise AssertionError(f'Missing public procedure {name}')
    end = re.search(r'(?mi)^End Sub\s*$', source[match.end():])
    return source[match.end():match.end() + end.start()]


class PowerImportPatchChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = ORIGINAL.read_text(encoding='utf-8')
        cls.patched = PATCHED.read_text(encoding='cp1252')
        cls.path = procedure(cls.patched, 'Fill_PD6_From_PowerCalculation_Path_RELEASED')
        cls.failure = cls.path.split('\nCleanFail:\n', 1)[1]

    def test_public_procedure_signatures_preserved(self):
        pattern = r'(?mi)^Public (?:Sub|Function) [^\n]+'
        self.assertEqual(re.findall(pattern, self.original), re.findall(pattern, self.patched))

    def test_failure_is_captured_before_cleanup_and_propagated(self):
        cleanup = self.failure.index('On Error Resume Next')
        for capture in ['errNum = Err.number', 'errDesc = Err.description', 'errSource = Err.Source']:
            self.assertLess(self.failure.index(capture), cleanup)
        raise_pos = self.failure.index('Err.Raise errNum, errSource, errDesc')
        for restore in ['Application.ScreenUpdating = oldScreen', 'Application.EnableEvents = oldEvents',
                        'Application.Calculation = oldCalc', 'Application.DisplayAlerts = oldAlerts']:
            self.assertLess(self.failure.index(restore), raise_pos)
        self.assertLess(self.failure.index('On Error GoTo 0'), raise_pos)
        self.assertNotIn('Exit Sub', self.failure)
        self.assertNotIn('MsgBox', self.failure)

    def test_direct_button_handles_propagated_failure(self):
        button = procedure(self.patched, 'Fill_PD6_From_PowerCalculation_RELEASED')
        self.assertLess(button.index('On Error GoTo DirectFail'),
                        button.index('Fill_PD6_From_PowerCalculation_Path_RELEASED FilePath'))
        failure = button.split('\nDirectFail:\n', 1)[1]
        self.assertIn('MsgBox', failure)
        self.assertIn('Err.number', failure)
        self.assertIn('Err.description', failure)

    def test_state_changes_are_inside_error_handler_scope(self):
        self.assertLess(self.path.index('On Error GoTo CleanFail'),
                        self.path.index('Application.ScreenUpdating = False'))

    def test_engineering_merge_and_helper_procedures_unchanged(self):
        anchor = '\nPrivate Function BuildCompletionMessage('
        self.assertEqual(self.original.split(anchor, 1)[1], self.patched.split(anchor, 1)[1])
        source = (ROOT / 'analysis/vba/ONGEN PD_DEFINITION_MASTER_WORKFLOW_V5.1.6.5/mod11_PowerRoundTrip.bas').read_text()
        caller = procedure(source, 'PowerRT_4D_Import_Power_FAST')
        self.assertLess(caller.index('On Error GoTo Fail'),
                        caller.index('mod14_ImportPD6Power.Fill_PD6_From_PowerCalculation_Path_RELEASED path'))
        self.assertIn('PowerRT_BackfillFinalPowerAssignments path', caller)


if __name__ == '__main__':
    unittest.main(verbosity=2)
