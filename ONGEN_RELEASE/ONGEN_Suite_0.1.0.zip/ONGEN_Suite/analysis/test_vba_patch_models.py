"""Algorithm regression models/source checks only. These do not execute or compile VBA."""
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def rebuild_model(initial, parents, fixed):
    rows = list(initial)
    seen = {name: i + 1 for i, name in enumerate(rows)}
    count = len(rows)
    for name in parents:
        if name in seen:
            if fixed:
                target = seen[name]
            else:
                count = seen[name]
                target = count
        else:
            count += 1
            target = count
            seen[name] = target
            if target > len(rows):
                rows.append(name)
            else:
                rows[target - 1] = name
    return rows[:count]

class VBAPatchModels(unittest.TestCase):
    def test_original_existing_vfd_truncates_trailing_devices(self):
        self.assertEqual(rebuild_model(['VFD_A', 'Beacon', 'Scanner'], ['VFD_A'], False), ['VFD_A'])
    def test_fixed_existing_vfd_preserves_trailing_devices(self):
        self.assertEqual(rebuild_model(['VFD_A', 'Beacon', 'Scanner'], ['VFD_A'], True), ['VFD_A', 'Beacon', 'Scanner'])
    def test_fixed_mixed_update_append_preserves_all_devices(self):
        self.assertEqual(rebuild_model(['VFD_A', 'Beacon', 'Scanner'], ['VFD_A', 'VFD_B'], True), ['VFD_A', 'Beacon', 'Scanner', 'VFD_B'])
    def test_fixed_multiple_vfd_updates_do_not_change_count(self):
        self.assertEqual(rebuild_model(['VFD_A', 'Beacon', 'VFD_B', 'Scanner'], ['VFD_B', 'VFD_A'], True), ['VFD_A', 'Beacon', 'VFD_B', 'Scanner'])
    def test_patch_uses_separate_vfd_index(self):
        s = (ROOT/'vba/patched/mod20_DeviceWorkflow.bas').read_text()
        block=s[s.index("'Pass 2: add/update parent VFD"):s.index("'Trim the oversized work array")]
        self.assertNotIn('outRow = CLng(seen(k))',block)
        self.assertIn('targetRow = CLng(seen(k))',block)
        self.assertIn('targetRow = outRow',block)
        self.assertNotIn('outData(outRow,',block)
    def test_bounded_clear_covers_existing_data_extent(self):
        for old_last in [1, 2, 4560, 9000]:
            old_nonempty_rows = set(range(2, old_last+1))
            bounded_clear = set(range(2, old_last+1))
            self.assertEqual(old_nonempty_rows-bounded_clear,set())
    def test_bounded_clear_source_snapshot_precedes_copy(self):
        s=(ROOT/'vba/patched/mod09_GeneratePD2.bas').read_text()
        self.assertIn('lastRowExisting = LastUsedRow(wsDest)',s)
        self.assertNotIn('wsDest.Cells(wsDest.rows.count, destCol)).ClearContents',s)
        self.assertIn('wsDest.Cells(lastRowExisting, destCol)).ClearContents',s)

if __name__ == '__main__':
    unittest.main(verbosity=2)
