# Master power and I/O return paths: static audit

Scope: all five modules `mod11_PowerRoundTrip` (786 lines), `mod12_BuildPD6` (764), `mod13_ExportPD6Power` (852), `mod14_ImportPD6Power` (1,030), and `mod15_IOReturnMerge` (271) were inspected. Line numbers refer to the extracted UTF-8 sources in `analysis/vba/ONGEN PD_DEFINITION_MASTER_WORKFLOW_V5.1.6.5/`. No Excel/VBA execution or compilation was possible. Static defects below establish what the source does, not that a user-observed freeze has been reproduced. The uploaded Power Calculation XLSM could not be transferred because it exceeds 32 MiB; its formulas and macro implementations are uninspected.

## Phase contracts and existing useful optimizations

| Step | Entry procedure | Inputs | Outputs and external dependencies |
|---|---|---|---|
| 4A | `PowerRT_4A_Send_PD5_FAST` | `SIS_TAG_PD5`, optional `Estimated_Power_Supply` and `Power Supply Bus` | A 41-column `PD5_IMPORT` dataset in selected Power workbook; calls `PC_Refresh_Definition_From_PD5`; saves Power workbook. Uses bulk arrays and dictionary source lookup. |
| 4B | `PowerRT_4B_Build_PD6_FAST` → `Build_PD6_System_Designed_RELEASED` | `SIS_TAG_PD5`, `PD4_Estimate_PSU`, `IO DEVICE EM`, `FUNCTION DEVICE PD2` | Rebuilds `PD6 System Designed`, including one-time sizing and a bulk final write. Missing sources are skipped. ONGEN_MECH rows are suppressed if a non-ONGEN_MECH row has the same normalized sequence. |
| 4C | `PowerRT_4C_Send_PD6_FAST` | Selected Power workbook with `PD5_IMPORT` and `EM MTR LIST` | Calls `PC_Finalize_PD_Return`, `PC_LastFinalizationOK`, `PC_LastFinalizationMessage`; requires data in `Export PD6 Designed Definition`; saves Power workbook. Despite procedure name, this entry does not invoke mod13 to send master PD6 rows. |
| 4D | `PowerRT_4D_Import_Power_FAST` → mod14 path procedure | Power `Export PD6 Designed Definition`; master `PD6 System Designed` | Case-insensitive, trimmed SIS_SEQUENCE match; overwrite nonblank element, switchgroup and panel; AREA_NUMBER fills blanks only; append missing PSU rows; then backfill assignments to master source sheets. |
| Legacy alternate export | `Export_PD6_System_Designed_Definition_FAST_RELEASED` | Master/open workbook `PD6 System Designed`, Power session path | Writes 18 fields to both Power `Definition_Import` and `Export PD6 Designed Definition`; refreshes group/panel from `EM MTR LIST`; saves destination. This is separate from the current 4C macro. |
| 5D | `IOReturn_Update_IO_DEVICE_EM_From_PD2_And_FunctionDefinition` | `IO DEVICE EM`, optional `FUNCTION DEVICE pd2`, `SIS_TAG_IMPORT_PD2`, `FUNCTION DEFINITION` | Bulk I/O output merge: base sequence + tag/type, coordinate fallback by sequence, then parts fallback by function code. |

Already optimized: 4A bulk source read/output write (mod11 44, 66, 157–158); 4B preallocation, dictionaries, single final body write (mod12 74–111); mod13 column-array refresh (354–430); mod14 dictionary merge (280–363); mod15 dictionary/array pass (31–94). These are existing source features, not changes made by this audit. No measured speedup is claimed.

## Confirmed source defects and gaps

### PWR-01 — Failed 4D import does not stop subsequent backfill (high)

`mod11_PowerRoundTrip.bas:251–252` calls `Fill_PD6_From_PowerCalculation_Path_RELEASED` and immediately calls `PowerRT_BackfillFinalPowerAssignments`. The inner procedure's failure handler at `mod14_ImportPD6Power.bas:127–145` restores state and displays a message, but neither raises the error nor returns a success flag. Therefore the outer operation cannot distinguish a failed PD6 import from success and can continue to change source assignments. This is confirmed control flow. Change the inner operation to a function returning an explicit result or re-raise a captured error after cleanup. Commit the entire return transaction only after successful validation, matching, and append staging.

### PWR-02 — Function-only fallback chooses the wrong device's part (high)

`mod15_IOReturnMerge.bas:177–193` builds the definition dictionary solely by CONTROL_FUNCTION_NUMBER and overwrites earlier rows; `:81–86` fills missing parts from that one row. The master actually contains 38 nonblank definition rows but only 30 function codes; six codes have multiple rows. For CF-B-010, worksheet rows 2–5 alternate B (TL70BYQ) and PBL (K50LGXXPPB2Q). The dictionary ends on the PBL row. A B device with missing parts can consequently receive the PBL part when this fallback executes. Resolve by function + device tag/type + approved variant/conveyor context; preserve a one-to-many set and report ambiguity rather than selecting the last row. This is demonstrated against source and supplied worksheet data, not an Excel execution.

### PWR-03 — Duplicate return identities are silently first-wins (high)

`mod14_ImportPD6Power.bas:285–300` retains the first SIS_SEQUENCE return row and ignores all later rows, with no conflict comparison. `mod11_PowerRoundTrip.bas:568–579` does the same for metadata backfill. Conflicting panel/group assignments can be silently hidden. mod13 uses separate first-usable dictionaries for switchgroup (`:377–380`) and panel (`:384–387`), which can even combine values from different duplicate source rows. Validate unique identities or prove repeated rows agree across all controlled return fields; reject conflicts before changing destination sheets.

### PWR-04 — PSU append counts duplicates but writes only unique rows (medium)

`mod14_ImportPD6Power.bas:409–416` increments appendCount for every missing PSU source row without updating destSet. The second pass (`:421–435`) updates destSet, so repeated new PSU sequences are copied once. `:440–441` nevertheless writes and reports appendCount, leaving blank allocated trailing rows and overstating the number appended. Maintain an append identity set during sizing or size/write/report outRow after unique selection. This is a provable two-pass mismatch when duplicated new PSU return rows are supplied.

### PWR-05 — Legacy alternate export can save an empty or incomplete replacement (high)

`mod13_ExportPD6Power.bas:123–132` gathers missing source headers as warning text and clears both destination datasets before requiring a valid source identity/header set or nonzero row count. The empty-source path (`:156–159`) remains successful and `:167` saves the destination; warnings are shown only after saving (`:184–187`). Use required schema validation, row/identity checks and a staged new output before clearing any prior data; preserve formulas and unrelated user-managed columns; save a separate output/revision. Do not run this alternate export merely because its name appears in old documentation.

### PWR-06 — 4A overwrites the target before the required Power callback is proven available (high)

`mod11_PowerRoundTrip.bas:153` validates only an `EM MTR LIST` sheet (`:374–376`). It clears/writes `PD5_IMPORT` (`:156–158`) and only then invokes `PC_Refresh_Definition_From_PD5` (`:161`). A missing/blocked/failed callback leaves a changed open target even though 4A reports failure. No rollback is implemented. This path does not by itself prove the provided Power V4.6 lacks the callback; that file is inaccessible. Validate the intended workbook revision and callback contract first, stage a copied destination, and commit only when refresh validation succeeds.

### PWR-07 — Completion counts do not imply all engineering prerequisites exist (medium)

4B deliberately skips missing sources (`mod12_BuildPD6.bas:89–98`) and missing SIS_SEQUENCE sources and still reports `Phase 4B complete` (`:118–124`). 5D treats absent supporting worksheets as empty dictionaries (`mod15_IOReturnMerge.bas:115–116`, `:156–157`, `:174–175`), has no unmatched-row count, and still reports merge complete (`:99–102`). This can be a valid partial-preview mode, but it is not a release readiness gate. Explicitly distinguish partial draft generation from a complete engineering release, with required sheet/field counts and unresolved matches.

### PWR-08 — Rebuilding PD6 erases accepted return/manual assignments unless reimported (medium)

4B clears the existing output (`mod12_BuildPD6.bas:102`, `:318–328`) and regenerates SIS_ELEMENT_NUMBER (`:161–162`, `:192–197`, `:340–347`) rather than carrying forward the prior PD6 value. This is documented rebuild behavior, but rerunning 4B after 4D can replace returned/manual PD6 fields unless their source has been backfilled and reimported correctly. Persist revisions, invalidate downstream phases explicitly, and show a diff before replacing accepted assignments. No freeze is implied.

### PWR-09 — Open-workbook reuse does not enforce requested access mode (medium)

`PowerRT_OpenWorkbook` returns an already-open workbook by fullname without checking `.ReadOnly` (`mod11_PowerRoundTrip.bas:389–399`). 4A/4C can obtain a read-only workbook and fail only at save after earlier mutation; requesting read-only for 4D does not make an already writable workbook read-only. Validate required mode and `.Saved`/revision state, with explicit ownership of opened resources. The alternate mod13 opener (`:505`) omits UpdateLinks:=False, unlike the current mod11 opener (`:399`), so legacy export can prompt for links or refresh external links. Runtime impact depends on the selected file.

### PWR-10 — Residual worksheet I/O remains in supposedly in-memory paths (performance risk)

`PowerRT_BuildPSUMeta` (`mod11:507–525`) makes about 13 worksheet cell reads per accepted bus row; `PowerRT_BackfillPowerBus` (`:736–755`) reads cells repeatedly; `AppendMissingPSURowsFromPower` (`mod14:402–405`, `:428–432`) rereads headers for each appended row. Preload the bus block once, map headers once outside the row loop, and operate in arrays. These are static COM-call reductions; Excel duration and improvement have not been measured. Preserve the already present throttled PDPerf calls rather than adding unbounded DoEvents.

### PWR-11 — Synchronous external callback/open/save remain freeze boundaries (runtime-unverified)

Phase 4A `Application.Run` and `wbPower.Save` (`mod11:161–162`) and Phase 4C callbacks/save (`:199–215`) block the Excel UI thread. A pulse in the caller cannot guarantee responsiveness inside a long callback, link update or large-file save. Inspection of the missing Power workbook and timed Excel instrumentation are needed. Do not call these confirmed infinite loops. For the new suite, execute import/validation/output in a worker job with visible stages, stable input hashes, cancellation between stages and atomic file/database commits.

### PWR-12 — Full-body values write removes any user-inserted formulas (conditional data-preservation risk)

The return merge reads Value2 and writes all PD6 body columns as values (`mod14:304–363`); I/O return similarly writes its complete used rectangle (`mod15:31`, `:51`, `:94`). Any formulas in untouched columns become cached values. The supplied current output sheets must be checked separately for actual formulas before calling this observed data loss. Write only controlled columns, or reject formulas in an explicitly values-only contract; preserve unaffected columns in an immutable source/revision.

## Required Windows/Excel validation

1. Compile all source with `Debug > Compile VBAProject` on a disposable copy; confirm required references and current Power/Field workbook callbacks. This audit does not establish compiled/P-code behavior.
2. Measure 4A/4B/4C/4D and 5D separately with source row counts and open/refresh/write/save durations. Record Calculation, EnableEvents, ScreenUpdating and DisplayAlerts before/after success, cancellation and injected failures.
3. Verify no changed workbook/save remains after failed validation or callback; prove rollback on missing headers, read-only file, blocked macros and invalid path.
4. Return duplicate/conflicting sequences, repeated new PSU sequences, missing source sheets, formulas in untouched columns, and mismatched revisions. Check failure/report behavior, not merely a completion message.
5. Run 4B → 4C → 4D → Phase5 on a known engineering baseline; compare identities, tag assignments, return groups/panels, parts and CAD exports. Verify repeated runs are idempotent.

No original XLSM files were changed by this audit. All improvement statements are recommendations or descriptions of the new engine; no Excel runtime speedup or full workbook compatibility is claimed here.
