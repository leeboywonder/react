# ONGEN Engineering Suite — audit, changes and validation

Version 0.1.0 • Engineering preview • 21 October 2026

## Executive finding

The supplied PD master has identifiable code paths that can do unnecessary work, lose device rows, or report a transfer as completed after an inner failure. The supporting workbooks also have incompatible interfaces and gaps in BOM quantity/identity handling. These are concrete findings from extracted source and stored workbook data. No Excel freeze was reproduced or timed on this Linux machine, and no claim is made that every Excel hang has been eliminated.

Delivered work consists of a runnable combined local application, browser interface, Windows desktop host and build scripts, four proposed importable VBA module replacements, original-file provenance, detailed audits, regression tests, and engineering exchange files. Original XLSM/CSV bytes are unchanged. The native Windows application is supplied as source and launch/build scripts; a Windows EXE has not been built or executed here.

This is a working engineering workspace and a staged migration foundation. It is not a validated replacement for every Power Calculation, EtherCAT allocation, EAS, purchasing, or CAD-generation macro. Production electrical design approval and native Excel acceptance are outstanding.

## 1. Inputs, coverage and limits

Seven files were supplied. Six were accessible: five XLSM workbooks and one CSV. Power Calculation V4.6 could not be downloaded because it exceeds the environment's 32 MiB transfer limit. Its formulas, VBA, cached outputs and compatibility therefore remain uninspected. The new local importer itself accepts files up to 256 MiB, with a 750 MiB uncompressed workbook limit; those limits do not remove the attachment transfer restriction encountered here.

| Accessible input | Worksheets | Imported data rows across sheets | Notes |
|---|---:|---:|---|
| PD Definition Master Workflow V5.1.6.5 | 11 | 12,174 | PD5 has 4,559 records; CAD export 4,410 records; BOQ units row excluded |
| Field Devices Specification v2.1.7.1 | 12 | 4,683 | 5,689 formula cells; one cached error |
| IO Generator B05 | 4 | 16 | IO_DEVICE_LIST has headers but no input device records |
| EAS Master Function Library | 16 | 1,371 | Normalized functions, components, variants, BOM, parts |
| EAS V2.5.3 | 44 | 1,152 | PD6_IMPORT and IO_DEVICE_LIST are header-only interfaces |
| Function code lookup CSV | 1 logical table | 30 | Missing active library code CF-STD-002 |
| Total accessible | 87 worksheets + CSV table | 19,426 | Imported rows are populated rows after detected headers, not worksheet dimensions |

The master source inventory contains 42 modules/classes/forms, 17,031 extracted lines and 662 procedure declarations. All extracted components were inventoried and assessed statically. Support inventories and substantive-code reviews are included in the analysis folder. The EAS project includes 192 extracted components; empty sheet classes are distinguished from substantive modules. Static coverage does not establish that every branch, form, event or external workbook call has executed correctly.

The master has zero stored worksheet formulas. Formula recalculation is therefore not an evidenced primary freeze cause within its own sheets. Its VBA can still call global calculation and external workbooks, so this does not rule out calculation delays elsewhere. Existing mod26_Performance already includes guarded execution, pulses and cancellation support; several Phase 4/5 procedures already use arrays and dictionaries. These existing improvements are retained and credited.

No Microsoft Excel/VBA runtime was available. LibreOffice is not a valid substitute for proving this VBA workflow. VBA compilation, compiled P-code behavior, event timing, file-dialog interaction, OneDrive/network-file delays, external CAD integration and Windows desktop behavior were not validated here. Instructions embedded in sheets were treated as data and design context, not authorization to execute macros.

## 2. Phase-by-phase assessment

| Phase | Actual workflow | Finding and resulting action |
|---|---|---|
| Startup / navigation | Dashboard, workbook-open library check, refresh, worksheet launcher | Synchronous folder/workbook scanning can delay startup; global RefreshAll/CalculateFull suppresses errors. Existing guard is useful but cannot detect every swallowed inner failure. New app imports explicitly and runs long operations as background jobs. |
| 1A–1D | CAD import, BOQ import, LPN QA, PD5 build | Preserve literal HANDLE/sequence/LPN identifiers; map by header, not position. BOQ row 2 is units. New app imports and audits existing PD5/CAD/BOQ; it does not reproduce every original CAD-to-PD5 generation rule. Duplicate BOQ LPNs are flagged and not given an arbitrary winner. |
| 2A–2D | PSU/VFD estimate, PD4, block library, HWE_PSU | Original grouping/terminal rules remain in Excel. New transparent single/three-phase/DC load estimates are available, with explicit inputs and assumptions. They are not equivalents of the unavailable Power V4.6 calculation. |
| 3A | PD5 + BOQ + function definitions → SIS_TAG_IMPORT_PD2 | Existing per-column clearing extends to row 1,048,576. Proposed mod09 patch bounds stale-row clearing to existing used data. New engine uses indexed BOQ lookup and preserves source fields/trace. |
| 3B | PD2 + function definitions → function devices | Existing nested source-by-definition scans read many individual cells before matching and write output cell by cell. Prior output is deleted early. New engine preindexes function definitions, deduplicates repeated identical child compositions, preserves distinct components/parts, and commits generated records transactionally. A broad uncompiled VBA rewrite was intentionally not presented as a validated fix. |
| 4A | PD5/estimated equipment → Power PD5_IMPORT; external PC_Refresh_Definition_From_PD5 | Existing bulk write is already useful. New app exports a 41-column packet transcribed from the master's source. It does not run external Power macros, invent Load/PSU metadata or certify native compatibility. |
| 4B | Build local PD6 design | Original multi-source ownership/selection rules need controlled reconciliation. Canonical imported data and trace are available in the suite; complete original PD6 behavior is not claimed. |
| 4C | External PC_Finalize_PD_Return; status checks; final Power export | Cannot be accepted without Power V4.6 and desktop Excel. Existing explicit status functions are retained in source audit. New app does not emulate successful finalization. |
| 4D | Power return import, then metadata backfill | Inner mod14 procedure can display a failure then return normally, allowing wrapper backfill. Proposed mod14 patch rethrows after cleanup so wrapper stops. New return handling previews permitted changes and blocks ambiguous identities. |
| 5A | Specification Devices from functions/VFD/PD6 | Confirmed row-counter defect can truncate devices when updating an existing VFD. Proposed mod20 patch separates lookup target row from output count. Another producer/consumer gap remains: normal output lacks CONTROL_FUNCTION_NUMBER required by the central Specification push. |
| 5B–5C | Field Device IO → IO Generator | Master A:K transfer matches B05's actual 11 columns; it is not expanded blindly to include HANDLE. HANDLE remains in canonical trace. Direct Field→IO exporter expects different headers and matches conveyor alone. Proposed Field exporter fixes aliases, composite identity, validation, bulk writes and cleanup. |
| 5D–5G | IO return, component/BOM backfill, block and PSU-terminal review | Function-code-only fallback can choose a different component's part. Legacy IO return append can duplicate reruns. New suite blocks ambiguous/duplicate return targets and requires explicit reviewed application. Native IO/PSU allocation is not reimplemented. |
| 6 | Rebuild PD6, power completion, frozen CSV export | Existing frozen contracts drop later BOM slots. New XLSX/extended CSV retain trace and generated data, while legacy contract exports remain explicit. Complete CAD/PD6 parity is an acceptance gate. |
| 7 | Function/PD6/IO CSV and final CAD handoff | Structural validation alone is insufficient. Need identity, schema, row/quantity conservation, ownership and downstream CAD acceptance. New app supplies review files, not an automatic engineering release. |

## 3. Priority defects and performance factors

### Critical/high findings in master

1. **Phase 5A output truncation.** `mod20_DeviceWorkflow`, existing-VFD path, original source around lines 189–194 and final-array construction around 229–237. It assigns `outRow = CLng(seen(k))`; outRow also controls total output length. Updating a VFD located before the final device can lower the count, truncate trailing rows and let later appends overwrite rows. The replacement uses `vfdTargetRow` for updates while retaining outRow as the count. Python regression models demonstrate the old loss and corrected count behavior; VBA execution is unverified.
2. **Phase 3A excessive clearing.** `mod09_GeneratePD2`, column-copy clear around line 190. Clearing each copied column from row 2 through the worksheet bottom is avoidable. The patch records the previous used last row before copying and clears only through that prior extent. It preserves stale-tail removal when output shrinks. No Excel speedup percentage is claimed.
3. **Phase 3B repeated Excel object access.** `mod10_FunctionDevices`, source loop around 147, definition loop around 171, repeated part reads around 186 and writes around 224. This is a credible responsiveness risk: source rows × definition rows × COM reads plus cell-by-cell writes. The new Python path performs in-memory indexed joins; its measured timings are reported separately from Excel.
4. **Phase 4D error propagation.** `mod11_PowerRoundTrip` around 251–252 and `mod14_ImportPD6Power` failure path around 127. Failure can be handled internally without stopping later backfill. Proposed replacement preserves direct-button error display and propagates failure to the wrapper after restoration.
5. **Specification function-code contract.** `mod20_DeviceWorkflow` output construction around 126 and `modONGEN_CentralFunctionSystem` around 262–287. The preferred Specification Devices source lacks the function-code column the consumer requires. This requires validated schema expansion/join rather than guessing a code.
6. **BOM fallback identity.** `mod15_IOReturnMerge` around 81 and 177. CF-B-010 has beacon and PBL components; a function-only dictionary cannot reliably identify the correct component part. New canonical records retain function child identity and source rows; no automatic part substitution is made.

### Supporting workbook gaps

- **Confirmed Field→B05 header mismatch:** `EXPORT_TO_IOGEN.Export_IO_Device_List` searches Conv.ID/Items Type in the destination, while actual B05 headers are DEVICE NAME/ITEM TYPE. The old exporter can exit without transfer. Its conveyor-only match also risks collapsing different item types. The proposed replacement resolves aliases, validates both identities and uses a composite dictionary.
- **Legacy full-column import:** `Import_EE_data.Data_Import_EE_BOM` refers to absent Designed Export, copies A:AI as whole columns and can leave ScreenUpdating off. Present START-HERE controls use other wrappers; this is not evidence that the current main button invokes that legacy path.
- **BOM quantity/slot loss:** Field VARIANT LIST has 12 part/manufacturer pairs and Part Qty1–12; EM Designed function has nine pairs without per-part quantities. Active mapping still calls the legacy nine-slot routine; downstream rearrangement applies row QTY to each part without the stored part multiplier. The new normalized assembly preview uses instance × component × part quantities, with no fixed slot count and explicit component selection.
- **Field formula issues:** START-HERE!B2 has cached #VALUE!. D20 uses an unquoted Mason identifier absent from defined names. These require formula-owner confirmation and Excel recalculation; they were not silently edited.
- **Partial BOM generation:** ARRANGE_EE_DATA clears managed destination columns before later prerequisite validation; its shared cleanup/failure handling can obscure failure. Stage/validate before commit is recommended.
- **Purchasing identity:** part-number-only pricing/vendor aggregation can mix manufacturers. Currency, cost date and vendor ownership must accompany manufacturer+part identity. The suite retains these fields and does not total unlike currencies.
- **SAP export range:** clearing Q:XFD on a newly generated sheet is unnecessary. The conceptual range is huge, but sparse Excel optimization means its duration cannot be inferred from cell positions alone.
- **IO return reruns:** legacy export appends without deduplication. An idempotent upsert policy is required; the new reviewed return plan blocks duplicate targets.
- **IO export scope:** a blacklist excludes obsolete EtherCAT_IO_Address while generated output is Network_IO_Address; DATA/Revisions may be exported. Use a positive panel-output manifest rather than a permissive blacklist.
- **IO counts:** CLng(Val()) accepts/coerces malformed values without a proper nonnegative/integer contract. New exports reject invalid and out-of-range counts.
- **EAS controls:** three stored buttons reference unresolved macro procedures; duplicate public names are a potential compile/call ambiguity until verified in VBE. Whole-sheet clearing, repeated scans, quadratic sorts and synchronous operations are performance risks. Existing array/caching work is acknowledged. See the EAS audit for exact procedure/line evidence.
- **Library identity:** EUCHNER / 92898 appears under two PART_KEY values (rows 168 and 216). Four active variant-signature duplicate groups are documented. No duplicate primary keys or orphan part/variant/function references were found by the library audit.
- **Library approval:** 25 active migrated functions still carry review status, but legacy exports filter primarily on ACTIVE. Active is not equivalent to engineering approval. The new BOM preview displays the status and requires explicit components; it does not promote them to approved.
- **Lookup divergence:** CSV omits approved active CF-STD-002. Revision/version ownership between the CSV and central library needs definition.
- **Saved paths/links:** master's UI_Config points to a user-specific Power V4.3 path, whereas the missing upload is V4.6. It also retains external relationships to older EAS V25.8.3, while accessible EAS is V2.5.3. Names alone do not prove compatible schemas.

## 4. Changes delivered

### Proposed Excel-source patches

| Replacement file | Change | Validation performed | Still required |
|---|---|---|---|
| vba/patched/mod09_GeneratePD2.bas | Bounds stale-row clears to previous used extent | Algorithm/source checks | Excel compile; shrinking/empty destination and cancellation cases |
| vba/patched/mod20_DeviceWorkflow.bas | Separate VFD update target from total output count | Regression model/source checks | Excel compile; first/middle/last VFD + append acceptance |
| vba/patched/mod14_ImportPD6Power.bas | Propagate import failure after restoring state | Five static/source checks | Excel compile; controlled failure prevents wrapper backfill |
| vba/patched/field/EXPORT_TO_IOGEN.bas | Real header aliases, composite identity, count checks, bounded bulk writes, state restoration, best-effort rollback | Twelve Python transfer-model/source tests | Excel compile; overwrite/skip/cancel/read-only/protected/save-failure tests |

These files are not injected into an XLSM. Import instructions and diffs accompany them. The user must replace the named module in a copy, not add duplicate procedures into the same project. The report does not call an uncompiled VBA patch a verified Excel fix.

### Combined application

One FastAPI/Python/SQLite engine serves both the local browser UI and the pywebview Windows desktop host. This keeps engineering behavior and project data shared rather than maintaining two separate applications.

Implemented capabilities:

- Immutable originals retained by SHA-256; duplicate file import is idempotent.
- CSV/XLSX/XLSM values imported without opening Excel, executing macros or updating external links.
- Serialized-cell streaming avoids walking entire formatted dimensions. Header-only sheets do not become invented datasets.
- All sheets browseable with search, pagination, original row numbers and source-file identity. Formula values are saved caches only; missing/stale-cache limitations are surfaced.
- Transactional background import/build/validation with job status; cancellation requests roll back active database mutations at checkpoints.
- Phase 3 BOQ enrichment by indexed normalized LPN, with duplicate-LPN refusal, then explicit/inferred-unique function mapping and child-device expansion. This is an engineering-reviewed new implementation, not an assertion of complete original macro parity.
- Device review permits explicit IO names/exclusions with required review notes and history. Source rows remain unchanged. Rebuilding Phase 3 replaces derived outputs and resets those reviews, so export/backup reviewed work first.
- Normalized central-library assembly preview, explicit component selection, quantity conservation, uncapped child part rows and status/cost provenance. Component alternatives are not assumed to occur together.
- Transparent electrical load estimates with unit/phase/efficiency/PF/quantity/diversity/reserve inputs and optional arithmetic PSU count. Finite/range checks reject invalid inputs and derived overflow.
- Power exchange packet, full device/issue/review CSVs, JSON audit backup and literal-string-safe XLSX. CSV exports protect spreadsheet formula-like strings. XLSX generation uses text cells for string input.
- Reviewed return preview: HANDLE first, otherwise unique sequence+type, whitelist-only assignment fields, duplicate-target blocking, unchanged-source trace and stale-plan fingerprint check. Explicit user confirmation is required before applying a preview.
- Local-loopback service, same-origin writes, source/workbook history, and no external CDN dependencies for the UI.

Not implemented/validated: native Power macro finalization/grouping, electrical protection/cable sizing, redundant PSU strategy, actual terminal/cable routing, full original direct-equipment/IO allocation, automated purchasing release, CAD block generation, every EAS macro, multiuser authentication/concurrency, Windows installer signing/update delivery, and byte-for-byte parity for all legacy outputs. These omissions are explicit release gates, not implied completed features.

## 5. Import/export contracts and ownership

**Phase 3:** `SIS_TAG_IMPORT_PD2` is an enriched review dataset. Raw identifiers and existing nonblank values are preserved. Missing BOQ values are filled only when a unique LPN matches. Identical repeated function child compositions are deduplicated by tag/block/part identity; distinct part compositions remain separate. Source row and function definition row are carried in output. Parent records without a code remain visible in phase3_review.csv; many are direct/mechanical devices and cannot be declared erroneous solely for lacking a function code.

**Phase 4:** `PD5_IMPORT` uses the master's 41 field names/order, beginning SIS_sequence, AREA_Number, SwitchGroup, TYPE and ending PSU_TERMINAL_ASSIGNMENTS, PSU_ESTIMATED_LENGTH_MM, ZONE_LENGTH_ZL. Load, Control_ID and PSU engineering fields are not fabricated where absent. Blank-sequence records are excluded and counted. The new packet is not a remotely executed Power workbook workflow and does not append generated PSU groups absent from inputs.

**Phase 5/B05 exact order:** DEVICE NAME, ITEM TYPE, INPUT, OUTPUT, S_IN, S_OUT, PNL, PWG, LOCATION, Standard Block, Safety Block. Location aliases are explicit: PANEL→PNL, SWITCHGROUP→PWG, AREA_NUMBER→LOCATION. Counts must be blank/zero or nonnegative integral values within the legacy signed-long range. Unknown location/block assignments remain blank for engineering review. HANDLE is kept in extended trace, not silently inserted into the frozen eleven-column contract.

**Returns:** only NETWORK_IP, FEEDING_PANEL, LOAD, CURRENT_LOAD, PSU_TERMINAL_ASSIGNMENTS, IO_BLOCK, IO_PORT, PORT and TERMINAL are allowed. Function codes, parts, geometry and CAD identities cannot be overwritten by the generic return importer. This whitelist is a limited review contract; new native Power/EAS return fields need explicit ownership and validation before inclusion.

**BOM:** function code → explicitly selected component code → variant → child BOM part key. Output retains manufacturer, part, instance/component/part quantities, source rows, unit cost, currency, cost date and function review status. No fixed nine/five-slot truncation, automatic substitution, currency conversion or approval is performed.

**Project persistence:** SQLite and original files under the workspace data directory are the durable working project. project.json is an audit backup, not a full restorable package containing Office VBA; back up the whole data folder for restoration. New imports invalidate derived outputs so stale calculations are not presented as current.

## 6. Verified results and interpretation

See validation_results.json and test logs for exact results from the current run. Measured Python timings are machine-specific and are not Excel benchmarks, comparative speedups or Windows performance claims.

The real-data integration run imported all six accessible files, checked unchanged source hashes, rebuilt 4,559 Phase 3 parents and 1,564 function-derived device rows, produced a 4,210-row/41-column power packet and an XLSX review package. 3,777 parent records have no function assignment or require review; these are not silently dropped or labelled 3,777 confirmed defects.

The current validation register contains 1,363 entries: two errors, 1,355 warnings and six informational cache notices. These are checks, not 1,363 proven engineering faults. Main warning groups include 859 shared-sequence groups, 349 missing-sequence rows and 115 duplicated BOQ LPN groups. Shared sequences may be intentional across device types; composite identity review is necessary. The two errors are the saved Field #VALUE! and duplicate normalized part identity.

The real IO packet is deliberately blocked at ambiguous identity `6425-01B-B / B`. Therefore the supplied engineering.xlsx omits IO_DEVICE_LIST and records the reason in READ_ME. No successful complete IO export is claimed. The UI provides device naming/exclusion review; all necessary conflicts must be resolved before a complete function-derived packet can export. Direct PD5 equipment outside function expansion is not automatically included in that packet.

Python validation includes 27 engine/API/library regression/integration tests and 12 Field transfer-model tests, all passing. Separately, seven master patch model/source checks and five mod14 source checks pass. These are 51 Python/model/static checks, zero native Excel/VBA execution tests. Browser navigation and action tests are recorded separately in browser_validation.json. Windows desktop source compiles as Python; native Windows GUI, packaging and WebView2 remain untested.


### Measured new-engine timings

| Operation | Seconds in this run |
|---|---:|
| Import ONGEN Field Devices Specification -v2.1.7.1.xlsm | 0.3217 |
| Import ONGEN_FUNCTION_CODE_LOOKUP.csv | 0.0021 |
| Import ONGEN IO GENERATOR - B05.xlsm | 0.0211 |
| Import ONGEN_EAS_MASTER_FUNCTION_LIBRARY.xlsm | 0.1032 |
| Import ONGEN PD_DEFINITION_MASTER_WORKFLOW_V5.1.6.5.xlsm | 1.3565 |
| Import ONGEN EAS - V2.5.3.xlsm | 0.3676 |
| Validate project | 0.1920 |
| Build Phase 3 | 3.9555 |
| Generate review XLSX | 6.1893 |

These timings are one measured run on this Linux host. They are not an Excel comparison or a performance guarantee.

## 7. Operating both versions

Unzip the suite into a writable local folder. Install Python 3.11+ (Python 3.12 is the tested family). The included Windows PowerShell launcher creates a virtual environment and installs requirements. A normal Internet connection is needed for first dependency installation; no engineering project data is sent to a remote service by the application.

Browser on Windows: `powershell -NoProfile -File .\windows\Start-ONGEN.ps1`. It starts the local engine and opens the browser. Desktop: append `-Desktop`. Both launchers use `%LOCALAPPDATA%\ONGEN\data` so the two versions share one project. Close the first application before opening the other; concurrent independent engine processes are not a supported multiuser workflow. Microsoft Edge WebView2 and the pywebview Windows runtime dependencies may be needed.

Portable browser: create a virtual environment, install requirements.txt, then `python run.py --browser`. Its default data directory is ./data. Set ONGEN_DATA_DIR to deliberately share a different local workspace. A packaged sample_project seeds a new workspace once; an existing database is not overwritten.

Build a Windows executable with windows/Build-Desktop.ps1 on Windows. It produces a PyInstaller folder distribution, not a signed installer. Distribute the entire dist/ONGEN folder. Windows packaging has not been performed here; verify it on the intended Windows/Excel environment before release.

Recommended sequence: inspect sources → run validation → build Phase 3 → review unassigned parents/components and IO identities → preview selected library BOMs → calculate explicitly supplied power estimates → export review packets → import a return workbook → rebuild invalidated derived output if needed → preview return differences → apply only reviewed fields → export/backup the data folder. Export originals and generated data are separate artifacts.

## 8. Release gates and next engineering work

1. Supply Power V4.6 in a transferable form: reduced XLSM or exported VBA plus all interface/calculation/lookup sheets, formulas and representative saved results. Audit actual macros, calculation ownership and PC_LastFinalization* status; compare Phase 4A/C/D on representative cases.
2. In desktop Excel copies, compile all projects, resolve missing references/ambiguous names and missing button targets, import one proposed patch at a time and run its acceptance cases. Preserve originals and old outputs for comparison.
3. Reproduce freezes with phase-level elapsed time, row counts, workbook location and Excel calculation/event state. Separate parsing, COM access, formatting, calculation, network/open/save and external macro time. A spinner or DoEvents alone is not an optimization.
4. Resolve 5A function-code contract, component-specific BOM fallback, Field quantity propagation, library review approvals and lookup divergence. Compare BOM total quantities, part/manufacturer identity and currency/date ownership before procurement output.
5. Resolve project-specific duplicate LPN/sequence/device identities. Do not automatically collapse mechanically distinct records or infer a missing part/terminal from a similar number.
6. Test native IO panel capacity, port allocation, safety separation, direct equipment and return idempotence against the original generator. Validate every downstream CAD/PNL export schema with a controlled round trip.
7. Run Windows desktop browser/download/start/close/reopen tests, build the executable, test WebView2 prerequisites and user-folder persistence, then choose signing/installer/update requirements.
8. Only after these gates pass, approve a versioned engineering release. Retain measured evidence and expected outputs for future regression testing.

## 9. Detailed evidence supplied

- master_audit.md/json: master phase map, findings and per-module coverage.
- power_paths_audit.md: detailed Power/IO control flow and identity risks.
- support_audit.md/json: Field and IO findings with exact module/procedure/line evidence.
- eas_code_audit.md/json and library_code_audit.md/json: substantive supporting-code audits.
- inventory.md/json, schema.json, support_structure.json: all accessible sheet metrics and schemas.
- analysis/vba/: extracted original source, used for line evidence and diffs; no macro execution.
- vba/patched/: proposed replacements, diffs and native acceptance instructions.
- validation_results.json, python_tests.log, vba_*results.txt, browser_validation.json: actual execution/static evidence.
- original_hashes.csv: original filenames, byte sizes and SHA-256 provenance.

No original workbook was saved through openpyxl or another Office writer. New XLSX/CSV/JSON files are explicitly generated review outputs. Saved formula caches were not recalculated. Further Power/Windows/Excel checks remain open, rather than being represented as successful.
