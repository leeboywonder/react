# ONGEN supporting workbook audit

All accessible support workbook OOXML sheets and all extracted source module inventory; selected substantive procedures inspected; no Excel/VBA execution. Power workbook inaccessible due 32 MiB transfer limit.

No originals were changed. Static findings identify paths and stored-data problems; no Excel freeze was reproduced or timed.

## Coverage and stored workbook metrics

| Workbook | Sheets | Formula cells | Serialized cells | Styled empty cells | Cached errors |
|---|---:|---:|---:|---:|---:|
| ONGEN_EAS_MASTER_FUNCTION_LIBRARY.xlsm | 16 | 0 | 34048 | 21137 | 0 |
| ONGEN Field Devices Specification -v2.1.7.1.xlsm | 12 | 5689 | 73640 | 1926 | 1 |
| ONGEN IO GENERATOR - B05.xlsm | 4 | 1 | 7342 | 7244 | 0 |
| ONGEN EAS - V2.5.3.xlsm | 44 | 593 | 131268 | 125801 | 0 |

Metrics count OOXML `<c>` and `<f>` nodes including shared-formula followers. Styled empty means a serialized cell with neither value/formula/inline-string; it is not a wall-clock performance measurement. No external-link parts, volatile-function formula texts, or whole-column formula texts were detected in these four support files. Shared formulas retain base formula text at the anchor; count checks inspect stored text rather than recalculating.

## Findings

### SUP-F01 — Specification exporter cannot map supplied IO workbook headers

Severity: **high**. Evidence classification: confirmed static incompatibility.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `EXPORT_TO_IOGEN.bas`; `Export_IO_Device_List`; source lines 52, 53, 75, 83.

Exporter searches destination Conv.ID and Items Type; actual IO_DEVICE_LIST headers are DEVICE NAME and ITEM TYPE. Missing-header branch exits before data transfer.

Impact: Direct Specification→IO export is blocked with the supplied files.

Recommendation: Use explicit aliases Conv.ID→DEVICE NAME and Items Type→ITEM TYPE, validate all headers before opening output transaction, retain device instance key and engineering location fields.

### SUP-F02 — Legacy import addresses missing sheet and copies 35 complete columns

Severity: **high**. Evidence classification: confirmed legacy entry-point defect.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `Import_EE_data.bas`; `Data_Import_EE_BOM`; source lines 10, 11, 60, 69, 74, 81.

Destination Designed Export is absent from supplied workbook; source Definition lookup not checked; full A:AI copy/paste encompasses 36,700,160 cell positions. ScreenUpdating is disabled at line60 with no restore. Current START-HERE buttons use other wrappers, so this is not proof the present normal button freezes.

Impact: Manual invocation can error and leave Excel display state altered; whole-column clipboard work is a strong avoidable performance risk.

Recommendation: Retire legacy command or replace with bounded Value2 transfer into the intended schema and a single guaranteed cleanup path.

### SUP-F03 — Per-part quantities and slots beyond nine are not carried through the active legacy mapping

Severity: **high**. Evidence classification: confirmed static data-loss path; runtime not executed.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `VARIANT_BOM.bas; modONGEN_CentralFunctionSystem.bas; ARRANGE_EE_DATA.bas`; `MapVariantData / ONGEN_SyncSpecificationVariants / RearrangeDesignedExport_Fast`; source lines 39, 50, 117, 129, 505, 507, 287, 299.

VARIANT LIST contains 12 manufacturer/part pairs and Part Qty1–12. EM Designed function has nine pairs and no per-part quantities. MapVariantData hardcodes pairs1–9. Central sync stores BOM qty×component qty in Part Qty fields; rearrange writes row QTY unchanged to each BOM item. Active wrapper ONGEN_SPEC_RunPartVariant_Optimized calls MapVariantData.

Impact: Functions with nonunit part quantities or >9 parts can yield incomplete/understated purchasing BOMs. No specific live project loss has been executed in Excel.

Recommendation: Normalize BOM rows and multiply instance quantity×component quantity×part quantity. If remaining Excel-first, dynamically grow all pair/qty fields and validate quantity conservation before commit.

### SUP-F04 — Export matching key is conveyor alone

Severity: **medium**. Evidence classification: confirmed code behavior / collision risk.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `EXPORT_TO_IOGEN.bas`; `Export_IO_Device_List`; source lines 115, 137.

For each row, exporter Find searches entire destination key column using Conv.ID only; Items Type/function is not included in identity.

Impact: Multiple device/function records on one conveyor can overwrite each other in Yes mode or be skipped in No mode.

Recommendation: Use stable device-instance IDs or an explicitly validated composite key; reject ambiguous source duplicates before destination writes.

### SUP-F05 — Variant mapping prompts inside row-by-column loop

Severity: **medium**. Evidence classification: confirmed code behavior / responsiveness risk.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `VARIANT_BOM.bas`; `MapVariantData`; source lines 88, 138.

A full-column variant Find is performed per row, and each populated destination field can show a separate overwrite dialog. Cancel within header loop exits that loop only (lines125–126), so later source rows can continue.

Impact: Large jobs require repeated UI interaction; cancellation can mean partial application rather than an atomic cancel.

Recommendation: Build one variant dictionary, choose overwrite policy once, stage output arrays, expose cancellation between chunks, and commit only validated results.

### SUP-F06 — Unresolved formula identifier and a cached error

Severity: **medium**. Evidence classification: confirmed stored workbook issue.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `worksheet START-HERE`; `D20 formula and B2 saved cache`; source lines worksheet references above.

D20 formula contains IF(C20=Mason,...) without quotes; no defined name Mason exists. B2 is a stored #VALUE! error cell. D20 only fails when its evaluation reaches the unresolved identifier; this audit did not recalculate it.

Impact: A purchase-group branch can fail to resolve; the existing B2 error needs owner review.

Recommendation: Use intended quoted text "Mason" after confirming the engineering mapping, then recalculate in Excel and investigate B2 source.

### SUP-F07 — Destination is cleared before pricing/vendor prerequisite validation finishes

Severity: **medium**. Evidence classification: confirmed code behavior / transactional risk.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `ARRANGE_EE_DATA.bas`; `RearrangeDesignedExport_Fast`; source lines 180, 200, 244, 267, 342, 347.

Managed destination columns are cleared, then pricing/vendor row and header checks may GoTo SafeExit. SafeExit restores app state but does not report unhandled runtime errors (same handler used for normal cleanup).

Impact: Invalid lookup inputs can remove prior generated BOM and provide weak failure diagnostics.

Recommendation: Validate sources and build staged arrays first; snapshot destination or write temporary output, commit after validation, log precise failure without swallowing errors.

### SUP-F08 — Purchasing lookups aggregate on part number without manufacturer

Severity: **medium**. Evidence classification: confirmed code behavior / identity risk.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `ARRANGE_EE_DATA.bas; CREATE_SAP_IMPORT.bas`; `RearrangeDesignedExport_Fast / CreateVendorSheets_FromBOM_Full`; source lines 230, 240, 295, 305, 156, 164.

Pricing dictionary is indexed only by normalized part number; vendor part aggregation pKey=partNum. Master library identity is manufacturer+part.

Impact: Two manufacturers reusing one part identifier can take the first price or be combined. This is a path-level risk, not a verified collision in current project output.

Recommendation: Use manufacturer+part keys consistently and retain currency/cost date/vendor identity in price selection.

### SUP-F09 — SAP export clears all unused columns across complete worksheet

Severity: **medium**. Evidence classification: confirmed code behavior / performance risk.

File: `ONGEN Field Devices Specification -v2.1.7.1.xlsm`; `EXPORT_SAP_ORDER_LIST.bas`; `Export_SAP_POR_Order_List_A_To_P_ONLY`; source lines 78, 98.

After copying bounded A:P into a new sheet, Range("Q:XFD").Clear operates over 17,163,157,504 cell positions conceptually. Excel optimizes sparse operations, so actual time cannot be inferred from range size.

Impact: Unnecessary huge-range operation can add work without changing intended output; application screen/events states are forced on rather than restored.

Recommendation: Omit clear on a newly created sheet; restrict visible/print columns without touching empty cells; restore previous state, not constants.

### SUP-I01 — IO return export appends on every rerun

Severity: **high**. Evidence classification: confirmed append behavior.

File: `ONGEN IO GENERATOR - B05.xlsm`; `export_io_to_pd.bas`; `Export_IO_Block_Summary_To_IO_DEVICE_EM`; source lines 62, 85.

Destination SEQUENCE/TYPE rows begin after current last row and every source block is appended; no key lookup or dedupe is implemented.

Impact: Repeated return exports duplicate assignments and can create ambiguous PD merges.

Recommendation: Use idempotent upsert keyed by physical block identity with source run/version; detect and report conflicts instead of blind append.

### SUP-I02 — Panel export uses outdated exclusion list

Severity: **medium**. Evidence classification: confirmed export scope mismatch.

File: `ONGEN IO GENERATOR - B05.xlsm`; `export_panel_for_generation.bas; OPTION_IO_V6_RELEASED.bas`; `Export_All_Sheets_Except_Excluded / Run_IO_Generator_V6`; source lines 19, 24, 38, 67, 371, 372.

Generator creates Network_IO_Address, while exporter excludes only EtherCAT_IO_Address. DATA and Revisions are also not excluded.

Impact: Nonpanel reference/report sheets can be copied into the destination workbook, and existing same-name sheets can be deleted on Yes.

Recommendation: Export an explicit generated-panel manifest; separate topology reports from reference sheets and preserve untouched destination sheets.

### SUP-I03 — IO counts parsed with Val/CLng without explicit validation

Severity: **medium**. Evidence classification: confirmed permissive parsing / input validation gap.

File: `ONGEN IO GENERATOR - B05.xlsm`; `OPTION_IO_V6_RELEASED.bas`; `Run_IO_Generator_V6`; source lines 271, 276.

Val accepts numeric prefixes, CLng rounds fractions, and negative values are not rejected before totals and allocation branches.

Impact: Malformed or negative signal counts can be silently altered and produce misleading allocations.

Recommendation: Require finite nonnegative integer values for all four counts and block invalid rows before any generation.

### SUP-I04 — Generator can complete despite row-level errors or unsupported safety demand

Severity: **medium**. Evidence classification: confirmed code behavior / final-status risk.

File: `ONGEN IO GENERATOR - B05.xlsm`; `OPTION_IO_V6_RELEASED.bas`; `GenerateStandardIORows / Run_IO_Generator_V6`; source lines 517, 521, 344, 347, 376, 381.

Oversized standard demand yields an ERROR output row and returns; no-safety profile adds NOTE for requested safety IO; outer runner still displays IO generation completed.

Impact: Completion message alone does not prove allocation completeness.

Recommendation: Track requested, allocated, unallocated, error, and unsupported counts; fail release gate unless all required signals are allocated and reviewed.

### SUP-I05 — IO generator restores calculation but forces events/display on

Severity: **low**. Evidence classification: confirmed app-state behavior.

File: `ONGEN IO GENERATOR - B05.xlsm`; `OPTION_IO_V6_RELEASED.bas`; `Run_IO_Generator_V6`; source lines 120, 129, 383, 389.

Captures oldCalc only; cleanup sets ScreenUpdating=True and EnableEvents=True. Existing array input and bulk row-output writes are useful optimizations already present.

Impact: Nested calls can enable events/display before the caller is ready.

Recommendation: Capture and restore all changed application properties at the outermost scoped operation.

## Existing improvements to retain

- Field uses bounded dynamic named ranges and ~250-row formula headroom in current snapshot; no stored full-column or volatile formula texts detected in support workbooks.
- Field rearrange uses input arrays, lookup dictionaries, and column bulk output.
- Field full-repair module already wraps normal buttons and dynamically grows formula capacity.
- IO generator reads input arrays and writes per-device output buffers rather than every signal cell individually.
- EAS already has PD6 header/rule caches and 24V checksum/session caches; these should be retained, not rewritten blindly.

## Interface contracts

### PD→Specification design detail

```json
{
  "name": "PD\u2192Specification design detail",
  "source_sheets": [
    "Specification Devices",
    "FUNCTION DEVICE pd2"
  ],
  "destination_sheet": "EM Designed function",
  "identity": "No enforced stable ID in legacy path; cID aliases DEVICE NAME/SIS_SEQUENCE/SEQUENCE/SIS_ELEMENT_NUMBER/LPN",
  "mapped_fields": [
    "CONTROL_FUNCTION_NUMBER/FUNCTION_CODE/CODE VARIANT/VARIANT\u2192VARIANT",
    "CONTROL_FUNCTION_TAG/TYPE/ITEMS TYPE/ITEM TYPE\u2192Items Type",
    "DEVICE NAME/SIS_SEQUENCE/SEQUENCE/SIS_ELEMENT_NUMBER/LPN\u2192Conv.ID",
    "QTY/QUANTITY\u2192QTY",
    "INPUT",
    "OUTPUT",
    "S_IN",
    "S_OUT",
    "Manufacturer n",
    "Part Number n"
  ],
  "notes": "Code is present in both central-function modules, but Specification copy disallows running PD command outside PD workbook. Destination existing header writes mean missing fields may be skipped. Source function code is required."
}
```

### Specification→IO generator

```json
{
  "name": "Specification\u2192IO generator",
  "source_sheet": "EM Designed function",
  "source_headers": [
    "Conv.ID",
    "Items Type",
    "INPUT",
    "OUTPUT",
    "S_IN",
    "S_OUT"
  ],
  "destination_sheet": "IO_DEVICE_LIST",
  "actual_destination_headers": [
    "DEVICE NAME",
    "ITEM TYPE",
    "INPUT",
    "OUTPUT",
    "S_IN",
    "S_OUT",
    "PNL",
    "PWG",
    "LOCATION",
    "Standard Block",
    "Safety Block"
  ],
  "status": "blocked by header mismatch in supplied legacy exporter; PNL/PWG/LOCATION also not mapped"
}
```

### IO generator→PD

```json
{
  "name": "IO generator\u2192PD",
  "source_sheet": "IO_Block_Summary",
  "required_source_header": "BLOCK ID",
  "destination_sheet": "IO DEVICE EM",
  "destination_headers": [
    "SEQUENCE",
    "TYPE"
  ],
  "rule": "Split BLOCK ID at last hyphen; left\u2192SEQUENCE, right\u2192TYPE; append only; summary source is generated, currently absent in supplied input workbook"
}
```

### Master library normalized entities

```json
{
  "name": "Master library normalized entities",
  "sheets": [
    "FUNCTION_MASTER",
    "FUNCTION_COMPONENTS",
    "VARIANT_MASTER",
    "VARIANT_BOM",
    "PART_MASTER",
    "COST_HISTORY"
  ],
  "key_chain": "FUNCTION_CODE\u2192FUNCTION_COMPONENTS.VARIANT_CODE\u2192VARIANT_BOM.PART_KEY\u2192PART_MASTER.PART_KEY",
  "part_identity": "normalized manufacturer + normalized part number",
  "function_status": "ACTIVE and STATUS are distinct; 25 migration functions require review before production"
}
```

## Detailed EAS and Function Library findings

See `eas_code_audit.md` (192 components; 9 findings) and `library_code_audit.md` (18 components; 13 findings). Their structured audits are embedded under supplementary_audits in support_audit.json. These include the 29-column PD6 contract, broken EAS button references, duplicate library identities, review status gates, and source-line evidence.
