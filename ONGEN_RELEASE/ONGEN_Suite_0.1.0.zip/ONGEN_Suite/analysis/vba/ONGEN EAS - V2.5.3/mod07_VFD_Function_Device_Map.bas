Attribute VB_Name = "mod07_VFD_Function_Device_Map"
Option Explicit

'===============================================================================
' ONGEN EAS - VFD FUNCTION ASSIGNMENT + DEVICE MAPPING
'
' Author : Lee Pierre
' Title  : Principal Electrical Engineer
'
' PURPOSE
' -------
' Create one user-facing worksheet containing every active VFD so the operator
' can assign a Function Variant to the physical drive.
'
' WORKSHEETS
' ----------
' VFD_FUNCTION_ASSIGNMENT
'     One row per VFD.
'     User edits FUNCTION_VARIANT and NOTES. No LEFT/RIGHT assignment exists.
'
' VFD_DWG_FUNCTION_DEVICE_MAP
'     One row per Function Variant + DEVICE_TYPE rule.
'
' VFD_DWG_DEVICE_LIBRARY
'     Defines the reusable AutoCAD device/block definition.
'
' VFD_DWG_DEVICE_PLACEMENT
'     Manual exception layer.
'
' VFD_DWG_QUEUE
'     Generated drawing queue. Receives FUNCTION_VARIANT and
'     RIGHT_FUNCTION_VARIANT from VFD_FUNCTION_ASSIGNMENT.
'
' SOURCE OF TRUTH
' ---------------
' Do NOT manually type Function Variant into VFD_DWG_QUEUE.
' Do NOT depend on a generated queue row as the permanent assignment source.
'
' The permanent project assignment source is:
'     VFD_FUNCTION_ASSIGNMENT
'
' REFRESH BEHAVIOR
' ----------------
' VFD_FUNCTION_REFRESH_ASSIGNMENT rebuilds the list from VFD_480V_Generator,
' while preserving existing Function Variant and Notes by SIS_SEQUENCE first.
' SIS_ELEMENT_NUMBER is retained only as a fallback identity.
'
' LEFT / RIGHT
' ------------
' The user does NOT assign LEFT or RIGHT.
' SIS_SEQUENCE identifies the physical VFD.
' The queue determines whether that VFD is LEFT or RIGHT on a particular sheet.
' AutoCAD placement then uses that queue slot's coordinates automatically.
'
' PD6_IMPORT is used to enrich Control ID and panel metadata.
'===============================================================================

Private Const ASSIGN_SHEET As String = "VFD_FUNCTION_ASSIGNMENT"
Private Const MAP_SHEET As String = "VFD_DWG_FUNCTION_DEVICE_MAP"
Private Const DEVICE_LIBRARY_SHEET As String = "VFD_DWG_DEVICE_LIBRARY"
Private Const PLACEMENT_SHEET As String = "VFD_DWG_DEVICE_PLACEMENT"
Private Const QUEUE_SHEET As String = "VFD_DWG_QUEUE"
Private Const VFD_SOURCE_SHEET As String = "VFD_480V_Generator"
Private Const PD6_SHEET As String = "PD6_IMPORT"

Private Const BTN_REFRESH As String = "ONGEN_VFD_FUNC_BTN_REFRESH"
Private Const BTN_SYNC As String = "ONGEN_VFD_FUNC_BTN_SYNC"
Private Const BTN_MAP As String = "ONGEN_VFD_FUNC_BTN_MAP"
Private Const BTN_DIAG As String = "ONGEN_VFD_FUNC_BTN_DIAG"


'===============================================================================
' PUBLIC ENTRY POINTS
'===============================================================================

Public Sub VFD_FUNCTION_INSTALL()
    On Error GoTo Failed

    Dim oldScreen As Boolean
    Dim oldEvents As Boolean

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents

    Application.ScreenUpdating = False
    Application.EnableEvents = False

    VFD_FUNC_EnsureMapSheet
    VFD_FUNC_EnsureAssignmentSheet
    VFD_FUNC_EnsurePlacementOverrideColumn
    VFD_FUNC_EnsureQueueColumns

    Call VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT
    Call VFD_FUNCTION_SYNC_QUEUE_SILENT

CleanExit:
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    MsgBox _
        "VFD Function Assignment is installed." & vbCrLf & vbCrLf & _
        "Assign each drive on:" & vbCrLf & _
        ASSIGN_SHEET, _
        vbInformation, _
        "ONGEN VFD Function Assignment"
    Exit Sub

Failed:
    Dim n As Long
    Dim d As String

    n = Err.Number
    d = Err.description

    On Error Resume Next
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    MsgBox _
        "VFD Function Assignment installation failed." & vbCrLf & _
        "Error " & CStr(n) & ": " & d, _
        vbCritical, _
        "ONGEN VFD Function Assignment"
End Sub


Public Sub VFD_FUNCTION_REFRESH_ASSIGNMENT()
    If VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT Then
        MsgBox _
            "VFD_FUNCTION_ASSIGNMENT was refreshed." & vbCrLf & vbCrLf & _
            "Existing Function Variant assignments were preserved by VFD SIS Sequence.", _
            vbInformation, _
            "ONGEN VFD Function Assignment"
    Else
        MsgBox _
            "VFD Function Assignment could not be refreshed.", _
            vbExclamation, _
            "ONGEN VFD Function Assignment"
    End If
End Sub


Public Function VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT() As Boolean
    On Error GoTo Failed

    Dim wsAssign As Worksheet
    Dim wsSource As Worksheet
    Dim wsPD6 As Worksheet
    Dim existing As Object
    Dim pd6 As Object
    Dim packageMap As Object
    Dim seen As Object

    Set wsAssign = VFD_FUNC_GetSheet(ASSIGN_SHEET)
    Set wsSource = VFD_FUNC_GetSheet(VFD_SOURCE_SHEET)
    Set wsPD6 = VFD_FUNC_GetSheet(PD6_SHEET)

    If wsAssign Is Nothing Then
        VFD_FUNC_EnsureAssignmentSheet
        Set wsAssign = VFD_FUNC_GetSheet(ASSIGN_SHEET)
    End If

    If wsSource Is Nothing Then
        Err.Raise vbObjectError + 20701, _
                  "VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT", _
                  VFD_SOURCE_SHEET & " was not found."
    End If

    Set existing = VFD_FUNC_LoadExistingAssignments(wsAssign)
    Set pd6 = VFD_FUNC_LoadPD6Lookup(wsPD6)
    Set packageMap = VFD_FUNC_LoadPackageSummary()
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    VFD_FUNC_ClearAssignmentData wsAssign

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(wsSource)

    Dim cSisElement As Long
    Dim cSisSequence As Long
    Dim cArea As Long
    Dim cSWG As Long
    Dim cPanel As Long
    Dim cType As Long
    Dim cPower As Long

    cSisElement = VFD_FUNC_FindFirstHeader(h, Array("SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER"))
    cSisSequence = VFD_FUNC_FindFirstHeader(h, Array("SIS_SEQUENCE", "SIS SEQUENCE"))
    cArea = VFD_FUNC_FindFirstHeader(h, Array("AREA_NUMBER", "AREA NUMBER"))
    cSWG = VFD_FUNC_FindFirstHeader(h, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cPanel = VFD_FUNC_FindFirstHeader(h, Array("480V PANEL", "PANEL", "PNL"))
    cType = VFD_FUNC_FindFirstHeader(h, Array("TYPE", "DEVICE TYPE"))
    cPower = VFD_FUNC_FindFirstHeader(h, Array("MOTOR POWER (MAIN DRIVE)", "MOTOR POWER (MAIN)"))

    If cSisElement = 0 Then
        Err.Raise vbObjectError + 20702, _
                  "VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT", _
                  "SIS_ELEMENT_NUMBER is missing from " & VFD_SOURCE_SHEET & "."
    End If

    Dim r As Long
    Dim outRow As Long
    Dim sisElement As String
    Dim sisSequence As String
    Dim key As String
    Dim controlID As String
    Dim panel As String
    Dim pd6Rec As Variant
    Dim oldRec As Variant
    Dim functionVariant As String
    Dim notes As String
    Dim packageText As String
    Dim statusText As String

    outRow = 2

    For r = 2 To VFD_FUNC_LastRow(wsSource)
        sisElement = VFD_FUNC_Text(wsSource, r, cSisElement)
        sisSequence = VFD_FUNC_Text(wsSource, r, cSisSequence)

        If Len(sisSequence) > 0 Or Len(sisElement) > 0 Then
            key = VFD_FUNC_AssignmentKey(sisSequence, sisElement)

            If Not seen.Exists(key) Then
                seen.Add key, True
                controlID = vbNullString
                panel = VFD_FUNC_Text(wsSource, r, cPanel)

                If pd6.Exists(key) Then
                    pd6Rec = pd6(key)
                    controlID = CStr(pd6Rec(1))

                    If Len(panel) = 0 Then
                        panel = CStr(pd6Rec(2))
                    End If
                End If

                functionVariant = vbNullString
                notes = vbNullString

                If existing.Exists(key) Then
                    oldRec = existing(key)
                    functionVariant = CStr(oldRec(1))
                    notes = CStr(oldRec(2))
                End If

                packageText = VFD_FUNC_PackageText(packageMap, functionVariant)

                If Len(functionVariant) = 0 Then
                    statusText = "UNASSIGNED"
                ElseIf Len(packageText) = 0 Then
                    statusText = "FUNCTION HAS NO DEVICE MAP"
                Else
                    statusText = "READY"
                End If

                wsAssign.Cells(outRow, 1).Value2 = "YES"
                wsAssign.Cells(outRow, 2).Value2 = sisSequence
                wsAssign.Cells(outRow, 3).Value2 = sisElement
                wsAssign.Cells(outRow, 4).Value2 = controlID
                wsAssign.Cells(outRow, 5).Value2 = VFD_FUNC_Text(wsSource, r, cArea)
                wsAssign.Cells(outRow, 6).Value2 = VFD_FUNC_Text(wsSource, r, cSWG)
                wsAssign.Cells(outRow, 7).Value2 = panel
                wsAssign.Cells(outRow, 8).Value2 = VFD_FUNC_Text(wsSource, r, cType)
                wsAssign.Cells(outRow, 9).Value2 = VFD_FUNC_Text(wsSource, r, cPower)
                wsAssign.Cells(outRow, 10).Value2 = functionVariant
                wsAssign.Cells(outRow, 11).Value2 = packageText
                wsAssign.Cells(outRow, 12).Value2 = statusText
                wsAssign.Cells(outRow, 13).Value2 = notes

                outRow = outRow + 1
            End If
        End If
    Next r

    VFD_FUNC_FormatAssignmentSheet wsAssign
    VFD_FUNC_AddAssignmentButtons wsAssign

    VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT = True
    Exit Function

Failed:
    VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT = False
End Function


Public Sub VFD_FUNCTION_SYNC_QUEUE()
    If VFD_FUNCTION_SYNC_QUEUE_SILENT Then
        MsgBox _
            "Function Variant assignments were synchronized to VFD_DWG_QUEUE.", _
            vbInformation, _
            "ONGEN VFD Function Assignment"
    Else
        MsgBox _
            "Function Variant synchronization could not complete.", _
            vbExclamation, _
            "ONGEN VFD Function Assignment"
    End If
End Sub


Public Function VFD_FUNCTION_SYNC_QUEUE_SILENT() As Boolean
    On Error GoTo Failed

    VFD_FUNC_EnsureAssignmentSheet
    VFD_FUNC_EnsureQueueColumns

    Dim lookup As Object
    Set lookup = VFD_FUNC_LoadAssignmentLookup()

    Dim wsQ As Worksheet
    Set wsQ = VFD_FUNC_GetSheet(QUEUE_SHEET)

    If wsQ Is Nothing Then
        Err.Raise vbObjectError + 20703, _
                  "VFD_FUNCTION_SYNC_QUEUE_SILENT", _
                  QUEUE_SHEET & " was not found."
    End If

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(wsQ)

    Dim cVariant As Long
    Dim cRightVariant As Long
    Dim r As Long

    cVariant = VFD_FUNC_Col(h, "FUNCTION_VARIANT")
    cRightVariant = VFD_FUNC_Col(h, "RIGHT_FUNCTION_VARIANT")

    For r = 2 To VFD_FUNC_LastRow(wsQ)
        wsQ.Cells(r, cVariant).Value2 = _
            VFD_FUNC_ResolveQueueAssignment(wsQ, r, h, lookup, False)

        wsQ.Cells(r, cRightVariant).Value2 = _
            VFD_FUNC_ResolveQueueAssignment(wsQ, r, h, lookup, True)
    Next r

    VFD_FUNCTION_SYNC_QUEUE_SILENT = True
    Exit Function

Failed:
    VFD_FUNCTION_SYNC_QUEUE_SILENT = False
End Function


Public Sub VFD_FUNCTION_OPEN_ASSIGNMENT()
    VFD_FUNC_OpenSheet ASSIGN_SHEET
End Sub


Public Sub VFD_FUNCTION_OPEN_DEVICE_MAP()
    VFD_FUNC_OpenSheet MAP_SHEET
End Sub


Public Sub VFD_FUNCTION_DIAGNOSTIC()
    Dim wsAssign As Worksheet
    Dim wsQ As Worksheet
    Dim h As Object
    Dim r As Long

    Dim totalVFD As Long
    Dim assignedVFD As Long
    Dim readyVFD As Long
    Dim queueRows As Long
    Dim queueWithFunction As Long
    Dim rightWithFunction As Long

    Set wsAssign = VFD_FUNC_GetSheet(ASSIGN_SHEET)
    Set wsQ = VFD_FUNC_GetSheet(QUEUE_SHEET)

    If Not wsAssign Is Nothing Then
        Set h = VFD_FUNC_HeaderMap(wsAssign)

        For r = 2 To VFD_FUNC_LastRow(wsAssign)
            If VFD_FUNC_Yes(VFD_FUNC_Text(wsAssign, r, VFD_FUNC_Col(h, "ENABLED"))) Then
                totalVFD = totalVFD + 1

                If Len(VFD_FUNC_Text(wsAssign, r, VFD_FUNC_Col(h, "FUNCTION_VARIANT"))) > 0 Then
                    assignedVFD = assignedVFD + 1
                End If

                If UCase$(VFD_FUNC_Text(wsAssign, r, VFD_FUNC_Col(h, "ASSIGNMENT_STATUS"))) = "READY" Then
                    readyVFD = readyVFD + 1
                End If
            End If
        Next r
    End If

    If Not wsQ Is Nothing Then
        Set h = VFD_FUNC_HeaderMap(wsQ)

        For r = 2 To VFD_FUNC_LastRow(wsQ)
            If VFD_FUNC_Yes(VFD_FUNC_Text(wsQ, r, VFD_FUNC_Col(h, "ENABLED"))) Then
                queueRows = queueRows + 1

                If Len(VFD_FUNC_Text(wsQ, r, VFD_FUNC_Col(h, "FUNCTION_VARIANT"))) > 0 Then
                    queueWithFunction = queueWithFunction + 1
                End If

                If Len(VFD_FUNC_Text(wsQ, r, VFD_FUNC_Col(h, "RIGHT_FUNCTION_VARIANT"))) > 0 Then
                    rightWithFunction = rightWithFunction + 1
                End If
            End If
        Next r
    End If

    MsgBox _
        "VFD Function Assignment diagnostic" & vbCrLf & vbCrLf & _
        "Active VFDs: " & CStr(totalVFD) & vbCrLf & _
        "Assigned Function Variant: " & CStr(assignedVFD) & vbCrLf & _
        "Ready with Device Map: " & CStr(readyVFD) & vbCrLf & vbCrLf & _
        "Enabled queue rows: " & CStr(queueRows) & vbCrLf & _
        "LEFT queue functions: " & CStr(queueWithFunction) & vbCrLf & _
        "RIGHT queue functions: " & CStr(rightWithFunction), _
        vbInformation, _
        "ONGEN VFD Function Assignment"
End Sub


'===============================================================================
' ASSIGNMENT WORKSHEET
'===============================================================================

Private Sub VFD_FUNC_EnsureAssignmentSheet()
    Dim ws As Worksheet
    Set ws = VFD_FUNC_GetSheet(ASSIGN_SHEET)

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))

        ws.Name = ASSIGN_SHEET
    End If

    Dim headers As Variant
    headers = Array( _
        "ENABLED", _
        "SIS_SEQUENCE", _
        "SIS_ELEMENT_NUMBER", _
        "CONTROL_ID", _
        "AREA_NUMBER", _
        "SWITCHGROUP", _
        "PANEL", _
        "DRIVE_TYPE", _
        "MOTOR_POWER", _
        "FUNCTION_VARIANT", _
        "DEVICE_PACKAGE", _
        "ASSIGNMENT_STATUS", _
        "NOTES")

    Dim c As Long

    For c = LBound(headers) To UBound(headers)
        ws.Cells(1, c + 1).Value2 = headers(c)
    Next c

    VFD_FUNC_FormatAssignmentSheet ws
    VFD_FUNC_AddAssignmentButtons ws
End Sub


Private Sub VFD_FUNC_FormatAssignmentSheet(ByVal ws As Worksheet)
    With ws.Range("A1:M1")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .WrapText = True
    End With

    ws.Columns("A:M").AutoFit

    ws.Columns("B:D").columnWidth = 22
    ws.Columns("J:J").columnWidth = 18
    ws.Columns("K:K").columnWidth = 36
    ws.Columns("L:L").columnWidth = 28
    ws.Columns("M:M").columnWidth = 32

    'User-editable project assignment columns.
    ws.Columns("J:J").Interior.Color = RGB(226, 239, 218)
    ws.Columns("M:M").Interior.Color = RGB(255, 242, 204)

    On Error Resume Next
    ws.Range("A1:M1").AutoFilter
    On Error GoTo 0
End Sub


Private Sub VFD_FUNC_AddAssignmentButtons(ByVal ws As Worksheet)
    VFD_FUNC_DeleteShape ws, BTN_REFRESH
    VFD_FUNC_DeleteShape ws, BTN_SYNC
    VFD_FUNC_DeleteShape ws, BTN_MAP
    VFD_FUNC_DeleteShape ws, BTN_DIAG

    Dim leftPos As Double
    Dim topPos As Double
    Dim widthVal As Double
    Dim heightVal As Double

    leftPos = ws.Range("O2").Left
    topPos = ws.Range("O2").Top
    widthVal = 150
    heightVal = 28

    VFD_FUNC_AddButton _
        ws, _
        BTN_REFRESH, _
        "Refresh VFD List", _
        "VFD_FUNCTION_REFRESH_ASSIGNMENT", _
        leftPos, _
        topPos, _
        widthVal, _
        heightVal

    VFD_FUNC_AddButton _
        ws, _
        BTN_SYNC, _
        "Sync Functions to Queue", _
        "VFD_FUNCTION_SYNC_QUEUE", _
        leftPos, _
        topPos + 34, _
        widthVal, _
        heightVal

    VFD_FUNC_AddButton _
        ws, _
        BTN_MAP, _
        "Open Function Device Map", _
        "VFD_FUNCTION_OPEN_DEVICE_MAP", _
        leftPos, _
        topPos + 68, _
        widthVal, _
        heightVal

    VFD_FUNC_AddButton _
        ws, _
        BTN_DIAG, _
        "Function Diagnostic", _
        "VFD_FUNCTION_DIAGNOSTIC", _
        leftPos, _
        topPos + 102, _
        widthVal, _
        heightVal
End Sub


Private Function VFD_FUNC_LoadExistingAssignments(ByVal ws As Worksheet) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    If ws Is Nothing Then
        Set VFD_FUNC_LoadExistingAssignments = dict
        Exit Function
    End If

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(ws)

    Dim cSisSequence As Long
    Dim cSisElement As Long
    Dim cFunction As Long
    Dim cNotes As Long
    Dim r As Long
    Dim sisSequence As String
    Dim sisElement As String
    Dim rec(1 To 2) As Variant

    cSisSequence = VFD_FUNC_Col(h, "SIS_SEQUENCE")
    cSisElement = VFD_FUNC_Col(h, "SIS_ELEMENT_NUMBER")
    cFunction = VFD_FUNC_Col(h, "FUNCTION_VARIANT")
    cNotes = VFD_FUNC_Col(h, "NOTES")

    For r = 2 To VFD_FUNC_LastRow(ws)
        sisSequence = VFD_FUNC_Text(ws, r, cSisSequence)
        sisElement = VFD_FUNC_Text(ws, r, cSisElement)

        rec(1) = VFD_FUNC_Text(ws, r, cFunction)
        rec(2) = VFD_FUNC_Text(ws, r, cNotes)

        If Len(sisSequence) > 0 Then
            VFD_FUNC_SetAssignmentRecord dict, "SEQ|" & UCase$(sisSequence), rec
        End If

        If Len(sisElement) > 0 Then
            VFD_FUNC_SetAssignmentRecord dict, "ELM|" & UCase$(sisElement), rec
        End If
    Next r

    Set VFD_FUNC_LoadExistingAssignments = dict
End Function


Private Sub VFD_FUNC_SetAssignmentRecord( _
    ByVal dict As Object, _
    ByVal keyValue As String, _
    ByVal rec As Variant)

    If dict.Exists(keyValue) Then
        dict(keyValue) = rec
    Else
        dict.Add keyValue, rec
    End If
End Sub


Private Function VFD_FUNC_AssignmentKey( _
    ByVal sisSequence As String, _
    ByVal sisElement As String) As String

    If Len(Trim$(sisSequence)) > 0 Then
        VFD_FUNC_AssignmentKey = "SEQ|" & UCase$(Trim$(sisSequence))
    Else
        VFD_FUNC_AssignmentKey = "ELM|" & UCase$(Trim$(sisElement))
    End If
End Function


Private Sub VFD_FUNC_ClearAssignmentData(ByVal ws As Worksheet)
    Dim lastRow As Long
    lastRow = VFD_FUNC_LastRow(ws)

    If lastRow >= 2 Then
        ws.Range("A2:M" & lastRow).ClearContents
    End If
End Sub


'===============================================================================
' FUNCTION DEVICE MAP
'===============================================================================

Private Sub VFD_FUNC_EnsureMapSheet()
    Dim ws As Worksheet
    Set ws = VFD_FUNC_GetSheet(MAP_SHEET)

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = MAP_SHEET
    End If

    'Definition-only contract. Placement geometry belongs to the device library.
    Dim required As Variant
    required = Array("ENABLED", "FUNCTION_VARIANT", "DEVICE_TYPE", "PAGE_CODE", "QTY", "NOTES")

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(ws)
    Dim c As Long, nextCol As Long
    For c = LBound(required) To UBound(required)
        If Not h.Exists(CStr(required(c))) Then
            nextCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column + 1
            If nextCol < 1 Then nextCol = 1
            ws.Cells(1, nextCol).Value2 = required(c)
            Set h = VFD_FUNC_HeaderMap(ws)
        End If
    Next c

    With ws.Range("A1:F1")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .WrapText = True
    End With

    If VFD_FUNC_LastRow(ws) = 1 Then
        VFD_FUNC_WriteMapExample ws, 2, "01", "PHOTO_EYE", "IO", "EXAMPLE - Function 01 receives Photo-eye"
        VFD_FUNC_WriteMapExample ws, 3, "01", "ENCODER", "IO", "EXAMPLE - Function 01 receives Encoder"
        VFD_FUNC_WriteMapExample ws, 4, "02", "PHOTO_EYE", "IO", "EXAMPLE - Function 02 receives Photo-eye"
    End If
End Sub


Private Sub VFD_FUNC_WriteMapExample( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal functionVariant As String, _
    ByVal deviceType As String, _
    ByVal pageCode As String, _
    ByVal notes As String)

    ws.Cells(r, 1).Value2 = "NO"
    ws.Cells(r, 2).Value2 = functionVariant
    ws.Cells(r, 3).Value2 = deviceType
    ws.Cells(r, 4).Value2 = pageCode
    ws.Cells(r, 5).Value2 = 1
    ws.Cells(r, 6).Value2 = notes
End Sub


Public Sub VFD_FUNCTION_INSTALL_SILENT()
    On Error Resume Next
    VFD_FUNC_EnsureMapSheet
    VFD_FUNC_EnsureAssignmentSheet
    VFD_FUNC_EnsurePlacementOverrideColumn
    VFD_FUNC_EnsureQueueColumns
    VFD_FUNCTION_REFRESH_ASSIGNMENT_SILENT
    VFD_FUNCTION_SYNC_QUEUE_SILENT
    On Error GoTo 0
End Sub


Private Function VFD_FUNC_LoadPackageSummary() As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    Dim ws As Worksheet
    Set ws = VFD_FUNC_GetSheet(MAP_SHEET)

    If ws Is Nothing Then
        Set VFD_FUNC_LoadPackageSummary = dict
        Exit Function
    End If

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(ws)

    Dim cEnabled As Long
    Dim cFunction As Long
    Dim cDevice As Long
    Dim r As Long
    Dim functionVariant As String
    Dim deviceType As String
    Dim currentText As String

    cEnabled = VFD_FUNC_Col(h, "ENABLED")
    cFunction = VFD_FUNC_Col(h, "FUNCTION_VARIANT")
    cDevice = VFD_FUNC_Col(h, "DEVICE_TYPE")

    For r = 2 To VFD_FUNC_LastRow(ws)
        If VFD_FUNC_Yes(VFD_FUNC_Text(ws, r, cEnabled)) Then
            functionVariant = VFD_FUNC_Text(ws, r, cFunction)
            deviceType = VFD_FUNC_Text(ws, r, cDevice)

            If Len(functionVariant) > 0 And Len(deviceType) > 0 Then
                currentText = vbNullString

                If dict.Exists(functionVariant) Then
                    currentText = CStr(dict(functionVariant))
                End If

                If InStr(1, "|" & currentText & "|", "|" & deviceType & "|", vbTextCompare) = 0 Then
                    If Len(currentText) > 0 Then
                        currentText = currentText & " | "
                    End If

                    currentText = currentText & deviceType
                    dict(functionVariant) = currentText
                End If
            End If
        End If
    Next r

    Set VFD_FUNC_LoadPackageSummary = dict
End Function


Private Function VFD_FUNC_PackageText( _
    ByVal packageMap As Object, _
    ByVal functionVariant As String) As String

    If Len(Trim$(functionVariant)) = 0 Then Exit Function

    If packageMap.Exists(functionVariant) Then
        VFD_FUNC_PackageText = CStr(packageMap(functionVariant))
    End If
End Function


'===============================================================================
' PD6 ENRICHMENT
'===============================================================================

Private Function VFD_FUNC_LoadPD6Lookup(ByVal ws As Worksheet) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    If ws Is Nothing Then
        Set VFD_FUNC_LoadPD6Lookup = dict
        Exit Function
    End If

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(ws)

    Dim cSIS As Long
    Dim cType As Long
    Dim cControl As Long
    Dim cPanel As Long
    Dim r As Long
    Dim sisElement As String
    Dim typeValue As String
    Dim rec(1 To 2) As Variant

    cSIS = VFD_FUNC_FindFirstHeader(h, Array("SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER"))
    cType = VFD_FUNC_FindFirstHeader(h, Array("TYPE", "DEVICE TYPE"))
    cControl = VFD_FUNC_FindFirstHeader(h, Array("CONTROL_ID", "CONTROL ID"))
    cPanel = VFD_FUNC_FindFirstHeader(h, Array("PNL", "PANEL"))

    For r = 2 To VFD_FUNC_LastRow(ws)
        sisElement = VFD_FUNC_Text(ws, r, cSIS)
        typeValue = UCase$(VFD_FUNC_Text(ws, r, cType))

        If Len(sisElement) > 0 Then
            If typeValue = "VFD" Or typeValue = "MOT" Or typeValue = "MC" Then
                rec(1) = VFD_FUNC_Text(ws, r, cControl)
                rec(2) = VFD_FUNC_Text(ws, r, cPanel)

                If Not dict.Exists(sisElement) Then
                    dict.Add sisElement, rec
                End If
            End If
        End If
    Next r

    Set VFD_FUNC_LoadPD6Lookup = dict
End Function


'===============================================================================
' ASSIGNMENT LOOKUP -> QUEUE
'===============================================================================

Private Function VFD_FUNC_LoadAssignmentLookup() As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    Dim ws As Worksheet
    Set ws = VFD_FUNC_GetSheet(ASSIGN_SHEET)

    If ws Is Nothing Then
        Set VFD_FUNC_LoadAssignmentLookup = dict
        Exit Function
    End If

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(ws)

    Dim cEnabled As Long
    Dim cSisElement As Long
    Dim cSisSequence As Long
    Dim cControl As Long
    Dim cFunction As Long
    Dim r As Long
    Dim functionVariant As String

    cEnabled = VFD_FUNC_Col(h, "ENABLED")
    cSisElement = VFD_FUNC_Col(h, "SIS_ELEMENT_NUMBER")
    cSisSequence = VFD_FUNC_Col(h, "SIS_SEQUENCE")
    cControl = VFD_FUNC_Col(h, "CONTROL_ID")
    cFunction = VFD_FUNC_Col(h, "FUNCTION_VARIANT")

    For r = 2 To VFD_FUNC_LastRow(ws)
        If VFD_FUNC_Yes(VFD_FUNC_Text(ws, r, cEnabled)) Then
            functionVariant = VFD_FUNC_Text(ws, r, cFunction)

            If Len(functionVariant) > 0 Then
                VFD_FUNC_AddLookupKey _
                    dict, _
                    VFD_FUNC_Text(ws, r, cSisSequence), _
                    functionVariant

                VFD_FUNC_AddLookupKey _
                    dict, _
                    VFD_FUNC_Text(ws, r, cSisElement), _
                    functionVariant

                VFD_FUNC_AddLookupKey _
                    dict, _
                    VFD_FUNC_Text(ws, r, cControl), _
                    functionVariant
            End If
        End If
    Next r

    Set VFD_FUNC_LoadAssignmentLookup = dict
End Function


Private Sub VFD_FUNC_AddLookupKey( _
    ByVal dict As Object, _
    ByVal keyValue As String, _
    ByVal functionVariant As String)

    keyValue = Trim$(keyValue)

    If Len(keyValue) = 0 Then Exit Sub

    If dict.Exists(keyValue) Then
        dict(keyValue) = functionVariant
    Else
        dict.Add keyValue, functionVariant
    End If
End Sub


Private Function VFD_FUNC_ResolveQueueAssignment( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal h As Object, _
    ByVal lookup As Object, _
    ByVal useRight As Boolean) As String

    Dim prefix As String
    Dim candidates As Variant
    Dim item As Variant
    Dim value As String

    If useRight Then
        prefix = "RIGHT_"
    Else
        prefix = vbNullString
    End If

    candidates = Array( _
        prefix & "SIS_SEQUENCE", _
        prefix & "SIS_ELEMENT_NUMBER", _
        prefix & "CONTROL_ID")

    For Each item In candidates
        If h.Exists(CStr(item)) Then
            value = VFD_FUNC_Text(ws, r, CLng(h(CStr(item))))

            If Len(value) > 0 Then
                If lookup.Exists(value) Then
                    VFD_FUNC_ResolveQueueAssignment = CStr(lookup(value))
                    Exit Function
                End If
            End If
        End If
    Next item
End Function


'===============================================================================
' PLACEMENT / QUEUE INSTALLATION
'===============================================================================

Private Sub VFD_FUNC_EnsurePlacementOverrideColumn()
    Dim ws As Worksheet
    Set ws = VFD_FUNC_GetSheet(PLACEMENT_SHEET)

    If ws Is Nothing Then Exit Sub

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(ws)

    If Not h.Exists("OVERRIDE_ACTION") Then
        VFD_FUNC_AddHeader ws, "OVERRIDE_ACTION"
    End If
End Sub


Private Sub VFD_FUNC_EnsureQueueColumns()
    Dim ws As Worksheet
    Set ws = VFD_FUNC_GetSheet(QUEUE_SHEET)

    If ws Is Nothing Then Exit Sub

    Dim h As Object
    Set h = VFD_FUNC_HeaderMap(ws)

    If Not h.Exists("FUNCTION_VARIANT") Then
        VFD_FUNC_AddHeader ws, "FUNCTION_VARIANT"
    End If

    Set h = VFD_FUNC_HeaderMap(ws)

    If Not h.Exists("RIGHT_FUNCTION_VARIANT") Then
        VFD_FUNC_AddHeader ws, "RIGHT_FUNCTION_VARIANT"
    End If
End Sub


Private Sub VFD_FUNC_AddHeader(ByVal ws As Worksheet, ByVal headerName As String)
    Dim c As Long
    c = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column + 1

    ws.Cells(1, c).Value2 = headerName
    ws.Cells(1, c).Font.Bold = True
End Sub


'===============================================================================
' BUTTON / NAVIGATION HELPERS
'===============================================================================

Private Sub VFD_FUNC_AddButton( _
    ByVal ws As Worksheet, _
    ByVal shapeName As String, _
    ByVal caption As String, _
    ByVal macroName As String, _
    ByVal leftPos As Double, _
    ByVal topPos As Double, _
    ByVal widthVal As Double, _
    ByVal heightVal As Double)

    Dim shp As Shape

    Set shp = ws.Shapes.AddShape( _
        msoShapeRoundedRectangle, _
        leftPos, _
        topPos, _
        widthVal, _
        heightVal)

    shp.Name = shapeName
    shp.OnAction = VFD_FUNC_QualifiedMacro(macroName)

    On Error Resume Next
    shp.Fill.ForeColor.RGB = RGB(22, 42, 58)
    shp.Line.ForeColor.RGB = RGB(92, 200, 190)
    shp.TextFrame.Characters.text = caption
    shp.TextFrame.HorizontalAlignment = xlHAlignCenter
    shp.TextFrame.VerticalAlignment = xlVAlignCenter
    shp.TextFrame.Characters.Font.Bold = True
    shp.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
    On Error GoTo 0
End Sub


Private Sub VFD_FUNC_DeleteShape(ByVal ws As Worksheet, ByVal shapeName As String)
    On Error Resume Next
    ws.Shapes(shapeName).Delete
    On Error GoTo 0
End Sub


Private Sub VFD_FUNC_OpenSheet(ByVal sheetName As String)
    Dim ws As Worksheet
    Set ws = VFD_FUNC_GetSheet(sheetName)

    If ws Is Nothing Then
        MsgBox _
            sheetName & " was not found.", _
            vbExclamation, _
            "ONGEN VFD Function Assignment"

        Exit Sub
    End If

    ws.Activate
    ws.Range("A1").Select
End Sub


Private Function VFD_FUNC_QualifiedMacro(ByVal macroName As String) As String
    VFD_FUNC_QualifiedMacro = _
        "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function


'===============================================================================
' GENERAL HELPERS
'===============================================================================

Private Function VFD_FUNC_HeaderMap(ByVal ws As Worksheet) As Object
    Dim h As Object
    Set h = CreateObject("Scripting.Dictionary")
    h.CompareMode = vbTextCompare

    Dim lastCol As Long
    Dim c As Long
    Dim key As String

    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column

    For c = 1 To lastCol
        key = UCase$(Trim$(CStr(ws.Cells(1, c).Value2)))

        If Len(key) > 0 Then
            h(key) = c
        End If
    Next c

    Set VFD_FUNC_HeaderMap = h
End Function


Private Function VFD_FUNC_FindFirstHeader( _
    ByVal h As Object, _
    ByVal candidates As Variant) As Long

    Dim item As Variant

    For Each item In candidates
        If h.Exists(UCase$(CStr(item))) Then
            VFD_FUNC_FindFirstHeader = CLng(h(UCase$(CStr(item))))
            Exit Function
        End If
    Next item
End Function


Private Function VFD_FUNC_Col(ByVal h As Object, ByVal headerName As String) As Long
    If h.Exists(headerName) Then
        VFD_FUNC_Col = CLng(h(headerName))
    End If
End Function


Private Function VFD_FUNC_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set VFD_FUNC_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function


Private Function VFD_FUNC_LastRow(ByVal ws As Worksheet) As Long
    Dim f As Range

    On Error GoTo SafeExit

    Set f = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    If Not f Is Nothing Then
        VFD_FUNC_LastRow = f.Row
    End If

    Exit Function

SafeExit:
    VFD_FUNC_LastRow = 0
End Function


Private Function VFD_FUNC_Text( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal c As Long) As String

    If c <= 0 Then Exit Function
    If IsError(ws.Cells(r, c).Value2) Then Exit Function

    VFD_FUNC_Text = Trim$(CStr(ws.Cells(r, c).Value2))
End Function


Private Function VFD_FUNC_Yes(ByVal value As String) As Boolean
    Dim s As String
    s = UCase$(Trim$(value))

    VFD_FUNC_Yes = _
        (s = "YES" Or s = "Y" Or s = "TRUE" Or s = "1")
End Function
