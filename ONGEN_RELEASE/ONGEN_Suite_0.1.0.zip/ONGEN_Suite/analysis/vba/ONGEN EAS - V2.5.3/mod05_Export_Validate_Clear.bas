Attribute VB_Name = "mod05_Export_Validate_Clear"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod05_Export_Validate_Clear
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Step09 24V-only; Step15I VFD_DWG_QUEUE 480V export added.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : mod05_Export_Validate_Clear
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Static procedure, declaration, and public-name audit completed.
' Notes         : Logic retained from the uploaded workbook; comments preserved and suite header standardized.
'-------------------------------------------------------------------------------


'-------------------------------------------------------------------------------
' FULLY COMMENTED MAINTENANCE RELEASE
' Documentation Release : ONGEN V16.2-R2-COMMENTED
' Baseline              : ONGEN V16.2-R1 executable logic
' Functional Changes    : None - original VBA statements are preserved
' Commenting Method     : One explanation per logical VBA statement
' Continuation Rule     : Statements joined with _ receive one group comment
' Author/Owner          : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

Option Explicit

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R1
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-12
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

'==========================================================
' Module: mod05_Export_Validate_Clear
' Author     : Lee Pierre
' PATCH: export all panel-specific 24V generator worksheets
' PATCH C04.5: Step09 exports 24V A:H + TAG in I only; 480V moved to Step15I.
' PATCH C04.5: Step15I exports VFD_DWG_QUEUE + TAG/RIGHT_TAG for PWR rows.
'
' Replace the old mod05_Export_Validate_Clear module with this one.
' Step09 exports every worksheet created by Step07 whose name starts
' with "24v_" and contains the SNR 24V headers. This allows the existing
' SNR_24V_BUS_PSU_GEN LISP to scan one workbook and generate each PNL
' separately.
'
' Depends on:
'   mod00_ONGEN_Common
'==========================================================


'-------------------------------------------------------------------------------
' Procedure : Step09_Export_SNR_24V_Input
' Scope/Type: Public Sub
' Purpose   : Exports snr 24 v input.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Public Sub Step09_Export_SNR_24V_Input()

    Dim wbOut As Workbook
    Dim savePath As String
    Dim ws As Worksheet
    Dim wsNew As Worksheet
    Dim exported24VCount As Long
    Dim totalExported As Long
    Dim lastRow As Long

    On Error GoTo ErrHandler
    ResetApplicationState False

    'Step 09 is intentionally 24V-only. 480V/VFD queue export is Step 15I.
    savePath = PickSaveAsPath("Save SNR 24V input workbook", "SNR_24V_Input_By_Panel.xlsx")
    If Len(savePath) = 0 Then GoTo SafeExit

    ONGEN_CableID_BeginRun
    Set wbOut = Workbooks.Add(xlWBATWorksheet)

    'Export every generated panel 24V sheet A:H and append TAG in column I.
    'The right-side helper preview columns are intentionally excluded from SNR export.
    For Each ws In ThisWorkbook.Worksheets
        If Is24VPanelGeneratorSheet(ws) Then
            totalExported = totalExported + 1
            exported24VCount = exported24VCount + 1
            Set wsNew = GetNextExportWorksheet(wbOut, totalExported, _
                                                Replace$(ws.Name, "_24v", "", 1, -1, vbTextCompare))
            lastRow = LastUsedRow(ws)
            CopyGeneratorRangeWithFormat ws, wsNew, lastRow, 8
            Populate24VExportTags ws, wsNew, lastRow
        End If
    Next ws

    If totalExported = 0 Then
        wbOut.Close SaveChanges:=False
        MsgBox "No generated 24V panel generator sheets were found." & vbCrLf & _
               "Run Step 07 first.", vbExclamation, "ONGEN Step 09"
        GoTo SafeExit
    End If

    'Remove ONGEN navigation controls from the export only.
    NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook wbOut
    wbOut.SaveAs fileName:=savePath, FileFormat:=xlOpenXMLWorkbook
    wbOut.Close SaveChanges:=False
    Set wbOut = Nothing

    AppendLog "Step09_Export_SNR_24V_Input", "OK", savePath & _
        " | 24V sheets exported: " & CStr(exported24VCount) & _
        " | 480V export intentionally excluded; use Step 15I."

    MsgBox "Step 09 24V input export complete." & vbCrLf & _
           "24V panel sheets A:I (TAG in I): " & CStr(exported24VCount) & vbCrLf & _
           "480V/VFD data is NOT exported by Step 09." & vbCrLf & _
           "Use Step 15I for VFD_DWG_QUEUE export." & vbCrLf & vbCrLf & _
           savePath, vbInformation, "ONGEN Step 09"

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    On Error Resume Next
    If Not wbOut Is Nothing Then wbOut.Close SaveChanges:=False
    ResetApplicationState True
    AppendLog "Step09_Export_SNR_24V_Input", "ERROR", Err.description
    MsgBox "Step 09 24V export failed: " & Err.description, vbCritical, "ONGEN Step 09"

End Sub

'-------------------------------------------------------------------------------
' Procedure : Step15I_Export_VFD_DWG_Queue_480V_Input
' Scope/Type: Public Sub
' Purpose   : Exports the complete VFD_DWG_QUEUE worksheet to a standalone XLSX
'             and appends stable 480V feeder cable labels.
' Notes     : TAG is the primary/left VFD feeder label. RIGHT_TAG is populated
'             only when the queue row contains RIGHT_SIS_ELEMENT_NUMBER.
'             Tags are generated only for PAGE_CODE=PWR so the same physical
'             feeder is not duplicated on IO/MPWR queue rows.
' Author    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------
Public Sub Step15I_Export_VFD_DWG_Queue_480V_Input()

    Const QUEUE_SHEET As String = "VFD_DWG_QUEUE"

    Dim wsQueue As Worksheet
    Dim wbOut As Workbook
    Dim wsOut As Worksheet
    Dim savePath As String
    Dim lastRow As Long
    Dim lastCol As Long
    Dim colPageCode As Long
    Dim colSis As Long
    Dim colPanel As Long
    Dim colRightSis As Long
    Dim colRightPanel As Long
    Dim tagCol As Long
    Dim rightTagCol As Long
    Dim r As Long
    Dim pageCode As String
    Dim sisElement As String
    Dim panel As String
    Dim rightSis As String
    Dim rightPanel As String
    Dim tagCount As Long
    Dim rightTagCount As Long

    On Error GoTo ErrHandler
    ResetApplicationState False

    Set wsQueue = GetSheetIfExists(QUEUE_SHEET)
    If wsQueue Is Nothing Then
        MsgBox "Worksheet '" & QUEUE_SHEET & "' was not found." & vbCrLf & _
               "Run Step 15A/15B/15C before Step 15I.", _
               vbExclamation, "ONGEN Step 15I"
        GoTo SafeExit
    End If

    lastRow = LastUsedRow(wsQueue)
    lastCol = LastUsedCol(wsQueue, 1)
    If lastRow < 2 Or lastCol < 1 Then
        MsgBox "VFD_DWG_QUEUE does not contain exportable data rows." & vbCrLf & _
               "Refresh the VFD drawing queue first.", vbExclamation, "ONGEN Step 15I"
        GoTo SafeExit
    End If

    colPageCode = ExportFindHeaderColumn(wsQueue, 1, Array("PAGE_CODE", "PAGE CODE"))
    colSis = ExportFindHeaderColumn(wsQueue, 1, Array("SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER"))
    colPanel = ExportFindHeaderColumn(wsQueue, 1, Array("PANEL", "PNL", "480V PANEL"))
    colRightSis = ExportFindHeaderColumn(wsQueue, 1, Array("RIGHT_SIS_ELEMENT_NUMBER", "RIGHT SIS ELEMENT NUMBER"))
    colRightPanel = ExportFindHeaderColumn(wsQueue, 1, Array("RIGHT_PANEL", "RIGHT PNL", "RIGHT 480V PANEL"))

    If colPageCode = 0 Or colSis = 0 Or colPanel = 0 Then
        Err.Raise vbObjectError + 30951, "Step15I_Export_VFD_DWG_Queue_480V_Input", _
                  "VFD_DWG_QUEUE is missing PAGE_CODE, SIS_ELEMENT_NUMBER, or PANEL. " & _
                  "Run Step 15A/15B to repair the VFD data model."
    End If

    savePath = PickSaveAsPath("Save Step 15I VFD 480V drawing queue", _
                              "VFD_DWG_Queue_480V_Input.xlsx")
    If Len(savePath) = 0 Then GoTo SafeExit

    ONGEN_CableID_BeginRun
    Set wbOut = Workbooks.Add(xlWBATWorksheet)
    Set wsOut = wbOut.Worksheets(1)
    On Error Resume Next
    wsOut.Name = "VFD_DWG_Queue"
    On Error GoTo ErrHandler

    'Export the complete queue, not the older VFD_480V_Generator worksheet.
    CopyGeneratorRangeWithFormat wsQueue, wsOut, lastRow, lastCol

    tagCol = lastCol + 1
    rightTagCol = lastCol + 2
    wsOut.Cells(1, tagCol).Value2 = "TAG"
    wsOut.Cells(1, rightTagCol).Value2 = "RIGHT_TAG"

    For r = 2 To lastRow
        pageCode = UCase$(Trim$(CStr(wsQueue.Cells(r, colPageCode).Value2)))

        'Only PWR queue rows represent the physical 480V VFD feeder cable.
        If pageCode = "PWR" Then
            sisElement = Trim$(CStr(wsQueue.Cells(r, colSis).Value2))
            panel = Trim$(CStr(wsQueue.Cells(r, colPanel).Value2))

            If Len(sisElement) > 0 Then
                wsOut.Cells(r, tagCol).Value2 = ONGEN_ExportTag_PWR(panel, sisElement)
                If Len(Trim$(CStr(wsOut.Cells(r, tagCol).Value2))) > 0 Then tagCount = tagCount + 1
            End If

            If colRightSis > 0 Then
                rightSis = Trim$(CStr(wsQueue.Cells(r, colRightSis).Value2))
                If Len(rightSis) > 0 Then
                    rightPanel = panel
                    If colRightPanel > 0 Then
                        If Len(Trim$(CStr(wsQueue.Cells(r, colRightPanel).Value2))) > 0 Then _
                            rightPanel = Trim$(CStr(wsQueue.Cells(r, colRightPanel).Value2))
                    End If
                    wsOut.Cells(r, rightTagCol).Value2 = ONGEN_ExportTag_PWR(rightPanel, rightSis)
                    If Len(Trim$(CStr(wsOut.Cells(r, rightTagCol).Value2))) > 0 Then _
                        rightTagCount = rightTagCount + 1
                End If
            End If
        End If
    Next r

    'Match the queue header style for the appended label columns.
    wsQueue.Cells(1, lastCol).Copy
    wsOut.Cells(1, tagCol).PasteSpecial Paste:=xlPasteFormats
    wsOut.Cells(1, rightTagCol).PasteSpecial Paste:=xlPasteFormats
    Application.CutCopyMode = False
    wsOut.Columns(tagCol).columnWidth = 14
    wsOut.Columns(rightTagCol).columnWidth = 14

    NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook wbOut
    wbOut.SaveAs fileName:=savePath, FileFormat:=xlOpenXMLWorkbook
    wbOut.Close SaveChanges:=False
    Set wbOut = Nothing

    AppendLog "Step15I_Export_VFD_DWG_Queue_480V_Input", "OK", savePath & _
        " | Queue rows: " & CStr(lastRow - 1) & _
        " | TAG: " & CStr(tagCount) & _
        " | RIGHT_TAG: " & CStr(rightTagCount)

    MsgBox "Step 15I VFD 480V queue export complete." & vbCrLf & _
           "Source: VFD_DWG_QUEUE" & vbCrLf & _
           "Primary 480V feeder TAG labels: " & CStr(tagCount) & vbCrLf & _
           "Secondary RIGHT_TAG labels: " & CStr(rightTagCount) & vbCrLf & vbCrLf & _
           savePath, vbInformation, "ONGEN Step 15I"

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    On Error Resume Next
    If Not wbOut Is Nothing Then wbOut.Close SaveChanges:=False
    ResetApplicationState True
    AppendLog "Step15I_Export_VFD_DWG_Queue_480V_Input", "ERROR", Err.description
    MsgBox "Step 15I VFD queue export failed: " & Err.description, vbCritical, "ONGEN Step 15I"

End Sub

Private Sub Populate24VExportTags(ByVal wsSource As Worksheet, ByVal wsTarget As Worksheet, ByVal lastRow As Long)
    Dim r As Long, currentBus As String, currentPSU As String
    Dim bus1PSU As String, bus2PSU As String, firstCell As String, secondCell As String
    Dim seventhCell As String, panel As String

    panel = wsSource.Name
    If Right$(UCase$(panel), 4) = "_24V" Then panel = Left$(panel, Len(panel) - 4)
    wsTarget.Cells(1, 9).Value2 = "TAG"

    For r = 1 To lastRow
        firstCell = Trim$(CStr(wsSource.Cells(r, 1).Value2))
        secondCell = UCase$(Trim$(CStr(wsSource.Cells(r, 2).Value2)))
        seventhCell = UCase$(Trim$(CStr(wsSource.Cells(r, 7).Value2)))

        If UCase$(firstCell) = "PWG" And secondCell = "BUS POWER" Then
            currentBus = vbNullString: currentPSU = vbNullString
            bus1PSU = vbNullString: bus2PSU = vbNullString
        ElseIf secondCell = "BUS-1" Then
            bus1PSU = Trim$(CStr(wsSource.Cells(r, 3).Value2))
        ElseIf secondCell = "BUS-2" Then
            bus2PSU = Trim$(CStr(wsSource.Cells(r, 3).Value2))
        ElseIf UCase$(firstCell) = "SIS_ELEMENT_NUMBER" Then
            wsTarget.Cells(r, 9).Value2 = "TAG"
            If InStr(1, seventhCell, "BUS-1", vbTextCompare) > 0 Then
                currentBus = "BUS-1": currentPSU = bus1PSU
            ElseIf InStr(1, seventhCell, "BUS-2", vbTextCompare) > 0 Then
                currentBus = "BUS-2": currentPSU = bus2PSU
            Else
                currentBus = vbNullString: currentPSU = vbNullString
            End If
        ElseIf Len(firstCell) > 0 And Len(currentBus) > 0 And UCase$(firstCell) <> "PWG" Then
            'Pass both the source terminal and explicit DC+/DC- pair so the
            'central cable-ID core can group devices by the same physical PSU branch.
            wsTarget.Cells(r, 9).value = ONGEN_ExportTag_DC( _
                panel, currentBus, currentPSU, firstCell, _
                CStr(wsSource.Cells(r, 7).Value2), CStr(wsSource.Cells(r, 8).Value2))
        End If
    Next r

    wsTarget.Columns(9).columnWidth = 14
End Sub

'Legacy VFD_480V_Generator export helper removed in C04.5.
'Use Step15I_Export_VFD_DWG_Queue_480V_Input for all 480V drawing exports.



' Step 13 exports only worksheets whose names end in -Clean (spaces around the dash are tolerated).
' The exported workbook removes the -Clean suffix from each exported worksheet name.
Public Sub Export_RCP_Clean_Sheets_To_New_Workbook()
    Dim wbOut As Workbook, ws As Worksheet, wsNew As Worksheet
    Dim savePath As String, totalExported As Long, lastRow As Long

    On Error GoTo ErrHandler
    ResetApplicationState False
    savePath = PickSaveAsPath("Save RCP Clean values-only workbook", "RCP_Clean_Values_Only.xlsx")
    If Len(savePath) = 0 Then GoTo SafeExit

    ONGEN_CableID_BeginRun
    Set wbOut = Workbooks.Add(xlWBATWorksheet)
    For Each ws In ThisWorkbook.Worksheets
        If Step13IsCleanExportSheet(ws.Name) Then
            totalExported = totalExported + 1
            Set wsNew = GetNextExportWorksheet(wbOut, totalExported, Step13BasePanelName(ws.Name))
            lastRow = LastUsedRow(ws)
            CopyGeneratorRangeWithFormat ws, wsNew, lastRow, 8
            PopulateNetworkCleanExportTags ws, wsNew, lastRow
        End If
    Next ws

    If totalExported = 0 Then
        wbOut.Close SaveChanges:=False
        MsgBox "No *-Clean worksheets were found. Run Step 12 first.", vbExclamation, "ONGEN Step 13"
        GoTo SafeExit
    End If

    NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook wbOut
    wbOut.SaveAs fileName:=savePath, FileFormat:=xlOpenXMLWorkbook
    wbOut.Close SaveChanges:=False
    Set wbOut = Nothing
    AppendLog "Export_RCP_Clean_Sheets_To_New_Workbook", "OK", savePath & " | Sheets: " & CStr(totalExported)
    MsgBox "Clean panel worksheets exported with '-Clean' removed from the exported sheet names:" & vbCrLf & _
           savePath, vbInformation, "ONGEN Step 13"

SafeExit:
    ResetApplicationState True
    Exit Sub
ErrHandler:
    On Error Resume Next
    If Not wbOut Is Nothing Then wbOut.Close SaveChanges:=False
    ResetApplicationState True
    AppendLog "Export_RCP_Clean_Sheets_To_New_Workbook", "ERROR", Err.description
    MsgBox "Step 13 export failed: " & Err.description, vbCritical, "ONGEN Step 13"
End Sub

'Compatibility name listed in ONGEN_WORKFLOW_GUIDE.
Public Sub EXPORT_CLEAN_PNL_SHEETS_VALUES_ONLY()
    Export_RCP_Clean_Sheets_To_New_Workbook
End Sub

Private Function Step13IsCleanExportSheet(ByVal sheetName As String) As Boolean
    Dim normalized As String, basePanel As String
    normalized = UCase$(Replace(Trim$(sheetName), " ", vbNullString))
    If Len(normalized) <= 6 Or Right$(normalized, 6) <> "-CLEAN" Then Exit Function

    basePanel = UCase$(Replace(Step13BasePanelName(sheetName), "_", "-"))
    Step13IsCleanExportSheet = (Left$(basePanel, 4) = "RCP-")
End Function

Private Function Step13BasePanelName(ByVal sheetName As String) As String
    Dim t As String, normalized As String, p As Long
    t = Trim$(sheetName)
    normalized = UCase$(Replace(t, " ", vbNullString))
    If Len(normalized) <= 6 Or Right$(normalized, 6) <> "-CLEAN" Then
        Step13BasePanelName = t
        Exit Function
    End If

    'Remove CLEAN and any spaces/dash/underscore immediately before it.
    p = InStrRev(UCase$(t), "CLEAN", -1, vbTextCompare)
    If p > 0 Then t = Left$(t, p - 1)
    t = Trim$(t)
    Do While Len(t) > 0 And (Right$(t, 1) = "-" Or Right$(t, 1) = "_" Or Right$(t, 1) = " ")
        t = Trim$(Left$(t, Len(t) - 1))
    Loop
    Step13BasePanelName = t
End Function
Private Sub PopulateNetworkCleanExportTags(ByVal cleanWS As Worksheet, ByVal exportWS As Worksheet, ByVal cleanLastRow As Long)
    Dim panel As String, portText As String, previousDevice As String, currentDevice As String
    Dim r As Long, colPort As Long, colSis As Long, colDevice As Long

    exportWS.Cells(1, 9).Value2 = "tag"
    panel = Step13BasePanelName(cleanWS.Name)

    colPort = ExportFindHeaderColumn(cleanWS, 1, Array("SWITCH PORT", "PORT"))
    colSis = ExportFindHeaderColumn(cleanWS, 1, Array("SIS NUMBER", "SIS_ELEMENT_NUMBER"))
    colDevice = ExportFindHeaderColumn(cleanWS, 1, Array("DEVICE", "DEVICE NAME"))
    If colPort = 0 Or (colSis = 0 And colDevice = 0) Then
        Err.Raise vbObjectError + 30931, "PopulateNetworkCleanExportTags", _
                  "Clean topology sheet '" & cleanWS.Name & "' is missing Switch Port and/or SIS/Device headers. Rerun Step 12."
    End If

    For r = 2 To cleanLastRow
        If Len(Trim$(CStr(cleanWS.Cells(r, colPort).Value2))) > 0 Then
            portText = ONGEN_CableID_NormalizeNetworkPort(CStr(cleanWS.Cells(r, colPort).Value2))
            previousDevice = Trim$(panel & "-NSW01 " & portText)
        End If

        currentDevice = vbNullString
        If colSis > 0 Then currentDevice = Trim$(CStr(cleanWS.Cells(r, colSis).Value2))
        If Len(currentDevice) = 0 And colDevice > 0 Then currentDevice = Trim$(CStr(cleanWS.Cells(r, colDevice).Value2))

        If Len(currentDevice) > 0 And Len(portText) > 0 Then
            exportWS.Cells(r, 9).Value2 = ONGEN_ExportTag_NET(panel, portText, previousDevice, currentDevice)
            previousDevice = currentDevice
        End If
    Next r
    exportWS.Columns(9).columnWidth = 12
End Sub

Private Function ExportFindHeaderColumn(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal aliases As Variant) As Long
    Dim c As Long, i As Long, lastCol As Long, actual As String, wanted As String
    lastCol = LastUsedCol(ws)
    For c = 1 To lastCol
        actual = UCase$(Trim$(CStr(ws.Cells(headerRow, c).Value2)))
        actual = Replace(actual, "_", " ")
        Do While InStr(actual, "  ") > 0: actual = Replace(actual, "  ", " "): Loop
        For i = LBound(aliases) To UBound(aliases)
            wanted = UCase$(Trim$(CStr(aliases(i))))
            wanted = Replace(wanted, "_", " ")
            If actual = wanted Then ExportFindHeaderColumn = c: Exit Function
        Next i
    Next c
End Function

Private Sub PopulateNetworkTagsFromCleanFallback(ByVal cleanWS As Worksheet, ByVal exportWS As Worksheet, _
                                                 ByVal lastRow As Long, ByVal panel As String)
    Dim r As Long, portText As String, previousDevice As String, currentDevice As String
    For r = 2 To lastRow
        If Len(Trim$(CStr(cleanWS.Cells(r, 1).Value2))) > 0 Then
            portText = ONGEN_CableID_NormalizeNetworkPort(CStr(cleanWS.Cells(r, 1).Value2))
            previousDevice = panel & "-NSW01 " & portText
        End If
        currentDevice = Trim$(CStr(cleanWS.Cells(r, 2).Value2))
        If Len(currentDevice) = 0 Then currentDevice = Trim$(CStr(cleanWS.Cells(r, 4).Value2))
        If Len(currentDevice) > 0 And Len(portText) > 0 Then
            exportWS.Cells(r, 9).value = ONGEN_ExportTag_NET(panel, portText, previousDevice, currentDevice)
            previousDevice = currentDevice
        End If
    Next r
    exportWS.Columns(9).columnWidth = 12
End Sub

Private Function ExportMetadataValue(ByVal metadata As String, ByVal keyName As String) As String
    Dim fields() As String, i As Long, p As Long, fieldName As String
    If Len(Trim$(metadata)) = 0 Then Exit Function
    fields = Split(metadata, "|")
    keyName = UCase$(Trim$(keyName))
    For i = LBound(fields) To UBound(fields)
        p = InStr(1, fields(i), "=", vbBinaryCompare)
        If p > 0 Then
            fieldName = UCase$(Trim$(Left$(fields(i), p - 1)))
            If fieldName = keyName Then ExportMetadataValue = Trim$(mid$(fields(i), p + 1)): Exit Function
        End If
    Next i
End Function

Private Function ExportCleanTopologyDevice(ByVal topologyText As String) As String
    Dim p As Long
    topologyText = Trim$(topologyText)
    If Len(topologyText) = 0 Then Exit Function
    If InStr(1, topologyText, "AUTO NETWORK|", vbTextCompare) > 0 Then Exit Function
    If InStr(1, topologyText, "STATUS=AVAILABLE", vbTextCompare) > 0 Then Exit Function
    p = InStr(1, topologyText, "[", vbBinaryCompare)
    If p > 1 Then topologyText = Trim$(Left$(topologyText, p - 1))
    ExportCleanTopologyDevice = topologyText
End Function

Private Function IsExportNetworkPort(ByVal portText As String) As Boolean
    IsExportNetworkPort = (Len(ONGEN_CableID_NormalizeNetworkPort(portText)) > 0)
End Function

'-------------------------------------------------------------------------------
' Procedure : Step10_Validate_Workbook
' Scope/Type: Public Sub
' Purpose   : Validates workbook.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Public Sub Step10_Validate_Workbook()

    Dim wsVal As Worksheet
    Dim rowOut As Long
    Dim okAll As Boolean

    On Error GoTo ErrHandler
    ResetApplicationState False

    Set wsVal = EnsureSheet(SH_VALIDATION)
    wsVal.Cells.Clear
    wsVal.Range("A1:D1").value = Array("Area", "Check", "Result", "Details")
    StyleHeader wsVal.Range("A1:D1")
    rowOut = 2
    okAll = True

    ValidateSheetExists wsVal, rowOut, SH_IO_INPUT, okAll
    ValidateSheetExists wsVal, rowOut, SH_IO_GEN, okAll
    ValidateSheetExists wsVal, rowOut, SH_PD6, okAll
    ValidateSheetExists wsVal, rowOut, SH_24V, okAll
    ValidateSheetExists wsVal, rowOut, SH_480V, okAll
    ValidateSheetExists wsVal, rowOut, SH_DATA_IO, okAll
    ValidateSheetExists wsVal, rowOut, SH_DATA_PWR, okAll

    ValidateHeader wsVal, rowOut, SH_DATA_IO, "TYPE", okAll
    ValidateHeader wsVal, rowOut, SH_DATA_IO, "DESC", okAll

    ValidateHeader wsVal, rowOut, SH_PD6, "TYPE", okAll
    ValidateHeader wsVal, rowOut, SH_PD6, "SIS_Element_Number", okAll
    ValidateHeader wsVal, rowOut, SH_PD6, "Control_ID", okAll
    ValidateHeader wsVal, rowOut, SH_PD6, "Bus Power", okAll
    ValidateHeader wsVal, rowOut, SH_PD6, "Power Supply", okAll
    ValidateHeader wsVal, rowOut, SH_PD6, "Power BUS-1 Terminal", okAll
    ValidateHeader wsVal, rowOut, SH_PD6, "Power BUS-2 Terminal", okAll
    ValidateHeader wsVal, rowOut, SH_PD6, "PNL", okAll

    ValidateAny24VPanelSheet wsVal, rowOut, okAll

    wsVal.Columns("A:D").AutoFit
    If okAll Then
        AppendLog "Step10_Validate_Workbook", "OK", "Validation passed."
        MsgBox "Validation passed.", vbInformation
    Else
        AppendLog "Step10_Validate_Workbook", "WARN", "Validation has warnings. See VALIDATION sheet."
        MsgBox "Validation found warnings. See the VALIDATION sheet.", vbExclamation
    End If

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    ResetApplicationState True
    AppendLog "Step10_Validate_Workbook", "ERROR", Err.description
    MsgBox "Validation failed: " & Err.description, vbCritical

End Sub

'-------------------------------------------------------------------------------
' Procedure : Step99_Clear_Generated_Data
' Scope/Type: Public Sub
' Purpose   : Clears generated data.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Public Sub Step99_Clear_Generated_Data()

    Dim answer As VbMsgBoxResult
    Dim ws As Worksheet
    Dim namesToDelete As Collection
    Dim nm As Variant

    answer = MsgBox("Clear generated data from IO_DEVICE_LIST, IO_BLOCK_GENERATOR, PD6_IMPORT, 24V panel sheets, and VFD_480V_Generator? DATA sheets will be kept.", vbYesNo + vbQuestion)
    If answer <> vbYes Then Exit Sub

    On Error GoTo ErrHandler
    ResetApplicationState False

    ClearBelowHeader EnsureSheet(SH_IO_INPUT), 1
    ClearBelowHeader EnsureSheet(SH_IO_GEN), 1
    ClearBelowHeader EnsureSheet(SH_PD6), 1
    EnsureSheet(SH_24V).Cells.ClearContents
    EnsureSheet(SH_480V).Cells.ClearContents

    Set namesToDelete = New Collection
    For Each ws In ThisWorkbook.Worksheets
        'Delete only actual generated panel 24V sheets. This protects support/report
        'sheets such as 24V_NOT_GENERATED and 24V_OVERLOAD_TERMINALS.
        If Is24VPanelGeneratorSheet(ws) Then namesToDelete.Add ws.Name
    Next ws

    Application.DisplayAlerts = False
    For Each nm In namesToDelete
        ThisWorkbook.Worksheets(CStr(nm)).Delete
    Next nm
    Application.DisplayAlerts = True

    AppendLog "Step99_Clear_Generated_Data", "OK", "Generated data cleared. DATA sheets kept."
    MsgBox "Generated data cleared. DATA sheets were not changed.", vbInformation

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    ResetApplicationState True
    AppendLog "Step99_Clear_Generated_Data", "ERROR", Err.description
    MsgBox "Clear failed: " & Err.description, vbCritical

End Sub

'-------------------------------------------------------------------------------
' Procedure : Is24VPanelGeneratorSheet
' Scope/Type: Private Function
' Purpose   : Checks whether 24 v panel generator sheet.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function Is24VPanelGeneratorSheet(ByVal ws As Worksheet) As Boolean

    If UCase$(ws.Name) = UCase$(SH_24V) Then
        Is24VPanelGeneratorSheet = False
        Exit Function
    End If

    If Left$(UCase$(ws.Name), 4) <> "24V_" And Right$(UCase$(ws.Name), 4) <> "_24V" Then
        Is24VPanelGeneratorSheet = False
        Exit Function
    End If

    Is24VPanelGeneratorSheet = SheetContains24VHeaders(ws)

End Function

'-------------------------------------------------------------------------------
' Procedure : SheetContains24VHeaders
' Scope/Type: Private Function
' Purpose   : Calculates or returns sheet contains 24 v headers.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function SheetContains24VHeaders(ByVal ws As Worksheet) As Boolean

    Dim lastRow As Long
    Dim r As Long

    lastRow = LastUsedRow(ws)
    If lastRow < 1 Then Exit Function

    For r = 1 To lastRow
        If NormalizeHeader(ws.Cells(r, 1).value) = "PWG" _
        And NormalizeHeader(ws.Cells(r, 2).value) = "BUSPOWER" _
        And NormalizeHeader(ws.Cells(r, 3).value) = "POWERSUPPLY" Then
            SheetContains24VHeaders = True
            Exit Function
        End If
    Next r

End Function

'-------------------------------------------------------------------------------
' Procedure : SheetContains480VHeaders
' Scope/Type: Private Function
' Purpose   : Calculates or returns sheet contains 480 v headers.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function SheetContains480VHeaders(ByVal ws As Worksheet) As Boolean

    SheetContains480VHeaders = _
        NormalizeHeader(ws.Cells(1, 1).value) = "SISELEMENTNUMBER" And _
        NormalizeHeader(ws.Cells(1, 2).value) = "TYPE" And _
        NormalizeHeader(ws.Cells(1, 3).value) = "480VPANEL"

End Function

'-------------------------------------------------------------------------------
' Procedure : GetNextExportWorksheet
' Scope/Type: Private Function
' Purpose   : Returns next export worksheet.
' Parameters:
' wbOut (Workbook) - Supplies workbook out.
' exportIndex (Long) - Supplies export index.
' sourceSheetName (String) - Supplies source sheet name.
' Returns   : Worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function GetNextExportWorksheet(ByVal wbOut As Workbook, ByVal exportIndex As Long, ByVal sourceSheetName As String) As Worksheet

    Dim wsNew As Worksheet
    Dim baseName As String
    Dim tryName As String
    Dim i As Long

    If exportIndex = 1 Then
        Set wsNew = wbOut.Worksheets(1)
    Else
        Set wsNew = wbOut.Worksheets.Add(After:=wbOut.Worksheets(wbOut.Worksheets.count))
    End If

    baseName = SafeSheetName(sourceSheetName)
    tryName = baseName
    i = 1
    Do While ExportWorkbookSheetExists(wbOut, tryName, wsNew)
        i = i + 1
        tryName = Left$(baseName, 28) & "_" & Format$(i, "00")
    Loop

    wsNew.Name = tryName
    Set GetNextExportWorksheet = wsNew

End Function

'-------------------------------------------------------------------------------
' Procedure : ExportWorkbookSheetExists
' Scope/Type: Private Function
' Purpose   : Exports workbook sheet exists.
' Parameters:
' wbOut (Workbook) - Supplies workbook out.
' sheetName (String) - Supplies sheet name.
' ignoreSheet (Worksheet) - Supplies ignore sheet.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function ExportWorkbookSheetExists(ByVal wbOut As Workbook, ByVal sheetName As String, ByVal ignoreSheet As Worksheet) As Boolean

    Dim ws As Worksheet

    For Each ws In wbOut.Worksheets
        If Not ws Is ignoreSheet Then
            If UCase$(Trim$(ws.Name)) = UCase$(Trim$(sheetName)) Then
                ExportWorkbookSheetExists = True
                Exit Function
            End If
        End If
    Next ws

End Function

'-------------------------------------------------------------------------------
' Procedure : CopyGeneratorRangeWithFormat
' Scope/Type: Private Sub
' Purpose   : Copies generator range with format.
' Parameters:
' wsSource (Worksheet) - Supplies worksheet source.
' wsTarget (Worksheet) - Supplies worksheet target.
' LastRow (Long) - Supplies last row.
' colCount (Long) - Supplies column count.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub CopyGeneratorRangeWithFormat(ByVal wsSource As Worksheet, ByVal wsTarget As Worksheet, ByVal lastRow As Long, ByVal colCount As Long)

    Dim srcRng As Range
    Dim dstRng As Range
    Dim c As Long

    If lastRow < 1 Then lastRow = 1
    If colCount < 1 Then colCount = 1

    Set srcRng = wsSource.Range(wsSource.Cells(1, 1), wsSource.Cells(lastRow, colCount))
    Set dstRng = wsTarget.Range("A1").Resize(lastRow, colCount)

    srcRng.Copy
    dstRng.PasteSpecial Paste:=xlPasteValuesAndNumberFormats
    dstRng.PasteSpecial Paste:=xlPasteFormats
    Application.CutCopyMode = False

    For c = 1 To colCount
        wsTarget.Columns(c).columnWidth = wsSource.Columns(c).columnWidth
    Next c

End Sub

'-------------------------------------------------------------------------------
' Procedure : ValidateAny24VPanelSheet
' Scope/Type: Private Sub
' Purpose   : Validates any 24 v panel sheet.
' Parameters:
' wsVal (Worksheet) - Supplies worksheet value.
' rowOut (Long) - Supplies row out.
' okAll (Boolean) - Supplies ok all.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub ValidateAny24VPanelSheet(ByVal wsVal As Worksheet, ByRef rowOut As Long, ByRef okAll As Boolean)

    Dim ws As Worksheet
    Dim cnt As Long

    For Each ws In ThisWorkbook.Worksheets
        If Is24VPanelGeneratorSheet(ws) Then cnt = cnt + 1
    Next ws

    wsVal.Cells(rowOut, 1).value = "24V"
    wsVal.Cells(rowOut, 2).value = "Panel-specific 24V sheets"
    If cnt > 0 Then
        wsVal.Cells(rowOut, 3).value = "OK"
        wsVal.Cells(rowOut, 4).value = CStr(cnt) & " sheet(s) found."
    Else
        wsVal.Cells(rowOut, 3).value = "MISSING"
        wsVal.Cells(rowOut, 4).value = "Run Step07 to create sheets like 24v_RCP101."
        okAll = False
    End If
    rowOut = rowOut + 1

End Sub

'-------------------------------------------------------------------------------
' Procedure : ClearBelowHeader
' Scope/Type: Private Sub
' Purpose   : Clears below header.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' headerRow (Long) - Supplies header row.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub ClearBelowHeader(ByVal ws As Worksheet, ByVal headerRow As Long)

    If LastUsedRow(ws) > headerRow Then
        ws.rows((headerRow + 1) & ":" & ws.rows.count).ClearContents
    End If

End Sub

'-------------------------------------------------------------------------------
' Procedure : ValidateSheetExists
' Scope/Type: Private Sub
' Purpose   : Validates sheet exists.
' Parameters:
' wsVal (Worksheet) - Supplies worksheet value.
' rowOut (Long) - Supplies row out.
' sheetName (String) - Supplies sheet name.
' okAll (Boolean) - Supplies ok all.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub ValidateSheetExists(ByVal wsVal As Worksheet, ByRef rowOut As Long, ByVal sheetName As String, ByRef okAll As Boolean)

    wsVal.Cells(rowOut, 1).value = "Sheet"
    wsVal.Cells(rowOut, 2).value = sheetName & " exists"
    If WorksheetExists(sheetName) Then
        wsVal.Cells(rowOut, 3).value = "OK"
        wsVal.Cells(rowOut, 4).value = "Found"
    Else
        wsVal.Cells(rowOut, 3).value = "MISSING"
        wsVal.Cells(rowOut, 4).value = "Create or restore this sheet."
        okAll = False
    End If
    rowOut = rowOut + 1

End Sub

'-------------------------------------------------------------------------------
' Procedure : ValidateHeader
' Scope/Type: Private Sub
' Purpose   : Validates header.
' Parameters:
' wsVal (Worksheet) - Supplies worksheet value.
' rowOut (Long) - Supplies row out.
' sheetName (String) - Supplies sheet name.
' headerName (String) - Supplies header name.
' okAll (Boolean) - Supplies ok all.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub ValidateHeader(ByVal wsVal As Worksheet, ByRef rowOut As Long, ByVal sheetName As String, ByVal headerName As String, ByRef okAll As Boolean)

    Dim ws As Worksheet
    Set ws = GetSheetIfExists(sheetName)
    wsVal.Cells(rowOut, 1).value = "Header"
    wsVal.Cells(rowOut, 2).value = sheetName & " / " & headerName
    If ws Is Nothing Then
        wsVal.Cells(rowOut, 3).value = "SKIP"
        wsVal.Cells(rowOut, 4).value = "Sheet missing"
        okAll = False
    ElseIf HeaderCol(ws, headerName) > 0 Then
        wsVal.Cells(rowOut, 3).value = "OK"
        wsVal.Cells(rowOut, 4).value = "Found column " & HeaderCol(ws, headerName)
    Else
        wsVal.Cells(rowOut, 3).value = "MISSING"
        wsVal.Cells(rowOut, 4).value = "Required header not found on row 1."
        okAll = False
    End If
    rowOut = rowOut + 1

End Sub

