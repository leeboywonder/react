Attribute VB_Name = "mod00_ONGEN_UI_Workflow_Manager"
Option Explicit

'===============================================================================
' ONGEN EAS - FINAL UI WORKFLOW MANAGER
' Author: Lee Pierre, Principal Electrical Engineer
'
' PURPOSE
'   Keeps the MAIN worksheet button assignments aligned with the production
'   workflow without stacking repair/installer modules.
'
' IMPORTANT
'   - Existing Phase 0-6 buttons remain owned by the workbook's current UI
'     builder (mod00_UI_Buttons_ProgressBar).
'   - This module audits the 43 existing buttons found in V26.3.
'   - It permanently rebinds the VFD/release buttons to the clean workflow.
'   - It creates the missing final clear button when it is not present.

'   - It installs 0B Sheet Launcher immediately beside 0C Workflow Guide.
'===============================================================================

Private Const MAIN_SHEET As String = "MAIN"
Private Const AUDIT_SHEET As String = "UI_BUTTON_AUDIT"

'Run this once after importing the clean V26.3 modules.
Public Sub ONGEN_UI_ALIGN_COMPLETE_WORKFLOW()
    On Error GoTo FailHandler

    Dim wsMain As Worksheet
    Set wsMain = ThisWorkbook.Worksheets(MAIN_SHEET)

    'Rebind only the workflow points whose production owner changed during the
    'VFD / cable-tag cleanup. Other buttons keep their existing stable macros.
    UI_RebindAction wsMain, "BTN_VFD_Build_And_Refresh", "ONGEN_VFD_BUILD_AND_REFRESH"
    UI_RebindAction wsMain, "BTN_VFD_Refresh_Queue", "ONGEN_VFD_REFRESH_QUEUE"
    UI_RebindAction wsMain, "BTN_VFD_Rebuild_Queue", "ONGEN_VFD_REBUILD_FROM_PLAN"
    UI_RebindAction wsMain, "BTN_Build_All_Cable_Tags", "ONGEN_STEP15H_BUILD_ALL_CABLE_TAGS"
    UI_RebindAction wsMain, "BTN_Export_Label_List_Report", "ONGEN_STEP17_EXPORT_LABEL_REPORT"

    'The V26.3 drawing contains the Phase 6 release buttons but no physical
    'Final Clear button assignment. Add one safely when absent.
    UI_EnsureSafeClearButton wsMain

    'Install the final Phase 0 Sheet Launcher.
    'Navigation is owned by mod00_ONGEN_Navigation_UI and uses the existing
    'searchable frmPDLauncher UserForm. No worksheet-based navigator is used.
    'Navigation installation is independent of button rebinding.
    'A cosmetic/navigation issue must not prevent Step 17 and other workflow
    'buttons from being aligned.
    On Error Resume Next
    ONGEN_INSTALL_NAVIGATION_UI
    On Error GoTo FailHandler

    ONGEN_UI_AUDIT_WORKFLOW_BUTTONS

    MsgBox _
        "ONGEN workflow buttons are aligned." & vbCrLf & vbCrLf & _
        "15B -> ONGEN_VFD_BUILD_AND_REFRESH" & vbCrLf & _
        "15C -> ONGEN_VFD_REFRESH_QUEUE" & vbCrLf & _
        "15D -> ONGEN_VFD_REBUILD_FROM_PLAN" & vbCrLf & _
        "15H -> ONGEN_STEP15H_BUILD_ALL_CABLE_TAGS" & vbCrLf & _
        "17  -> ONGEN_STEP17_EXPORT_LABEL_REPORT" & vbCrLf & _
        "18  -> ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE", _
        vbInformation, "ONGEN UI Workflow"
    Exit Sub

FailHandler:
    MsgBox "UI workflow alignment failed." & vbCrLf & _
           "Error " & CStr(Err.Number) & ": " & Err.description, _
           vbCritical, "ONGEN UI Workflow"
End Sub

'Writes a non-destructive audit to UI_BUTTON_AUDIT.
Public Sub ONGEN_UI_AUDIT_WORKFLOW_BUTTONS()
    On Error GoTo FailHandler

    Dim wsMain As Worksheet
    Dim wsAudit As Worksheet
    Set wsMain = ThisWorkbook.Worksheets(MAIN_SHEET)
    Set wsAudit = UI_GetOrCreateSheet(AUDIT_SHEET)

    wsAudit.Cells.Clear
    wsAudit.Range("A1:F1").value = Array( _
        "Expected Macro", "Found", "Shape Name", "Caption", "Assigned Macro", "Status")

    Dim expected As Variant
    expected = UI_ExpectedMacros()

    Dim outRow As Long
    outRow = 2

    Dim i As Long
    Dim shp As Shape
    Dim assigned As String
    Dim caption As String
    Dim foundCount As Long

    For i = LBound(expected) To UBound(expected)
        foundCount = 0

        For Each shp In wsMain.Shapes
            assigned = UI_NormalizeMacroName(shp.OnAction)
            If StrComp(assigned, CStr(expected(i)), vbTextCompare) = 0 Then
                foundCount = foundCount + 1
                caption = UI_ShapeCaption(shp)

                wsAudit.Cells(outRow, 1).Value2 = CStr(expected(i))
                wsAudit.Cells(outRow, 2).Value2 = foundCount
                wsAudit.Cells(outRow, 3).Value2 = shp.Name
                wsAudit.Cells(outRow, 4).Value2 = caption
                wsAudit.Cells(outRow, 5).Value2 = assigned
                wsAudit.Cells(outRow, 6).Value2 = "OK"
                outRow = outRow + 1
            End If
        Next shp

        If foundCount = 0 Then
            wsAudit.Cells(outRow, 1).Value2 = CStr(expected(i))
            wsAudit.Cells(outRow, 2).Value2 = 0
            wsAudit.Cells(outRow, 6).Value2 = "MISSING / REPLACED"
            outRow = outRow + 1
        End If
    Next i

    wsAudit.rows(1).Font.Bold = True
    wsAudit.Columns("A:F").AutoFit
    wsAudit.Visible = xlSheetVisible
    Exit Sub

FailHandler:
    MsgBox "UI button audit failed: " & Err.description, vbExclamation, "ONGEN UI Audit"
End Sub

'Ensures the current premium MAIN sheet exists before alignment.
'If a future template loses the MAIN controls, the existing released UI builder
'is called once and then the clean bindings are reapplied.
Public Sub ONGEN_UI_ENSURE_ALL_WORKFLOW_BUTTONS()
    On Error GoTo FailHandler

    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(MAIN_SHEET)

    If ws.Shapes.count < 30 Then
        Application.Run "'" & ThisWorkbook.Name & "'!Step00_Create_MAIN_Buttons_And_ProgressBar"
    End If

    ONGEN_UI_ALIGN_COMPLETE_WORKFLOW
    Exit Sub

FailHandler:
    MsgBox "Could not ensure the MAIN workflow UI." & vbCrLf & _
           Err.description, vbCritical, "ONGEN UI Workflow"
End Sub

Private Sub UI_RebindAction(ByVal ws As Worksheet, ByVal oldMacro As String, ByVal newMacro As String)
    Dim shp As Shape
    Dim currentMacro As String

    For Each shp In ws.Shapes
        currentMacro = UI_NormalizeMacroName(shp.OnAction)

        If StrComp(currentMacro, oldMacro, vbTextCompare) = 0 Or _
           StrComp(currentMacro, newMacro, vbTextCompare) = 0 Then

            shp.OnAction = UI_QualifiedMacro(newMacro)
        End If
    Next shp
End Sub

Private Sub UI_EnsureSafeClearButton(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim macroName As String

    For Each shp In ws.Shapes
        macroName = UI_NormalizeMacroName(shp.OnAction)
        If StrComp(macroName, "ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE", vbTextCompare) = 0 Then Exit Sub
        If StrComp(macroName, "BTN_Run_Step99", vbTextCompare) = 0 Then
            shp.OnAction = UI_QualifiedMacro("ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE")
            Exit Sub
        End If
    Next shp

    'Place the clear button near the right side of the Phase 6 band. Position is
    'derived from the existing Validation/Log button when possible.
    Dim anchor As Shape
    For Each shp In ws.Shapes
        If StrComp(UI_NormalizeMacroName(shp.OnAction), "BTN_Open_Validation_Sheet", vbTextCompare) = 0 Then
            Set anchor = shp
            Exit For
        End If
    Next shp

    Dim leftPos As Double, topPos As Double, widthVal As Double, heightVal As Double
    If anchor Is Nothing Then
        leftPos = 810: topPos = 690: widthVal = 145: heightVal = 38
    Else
        leftPos = anchor.Left + anchor.Width + 12
        topPos = anchor.Top
        widthVal = anchor.Width
        heightVal = anchor.Height
    End If

    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPos, topPos, widthVal, heightVal)
    shp.Name = "ONGEN_BTN_FINAL_CLEAR_SAFE"
    shp.TextFrame2.TextRange.text = "18 Final Clear Data"
    shp.OnAction = UI_QualifiedMacro("ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE")
    shp.Fill.ForeColor.RGB = RGB(158, 39, 28)
    shp.Line.ForeColor.RGB = RGB(120, 28, 20)
    shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
    shp.TextFrame2.TextRange.Font.Bold = msoTrue
    shp.TextFrame2.TextRange.Font.Size = 9
End Sub



Private Function UI_ExpectedMacros() As Variant
    UI_ExpectedMacros = Array( _
        "BTN_Open_Workflow_Guide", "BTN_Refresh_All_Workbook", _
        "BTN_Run_Step01", "BTN_Run_Step02", "BTN_Run_Step03", "BTN_Run_Step04", _
        "BTN_Run_Beckhoff_IO_Workflow", "BTN_Run_Step05", "BTN_Run_PD6_Ensure_Headers", _
        "BTN_Run_PD6_Recalculate", "BTN_Run_PD6_Backfill", "BTN_Run_PD6_Reassign", _
        "BTN_Run_PD6_Coordinate_Import", "BTN_Run_PD6_Network_Kx_Backfill", _
        "BTN_Run_Step05G_Power_Kx_Sync_UI", "BTN_Run_Step06", "BTN_Run_Step07", _
        "BTN_Run_Step08", "BTN_Run_Step09", "BTN_Run_Refresh_Missing_PSU", _
        "BTN_Run_Recheck_Step10A_Audit", "BTN_Run_Power_Workflow", "BTN_Run_Step11", _
        "BTN_Run_Step11B", "BTN_Run_Step12", "BTN_Run_Step12A", "BTN_Run_Step13", _
        "BTN_Enforce_RIO_IOS_Grouping", "BTN_Run_Network_RCP_Workflow", _
        "BTN_Run_Auto_Network_RCP_Workflow", "BTN_VFD_Install_Workflow", _
        "ONGEN_VFD_BUILD_AND_REFRESH", "ONGEN_VFD_REFRESH_QUEUE", _
        "ONGEN_VFD_REBUILD_FROM_PLAN", "BTN_VFD_Open_Queue", "BTN_VFD_Open_Sheet_Plan", _
        "BTN_VFD_Backfill_Network", "ONGEN_STEP15H_BUILD_ALL_CABLE_TAGS", _
        "BTN_VFD_Export_480V_Queue", "BTN_VFD_Add_Device", "BTN_Run_Step10", _
        "ONGEN_STEP17_EXPORT_LABEL_REPORT", "BTN_Open_Validation_Sheet", _
        "ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE", "NAV_Open_Worksheet_Launcher")
End Function

Private Function UI_QualifiedMacro(ByVal macroName As String) As String
    UI_QualifiedMacro = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function

Private Function UI_NormalizeMacroName(ByVal actionName As String) As String
    Dim s As String
    s = Trim$(actionName)
    If InStrRev(s, "!") > 0 Then s = mid$(s, InStrRev(s, "!") + 1)
    s = Replace$(s, "'", "")
    UI_NormalizeMacroName = Trim$(s)
End Function

Private Function UI_ShapeCaption(ByVal shp As Shape) As String
    On Error Resume Next
    UI_ShapeCaption = shp.TextFrame2.TextRange.text
    If Len(UI_ShapeCaption) = 0 Then UI_ShapeCaption = shp.TextFrame.Characters.text
    On Error GoTo 0
End Function

Private Function UI_GetOrCreateSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set UI_GetOrCreateSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0

    If UI_GetOrCreateSheet Is Nothing Then
        Set UI_GetOrCreateSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        UI_GetOrCreateSheet.Name = sheetName
    End If
End Function
