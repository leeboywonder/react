Attribute VB_Name = "create_clean_PNL"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : create_clean_PNL
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.2.4-STEP12-OPTIONAL-AREA-NO-DUPLICATE
' Module        : create_clean_PNL
' Audit Date    : 2026-07-27
' Owner         : Lee Pierre, Principal Electrical Engineer
' Purpose       : Restores the established RCP clean-sheet transformation,
'                 honors overwrite/missing-only mode, and treats Area as an
'                 optional prefix without creating duplicate area numbers.
'-------------------------------------------------------------------------------
Option Explicit

Private Const CLEAN_DATA_SHEET As String = "DATA"

Public Sub Create_All_RCP_Clean_Sheets()
    Dim wb As Workbook
    Dim areaWS As Worksheet
    Dim ws As Worksheet
    Dim cleanWS As Worksheet
    Dim srcWS As Worksheet
    Dim sourceNames As Collection
    Dim sourceName As Variant
    Dim areaCol As Long
    Dim areaNumber As String
    Dim cleanName As String
    Dim lastRow As Long
    Dim lastCol As Long
    Dim r As Long
    Dim c As Long
    Dim outRow As Long
    Dim portHeader As String
    Dim cellValue As String
    Dim sisNumber As String
    Dim controlTag As String
    Dim deviceText As String
    Dim wrotePort As Boolean
    Dim mode As Long
    Dim createdCount As Long
    Dim overwrittenCount As Long
    Dim skippedCount As Long
    Dim oldAlerts As Boolean
    Dim oldScreen As Boolean
    Dim oldEvents As Boolean
    Dim savedErrNumber As Long
    Dim savedErrDescription As String

    On Error GoTo ErrHandler

    Set wb = ThisWorkbook
    EnsureCleanDataLookupSheet wb

    ' Area is optional. When supplied, it is used only when the source network
    ' value does not already begin with the same area number.
    areaNumber = vbNullString
    Set areaWS = Nothing
    On Error Resume Next
    Set areaWS = wb.Worksheets("Area")
    On Error GoTo ErrHandler

    If Not areaWS Is Nothing Then
        areaCol = FindHeaderColumn(areaWS, "Area Number", 1)
        If areaCol > 0 Then areaNumber = Trim$(CStr(areaWS.Cells(2, areaCol).value))
    End If

    mode = ONGEN_GetGenerationMode()
    If mode <> ONGEN_GEN_OVERWRITE And mode <> ONGEN_GEN_MISSING_ONLY Then mode = ONGEN_GEN_MISSING_ONLY

    Set sourceNames = New Collection
    For Each ws In wb.Worksheets
        If IsRawRCPTopologySheet(ws.Name) Then sourceNames.Add ws.Name
    Next ws

    If sourceNames.count = 0 Then
        MsgBox "No raw RCP topology worksheets were found." & vbCrLf & _
               "Run Step 11 or Step 11B before Step 12.", vbExclamation, "Step 12 - No RCP Inputs"
        Exit Sub
    End If

    oldAlerts = Application.DisplayAlerts
    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    Application.DisplayAlerts = False
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    For Each sourceName In sourceNames
        Set srcWS = wb.Worksheets(CStr(sourceName))
        cleanName = SafeSheetName(srcWS.Name & " - Clean")

        If WorksheetExists(cleanName, wb) Then
            If mode = ONGEN_GEN_MISSING_ONLY Then
                skippedCount = skippedCount + 1
                GoTo ContinueSource
            End If
            wb.Worksheets(cleanName).Delete
            overwrittenCount = overwrittenCount + 1
        End If

        Set cleanWS = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        cleanWS.Name = cleanName
        WriteCleanHeaders cleanWS
        outRow = 2

        lastRow = LastUsedRow(srcWS)
        lastCol = LastUsedCol(srcWS)

        For c = 1 To lastCol
            portHeader = NormalizePortHeader(CStr(srcWS.Cells(1, c).value))
            If IsXPortHeader(portHeader) Then
                wrotePort = False
                For r = 3 To lastRow
                    cellValue = Trim$(CStr(srcWS.Cells(r, c).value))
                    If Len(cellValue) > 0 Then
                        sisNumber = BuildSISNumber(cellValue, areaNumber)
                        controlTag = ExtractControlTag(cellValue)
                        deviceText = ExtractDevice(cellValue)

                        If Len(sisNumber) > 0 Or Len(controlTag) > 0 Or Len(deviceText) > 0 Then
                            If Not wrotePort Then
                                cleanWS.Cells(outRow, 1).value = portHeader
                                wrotePort = True
                            End If
                            cleanWS.Cells(outRow, 2).value = sisNumber
                            cleanWS.Cells(outRow, 3).value = controlTag
                            cleanWS.Cells(outRow, 4).value = deviceText
                            outRow = outRow + 1
                        End If
                    End If
                Next r
            End If
        Next c

        ApplyCleanSheetLookupFormulas cleanWS, outRow - 1
        ApplyEstablishedCleanSheetFormat cleanWS, outRow - 1
        createdCount = createdCount + 1

ContinueSource:
        Set cleanWS = Nothing
        Set srcWS = Nothing
    Next sourceName

    Application.DisplayAlerts = oldAlerts
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents

    MsgBox "Step 12 completed using the established RCP clean-sheet format." & vbCrLf & vbCrLf & _
           "Clean sheets created: " & createdCount & vbCrLf & _
           "Existing clean sheets overwritten: " & overwrittenCount & vbCrLf & _
           "Existing clean sheets preserved: " & skippedCount, vbInformation, "Step 12 - RCP Clean Sheets"
    Exit Sub

ErrHandler:
    savedErrNumber = Err.Number
    savedErrDescription = Err.description
    On Error Resume Next
    Application.DisplayAlerts = oldAlerts
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents
    On Error GoTo 0
    MsgBox "Step 12 could not create the RCP clean sheets." & vbCrLf & vbCrLf & _
           "Error " & savedErrNumber & ": " & savedErrDescription, vbCritical, "Step 12 Error"
End Sub

Public Sub Refresh_All_RCP_Clean_Sheet_Formulas()
    Dim ws As Worksheet
    Dim refreshedCount As Long
    Dim lastRow As Long
    Dim oldScreen As Boolean
    Dim oldEvents As Boolean

    On Error GoTo ErrHandler
    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    EnsureCleanDataLookupSheet ThisWorkbook

    For Each ws In ThisWorkbook.Worksheets
        If IsCleanSheet(ws.Name) Then
            lastRow = LastUsedRow(ws)
            ApplyCleanSheetLookupFormulas ws, lastRow
            ApplyEstablishedCleanSheetFormat ws, lastRow
            refreshedCount = refreshedCount + 1
        End If
    Next ws

    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    MsgBox refreshedCount & " RCP clean sheet(s) refreshed with DATA lookup formulas.", vbInformation, "Step 12A - Refresh Complete"
    Exit Sub

ErrHandler:
    On Error Resume Next
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0
    MsgBox "Failed to refresh RCP clean sheet formulas." & vbCrLf & Err.description, vbCritical, "Step 12A Error"
End Sub

Private Sub ApplyCleanSheetLookupFormulas(ByVal ws As Worksheet, ByVal lastDataRow As Long)
    Dim q As String
    WriteCleanHeaders ws
    If lastDataRow < 2 Then Exit Sub

    q = Chr$(34) & Chr$(34)
    ws.Range("E2:E" & lastDataRow).Formula = _
        "=IFERROR(INDEX(DATA!$G:$G,MATCH($D2,DATA!$F:$F,0))," & _
        "IFERROR(INDEX(DATA!$A:$A,MATCH($D2,DATA!$A:$A,0))," & q & "))"

    ws.Range("F2:F" & lastDataRow).Formula = _
        "=IF($E2=" & q & "," & q & "," & _
        "IFERROR(INDEX(DATA!$B:$B,MATCH($E2,DATA!$A:$A,0))," & _
        "IFERROR(INDEX(DATA!$H:$H,MATCH($E2,DATA!$G:$G,0))," & q & ")))"

    ws.Range("G2:G" & lastDataRow).Formula = _
        "=IF($E2=" & q & "," & q & "," & _
        "IFERROR(INDEX(DATA!$C:$C,MATCH($E2,DATA!$A:$A,0))," & _
        "IFERROR(INDEX(DATA!$I:$I,MATCH($E2,DATA!$G:$G,0))," & q & ")))"

    ws.Range("H2:H" & lastDataRow).Formula = _
        "=IF($E2=" & q & "," & q & "," & _
        "IFERROR(INDEX(DATA!$D:$D,MATCH($E2,DATA!$A:$A,0))," & _
        "IFERROR(INDEX(DATA!$J:$J,MATCH($E2,DATA!$G:$G,0))," & q & ")))"

    ws.Calculate
End Sub

Private Sub ApplyEstablishedCleanSheetFormat(ByVal ws As Worksheet, ByVal lastDataRow As Long)
    With ws.Range("A1:H1")
        .Font.Bold = True
        .Font.Color = vbWhite
        .Interior.Color = RGB(31, 78, 121)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With

    If lastDataRow >= 2 Then
        With ws.Range("A2:H" & lastDataRow)
            .VerticalAlignment = xlCenter
            .Borders.LineStyle = xlContinuous
            .Borders.Weight = xlThin
        End With
        ws.Range("E2:H" & lastDataRow).Interior.Color = RGB(234, 244, 255)
    End If

    ws.Columns("A:H").AutoFit
    If ws.Columns("A").columnWidth < 12 Then ws.Columns("A").columnWidth = 12
    If ws.Columns("B").columnWidth < 22 Then ws.Columns("B").columnWidth = 22
    If ws.Columns("C").columnWidth < 12 Then ws.Columns("C").columnWidth = 12
    If ws.Columns("D").columnWidth < 24 Then ws.Columns("D").columnWidth = 24
    If ws.Columns("E").columnWidth < 12 Then ws.Columns("E").columnWidth = 12
    If ws.Columns("F").columnWidth < 22 Then ws.Columns("F").columnWidth = 22
    If ws.Columns("G").columnWidth < 16 Then ws.Columns("G").columnWidth = 16
    If ws.Columns("H").columnWidth < 16 Then ws.Columns("H").columnWidth = 16
    ws.rows(1).RowHeight = 22
    ws.Range("A1:H1").AutoFilter
    ws.Activate
    ActiveWindow.FreezePanes = False
    ws.Range("A2").Select
    ActiveWindow.FreezePanes = True
End Sub

Private Sub EnsureCleanDataLookupSheet(ByVal wb As Workbook)
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets(CLEAN_DATA_SHEET)
    On Error GoTo 0

    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ws.Name = CLEAN_DATA_SHEET
    End If

    EnsureCleanDataHeaders ws
    EnsureTypeMapRow ws, "IO_D", "HDV1T6_IO_D", "X4TERM01", "X1TERM02"
    EnsureTypeMapRow ws, "SWT", "HDV1_001_CU2508", "X4TERM01", ""
    EnsureTypeMapRow ws, "MC", "HDV1T6_MC", "X4TERM01", "X1TERM02"
    EnsureTypeMapRow ws, "VFD_MC", "HDV1T6-VFD_MC", "X4TERM01", "X1TERM02"
    EnsureTypeMapRow ws, "SCN", "HDV1T6_GENERIC", "X4TERM01", "X1TERM02"
    EnsureTypeMapRow ws, "RACK", "HDV1_001_EK1100", "X3TERM01", "X3TERM02"
    EnsureTypeMapRow ws, "IO_S", "HDV1T6_IO_S", "X4TERM01", "X1TERM02"
    EnsureTypeMapRow ws, "VFD_MF", "HDV1T6-VFD_MF", "X4TERM01", "X1TERM02"
    EnsureTypeMapRow ws, "PNL", "HDV1_001_CU2508", "X4TERM01", "X1TERM02"

    EnsureDeviceMapRow ws, "EK1100", "RACK", "HDV1_001_EK1100", "X3TERM01", "X3TERM02"
    EnsureDeviceMapRow ws, "MultiControl EtherCAT", "MC", "HDV1T6_MC", "X4TERM01", "X1TERM02"
    EnsureDeviceMapRow ws, "EP2339-0042", "IO_D", "HDV1T6_IO_D", "X4TERM01", "X1TERM02"
    EnsureDeviceMapRow ws, "EP1957-0022", "IO_S", "HDV1T6_IO_S", "X4TERM01", "X1TERM02"
    EnsureDeviceMapRow ws, "MOVIMOT+MFE72A", "VFD_MC", "HDV1T6-VFD_MC", "X4TERM01", "X1TERM02"
    EnsureDeviceMapRow ws, "Scanner CDF600-x3xx", "SCN", "HDV1T6_GENERIC", "X4TERM01", "X1TERM02"
    EnsureDeviceMapRow ws, "MOVI-C Decentralized Electronics", "VFD_MF", "HDV1T6-VFD_MF", "X4TERM01", "X1TERM02"
    EnsureDeviceMapRow ws, "spareInField MultiControl EtherCAT", "MC", "HDV1T6_MC", "X4TERM01", "X1TERM02"
    EnsureDeviceMapRow ws, "RIO", "PNL", "HDV1_001_CU2508", "X4TERM01", "X1TERM02"

    With ws.Range("A1:D1,F4:J4")
        .Font.Bold = True
        .Font.Color = vbWhite
        .Interior.Color = RGB(31, 78, 121)
    End With
    ws.Columns("A:J").AutoFit
End Sub

Private Sub EnsureCleanDataHeaders(ByVal ws As Worksheet)
    If Len(Trim$(CStr(ws.Range("A1").value))) = 0 Then ws.Range("A1").value = "Device Type"
    If Len(Trim$(CStr(ws.Range("B1").value))) = 0 Then ws.Range("B1").value = "Block"
    If Len(Trim$(CStr(ws.Range("C1").value))) = 0 Then ws.Range("C1").value = "Terminal (IN)"
    If Len(Trim$(CStr(ws.Range("D1").value))) = 0 Then ws.Range("D1").value = "Terminal (OUT)"
    If Len(Trim$(CStr(ws.Range("F4").value))) = 0 Then ws.Range("F4").value = "control Device"
    If Len(Trim$(CStr(ws.Range("G4").value))) = 0 Then ws.Range("G4").value = "Device Type"
    If Len(Trim$(CStr(ws.Range("H4").value))) = 0 Then ws.Range("H4").value = "Block"
    If Len(Trim$(CStr(ws.Range("I4").value))) = 0 Then ws.Range("I4").value = "Terminal (IN)"
    If Len(Trim$(CStr(ws.Range("J4").value))) = 0 Then ws.Range("J4").value = "Terminal (OUT)"
End Sub

Private Sub EnsureTypeMapRow(ByVal ws As Worksheet, ByVal deviceType As String, ByVal blockName As String, ByVal termIn As String, ByVal termOut As String)
    Dim rowNum As Long
    rowNum = FindExactInColumn(ws, deviceType, 1, 2)
    If rowNum = 0 Then rowNum = NextFreeRowInColumn(ws, 1, 2)
    ws.Cells(rowNum, 1).value = deviceType
    ws.Cells(rowNum, 2).value = blockName
    ws.Cells(rowNum, 3).value = termIn
    ws.Cells(rowNum, 4).value = termOut
End Sub

Private Sub EnsureDeviceMapRow(ByVal ws As Worksheet, ByVal deviceDesc As String, ByVal deviceType As String, ByVal blockName As String, ByVal termIn As String, ByVal termOut As String)
    Dim rowNum As Long
    rowNum = FindExactInColumn(ws, deviceDesc, 6, 5)
    If rowNum = 0 Then rowNum = NextFreeRowInColumn(ws, 6, 5)
    ws.Cells(rowNum, 6).value = deviceDesc
    ws.Cells(rowNum, 7).value = deviceType
    ws.Cells(rowNum, 8).value = blockName
    ws.Cells(rowNum, 9).value = termIn
    ws.Cells(rowNum, 10).value = termOut
End Sub

Private Function FindExactInColumn(ByVal ws As Worksheet, ByVal findText As String, ByVal colNum As Long, ByVal startRow As Long) As Long
    Dim lastRow As Long, r As Long
    lastRow = LastUsedRow(ws)
    If lastRow < startRow Then Exit Function
    For r = startRow To lastRow
        If UCase$(Trim$(CStr(ws.Cells(r, colNum).value))) = UCase$(Trim$(findText)) Then
            FindExactInColumn = r
            Exit Function
        End If
    Next r
End Function

Private Function NextFreeRowInColumn(ByVal ws As Worksheet, ByVal colNum As Long, ByVal minimumRow As Long) As Long
    Dim rowNum As Long
    rowNum = ws.Cells(ws.rows.count, colNum).End(xlUp).Row + 1
    If rowNum < minimumRow Then rowNum = minimumRow
    NextFreeRowInColumn = rowNum
End Function

Private Sub WriteCleanHeaders(ByVal ws As Worksheet)
    ws.Cells(1, 1).value = "Switch Port"
    ws.Cells(1, 2).value = "SIS Number"
    ws.Cells(1, 3).value = "Control Tag"
    ws.Cells(1, 4).value = "Device"
    ws.Cells(1, 5).value = "TYPE"
    ws.Cells(1, 6).value = "Block"
    ws.Cells(1, 7).value = "Terminal (IN)"
    ws.Cells(1, 8).value = "Terminal (OUT)"
End Sub

Private Function IsRawRCPTopologySheet(ByVal sheetName As String) As Boolean
    Dim n As String
    n = UCase$(Trim$(sheetName))
    If Left$(n, 4) <> "RCP-" Then Exit Function
    If Right$(n, 4) = "_24V" Then Exit Function
    If Right$(n, 8) = " - CLEAN" Then Exit Function
    IsRawRCPTopologySheet = True
End Function

Private Function IsCleanSheet(ByVal sheetName As String) As Boolean
    IsCleanSheet = (Right$(UCase$(Trim$(sheetName)), 8) = " - CLEAN")
End Function

Private Function FindHeaderColumn(ByVal ws As Worksheet, ByVal headerText As String, Optional ByVal headerRow As Long = 1) As Long
    Dim c As Long
    For c = 1 To LastUsedCol(ws)
        If UCase$(Trim$(CStr(ws.Cells(headerRow, c).value))) = UCase$(headerText) Then
            FindHeaderColumn = c
            Exit Function
        End If
    Next c
End Function

Private Function LastUsedRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find("*", , xlFormulas, xlPart, xlByRows, xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then LastUsedRow = 1 Else LastUsedRow = f.Row
End Function

Private Function LastUsedCol(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find("*", , xlFormulas, xlPart, xlByColumns, xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then LastUsedCol = 1 Else LastUsedCol = f.Column
End Function

Private Function NormalizePortHeader(ByVal txt As String) As String
    NormalizePortHeader = UCase$(Replace(Trim$(txt), " ", ""))
End Function

Private Function IsXPortHeader(ByVal txt As String) As Boolean
    Dim i As Long, ch As String
    txt = NormalizePortHeader(txt)
    If Len(txt) < 2 Then Exit Function
    If Left$(txt, 1) <> "X" Then Exit Function
    For i = 2 To Len(txt)
        ch = mid$(txt, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i
    IsXPortHeader = True
End Function

Private Function BuildSISNumber(ByVal src As String, ByVal areaNumber As String) As String
    Dim coreText As String
    Dim parts() As String
    Dim tokens As Collection
    Dim i As Long
    Dim token As String
    Dim result As String
    Dim firstToken As String
    Dim normalizedArea As String

    coreText = RemoveBracketParts(src)
    coreText = Replace(coreText, "-", "_")
    coreText = CleanUnderscores(coreText)
    If Len(coreText) = 0 Then Exit Function

    normalizedArea = Trim$(areaNumber)
    Set tokens = New Collection
    parts = Split(coreText, "_")

    For i = LBound(parts) To UBound(parts)
        token = Trim$(parts(i))
        If Len(token) > 0 Then
            If Not (tokens.count = 0 And UCase$(token) = "IO") Then
                tokens.Add token
                If IsKToken(token) Then Exit For
            End If
        End If
    Next i

    If tokens.count = 0 Then Exit Function
    firstToken = Trim$(CStr(tokens(1)))

    ' Use Area only as an optional prefix. Do not prepend it when the network
    ' value already starts with that same area, for example IO_12_203_2035.
    If Len(normalizedArea) > 0 Then
        If StrComp(firstToken, normalizedArea, vbTextCompare) <> 0 Then
            result = normalizedArea
        End If
    End If

    For i = 1 To tokens.count
        If Len(result) > 0 Then result = result & "-"
        result = result & CStr(tokens(i))
    Next i

    BuildSISNumber = result
End Function

Private Function ExtractControlTag(ByVal src As String) As String
    Dim coreText As String, parts() As String
    Dim i As Long, token As String
    coreText = RemoveBracketParts(src)
    coreText = Replace(coreText, "-", "_")
    coreText = CleanUnderscores(coreText)
    If Len(coreText) = 0 Then Exit Function
    parts = Split(coreText, "_")
    For i = LBound(parts) To UBound(parts)
        token = Trim$(parts(i))
        If IsKToken(token) Then
            ExtractControlTag = token
            Exit Function
        End If
    Next i
End Function

Private Function ExtractDevice(ByVal src As String) As String
    Dim coreText As String, parts() As String
    Dim i As Long, token As String
    Dim postKText As String, bracketText As String
    coreText = RemoveBracketParts(src)
    coreText = Replace(coreText, "-", "_")
    coreText = CleanUnderscores(coreText)
    If Len(coreText) > 0 Then
        parts = Split(coreText, "_")
        For i = LBound(parts) To UBound(parts)
            token = Trim$(parts(i))
            If IsKToken(token) Then
                If i < UBound(parts) Then postKText = JoinRemainingNonBlank(parts, i + 1)
                Exit For
            End If
        Next i
    End If
    bracketText = ExtractBracketValue(src)
    If Len(postKText) > 0 And Len(bracketText) > 0 Then
        ExtractDevice = postKText & " " & bracketText
    ElseIf Len(postKText) > 0 Then
        ExtractDevice = postKText
    Else
        ExtractDevice = bracketText
    End If
End Function

Private Function JoinRemainingNonBlank(ByRef parts() As String, ByVal startIndex As Long) As String
    Dim i As Long, s As String
    For i = startIndex To UBound(parts)
        If Len(Trim$(parts(i))) > 0 Then
            If Len(s) > 0 Then s = s & " "
            s = s & Trim$(parts(i))
        End If
    Next i
    JoinRemainingNonBlank = s
End Function

Private Function ExtractBracketValue(ByVal txt As String) As String
    ExtractBracketValue = ExtractBetween(txt, "[", "]")
    If Len(ExtractBracketValue) = 0 Then ExtractBracketValue = ExtractBetween(txt, "(", ")")
    If Len(ExtractBracketValue) = 0 Then ExtractBracketValue = ExtractBetween(txt, "{", "}")
End Function

Private Function ExtractBetween(ByVal txt As String, ByVal openChar As String, ByVal closeChar As String) As String
    Dim p1 As Long, p2 As Long
    p1 = InStr(1, txt, openChar)
    If p1 = 0 Then Exit Function
    p2 = InStr(p1 + 1, txt, closeChar)
    If p2 = 0 Then Exit Function
    ExtractBetween = mid$(txt, p1 + 1, p2 - p1 - 1)
End Function

Private Function RemoveBracketParts(ByVal txt As String) As String
    txt = StripDelimitedText(txt, "[", "]")
    txt = StripDelimitedText(txt, "(", ")")
    txt = StripDelimitedText(txt, "{", "}")
    RemoveBracketParts = CleanSpaces(txt)
End Function

Private Function StripDelimitedText(ByVal txt As String, ByVal openChar As String, ByVal closeChar As String) As String
    Dim p1 As Long, p2 As Long
    Do
        p1 = InStr(1, txt, openChar)
        If p1 = 0 Then Exit Do
        p2 = InStr(p1 + 1, txt, closeChar)
        If p2 = 0 Then
            txt = Left$(txt, p1 - 1)
            Exit Do
        Else
            txt = Left$(txt, p1 - 1) & mid$(txt, p2 + 1)
        End If
    Loop
    StripDelimitedText = txt
End Function

Private Function CleanUnderscores(ByVal txt As String) As String
    txt = Trim$(txt)
    Do While InStr(txt, "__") > 0
        txt = Replace(txt, "__", "_")
    Loop
    If Left$(txt, 1) = "_" Then txt = mid$(txt, 2)
    If Right$(txt, 1) = "_" Then txt = Left$(txt, Len(txt) - 1)
    CleanUnderscores = txt
End Function

Private Function CleanSpaces(ByVal txt As String) As String
    txt = Trim$(txt)
    Do While InStr(txt, "  ") > 0
        txt = Replace(txt, "  ", " ")
    Loop
    CleanSpaces = txt
End Function

Private Function IsKToken(ByVal txt As String) As Boolean
    Dim i As Long, ch As String
    txt = Trim$(txt)
    If Len(txt) < 2 Then Exit Function
    If UCase$(Left$(txt, 1)) <> "K" Then Exit Function
    For i = 2 To Len(txt)
        ch = mid$(txt, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i
    IsKToken = True
End Function

Private Function SafeSheetName(ByVal sheetName As String) As String
    Dim badChars As Variant, i As Long
    badChars = Array("/", "\", "[", "]", ":", "*", "?", Chr$(34))
    For i = LBound(badChars) To UBound(badChars)
        sheetName = Replace(sheetName, badChars(i), "-")
    Next i
    If Len(sheetName) > 31 Then sheetName = Left$(sheetName, 31)
    SafeSheetName = sheetName
End Function

Private Function WorksheetExists(ByVal sheetName As String, ByVal wb As Workbook) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    WorksheetExists = Not ws Is Nothing
    Set ws = Nothing
    On Error GoTo 0
End Function

