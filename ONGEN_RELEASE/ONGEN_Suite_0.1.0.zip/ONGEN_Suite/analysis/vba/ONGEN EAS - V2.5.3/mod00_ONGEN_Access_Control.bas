Attribute VB_Name = "mod00_ONGEN_Access_Control"
Option Explicit
Option Private Module

'===============================================================================
' ONGEN EAS USER / ADMIN ACCESS CONTROL
'
' MATCHED RELEASE FOR:
'   mod00_UI_Buttons_ProgressBar.bas
'
' USER MODE
'   - Engineering worksheet data remains editable.
'   - Workbook structure is protected.
'   - MAIN shapes/buttons are protected.
'   - 0A Rebuild MAIN is hidden.
'   - 0E Verify / Repair Buttons is hidden.
'   - Admin-only buttons are hidden.
'   - ONGEN_WORKFLOW_GUIDE is read-only.
'   - ONGEN_WORKFLOW_GUIDE Macro column F is hidden.
'   - Admin/configuration worksheets use normal Hidden, never VeryHidden.
'
' ADMIN MODE
'   - Workbook structure and MAIN are unlocked.
'   - 0A / 0E and Admin controls are visible.
'   - ONGEN_WORKFLOW_GUIDE is editable.
'   - Macro column F is visible.
'
' SESSION SECURITY
'   - Workbook always opens in User Mode.
'   - Closing while in Admin Mode silently returns to User Mode.
'
' DEFAULT ADMIN PASSWORD
'   zayden
'===============================================================================

Private Const MAIN_SHEET As String = "MAIN"
Private Const GUIDE_SHEET As String = "ONGEN_WORKFLOW_GUIDE"
Private Const STRUCTURE_KEY As String = "ONGEN-STRUCTURE-2026"
Private Const DEFAULT_ADMIN_PASSWORD As String = "zayden"

Private Const PROP_ADMIN_PASSWORD As String = "ONGEN_ADMIN_PASSWORD"
Private Const PROP_MODE As String = "ONGEN_ACCESS_MODE"

Private mIsAdmin As Boolean

'===============================================================================
' STARTUP / CLOSE
'===============================================================================

Public Sub ONGEN_PREPARE_STARTUP_NAVIGATION()
    'Temporarily unlock only what the worksheet-navigation installer needs.
    'This does NOT enter Admin Mode.
    Dim ws As Worksheet

    On Error Resume Next

    ThisWorkbook.Unprotect Password:=STRUCTURE_KEY

    Set ws = ONGEN_GetSheet(GUIDE_SHEET)
    If Not ws Is Nothing Then
        ws.Unprotect Password:=STRUCTURE_KEY
    End If

    On Error GoTo 0
End Sub

Public Sub ONGEN_APPLY_STARTUP_SECURITY()
    ONGEN_EnsureAdminPassword
    mIsAdmin = False
    ONGEN_USER_MODE False
End Sub

Public Sub ONGEN_APPLY_CLOSE_SECURITY()
    On Error Resume Next
    mIsAdmin = False
    ONGEN_USER_MODE False
    On Error GoTo 0
End Sub

'===============================================================================
' USER / ADMIN MODE
'===============================================================================

Public Sub ONGEN_USER_MODE(Optional ByVal ShowMessage As Boolean = True)
    On Error GoTo EH

    Application.ScreenUpdating = False
    Application.EnableEvents = False

    mIsAdmin = False

    ONGEN_UnprotectWorkbookStructure
    ONGEN_UnprotectMainDashboard

    ONGEN_SetAdminSheetVisibility xlSheetHidden
    ONGEN_SetAdminControlsVisible False
    ONGEN_SetPhaseZeroAdminControlsVisible False
    ONGEN_ProtectWorkflowGuideForUser

    ONGEN_ProtectMainDashboard
    ONGEN_ProtectWorkbookStructure
    ONGEN_SetProperty PROP_MODE, "USER"

    Application.EnableEvents = True
    Application.ScreenUpdating = True

    If ShowMessage Then
        MsgBox "ONGEN User Mode is active.", vbInformation, "ONGEN User Mode"
    End If
    Exit Sub

EH:
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    If ShowMessage Then
        MsgBox "Unable to apply User Mode." & vbCrLf & _
               "Error " & Err.Number & ": " & Err.description, _
               vbCritical, "ONGEN Access Control"
    End If
End Sub

Public Sub ONGEN_ADMIN_LOGIN()
    On Error GoTo EH

    ONGEN_EnsureAdminPassword

    Dim entered As String
    entered = InputBox("Enter the ONGEN administrator password.", "ONGEN Admin Login")
    If Len(entered) = 0 Then Exit Sub

    If StrComp(entered, ONGEN_GetProperty(PROP_ADMIN_PASSWORD), vbBinaryCompare) <> 0 Then
        MsgBox "Administrator password was not accepted.", _
               vbCritical, "ONGEN Admin Login"
        Exit Sub
    End If

    mIsAdmin = True
    ONGEN_ADMIN_MODE True
    Exit Sub

EH:
    MsgBox "Admin login failed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN Access Control"
End Sub

Public Sub ONGEN_ADMIN_MODE(Optional ByVal ShowMessage As Boolean = True)
    On Error GoTo EH

    If Not mIsAdmin Then
        ONGEN_ADMIN_LOGIN
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.EnableEvents = False

    ONGEN_UnprotectWorkbookStructure
    ONGEN_UnprotectMainDashboard
    ONGEN_UnprotectWorkflowGuideForAdmin

    ONGEN_SetAdminSheetVisibility xlSheetVisible
    ONGEN_SetAdminControlsVisible True
    ONGEN_SetPhaseZeroAdminControlsVisible True
    ONGEN_SetProperty PROP_MODE, "ADMIN"

    Application.EnableEvents = True
    Application.ScreenUpdating = True

    If ShowMessage Then
        MsgBox "ONGEN Admin Mode is active for this session.", _
               vbInformation, "ONGEN Admin Mode"
    End If
    Exit Sub

EH:
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    If ShowMessage Then
        MsgBox "Unable to apply Admin Mode." & vbCrLf & _
               "Error " & Err.Number & ": " & Err.description, _
               vbCritical, "ONGEN Access Control"
    End If
End Sub

Public Sub ONGEN_ADMIN_LOGOUT()
    ONGEN_USER_MODE True
End Sub

Public Sub ONGEN_ADMIN_CHANGE_PASSWORD()
    If Not mIsAdmin Then
        MsgBox "Enter Admin Mode before changing the administrator password.", _
               vbExclamation, "ONGEN Admin Password"
        Exit Sub
    End If

    Dim oldPass As String
    Dim p1 As String
    Dim p2 As String

    oldPass = InputBox("Enter the current administrator password.", "ONGEN Admin Password")
    If Len(oldPass) = 0 Then Exit Sub

    If StrComp(oldPass, ONGEN_GetProperty(PROP_ADMIN_PASSWORD), vbBinaryCompare) <> 0 Then
        MsgBox "Current administrator password was not accepted.", vbCritical
        Exit Sub
    End If

    p1 = InputBox("Enter the new administrator password.", "ONGEN Admin Password")
    If Len(p1) = 0 Then Exit Sub

    p2 = InputBox("Re-enter the new administrator password.", "Confirm ONGEN Admin Password")
    If p1 <> p2 Then
        MsgBox "Passwords do not match.", vbCritical
        Exit Sub
    End If

    ONGEN_SetProperty PROP_ADMIN_PASSWORD, p1
    MsgBox "Administrator password updated.", vbInformation, "ONGEN Admin Password"
End Sub

Public Function ONGEN_IS_ADMIN_MODE() As Boolean
    ONGEN_IS_ADMIN_MODE = mIsAdmin
End Function

Public Function ONGEN_REQUIRE_ADMIN(Optional ByVal actionDescription As String = "this administrator function") As Boolean
    If mIsAdmin Then
        ONGEN_REQUIRE_ADMIN = True
    Else
        MsgBox actionDescription & " is available only in ONGEN Admin Mode." & vbCrLf & _
               "Use ADMIN LOGIN on MAIN.", _
               vbExclamation, "ONGEN Admin Required"
    End If
End Function

'===============================================================================
' SECURITY / NAVIGATION BUTTON REPAIR
'===============================================================================

Public Sub ONGEN_REPAIR_SECURITY_AND_NAV_BUTTONS()
    Dim ws As Worksheet

    On Error GoTo EH

    Application.ScreenUpdating = False
    Application.EnableEvents = False

    ONGEN_UnprotectWorkbookStructure
    ONGEN_UnprotectMainDashboard

    Set ws = ONGEN_GetSheet(MAIN_SHEET)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 901, , "MAIN worksheet was not found."
    End If

    'Admin / Recovery panel
    ONGEN_LinkButton ws, "ONGEN_ADMIN_LOGIN_BTN", "ONGEN_ADMIN_LOGIN"
    ONGEN_LinkButton ws, "ONGEN_ADMIN_SHEET_LAUNCHER_BTN", "NAV_Open_Worksheet_Launcher"
    ONGEN_LinkButton ws, "ONGEN_ADMIN_LOGOUT_BTN", "ONGEN_ADMIN_LOGOUT"
    ONGEN_LinkButton ws, "ONGEN_ADMIN_CHANGE_PASSWORD_BTN", "ONGEN_ADMIN_CHANGE_PASSWORD"
    ONGEN_LinkButton ws, "ONGEN_ADMIN_REPAIR_BTN", "ONGEN_REPAIR_SECURITY_AND_NAV_BUTTONS"
    ONGEN_LinkButton ws, "ONGEN_ADMIN_RELOAD_UI_BTN", "ONGEN_RELOAD_ALL_UI_BUTTONS"

    'IMPORTANT:
    'ONGEN_VFD_SETUP is an AutoCAD LISP command, NOT an Excel VBA macro.
    'The Excel-side VFD setup wrapper is BTN_VFD_Install_Workflow.
    ONGEN_LinkButton ws, "ONGEN_ADMIN_VFD_SETUP_BTN", "BTN_VFD_Install_Workflow"

    'The Excel UI repair action is the production MAIN/UI reload macro.
    ONGEN_LinkButton ws, "ONGEN_ADMIN_INSTALL_UI_BTN", "ONGEN_RELOAD_ALL_UI_BUTTONS"

    ONGEN_LinkButton ws, "ONGEN_ADMIN_CLEAR_BTN", "ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE"

    'Phase 0
    ONGEN_LinkButton ws, "ONGEN_UI_BTN_0A_Rebuild_MAIN", "ONGEN_REBUILD_MAIN_FROM_SCRATCH"
    ONGEN_LinkButton ws, "ONGEN_UI_BTN_0B_Sheet_Launcher", "NAV_Open_Worksheet_Launcher"
    ONGEN_LinkButton ws, "ONGEN_UI_BTN_0E_Verify___Repair_Buttons", "ONGEN_VERIFY_AND_REPAIR_MAIN_BUTTONS"

    'Worksheet navigation
    For Each ws In ThisWorkbook.Worksheets
        If StrComp(ws.Name, MAIN_SHEET, vbTextCompare) <> 0 Then
            ONGEN_LinkButton ws, "btnReturnToMAIN", "NAV_Return_To_MAIN"
            ONGEN_LinkButton ws, "btnWorksheetLauncher", "NAV_Open_Worksheet_Launcher"
        End If
    Next ws

    ONGEN_USER_MODE False

    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN security and navigation button links repaired.", _
           vbInformation, "ONGEN Button Repair"
    Exit Sub

EH:
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN button repair stopped." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN Button Repair"
End Sub

Public Sub ONGEN_MARK_SHAPE_ADMIN_ONLY(ByVal ws As Worksheet, ByVal shapeName As String)
    On Error Resume Next
    ws.Shapes(shapeName).AlternativeText = "ONGEN_ROLE=ADMIN"
    On Error GoTo 0
End Sub

Private Sub ONGEN_LinkButton(ByVal ws As Worksheet, _
                             ByVal shapeName As String, _
                             ByVal macroName As String)

    On Error Resume Next
    ws.Shapes(shapeName).OnAction = "'" & ThisWorkbook.Name & "'!" & macroName
    On Error GoTo 0
End Sub

'===============================================================================
' USER / ADMIN VISIBILITY
'===============================================================================

Private Sub ONGEN_SetPhaseZeroAdminControlsVisible(ByVal makeVisible As Boolean)
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(MAIN_SHEET)
    If ws Is Nothing Then Exit Sub

    ONGEN_SetShapeVisible ws, "ONGEN_UI_BTN_0A_Rebuild_MAIN", makeVisible
    ONGEN_SetShapeVisible ws, "ONGEN_UI_BTN_0E_Verify___Repair_Buttons", makeVisible
End Sub

Private Sub ONGEN_SetAdminControlsVisible(ByVal makeVisible As Boolean)
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(MAIN_SHEET)
    If ws Is Nothing Then Exit Sub

    Dim shp As Shape

    For Each shp In ws.Shapes
        If InStr(1, UCase$(shp.AlternativeText), "ONGEN_ROLE=ADMIN", vbTextCompare) > 0 Then
            On Error Resume Next
            shp.Visible = IIf(makeVisible, msoTrue, msoFalse)
            On Error GoTo 0
        End If
    Next shp

    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_LOGOUT_BTN", makeVisible
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_CHANGE_PASSWORD_BTN", makeVisible
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_REPAIR_BTN", makeVisible
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_RELOAD_UI_BTN", makeVisible
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_VFD_SETUP_BTN", makeVisible
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_INSTALL_UI_BTN", makeVisible

    'Always-visible User Mode controls
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_LOGIN_BTN", True
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_SHEET_LAUNCHER_BTN", True
    ONGEN_SetShapeVisible ws, "ONGEN_ADMIN_CLEAR_BTN", True
End Sub

Private Sub ONGEN_SetAdminSheetVisibility(ByVal stateValue As XlSheetVisibility)
    Dim names As Variant
    names = Array( _
        "VFD_DWG_CONFIG", _
        "VFD_DWG_DEVICE_LIBRARY", _
        "VFD_DWG_DEVICE_PLACEMENT", _
        "VFD_DWG_ATTRIBUTE_MAP", _
        "VFD_DWG_SEED_LIBRARY", _
        "CTRL_FUNCTION", _
        "DATA_POWER", _
        "DATA_IO_BLOCK", _
        "READ ME" _
    )

    Dim i As Long
    Dim ws As Worksheet

    For i = LBound(names) To UBound(names)
        Set ws = ONGEN_GetSheet(CStr(names(i)))
        If Not ws Is Nothing Then ws.Visible = stateValue
        Set ws = Nothing
    Next i
End Sub

Private Sub ONGEN_SetShapeVisible(ByVal ws As Worksheet, _
                                  ByVal shapeName As String, _
                                  ByVal showIt As Boolean)
    On Error Resume Next
    ws.Shapes(shapeName).Visible = IIf(showIt, msoTrue, msoFalse)
    On Error GoTo 0
End Sub

'===============================================================================
' WORKFLOW GUIDE
'===============================================================================

Private Sub ONGEN_ProtectWorkflowGuideForUser()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(GUIDE_SHEET)
    If ws Is Nothing Then Exit Sub

    On Error Resume Next

    ws.Unprotect Password:=STRUCTURE_KEY

    'Hide implementation macro names from User Mode.
    ws.Columns("F").Hidden = True

    'Only touch populated cells. Never lock ws.Cells across the entire worksheet,
    'because doing so can consume excessive memory in a large XLSM.
    If Application.WorksheetFunction.CountA(ws.UsedRange) > 0 Then
        ws.UsedRange.Locked = True
    End If

    ws.Protect _
        Password:=STRUCTURE_KEY, _
        DrawingObjects:=True, _
        Contents:=True, _
        Scenarios:=True, _
        UserInterfaceOnly:=True, _
        AllowFiltering:=True

    ws.EnableSelection = xlNoRestrictions

    On Error GoTo 0
End Sub

Private Sub ONGEN_UnprotectWorkflowGuideForAdmin()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(GUIDE_SHEET)
    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Unprotect Password:=STRUCTURE_KEY
    ws.Columns("F").Hidden = False
    On Error GoTo 0
End Sub

'===============================================================================
' MAIN / WORKBOOK PROTECTION
'===============================================================================

Private Sub ONGEN_ProtectMainDashboard()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(MAIN_SHEET)
    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Unprotect Password:=STRUCTURE_KEY
    On Error GoTo 0

    Dim shp As Shape
    For Each shp In ws.Shapes
        On Error Resume Next
        shp.Locked = True
        On Error GoTo 0
    Next shp

    ws.Protect _
        Password:=STRUCTURE_KEY, _
        DrawingObjects:=True, _
        Contents:=False, _
        Scenarios:=False, _
        UserInterfaceOnly:=True, _
        AllowFiltering:=True

    ws.EnableSelection = xlNoRestrictions
End Sub

Private Sub ONGEN_UnprotectMainDashboard()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(MAIN_SHEET)
    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Unprotect Password:=STRUCTURE_KEY
    On Error GoTo 0
End Sub

Private Sub ONGEN_ProtectWorkbookStructure()
    On Error Resume Next
    ThisWorkbook.Protect Password:=STRUCTURE_KEY, Structure:=True, Windows:=False
    On Error GoTo 0
End Sub

Private Sub ONGEN_UnprotectWorkbookStructure()
    On Error Resume Next
    ThisWorkbook.Unprotect Password:=STRUCTURE_KEY
    On Error GoTo 0
End Sub

'===============================================================================
' PASSWORD / PROPERTIES
'===============================================================================

Private Sub ONGEN_EnsureAdminPassword()
    If Len(ONGEN_GetProperty(PROP_ADMIN_PASSWORD)) = 0 Then
        ONGEN_SetProperty PROP_ADMIN_PASSWORD, DEFAULT_ADMIN_PASSWORD
    End If
End Sub

Private Sub ONGEN_SetProperty(ByVal propName As String, ByVal propValue As String)
    On Error Resume Next
    ThisWorkbook.CustomDocumentProperties(propName).Delete
    On Error GoTo 0

    ThisWorkbook.CustomDocumentProperties.Add _
        Name:=propName, _
        LinkToContent:=False, _
        Type:=4, _
        value:=propValue
End Sub

Private Function ONGEN_GetProperty(ByVal propName As String) As String
    On Error GoTo SafeExit
    ONGEN_GetProperty = CStr(ThisWorkbook.CustomDocumentProperties(propName).value)

SafeExit:
End Function

'===============================================================================
' HELPERS
'===============================================================================

Private Function ONGEN_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set ONGEN_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function
