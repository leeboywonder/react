Attribute VB_Name = "mod09_ONGEN_Cable_ID_Core"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod09_ONGEN_Cable_ID_Core
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : 24V branch-suffix functional update applied.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE AUDIT UPDATE
' Module        : mod09_ONGEN_Cable_ID_Core
' Release       : V25.8.5-C04.4 24V DC Branch Suffix
' Author/Owner  : Lee Pierre
' Purpose       : Permanent functional cable IDs, PREFIX-#### formatting, shared tag helpers, registry migration/guards.
'-------------------------------------------------------------------------------
Option Explicit

'===============================================================================
' ONGEN EAS V25.7.1 - OPTION A FUNCTIONAL SHORT CABLE ID CORE
'
' Approved permanent tag families (PREFIX-####):
'   WPWR-#### = AC / 480VAC power
'   WDC-####[.n] = 24VDC power; same PSU + DC pair shares one base number
'   WIO-####  = standard / non-safety I/O cable
'   WSF-####  = safety I/O cable
'   WNET-#### = Ethernet network cable
'   WFB-####  = fiber-optic cable
'   WMTR-#### = motor power cable
'   WEN-####  = encoder / feedback cable
'   WBK-####  = motor brake cable
'   WCT-####  = general control cable
'   WBS-####  = fieldbus / specialty bus cable
'   WGN-####  = general / uncategorized cable
'
' Design intent:
'   * The prefix makes the cable family obvious in the field without embedding
'     Panel, SIS sequence, terminal, switch port, route, or drawing location.
'   * Each prefix family uses its own four-digit permanent sequence after a dash.
'   * 24VDC is branch-aware: one PSU + DC pair owns WDC-####; additional devices
'     on that same pair receive .1, .2, .3, etc. without consuming another base.
'   * CABLE_ID_REGISTRY preserves the ID assigned to one physical cable key.
'   * Legacy WD###### records created by V25.7.0 are migrated in a controlled,
'     deterministic way when the registry is first loaded by this release.
'===============================================================================

Private Const CID_REGISTRY_SHEET As String = "CABLE_ID_REGISTRY"
Private Const CID_DIGITS As Long = 4
Private Const CID_MAX_NUMBER As Long = 9999
Private Const CID_DC_MAX_BRANCH_SUFFIX As Long = 9999

Private mCableMap As Object
Private mNextByPrefix As Object
Private mDCBaseByGroup As Object
Private mDCMaxSuffixByGroup As Object
Private mLoaded As Boolean

Public Sub ONGEN_CableID_BeginRun()
    CID_LoadRegistry True
End Sub

Public Function ONGEN_CableID_Get(ByVal physicalCableKey As String, _
                                  Optional ByVal legacyCableID As String = vbNullString, _
                                  Optional ByVal cableRoleCode As String = vbNullString) As String
    Dim key As String, roleCode As String, prefix As String
    Dim ws As Worksheet, newID As String, newRow As Long, n As Long

    key = CID_NormalizeKey(physicalCableKey)
    If Len(key) = 0 Then Err.Raise vbObjectError + 25701, "ONGEN_CableID_Get", "Physical cable key is blank."

    If Not mLoaded Then CID_LoadRegistry True

    roleCode = CID_NormalizeRole(cableRoleCode)
    If Len(roleCode) = 0 Then roleCode = CID_RoleFromKey(key)
    prefix = CID_PrefixForRole(roleCode)

    If mCableMap.Exists(key) Then
        ONGEN_CableID_Get = CStr(mCableMap(key))
        CID_TouchRegistry key
        Exit Function
    End If

    n = CID_GetNextNumber(prefix)
    If n < 1 Or n > CID_MAX_NUMBER Then
        Err.Raise vbObjectError + 25702, "ONGEN_CableID_Get", _
                  "Cable ID family " & prefix & " exceeded " & CID_FormatCableID(prefix, CID_MAX_NUMBER) & ". A controlled numbering extension is required."
    End If

    newID = CID_FormatCableID(prefix, n)
    CID_SetNextNumber prefix, n + 1

    Set ws = CID_GetOrCreateRegistry()
    newRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row + 1
    If newRow < 2 Then newRow = 2

    ws.Cells(newRow, 1).Value2 = key
    ws.Cells(newRow, 2).Value2 = newID
    ws.Cells(newRow, 3).value = Now
    ws.Cells(newRow, 4).value = Now
    ws.Cells(newRow, 5).Value2 = "ACTIVE"
    ws.Cells(newRow, 6).Value2 = legacyCableID
    ws.Cells(newRow, 7).Value2 = roleCode
    ws.Cells(newRow, 8).Value2 = prefix

    mCableMap.Add key, newID
    ONGEN_CableID_Get = newID
End Function

Public Function ONGEN_CableID_PrefixForRole(ByVal cableRoleCode As String) As String
    ONGEN_CableID_PrefixForRole = CID_PrefixForRole(CID_NormalizeRole(cableRoleCode))
End Function

' Central export helpers. These deliberately build the same physical-cable keys used
' by the label-list exporter so workflow exports reuse permanent cable IDs.
Public Function ONGEN_ExportTag_IO(ByVal deviceName As String, ByVal blockID As String, _
                                   ByVal panel As String, ByVal areaNumber As String, _
                                   Optional ByVal evidence As String = vbNullString, _
                                   Optional ByVal physicalCableGroup As String = vbNullString) As String
    Dim roleCode As String, packageCode As String, keyText As String, identityToken As String

    deviceName = Trim$(deviceName)
    blockID = Trim$(blockID)
    panel = Trim$(panel)
    areaNumber = Trim$(areaNumber)
    physicalCableGroup = Trim$(physicalCableGroup)
    If Len(deviceName) = 0 Then Exit Function

    roleCode = ONGEN_CableID_IOCableRoleFromEvidence(blockID & "|" & evidence)
    If Len(roleCode) = 0 Then roleCode = "GEN"

    If Len(panel) > 0 Then
        packageCode = panel
    ElseIf Len(areaNumber) > 0 Then
        packageCode = "AREA-" & areaNumber
    Else
        packageCode = "UNASSIGNED"
    End If

    If Len(physicalCableGroup) > 0 Then
        identityToken = "GROUP:" & physicalCableGroup
    Else
        identityToken = "BLOCK:" & blockID
    End If

    keyText = roleCode & "|" & packageCode & "|" & deviceName & "|" & identityToken
    ONGEN_ExportTag_IO = ONGEN_CableID_Get(keyText, vbNullString, roleCode)
End Function
Public Function ONGEN_CableID_IOCableRoleFromEvidence(ByVal sourceText As String) As String
    Dim s As String
    s = UCase$(Trim$(sourceText))

    If InStr(1, s, "IO/S", vbTextCompare) > 0 Then
        ONGEN_CableID_IOCableRoleFromEvidence = "SAF"
        Exit Function
    ElseIf InStr(1, s, "IO/D", vbTextCompare) > 0 Then
        ONGEN_CableID_IOCableRoleFromEvidence = "IO"
        Exit Function
    End If

    If InStr(1, s, "S_IN", vbTextCompare) > 0 Or _
       InStr(1, s, "S- IN", vbTextCompare) > 0 Or _
       InStr(1, s, "S OUT", vbTextCompare) > 0 Or _
       InStr(1, s, "S_OUT", vbTextCompare) > 0 Or _
       InStr(1, s, "SAFETY", vbTextCompare) > 0 Or _
       CID_HasEvidenceToken(s, "EST") Or _
       CID_HasEvidenceToken(s, "EPC") Then
        ONGEN_CableID_IOCableRoleFromEvidence = "SAF"
        Exit Function
    End If

    If CID_HasEvidenceToken(s, "DI") Or _
       CID_HasEvidenceToken(s, "DO") Or _
       CID_HasEvidenceToken(s, "AI") Or _
       CID_HasEvidenceToken(s, "AO") Or _
       InStr(1, s, "DIGITAL INPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "DIGITAL OUTPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "ANALOG INPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "ANALOG OUTPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "STANDARD I/O", vbTextCompare) > 0 Or _
       InStr(1, s, "STANDARD IO", vbTextCompare) > 0 Then
        ONGEN_CableID_IOCableRoleFromEvidence = "IO"
    End If
End Function

Private Function CID_HasEvidenceToken(ByVal sourceText As String, ByVal tokenText As String) As Boolean
    Dim s As String
    s = UCase$(sourceText)
    s = Replace(s, "-", " ")
    s = Replace(s, "_", " ")
    s = Replace(s, "/", " ")
    s = Replace(s, "\", " ")
    s = Replace(s, ".", " ")
    s = Replace(s, ",", " ")
    s = Replace(s, ":", " ")
    s = Replace(s, ";", " ")
    s = Replace(s, "(", " ")
    s = Replace(s, ")", " ")
    s = Replace(s, "[", " ")
    s = Replace(s, "]", " ")
    s = Replace(s, "|", " ")
    Do While InStr(1, s, "  ", vbBinaryCompare) > 0
        s = Replace(s, "  ", " ")
    Loop
    s = " " & Trim$(s) & " "
    CID_HasEvidenceToken = (InStr(1, s, " " & UCase$(Trim$(tokenText)) & " ", vbBinaryCompare) > 0)
End Function

'===============================================================================
' 24VDC BRANCH-AWARE TAG ALLOCATION - V25.8.5-C04.4
'
' Rule:
'   * One known PSU + physical DC pair owns one permanent WDC-#### base.
'   * The first device on that pair uses the base unchanged.
'   * Additional device cables use WDC-####.1, WDC-####.2, and so on.
'   * The exact device physical-cable key remains in CABLE_ID_REGISTRY, so an
'     already-issued branch suffix is stable across rebuilds and row reordering.
'   * Missing/unknown PSUs NEVER share a branch base because they do not prove a
'     common physical source. Those rows retain one independent WDC-#### each.
'
' terminalPair should normally be DC1+/DC1-, DC2+/DC2-, DC3+/DC3-, or DC4+/DC4-.
' sourceTerminal remains part of the permanent physical cable key for backwards
' compatibility and also supplies the DC-pair fallback mapping (05/07/09/11).
'===============================================================================
Public Function ONGEN_ExportTag_DC(ByVal panel As String, ByVal busName As String, _
                                   ByVal psuName As String, ByVal sisElement As String, _
                                   ByVal sourceTerminal As String, _
                                   Optional ByVal terminalPair As String = vbNullString) As String
    Dim physicalKey As String, normalizedKey As String, groupKey As String
    Dim baseID As String, newID As String
    Dim branchSuffix As Long, n As Long, newRow As Long
    Dim ws As Worksheet

    sisElement = Trim$(sisElement)
    If Len(sisElement) = 0 Then Exit Function

    'Keep the historical key layout so existing registry rows remain reusable.
    physicalKey = "DC|" & Trim$(panel) & "|" & Trim$(busName) & "|" & Trim$(psuName) & "|" & _
                  sisElement & "|" & Trim$(sourceTerminal)
    normalizedKey = CID_NormalizeKey(physicalKey)

    If Not mLoaded Then CID_LoadRegistry True

    'A previously-issued device cable always wins. CID_LoadRegistry upgrades old
    'same-branch WDC rows to the suffix scheme before this lookup is reached.
    If mCableMap.Exists(normalizedKey) Then
        ONGEN_ExportTag_DC = CStr(mCableMap(normalizedKey))
        CID_TouchRegistry normalizedKey
        Exit Function
    End If

    'Do not group unknown sources. "MISSING PSU" can represent more than one
    'future physical PSU, so sharing a branch label here would create false ties.
    If CID_DCIsMissingPSU(psuName) Then
        ONGEN_ExportTag_DC = ONGEN_CableID_Get(physicalKey, vbNullString, "DC")
        Exit Function
    End If

    groupKey = CID_DCGroupKey(panel, psuName, sourceTerminal, terminalPair)
    If Len(groupKey) = 0 Then
        'If no DC pair can be identified, preserve the safe one-ID-per-cable rule.
        ONGEN_ExportTag_DC = ONGEN_CableID_Get(physicalKey, vbNullString, "DC")
        Exit Function
    End If

    CID_EnsureDCGroupCache

    If mDCBaseByGroup.Exists(groupKey) Then
        baseID = CStr(mDCBaseByGroup(groupKey))
        branchSuffix = CLng(mDCMaxSuffixByGroup(groupKey)) + 1
        If branchSuffix > CID_DC_MAX_BRANCH_SUFFIX Then
            Err.Raise vbObjectError + 25721, "ONGEN_ExportTag_DC", _
                      "24VDC branch " & groupKey & " exceeded suffix ." & _
                      CStr(CID_DC_MAX_BRANCH_SUFFIX) & ". Review the physical distribution design."
        End If
        newID = baseID & "." & CStr(branchSuffix)
        mDCMaxSuffixByGroup(groupKey) = branchSuffix
    Else
        n = CID_GetNextNumber("WDC")
        If n < 1 Or n > CID_MAX_NUMBER Then
            Err.Raise vbObjectError + 25722, "ONGEN_ExportTag_DC", _
                      "WDC base family exceeded " & CID_FormatCableID("WDC", CID_MAX_NUMBER) & "."
        End If
        baseID = CID_FormatCableID("WDC", n)
        newID = baseID
        CID_SetNextNumber "WDC", n + 1
        mDCBaseByGroup.Add groupKey, baseID
        mDCMaxSuffixByGroup.Add groupKey, 0
    End If

    'Persist the branch-specific cable, not a synthetic group row. This keeps every
    'registry CABLE_ID unique while still allowing many cables to share one base.
    Set ws = CID_GetOrCreateRegistry()
    newRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row + 1
    If newRow < 2 Then newRow = 2

    ws.Cells(newRow, 1).Value2 = normalizedKey
    ws.Cells(newRow, 2).Value2 = newID
    ws.Cells(newRow, 3).value = Now
    ws.Cells(newRow, 4).value = Now
    ws.Cells(newRow, 5).Value2 = "ACTIVE - DC BRANCH SUFFIX"
    ws.Cells(newRow, 6).Value2 = vbNullString
    ws.Cells(newRow, 7).Value2 = "DC"
    ws.Cells(newRow, 8).Value2 = "WDC"
    ws.Cells(newRow, 9).Value2 = groupKey

    mCableMap.Add normalizedKey, newID
    ONGEN_ExportTag_DC = newID
End Function

'Builds the grouping identity used only for 24VDC base-number sharing.
Private Function CID_DCGroupKey(ByVal panel As String, ByVal psuName As String, _
                                ByVal sourceTerminal As String, _
                                Optional ByVal terminalPair As String = vbNullString) As String
    Dim pairToken As String

    If CID_DCIsMissingPSU(psuName) Then Exit Function
    pairToken = CID_DCGroupToken(terminalPair, sourceTerminal)
    If Len(pairToken) = 0 Then Exit Function

    CID_DCGroupKey = CID_NormalizeKey( _
        "DCGROUP|" & Trim$(panel) & "|" & Trim$(psuName) & "|" & pairToken)
End Function

'Converts explicit DC-pair text or the standard X1 terminal sequence into DC1..DC4.
Private Function CID_DCGroupToken(ByVal terminalPair As String, ByVal sourceTerminal As String) As String
    Dim s As String, n As Long

    s = UCase$(Replace(Trim$(terminalPair), " ", vbNullString))
    For n = 1 To 4
        If InStr(1, s, "DC" & CStr(n) & "+", vbTextCompare) > 0 Or _
           InStr(1, s, "DC" & CStr(n) & "-", vbTextCompare) > 0 Or _
           StrComp(s, "DC" & CStr(n), vbTextCompare) = 0 Then
            CID_DCGroupToken = "DC" & CStr(n)
            Exit Function
        End If
    Next n

    s = UCase$(Replace(Trim$(sourceTerminal), " ", vbNullString))
    If Len(s) = 0 Then Exit Function

    If InStr(1, s, "TERM05", vbTextCompare) > 0 Or Right$(s, 2) = "05" Then
        CID_DCGroupToken = "DC1"
    ElseIf InStr(1, s, "TERM07", vbTextCompare) > 0 Or Right$(s, 2) = "07" Then
        CID_DCGroupToken = "DC2"
    ElseIf InStr(1, s, "TERM09", vbTextCompare) > 0 Or Right$(s, 2) = "09" Then
        CID_DCGroupToken = "DC3"
    ElseIf InStr(1, s, "TERM11", vbTextCompare) > 0 Or Right$(s, 2) = "11" Then
        CID_DCGroupToken = "DC4"
    Else
        'A nonstandard terminal is still a valid stable group identifier; using the
        'literal terminal is safer than guessing which DC pair it represents.
        CID_DCGroupToken = "TERM:" & CID_NormalizeKey(s)
    End If
End Function

Private Function CID_DCIsMissingPSU(ByVal psuName As String) As Boolean
    Dim s As String
    s = UCase$(Trim$(psuName))
    CID_DCIsMissingPSU = (Len(s) = 0 Or InStr(1, s, "MISSING", vbTextCompare) > 0)
End Function

'Parses historical/current DC physical keys without changing their persisted layout.
Private Function CID_DCGroupKeyFromPhysicalKey(ByVal normalizedKey As String) As String
    Dim parts As Variant
    parts = Split(CID_NormalizeKey(normalizedKey), "|")
    If UBound(parts) < 5 Then Exit Function
    If StrComp(CStr(parts(0)), "DC", vbTextCompare) <> 0 Then Exit Function

    CID_DCGroupKeyFromPhysicalKey = CID_DCGroupKey( _
        CStr(parts(1)), CStr(parts(3)), CStr(parts(5)), vbNullString)
End Function

Private Sub CID_EnsureDCGroupCache()
    If mDCBaseByGroup Is Nothing Then
        Set mDCBaseByGroup = CreateObject("Scripting.Dictionary")
        mDCBaseByGroup.CompareMode = vbTextCompare
    End If
    If mDCMaxSuffixByGroup Is Nothing Then
        Set mDCMaxSuffixByGroup = CreateObject("Scripting.Dictionary")
        mDCMaxSuffixByGroup.CompareMode = vbTextCompare
    End If
End Sub

Private Function CID_DCBaseIDFromID(ByVal cableID As String) As String
    Dim s As String, p As Long
    s = UCase$(Trim$(cableID))
    If CID_PrefixFromApprovedID(s) <> "WDC" Then Exit Function
    p = InStr(1, s, ".", vbBinaryCompare)
    If p > 0 Then s = Left$(s, p - 1)
    CID_DCBaseIDFromID = s
End Function

Private Function CID_DCBranchSuffixFromID(ByVal cableID As String) As Long
    Dim s As String, p As Long, suffixText As String
    s = UCase$(Trim$(cableID))
    If CID_PrefixFromApprovedID(s) <> "WDC" Then Exit Function
    p = InStr(1, s, ".", vbBinaryCompare)
    If p = 0 Then Exit Function
    suffixText = mid$(s, p + 1)
    If CID_IsDigitsOnly(suffixText) Then CID_DCBranchSuffixFromID = CLng(suffixText)
End Function

Public Function ONGEN_ExportTag_PWR(ByVal panel As String, ByVal sisElement As String) As String
    If Len(Trim$(sisElement)) = 0 Then Exit Function
    ONGEN_ExportTag_PWR = ONGEN_CableID_Get( _
        "PWR|" & Trim$(panel) & "|" & Trim$(sisElement), vbNullString, "PWR")
End Function

Public Function ONGEN_ExportTag_NET(ByVal panel As String, ByVal portText As String, _
                                    ByVal sourceDevice As String, ByVal destinationDevice As String) As String
    If Len(Trim$(destinationDevice)) = 0 Then Exit Function
    portText = ONGEN_CableID_NormalizeNetworkPort(portText)
    If Len(portText) = 0 Then Exit Function
    ONGEN_ExportTag_NET = ONGEN_CableID_Get( _
        "NET|" & Trim$(panel) & "|" & portText & "|" & _
        Trim$(sourceDevice) & "|" & Trim$(destinationDevice), vbNullString, "NET")
End Function

' Accept both X1..X9 and X01..X09 (and X10..X99) and store one canonical key.
Public Function ONGEN_CableID_NormalizeNetworkPort(ByVal portText As String) As String
    Dim s As String, n As Long
    s = UCase$(Replace(Trim$(portText), " ", vbNullString))
    If Len(s) < 2 Then Exit Function
    If Left$(s, 1) <> "X" Then Exit Function
    If Not IsNumeric(mid$(s, 2)) Then Exit Function
    n = CLng(mid$(s, 2))
    If n < 1 Or n > 99 Then Exit Function
    ONGEN_CableID_NormalizeNetworkPort = "X" & Format$(n, "00")
End Function

Public Sub ONGEN_CableID_ResetCache()
    Set mCableMap = Nothing
    Set mNextByPrefix = Nothing
    Set mDCBaseByGroup = Nothing
    Set mDCMaxSuffixByGroup = Nothing
    mLoaded = False
End Sub

Public Sub ONGEN_CableID_OpenRegistry()
    Dim ws As Worksheet
    Set ws = CID_GetOrCreateRegistry()
    ws.Visible = xlSheetVisible
    ws.Activate
End Sub

Public Sub ONGEN_CableID_MigrateLegacyWDIDs()
    Dim ws As Worksheet, migrated As Long
    Set ws = CID_GetOrCreateRegistry()
    ONGEN_CableID_ResetCache
    CID_LoadRegistry True
    migrated = CID_CountNewFormatIDs(ws)
    MsgBox "Cable ID migration complete." & vbCrLf & _
           CStr(migrated) & " registry record(s) now use PREFIX-#### formatting.", _
           vbInformation, "ONGEN Cable ID Migration"
End Sub

Public Sub ONGEN_CableID_MigrateTagFormat()
    Dim ws As Worksheet, migrated As Long
    Set ws = CID_GetOrCreateRegistry()
    migrated = CID_MigrateCurrentTagFormat(ws)
    ONGEN_CableID_ResetCache
    CID_LoadRegistry True
    MsgBox CStr(migrated) & " existing cable ID(s) were normalized to PREFIX-#### format." & vbCrLf & _
           "Required families: WIO, WSF, WNET, WDC, WPWR, WMTR.", _
           vbInformation, "ONGEN Cable Tag Format Migration"
End Sub

Public Sub ONGEN_CableID_AuditRegistry()
    Dim ws As Worksheet
    Dim lastRow As Long, r As Long
    Dim ids As Object, keys As Object
    Dim cableID As String, key As String, roleCode As String, expectedPrefix As String
    Dim issueCount As Long, msg As String

    Set ws = CID_GetOrCreateRegistry()
    Set ids = CreateObject("Scripting.Dictionary")
    Set keys = CreateObject("Scripting.Dictionary")
    ids.CompareMode = vbTextCompare
    keys.CompareMode = vbTextCompare

    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    For r = 2 To lastRow
        key = Trim$(CStr(ws.Cells(r, 1).Value2))
        cableID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
        If Len(key) = 0 And Len(cableID) = 0 Then GoTo nextRow

        roleCode = CID_RoleFromKey(key)
        expectedPrefix = CID_PrefixForRole(roleCode)

        If Not CID_IsApprovedID(cableID) Then
            issueCount = issueCount + 1
            msg = msg & vbCrLf & "Row " & r & ": invalid PREFIX-#### cable ID " & cableID
        ElseIf Left$(cableID, Len(expectedPrefix) + 1) <> expectedPrefix & "-" Then
            issueCount = issueCount + 1
            msg = msg & vbCrLf & "Row " & r & ": " & cableID & " does not match expected family " & expectedPrefix
        End If
        'WDC branch IDs can extend to WDC-####.9999; all other approved
        'families remain the compact base form checked by CID_IsApprovedID.
        If CID_IsApprovedID(cableID) Then
            If CID_PrefixFromApprovedID(cableID) = "WDC" Then
                If Len(cableID) > 13 Then
                    issueCount = issueCount + 1
                    msg = msg & vbCrLf & "Row " & r & ": WDC branch ID exceeds supported length"
                End If
            ElseIf Len(cableID) > 10 Then
                issueCount = issueCount + 1
                msg = msg & vbCrLf & "Row " & r & ": ID exceeds supported compact length"
            End If
        End If
        If keys.Exists(key) Then
            issueCount = issueCount + 1
            msg = msg & vbCrLf & "Row " & r & ": duplicate physical cable key"
        ElseIf Len(key) > 0 Then
            keys.Add key, r
        End If
        If ids.Exists(cableID) Then
            issueCount = issueCount + 1
            msg = msg & vbCrLf & "Row " & r & ": duplicate cable ID " & cableID
        ElseIf Len(cableID) > 0 Then
            ids.Add cableID, r
        End If
nextRow:
    Next r

    If issueCount = 0 Then
        MsgBox "Cable ID registry PASS." & vbCrLf & _
               CStr(ids.count) & " permanent cable IDs are unique; WDC supports the approved .n branch suffix.", _
               vbInformation, "ONGEN Cable ID Audit"
    Else
        MsgBox "Cable ID registry has " & CStr(issueCount) & " issue(s):" & msg, _
               vbExclamation, "ONGEN Cable ID Audit"
    End If
End Sub

Private Sub CID_LoadRegistry(ByVal createIfMissing As Boolean)
    Dim ws As Worksheet
    Dim lastRow As Long, r As Long
    Dim key As String, cableID As String, prefix As String
    Dim n As Long

    Set mCableMap = CreateObject("Scripting.Dictionary")
    mCableMap.CompareMode = vbTextCompare
    Set mNextByPrefix = CreateObject("Scripting.Dictionary")
    mNextByPrefix.CompareMode = vbTextCompare
    CID_SeedPrefixes

    If createIfMissing Then
        Set ws = CID_GetOrCreateRegistry()
    Else
        On Error Resume Next
        Set ws = ThisWorkbook.Worksheets(CID_REGISTRY_SHEET)
        On Error GoTo 0
        If ws Is Nothing Then
            mLoaded = True
            Exit Sub
        End If
    End If

    CID_EnsureRegistryLayout ws
    CID_ValidateRegistryUniqueness ws

    'Normalize all previously-issued functional IDs without renumbering the physical cable.
    'Examples: WIO00060 -> WIO-0060; WP00012 -> WPWR-0012; WMT00007 -> WMTR-0007.
    CID_MigrateCurrentTagFormat ws
    CID_ValidateRegistryUniqueness ws

    'Seed family counters from the normalized PREFIX-#### IDs.
    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    For r = 2 To lastRow
        cableID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
        If CID_IsApprovedID(cableID) Then
            prefix = CID_PrefixFromApprovedID(cableID)
            n = CID_NumberFromApprovedID(cableID)
            If n >= CID_GetNextNumber(prefix) Then CID_SetNextNumber prefix, n + 1
        End If
    Next r

    'Controlled migration of V25.7.0 WD###### IDs after counters are seeded.
    CID_MigrateLegacyWDRecords ws
    CID_ValidateRegistryUniqueness ws

    'Upgrade historical one-base-per-device DC rows into one base per PSU + DC pair.
    'The first issued ID in each group is preserved; later rows become .1, .2, etc.
    CID_MigrateDCBranchSuffixes ws
    CID_ValidateRegistryUniqueness ws

    Set mDCBaseByGroup = CreateObject("Scripting.Dictionary")
    mDCBaseByGroup.CompareMode = vbTextCompare
    Set mDCMaxSuffixByGroup = CreateObject("Scripting.Dictionary")
    mDCMaxSuffixByGroup.CompareMode = vbTextCompare

    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    For r = 2 To lastRow
        key = CID_NormalizeKey(CStr(ws.Cells(r, 1).Value2))
        cableID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
        If Len(key) > 0 And Len(cableID) > 0 Then
            If Not mCableMap.Exists(key) Then mCableMap.Add key, cableID
            If CID_IsApprovedID(cableID) Then
                prefix = CID_PrefixFromApprovedID(cableID)
                n = CID_NumberFromApprovedID(cableID)
                If n >= CID_GetNextNumber(prefix) Then CID_SetNextNumber prefix, n + 1
            End If
            CID_RegisterDCGroupFromRegistry key, cableID, CStr(ws.Cells(r, 9).Value2)
        End If
    Next r
    mLoaded = True
End Sub
'Consolidates existing DC registry rows without changing their physical keys.
'Example legacy rows WDC-1659 / WDC-1660 / WDC-1661 on the same PSU+DC1 pair
'become WDC-1659 / WDC-1659.1 / WDC-1659.2. This is intentionally idempotent.
Private Function CID_MigrateDCBranchSuffixes(ByVal ws As Worksheet) As Long
    Dim groups As Object, idRows As Object, memberRows As Object
    Dim members As Collection
    Dim lastRow As Long, r As Long, i As Long, firstRow As Long
    Dim key As String, cableID As String, groupKey As String
    Dim baseID As String, desiredID As String, oldID As String
    Dim groupItem As Variant, existingRow As Long

    Set groups = CreateObject("Scripting.Dictionary")
    groups.CompareMode = vbTextCompare
    Set idRows = CreateObject("Scripting.Dictionary")
    idRows.CompareMode = vbTextCompare

    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    For r = 2 To lastRow
        cableID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
        If Len(cableID) > 0 Then idRows(cableID) = r

        key = CID_NormalizeKey(CStr(ws.Cells(r, 1).Value2))
        groupKey = CID_NormalizeKey(CStr(ws.Cells(r, 9).Value2))
        If Len(groupKey) = 0 Then groupKey = CID_DCGroupKeyFromPhysicalKey(key)
        If Len(groupKey) > 0 And CID_PrefixFromApprovedID(cableID) = "WDC" Then
            'Persist the resolved branch identity so nonstandard source-terminal names
            'remain tied to the explicit DC pair across future workbook sessions.
            ws.Cells(r, 9).Value2 = groupKey
            If Not groups.Exists(groupKey) Then
                Set members = New Collection
                groups.Add groupKey, members
            End If
            Set members = groups(groupKey)
            members.Add r
        End If
    Next r

    For Each groupItem In groups.keys
        Set members = groups(CStr(groupItem))
        If members.count < 2 Then GoTo NextGroup

        firstRow = CLng(members(1))
        baseID = CID_DCBaseIDFromID(CStr(ws.Cells(firstRow, 2).Value2))
        If Len(baseID) = 0 Then GoTo NextGroup

        Set memberRows = CreateObject("Scripting.Dictionary")
        For i = 1 To members.count
            memberRows(CStr(CLng(members(i)))) = True
        Next i

        'Preflight all desired IDs against rows outside this physical branch group.
        For i = 1 To members.count
            If i = 1 Then
                desiredID = baseID
            Else
                If i - 1 > CID_DC_MAX_BRANCH_SUFFIX Then
                    Err.Raise vbObjectError + 25723, "CID_MigrateDCBranchSuffixes", _
                              "24VDC branch " & CStr(groupItem) & " exceeds the supported suffix range."
                End If
                desiredID = baseID & "." & CStr(i - 1)
            End If

            If idRows.Exists(desiredID) Then
                existingRow = CLng(idRows(desiredID))
                If Not memberRows.Exists(CStr(existingRow)) Then
                    Err.Raise vbObjectError + 25724, "CID_MigrateDCBranchSuffixes", _
                              "Cannot assign " & desiredID & " to DC branch " & CStr(groupItem) & _
                              " because registry row " & CStr(existingRow) & " already owns that ID."
                End If
            End If
        Next i

        'Apply in registry order. Registry order is the permanent first-seen cable order.
        For i = 1 To members.count
            r = CLng(members(i))
            oldID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
            If i = 1 Then
                desiredID = baseID
            Else
                desiredID = baseID & "." & CStr(i - 1)
            End If

            If StrComp(oldID, desiredID, vbTextCompare) <> 0 Then
                If idRows.Exists(oldID) Then idRows.Remove oldID
                If Len(Trim$(CStr(ws.Cells(r, 6).Value2))) = 0 Then ws.Cells(r, 6).Value2 = oldID
                ws.Cells(r, 2).Value2 = desiredID
                ws.Cells(r, 4).value = Now
                ws.Cells(r, 5).Value2 = "ACTIVE - DC BRANCH SUFFIX MIGRATED"
                idRows(desiredID) = r
                CID_MigrateDCBranchSuffixes = CID_MigrateDCBranchSuffixes + 1
            End If
        Next i
NextGroup:
    Next groupItem
End Function

'Builds the fast group cache used when a new DC device cable is encountered.
Private Sub CID_RegisterDCGroupFromRegistry(ByVal normalizedKey As String, ByVal cableID As String, _
                                              Optional ByVal persistedGroupKey As String = vbNullString)
    Dim groupKey As String, baseID As String, suffixNumber As Long

    groupKey = CID_NormalizeKey(persistedGroupKey)
    If Len(groupKey) = 0 Then groupKey = CID_DCGroupKeyFromPhysicalKey(normalizedKey)
    If Len(groupKey) = 0 Then Exit Sub
    If CID_PrefixFromApprovedID(cableID) <> "WDC" Then Exit Sub

    baseID = CID_DCBaseIDFromID(cableID)
    suffixNumber = CID_DCBranchSuffixFromID(cableID)
    CID_EnsureDCGroupCache

    If mDCBaseByGroup.Exists(groupKey) Then
        If StrComp(CStr(mDCBaseByGroup(groupKey)), baseID, vbTextCompare) <> 0 Then
            Err.Raise vbObjectError + 25725, "CID_RegisterDCGroupFromRegistry", _
                      "DC branch " & groupKey & " contains more than one WDC base ID. Run the cable registry audit."
        End If
        If suffixNumber > CLng(mDCMaxSuffixByGroup(groupKey)) Then _
            mDCMaxSuffixByGroup(groupKey) = suffixNumber
    Else
        mDCBaseByGroup.Add groupKey, baseID
        mDCMaxSuffixByGroup.Add groupKey, suffixNumber
    End If
End Sub

Private Sub CID_ValidateRegistryUniqueness(ByVal ws As Worksheet)
    Dim keys As Object, ids As Object
    Dim lastRow As Long, r As Long
    Dim key As String, cableID As String, firstRow As Long

    Set keys = CreateObject("Scripting.Dictionary")
    Set ids = CreateObject("Scripting.Dictionary")
    keys.CompareMode = vbTextCompare
    ids.CompareMode = vbTextCompare

    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    For r = 2 To lastRow
        key = CID_NormalizeKey(CStr(ws.Cells(r, 1).Value2))
        cableID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))

        If Len(key) > 0 Then
            If keys.Exists(key) Then
                firstRow = CLng(keys(key))
                Err.Raise vbObjectError + 25711, "CID_ValidateRegistryUniqueness", _
                          "CABLE_ID_REGISTRY contains duplicate physical cable keys at rows " & _
                          CStr(firstRow) & " and " & CStr(r) & ". Repair the registry before generating new tags."
            End If
            keys.Add key, r
        End If

        If Len(cableID) > 0 Then
            If ids.Exists(cableID) Then
                firstRow = CLng(ids(cableID))
                Err.Raise vbObjectError + 25712, "CID_ValidateRegistryUniqueness", _
                          "CABLE_ID_REGISTRY contains duplicate cable ID " & cableID & _
                          " at rows " & CStr(firstRow) & " and " & CStr(r) & _
                          ". Repair the registry before generating new tags."
            End If
            ids.Add cableID, r
        End If
    Next r
End Sub


Private Function CID_MigrateCurrentTagFormat(ByVal ws As Worksheet) As Long
    Dim lastRow As Long, r As Long, n As Long
    Dim key As String, oldID As String, roleCode As String, prefix As String, newID As String
    Dim proposed As Object, proposedByRow As Object, firstRow As Long

    Set proposed = CreateObject("Scripting.Dictionary")
    proposed.CompareMode = vbTextCompare
    Set proposedByRow = CreateObject("Scripting.Dictionary")

    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row

    'Preflight every conversion so a legacy/new alias collision cannot corrupt the registry.
    For r = 2 To lastRow
        key = CID_NormalizeKey(CStr(ws.Cells(r, 1).Value2))
        oldID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
        If Len(key) = 0 Or Len(oldID) = 0 Then GoTo preflightNext
        If Left$(oldID, 2) = "WD" And Len(oldID) = 8 And IsNumeric(mid$(oldID, 3)) Then GoTo preflightNext

        roleCode = CID_RoleFromKey(key)

        'Already-approved IDs must be kept byte-for-byte. This is especially
        'important for WDC-####.n; stripping .n here would collapse branch IDs.
        If CID_IsApprovedID(oldID) Then
            newID = oldID
            proposedByRow(CStr(r)) = newID
            If proposed.Exists(newID) Then
                firstRow = CLng(proposed(newID))
                Err.Raise vbObjectError + 25714, "CID_MigrateCurrentTagFormat", _
                          "Cable ID format migration found duplicate " & newID & _
                          " at registry rows " & CStr(firstRow) & " and " & CStr(r) & "."
            End If
            proposed.Add newID, r
            GoTo preflightNext
        End If

        If CID_TryExtractCableNumber(oldID, roleCode, n) Then
            If n < 1 Or n > CID_MAX_NUMBER Then
                Err.Raise vbObjectError + 25713, "CID_MigrateCurrentTagFormat", _
                          "Existing cable ID " & oldID & " at registry row " & CStr(r) & _
                          " cannot fit the required four-digit sequence."
            End If
            prefix = CID_PrefixForRole(roleCode)
            newID = CID_FormatCableID(prefix, n)
            proposedByRow(CStr(r)) = newID
            If proposed.Exists(newID) Then
                firstRow = CLng(proposed(newID))
                Err.Raise vbObjectError + 25714, "CID_MigrateCurrentTagFormat", _
                          "Cable ID format migration would create duplicate " & newID & _
                          " at registry rows " & CStr(firstRow) & " and " & CStr(r) & "."
            End If
            proposed.Add newID, r
        Else
            'Keep an unrecognized ID in the collision set so it cannot be overwritten silently.
            If proposed.Exists(oldID) Then
                firstRow = CLng(proposed(oldID))
                Err.Raise vbObjectError + 25715, "CID_MigrateCurrentTagFormat", _
                          "Duplicate/unrecognized cable ID " & oldID & " at registry rows " & _
                          CStr(firstRow) & " and " & CStr(r) & "."
            End If
            proposed.Add oldID, r
        End If
preflightNext:
    Next r

    For r = 2 To lastRow
        If proposedByRow.Exists(CStr(r)) Then
            oldID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
            newID = CStr(proposedByRow(CStr(r)))
            key = CID_NormalizeKey(CStr(ws.Cells(r, 1).Value2))
            roleCode = CID_RoleFromKey(key)
            prefix = CID_PrefixForRole(roleCode)
            If StrComp(oldID, newID, vbTextCompare) <> 0 Then
                If Len(Trim$(CStr(ws.Cells(r, 6).Value2))) = 0 Then ws.Cells(r, 6).Value2 = oldID
                ws.Cells(r, 2).Value2 = newID
                ws.Cells(r, 4).value = Now
                ws.Cells(r, 5).Value2 = "ACTIVE - MIGRATED V25.8.4-C03"
                CID_MigrateCurrentTagFormat = CID_MigrateCurrentTagFormat + 1
            End If
            ws.Cells(r, 7).Value2 = roleCode
            ws.Cells(r, 8).Value2 = prefix
        End If
    Next r
End Function

Private Function CID_TryExtractCableNumber(ByVal cableID As String, ByVal roleCode As String, ByRef n As Long) As Boolean
    Dim s As String, newPrefix As String, oldPrefix As String, suffixText As String
    s = UCase$(Trim$(cableID))

    If CID_IsApprovedID(s) Then
        n = CID_NumberFromApprovedID(s)
        CID_TryExtractCableNumber = True
        Exit Function
    End If

    newPrefix = CID_PrefixForRole(roleCode)
    oldPrefix = CID_LegacyPrefixForRole(roleCode)

    If Left$(s, Len(newPrefix) + 1) = newPrefix & "-" Then
        suffixText = mid$(s, Len(newPrefix) + 2)
    ElseIf Left$(s, Len(newPrefix)) = newPrefix Then
        suffixText = mid$(s, Len(newPrefix) + 1)
    ElseIf Len(oldPrefix) > 0 And Left$(s, Len(oldPrefix) + 1) = oldPrefix & "-" Then
        suffixText = mid$(s, Len(oldPrefix) + 2)
    ElseIf Len(oldPrefix) > 0 And Left$(s, Len(oldPrefix)) = oldPrefix Then
        suffixText = mid$(s, Len(oldPrefix) + 1)
    Else
        Exit Function
    End If

    If Len(suffixText) < 1 Or Not IsNumeric(suffixText) Then Exit Function
    n = CLng(suffixText)
    CID_TryExtractCableNumber = True
End Function

Private Function CID_LegacyPrefixForRole(ByVal roleCode As String) As String
    Select Case CID_NormalizeRole(roleCode)
        Case "PWR": CID_LegacyPrefixForRole = "WP"
        Case "DC": CID_LegacyPrefixForRole = "WDC"
        Case "IO": CID_LegacyPrefixForRole = "WIO"
        Case "SAF": CID_LegacyPrefixForRole = "WSF"
        Case "NET": CID_LegacyPrefixForRole = "WNT"
        Case "FBR": CID_LegacyPrefixForRole = "WFB"
        Case "MTR": CID_LegacyPrefixForRole = "WMT"
        Case "ENC": CID_LegacyPrefixForRole = "WEN"
        Case "BRK": CID_LegacyPrefixForRole = "WBK"
        Case "CTRL": CID_LegacyPrefixForRole = "WCT"
        Case "BUS": CID_LegacyPrefixForRole = "WBS"
        Case Else: CID_LegacyPrefixForRole = "WGN"
    End Select
End Function

Private Function CID_CountNewFormatIDs(ByVal ws As Worksheet) As Long
    Dim lastRow As Long, r As Long
    lastRow = ws.Cells(ws.rows.count, 2).End(xlUp).Row
    For r = 2 To lastRow
        If CID_IsApprovedID(CStr(ws.Cells(r, 2).Value2)) Then CID_CountNewFormatIDs = CID_CountNewFormatIDs + 1
    Next r
End Function

Private Function CID_MigrateLegacyWDRecords(ByVal ws As Worksheet) As Long
    Dim lastRow As Long, r As Long, n As Long
    Dim key As String, oldID As String, roleCode As String, prefix As String, newID As String

    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    For r = 2 To lastRow
        key = CID_NormalizeKey(CStr(ws.Cells(r, 1).Value2))
        oldID = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
        If Len(key) = 0 Then GoTo nextRow
        If Len(oldID) = 8 And Left$(oldID, 2) = "WD" And IsNumeric(mid$(oldID, 3)) Then
            roleCode = CID_RoleFromKey(key)
            prefix = CID_PrefixForRole(roleCode)
            n = CID_GetNextNumber(prefix)
            If n > CID_MAX_NUMBER Then Err.Raise vbObjectError + 25703, "CID_MigrateLegacyWDRecords", "Cable family " & prefix & " exceeded capacity during migration."
            newID = CID_FormatCableID(prefix, n)
            CID_SetNextNumber prefix, n + 1
            If Len(Trim$(CStr(ws.Cells(r, 6).Value2))) = 0 Then ws.Cells(r, 6).Value2 = oldID
            ws.Cells(r, 2).Value2 = newID
            ws.Cells(r, 4).value = Now
            ws.Cells(r, 5).Value2 = "ACTIVE - MIGRATED V25.7.1"
            ws.Cells(r, 7).Value2 = roleCode
            ws.Cells(r, 8).Value2 = prefix
            CID_MigrateLegacyWDRecords = CID_MigrateLegacyWDRecords + 1
        End If
nextRow:
    Next r
End Function

Private Function CID_GetOrCreateRegistry() As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(CID_REGISTRY_SHEET)
    On Error GoTo 0

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = CID_REGISTRY_SHEET
    End If
    CID_EnsureRegistryLayout ws
    Set CID_GetOrCreateRegistry = ws
End Function

Private Sub CID_EnsureRegistryLayout(ByVal ws As Worksheet)
    ws.Range("A1:I1").value = Array("PHYSICAL_CABLE_KEY", "CABLE_ID", "CREATED", "LAST_USED", "STATUS", "LEGACY_CABLE_ID", "CABLE_ROLE", "TAG_PREFIX", "DC_GROUP_KEY")
    With ws.Range("A1:I1")
        .Font.Bold = True
        .Font.Color = vbWhite
        .Interior.Color = RGB(31, 78, 121)
    End With
    ws.Columns("A").columnWidth = 70
    ws.Columns("B").columnWidth = 16
    ws.Columns("C:D").columnWidth = 20
    ws.Columns("E:H").columnWidth = 20
    ws.Columns("I").columnWidth = 55
End Sub

Private Sub CID_TouchRegistry(ByVal normalizedKey As String)
    Dim ws As Worksheet, f As Range
    Set ws = CID_GetOrCreateRegistry()
    Set f = ws.Columns(1).Find(What:=normalizedKey, LookIn:=xlValues, LookAt:=xlWhole, MatchCase:=False)
    If Not f Is Nothing Then ws.Cells(f.Row, 4).value = Now
End Sub

Private Sub CID_SeedPrefixes()
    Dim prefixes As Variant, i As Long
    prefixes = Array("WPWR", "WDC", "WIO", "WSF", "WNET", "WFB", "WMTR", "WEN", "WBK", "WCT", "WBS", "WGN")
    For i = LBound(prefixes) To UBound(prefixes)
        mNextByPrefix(CStr(prefixes(i))) = 1
    Next i
End Sub

Private Function CID_GetNextNumber(ByVal prefix As String) As Long
    If mNextByPrefix Is Nothing Then
        Set mNextByPrefix = CreateObject("Scripting.Dictionary")
        mNextByPrefix.CompareMode = vbTextCompare
        CID_SeedPrefixes
    End If
    If Not mNextByPrefix.Exists(prefix) Then mNextByPrefix(prefix) = 1
    CID_GetNextNumber = CLng(mNextByPrefix(prefix))
End Function

Private Sub CID_SetNextNumber(ByVal prefix As String, ByVal valueNumber As Long)
    If mNextByPrefix Is Nothing Then
        Set mNextByPrefix = CreateObject("Scripting.Dictionary")
        mNextByPrefix.CompareMode = vbTextCompare
    End If
    mNextByPrefix(prefix) = valueNumber
End Sub

Private Function CID_RoleFromKey(ByVal normalizedKey As String) As String
    Dim p As Long, token As String
    p = InStr(1, normalizedKey, "|", vbBinaryCompare)
    If p > 0 Then token = Left$(normalizedKey, p - 1) Else token = normalizedKey
    CID_RoleFromKey = CID_NormalizeRole(token)
    If Len(CID_RoleFromKey) = 0 Then CID_RoleFromKey = "GEN"
End Function

Private Function CID_NormalizeRole(ByVal valueText As String) As String
    Dim s As String
    s = UCase$(Trim$(valueText))
    Select Case s
        Case "PWR", "POWER", "AC", "480V", "480VAC": CID_NormalizeRole = "PWR"
        Case "DC", "24V", "24VDC": CID_NormalizeRole = "DC"
        Case "IO", "I/O", "STANDARD IO", "STANDARD I/O": CID_NormalizeRole = "IO"
        Case "SAF", "SAFE", "SAFETY", "SAFETY IO", "SAFETY I/O": CID_NormalizeRole = "SAF"
        Case "NET", "NETWORK", "ETHERNET": CID_NormalizeRole = "NET"
        Case "FBR", "FIBER", "FIBRE": CID_NormalizeRole = "FBR"
        Case "MTR", "MOTOR", "MOTOR POWER": CID_NormalizeRole = "MTR"
        Case "ENC", "ENCODER", "FEEDBACK": CID_NormalizeRole = "ENC"
        Case "BRK", "BRAKE": CID_NormalizeRole = "BRK"
        Case "CTRL", "CONTROL", "GENERAL CONTROL": CID_NormalizeRole = "CTRL"
        Case "BUS", "FIELDBUS": CID_NormalizeRole = "BUS"
        Case "GEN", "GENERAL", "OTHER", "MISC", "MISCELLANEOUS": CID_NormalizeRole = "GEN"
        Case Else: CID_NormalizeRole = vbNullString
    End Select
End Function

Private Function CID_PrefixForRole(ByVal roleCode As String) As String
    Select Case CID_NormalizeRole(roleCode)
        Case "PWR": CID_PrefixForRole = "WPWR"
        Case "DC": CID_PrefixForRole = "WDC"
        Case "IO": CID_PrefixForRole = "WIO"
        Case "SAF": CID_PrefixForRole = "WSF"
        Case "NET": CID_PrefixForRole = "WNET"
        Case "FBR": CID_PrefixForRole = "WFB"
        Case "MTR": CID_PrefixForRole = "WMTR"
        Case "ENC": CID_PrefixForRole = "WEN"
        Case "BRK": CID_PrefixForRole = "WBK"
        Case "CTRL": CID_PrefixForRole = "WCT"
        Case "BUS": CID_PrefixForRole = "WBS"
        Case Else: CID_PrefixForRole = "WGN"
    End Select
End Function

Private Function CID_FormatCableID(ByVal prefix As String, ByVal n As Long) As String
    CID_FormatCableID = UCase$(Trim$(prefix)) & "-" & Format$(n, String$(CID_DIGITS, "0"))
End Function

Private Function CID_IsApprovedID(ByVal cableID As String) As Boolean
    CID_IsApprovedID = (Len(CID_PrefixFromApprovedID(cableID)) > 0)
End Function

Private Function CID_NumberFromApprovedID(ByVal cableID As String) As Long
    Dim prefix As String, remainder As String, p As Long
    prefix = CID_PrefixFromApprovedID(cableID)
    If Len(prefix) = 0 Then Exit Function

    remainder = mid$(UCase$(Trim$(cableID)), Len(prefix) + 2)
    p = InStr(1, remainder, ".", vbBinaryCompare)
    If p > 0 Then remainder = Left$(remainder, p - 1)
    If CID_IsDigitsOnly(remainder) Then CID_NumberFromApprovedID = CLng(remainder)
End Function

Private Function CID_PrefixFromApprovedID(ByVal cableID As String) As String
    Dim prefixes As Variant, i As Long, p As String
    Dim remainder As String, baseDigits As String, branchText As String
    Dim dotPos As Long, baseNumber As Long, branchNumber As Long

    cableID = UCase$(Trim$(cableID))
    'Longer prefixes first to avoid W* partial matches.
    prefixes = Array("WPWR", "WNET", "WMTR", "WDC", "WIO", "WSF", "WFB", "WEN", "WBK", "WCT", "WBS", "WGN")

    For i = LBound(prefixes) To UBound(prefixes)
        p = CStr(prefixes(i))
        If Left$(cableID, Len(p) + 1) = p & "-" Then
            remainder = mid$(cableID, Len(p) + 2)
            dotPos = InStr(1, remainder, ".", vbBinaryCompare)

            If dotPos > 0 Then
                'Only WDC supports a branch suffix. A second dot or non-digit suffix is invalid.
                If p <> "WDC" Then GoTo NextPrefix
                If InStr(dotPos + 1, remainder, ".", vbBinaryCompare) > 0 Then GoTo NextPrefix
                baseDigits = Left$(remainder, dotPos - 1)
                branchText = mid$(remainder, dotPos + 1)
                If Not CID_IsDigitsOnly(branchText) Then GoTo NextPrefix
                If Left$(branchText, 1) = "0" Then GoTo NextPrefix
                branchNumber = CLng(branchText)
                If branchNumber < 1 Or branchNumber > CID_DC_MAX_BRANCH_SUFFIX Then GoTo NextPrefix
            Else
                baseDigits = remainder
            End If

            If Len(baseDigits) <> CID_DIGITS Then GoTo NextPrefix
            If Not CID_IsDigitsOnly(baseDigits) Then GoTo NextPrefix
            baseNumber = CLng(baseDigits)
            If baseNumber < 1 Or baseNumber > CID_MAX_NUMBER Then GoTo NextPrefix

            CID_PrefixFromApprovedID = p
            Exit Function
        End If
NextPrefix:
    Next i
End Function

Private Function CID_IsDigitsOnly(ByVal valueText As String) As Boolean
    Dim i As Long, ch As String
    If Len(valueText) = 0 Then Exit Function
    For i = 1 To Len(valueText)
        ch = mid$(valueText, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i
    CID_IsDigitsOnly = True
End Function

Private Function CID_NormalizeKey(ByVal valueText As String) As String
    Dim s As String
    s = UCase$(Trim$(valueText))
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    CID_NormalizeKey = s
End Function

