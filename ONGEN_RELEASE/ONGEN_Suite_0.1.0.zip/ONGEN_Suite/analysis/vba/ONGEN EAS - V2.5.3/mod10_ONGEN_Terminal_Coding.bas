Attribute VB_Name = "mod10_ONGEN_Terminal_Coding"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod10_ONGEN_Terminal_Coding
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
Option Explicit

'===============================================================================
' ONGEN EAS V25.7.1 - TERMINAL CODING STANDARD
'
' X101-X700 retain the defined functional ranges.
' X701-X999 are RESERVED FOR PROJECT USE. This project-use range may include
' field-device terminal groups, but no single X number is globally mandated for
' every field device. The project terminal plan owns the exact assignment.
'===============================================================================

Public Function ONGEN_Terminal_DefaultCode(ByVal circuitClass As String, _
                                           Optional ByVal isFieldDevice As Boolean = False) As String
    Dim s As String
    s = UCase$(Trim$(circuitClass))

    If isFieldDevice Then
        'Project-owned assignment required inside X701-X999.
        ONGEN_Terminal_DefaultCode = vbNullString
        Exit Function
    End If

    Select Case s
        Case "EMERGENCY STOP", "ESTOP", "E-STOP", "E STOP": ONGEN_Terminal_DefaultCode = "X101"
        Case "GENERAL CONTROL", "CONTROL": ONGEN_Terminal_DefaultCode = "X111"
        Case "MOTOR": ONGEN_Terminal_DefaultCode = "X201"
        Case "MOTOR FREQUENCY DRIVE", "VFD", "FREQUENCY DRIVE": ONGEN_Terminal_DefaultCode = "X281"
        Case "3 PHASE INCOMING", "3PH IN", "480V IN": ONGEN_Terminal_DefaultCode = "X300"
        Case "3 PHASE OUTGOING", "3PH OUT", "480V OUT": ONGEN_Terminal_DefaultCode = "X311"
        Case "1 PHASE INCOMING", "1PH IN": ONGEN_Terminal_DefaultCode = "X336"
        Case "1 PHASE OUTGOING", "1PH OUT": ONGEN_Terminal_DefaultCode = "X341"
        Case "24VDC INCOMING", "24V IN", "DC IN": ONGEN_Terminal_DefaultCode = "X360"
        Case "24VDC OUTGOING", "24V OUT", "DC OUT": ONGEN_Terminal_DefaultCode = "X371"
        Case "UPS INCOMING", "UPS": ONGEN_Terminal_DefaultCode = "X390"
        Case "INTERFACING", "COMMUNICATION", "INTERFACING / COMMUNICATION": ONGEN_Terminal_DefaultCode = "X481"
        Case "BUILDING MANAGEMENT SYSTEMS", "BMS": ONGEN_Terminal_DefaultCode = "X501"
        Case "DATA COMMUNICATION", "DATA": ONGEN_Terminal_DefaultCode = "X601"
        Case "FIELD DEVICE", "FIELD DEVICES", "PROJECT", "PROJECT USE": ONGEN_Terminal_DefaultCode = vbNullString
        Case Else: ONGEN_Terminal_DefaultCode = vbNullString
    End Select
End Function

Public Function ONGEN_Terminal_IsProjectReservedCode(ByVal terminalCode As String) As Boolean
    Dim n As Long
    n = ONGEN_Terminal_Number(terminalCode)
    ONGEN_Terminal_IsProjectReservedCode = (n >= 701 And n <= 999)
End Function

Public Function ONGEN_Terminal_IsFieldDeviceCode(ByVal terminalCode As String) As Boolean
    'Backward-compatible helper. X701-X999 is eligible for project-defined field
    'device groups, but the code alone does not prove the circuit is a field device.
    ONGEN_Terminal_IsFieldDeviceCode = ONGEN_Terminal_IsProjectReservedCode(terminalCode)
End Function

Public Function ONGEN_Terminal_Function(ByVal terminalCode As String) As String
    Dim n As Long
    n = ONGEN_Terminal_Number(terminalCode)
    If n < 0 Then
        ONGEN_Terminal_Function = "INVALID"
        Exit Function
    End If

    Select Case n
        Case 101 To 110: ONGEN_Terminal_Function = "EMERGENCY STOP"
        Case 111 To 120: ONGEN_Terminal_Function = "GENERAL CONTROL"
        Case 201 To 220: ONGEN_Terminal_Function = "MOTOR"
        Case 281 To 299: ONGEN_Terminal_Function = "MOTOR FREQUENCY DRIVE"
        Case 300 To 310: ONGEN_Terminal_Function = "3 PHASE INCOMING"
        Case 311 To 335: ONGEN_Terminal_Function = "3 PHASE OUTGOING"
        Case 336 To 340: ONGEN_Terminal_Function = "1 PHASE INCOMING"
        Case 341 To 359: ONGEN_Terminal_Function = "1 PHASE OUTGOING"
        Case 360 To 370: ONGEN_Terminal_Function = "24VDC INCOMING"
        Case 371 To 389: ONGEN_Terminal_Function = "24VDC OUTGOING"
        Case 390 To 400: ONGEN_Terminal_Function = "UPS INCOMING"
        Case 481 To 499: ONGEN_Terminal_Function = "INTERFACING / COMMUNICATION"
        Case 501 To 600: ONGEN_Terminal_Function = "BUILDING MANAGEMENT SYSTEMS"
        Case 601 To 700: ONGEN_Terminal_Function = "DATA COMMUNICATION"
        Case 701 To 999: ONGEN_Terminal_Function = "RESERVED / PROJECT USE (FIELD DEVICES INCLUDED)"
        Case Else: ONGEN_Terminal_Function = "UNASSIGNED"
    End Select
End Function

Public Function ONGEN_Terminal_IsValid(ByVal terminalCode As String) As Boolean
    Dim f As String
    f = ONGEN_Terminal_Function(terminalCode)
    ONGEN_Terminal_IsValid = (f <> "INVALID" And f <> "UNASSIGNED")
End Function

Private Function ONGEN_Terminal_Number(ByVal terminalCode As String) As Long
    Dim s As String
    s = UCase$(Trim$(terminalCode))
    If Left$(s, 1) = "X" Then s = mid$(s, 2)
    If InStr(s, ":") > 0 Then s = Left$(s, InStr(s, ":") - 1)
    If InStr(s, ".") > 0 Then s = Left$(s, InStr(s, ".") - 1)
    If Len(s) = 0 Or Not IsNumeric(s) Then
        ONGEN_Terminal_Number = -1
    Else
        ONGEN_Terminal_Number = CLng(s)
    End If
End Function

