Attribute VB_Name = "modVFD_V21_5_LocatorSTOConfig"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : modVFD_V21_5_LocatorSTOConfig
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : modVFD_V21_5_LocatorSTOConfig
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Static procedure, declaration, and public-name audit completed.
' Notes         : New manual-only locator/feed-header/STO configuration installer.
'-------------------------------------------------------------------------------

Option Explicit

'===============================================================================
' ONGEN EAS V21.5 - Manual locator, feed-header, and STO configuration installer
'
' This module never runs automatically. Run ONGEN_EAS_V21_5_INSTALL_CONFIG only
' when the workbook configuration or exact STO BLOCK_EDIT rule must be repaired.
'===============================================================================

Private Const CONFIG_SHEET As String = "VFD_DWG_CONFIG"
Private Const BLOCK_EDIT_SHEET As String = "BLOCK_EDIT"

Public Sub ONGEN_EAS_V21_5_INSTALL_CONFIG()
    Dim wsConfig As Worksheet
    Dim wsBlockEdit As Worksheet
    Dim oldCalculation As XlCalculation
    Dim oldScreenUpdating As Boolean
    Dim oldEnableEvents As Boolean

    On Error GoTo EH

    oldCalculation = Application.Calculation
    oldScreenUpdating = Application.ScreenUpdating
    oldEnableEvents = Application.EnableEvents

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Set wsConfig = ThisWorkbook.Worksheets(CONFIG_SHEET)
    Set wsBlockEdit = ThisWorkbook.Worksheets(BLOCK_EDIT_SHEET)

    'Feed header: From RCP-101 - SWG104.
    UpsertConfig wsConfig, "FEED_HEADER_ENABLED", "YES", "NO", _
        "Adds the Panel and SwitchGroup header to PWR and IO pages only."
    UpsertConfig wsConfig, "FEED_HEADER_PREFIX", _
        "From {PANEL} - {SWITCHGROUP}", "NO", _
        "Token template. Example output: From RCP-101 - SWG104."
    UpsertConfig wsConfig, "FEED_HEADER_SEPARATOR", " - ", "NO", _
        "Fallback separator when FEED_HEADER_PREFIX does not contain tokens."
    UpsertConfig wsConfig, "FEED_HEADER_SWITCHGROUP_PREFIX", "SWG", "NO", _
        "Prefix applied to a numeric SwitchGroup."

    'Locator callouts.
    UpsertConfig wsConfig, "LOCATOR_CALLOUTS_ENABLED", "YES", "NO", _
        "Enables LP_BUS2_IN, LP_NET_IN, and LP_NET_OUT callouts on PWR/IO pages."
    UpsertConfig wsConfig, "CALLOUT_LOCATOR_LAYER", vbNullString, "NO", _
        "Blank searches all layers, block names, attributes, and nested blocks."
    UpsertConfig wsConfig, "LOCATOR_CALLOUT_LAYER", "LP_TITLE_DETAILS", "NO", _
        "Layer used for generated callout geometry and text."
    UpsertConfig wsConfig, "LOCATOR_ARROW_LINE_LENGTH", 1.5, "NO", _
        "Horizontal source/destination line length."
    UpsertConfig wsConfig, "LOCATOR_CALLOUT_TEXT_DISTANCE", 1.6, "NO", _
        "Horizontal distance from the locator to both callout text rows."
    UpsertConfig wsConfig, "LOCATOR_ARROW_TEXT_HEIGHT", 0.125, "NO", _
        "Text height for both callout text rows."
    UpsertConfig wsConfig, "LOCATOR_ARROW_TEXT_OFFSET", 0.2, "NO", _
        "Vertical distance above and below the horizontal line."
    UpsertConfig wsConfig, "LOCATOR_ARROW_HEAD_SIZE", 0.18, "NO", _
        "Open arrowhead size."
    UpsertConfig wsConfig, "LOCATOR_MISSING_TEXT", "MISSING", "NO", _
        "Fallback text when a network or 24V source field is blank."
    UpsertConfig wsConfig, "BUS2_IN_LOCATOR_TEXT", "LP_BUS2_IN", "NO", _
        "24V BUS-2 FROM-arrow locator."
    UpsertConfig wsConfig, "NET_IN_LOCATOR_TEXT", "LP_NET_IN", "NO", _
        "Network FROM-arrow locator."
    UpsertConfig wsConfig, "NET_OUT_LOCATOR_TEXT", "LP_NET_OUT", "NO", _
        "Network TO-arrow locator."
    UpsertConfig wsConfig, "BUS2_IN_PREFIX", "From ", "NO", _
        "Prefix before the BUS-2 source."
    UpsertConfig wsConfig, "NET_IN_PREFIX", "From: ", "NO", _
        "Prefix before NETWORK_FROM."
    UpsertConfig wsConfig, "NET_OUT_PREFIX", "To: ", "NO", _
        "Prefix before NETWORK_TO."

    'VFD STO data source.
    UpsertConfig wsConfig, "VFD_STO_BACKFILL_ENABLED", "YES", "NO", _
        "YES matches VFD SIS_SEQUENCE to IO_DEVICE_LIST[Device]."
    UpsertConfig wsConfig, "VFD_STO_BACKFILL_OVERWRITE", "YES", "NO", _
        "YES keeps STO source fields synchronized with IO_DEVICE_LIST."
    UpsertConfig wsConfig, "VFD_STO_MISSING_TEXT", "FROM- xxx", "NO", _
        "Text used when a VFD has no matching IO_DEVICE_LIST STO outputs."

    UpdateSTOBlockEditRule wsBlockEdit
    wsConfig.Columns("A:D").AutoFit

    MsgBox "ONGEN EAS V21.5 configuration was installed." & vbCrLf & vbCrLf & _
           "FROM arrows point left; TO arrows point right." & vbCrLf & _
           "Callout text starts 1.6 drawing units from its locator." & vbCrLf & _
           "STO uses STO_FROM_TEXT and does not create an arrow.", _
           vbInformation, "ONGEN EAS V21.5"

CleanExit:
    Application.Calculation = oldCalculation
    Application.EnableEvents = oldEnableEvents
    Application.ScreenUpdating = oldScreenUpdating
    Exit Sub
EH:
    MsgBox "The V21.5 configuration could not be installed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN EAS V21.5"
    Resume CleanExit
End Sub

Public Sub ONGEN_EAS_V21_5_VALIDATE_CONFIG()
    Dim ws As Worksheet
    Dim requiredKeys As Variant
    Dim item As Variant
    Dim missing As String

    On Error GoTo EH
    Set ws = ThisWorkbook.Worksheets(CONFIG_SHEET)

    requiredKeys = Array( _
        "FEED_HEADER_PREFIX", _
        "FEED_HEADER_SWITCHGROUP_PREFIX", _
        "LOCATOR_CALLOUTS_ENABLED", _
        "CALLOUT_LOCATOR_LAYER", _
        "LOCATOR_CALLOUT_TEXT_DISTANCE", _
        "VFD_STO_BACKFILL_ENABLED", _
        "VFD_STO_MISSING_TEXT")

    For Each item In requiredKeys
        If FindConfigRow(ws, CStr(item)) = 0 Then
            If Len(missing) > 0 Then missing = missing & vbCrLf
            missing = missing & CStr(item)
        End If
    Next item

    If Len(missing) = 0 Then
        MsgBox "The required V21.5 configuration keys are present.", _
               vbInformation, "ONGEN EAS V21.5"
    Else
        MsgBox "Missing configuration keys:" & vbCrLf & missing & vbCrLf & vbCrLf & _
               "Run ONGEN_EAS_V21_5_INSTALL_CONFIG.", _
               vbExclamation, "ONGEN EAS V21.5"
    End If
    Exit Sub
EH:
    MsgBox "Configuration validation failed." & vbCrLf & Err.description, _
           vbExclamation, "ONGEN EAS V21.5"
End Sub

Private Sub UpdateSTOBlockEditRule(ByVal ws As Worksheet)
    Dim lastRow As Long
    Dim rowNumber As Long

    lastRow = ws.Cells(ws.rows.count, 2).End(xlUp).Row
    For rowNumber = 5 To lastRow
        If StrComp(Trim$(CStr(ws.Cells(rowNumber, 2).Value2)), "HA1X3Y", vbTextCompare) = 0 Or _
           StrComp(Trim$(CStr(ws.Cells(rowNumber, 1).Value2)), "STO IN", vbTextCompare) = 0 Then
            ws.Cells(rowNumber, 1).Value2 = "STO IN"
            ws.Cells(rowNumber, 2).Value2 = "HA1X3Y"
            ws.Cells(rowNumber, 6).Value2 = "STO"
            ws.Cells(rowNumber, 7).Value2 = "STO_FROM_TEXT"
            Exit Sub
        End If
    Next rowNumber

    rowNumber = Application.Max(5, lastRow + 1)
    ws.Cells(rowNumber, 1).Value2 = "STO IN"
    ws.Cells(rowNumber, 2).Value2 = "HA1X3Y"
    ws.Cells(rowNumber, 6).Value2 = "STO"
    ws.Cells(rowNumber, 7).Value2 = "STO_FROM_TEXT"
End Sub

Private Sub UpsertConfig(ByVal ws As Worksheet, _
                         ByVal keyName As String, _
                         ByVal settingValue As Variant, _
                         ByVal requiredValue As String, _
                         ByVal descriptionValue As String)
    Dim targetRow As Long
    Dim templateRow As Long

    targetRow = FindConfigRow(ws, keyName)
    If targetRow = 0 Then
        targetRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row + 1
        templateRow = targetRow - 1
        If templateRow >= 2 Then
            ws.Range("A" & templateRow & ":D" & templateRow).Copy
            ws.Range("A" & targetRow & ":D" & targetRow).PasteSpecial xlPasteFormats
            Application.CutCopyMode = False
        End If
    End If

    ws.Cells(targetRow, 1).Value2 = keyName
    ws.Cells(targetRow, 2).Value2 = settingValue
    ws.Cells(targetRow, 3).Value2 = requiredValue
    ws.Cells(targetRow, 4).Value2 = descriptionValue
    ws.Range("A" & targetRow & ":D" & targetRow).WrapText = True
End Sub

Private Function FindConfigRow(ByVal ws As Worksheet, ByVal keyName As String) As Long
    Dim foundCell As Range

    Set foundCell = ws.Columns(1).Find( _
        What:=keyName, _
        After:=ws.Cells(1, 1), _
        LookIn:=xlValues, _
        LookAt:=xlWhole, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlNext, _
        MatchCase:=False)

    If foundCell Is Nothing Then
        FindConfigRow = 0
    Else
        FindConfigRow = foundCell.Row
    End If
End Function

