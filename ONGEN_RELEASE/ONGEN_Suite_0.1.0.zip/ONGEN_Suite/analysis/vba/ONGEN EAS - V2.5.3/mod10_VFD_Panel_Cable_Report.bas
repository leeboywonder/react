Attribute VB_Name = "mod10_VFD_Panel_Cable_Report"
Option Explicit
'===============================================================================
' ONGEN EAS - STRICT 480V PANEL CABLE REPORT
' Author: Lee Pierre, Principal Electrical Engineer
' Purpose: Permanent production module for the ONGEN Engineering Automation Suite.
'          This module is part of the V26.3 clean workflow baseline.
'===============================================================================



'===============================================================================
' ONGEN EAS - STRICT 480V DEVICE WIRE TAG REPORT
'
' Human-facing staging worksheet:
'   VFD DWG PANEL CABLE REPORT
'
' Automatic CSV:
'   480V devices WIRE TAG report <PANEL>.csv
'
' INCLUDED FAMILIES ONLY:
'   MPWR  RCP power-group branch to each 480V device
'   WPWR  other 480Vac device cable
'   WMTR  VFD-to-motor power cable
'
' EXCLUDED:
'   WIO / WSF / WNET / WDC
'
' MPWR branch rule:
'   one unique base ID per Area + RCP + PWG.
'   single-device group: MPWR-0001
'   multi-device group:  MPWR-0002.1, MPWR-0002.2, ...
'===============================================================================

Private Const SH_OUTPUT As String = "VFD DWG PANEL CABLE REPORT"
Private Const SH_CABLES As String = "CABLE_TAG_OUTPUT"
Private Const SH_QUEUE As String = "VFD_DWG_QUEUE"
Private Const SH_MPWR As String = "VFD DWG MPWR GROUPS"

Private Const OUT_PANEL As Long = 1
Private Const OUT_TAG As Long = 2
Private Const OUT_FROM As Long = 3
Private Const OUT_TO As Long = 4
Private Const OUT_AREA As Long = 5
Private Const OUT_REF As Long = 6
Private Const OUT_TYPE As Long = 7
Private Const OUT_PWG As Long = 8
Private Const OUT_SIS As Long = 9
Private Const OUT_SOURCE As Long = 10
Private Const OUT_KEY As Long = 11
Private Const OUT_REFRESHED As Long = 12

Public Sub VFD_DWG_REFRESH_PANEL_CABLE_REPORT_QUEUE()
    VFD480_Build False, True
End Sub

Public Sub VFD_DWG_REFRESH_PANEL_CABLE_REPORT_FULL()
    VFD480_Build True, True
End Sub

Public Sub VFD_DWG_PREPARE_PANEL_CABLE_REPORT_FOR_AUTOCAD()
    VFD480_Build False, False
End Sub

Public Sub VFD_DWG_UPGRADE_PANEL_CABLE_REPORT_EXISTING_WORKBOOK_ONLY()
    VFD480_Build False, True
End Sub

Public Sub VFD_DWG_Open_Panel_Cable_Report()
    Dim ws As Worksheet
    Set ws = VFD480_GetSheet(SH_OUTPUT)

    If ws Is Nothing Then
        VFD_DWG_REFRESH_PANEL_CABLE_REPORT_QUEUE
        Set ws = VFD480_GetSheet(SH_OUTPUT)
    End If

    If Not ws Is Nothing Then
        ws.Visible = xlSheetVisible
        ws.Activate
        ws.Range("A1").Select
    End If
End Sub

Public Sub VFD_DWG_DIAG_480V_REPORT()
    On Error GoTo FailHandler

    VFD480_Build False, False

    Dim ws As Worksheet
    Set ws = VFD480_GetSheet(SH_OUTPUT)

    Dim r As Long
    Dim family As String
    Dim mpwrCount As Long
    Dim wpwrCount As Long
    Dim wmtrCount As Long
    Dim badCount As Long

    For r = 2 To VFD480_LastRow(ws)
        family = VFD480_Family(VFD480_Value(ws, r, OUT_TAG))

        Select Case family
            Case "MPWR": mpwrCount = mpwrCount + 1
            Case "WPWR": wpwrCount = wpwrCount + 1
            Case "WMTR": wmtrCount = wmtrCount + 1
            Case Else
                If Len(family) > 0 Then badCount = badCount + 1
        End Select
    Next r

    MsgBox _
        "Strict 480V report staging" & vbCrLf & vbCrLf & _
        "MPWR device drops: " & mpwrCount & vbCrLf & _
        "WPWR: " & wpwrCount & vbCrLf & _
        "WMTR: " & wmtrCount & vbCrLf & _
        "Non-480V families found: " & badCount, _
        vbInformation, _
        "ONGEN 480V Report Diagnostic"
    Exit Sub

FailHandler:
    MsgBox "480V report diagnostic failed." & vbCrLf & Err.description, _
           vbCritical, "ONGEN 480V Report Diagnostic"
End Sub

Private Sub VFD480_Build(ByVal refreshPermanentTags As Boolean, ByVal ShowMessage As Boolean)
    On Error GoTo FailHandler

    Dim oldCalc As XlCalculation
    Dim oldEvents As Boolean
    Dim oldScreen As Boolean

    oldCalc = Application.Calculation
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    If refreshPermanentTags Then VFD480_RefreshCableTagsIfAvailable

    Dim wsCable As Worksheet
    Dim wsQueue As Worksheet
    Dim wsMPWR As Worksheet
    Dim wsOut As Worksheet

    Set wsCable = VFD480_GetSheet(SH_CABLES)
    Set wsQueue = VFD480_GetSheet(SH_QUEUE)
    Set wsMPWR = VFD480_GetSheet(SH_MPWR)
    Set wsOut = VFD480_EnsureOutputSheet()

    If wsMPWR Is Nothing Then
        Err.Raise vbObjectError + 4701, "VFD480_Build", _
                  "VFD DWG MPWR GROUPS was not found."
    End If

    Dim rows As Collection
    Dim seen As Object
    Set rows = New Collection
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    'MPWR is rebuilt exclusively from the canonical group map so suffix labels
    'cannot be replaced by stale base-only records from CABLE_TAG_OUTPUT.
    VFD480_CollectMPWRDeviceDrops wsMPWR, wsQueue, rows, seen

    If Not wsCable Is Nothing Then
        VFD480_CollectStrict480Families wsCable, wsQueue, rows, seen
    End If

    VFD480_WriteOutput wsOut, rows
    VFD480_FormatSheet wsOut

    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    If ShowMessage Then
        MsgBox _
            "VFD DWG PANEL CABLE REPORT refreshed." & vbCrLf & _
            "Strict 480V cable rows: " & rows.count & vbCrLf & _
            "Only MPWR / WPWR / WMTR are included.", _
            vbInformation, _
            "ONGEN 480V Device Report"
    End If
    Exit Sub

FailHandler:
    Dim n As Long
    Dim d As String
    n = Err.Number
    d = Err.description

    On Error Resume Next
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    If ShowMessage Then
        MsgBox "480V device report refresh failed." & vbCrLf & vbCrLf & _
               "Error " & n & ": " & d, vbCritical, "ONGEN 480V Device Report"
    Else
        If n = 0 Then n = vbObjectError + 4799
        Err.Raise n, "VFD_DWG_PREPARE_PANEL_CABLE_REPORT_FOR_AUTOCAD", d
    End If
End Sub

Private Sub VFD480_CollectMPWRDeviceDrops( _
    ByVal ws As Worksheet, _
    ByVal wsQueue As Worksheet, _
    ByVal rows As Collection, _
    ByVal seen As Object)

    Dim hr As Long
    hr = VFD480_FindHeaderRow(ws, Array("MPWR_LABEL_ID", "RCP_PANEL"))
    If hr = 0 Then Exit Sub

    Dim cBase As Long, cArea As Long, cPanel As Long, cSWG As Long
    Dim cSeq As Long, cStatus As Long, cTags As Long, cParent As Long

    cBase = VFD480_FindHeader(ws, hr, Array("MPWR_LABEL_ID"))
    cArea = VFD480_FindHeader(ws, hr, Array("AREA_NUMBER", "AREA NUMBER"))
    cPanel = VFD480_FindHeader(ws, hr, Array("RCP_PANEL", "RCP PANEL"))
    cSWG = VFD480_FindHeader(ws, hr, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cSeq = VFD480_FindHeader(ws, hr, Array("SIS_SEQUENCE", "SIS SEQUENCE"))
    cStatus = VFD480_FindHeader(ws, hr, Array("STATUS"))
    cTags = VFD480_FindHeader(ws, hr, Array("DEVICE_CABLE_TAGS", "DEVICE CABLE TAGS"))
    cParent = VFD480_FindHeader(ws, hr, Array("PARENT_CABLE_ID", "PARENT CABLE ID"))

    Dim r As Long
    Dim panelVal As String, areaVal As String, pwgVal As String
    Dim statusVal As String, baseID As String, parentID As String
    Dim seqList As String, tagList As String
    Dim devices As Variant, tags As Variant
    Dim deviceCount As Long, i As Long
    Dim refVal As String

    For r = hr + 1 To VFD480_LastRow(ws)
        panelVal = VFD480_Value(ws, r, cPanel)
        statusVal = UCase$(VFD480_Value(ws, r, cStatus))
        baseID = VFD480_Value(ws, r, cBase)

        If VFD480_IsRCP(panelVal) And _
           VFD480_Family(baseID) = "MPWR" And _
           InStr(1, statusVal, "SPARE", vbTextCompare) = 0 Then

            areaVal = VFD480_Value(ws, r, cArea)
            pwgVal = VFD480_NormalizePWG(VFD480_Value(ws, r, cSWG))
            seqList = VFD480_Value(ws, r, cSeq)
            tagList = VFD480_Value(ws, r, cTags)
            parentID = VFD480_Value(ws, r, cParent)
            If Len(parentID) = 0 Then parentID = baseID

            devices = VFD480_SplitNonBlank(seqList)
            tags = VFD480_SplitNonBlank(tagList)
            deviceCount = VFD480_ArrayCount(devices)
            refVal = VFD480_FindMPWRReferenceSheet(wsQueue, panelVal)

            'Parent/trunk cable always exists as its own record.
            VFD480_Add rows, seen, panelVal, parentID, _
                       panelVal & " " & pwgVal, "480V POWER GROUP TRUNK", _
                       areaVal, refVal, "MPWR PARENT", pwgVal, _
                       vbNullString, SH_MPWR

            If VFD480_ArrayCount(tags) <> deviceCount Then
                tags = VFD480_BuildChildTagsFromBase(parentID, deviceCount)
            End If

            For i = 0 To deviceCount - 1
                VFD480_Add rows, seen, panelVal, _
                           CStr(tags(LBound(tags) + i)), _
                           parentID, _
                           CStr(devices(LBound(devices) + i)), _
                           areaVal, refVal, "MPWR CHILD", pwgVal, _
                           CStr(devices(LBound(devices) + i)), SH_MPWR
            Next i
        End If
    Next r
End Sub

Private Sub VFD480_CollectStrict480Families( _
    ByVal ws As Worksheet, _
    ByVal wsQueue As Worksheet, _
    ByVal rows As Collection, _
    ByVal seen As Object)

    Dim hr As Long
    hr = VFD480_FindHeaderRow(ws, Array("LABEL ID", "TAG"))
    If hr = 0 Then Exit Sub

    Dim cTag As Long, cPanel As Long, cFrom As Long, cTo As Long
    Dim cArea As Long, cRef As Long, cType As Long, cSWG As Long, cSource As Long

    cTag = VFD480_FindHeader(ws, hr, Array("LABEL ID", "CABLE_ID", "TAG"))
    cPanel = VFD480_FindHeader(ws, hr, Array("PANEL", "PNL", "RCP_PANEL"))
    cFrom = VFD480_FindHeader(ws, hr, Array("FROM", "FROM ENDPOINT", "SOURCE"))
    cTo = VFD480_FindHeader(ws, hr, Array("TO", "TO ENDPOINT", "DESTINATION"))
    cArea = VFD480_FindHeader(ws, hr, Array("AREA", "AREA NUMBER", "AREA_NUMBER"))
    cRef = VFD480_FindHeader(ws, hr, Array("REFERENCE SHEET", "SOURCE SHEET", "SHEET"))
    cType = VFD480_FindHeader(ws, hr, Array("TYPE CODE", "CABLE_TYPE", "TYPE"))
    cSWG = VFD480_FindHeader(ws, hr, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cSource = VFD480_FindHeader(ws, hr, Array("SOURCE DATA SHEET", "SOURCE_SHEET"))

    Dim r As Long
    Dim tagVal As String, family As String, panelVal As String

    For r = hr + 1 To VFD480_LastRow(ws)
        tagVal = VFD480_Value(ws, r, cTag)
        family = VFD480_Family(tagVal)

        If family = "WPWR" Or family = "WMTR" Then
            panelVal = VFD480_Value(ws, r, cPanel)

            If VFD480_IsRCP(panelVal) Then
                VFD480_Add rows, seen, panelVal, tagVal, _
                    VFD480_Value(ws, r, cFrom), _
                    VFD480_Value(ws, r, cTo), _
                    VFD480_Value(ws, r, cArea), _
                    VFD480_Value(ws, r, cRef), _
                    family, _
                    VFD480_NormalizePWG(VFD480_Value(ws, r, cSWG)), _
                    vbNullString, _
                    VFD480_Value(ws, r, cSource)
            End If
        End If
    Next r
End Sub

Private Sub VFD480_Add( _
    ByVal rows As Collection, ByVal seen As Object, _
    ByVal panelVal As String, ByVal tagVal As String, _
    ByVal fromVal As String, ByVal toVal As String, _
    ByVal areaVal As String, ByVal refVal As String, _
    ByVal typeVal As String, ByVal pwgVal As String, _
    ByVal sisVal As String, ByVal sourceVal As String)

    panelVal = Trim$(panelVal)
    tagVal = Trim$(tagVal)

    If Len(panelVal) = 0 Or Len(tagVal) = 0 Then Exit Sub

    Dim key As String
    key = UCase$(panelVal & "|" & tagVal)

    If seen.Exists(key) Then Exit Sub
    seen.Add key, True

    rows.Add Array(panelVal, tagVal, fromVal, toVal, areaVal, refVal, _
                   typeVal, pwgVal, sisVal, sourceVal, key, Now)
End Sub

Private Function VFD480_FindMPWRReferenceSheet(ByVal wsQueue As Worksheet, ByVal panelVal As String) As String
    If wsQueue Is Nothing Then
        VFD480_FindMPWRReferenceSheet = "MPWR"
        Exit Function
    End If

    Dim hr As Long
    hr = VFD480_FindHeaderRow(wsQueue, Array("DRAWING_ID", "PAGE_CODE"))
    If hr = 0 Then
        VFD480_FindMPWRReferenceSheet = "MPWR"
        Exit Function
    End If

    Dim cPage As Long, cPanel As Long, cPlan As Long, cSheet As Long
    cPage = VFD480_FindHeader(wsQueue, hr, Array("PAGE_CODE"))
    cPanel = VFD480_FindHeader(wsQueue, hr, Array("PANEL"))
    cPlan = VFD480_FindHeader(wsQueue, hr, Array("PLAN_ID"))
    cSheet = VFD480_FindHeader(wsQueue, hr, Array("SHEET_NUMBER"))

    Dim r As Long
    For r = hr + 1 To VFD480_LastRow(wsQueue)
        If UCase$(VFD480_Value(wsQueue, r, cPage)) = "MPWR" And _
           StrComp(VFD480_Value(wsQueue, r, cPanel), panelVal, vbTextCompare) = 0 And _
           StrComp(VFD480_Value(wsQueue, r, cPlan), "PANEL_MPWR_2", vbTextCompare) = 0 Then

            VFD480_FindMPWRReferenceSheet = VFD480_Value(wsQueue, r, cSheet)
            Exit Function
        End If
    Next r

    VFD480_FindMPWRReferenceSheet = "MPWR"
End Function

Private Function VFD480_BuildChildTagsFromBase(ByVal baseID As String, ByVal count As Long) As Variant
    If count <= 0 Then
        VFD480_BuildChildTagsFromBase = Array()
        Exit Function
    End If

    Dim arr() As String
    Dim i As Long
    ReDim arr(0 To count - 1)

    For i = 0 To count - 1
        arr(i) = baseID & "." & CStr(i + 1)
    Next i

    VFD480_BuildChildTagsFromBase = arr
End Function

Private Function VFD480_SplitNonBlank(ByVal value As String) As Variant
    Dim coll As Collection
    Set coll = New Collection

    Dim part As Variant
    For Each part In Split(value, "|")
        If Len(Trim$(CStr(part))) > 0 Then coll.Add Trim$(CStr(part))
    Next part

    If coll.count = 0 Then
        VFD480_SplitNonBlank = Array()
        Exit Function
    End If

    Dim arr() As String
    Dim i As Long
    ReDim arr(0 To coll.count - 1)

    For i = 1 To coll.count
        arr(i - 1) = CStr(coll(i))
    Next i

    VFD480_SplitNonBlank = arr
End Function

Private Function VFD480_ArrayCount(ByVal arr As Variant) As Long
    On Error GoTo EmptyArray
    VFD480_ArrayCount = UBound(arr) - LBound(arr) + 1
    Exit Function
EmptyArray:
    VFD480_ArrayCount = 0
End Function

Private Sub VFD480_RefreshCableTagsIfAvailable()
    On Error Resume Next
    Application.Run "'" & ThisWorkbook.Name & "'!Build_ONGEN_Combined_Label_List"
    On Error GoTo 0
End Sub

Private Function VFD480_EnsureOutputSheet() As Worksheet
    Dim ws As Worksheet
    Set ws = VFD480_GetSheet(SH_OUTPUT)

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = SH_OUTPUT
    End If

    VFD480_EnsureHeaders ws
    Set VFD480_EnsureOutputSheet = ws
End Function

Private Sub VFD480_EnsureHeaders(ByVal ws As Worksheet)
    Dim h As Variant
    h = Array("PANEL", "TAG", "FROM", "TO", "AREA_LOCATION", _
              "REFERENCE_SHEET", "CABLE_TYPE", "PWG", "SIS_SEQUENCE", _
              "SOURCE", "SOURCE_KEY", "LAST_REFRESHED")

    Dim i As Long
    For i = LBound(h) To UBound(h)
        ws.Cells(1, i + 1).Value2 = h(i)
    Next i
End Sub

Private Sub VFD480_WriteOutput(ByVal ws As Worksheet, ByVal rows As Collection)
    VFD480_EnsureHeaders ws

    Dim lastOld As Long
    lastOld = VFD480_LastRow(ws)

    If lastOld >= 2 Then
        ws.Range(ws.Cells(2, 1), ws.Cells(lastOld, OUT_REFRESHED)).ClearContents
    End If

    If rows.count = 0 Then Exit Sub

    Dim arr() As Variant
    ReDim arr(1 To rows.count, 1 To OUT_REFRESHED)

    Dim i As Long, c As Long, rec As Variant
    For i = 1 To rows.count
        rec = rows(i)
        For c = 0 To UBound(rec)
            arr(i, c + 1) = rec(c)
        Next c
    Next i

    ws.Range(ws.Cells(2, 1), ws.Cells(rows.count + 1, OUT_REFRESHED)).value = arr
End Sub

Private Function VFD480_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set VFD480_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function VFD480_FindHeaderRow(ByVal ws As Worksheet, ByVal aliases As Variant) As Long
    Dim maxRow As Long
    maxRow = Application.Min(20, Application.Max(1, ws.UsedRange.rows.count))

    Dim r As Long
    For r = 1 To maxRow
        If VFD480_FindHeader(ws, r, aliases) > 0 Then
            VFD480_FindHeaderRow = r
            Exit Function
        End If
    Next r
End Function

Private Function VFD480_FindHeader(ByVal ws As Worksheet, ByVal hr As Long, ByVal aliases As Variant) As Long
    If hr <= 0 Then Exit Function

    Dim lastCol As Long
    lastCol = ws.Cells(hr, ws.Columns.count).End(xlToLeft).Column

    Dim c As Long, a As Variant, key As String
    For c = 1 To lastCol
        key = VFD480_HeaderKey(ws.Cells(hr, c).Value2)
        For Each a In aliases
            If key = VFD480_HeaderKey(CStr(a)) Then
                VFD480_FindHeader = c
                Exit Function
            End If
        Next a
    Next c
End Function

Private Function VFD480_HeaderKey(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(v)))
    s = Replace$(s, "_", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "-", "")
    s = Replace$(s, "/", "")
    s = Replace$(s, ".", "")
    s = Replace$(s, "(", "")
    s = Replace$(s, ")", "")
    VFD480_HeaderKey = s
End Function

Private Function VFD480_Value(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c <= 0 Then Exit Function
    If IsError(ws.Cells(r, c).Value2) Then Exit Function
    VFD480_Value = Trim$(CStr(ws.Cells(r, c).Value2))
End Function

Private Function VFD480_LastRow(ByVal ws As Worksheet) As Long
    On Error GoTo SafeExit

    Dim f As Range
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                          LookAt:=xlPart, SearchOrder:=xlByRows, _
                          SearchDirection:=xlPrevious, MatchCase:=False)

    If Not f Is Nothing Then VFD480_LastRow = f.Row
    Exit Function

SafeExit:
    VFD480_LastRow = 0
End Function

Private Function VFD480_Family(ByVal tagVal As String) As String
    Dim s As String
    s = UCase$(Trim$(tagVal))

    If InStr(1, s, "-", vbTextCompare) > 0 Then
        VFD480_Family = Left$(s, InStr(1, s, "-", vbTextCompare) - 1)
    Else
        VFD480_Family = s
    End If
End Function

Private Function VFD480_IsRCP(ByVal panelVal As String) As Boolean
    VFD480_IsRCP = (Left$(UCase$(Trim$(panelVal)), 3) = "RCP")
End Function

Private Function VFD480_NormalizePWG(ByVal value As String) As String
    Dim s As String
    s = UCase$(Trim$(value))
    If Len(s) = 0 Then Exit Function
    If Left$(s, 3) = "PWG" Then
        VFD480_NormalizePWG = s
    Else
        VFD480_NormalizePWG = "PWG" & s
    End If
End Function

Private Sub VFD480_FormatSheet(ByVal ws As Worksheet)
    On Error Resume Next
    With ws
        .rows(1).Font.Bold = True
        .rows(1).Interior.Color = RGB(31, 78, 121)
        .rows(1).Font.Color = RGB(255, 255, 255)
        .Columns("A:L").AutoFit
        .Columns("L").NumberFormat = "yyyy-mm-dd hh:mm:ss"
        If .AutoFilterMode Then .AutoFilterMode = False
        .Range(.Cells(1, 1), .Cells(1, OUT_REFRESHED)).AutoFilter
    End With
    On Error GoTo 0
End Sub
