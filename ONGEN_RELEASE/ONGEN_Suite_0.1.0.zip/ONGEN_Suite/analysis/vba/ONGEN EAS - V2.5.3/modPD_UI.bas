Attribute VB_Name = "modPD_UI"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : modPD_UI
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : modPD_UI
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Static procedure, declaration, and public-name audit completed.
' Notes         : Logic retained from the uploaded workbook; comments preserved and suite header standardized.
'-------------------------------------------------------------------------------

' [R7 LINE] Requires explicit variable declarations to prevent misspelled variables.
Option Explicit

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R7
' Module Version  : modPD_UI V1.2
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

'This module owns the worksheet launcher support. The launcher now lists every
'normal workbook worksheet, recognizes all current ONGEN workflow sheets, and
'opens hidden sheets safely without leaving a modal form blocking Excel.

' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const UI_HOME_SHEET As String = "MAIN"

' [R7 LINE] Starts Sub UI_ShowLauncher; the following statements perform or calculate this named workflow.
Public Sub UI_ShowLauncher()
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo EH

    'Unload a stale form instance so initialization always rebuilds the list.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    Unload frmPDLauncher
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo EH

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    frmPDLauncher.Show vbModal
    ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
    Exit Sub
' [R7 LINE] Defines a named execution label used by normal cleanup or error handling.
EH:
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    MsgBox "The worksheet launcher could not be opened." & vbCrLf & _
           "Keep the existing frmPDLauncher controls and paste the supplied R7 form code." & _
           vbCrLf & Err.description, vbExclamation, "ONGEN Worksheet Launcher"
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub UI_ResetMainWorksheet; the following statements perform or calculate this named workflow.
Public Sub UI_ResetMainWorksheet()
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo EH
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Run "'" & ThisWorkbook.Name & _
                    "'!Step00_Create_MAIN_Buttons_And_ProgressBar"
    ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
    Exit Sub
' [R7 LINE] Defines a named execution label used by normal cleanup or error handling.
EH:
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    MsgBox "The MAIN worksheet could not be rebuilt." & vbCrLf & _
           "Confirm mod00_UI_Buttons_ProgressBar is installed." & vbCrLf & _
           Err.description, vbCritical, "Reset MAIN"
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub UI_GoHome; the following statements perform or calculate this named workflow.
Public Sub UI_GoHome()
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not UI_WorksheetExists(UI_HOME_SHEET) Then UI_ResetMainWorksheet
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    UI_OpenWorksheetByName UI_HOME_SHEET
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub UI_RefreshAll; the following statements perform or calculate this named workflow.
Public Sub UI_RefreshAll()
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim oldCalc As XlCalculation
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim oldEvents As Boolean, oldScreen As Boolean

    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo EH
    ' [R7 LINE] Calculates or updates oldCalc using the expression in this statement.
    oldCalc = Application.Calculation
    ' [R7 LINE] Calculates or updates oldEvents using the expression in this statement.
    oldEvents = Application.EnableEvents
    ' [R7 LINE] Calculates or updates oldScreen using the expression in this statement.
    oldScreen = Application.ScreenUpdating

    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.ScreenUpdating = False
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.EnableEvents = False
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Calculation = xlCalculationManual
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ThisWorkbook.RefreshAll
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.CalculateFullRebuild

' [R7 LINE] Defines a named execution label used by normal cleanup or error handling.
CleanExit:
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Calculation = oldCalc
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.EnableEvents = oldEvents
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.ScreenUpdating = oldScreen
    ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
    Exit Sub
' [R7 LINE] Defines a named execution label used by normal cleanup or error handling.
EH:
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    MsgBox "Refresh completed with an issue:" & vbCrLf & Err.description, _
           vbExclamation, "Workbook Refresh"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    Resume CleanExit
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function UI_WorksheetExists; the following statements perform or calculate this named workflow.
Public Function UI_WorksheetExists(ByVal sheetName As String) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim ws As Worksheet
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
    Set ws = ThisWorkbook.Worksheets(sheetName)
    ' [R7 LINE] Calculates or updates UI_WorksheetExists using the expression in this statement.
    UI_WorksheetExists = Not ws Is Nothing
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function UI_IsWorkflowSheet; the following statements perform or calculate this named workflow.
Public Function UI_IsWorkflowSheet(ByVal sheetName As String) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim n As String
    ' [R7 LINE] Calculates or updates n using the expression in this statement.
    n = Trim$(sheetName)

    'The launcher is intended to be dynamic. Every normal named worksheet is listed;
    'only underscore-prefixed internal/temp sheets are intentionally excluded.
    ' [R7 LINE] Calculates or updates UI_IsWorkflowSheet using the expression in this statement.
    UI_IsWorkflowSheet = (Len(n) > 0 And Left$(n, 1) <> "_")
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function UI_GetWorkflowGroup; the following statements perform or calculate this named workflow.
Public Function UI_GetWorkflowGroup(ByVal sheetName As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim n As String
    ' [R7 LINE] Calculates or updates n using the expression in this statement.
    n = UCase$(Trim$(sheetName))

    ' [R7 LINE] Chooses a processing branch based on the current value.
    Select Case n
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "MAIN"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "00 - HOME / CONTROL"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "DATA", "DATA_POWER", "DATA_IO_BLOCK", "480V_DATA_POWER", _
             "FUNCTION DEFINITION", "FUNCTION DEVICE PD2"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "01 - SOURCE DATA"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "PD6_IMPORT", "IO_DEVICE_LIST", "SIS_TAG_IMPORT_PD2", "SIS_TAG_PD5"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "02 - IMPORT / DEVICE DATA"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "IO_BLOCK_GENERATOR"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "03 - BECKHOFF IO"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "24V_POWER GENERATOR"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "04 - 24V POWER"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "VFD_480V_GENERATOR", "VFD_DWG_CONFIG", "VFD_DWG_QUEUE", _
             "VFD_DWG_CIRCUIT_LIBRARY", "VFD_DWG_DEVICE_LIBRARY", _
             "VFD_DWG_DEVICE_PLACEMENT", "VFD_DWG_ATTRIBUTE_MAP", "LP_DEVICE_LOCATORS"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "05 - 480V / VFD DRAWING"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "IO_ROUTE_CONFIG", "24V_ROUTE_INDEX", "NETWORK_ROUTE_INDEX", _
             "IO_ROUTE_MASTER", "IO_ROUTE_ERRORS"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "06 - ROUTE ECOSYSTEM"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "VALIDATION", "UI_BUTTON_AUDIT"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "07 - VALIDATION / STATUS"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "PROCESS_LOG", "EXPORT_LOG"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "08 - LOGS"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "NETWORK_AUTO_SUMMARY", "NETWORK_AUTO_EXCLUDED", "AREA_NETWORK_SWITCH_MAP"
            ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
            UI_GetWorkflowGroup = "10 - NETWORK / RCP MAP"
        ' [R7 LINE] Handles values not matched by the preceding Case branches.
        Case Else
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Left$(n, 4) = "24V_" Then
                ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
                UI_GetWorkflowGroup = "09 - GENERATED 24V PANELS"
            ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
            ElseIf Left$(n, 4) = "RCP-" Or _
                   InStr(1, n, "CLEAN", vbTextCompare) > 0 Or _
                   InStr(1, n, "TOPOLOGY", vbTextCompare) > 0 Or _
                   InStr(1, n, "NETWORK", vbTextCompare) > 0 Then
                ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
                UI_GetWorkflowGroup = "10 - NETWORK / RCP MAP"
            ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
            Else
                ' [R7 LINE] Calculates or updates UI_GetWorkflowGroup using the expression in this statement.
                UI_GetWorkflowGroup = "11 - OTHER WORKSHEETS"
            ' [R7 LINE] Ends the current conditional block.
            End If
    ' [R7 LINE] Ends the current Select Case block.
    End Select
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub UI_OpenWorksheetByName; the following statements perform or calculate this named workflow.
Public Sub UI_OpenWorksheetByName(ByVal sheetName As String)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim ws As Worksheet
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo EH

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not UI_WorksheetExists(sheetName) Then
        ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
        MsgBox "Worksheet '" & sheetName & "' was not found.", _
               vbExclamation, "ONGEN Workbook Launcher"
        ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
        Exit Sub
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
    Set ws = ThisWorkbook.Worksheets(sheetName)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If ThisWorkbook.ProtectStructure And ws.Visible <> xlSheetVisible Then
        ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
        MsgBox "Worksheet '" & sheetName & "' is hidden and the workbook structure is protected.", _
               vbExclamation, "ONGEN Workbook Launcher"
        ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
        Exit Sub
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates ws.Visible using the expression in this statement.
    ws.Visible = xlSheetVisible
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ThisWorkbook.Activate
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Activate
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.GoTo ws.Range("A1"), True
    ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
    Exit Sub
' [R7 LINE] Defines a named execution label used by normal cleanup or error handling.
EH:
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    MsgBox "The worksheet could not be opened:" & vbCrLf & _
           sheetName & vbCrLf & Err.description, vbExclamation, "ONGEN Workbook Launcher"
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

