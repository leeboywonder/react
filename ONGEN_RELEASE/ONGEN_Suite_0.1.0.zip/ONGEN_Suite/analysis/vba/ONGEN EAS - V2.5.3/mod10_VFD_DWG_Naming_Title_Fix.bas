Attribute VB_Name = "mod10_VFD_DWG_Naming_Title_Fix"
Option Explicit
'===============================================================================
' ONGEN EAS - VFD DRAWING NAMING / TITLE NORMALIZER
' Author: Lee Pierre, Principal Electrical Engineer
' Purpose: Permanent production module for the ONGEN Engineering Automation Suite.
'          This module is part of the V26.3 clean workflow baseline.
'===============================================================================



'===============================================================================
' ONGEN EAS - VFD PWR / IO SHEET NUMBER, DWG NAME, AND T2 REPAIR
'
' PURPOSE
'   Repairs an EXISTING VFD_DWG_QUEUE without rebuilding VFD_480V_Generator,
'   VFD_DWG_QUEUE, or any existing cable-ID registry/output.
'
' REQUIRED OUTPUT EXAMPLES
'   PWR-001 VFD Power Circuit 9025-VFD PWG451.dwg
'   IO-001 VFD IO circuit 9025-VFD PWG451.dwg
'
' REQUIRED TITLE BLOCK T2 (DRAWING_DESCRIPTION)
'   VFD Power PWG451: 9025-VFD-K7
'   VFD IO PWG451: 9025-VFD-K7
'
' IMPORTANT
'   DRAWING_ID remains the verbose internal selector/key.  This module repairs
'   SHEET_NUMBER + OUTPUT_DWG_NAME + DRAWING_DESCRIPTION only.
'===============================================================================

Private Const SH_QUEUE As String = "VFD_DWG_QUEUE"
Private Const SH_ATTRMAP As String = "VFD_DWG_ATTRIBUTE_MAP"

Public Sub VFD_DWG_FIX_EXISTING_QUEUE_NAMING()
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = VFD_Name_GetSheet(SH_QUEUE)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 2451, "VFD_DWG_FIX_EXISTING_QUEUE_NAMING", _
                  "VFD_DWG_QUEUE does not exist. Run the normal VFD queue workflow once, then run this repair macro."
    End If

    Dim oldScreen As Boolean, oldEvents As Boolean, oldCalc As XlCalculation
    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    oldCalc = Application.Calculation

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Dim map As Object
    Set map = VFD_Name_HeaderMap(ws)

    Dim cDrawing As Long, cPage As Long, cSheet As Long, cOutput As Long
    Dim cSeq As Long, cElem As Long, cSWG As Long, cArea As Long, cDesc As Long
    cDrawing = VFD_Name_Col(map, "DRAWING_ID")
    cPage = VFD_Name_Col(map, "PAGE_CODE")
    cSheet = VFD_Name_Col(map, "SHEET_NUMBER")
    cOutput = VFD_Name_Col(map, "OUTPUT_DWG_NAME")
    cSeq = VFD_Name_Col(map, "SIS_SEQUENCE")
    cElem = VFD_Name_Col(map, "SIS_ELEMENT_NUMBER")
    cSWG = VFD_Name_Col(map, "SWITCHGROUP")
    cArea = VFD_Name_Col(map, "AREA_NUMBER")
    cDesc = VFD_Name_Col(map, "DRAWING_DESCRIPTION")

    If cDrawing = 0 Or cPage = 0 Or cSheet = 0 Or cOutput = 0 Or cSeq = 0 Or cSWG = 0 Or cDesc = 0 Then
        Err.Raise vbObjectError + 2452, "VFD_DWG_FIX_EXISTING_QUEUE_NAMING", _
                  "VFD_DWG_QUEUE is missing one or more required headers."
    End If

    Dim counters As Object
    Set counters = CreateObject("Scripting.Dictionary")
    counters.CompareMode = vbTextCompare

    Dim lastRow As Long, r As Long, changed As Long
    Dim pageCode As String, areaVal As String, drawingID As String
    Dim oldSheet As String, sheetNo As String, seq As String, elem As String
    Dim pwg As String, vfdRef As String, fileDesc As String, title2 As String
    Dim counterKey As String

    lastRow = VFD_Name_LastRow(ws)
    For r = 2 To lastRow
        pageCode = UCase$(Trim$(CStr(ws.Cells(r, cPage).Value2)))
        If pageCode = "PWR" Or pageCode = "IO" Then
            areaVal = Trim$(CStr(ws.Cells(r, cArea).Value2))
            drawingID = Trim$(CStr(ws.Cells(r, cDrawing).Value2))
            oldSheet = Trim$(CStr(ws.Cells(r, cSheet).Value2))

            counterKey = UCase$(areaVal) & "|" & pageCode
            sheetNo = VFD_Name_CanonicalSheet(pageCode, oldSheet, drawingID, _
                                               Trim$(CStr(ws.Cells(r, cOutput).Value2)))
            If Len(sheetNo) = 0 Then
                If Not counters.Exists(counterKey) Then counters.Add counterKey, 0
                counters(counterKey) = CLng(counters(counterKey)) + 1
                sheetNo = pageCode & "-" & Format$(CLng(counters(counterKey)), "000")
            Else
                VFD_Name_AdvanceCounter counters, counterKey, sheetNo
            End If

            seq = VFD_Name_Sequence(Trim$(CStr(ws.Cells(r, cSeq).Value2)))
            elem = ""
            If cElem > 0 Then elem = Trim$(CStr(ws.Cells(r, cElem).Value2))
            pwg = VFD_Name_PWG(Trim$(CStr(ws.Cells(r, cSWG).Value2)))
            vfdRef = VFD_Name_VFDReference(seq, elem)

            If pageCode = "PWR" Then
                fileDesc = VFD_Name_CollapseSpaces("VFD Power Circuit " & seq & " " & pwg)
                title2 = VFD_Name_CollapseSpaces("VFD Power " & pwg & ": " & vfdRef)
            Else
                fileDesc = VFD_Name_CollapseSpaces("VFD IO circuit " & seq & " " & pwg)
                title2 = VFD_Name_CollapseSpaces("VFD IO " & pwg & ": " & vfdRef)
            End If

            ws.Cells(r, cSheet).Value2 = sheetNo
            ws.Cells(r, cOutput).Value2 = sheetNo & " " & fileDesc & ".dwg"
            ws.Cells(r, cDesc).Value2 = title2
            changed = changed + 1
        End If
    Next r

    VFD_Name_EnsureAttributeMap

    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    MsgBox CStr(changed) & " existing PWR/IO queue row(s) repaired." & vbCrLf & vbCrLf & _
           "The macro did NOT rebuild VFD_DWG_QUEUE and did NOT regenerate existing cable IDs.", _
           vbInformation, "ONGEN VFD Naming / T2 Repair"
    Exit Sub
EH:
    On Error Resume Next
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0
    MsgBox "VFD queue naming repair failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD Naming / T2 Repair"
End Sub

Public Sub VFD_DWG_REPAIR_EXISTING_WORKBOOK_NO_REBUILD()
    'Convenience command for an existing workbook:
    '  1) repair current PWR/IO names and T2 text
    '  2) upgrade/refresh only the MPWR group mapping sheet
    '  3) create/refresh VFD DWG PANEL CABLE REPORT from CURRENT cable-tag output
    'No VFD queue rebuild and no cable-ID registry renumbering is performed.
    VFD_DWG_FIX_EXISTING_QUEUE_NAMING
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!VFD_MPWR_UPGRADE_EXISTING_WORKBOOK_ONLY"
    Application.Run "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!VFD_DWG_UPGRADE_PANEL_CABLE_REPORT_EXISTING_WORKBOOK_ONLY"
    On Error GoTo 0
End Sub

Private Function VFD_Name_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set VFD_Name_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function VFD_Name_HeaderMap(ByVal ws As Worksheet) As Object
    Dim d As Object: Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    Dim lastCol As Long, c As Long, key As String
    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lastCol
        key = UCase$(Trim$(CStr(ws.Cells(1, c).Value2)))
        If Len(key) > 0 Then d(key) = c
    Next c
    Set VFD_Name_HeaderMap = d
End Function

Private Function VFD_Name_Col(ByVal map As Object, ByVal key As String) As Long
    If map.Exists(key) Then VFD_Name_Col = CLng(map(key))
End Function

Private Function VFD_Name_LastRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                          LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then VFD_Name_LastRow = 1 Else VFD_Name_LastRow = f.Row
End Function

Private Function VFD_Name_CanonicalSheet(ByVal pageCode As String, ByVal sheetValue As String, _
                                         ByVal drawingID As String, ByVal outputName As String) As String
    Dim s As String, d As String, o As String, suffix As String, stem As String, token As String
    s = UCase$(Trim$(sheetValue))
    d = UCase$(Trim$(drawingID))
    o = UCase$(Trim$(outputName))

    If VFD_Name_IsCanonical(pageCode, s) Then
        VFD_Name_CanonicalSheet = Left$(s, Len(pageCode) + 4)
        Exit Function
    End If
    If VFD_Name_IsCanonical(pageCode, o) Then
        VFD_Name_CanonicalSheet = Left$(o, Len(pageCode) + 4)
        Exit Function
    End If

    suffix = "-" & pageCode
    If Len(d) > Len(suffix) And Right$(d, Len(suffix)) = suffix Then
        stem = Left$(d, Len(d) - Len(suffix))
        token = mid$(stem, InStrRev(stem, "-") + 1)
        If Len(token) = 3 And IsNumeric(token) Then
            VFD_Name_CanonicalSheet = pageCode & "-" & Format$(CLng(token), "000")
        End If
    End If
End Function

Private Function VFD_Name_IsCanonical(ByVal pageCode As String, ByVal value As String) As Boolean
    Dim prefix As String, numText As String
    prefix = UCase$(pageCode) & "-"
    value = UCase$(Trim$(value))
    If Left$(value, Len(prefix)) <> prefix Then Exit Function
    If Len(value) < Len(prefix) + 3 Then Exit Function
    numText = mid$(value, Len(prefix) + 1, 3)
    VFD_Name_IsCanonical = IsNumeric(numText)
End Function

Private Sub VFD_Name_AdvanceCounter(ByVal counters As Object, ByVal key As String, ByVal sheetNo As String)
    Dim n As Long
    On Error Resume Next
    n = CLng(mid$(sheetNo, InStrRev(sheetNo, "-") + 1, 3))
    On Error GoTo 0
    If Not counters.Exists(key) Then counters.Add key, n Else If n > CLng(counters(key)) Then counters(key) = n
End Sub

Private Function VFD_Name_Sequence(ByVal sequence As String) As String
    sequence = Trim$(sequence)
    If Len(sequence) = 0 Then Exit Function
    If UCase$(Right$(sequence, 4)) = "-VFD" Then
        VFD_Name_Sequence = sequence
    Else
        VFD_Name_Sequence = sequence & "-VFD"
    End If
End Function

Private Function VFD_Name_PWG(ByVal swg As String) As String
    Dim u As String
    swg = Trim$(swg): u = UCase$(swg)
    If Len(swg) = 0 Then Exit Function
    If Left$(u, 3) = "PWG" Then
        VFD_Name_PWG = swg
    ElseIf Left$(u, 3) = "SWG" Then
        VFD_Name_PWG = "PWG" & mid$(swg, 4)
    Else
        If Right$(swg, 2) = ".0" And IsNumeric(swg) Then swg = CStr(CLng(CDbl(swg)))
        VFD_Name_PWG = "PWG" & swg
    End If
End Function

Private Function VFD_Name_VFDReference(ByVal sequence As String, ByVal elementNumber As String) As String
    Dim p As Long, suffix As String
    If Len(sequence) = 0 Then Exit Function
    If InStr(1, UCase$(sequence), "-K", vbTextCompare) > 0 Then
        VFD_Name_VFDReference = sequence
        Exit Function
    End If
    p = InStrRev(UCase$(elementNumber), "-K")
    If p > 0 Then
        suffix = mid$(elementNumber, p)
        VFD_Name_VFDReference = sequence & suffix
    Else
        VFD_Name_VFDReference = sequence
    End If
End Function

Private Function VFD_Name_CollapseSpaces(ByVal text As String) As String
    text = Trim$(text)
    Do While InStr(text, "  ") > 0
        text = Replace(text, "  ", " ")
    Loop
    text = Replace(text, " :", ":")
    VFD_Name_CollapseSpaces = text
End Function

Private Sub VFD_Name_EnsureAttributeMap()
    Dim ws As Worksheet
    Set ws = VFD_Name_GetSheet(SH_ATTRMAP)
    If ws Is Nothing Then Exit Sub

    Dim map As Object: Set map = VFD_Name_HeaderMap(ws)
    Dim cEnabled As Long, cScope As Long, cPattern As Long, cTag As Long, cSource As Long
    cEnabled = VFD_Name_Col(map, "ENABLED")
    cScope = VFD_Name_Col(map, "SCOPE")
    cPattern = VFD_Name_Col(map, "TARGET_BLOCK_PATTERN")
    cTag = VFD_Name_Col(map, "ATTRIBUTE_TAG")
    cSource = VFD_Name_Col(map, "SOURCE_HEADER")
    If cScope = 0 Or cTag = 0 Or cSource = 0 Then Exit Sub

    VFD_Name_EnsureMapRow ws, cEnabled, cScope, cPattern, cTag, cSource, "SHEET_NUMBER", "SHEET_NUMBER"
    VFD_Name_EnsureMapRow ws, cEnabled, cScope, cPattern, cTag, cSource, "SHT", "SHEET_NUMBER"
    VFD_Name_EnsureMapRow ws, cEnabled, cScope, cPattern, cTag, cSource, "DRAWING_DESCRIPTION", "DRAWING_DESCRIPTION"
    VFD_Name_EnsureMapRow ws, cEnabled, cScope, cPattern, cTag, cSource, "T2", "DRAWING_DESCRIPTION"
End Sub

Private Sub VFD_Name_EnsureMapRow(ByVal ws As Worksheet, ByVal cEnabled As Long, ByVal cScope As Long, _
                                  ByVal cPattern As Long, ByVal cTag As Long, ByVal cSource As Long, _
                                  ByVal attrTag As String, ByVal sourceHeader As String)
    Dim lastRow As Long, r As Long
    lastRow = VFD_Name_LastRow(ws)
    For r = 2 To lastRow
        If UCase$(Trim$(CStr(ws.Cells(r, cScope).Value2))) = "TITLEBLOCK" And _
           UCase$(Trim$(CStr(ws.Cells(r, cTag).Value2))) = UCase$(attrTag) Then
            If cEnabled > 0 Then ws.Cells(r, cEnabled).Value2 = "YES"
            If cPattern > 0 And Len(Trim$(CStr(ws.Cells(r, cPattern).Value2))) = 0 Then ws.Cells(r, cPattern).Value2 = "*"
            ws.Cells(r, cSource).Value2 = sourceHeader
            Exit Sub
        End If
    Next r

    r = lastRow + 1
    If cEnabled > 0 Then ws.Cells(r, cEnabled).Value2 = "YES"
    ws.Cells(r, cScope).Value2 = "TITLEBLOCK"
    If cPattern > 0 Then ws.Cells(r, cPattern).Value2 = "*"
    ws.Cells(r, cTag).Value2 = attrTag
    ws.Cells(r, cSource).Value2 = sourceHeader
End Sub
