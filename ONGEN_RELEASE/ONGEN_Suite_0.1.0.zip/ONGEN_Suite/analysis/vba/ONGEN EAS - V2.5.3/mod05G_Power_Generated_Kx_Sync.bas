Attribute VB_Name = "mod05G_Power_Generated_Kx_Sync"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod05G_Power_Generated_Kx_Sync
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
Option Explicit

'===============================================================================
' ONGEN EAS - OPTIONAL POWER Kx SYNCHRONIZATION
' Release        : V25.3.3
' Module         : mod05G_Power_Generated_Kx_Sync
' Purpose        : Push the current PD6_IMPORT Control_ID -Kx values into
'                  existing generated 24V panel worksheets and the
'                  VFD_480V_Generator worksheet without rebuilding either.
'
' IMPORTANT
'   * This is an optional, standalone operation.
'   * It does not run Step 7 or Step 8.
'   * It does not clear, delete, or regenerate generated worksheets.
'   * It updates identifiers only; loads, terminals, PSUs, blocks, formatting,
'     formulas, and worksheet structure remain unchanged.
'   * Existing AutoCAD DWG files are not edited. Refresh/regenerate the VFD
'     drawing queue and drawings after the workbook data is synchronized.
'===============================================================================

Private Const KX_PD6_SHEET As String = "PD6_IMPORT"
Private Const KX_480V_SHEET As String = "VFD_480V_Generator"
Private Const KX_AUDIT_SHEET As String = "POWER_KX_SYNC_AUDIT"
Private Const KX_BUTTON_NAME As String = "BTN_STEP05G_POWER_KX_SYNC"

'-------------------------------------------------------------------------------
' User entry point.
' Yes    = apply changes.
' No     = audit only; do not change generated data.
' Cancel = exit.
'-------------------------------------------------------------------------------
Public Sub Step05G_Sync_Kx_To_Generated_Power()
    Dim answer As VbMsgBoxResult
    Dim applyChanges As Boolean
    Dim pd6Map As Object
    Dim ambiguousMap As Object
    Dim pd6Rows As Object
    Dim wsAudit As Worksheet
    Dim updated24V As Long
    Dim updated480V As Long
    Dim unchanged As Long
    Dim unmatched As Long
    Dim ambiguous As Long
    Dim skipped As Long
    Dim calcMode As XlCalculation
    Dim screenState As Boolean
    Dim eventsState As Boolean
    Dim statusText As Variant

    answer = MsgBox( _
        "Synchronize the current PD6 Control_ID -Kx values into existing " & _
        "generated 24V and 480V workbook data?" & vbCrLf & vbCrLf & _
        "YES  - Apply identifier updates." & vbCrLf & _
        "NO   - Audit only; make no changes." & vbCrLf & _
        "CANCEL - Exit." & vbCrLf & vbCrLf & _
        "This process does not rebuild Step 7 or Step 8 worksheets.", _
        vbYesNoCancel + vbQuestion + vbDefaultButton2, _
        "05G - Synchronize Power Kx")

    If answer = vbCancel Then Exit Sub
    applyChanges = (answer = vbYes)

    On Error GoTo CleanFail

    screenState = Application.ScreenUpdating
    eventsState = Application.EnableEvents
    calcMode = Application.Calculation
    statusText = Application.StatusBar

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "ONGEN 05G: Building PD6 Kx match index..."

    Set pd6Map = CreateObject("Scripting.Dictionary")
    Set ambiguousMap = CreateObject("Scripting.Dictionary")
    Set pd6Rows = CreateObject("Scripting.Dictionary")

    KX_BuildPD6Index pd6Map, ambiguousMap, pd6Rows
    Set wsAudit = KX_PrepareAuditSheet(applyChanges)

    Application.StatusBar = "ONGEN 05G: Synchronizing generated 24V worksheets..."
    KX_Sync24VSheets pd6Map, ambiguousMap, pd6Rows, wsAudit, applyChanges, _
                     updated24V, unchanged, unmatched, ambiguous, skipped

    Application.StatusBar = "ONGEN 05G: Synchronizing VFD_480V_Generator..."
    KX_Sync480VGenerator pd6Map, ambiguousMap, pd6Rows, wsAudit, applyChanges, _
                         updated480V, unchanged, unmatched, ambiguous, skipped

    KX_FinalizeAudit wsAudit, applyChanges, updated24V, updated480V, _
                     unchanged, unmatched, ambiguous, skipped

    Application.ScreenUpdating = screenState
    Application.EnableEvents = eventsState
    Application.Calculation = calcMode
    Application.StatusBar = statusText

    MsgBox "Power Kx synchronization completed." & vbCrLf & vbCrLf & _
           "Mode: " & IIf(applyChanges, "APPLY", "AUDIT ONLY") & vbCrLf & _
           "24V identifiers updated: " & updated24V & vbCrLf & _
           "480V identifiers updated: " & updated480V & vbCrLf & _
           "Already current: " & unchanged & vbCrLf & _
           "Unmatched: " & unmatched & vbCrLf & _
           "Ambiguous: " & ambiguous & vbCrLf & _
           "Skipped: " & skipped & vbCrLf & vbCrLf & _
           "Review worksheet '" & KX_AUDIT_SHEET & "'.", _
           vbInformation, "ONGEN 05G Complete"
    Exit Sub

CleanFail:
    On Error Resume Next
    Application.ScreenUpdating = screenState
    Application.EnableEvents = eventsState
    Application.Calculation = calcMode
    Application.StatusBar = statusText
    On Error GoTo 0

    MsgBox "Step 05G could not complete." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN 05G"
End Sub

' UI wrapper for assigned worksheet shapes.
Public Sub BTN_Run_Step05G_Power_Kx_Sync()
    Step05G_Sync_Kx_To_Generated_Power
End Sub

'-------------------------------------------------------------------------------
' Optional one-time MAIN worksheet button installer.
'-------------------------------------------------------------------------------
Public Sub Install_Step05G_Power_Kx_Sync_Button()
    Dim ws As Worksheet
    Dim shp As Shape
    Dim bottomPos As Double
    Dim leftPos As Double
    Dim buttonWidth As Double
    Dim buttonHeight As Double

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("MAIN")
    On Error GoTo 0

    If ws Is Nothing Then
        MsgBox "Worksheet 'MAIN' was not found.", vbExclamation, "Install Step 05G"
        Exit Sub
    End If

    On Error Resume Next
    ws.Shapes(KX_BUTTON_NAME).Delete
    On Error GoTo 0

    bottomPos = 20
    For Each shp In ws.Shapes
        If shp.Top + shp.Height > bottomPos Then bottomPos = shp.Top + shp.Height
    Next shp

    leftPos = 20
    buttonWidth = 235
    buttonHeight = 30

    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPos, bottomPos + 12, _
                                 buttonWidth, buttonHeight)
    With shp
        .Name = KX_BUTTON_NAME
        .OnAction = "BTN_Run_Step05G_Power_Kx_Sync"
        .TextFrame2.TextRange.text = "05G Sync Kx to 24V / 480V"
        .TextFrame2.TextRange.Font.Size = 10
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .Fill.ForeColor.RGB = RGB(128, 100, 162)
        .Line.ForeColor.RGB = RGB(91, 70, 118)
        .Placement = xlFreeFloating
    End With

    MsgBox "The optional Step 05G button was added to MAIN.", _
           vbInformation, "Install Step 05G"
End Sub

'-------------------------------------------------------------------------------
' Build unique lookup keys from PD6 Control_ID and SIS_Element_Number.
' Each dictionary item is: Control_ID|PD6 row.
'-------------------------------------------------------------------------------
Private Sub KX_BuildPD6Index(ByRef pd6Map As Object, _
                             ByRef ambiguousMap As Object, _
                             ByRef pd6Rows As Object)
    Dim ws As Worksheet
    Dim headerMap As Object
    Dim lastRow As Long
    Dim r As Long
    Dim cControl As Long
    Dim cSisElement As Long
    Dim cPanel As Long
    Dim controlID As String
    Dim sisElement As String
    Dim panel As String

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(KX_PD6_SHEET)
    On Error GoTo 0

    If ws Is Nothing Then Err.Raise vbObjectError + 5301, , _
        "Worksheet '" & KX_PD6_SHEET & "' was not found."

    Set headerMap = KX_HeaderMap(ws, 1)
    cControl = KX_HeaderColumn(headerMap, "CONTROL_ID", "CONTROL ID")
    cSisElement = KX_HeaderColumn(headerMap, "SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER")
    cPanel = KX_HeaderColumn(headerMap, "PNL", "PANEL", "480V PANEL")

    If cControl = 0 Then Err.Raise vbObjectError + 5302, , _
        "PD6_IMPORT is missing the Control_ID header."
    If cSisElement = 0 Then Err.Raise vbObjectError + 5303, , _
        "PD6_IMPORT is missing the SIS_Element_Number header."

    lastRow = KX_LastUsedRow(ws)
    For r = 2 To lastRow
        controlID = Trim$(CStr(ws.Cells(r, cControl).Value2))
        sisElement = Trim$(CStr(ws.Cells(r, cSisElement).Value2))
        If cPanel > 0 Then panel = Trim$(CStr(ws.Cells(r, cPanel).Value2)) Else panel = vbNullString

        If Len(controlID) > 0 Then
            pd6Rows(CStr(r)) = controlID
            KX_AddPD6Key pd6Map, ambiguousMap, _
                         KX_MatchKey(controlID, panel), controlID, r
            KX_AddPD6Key pd6Map, ambiguousMap, _
                         KX_MatchKey(controlID, vbNullString), controlID, r

            If Len(sisElement) > 0 Then
                KX_AddPD6Key pd6Map, ambiguousMap, _
                             KX_MatchKey(sisElement, panel), controlID, r
                KX_AddPD6Key pd6Map, ambiguousMap, _
                             KX_MatchKey(sisElement, vbNullString), controlID, r
            End If
        End If
    Next r
End Sub

Private Sub KX_AddPD6Key(ByRef pd6Map As Object, _
                         ByRef ambiguousMap As Object, _
                         ByVal key As String, _
                         ByVal controlID As String, _
                         ByVal pd6Row As Long)
    Dim existing As String
    Dim itemText As String

    If Len(key) = 0 Then Exit Sub
    itemText = controlID & "|" & CStr(pd6Row)

    If ambiguousMap.Exists(key) Then Exit Sub

    If Not pd6Map.Exists(key) Then
        pd6Map.Add key, itemText
    Else
        existing = CStr(pd6Map(key))
        If StrComp(existing, itemText, vbTextCompare) <> 0 Then
            pd6Map.Remove key
            ambiguousMap(key) = True
        End If
    End If
End Sub

'-------------------------------------------------------------------------------
' Update all <Panel>_24v sheets. Device identifiers are written in columns A
' and K by the current generator; both are synchronized when present.
'-------------------------------------------------------------------------------
Private Sub KX_Sync24VSheets(ByVal pd6Map As Object, _
                             ByVal ambiguousMap As Object, _
                             ByVal pd6Rows As Object, _
                             ByVal wsAudit As Worksheet, _
                             ByVal applyChanges As Boolean, _
                             ByRef updatedCount As Long, _
                             ByRef unchangedCount As Long, _
                             ByRef unmatchedCount As Long, _
                             ByRef ambiguousCount As Long, _
                             ByRef skippedCount As Long)
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim r As Long
    Dim panel As String

    For Each ws In ThisWorkbook.Worksheets
        If KX_Is24VPanelSheet(ws.Name) Then
            panel = Left$(ws.Name, Len(ws.Name) - 4)
            lastRow = KX_LastUsedRow(ws)

            For r = 1 To lastRow
                KX_SyncOneCell ws, r, 1, panel, "24V", pd6Map, ambiguousMap, _
                               wsAudit, applyChanges, updatedCount, unchangedCount, _
                               unmatchedCount, ambiguousCount, skippedCount
                KX_SyncOneCell ws, r, 11, panel, "24V", pd6Map, ambiguousMap, _
                               wsAudit, applyChanges, updatedCount, unchangedCount, _
                               unmatchedCount, ambiguousCount, skippedCount
            Next r
        End If
    Next ws
End Sub

Private Sub KX_SyncOneCell(ByVal ws As Worksheet, _
                           ByVal rowNumber As Long, _
                           ByVal columnNumber As Long, _
                           ByVal panel As String, _
                           ByVal category As String, _
                           ByVal pd6Map As Object, _
                           ByVal ambiguousMap As Object, _
                           ByVal wsAudit As Worksheet, _
                           ByVal applyChanges As Boolean, _
                           ByRef updatedCount As Long, _
                           ByRef unchangedCount As Long, _
                           ByRef unmatchedCount As Long, _
                           ByRef ambiguousCount As Long, _
                           ByRef skippedCount As Long)
    Dim oldValue As String
    Dim newValue As String
    Dim pd6Row As Long
    Dim status As String

    oldValue = Trim$(CStr(ws.Cells(rowNumber, columnNumber).Value2))
    If Len(oldValue) = 0 Then Exit Sub

    If KX_IsHeaderOrNonDevice(oldValue) Then Exit Sub
    If Not KX_LooksLikeGeneratedIdentity(oldValue) Then Exit Sub

    KX_ResolveIdentity oldValue, panel, pd6Map, ambiguousMap, _
                       newValue, pd6Row, status

    Select Case status
        Case "MATCHED"
            If StrComp(oldValue, newValue, vbBinaryCompare) = 0 Then
                unchangedCount = unchangedCount + 1
                KX_WriteAudit wsAudit, category, ws.Name, rowNumber, columnNumber, _
                              oldValue, newValue, pd6Row, "ALREADY_CURRENT", _
                              "Generated identifier already matches PD6 Control_ID."
            Else
                If applyChanges Then ws.Cells(rowNumber, columnNumber).Value2 = newValue
                updatedCount = updatedCount + 1
                KX_WriteAudit wsAudit, category, ws.Name, rowNumber, columnNumber, _
                              oldValue, newValue, pd6Row, _
                              IIf(applyChanges, "UPDATED", "WOULD_UPDATE"), _
                              "Kx synchronized from PD6 Control_ID."
            End If

        Case "AMBIGUOUS"
            ambiguousCount = ambiguousCount + 1
            KX_WriteAudit wsAudit, category, ws.Name, rowNumber, columnNumber, _
                          oldValue, vbNullString, 0, "AMBIGUOUS", _
                          "More than one PD6 record shares this normalized identity."

        Case "UNMATCHED"
            unmatchedCount = unmatchedCount + 1
            KX_WriteAudit wsAudit, category, ws.Name, rowNumber, columnNumber, _
                          oldValue, vbNullString, 0, "UNMATCHED", _
                          "No unique PD6 Control_ID match was found."

        Case Else
            skippedCount = skippedCount + 1
    End Select
End Sub

'-------------------------------------------------------------------------------
' Synchronize VFD_480V_Generator. PD6_SOURCE_ROW is the preferred exact link.
' When that link is absent or invalid, the normalized identifier lookup is used.
'-------------------------------------------------------------------------------
Private Sub KX_Sync480VGenerator(ByVal pd6Map As Object, _
                                 ByVal ambiguousMap As Object, _
                                 ByVal pd6Rows As Object, _
                                 ByVal wsAudit As Worksheet, _
                                 ByVal applyChanges As Boolean, _
                                 ByRef updatedCount As Long, _
                                 ByRef unchangedCount As Long, _
                                 ByRef unmatchedCount As Long, _
                                 ByRef ambiguousCount As Long, _
                                 ByRef skippedCount As Long)
    Dim ws As Worksheet
    Dim headerMap As Object
    Dim cIdentity As Long
    Dim cPD6Row As Long
    Dim cPanel As Long
    Dim lastRow As Long
    Dim r As Long
    Dim oldValue As String
    Dim newValue As String
    Dim panel As String
    Dim status As String
    Dim pd6Row As Long
    Dim sourceRowValue As Variant

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(KX_480V_SHEET)
    On Error GoTo 0

    If ws Is Nothing Then
        KX_WriteAudit wsAudit, "480V", KX_480V_SHEET, 0, 0, vbNullString, _
                      vbNullString, 0, "SHEET_NOT_FOUND", _
                      "The 480V generator worksheet is optional and was not found."
        skippedCount = skippedCount + 1
        Exit Sub
    End If

    Set headerMap = KX_HeaderMap(ws, 1)
    cIdentity = KX_HeaderColumn(headerMap, "SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER")
    cPD6Row = KX_HeaderColumn(headerMap, "PD6_SOURCE_ROW", "PD6 SOURCE ROW")
    cPanel = KX_HeaderColumn(headerMap, "480V PANEL", "PANEL", "PNL")

    If cIdentity = 0 Then
        KX_WriteAudit wsAudit, "480V", ws.Name, 1, 0, vbNullString, vbNullString, _
                      0, "HEADER_MISSING", _
                      "SIS_ELEMENT_NUMBER header was not found."
        skippedCount = skippedCount + 1
        Exit Sub
    End If

    lastRow = KX_LastUsedRow(ws)
    For r = 2 To lastRow
        oldValue = Trim$(CStr(ws.Cells(r, cIdentity).Value2))
        If Len(oldValue) = 0 Then GoTo ContinueRow

        If cPanel > 0 Then panel = Trim$(CStr(ws.Cells(r, cPanel).Value2)) Else panel = vbNullString
        newValue = vbNullString
        pd6Row = 0
        status = vbNullString

        If cPD6Row > 0 Then
            sourceRowValue = ws.Cells(r, cPD6Row).Value2
            If IsNumeric(sourceRowValue) Then
                pd6Row = CLng(sourceRowValue)
                If pd6Rows.Exists(CStr(pd6Row)) Then
                    newValue = CStr(pd6Rows(CStr(pd6Row)))
                    status = "MATCHED"
                End If
            End If
        End If

        If Len(status) = 0 Then
            KX_ResolveIdentity oldValue, panel, pd6Map, ambiguousMap, _
                               newValue, pd6Row, status
        End If

        Select Case status
            Case "MATCHED"
                If StrComp(oldValue, newValue, vbBinaryCompare) = 0 Then
                    unchangedCount = unchangedCount + 1
                    KX_WriteAudit wsAudit, "480V", ws.Name, r, cIdentity, oldValue, _
                                  newValue, pd6Row, "ALREADY_CURRENT", _
                                  "480V identifier already matches PD6 Control_ID."
                Else
                    If applyChanges Then ws.Cells(r, cIdentity).Value2 = newValue
                    updatedCount = updatedCount + 1
                    KX_WriteAudit wsAudit, "480V", ws.Name, r, cIdentity, oldValue, _
                                  newValue, pd6Row, _
                                  IIf(applyChanges, "UPDATED", "WOULD_UPDATE"), _
                                  "Kx synchronized from PD6 Control_ID."
                End If

            Case "AMBIGUOUS"
                ambiguousCount = ambiguousCount + 1
                KX_WriteAudit wsAudit, "480V", ws.Name, r, cIdentity, oldValue, _
                              vbNullString, 0, "AMBIGUOUS", _
                              "More than one PD6 record shares this normalized identity."

            Case Else
                unmatchedCount = unmatchedCount + 1
                KX_WriteAudit wsAudit, "480V", ws.Name, r, cIdentity, oldValue, _
                              vbNullString, 0, "UNMATCHED", _
                              "No unique PD6 Control_ID match was found."
        End Select
ContinueRow:
    Next r
End Sub

Private Sub KX_ResolveIdentity(ByVal oldValue As String, _
                               ByVal panel As String, _
                               ByVal pd6Map As Object, _
                               ByVal ambiguousMap As Object, _
                               ByRef newValue As String, _
                               ByRef pd6Row As Long, _
                               ByRef status As String)
    Dim key As String
    Dim itemText As String
    Dim parts() As String

    key = KX_MatchKey(oldValue, panel)
    If ambiguousMap.Exists(key) Then
        status = "AMBIGUOUS"
        Exit Sub
    End If

    If Not pd6Map.Exists(key) Then
        key = KX_MatchKey(oldValue, vbNullString)
        If ambiguousMap.Exists(key) Then
            status = "AMBIGUOUS"
            Exit Sub
        End If
    End If

    If pd6Map.Exists(key) Then
        itemText = CStr(pd6Map(key))
        parts = Split(itemText, "|")
        newValue = parts(0)
        If UBound(parts) >= 1 Then pd6Row = CLng(parts(1))
        status = "MATCHED"
    Else
        status = "UNMATCHED"
    End If
End Sub

Private Function KX_MatchKey(ByVal identity As String, ByVal panel As String) As String
    Dim normalizedIdentity As String
    normalizedIdentity = KX_NormalizeIdentity(identity)
    If Len(normalizedIdentity) = 0 Then Exit Function

    If Len(Trim$(panel)) > 0 Then
        KX_MatchKey = UCase$(Trim$(panel)) & "|" & normalizedIdentity
    Else
        KX_MatchKey = "*|" & normalizedIdentity
    End If
End Function

Private Function KX_NormalizeIdentity(ByVal valueText As String) As String
    Dim s As String
    s = UCase$(Trim$(valueText))
    s = Replace(s, "_", "-")
    s = Replace(s, " ", vbNullString)

    Do While InStr(s, "--") > 0
        s = Replace(s, "--", "-")
    Loop

    s = KX_RemoveTrailingKx(s)
    KX_NormalizeIdentity = s
End Function

Private Function KX_RemoveTrailingKx(ByVal valueText As String) As String
    Dim dashPos As Long
    Dim suffixText As String
    Dim digitsText As String

    KX_RemoveTrailingKx = valueText
    dashPos = InStrRev(valueText, "-")
    If dashPos <= 0 Then Exit Function

    suffixText = mid$(valueText, dashPos + 1)
    If Len(suffixText) < 2 Then Exit Function
    If Left$(suffixText, 1) <> "K" Then Exit Function

    digitsText = mid$(suffixText, 2)
    If Len(digitsText) = 0 Then Exit Function
    If Not KX_IsDigitsOnly(digitsText) Then Exit Function

    KX_RemoveTrailingKx = Left$(valueText, dashPos - 1)
End Function

Private Function KX_IsDigitsOnly(ByVal valueText As String) As Boolean
    Dim i As Long
    Dim ch As String

    If Len(valueText) = 0 Then Exit Function
    For i = 1 To Len(valueText)
        ch = mid$(valueText, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i
    KX_IsDigitsOnly = True
End Function

Private Function KX_Is24VPanelSheet(ByVal sheetName As String) As Boolean
    KX_Is24VPanelSheet = (Len(sheetName) > 4 And _
                         UCase$(Right$(sheetName, 4)) = "_24V")
End Function

Private Function KX_IsHeaderOrNonDevice(ByVal valueText As String) As Boolean
    Dim s As String
    s = UCase$(Trim$(valueText))

    Select Case s
        Case "SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER", "PWG", _
             "POWER SUPPLY", "PANEL", "PNL", "BUS POWER"
            KX_IsHeaderOrNonDevice = True
    End Select
End Function

Private Function KX_LooksLikeGeneratedIdentity(ByVal valueText As String) As Boolean
    Dim s As String
    s = Trim$(valueText)
    KX_LooksLikeGeneratedIdentity = (InStr(s, "-") > 0 And Len(s) >= 5)
End Function

Private Function KX_PrepareAuditSheet(ByVal applyChanges As Boolean) As Worksheet
    Dim ws As Worksheet
    Dim headers As Variant
    Dim i As Long

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(KX_AUDIT_SHEET)
    On Error GoTo 0

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = KX_AUDIT_SHEET
    Else
        ws.Cells.Clear
    End If

    headers = Array("CATEGORY", "WORKSHEET", "ROW", "COLUMN", "OLD_IDENTIFIER", _
                    "NEW_CONTROL_ID", "PD6_ROW", "STATUS", "DETAILS", "RUN_MODE")

    For i = LBound(headers) To UBound(headers)
        ws.Cells(1, i + 1).Value2 = headers(i)
    Next i

    With ws.Range("A1:J1")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .HorizontalAlignment = xlCenter
    End With

    ws.Range("L1").Value2 = "ONGEN Power Kx Synchronization"
    ws.Range("L2").Value2 = "Run time"
    ws.Range("M2").Value2 = Now
    ws.Range("L3").Value2 = "Mode"
    ws.Range("M3").Value2 = IIf(applyChanges, "APPLY", "AUDIT ONLY")

    Set KX_PrepareAuditSheet = ws
End Function

Private Sub KX_WriteAudit(ByVal ws As Worksheet, _
                          ByVal category As String, _
                          ByVal sheetName As String, _
                          ByVal rowNumber As Long, _
                          ByVal columnNumber As Long, _
                          ByVal oldIdentifier As String, _
                          ByVal newIdentifier As String, _
                          ByVal pd6Row As Long, _
                          ByVal status As String, _
                          ByVal details As String)
    Dim nextRow As Long

    nextRow = KX_LastUsedRow(ws) + 1
    If nextRow < 2 Then nextRow = 2

    ws.Cells(nextRow, 1).Value2 = category
    ws.Cells(nextRow, 2).Value2 = sheetName
    If rowNumber > 0 Then ws.Cells(nextRow, 3).Value2 = rowNumber
    If columnNumber > 0 Then ws.Cells(nextRow, 4).Value2 = KX_ColumnLetter(columnNumber)
    ws.Cells(nextRow, 5).Value2 = oldIdentifier
    ws.Cells(nextRow, 6).Value2 = newIdentifier
    If pd6Row > 0 Then ws.Cells(nextRow, 7).Value2 = pd6Row
    ws.Cells(nextRow, 8).Value2 = status
    ws.Cells(nextRow, 9).Value2 = details
    ws.Cells(nextRow, 10).Value2 = ws.Range("M3").Value2
End Sub

Private Sub KX_FinalizeAudit(ByVal ws As Worksheet, _
                             ByVal applyChanges As Boolean, _
                             ByVal updated24V As Long, _
                             ByVal updated480V As Long, _
                             ByVal unchanged As Long, _
                             ByVal unmatched As Long, _
                             ByVal ambiguous As Long, _
                             ByVal skipped As Long)
    Dim lastRow As Long

    ws.Range("L5").Value2 = "24V updates"
    ws.Range("M5").Value2 = updated24V
    ws.Range("L6").Value2 = "480V updates"
    ws.Range("M6").Value2 = updated480V
    ws.Range("L7").Value2 = "Already current"
    ws.Range("M7").Value2 = unchanged
    ws.Range("L8").Value2 = "Unmatched"
    ws.Range("M8").Value2 = unmatched
    ws.Range("L9").Value2 = "Ambiguous"
    ws.Range("M9").Value2 = ambiguous
    ws.Range("L10").Value2 = "Skipped"
    ws.Range("M10").Value2 = skipped

    lastRow = KX_LastUsedRow(ws)
    If lastRow >= 2 Then
        ws.Range("A1:J" & lastRow).AutoFilter
        ws.Range("A1:J" & lastRow).Borders.LineStyle = xlContinuous
    End If

    ws.Columns("A:J").AutoFit
    ws.Columns("I:I").columnWidth = 52
    ws.Columns("L:M").AutoFit
    ws.Activate
    ws.Range("A1").Select
End Sub

Private Function KX_HeaderMap(ByVal ws As Worksheet, ByVal headerRow As Long) As Object
    Dim dict As Object
    Dim lastCol As Long
    Dim c As Long
    Dim headerText As String

    Set dict = CreateObject("Scripting.Dictionary")
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column

    For c = 1 To lastCol
        headerText = KX_NormalizeHeader(CStr(ws.Cells(headerRow, c).Value2))
        If Len(headerText) > 0 Then
            If Not dict.Exists(headerText) Then dict.Add headerText, c
        End If
    Next c

    Set KX_HeaderMap = dict
End Function

Private Function KX_HeaderColumn(ByVal headerMap As Object, ParamArray names() As Variant) As Long
    Dim i As Long
    Dim key As String

    For i = LBound(names) To UBound(names)
        key = KX_NormalizeHeader(CStr(names(i)))
        If headerMap.Exists(key) Then
            KX_HeaderColumn = CLng(headerMap(key))
            Exit Function
        End If
    Next i
End Function

Private Function KX_NormalizeHeader(ByVal valueText As String) As String
    Dim s As String
    s = UCase$(Trim$(valueText))
    s = Replace(s, "_", " ")
    s = Replace(s, "-", " ")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    KX_NormalizeHeader = s
End Function

Private Function KX_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim lastCell As Range

    On Error Resume Next
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), _
                                 LookIn:=xlFormulas, LookAt:=xlPart, _
                                 SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                 MatchCase:=False)
    On Error GoTo 0

    If lastCell Is Nothing Then
        KX_LastUsedRow = 1
    Else
        KX_LastUsedRow = lastCell.Row
    End If
End Function

Private Function KX_ColumnLetter(ByVal columnNumber As Long) As String
    KX_ColumnLetter = Split(Cells(1, columnNumber).Address(False, False), "1")(0)
End Function

