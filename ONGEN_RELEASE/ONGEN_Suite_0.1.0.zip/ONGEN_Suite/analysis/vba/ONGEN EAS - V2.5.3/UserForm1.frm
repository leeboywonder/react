Attribute VB_Name = "UserForm1"
Attribute VB_Base = "0{63E6E1DC-75C3-4EDB-B80B-D429DE981E12}{AA4A5063-B143-42AC-88AC-61335B994DD9}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
