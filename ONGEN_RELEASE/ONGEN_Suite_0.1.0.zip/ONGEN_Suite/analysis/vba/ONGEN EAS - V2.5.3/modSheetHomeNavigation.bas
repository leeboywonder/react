Attribute VB_Name = "modSheetHomeNavigation"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : modSheetHomeNavigation
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : modSheetHomeNavigation
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Purpose       : Return Home + Worksheet Launcher controls and export cleanup.
'-------------------------------------------------------------------------------

Option Explicit

Private Const NAV_HOME_SHEET As String = "MAIN"

Private Const NAV_HOME_BUTTON_NAME As String = "btnReturnToMAIN"
Private Const NAV_HOME_BUTTON_CAPTION As String = "Return To Home"
Private Const NAV_HOME_MACRO As String = "NAV_Return_To_MAIN"

Private Const NAV_LAUNCH_BUTTON_NAME As String = "btnWorksheetLauncher"
Private Const NAV_LAUNCH_BUTTON_CAPTION As String = "Sheet Launcher"
Private Const NAV_LAUNCH_MACRO As String = "NAV_Open_Worksheet_Launcher"

Private Const NAV_BUTTON_ANCHOR As String = "A1"
Private Const NAV_HOME_BUTTON_WIDTH As Double = 112
Private Const NAV_LAUNCH_BUTTON_WIDTH As Double = 118
Private Const NAV_BUTTON_HEIGHT As Double = 28
Private Const NAV_BUTTON_GAP As Double = 6

'Backward-compatible entry point. It now installs both navigation controls.
Public Sub NAV_Install_Return_To_MAIN_Buttons_All_Sheets( _
    Optional ByVal resetPosition As Boolean = False, _
    Optional ByVal showSummary As Boolean = True)

    Dim ws As Worksheet
    Dim installed As Long
    Dim Failed As Long
    Dim oldScreen As Boolean
    Dim oldEvents As Boolean

    On Error GoTo FatalError

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    For Each ws In ThisWorkbook.Worksheets
        If NAV_Ensure_Return_To_MAIN_Button(ws, resetPosition) Then
            installed = installed + 1
        Else
            Failed = Failed + 1
        End If
    Next ws

CleanExit:
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    If showSummary Then
        If Failed = 0 Then
            MsgBox "Worksheet navigation was installed or repaired on " & _
                   CStr(installed) & " worksheet(s)." & vbCrLf & _
                   "Each worksheet now has access to the Sheet Launcher.", _
                   vbInformation, "ONGEN Worksheet Navigation"
        Else
            MsgBox "Worksheet navigation completed with " & CStr(Failed) & _
                   " worksheet failure(s).", vbExclamation, _
                   "ONGEN Worksheet Navigation"
        End If
    End If
    Exit Sub

FatalError:
    Failed = Failed + 1
    Resume CleanExit
End Sub

Public Sub NAV_Install_Worksheet_Navigation_Buttons_All_Sheets( _
    Optional ByVal resetPosition As Boolean = False, _
    Optional ByVal showSummary As Boolean = True)

    NAV_Install_Return_To_MAIN_Buttons_All_Sheets resetPosition, showSummary
End Sub

'This public function is retained because ThisWorkbook already calls it from
'Workbook_NewSheet and Workbook_SheetActivate. It now ensures both buttons.
Public Function NAV_Ensure_Return_To_MAIN_Button( _
    ByVal ws As Worksheet, _
    Optional ByVal resetPosition As Boolean = False) As Boolean

    Dim homeOK As Boolean
    Dim launcherOK As Boolean

    On Error GoTo Failed
    If ws Is Nothing Then Exit Function

    If StrComp(ws.Name, NAV_HOME_SHEET, vbTextCompare) = 0 Then
        NAV_Remove_Home_Button_From_Worksheet ws

        'MAIN already contains the large launcher button created by the MAIN UI.
        'Only add the small floating launcher when that normal control is absent.
        If NAV_Worksheet_Has_Any_Launcher_Action(ws) Then
            launcherOK = True
        Else
            launcherOK = NAV_Ensure_Launcher_Button(ws, resetPosition, False)
        End If

        NAV_Ensure_Return_To_MAIN_Button = launcherOK
        Exit Function
    End If

    homeOK = NAV_Ensure_Home_Button(ws, resetPosition)
    launcherOK = NAV_Ensure_Launcher_Button(ws, resetPosition, True)

    NAV_Ensure_Return_To_MAIN_Button = (homeOK And launcherOK)
    Exit Function

Failed:
    NAV_Ensure_Return_To_MAIN_Button = False
End Function

Public Function NAV_Ensure_Worksheet_Launcher_Button( _
    ByVal ws As Worksheet, _
    Optional ByVal resetPosition As Boolean = False) As Boolean

    On Error GoTo Failed
    If ws Is Nothing Then Exit Function

    NAV_Ensure_Worksheet_Launcher_Button = _
        NAV_Ensure_Launcher_Button( _
            ws, resetPosition, _
            (StrComp(ws.Name, NAV_HOME_SHEET, vbTextCompare) <> 0))
    Exit Function

Failed:
    NAV_Ensure_Worksheet_Launcher_Button = False
End Function

Private Function NAV_Ensure_Home_Button( _
    ByVal ws As Worksheet, _
    ByVal resetPosition As Boolean) As Boolean

    Dim anchor As Range
    Dim oldShape As Shape
    Dim btn As Button
    Dim buttonLeft As Double
    Dim buttonTop As Double
    Dim buttonWidth As Double
    Dim buttonHeight As Double

    On Error GoTo Failed

    Set anchor = ws.Range(NAV_BUTTON_ANCHOR)
    buttonLeft = anchor.Left + 2
    buttonTop = anchor.Top + 2
    buttonWidth = NAV_HOME_BUTTON_WIDTH
    buttonHeight = NAV_BUTTON_HEIGHT

    On Error Resume Next
    Set oldShape = ws.Shapes(NAV_HOME_BUTTON_NAME)
    On Error GoTo Failed

    If Not oldShape Is Nothing Then
        If Not resetPosition Then
            buttonLeft = oldShape.Left
            buttonTop = oldShape.Top
            If oldShape.Width > 40 Then buttonWidth = oldShape.Width
            If oldShape.Height > 16 Then buttonHeight = oldShape.Height
        End If
    End If

    NAV_Remove_Home_Button_From_Worksheet ws

    Set btn = ws.Buttons.Add(buttonLeft, buttonTop, buttonWidth, buttonHeight)
    NAV_Format_Button btn, NAV_HOME_BUTTON_NAME, NAV_HOME_BUTTON_CAPTION, _
                      NAV_HOME_MACRO, RGB(31, 78, 121)

    NAV_Ensure_Home_Button = True
    Exit Function

Failed:
    NAV_Ensure_Home_Button = False
End Function

Private Function NAV_Ensure_Launcher_Button( _
    ByVal ws As Worksheet, _
    ByVal resetPosition As Boolean, _
    ByVal placeAfterHome As Boolean) As Boolean

    Dim anchor As Range
    Dim oldShape As Shape
    Dim homeShape As Shape
    Dim btn As Button
    Dim buttonLeft As Double
    Dim buttonTop As Double
    Dim buttonWidth As Double
    Dim buttonHeight As Double

    On Error GoTo Failed

    Set anchor = ws.Range(NAV_BUTTON_ANCHOR)
    buttonLeft = anchor.Left + 2
    buttonTop = anchor.Top + 2
    buttonWidth = NAV_LAUNCH_BUTTON_WIDTH
    buttonHeight = NAV_BUTTON_HEIGHT

    If placeAfterHome Then
        On Error Resume Next
        Set homeShape = ws.Shapes(NAV_HOME_BUTTON_NAME)
        On Error GoTo Failed

        If Not homeShape Is Nothing Then
            buttonLeft = homeShape.Left + homeShape.Width + NAV_BUTTON_GAP
            buttonTop = homeShape.Top
        Else
            buttonLeft = buttonLeft + NAV_HOME_BUTTON_WIDTH + NAV_BUTTON_GAP
        End If
    End If

    On Error Resume Next
    Set oldShape = ws.Shapes(NAV_LAUNCH_BUTTON_NAME)
    On Error GoTo Failed

    If Not oldShape Is Nothing Then
        If Not resetPosition Then
            buttonLeft = oldShape.Left
            buttonTop = oldShape.Top
            If oldShape.Width > 40 Then buttonWidth = oldShape.Width
            If oldShape.Height > 16 Then buttonHeight = oldShape.Height
        End If
    End If

    NAV_Remove_Launcher_Button_From_Worksheet ws, False

    Set btn = ws.Buttons.Add(buttonLeft, buttonTop, buttonWidth, buttonHeight)
    NAV_Format_Button btn, NAV_LAUNCH_BUTTON_NAME, _
                      NAV_LAUNCH_BUTTON_CAPTION, NAV_LAUNCH_MACRO, _
                      RGB(47, 84, 150)

    NAV_Ensure_Launcher_Button = True
    Exit Function

Failed:
    NAV_Ensure_Launcher_Button = False
End Function

Private Sub NAV_Format_Button( _
    ByVal btn As Button, _
    ByVal buttonName As String, _
    ByVal buttonCaption As String, _
    ByVal macroName As String, _
    ByVal fillColor As Long)

    Dim shp As Shape

    btn.Name = buttonName
    btn.caption = buttonCaption
    btn.OnAction = NAV_QualifiedMacroName(macroName)
    btn.Placement = xlFreeFloating
    btn.PrintObject = False
    btn.Locked = True

    On Error Resume Next
    btn.Font.Name = "Arial"
    btn.Font.Size = 9
    btn.Font.Bold = True

    Set shp = btn.Parent.Shapes(buttonName)
    If Not shp Is Nothing Then
        shp.AlternativeText = "ONGEN workbook navigation control."
        shp.TextFrame.Characters.text = buttonCaption
        shp.TextFrame.HorizontalAlignment = xlHAlignCenter
        shp.TextFrame.VerticalAlignment = xlVAlignCenter
        shp.TextFrame.Characters.Font.Name = "Arial"
        shp.TextFrame.Characters.Font.Size = 9
        shp.TextFrame.Characters.Font.Bold = True
        shp.Fill.ForeColor.RGB = fillColor
        shp.Line.ForeColor.RGB = RGB(255, 255, 255)
    End If
    On Error GoTo 0
End Sub

Public Sub NAV_Return_To_MAIN()
    Dim wsHome As Worksheet

    On Error GoTo Failed
    Set wsHome = ThisWorkbook.Worksheets(NAV_HOME_SHEET)

    If wsHome.Visible <> xlSheetVisible Then wsHome.Visible = xlSheetVisible
    ThisWorkbook.Activate
    wsHome.Activate
    wsHome.Range("A1").Select
    Exit Sub

Failed:
    MsgBox "The MAIN worksheet could not be opened." & vbCrLf & _
           Err.description, vbExclamation, "ONGEN Navigation"
End Sub

Public Sub NAV_Open_Worksheet_Launcher()
    On Error GoTo Failed

    Application.Run NAV_QualifiedMacroName("UI_ShowLauncher")
    Exit Sub

Failed:
    MsgBox "The worksheet launcher could not be opened." & vbCrLf & _
           "Confirm modPD_UI and frmPDLauncher are installed." & vbCrLf & _
           Err.description, vbExclamation, "ONGEN Worksheet Launcher"
End Sub

Public Sub NAV_Audit_Return_To_MAIN_Buttons()
    NAV_Audit_Worksheet_Navigation_Buttons
End Sub

Public Sub NAV_Audit_Worksheet_Navigation_Buttons()
    Dim ws As Worksheet
    Dim checked As Long
    Dim issues As String

    For Each ws In ThisWorkbook.Worksheets
        checked = checked + 1

        If StrComp(ws.Name, NAV_HOME_SHEET, vbTextCompare) = 0 Then
            If Not NAV_Worksheet_Has_Any_Launcher_Action(ws) Then
                issues = issues & vbCrLf & "- " & ws.Name & _
                         ": launcher button missing"
            End If
        Else
            If Not NAV_Button_Is_Valid(ws, NAV_HOME_BUTTON_NAME, _
                                       NAV_HOME_BUTTON_CAPTION, _
                                       NAV_HOME_MACRO) Then
                issues = issues & vbCrLf & "- " & ws.Name & _
                         ": Return To Home button missing or invalid"
            End If

            If Not NAV_Button_Is_Valid(ws, NAV_LAUNCH_BUTTON_NAME, _
                                       NAV_LAUNCH_BUTTON_CAPTION, _
                                       NAV_LAUNCH_MACRO) Then
                issues = issues & vbCrLf & "- " & ws.Name & _
                         ": Sheet Launcher button missing or invalid"
            End If
        End If
    Next ws

    If Len(issues) = 0 Then
        MsgBox CStr(checked) & _
               " worksheets contain valid ONGEN navigation controls.", _
               vbInformation, "ONGEN Navigation Audit"
    Else
        MsgBox "Navigation audit found issues:" & vbCrLf & issues & vbCrLf & _
               vbCrLf & "Run Install Sheet Navigation from MAIN.", _
               vbExclamation, "ONGEN Navigation Audit"
    End If
End Sub

Public Sub NAV_Reset_Return_To_MAIN_Button_Positions()
    NAV_Install_Return_To_MAIN_Buttons_All_Sheets True, True
End Sub

Public Sub NAV_Remove_Return_To_MAIN_Buttons_All_Sheets()
    Dim ws As Worksheet

    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        NAV_Remove_Home_Button_From_Worksheet ws
    Next ws
    On Error GoTo 0

    MsgBox "All ONGEN Return To Home worksheet buttons were removed.", _
           vbInformation, "ONGEN Navigation"
End Sub

Public Sub NAV_Remove_Worksheet_Launcher_Buttons_All_Sheets()
    Dim ws As Worksheet

    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        NAV_Remove_Launcher_Button_From_Worksheet ws, False
    Next ws
    On Error GoTo 0

    MsgBox "All small ONGEN Sheet Launcher buttons were removed.", _
           vbInformation, "ONGEN Navigation"
End Sub

Public Sub NAV_Remove_All_Navigation_Buttons_All_Sheets()
    Dim ws As Worksheet

    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        NAV_Remove_ONGEN_Navigation_Buttons_From_Worksheet ws
    Next ws
    On Error GoTo 0

    MsgBox "All ONGEN worksheet navigation buttons were removed.", _
           vbInformation, "ONGEN Navigation"
End Sub

'Use this on an output workbook only. It never changes the source workbook
'unless the source workbook is explicitly passed as the argument.
Public Sub NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook( _
    ByVal wb As Workbook)

    Dim ws As Worksheet

    If wb Is Nothing Then Exit Sub

    On Error Resume Next
    For Each ws In wb.Worksheets
        NAV_Remove_ONGEN_Navigation_Buttons_From_Worksheet ws
    Next ws
    On Error GoTo 0
End Sub

'Public so every export module can sanitize a copied worksheet immediately.
Public Sub NAV_Remove_ONGEN_Navigation_Buttons_From_Worksheet( _
    ByVal ws As Worksheet)

    Dim i As Long
    Dim actionText As String
    Dim shapeName As String
    Dim captionText As String

    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Buttons(NAV_HOME_BUTTON_NAME).Delete
    ws.Shapes(NAV_HOME_BUTTON_NAME).Delete
    ws.Buttons(NAV_LAUNCH_BUTTON_NAME).Delete
    ws.Shapes(NAV_LAUNCH_BUTTON_NAME).Delete

    For i = ws.Shapes.count To 1 Step -1
        actionText = vbNullString
        shapeName = ws.Shapes(i).Name
        captionText = vbNullString
        actionText = ws.Shapes(i).OnAction
        captionText = ws.Shapes(i).TextFrame.Characters.text

        If NAV_Is_Export_Navigation_Action(actionText) Then
            ws.Shapes(i).Delete
        ElseIf StrComp(shapeName, NAV_HOME_BUTTON_NAME, vbTextCompare) = 0 Then
            ws.Shapes(i).Delete
        ElseIf StrComp(shapeName, NAV_LAUNCH_BUTTON_NAME, vbTextCompare) = 0 Then
            ws.Shapes(i).Delete
        ElseIf StrComp(Trim$(captionText), NAV_HOME_BUTTON_CAPTION, _
                       vbTextCompare) = 0 Then
            ws.Shapes(i).Delete
        ElseIf StrComp(Trim$(captionText), NAV_LAUNCH_BUTTON_CAPTION, _
                       vbTextCompare) = 0 Then
            ws.Shapes(i).Delete
        End If
    Next i
    On Error GoTo 0
End Sub

Private Sub NAV_Remove_Home_Button_From_Worksheet(ByVal ws As Worksheet)
    Dim i As Long
    Dim actionText As String
    Dim shapeName As String

    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Buttons(NAV_HOME_BUTTON_NAME).Delete
    ws.Shapes(NAV_HOME_BUTTON_NAME).Delete

    For i = ws.Shapes.count To 1 Step -1
        shapeName = ws.Shapes(i).Name
        actionText = ws.Shapes(i).OnAction

        If StrComp(shapeName, NAV_HOME_BUTTON_NAME, vbTextCompare) = 0 Then
            ws.Shapes(i).Delete
        ElseIf NAV_ActionTargetsMacro(actionText, NAV_HOME_MACRO) Then
            ws.Shapes(i).Delete
        End If
    Next i
    On Error GoTo 0
End Sub

Private Sub NAV_Remove_Launcher_Button_From_Worksheet( _
    ByVal ws As Worksheet, _
    ByVal removeAnyLauncherAction As Boolean)

    Dim i As Long
    Dim actionText As String
    Dim shapeName As String

    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Buttons(NAV_LAUNCH_BUTTON_NAME).Delete
    ws.Shapes(NAV_LAUNCH_BUTTON_NAME).Delete

    For i = ws.Shapes.count To 1 Step -1
        shapeName = ws.Shapes(i).Name
        actionText = ws.Shapes(i).OnAction

        If StrComp(shapeName, NAV_LAUNCH_BUTTON_NAME, vbTextCompare) = 0 Then
            ws.Shapes(i).Delete
        ElseIf NAV_ActionTargetsMacro(actionText, NAV_LAUNCH_MACRO) Then
            ws.Shapes(i).Delete
        ElseIf removeAnyLauncherAction And _
               NAV_Is_Any_Launcher_Action(actionText) Then
            ws.Shapes(i).Delete
        End If
    Next i
    On Error GoTo 0
End Sub

Private Function NAV_Button_Is_Valid( _
    ByVal ws As Worksheet, _
    ByVal buttonName As String, _
    ByVal expectedCaption As String, _
    ByVal expectedMacro As String) As Boolean

    Dim btn As Button

    On Error Resume Next
    Set btn = ws.Buttons(buttonName)
    On Error GoTo 0

    If btn Is Nothing Then Exit Function
    If StrComp(Trim$(btn.caption), expectedCaption, vbTextCompare) <> 0 Then _
        Exit Function
    If Not NAV_ActionTargetsMacro(btn.OnAction, expectedMacro) Then Exit Function

    NAV_Button_Is_Valid = True
End Function

Private Function NAV_Worksheet_Has_Any_Launcher_Action( _
    ByVal ws As Worksheet) As Boolean

    Dim i As Long
    Dim actionText As String

    If ws Is Nothing Then Exit Function

    On Error Resume Next
    For i = 1 To ws.Shapes.count
        actionText = ws.Shapes(i).OnAction
        If NAV_Is_Any_Launcher_Action(actionText) Then
            NAV_Worksheet_Has_Any_Launcher_Action = True
            Exit Function
        End If
    Next i
    On Error GoTo 0
End Function

Private Function NAV_Is_Any_Launcher_Action( _
    ByVal actionText As String) As Boolean

    NAV_Is_Any_Launcher_Action = _
        NAV_ActionTargetsMacro(actionText, NAV_LAUNCH_MACRO) Or _
        NAV_ActionTargetsMacro(actionText, "UI_ShowLauncher") Or _
        NAV_ActionTargetsMacro(actionText, "BTN_Open_PD_Launcher")
End Function

Private Function NAV_Is_Export_Navigation_Action( _
    ByVal actionText As String) As Boolean

    NAV_Is_Export_Navigation_Action = _
        NAV_ActionTargetsMacro(actionText, NAV_HOME_MACRO) Or _
        NAV_Is_Any_Launcher_Action(actionText)
End Function

Private Function NAV_QualifiedMacroName(ByVal macroName As String) As String
    NAV_QualifiedMacroName = "'" & Replace(ThisWorkbook.Name, "'", "''") & _
                             "'!" & macroName
End Function

Private Function NAV_ActionTargetsMacro( _
    ByVal actionText As String, _
    ByVal macroName As String) As Boolean

    Dim normalized As String

    normalized = UCase$(Trim$(actionText))
    normalized = Replace(normalized, "'", vbNullString)

    NAV_ActionTargetsMacro = _
        (Right$(normalized, Len(UCase$(macroName))) = UCase$(macroName))
End Function

