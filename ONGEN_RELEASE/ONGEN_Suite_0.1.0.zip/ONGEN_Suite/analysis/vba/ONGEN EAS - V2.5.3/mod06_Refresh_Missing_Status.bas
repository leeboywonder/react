Attribute VB_Name = "mod06_Refresh_Missing_Status"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod06_Refresh_Missing_Status
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.2-INDUSTRIAL-FULL-RELEASE
' Module        : mod06_Refresh_Missing_Status
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : V25.2 generated PSU detail register and live Step10A/10B reconciliation completed.
' Notes         : PSU list combines generated-sheet scan with a PD6 assignment cross-check; Step10B recalculates and removes solved issues without running Step07.
'-------------------------------------------------------------------------------


'-------------------------------------------------------------------------------
' FULLY COMMENTED MAINTENANCE RELEASE
' Documentation Release : ONGEN V16.2-R2-COMMENTED
' Baseline              : ONGEN V16.2-R1 executable logic
' Functional Changes    : None - original VBA statements are preserved
' Commenting Method     : One explanation per logical VBA statement
' Continuation Rule     : Statements joined with _ receive one group comment
' Author/Owner          : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

Option Explicit

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R1
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-12
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

'==========================================================
' Module     : mod06_Refresh_Missing_Status
' Author     : Lee Pierre
' Purpose    : Audit generated 24V sheets and optionally backfill safe manual
'              BUS / PSU / terminal edits into existing PD6 rows.
'
' Use Case:
'   If a generated 24V sheet has BUS Power rows where Power Supply
'   was changed from MISSING to a real PSU, or from a real PSU back
'   to MISSING, run:
'
'       Step10_Refresh_Missing_Status_From_Generated_Sheets
'
' What it does:
'   1) Scans every generated worksheet named 24v_* or *_24v.
'   2) Rebuilds the consolidated 24v_Power Generator index from the current generated sheets.
      'V22.8 labels such as MISSING BUS-1 PSU REQUIRED #2 are counted as missing PSUs.
'   3) Repairs blank generated terminals when a real PSU has been entered.
'   4) Updates PD6_IMPORT[Bus Power], [Power Supply], and both BUS terminals.
'   5) Matches PD6_IMPORT by:
'        PNL + Control_ID + BUS
'      and falls back to:
'        PNL + SIS_Element_Number + BUS
'
' Notes:
'   - This does NOT rebuild the generated 24V sheets; it refreshes the index from their current contents.
'   - This is a back-sync utility for manual generated-sheet edits.
'   - After this refresh, rerun the 480V generator if the 480V sheet
'     needs to reflect the refreshed BUS-2 PSU information.
'==========================================================

Private Const SH_PD6_REFRESH As String = "PD6_IMPORT"
Private Const SH_24V_INDEX_REFRESH As String = "24v_Power Generator"
Private Const SH_STEP10A_AUDIT As String = "STEP10A_SYNC_AUDIT"
Private Const SH_24V_OVERLOAD_REPORT As String = "24V_OVERLOAD_TERMINALS"
Private Const SH_24V_NOT_GENERATED As String = "24V_NOT_GENERATED"
Private Const MISSING_PSU_TEXT_REFRESH As String = "MISSING"
Private Const PSU_CAPACITY_AMPS_REFRESH As Double = 40#
Private Const TERMINAL_CAPACITY_AMPS_REFRESH As Double = 20#

Private mStep10ASkipOverloads As Boolean
Private mStep10AOverloadedSections As Object
Private mStep10AOverloadedTerminals As Object
Private mStep10ALabelCorrections As Collection
Private mStep10APriorIssueKeys As Object
Private mStep10ACurrentIssueKeys As Object
Private mStep10AResolvedCleared As Long

'-------------------------------------------------------------------------------
' Procedure : Step10_Refresh_Missing_Status_From_Generated_Sheets
' Scope/Type: Public Sub
' Purpose   : Refreshes missing status from generated sheets.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Public Sub Step10_Refresh_Missing_Status_From_Generated_Sheets()

    'V25.8.4 CONTROLLED MANUAL BACKFILL:
    'Step10A always audits generated 24V sheets. The user may optionally accept
    'manual PSU/terminal edits back into existing PD6 rows. It never adds PD6
    'rows, recalculates loads, or runs the automatic PSU allocator.
    Dim wb As Workbook
    Dim wsPD6 As Worksheet
    Dim syncChoice As VbMsgBoxResult
    Dim correctedGeneratedLabels As Long
    Dim ambiguousGeneratedLabels As Long
    Dim unresolvedGeneratedLabels As Long
    Dim overloadReportSections As Long
    Dim overloadReportTerminals As Long
    Dim issueSummary As String
    Dim freshnessIssueCount As Long
    Dim capacityIssueCount As Long
    Dim previousEnableEvents As Boolean

    Dim sectionMap As Object
    Dim labelBusMap As Object
    Dim labelBusMapNoPanel As Object
    Dim terminalBusMap As Object
    Dim terminalBusMapNoPanel As Object
    Dim sheetStats As Object
    Dim psuSeen As Object
    Dim scannedSheets As Long
    Dim repairedTerminals As Long
    Dim unresolvedTerminals As Long
    Dim skippedRows As Long
    Dim changedRows As Long
    Dim matchedRows As Long
    Dim partialRows As Long
    Dim unmatchedRows As Long
    Dim backfillText As String

    syncChoice = MsgBox( _
        "Step 10A always audits the CURRENT generated 24V worksheets." & vbCrLf & vbCrLf & _
        "YES = Audit + backfill manual BUS / PSU / terminal edits into EXISTING PD6 rows." & vbCrLf & _
        "NO  = Audit / refresh index only; PD6 remains unchanged." & vbCrLf & _
        "CANCEL = Exit without making changes." & vbCrLf & vbCrLf & _
        "Use YES after manually moving a device to another terminal or entering a real PSU on a generated 24V sheet." & vbCrLf & _
        "A later Step 05 PD6 re-import remains authoritative and can supersede this manual backfill.", _
        vbYesNoCancel + vbQuestion, "10A - Audit / Optional PD6 Backfill")
    If syncChoice = vbCancel Then Exit Sub

    On Error GoTo ErrHandler
    Set wb = ThisWorkbook
    previousEnableEvents = Application.EnableEvents
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    mStep10ASkipOverloads = False

    Application.StatusBar = "ONGEN Step 10A: synchronizing generated labels FROM PD6..."
    correctedGeneratedLabels = RefreshV233SyncGeneratedLabels( _
                                   wb, ambiguousGeneratedLabels, unresolvedGeneratedLabels)

    Application.StatusBar = "ONGEN Step 10A: rebuilding overload / terminal audit..."
    RefreshV233BuildOverloadTerminalReport wb, overloadReportSections, overloadReportTerminals

    Application.StatusBar = "ONGEN Step 10A: rebuilding 24V index from generated sheets..."
    Step10A_Rebuild_24V_Index_And_PSU_List_Only False

    'Preflight creates the overloaded section/terminal dictionaries. If the user
    'chooses backfill, those sections are excluded from the write-back pass.
    Application.StatusBar = "ONGEN Step 10A: checking generated-sheet capacity / freshness..."
    If Not RefreshStep10APreflight(wb, issueSummary, freshnessIssueCount, capacityIssueCount) Then
        Err.Raise vbObjectError + 2511, "Step10_Refresh_Missing_Status_From_Generated_Sheets", issueSummary
    End If

    If syncChoice = vbYes Then
        Set sectionMap = CreateObject("Scripting.Dictionary")
        Set labelBusMap = CreateObject("Scripting.Dictionary")
        Set labelBusMapNoPanel = CreateObject("Scripting.Dictionary")
        Set terminalBusMap = CreateObject("Scripting.Dictionary")
        Set terminalBusMapNoPanel = CreateObject("Scripting.Dictionary")
        Set sheetStats = CreateObject("Scripting.Dictionary")
        Set psuSeen = CreateObject("Scripting.Dictionary")
        sectionMap.CompareMode = vbTextCompare
        labelBusMap.CompareMode = vbTextCompare
        labelBusMapNoPanel.CompareMode = vbTextCompare
        terminalBusMap.CompareMode = vbTextCompare
        terminalBusMapNoPanel.CompareMode = vbTextCompare
        sheetStats.CompareMode = vbTextCompare
        psuSeen.CompareMode = vbTextCompare

        'Never push an overloaded generated section/terminal into PD6. The scan
        'will highlight/skip those records while still collecting safe edits.
        mStep10ASkipOverloads = True
        Application.StatusBar = "ONGEN Step 10A: scanning safe manual generated-sheet edits..."
        scannedSheets = RefreshScanGenerated24VSheets( _
            wb, sectionMap, labelBusMap, labelBusMapNoPanel, _
            terminalBusMap, terminalBusMapNoPanel, sheetStats, psuSeen, _
            repairedTerminals, unresolvedTerminals, skippedRows)
        mStep10ASkipOverloads = False

        Set wsPD6 = wb.Worksheets(SH_PD6_REFRESH)
        Application.StatusBar = "ONGEN Step 10A: backfilling safe manual PSU / terminal edits into PD6..."
        changedRows = RefreshSyncPD6ImportFromGeneratedMaps( _
                          wsPD6, labelBusMap, labelBusMapNoPanel, _
                          terminalBusMap, terminalBusMapNoPanel, _
                          matchedRows, partialRows, unmatchedRows)

        'Refresh the index/audit after the controlled write-back. No PD6 power
        'calculation or automatic assignment routine is called here.
        Step10A_Rebuild_24V_Index_And_PSU_List_Only False
        RefreshStep10APreflight wb, issueSummary, freshnessIssueCount, capacityIssueCount
        backfillText = "Manual PD6 backfill: YES" & vbCrLf & _
                       "PD6 rows changed: " & CStr(changedRows) & vbCrLf & _
                       "Fully matched rows: " & CStr(matchedRows) & vbCrLf & _
                       "Partially matched rows: " & CStr(partialRows) & vbCrLf & _
                       "Unmatched existing PD6 rows: " & CStr(unmatchedRows) & vbCrLf & _
                       "Generated rows skipped for overload protection: " & CStr(skippedRows)
    Else
        backfillText = "Manual PD6 backfill: NO (audit only)"
    End If

    AppendLog "Step10_Refresh_Missing_Status_From_Generated_Sheets", "OK", _
              "audit; manual backfill=" & IIf(syncChoice = vbYes, "YES", "NO") & _
              "; PD6 rows changed=" & CStr(changedRows) & _
              "; labels corrected=" & CStr(correctedGeneratedLabels) & _
              "; freshness issues=" & CStr(freshnessIssueCount) & _
              "; capacity issues=" & CStr(capacityIssueCount) & "."

    Application.StatusBar = False
    Application.EnableEvents = previousEnableEvents
    Application.ScreenUpdating = True

    MsgBox "Step10A completed." & vbCrLf & vbCrLf & _
           backfillText & vbCrLf & vbCrLf & _
           "Generated labels corrected FROM PD6: " & CStr(correctedGeneratedLabels) & vbCrLf & _
           "Ambiguous labels not changed: " & CStr(ambiguousGeneratedLabels) & vbCrLf & _
           "Unresolved labels not changed: " & CStr(unresolvedGeneratedLabels) & vbCrLf & _
           "Freshness issues: " & CStr(freshnessIssueCount) & vbCrLf & _
           "Capacity issues: " & CStr(capacityIssueCount) & vbCrLf & vbCrLf & _
           "Step10A never runs the PD6 load/PSU allocator. A later Step05 re-import can supersede manual backfill values.", _
           IIf(freshnessIssueCount + capacityIssueCount > 0, vbExclamation, vbInformation), _
           "10A - Audit / Optional PD6 Backfill"
    Exit Sub

ErrHandler:
    On Error Resume Next
    mStep10ASkipOverloads = False
    Application.StatusBar = False
    Application.EnableEvents = previousEnableEvents
    Application.ScreenUpdating = True
    AppendLog "Step10_Refresh_Missing_Status_From_Generated_Sheets", "ERROR", Err.description
    MsgBox "Step10A generated-power audit/backfill failed:" & vbCrLf & vbCrLf & Err.description, _
           vbCritical, "10A - Audit / Optional PD6 Backfill"
End Sub


Public Sub Step10A_Rebuild_24V_Index_And_PSU_List_Only( _
           Optional ByVal showCompletionMessage As Boolean = True)

    Dim wb As Workbook
    Dim sectionMap As Object
    Dim labelBusMap As Object
    Dim labelBusMapNoPanel As Object
    Dim terminalBusMap As Object
    Dim terminalBusMapNoPanel As Object
    Dim sheetStats As Object
    Dim psuSeen As Object
    Dim scannedSheets As Long
    Dim repairedTerminals As Long
    Dim unresolvedTerminals As Long
    Dim skippedRows As Long

    On Error GoTo EH
    Set wb = ThisWorkbook
    mStep10ASkipOverloads = False

    Set sectionMap = CreateObject("Scripting.Dictionary")
    Set labelBusMap = CreateObject("Scripting.Dictionary")
    Set labelBusMapNoPanel = CreateObject("Scripting.Dictionary")
    Set terminalBusMap = CreateObject("Scripting.Dictionary")
    Set terminalBusMapNoPanel = CreateObject("Scripting.Dictionary")
    Set sheetStats = CreateObject("Scripting.Dictionary")
    Set psuSeen = CreateObject("Scripting.Dictionary")

    sectionMap.CompareMode = vbTextCompare
    labelBusMap.CompareMode = vbTextCompare
    labelBusMapNoPanel.CompareMode = vbTextCompare
    terminalBusMap.CompareMode = vbTextCompare
    terminalBusMapNoPanel.CompareMode = vbTextCompare
    sheetStats.CompareMode = vbTextCompare
    psuSeen.CompareMode = vbTextCompare

    scannedSheets = RefreshScanGenerated24VSheets( _
        wb, sectionMap, labelBusMap, labelBusMapNoPanel, _
        terminalBusMap, terminalBusMapNoPanel, sheetStats, psuSeen, _
        repairedTerminals, unresolvedTerminals, skippedRows)

    RefreshAddPD6AssignedPSUsToRegister wb, psuSeen
    RefreshWrite24VIndex wb, sheetStats, psuSeen
    wb.Worksheets(SH_24V_INDEX_REFRESH).Calculate

    If showCompletionMessage Then
        MsgBox "The 24V index and generated PSU SIS list were rebuilt from " & _
               CStr(scannedSheets) & " active panel worksheet(s).", _
               vbInformation, "ONGEN 24V PSU List"
    End If
    Exit Sub
EH:
    MsgBox "The 24V index/PSU list refresh failed." & vbCrLf & vbCrLf & _
           Err.description, vbCritical, "ONGEN 24V PSU List"
End Sub

Public Sub Step10B_Recheck_And_Clear_Solved_Audit_Issues()
    Dim issueSummary As String
    Dim freshnessIssueCount As Long
    Dim capacityIssueCount As Long
    Dim activeIssueCount As Long

    On Error GoTo EH
    Application.StatusBar = "ONGEN Step 10B: recalculating and rechecking generated-sheet audit issues..."
    Application.CalculateFull
    Step10A_Rebuild_24V_Index_And_PSU_List_Only False

    If Not RefreshStep10APreflight(ThisWorkbook, issueSummary, _
                                    freshnessIssueCount, capacityIssueCount) Then
        Err.Raise vbObjectError + 2510, _
                  "Step10B_Recheck_And_Clear_Solved_Audit_Issues", issueSummary
    End If

    activeIssueCount = freshnessIssueCount + capacityIssueCount
    RefreshOpenStep10AAudit ThisWorkbook
    Application.StatusBar = False

    MsgBox "Step 10B cross-check complete." & vbCrLf & vbCrLf & _
           "Active issues remaining: " & CStr(activeIssueCount) & vbCrLf & _
           "Solved issues cleared from the audit: " & CStr(mStep10AResolvedCleared) & vbCrLf & vbCrLf & _
           "Step 07 was not run and generated worksheets were not rebuilt.", _
           vbInformation, "ONGEN Step 10B Audit Recheck"
    Exit Sub
EH:
    Application.StatusBar = False
    MsgBox "Step 10B audit recheck failed." & vbCrLf & vbCrLf & _
           Err.description, vbCritical, "ONGEN Step 10B"
End Sub

'-------------------------------------------------------------------------------
' Procedure : RefreshScanGenerated24VSheets
' Scope/Type: Private Function
' Purpose   : Refreshes scan generated 24 v sheets.
' Parameters:
' wb (Workbook) - Supplies workbook.
' sectionMap (Object) - Supplies section map.
' labelBusMap (Object) - Supplies label bus map.
' labelBusMapNoPanel (Object) - Supplies label bus map no panel.
' sheetStats (Object) - Supplies sheet stats.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshScanGenerated24VSheets(ByVal wb As Workbook, _
                                               ByVal sectionMap As Object, _
                                               ByVal labelBusMap As Object, _
                                               ByVal labelBusMapNoPanel As Object, _
                                               ByVal terminalBusMap As Object, _
                                               ByVal terminalBusMapNoPanel As Object, _
                                               ByVal sheetStats As Object, _
                                               ByVal psuSeen As Object, _
                                               ByRef repairedGeneratedTerminals As Long, _
                                               ByRef unresolvedGeneratedTerminals As Long, _
                                               ByRef skippedOverloadedRows As Long) As Long

    Dim ws As Worksheet
    Dim scannedCount As Long

    For Each ws In wb.Worksheets
        If RefreshIsGenerated24VSheet(ws.Name) Then
            RefreshScanOne24VSheet ws, sectionMap, labelBusMap, labelBusMapNoPanel, _
                                      terminalBusMap, terminalBusMapNoPanel, sheetStats, psuSeen, _
                                      repairedGeneratedTerminals, unresolvedGeneratedTerminals, _
                                      skippedOverloadedRows
            scannedCount = scannedCount + 1
        End If
    Next ws

    RefreshScanGenerated24VSheets = scannedCount
End Function
'-------------------------------------------------------------------------------
' Procedure : RefreshScanOne24VSheet
' Scope/Type: Private Sub
' Purpose   : Refreshes scan one 24 v sheet.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' sectionMap (Object) - Supplies section map.
' labelBusMap (Object) - Supplies label bus map.
' labelBusMapNoPanel (Object) - Supplies label bus map no panel.
' sheetStats (Object) - Supplies sheet stats.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub RefreshScanOne24VSheet(ByVal ws As Worksheet, _
                                   ByVal sectionMap As Object, _
                                   ByVal labelBusMap As Object, _
                                   ByVal labelBusMapNoPanel As Object, _
                                   ByVal terminalBusMap As Object, _
                                   ByVal terminalBusMapNoPanel As Object, _
                                   ByVal sheetStats As Object, _
                                   ByVal psuSeen As Object, _
                                   ByRef repairedGeneratedTerminals As Long, _
                                   ByRef unresolvedGeneratedTerminals As Long, _
                                   ByRef skippedOverloadedRows As Long)

    Dim lastRow As Long
    Dim r As Long
    Dim panelDisplay As String
    Dim panelKey As String
    Dim currentPWG As String
    Dim currentBus1PSU As String
    Dim currentBus2PSU As String
    Dim currentBus1PSURow As Long
    Dim currentBus2PSURow As Long
    Dim currentSectionHeaderRow As Long
    Dim currentBus1MissingCounted As Boolean
    Dim currentBus2MissingCounted As Boolean
    Dim rowBus As String
    Dim rowPSU As String
    Dim deviceBus As String
    Dim nextTableBus As String
    Dim deviceRow As Long
    Dim deviceLabel As String
    Dim alternateDeviceLabel As String
    Dim deviceTerminal As String
    Dim insideTerminal As String
    Dim psuForDevice As String
    Dim psuTerminalRow As Long
    Dim firstDeviceInSection As Boolean
    Dim terminalLoads As Object
    Dim loadAmps As Double

    panelDisplay = RefreshPanelNameFrom24VSheet(ws.Name)
    panelKey = RefreshNormalizePanelKey(panelDisplay)
    lastRow = RefreshLastUsedRow(ws)

    currentPWG = vbNullString
    currentBus1PSU = vbNullString
    currentBus2PSU = vbNullString

    For r = 1 To lastRow

        If RefreshIsPSUSectionHeader(ws, r) Then

            currentSectionHeaderRow = r
            currentPWG = vbNullString
            currentBus1PSU = vbNullString
            currentBus2PSU = vbNullString
            currentBus1PSURow = 0
            currentBus2PSURow = 0
            currentBus1MissingCounted = False
            currentBus2MissingCounted = False

            If r + 1 <= lastRow Then
                rowBus = RefreshNormalizeBus(ws.Cells(r + 1, 2).Value2)
                rowPSU = RefreshNormalizePSU(ws.Cells(r + 1, 3).Value2)
                If rowBus = "BUS-1" Then
                    currentPWG = RefreshSafeText(ws.Cells(r + 1, 1).Value2)
                    currentBus1PSU = rowPSU
                    currentBus1PSURow = r + 1
                    RefreshAddSectionPSU sectionMap, sheetStats, psuSeen, panelDisplay, _
                                         panelKey, ws.Name, currentPWG, "BUS-1", rowPSU
                    RefreshFormatPSUCell ws.Cells(r + 1, 3), False
                ElseIf rowBus = "BUS-2" Then
                    currentPWG = RefreshSafeText(ws.Cells(r + 1, 1).Value2)
                    currentBus2PSU = rowPSU
                    currentBus2PSURow = r + 1
                    RefreshAddSectionPSU sectionMap, sheetStats, psuSeen, panelDisplay, _
                                         panelKey, ws.Name, currentPWG, "BUS-2", rowPSU
                    RefreshFormatPSUCell ws.Cells(r + 1, 3), False
                End If
            End If

            If r + 2 <= lastRow Then
                rowBus = RefreshNormalizeBus(ws.Cells(r + 2, 2).Value2)
                rowPSU = RefreshNormalizePSU(ws.Cells(r + 2, 3).Value2)
                If rowBus = "BUS-1" Then
                    If Len(currentPWG) = 0 Then _
                        currentPWG = RefreshSafeText(ws.Cells(r + 2, 1).Value2)
                    currentBus1PSU = rowPSU
                    currentBus1PSURow = r + 2
                    RefreshAddSectionPSU sectionMap, sheetStats, psuSeen, panelDisplay, _
                                         panelKey, ws.Name, currentPWG, "BUS-1", rowPSU
                    RefreshFormatPSUCell ws.Cells(r + 2, 3), False
                ElseIf rowBus = "BUS-2" Then
                    If Len(currentPWG) = 0 Then _
                        currentPWG = RefreshSafeText(ws.Cells(r + 2, 1).Value2)
                    currentBus2PSU = rowPSU
                    currentBus2PSURow = r + 2
                    RefreshAddSectionPSU sectionMap, sheetStats, psuSeen, panelDisplay, _
                                         panelKey, ws.Name, currentPWG, "BUS-2", rowPSU
                    RefreshFormatPSUCell ws.Cells(r + 2, 3), False
                End If
            End If

        ElseIf RefreshIsDeviceTableHeader(ws, r, deviceBus) Then

            If deviceBus = "BUS-1" Then
                psuForDevice = RefreshNormalizePSU(currentBus1PSU)
                psuTerminalRow = currentBus1PSURow
            ElseIf deviceBus = "BUS-2" Then
                psuForDevice = RefreshNormalizePSU(currentBus2PSU)
                psuTerminalRow = currentBus2PSURow
            Else
                psuForDevice = vbNullString
                psuTerminalRow = 0
            End If

            Set terminalLoads = RefreshBuildSectionTerminalLoads(ws, r, lastRow)
            firstDeviceInSection = True
            deviceRow = r + 1

            Do While deviceRow <= lastRow

                If RefreshIsPSUSectionHeader(ws, deviceRow) Then Exit Do
                nextTableBus = vbNullString
                If RefreshIsDeviceTableHeader(ws, deviceRow, nextTableBus) Then Exit Do

                deviceLabel = RefreshSafeText(ws.Cells(deviceRow, 1).Value2)
                If Len(deviceLabel) = 0 Then GoTo NextGeneratedDeviceRow
                If UCase$(deviceLabel) = "SIS_ELEMENT_NUMBER" Then Exit Do

                If Len(deviceBus) > 0 Then
                    If firstDeviceInSection Then
                        firstDeviceInSection = False

                        If RefreshIsMissingPSUValue(psuForDevice) Then
                            If deviceBus = "BUS-1" And Not currentBus1MissingCounted Then
                                RefreshIncrementActiveMissingPSU sheetStats, panelDisplay, _
                                                                 panelKey, ws.Name, "BUS-1"
                                currentBus1MissingCounted = True
                                If currentBus1PSURow > 0 Then _
                                    RefreshFormatPSUCell ws.Cells(currentBus1PSURow, 3), True
                            ElseIf deviceBus = "BUS-2" And Not currentBus2MissingCounted Then
                                RefreshIncrementActiveMissingPSU sheetStats, panelDisplay, _
                                                                 panelKey, ws.Name, "BUS-2"
                                currentBus2MissingCounted = True
                                If currentBus2PSURow > 0 Then _
                                    RefreshFormatPSUCell ws.Cells(currentBus2PSURow, 3), True
                            End If
                        End If
                    End If

                    loadAmps = RefreshParseAmps(ws.Cells(deviceRow, 3).Value2)
                    deviceTerminal = _
                        RefreshNormalizeTerminalValue(ws.Cells(deviceRow, 7).Value2)

                    If RefreshShouldSkipGeneratedDevice( _
                           ws.Name, currentSectionHeaderRow, deviceBus, _
                           deviceTerminal) Then
                        skippedOverloadedRows = skippedOverloadedRows + 1
                        RefreshIncrementDeviceRows sheetStats, panelDisplay, _
                                                   panelKey, ws.Name
                        ws.Range(ws.Cells(deviceRow, 1), _
                                 ws.Cells(deviceRow, 8)).Interior.Color = _
                                 RGB(255, 235, 156)
                        GoTo NextGeneratedDeviceRow
                    End If

                    If Not RefreshIsMissingPSUValue(psuForDevice) And _
                       Len(deviceTerminal) = 0 Then

                        deviceTerminal = RefreshNextSafeTerminalFromPSURow( _
                                             ws, psuTerminalRow, terminalLoads, loadAmps)

                        If Len(deviceTerminal) > 0 Then
                            ws.Cells(deviceRow, 7).Value2 = deviceTerminal
                            insideTerminal = RefreshInsideTerminalDescription( _
                                                 ws, psuTerminalRow, deviceTerminal)
                            If Len(insideTerminal) > 0 Then _
                                ws.Cells(deviceRow, 8).Value2 = insideTerminal
                            RefreshAddTerminalLoad terminalLoads, deviceTerminal, loadAmps
                            ws.Cells(deviceRow, 7).Font.ColorIndex = xlAutomatic
                            ws.Cells(deviceRow, 7).Font.Bold = False
                            repairedGeneratedTerminals = repairedGeneratedTerminals + 1
                        Else
                            unresolvedGeneratedTerminals = _
                                unresolvedGeneratedTerminals + 1
                            ws.Cells(deviceRow, 7).Font.Color = vbRed
                            ws.Cells(deviceRow, 7).Font.Bold = True
                        End If

                    ElseIf Len(deviceTerminal) > 0 Then

                        insideTerminal = RefreshSafeText(ws.Cells(deviceRow, 8).Value2)
                        If Len(insideTerminal) = 0 Then
                            insideTerminal = RefreshInsideTerminalDescription( _
                                                 ws, psuTerminalRow, deviceTerminal)
                            If Len(insideTerminal) > 0 Then _
                                ws.Cells(deviceRow, 8).Value2 = insideTerminal
                        End If
                    End If

                    alternateDeviceLabel = _
                        RefreshSafeText(ws.Cells(deviceRow, 11).Value2)

                    RefreshAddLabelBusPSU labelBusMap, labelBusMapNoPanel, _
                                          panelKey, deviceLabel, deviceBus, psuForDevice
                    RefreshAddLabelBusValue terminalBusMap, terminalBusMapNoPanel, _
                                            panelKey, deviceLabel, deviceBus, deviceTerminal

                    If Len(alternateDeviceLabel) > 0 And _
                       StrComp(alternateDeviceLabel, deviceLabel, _
                               vbTextCompare) <> 0 Then
                        RefreshAddLabelBusPSU labelBusMap, labelBusMapNoPanel, _
                                              panelKey, alternateDeviceLabel, _
                                              deviceBus, psuForDevice
                        RefreshAddLabelBusValue terminalBusMap, _
                                                terminalBusMapNoPanel, panelKey, _
                                                alternateDeviceLabel, deviceBus, _
                                                deviceTerminal
                    End If

                    RefreshIncrementDeviceRows sheetStats, panelDisplay, _
                                               panelKey, ws.Name
                End If

NextGeneratedDeviceRow:
                deviceRow = deviceRow + 1
            Loop
        End If
    Next r
End Sub
'-------------------------------------------------------------------------------
' Procedure : RefreshAddSectionPSU
' Scope/Type: Private Sub
' Purpose   : Refreshes add section PSU.
' Parameters:
' sectionMap (Object) - Supplies section map.
' sheetStats (Object) - Supplies sheet stats.
' panelDisplay (String) - Supplies panel display.
' panelKey (String) - Supplies panel key.
' sheetName (String) - Supplies sheet name.
' pwg (String) - Supplies power group.
' busName (String) - Supplies bus name.
' psuName (String) - Supplies PSU name.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshBuildSectionTerminalLoads(ByVal ws As Worksheet, _
                                                  ByVal tableHeaderRow As Long, _
                                                  ByVal lastRow As Long) As Object

    Dim terminalLoads As Object
    Dim r As Long
    Dim nextBus As String
    Dim deviceLabel As String
    Dim terminalName As String
    Dim loadAmps As Double

    Set terminalLoads = CreateObject("Scripting.Dictionary")
    terminalLoads.CompareMode = vbTextCompare

    For r = tableHeaderRow + 1 To lastRow
        If RefreshIsPSUSectionHeader(ws, r) Then Exit For

        nextBus = vbNullString
        If RefreshIsDeviceTableHeader(ws, r, nextBus) Then Exit For

        deviceLabel = RefreshSafeText(ws.Cells(r, 1).Value2)
        If Len(deviceLabel) > 0 And _
           UCase$(deviceLabel) <> "SIS_ELEMENT_NUMBER" Then

            terminalName = _
                RefreshNormalizeTerminalValue(ws.Cells(r, 7).Value2)
            If Len(terminalName) > 0 Then
                loadAmps = RefreshParseAmps(ws.Cells(r, 3).Value2)
                RefreshAddTerminalLoad terminalLoads, terminalName, loadAmps
            End If
        End If
    Next r

    Set RefreshBuildSectionTerminalLoads = terminalLoads
End Function

Private Function RefreshNextSafeTerminalFromPSURow(ByVal ws As Worksheet, _
                                                   ByVal psuRow As Long, _
                                                   ByVal terminalLoads As Object, _
                                                   ByVal loadAmps As Double) As String

    Dim c As Long
    Dim terminalName As String
    Dim existingLoad As Double

    If psuRow <= 0 Then Exit Function
    If loadAmps < 0# Then loadAmps = 0#
    If loadAmps > TERMINAL_CAPACITY_AMPS_REFRESH Then Exit Function

    For c = 5 To 8
        terminalName = _
            RefreshNormalizeTerminalValue(ws.Cells(psuRow, c).Value2)
        If Len(terminalName) = 0 Then _
            terminalName = RefreshDefaultTerminalName(c - 4)

        existingLoad = RefreshDictionaryDouble(terminalLoads, terminalName)
        If existingLoad + loadAmps <= TERMINAL_CAPACITY_AMPS_REFRESH Then
            RefreshNextSafeTerminalFromPSURow = terminalName
            Exit Function
        End If
    Next c
End Function

Private Sub RefreshAddTerminalLoad(ByVal terminalLoads As Object, _
                                   ByVal terminalName As String, _
                                   ByVal loadAmps As Double)

    terminalName = RefreshNormalizeTerminalValue(terminalName)
    If terminalLoads Is Nothing Then Exit Sub
    If Len(terminalName) = 0 Then Exit Sub
    If loadAmps < 0# Then loadAmps = 0#

    terminalLoads(terminalName) = _
        RefreshDictionaryDouble(terminalLoads, terminalName) + loadAmps
End Sub

Private Function RefreshDictionaryDouble(ByVal dictObj As Object, _
                                         ByVal keyText As String) As Double
    If dictObj Is Nothing Then Exit Function
    If dictObj.Exists(keyText) Then
        If IsNumeric(dictObj(keyText)) Then _
            RefreshDictionaryDouble = CDbl(dictObj(keyText))
    End If
End Function

Private Function RefreshParseAmps(ByVal valueIn As Variant) As Double

    Dim s As String

    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then _
        Exit Function

    If IsNumeric(valueIn) Then
        RefreshParseAmps = CDbl(valueIn)
        Exit Function
    End If

    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace(s, "AMPS", "")
    s = Replace(s, "AMP", "")
    s = Replace(s, "A", "")
    s = Replace(s, ",", "")

    If IsNumeric(s) Then RefreshParseAmps = CDbl(s)
End Function

Private Function RefreshNormalizeTerminalValue(ByVal valueIn As Variant) As String

    Dim s As String
    Dim u As String

    s = RefreshSafeText(valueIn)
    u = UCase$(Trim$(s))

    If Len(u) = 0 Then Exit Function
    If Left$(u, 7) = "MISSING" Then Exit Function
    If InStr(1, u, "PSU REQUIRED", vbTextCompare) > 0 Then Exit Function
    If InStr(1, u, "DEVICE OVER LIMIT", vbTextCompare) > 0 Then Exit Function

    RefreshNormalizeTerminalValue = Trim$(s)
End Function

Private Function RefreshDefaultTerminalName(ByVal terminalIndex As Long) As String

    Select Case terminalIndex
        Case 1: RefreshDefaultTerminalName = "X1TERM05"
        Case 2: RefreshDefaultTerminalName = "X1TERM07"
        Case 3: RefreshDefaultTerminalName = "X1TERM09"
        Case 4: RefreshDefaultTerminalName = "X1TERM11"
    End Select
End Function

Private Function RefreshInsideTerminalDescription( _
                 ByVal wsGenerated As Worksheet, _
                 ByVal psuRow As Long, _
                 ByVal terminalName As String) As String

    Dim wsData As Worksheet
    Dim headerRow As Long
    Dim cTerm As Long
    Dim cDesc As Long
    Dim lastRow As Long
    Dim r As Long
    Dim c As Long
    Dim candidate As String

    terminalName = RefreshNormalizeTerminalValue(terminalName)
    If Len(terminalName) = 0 Then Exit Function

    lastRow = RefreshLastUsedRow(wsGenerated)
    For r = 1 To lastRow
        If StrComp( _
             RefreshNormalizeTerminalValue(wsGenerated.Cells(r, 7).Value2), _
             terminalName, vbTextCompare) = 0 Then

            candidate = RefreshSafeText(wsGenerated.Cells(r, 8).Value2)
            If Len(candidate) > 0 Then
                RefreshInsideTerminalDescription = candidate
                Exit Function
            End If
        End If
    Next r

    If RefreshWorksheetExists(ThisWorkbook, "480v_DATA_POWER") Then
        Set wsData = ThisWorkbook.Worksheets("480v_DATA_POWER")
        headerRow = RefreshFindHeaderRow(wsData, Array("PSU TERM"))

        If headerRow > 0 Then
            cTerm = RefreshFindHeaderCol(wsData, headerRow, _
                                         "PSU TERM", "PSU_TERM", _
                                         "PSU TERMINAL")
            cDesc = RefreshFindHeaderCol(wsData, headerRow, _
                                         "DESCPSU", "PSUDESC", _
                                         "PSU DESC")

            If cTerm > 0 And cDesc > 0 Then
                lastRow = RefreshLastUsedRow(wsData)
                For r = headerRow + 1 To lastRow
                    If StrComp( _
                         RefreshNormalizeTerminalValue( _
                             wsData.Cells(r, cTerm).Value2), _
                         terminalName, vbTextCompare) = 0 Then

                        candidate = _
                            RefreshSafeText(wsData.Cells(r, cDesc).Value2)
                        If Len(candidate) > 0 Then
                            RefreshInsideTerminalDescription = candidate
                            Exit Function
                        End If
                    End If
                Next r
            End If
        End If
    End If

    If psuRow > 0 Then
        For c = 5 To 8
            If StrComp( _
                 RefreshNormalizeTerminalValue( _
                     wsGenerated.Cells(psuRow, c).Value2), _
                 terminalName, vbTextCompare) = 0 Then

                RefreshInsideTerminalDescription = _
                    "DC" & CStr(c - 4) & "+/DC" & _
                    CStr(c - 4) & "-"
                Exit Function
            End If
        Next c
    End If
End Function

Private Sub RefreshAddSectionPSU(ByVal sectionMap As Object, _
                                 ByVal sheetStats As Object, _
                                 ByVal psuSeen As Object, _
                                 ByVal panelDisplay As String, _
                                 ByVal panelKey As String, _
                                 ByVal sheetName As String, _
                                 ByVal pwg As String, _
                                 ByVal busName As String, _
                                 ByVal psuName As String)

    Dim sectionKey As String
    Dim statsKey As String
    Dim psuKey As String
    Dim stats As Variant
    Dim psuInfo As Variant
    Dim areaNumber As String
    Dim busList As String

    psuName = RefreshNormalizePSU(psuName)
    sectionKey = panelKey & "|" & UCase$(Trim$(pwg)) & "|" & _
                 UCase$(busName) & "|" & CStr(sectionMap.count + 1)
    sectionMap(sectionKey) = psuName

    statsKey = panelKey & "|" & sheetName
    If Not sheetStats.Exists(statsKey) Then
        sheetStats.Add statsKey, Array(panelDisplay, sheetName, CLng(0), CLng(0), CLng(0), CLng(0))
    End If

    If Not RefreshIsMissingPSUValue(psuName) Then
        stats = sheetStats(statsKey)
        psuKey = statsKey & "|" & UCase$(psuName)
        areaNumber = RefreshAreaFromSISElementNumber(psuName)
        If Len(areaNumber) = 0 Then areaNumber = "UNASSIGNED"

        If Not psuSeen.Exists(psuKey) Then
            psuSeen.Add psuKey, Array(areaNumber, panelDisplay, pwg, _
                                      psuName, UCase$(Trim$(busName)), sheetName)
            stats(4) = CLng(stats(4)) + 1
            sheetStats(statsKey) = stats
        Else
            psuInfo = psuSeen(psuKey)
            busList = CStr(psuInfo(4))
            If InStr(1, "|" & busList & "|", _
                     "|" & UCase$(Trim$(busName)) & "|", vbTextCompare) = 0 Then
                If Len(busList) > 0 Then busList = busList & "|"
                psuInfo(4) = busList & UCase$(Trim$(busName))
                psuSeen(psuKey) = psuInfo
            End If
        End If
    End If
End Sub

Private Function RefreshAreaFromSISElementNumber(ByVal sisElementNumber As String) As String
    Dim normalized As String
    Dim parts As Variant

    normalized = Trim$(Replace(sisElementNumber, "_", "-"))
    If Len(normalized) = 0 Then Exit Function
    parts = Split(normalized, "-")
    If UBound(parts) >= 0 Then RefreshAreaFromSISElementNumber = Trim$(CStr(parts(0)))
End Function
Private Sub RefreshIncrementActiveMissingPSU(ByVal sheetStats As Object, _
                                             ByVal panelDisplay As String, _
                                             ByVal panelKey As String, _
                                             ByVal sheetName As String, _
                                             ByVal busName As String)

    Dim statsKey As String
    Dim stats As Variant

    statsKey = panelKey & "|" & sheetName
    If Not sheetStats.Exists(statsKey) Then
        sheetStats.Add statsKey, Array(panelDisplay, sheetName, CLng(0), CLng(0), CLng(0), CLng(0))
    End If

    stats = sheetStats(statsKey)
    If UCase$(busName) = "BUS-1" Then
        stats(2) = CLng(stats(2)) + 1
    ElseIf UCase$(busName) = "BUS-2" Then
        stats(3) = CLng(stats(3)) + 1
    End If
    sheetStats(statsKey) = stats
End Sub
Private Sub RefreshIncrementDeviceRows(ByVal sheetStats As Object, _
                                       ByVal panelDisplay As String, _
                                       ByVal panelKey As String, _
                                       ByVal sheetName As String)
    Dim statsKey As String
    Dim stats As Variant

    statsKey = panelKey & "|" & sheetName
    If Not sheetStats.Exists(statsKey) Then
        sheetStats.Add statsKey, Array(panelDisplay, sheetName, CLng(0), CLng(0), CLng(0), CLng(0))
    End If

    stats = sheetStats(statsKey)
    stats(5) = CLng(stats(5)) + 1
    sheetStats(statsKey) = stats
End Sub

'-------------------------------------------------------------------------------
' Procedure : RefreshAddLabelBusPSU
' Scope/Type: Private Sub
' Purpose   : Refreshes add label bus PSU.
' Parameters:
' labelBusMap (Object) - Supplies label bus map.
' labelBusMapNoPanel (Object) - Supplies label bus map no panel.
' panelKey (String) - Supplies panel key.
' deviceLabel (String) - Supplies device label.
' busName (String) - Supplies bus name.
' psuName (String) - Supplies PSU name.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub RefreshAddLabelBusPSU(ByVal labelBusMap As Object, _
                                  ByVal labelBusMapNoPanel As Object, _
                                  ByVal panelKey As String, _
                                  ByVal deviceLabel As String, _
                                  ByVal busName As String, _
                                  ByVal psuName As String)

    Dim fullKey As String
    Dim noPanelKey As String
    Dim currentValue As String

    deviceLabel = RefreshNormalizeLabelKey(deviceLabel)
    busName = RefreshNormalizeBus(busName)
    psuName = RefreshNormalizePSU(psuName)

    If Len(deviceLabel) = 0 Or Len(busName) = 0 Then Exit Sub

    fullKey = panelKey & "|" & deviceLabel & "|" & busName
    'Do not silently overwrite conflicting values for the same panel/device/bus.
    If Not labelBusMap.Exists(fullKey) Then
        labelBusMap.Add fullKey, psuName
    ElseIf StrComp(RefreshSafeText(labelBusMap(fullKey)), psuName, vbTextCompare) <> 0 Then
        labelBusMap(fullKey) = "<<AMBIGUOUS>>"
    End If

    noPanelKey = deviceLabel & "|" & busName
    If Not labelBusMapNoPanel.Exists(noPanelKey) Then
        labelBusMapNoPanel.Add noPanelKey, psuName
    Else
        currentValue = RefreshSafeText(labelBusMapNoPanel(noPanelKey))
        If StrComp(currentValue, psuName, vbTextCompare) <> 0 Then
            'AMBIGUOUS prevents unsafe fallback updates when the same device label
            'appears in multiple generated panels with different PSU values.
            labelBusMapNoPanel(noPanelKey) = "<<AMBIGUOUS>>"
        End If
    End If

End Sub

Private Sub RefreshAddLabelBusValue(ByVal valueMap As Object, _
                                    ByVal valueMapNoPanel As Object, _
                                    ByVal panelKey As String, _
                                    ByVal deviceLabel As String, _
                                    ByVal busName As String, _
                                    ByVal mapValue As String)

    Dim fullKey As String
    Dim noPanelKey As String
    Dim currentValue As String

    deviceLabel = RefreshNormalizeLabelKey(deviceLabel)
    busName = RefreshNormalizeBus(busName)
    mapValue = Trim$(CStr(mapValue))

    If Len(deviceLabel) = 0 Or Len(busName) = 0 Then Exit Sub

    fullKey = panelKey & "|" & deviceLabel & "|" & busName
    If Not valueMap.Exists(fullKey) Then
        valueMap.Add fullKey, mapValue
    ElseIf StrComp(RefreshSafeText(valueMap(fullKey)), mapValue, vbTextCompare) <> 0 Then
        valueMap(fullKey) = "<<AMBIGUOUS>>"
    End If

    noPanelKey = deviceLabel & "|" & busName
    If Not valueMapNoPanel.Exists(noPanelKey) Then
        valueMapNoPanel.Add noPanelKey, mapValue
    Else
        currentValue = RefreshSafeText(valueMapNoPanel(noPanelKey))
        If StrComp(currentValue, mapValue, vbTextCompare) <> 0 Then
            valueMapNoPanel(noPanelKey) = "<<AMBIGUOUS>>"
        End If
    End If
End Sub


'-------------------------------------------------------------------------------
' Procedure : RefreshSyncPD6ImportFromGeneratedMaps
' Scope/Type: Private Function
' Purpose   : Refreshes sync pd 6 import from generated maps.
' Parameters:
' wsPD6 (Worksheet) - Supplies worksheet pd 6.
' labelBusMap (Object) - Supplies label bus map.
' labelBusMapNoPanel (Object) - Supplies label bus map no panel.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshSyncPD6ImportFromGeneratedMaps( _
                 ByVal wsPD6 As Worksheet, _
                 ByVal labelBusMap As Object, _
                 ByVal labelBusMapNoPanel As Object, _
                 ByVal terminalBusMap As Object, _
                 ByVal terminalBusMapNoPanel As Object, _
                 ByRef matchedRows As Long, _
                 ByRef partiallyMatchedRows As Long, _
                 ByRef unmatchedRows As Long) As Long

    Dim headerRow As Long
    Dim lastRow As Long
    Dim r As Long
    Dim cPNL As Long
    Dim cControlID As Long
    Dim cSIS As Long
    Dim cSisSeq As Long
    Dim cBus As Long
    Dim cPSU As Long
    Dim cTerm1 As Long
    Dim cTerm2 As Long
    Dim cLoad1 As Long
    Dim cLoad2 As Long
    Dim panelKey As String
    Dim labelKey As String
    Dim sisKey As String
    Dim sisSeqKey As String
    Dim busList As Collection
    Dim busItem As Variant
    Dim psuName As String
    Dim terminalName As String
    Dim oldPSUText As String
    Dim newPSUText As String
    Dim oldBusText As String
    Dim newBusText As String
    Dim matchedBusCount As Long
    Dim rowChanged As Boolean
    Dim changedRows As Long

    matchedRows = 0
    partiallyMatchedRows = 0
    unmatchedRows = 0
    If wsPD6 Is Nothing Then Exit Function

    headerRow = RefreshFindHeaderRow(wsPD6, _
                                     Array("SIS_ELEMENT_NUMBER"))
    If headerRow = 0 Then headerRow = 1

    cPNL = RefreshFindHeaderCol(wsPD6, headerRow, _
                                "PNL", "Panel")
    cControlID = RefreshFindHeaderCol(wsPD6, headerRow, _
                                      "Control_ID", "CONTROL_ID", _
                                      "Control ID")
    cSIS = RefreshFindHeaderCol(wsPD6, headerRow, _
                                "SIS_Element_Number", _
                                "SIS ELEMENT NUMBER", _
                                "SIS_ELEMENT_NUMBER")
    cSisSeq = RefreshFindHeaderCol(wsPD6, headerRow, _
                                   "SIS_sequence", "SIS_SEQUENCE", _
                                   "Sequence")
    cBus = RefreshFindHeaderCol(wsPD6, headerRow, _
                                "Bus Power", "BUS POWER", _
                                "Power Bus")
    cPSU = RefreshFindHeaderCol(wsPD6, headerRow, _
                                "Power Supply", "POWER SUPPLY", _
                                "PSU")
    cTerm1 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Power BUS-1 Terminal", _
                                  "BUS-1 Terminal")
    cTerm2 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Power BUS-2 Terminal", _
                                  "BUS-2 Terminal")
    cLoad1 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Load BUS-1", "LOAD BUS 1", _
                                  "Load Bus1")
    cLoad2 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Load BUS-2", "LOAD BUS 2", _
                                  "Load Bus2")

    If cPSU = 0 Then Exit Function
    If cControlID = 0 And cSIS = 0 And cSisSeq = 0 Then _
        Exit Function

    lastRow = RefreshLastUsedRow(wsPD6)

    For r = headerRow + 1 To lastRow

        panelKey = vbNullString
        If cPNL > 0 Then _
            panelKey = RefreshNormalizePanelKey( _
                           wsPD6.Cells(r, cPNL).Value2)

        labelKey = vbNullString
        sisKey = vbNullString
        sisSeqKey = vbNullString

        If cControlID > 0 Then _
            labelKey = RefreshNormalizeLabelKey( _
                           wsPD6.Cells(r, cControlID).Value2)
        If cSIS > 0 Then _
            sisKey = RefreshNormalizeLabelKey( _
                         wsPD6.Cells(r, cSIS).Value2)
        If cSisSeq > 0 Then _
            sisSeqKey = RefreshNormalizeLabelKey( _
                            wsPD6.Cells(r, cSisSeq).Value2)

        If Len(labelKey) = 0 Then labelKey = sisKey
        If Len(labelKey) = 0 Then labelKey = sisSeqKey
        If Len(labelKey) = 0 Then GoTo NextPD6Row

        Set busList = RefreshGetPD6BusList( _
                          wsPD6, r, cBus, cLoad1, cLoad2)
        If busList.count = 0 Then
            Set busList = RefreshGetGeneratedBusListForPD6Row( _
                              labelBusMap, labelBusMapNoPanel, _
                              terminalBusMap, terminalBusMapNoPanel, _
                              panelKey, labelKey, sisKey, sisSeqKey)
        End If
        If busList.count = 0 Then GoTo NextPD6Row

        oldPSUText = RefreshSafeText(wsPD6.Cells(r, cPSU).Value2)
        'Preserve the current PD6 assignment. A bus is changed only when a
        'matching generated record is found. This prevents stale sheets from
        'turning an unmatched current assignment into MISSING.
        newPSUText = oldPSUText

        oldBusText = vbNullString
        If cBus > 0 Then _
            oldBusText = RefreshSafeText(wsPD6.Cells(r, cBus).Value2)
        newBusText = RefreshBusListDisplay(busList)

        matchedBusCount = 0
        rowChanged = False

        For Each busItem In busList

            psuName = RefreshLookupGeneratedValue( _
                          labelBusMap, labelBusMapNoPanel, _
                          panelKey, labelKey, CStr(busItem))

            If Len(psuName) = 0 And Len(sisKey) > 0 And _
               StrComp(labelKey, sisKey, vbTextCompare) <> 0 Then
                psuName = RefreshLookupGeneratedValue( _
                              labelBusMap, labelBusMapNoPanel, _
                              panelKey, sisKey, CStr(busItem))
            End If

            If Len(psuName) = 0 And Len(sisSeqKey) > 0 Then
                psuName = RefreshLookupGeneratedValue( _
                              labelBusMap, labelBusMapNoPanel, _
                              panelKey, sisSeqKey, CStr(busItem))
            End If

            terminalName = RefreshLookupGeneratedValue( _
                               terminalBusMap, _
                               terminalBusMapNoPanel, _
                               panelKey, labelKey, _
                               CStr(busItem))

            If Len(terminalName) = 0 And Len(sisKey) > 0 And _
               StrComp(labelKey, sisKey, vbTextCompare) <> 0 Then
                terminalName = RefreshLookupGeneratedValue( _
                                   terminalBusMap, _
                                   terminalBusMapNoPanel, _
                                   panelKey, sisKey, _
                                   CStr(busItem))
            End If

            If Len(terminalName) = 0 And Len(sisSeqKey) > 0 Then
                terminalName = RefreshLookupGeneratedValue( _
                                   terminalBusMap, _
                                   terminalBusMapNoPanel, _
                                   panelKey, sisSeqKey, _
                                   CStr(busItem))
            End If

            terminalName = _
                RefreshNormalizeTerminalValue(terminalName)

            If Len(psuName) > 0 Or Len(terminalName) > 0 Then
                matchedBusCount = matchedBusCount + 1
            End If

            If Len(psuName) > 0 Then
                newPSUText = RefreshSetPowerSupplyEntry( _
                                 newPSUText, CStr(busItem), _
                                 psuName, busList.count > 1)
            End If

            If UCase$(CStr(busItem)) = "BUS-1" And _
               cTerm1 > 0 Then

                If Len(terminalName) > 0 Then
                    If StrComp( _
                         RefreshSafeText( _
                             wsPD6.Cells(r, cTerm1).Value2), _
                         terminalName, vbTextCompare) <> 0 Then

                        wsPD6.Cells(r, cTerm1).Value2 = terminalName
                        rowChanged = True
                    End If
                End If

            ElseIf UCase$(CStr(busItem)) = "BUS-2" And _
                   cTerm2 > 0 Then

                If Len(terminalName) > 0 Then
                    If StrComp( _
                         RefreshSafeText( _
                             wsPD6.Cells(r, cTerm2).Value2), _
                         terminalName, vbTextCompare) <> 0 Then

                        wsPD6.Cells(r, cTerm2).Value2 = terminalName
                        rowChanged = True
                    End If
                End If
            End If
        Next busItem

        If Len(newBusText) > 0 And cBus > 0 Then
            If StrComp(Trim$(oldBusText), Trim$(newBusText), _
                       vbTextCompare) <> 0 Then
                wsPD6.Cells(r, cBus).Value2 = newBusText
                rowChanged = True
            End If
        End If

        If StrComp(Trim$(oldPSUText), Trim$(newPSUText), _
                   vbTextCompare) <> 0 Then
            wsPD6.Cells(r, cPSU).Value2 = newPSUText
            rowChanged = True
        End If

        RefreshFormatPSUCell wsPD6.Cells(r, cPSU)

        If matchedBusCount = busList.count Then
            matchedRows = matchedRows + 1
        ElseIf matchedBusCount > 0 Then
            partiallyMatchedRows = partiallyMatchedRows + 1
        Else
            unmatchedRows = unmatchedRows + 1
        End If

        If rowChanged Then changedRows = changedRows + 1

NextPD6Row:
    Next r

    RefreshSyncPD6ImportFromGeneratedMaps = changedRows
End Function
'-------------------------------------------------------------------------------
' Procedure : RefreshLookupGeneratedPSU
' Scope/Type: Private Function
' Purpose   : Refreshes lookup generated PSU.
' Parameters:
' labelBusMap (Object) - Supplies label bus map.
' labelBusMapNoPanel (Object) - Supplies label bus map no panel.
' panelKey (String) - Supplies panel key.
' labelKey (String) - Supplies label key.
' busName (String) - Supplies bus name.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshGetGeneratedBusListForPD6Row( _
                 ByVal labelBusMap As Object, _
                 ByVal labelBusMapNoPanel As Object, _
                 ByVal terminalBusMap As Object, _
                 ByVal terminalBusMapNoPanel As Object, _
                 ByVal panelKey As String, _
                 ByVal labelKey As String, _
                 ByVal sisKey As String, _
                 ByVal sisSeqKey As String) As Collection

    Dim buses As New Collection
    Dim busName As Variant
    Dim labels As Variant
    Dim i As Long
    Dim v As String

    labels = Array(labelKey, sisKey, sisSeqKey)
    For Each busName In Array("BUS-1", "BUS-2")
        For i = LBound(labels) To UBound(labels)
            If Len(CStr(labels(i))) > 0 Then
                v = RefreshLookupGeneratedValue(labelBusMap, labelBusMapNoPanel, _
                                                panelKey, CStr(labels(i)), CStr(busName))
                If Len(v) = 0 Then
                    v = RefreshLookupGeneratedValue(terminalBusMap, terminalBusMapNoPanel, _
                                                    panelKey, CStr(labels(i)), CStr(busName))
                End If
                If Len(v) > 0 Then
                    buses.Add CStr(busName)
                    Exit For
                End If
            End If
        Next i
    Next busName
    Set RefreshGetGeneratedBusListForPD6Row = buses
End Function

Private Function RefreshLookupGeneratedValue(ByVal labelBusMap As Object, _
                                           ByVal labelBusMapNoPanel As Object, _
                                           ByVal panelKey As String, _
                                           ByVal labelKey As String, _
                                           ByVal busName As String) As String

    Dim fullKey As String
    Dim noPanelKey As String
    Dim val As String

    labelKey = RefreshNormalizeLabelKey(labelKey)
    busName = RefreshNormalizeBus(busName)

    If Len(panelKey) > 0 Then
        fullKey = panelKey & "|" & labelKey & "|" & busName
        If labelBusMap.Exists(fullKey) Then
            val = RefreshSafeText(labelBusMap(fullKey))
            If val <> "<<AMBIGUOUS>>" Then
                RefreshLookupGeneratedValue = val
                Exit Function
            End If
        End If
    End If

    noPanelKey = labelKey & "|" & busName
    If labelBusMapNoPanel.Exists(noPanelKey) Then
        val = RefreshSafeText(labelBusMapNoPanel(noPanelKey))
        If val <> "<<AMBIGUOUS>>" Then RefreshLookupGeneratedValue = val
    End If

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshWrite24VIndex
' Scope/Type: Private Sub
' Purpose   : Rebuilds the consolidated 24V panel index.
' Parameters:
' wb (Workbook) - Supplies workbook.
' sheetStats (Object) - Supplies sheet stats.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub RefreshAddPD6AssignedPSUsToRegister(ByVal wb As Workbook, ByVal psuSeen As Object)
    Dim ws As Worksheet
    Dim headerRow As Long, lastRow As Long, r As Long
    Dim cArea As Long, cPanel As Long, cSWG As Long, cPSU As Long, cBus As Long
    Dim areaText As String, panelText As String, swgText As String
    Dim psuText As String, busText As String, sheetText As String, keyText As String
    Dim info As Variant

    If psuSeen Is Nothing Then Exit Sub
    If Not RefreshWorksheetExists(wb, SH_PD6_REFRESH) Then Exit Sub
    Set ws = wb.Worksheets(SH_PD6_REFRESH)
    headerRow = RefreshFindHeaderRow(ws, Array("SIS_sequence", "PNL", "Power Supply"))
    If headerRow = 0 Then headerRow = 1

    cArea = RefreshFindHeaderCol(ws, headerRow, "AREA_Number", "AREA NUMBER")
    cPanel = RefreshFindHeaderCol(ws, headerRow, "PNL", "PANEL")
    cSWG = RefreshFindHeaderCol(ws, headerRow, "SwitchGroup", "SWITCHGROUP", "PWG")
    cPSU = RefreshFindHeaderCol(ws, headerRow, "Power Supply", "POWER SUPPLY", "PD6_POWER_SUPPLY")
    cBus = RefreshFindHeaderCol(ws, headerRow, "Bus Power", "BUS POWER", "POWER BUS")
    If cPanel = 0 Or cSWG = 0 Or cPSU = 0 Then Exit Sub

    lastRow = RefreshLastUsedRow(ws)
    For r = headerRow + 1 To lastRow
        panelText = RefreshSafeText(ws.Cells(r, cPanel).Value2)
        swgText = RefreshSafeText(ws.Cells(r, cSWG).Value2)
        psuText = RefreshNormalizePSU(RefreshSafeText(ws.Cells(r, cPSU).Value2))
        If cBus > 0 Then busText = UCase$(RefreshSafeText(ws.Cells(r, cBus).Value2)) Else busText = vbNullString
        If Len(panelText) > 0 And Len(swgText) > 0 And Not RefreshIsMissingPSUValue(psuText) Then
            areaText = vbNullString
            If cArea > 0 Then areaText = RefreshSafeText(ws.Cells(r, cArea).Value2)
            If Len(areaText) = 0 Then areaText = RefreshAreaFromSISElementNumber(psuText)
            If Len(areaText) = 0 Then areaText = "UNASSIGNED"
            sheetText = RefreshExpected24VSheetName(panelText)
            If RefreshWorksheetExists(wb, sheetText) Then
                keyText = UCase$(panelText) & "|" & UCase$(sheetText) & "|" & UCase$(psuText)
                If Not psuSeen.Exists(keyText) Then
                    psuSeen.Add keyText, Array(areaText, panelText, swgText, psuText, busText, sheetText, "PD6 assignment cross-check")
                Else
                    info = psuSeen(keyText)
                    If Len(CStr(info(2))) = 0 Then info(2) = swgText
                    If Len(CStr(info(4))) = 0 Then info(4) = busText
                    psuSeen(keyText) = info
                End If
            End If
        End If
    Next r
End Sub

Private Function RefreshExpected24VSheetName(ByVal panelText As String) As String
    Dim txt As String, badChars As Variant, i As Long
    txt = Trim$(panelText) & "_24v"
    badChars = Array("/", "\", "[", "]", ":", "*", "?", Chr$(34))
    For i = LBound(badChars) To UBound(badChars)
        txt = Replace(txt, CStr(badChars(i)), "-")
    Next i
    If Len(txt) > 31 Then txt = Left$(txt, 31)
    RefreshExpected24VSheetName = txt
End Function

Private Sub RefreshWrite24VIndex(ByVal wb As Workbook, _
                                      ByVal sheetStats As Object, _
                                      ByVal psuSeen As Object)

    Dim ws As Worksheet
    Dim rowOut As Long
    Dim key As Variant
    Dim stats As Variant
    Dim psuInfo As Variant
    Dim bus1Missing As Long
    Dim bus2Missing As Long
    Dim totalMissing As Long
    Dim generatedPSUs As Long
    Dim deviceRows As Long
    Dim statusText As String
    Dim listTitleRow As Long
    Dim listHeaderRow As Long
    Dim listFirstRow As Long
    Dim listLastRow As Long

    Set ws = RefreshEnsureWorksheet(wb, SH_24V_INDEX_REFRESH)
    ws.Cells.Clear

    ws.Range("A1:I1").Value2 = Array( _
        "24V Power Generator Panel Sheet Index", _
        "PNL", "Worksheet", "Device Rows", "PSUs Generated", _
        "Missing BUS-1 PSU", "Missing BUS-2 PSU", "Total Missing PSU", "Status")
    RefreshStyleHeader ws.Range("A1:I1")
    rowOut = 2

    If sheetStats.count = 0 Then
        ws.Cells(rowOut, 1).Value2 = "No generated 24V panel sheets found."
        ws.Range("A" & rowOut & ":I" & rowOut).Merge
        rowOut = rowOut + 2
    Else
        For Each key In sheetStats.keys
            stats = sheetStats(key)
            bus1Missing = CLng(stats(2))
            bus2Missing = CLng(stats(3))
            generatedPSUs = CLng(stats(4))
            deviceRows = CLng(stats(5))
            totalMissing = bus1Missing + bus2Missing
            If totalMissing > 0 Then statusText = "MISSING PSU" Else statusText = "OK"

            ws.Cells(rowOut, 1).Value2 = "Panel 24V sheet"
            ws.Cells(rowOut, 2).Value2 = CStr(stats(0))
            ws.Cells(rowOut, 3).Value2 = CStr(stats(1))
            If RefreshWorksheetExists(wb, CStr(stats(1))) Then
                ws.Hyperlinks.Add anchor:=ws.Cells(rowOut, 3), Address:="", _
                                  SubAddress:="'" & CStr(stats(1)) & "'!A1", _
                                  TextToDisplay:=CStr(stats(1))
            End If
            ws.Cells(rowOut, 4).Value2 = deviceRows
            ws.Cells(rowOut, 5).Value2 = generatedPSUs
            ws.Cells(rowOut, 6).Value2 = bus1Missing
            ws.Cells(rowOut, 7).Value2 = bus2Missing
            ws.Cells(rowOut, 8).Value2 = totalMissing
            ws.Cells(rowOut, 9).Value2 = statusText
            If totalMissing > 0 Then ws.Range("A" & rowOut & ":I" & rowOut).Font.Bold = True
            rowOut = rowOut + 1
        Next key
    End If

    listTitleRow = rowOut + 1
    ws.Range("A" & listTitleRow & ":H" & listTitleRow).Merge
    ws.Cells(listTitleRow, 1).Value2 = "Generated PSU SIS_Element_Number List by Area"
    RefreshStyleHeader ws.Range("A" & listTitleRow & ":H" & listTitleRow)

    listHeaderRow = listTitleRow + 1
    ws.Range("A" & listHeaderRow & ":H" & listHeaderRow).Value2 = Array( _
        "AREA_Number", "PNL", "SwitchGroup", "SIS_Element_Number", _
        "Bus Power", "Worksheet", "Source", "Status")
    RefreshStyleHeader ws.Range("A" & listHeaderRow & ":H" & listHeaderRow)
    listFirstRow = listHeaderRow + 1
    rowOut = listFirstRow

    If psuSeen Is Nothing Then
        ws.Cells(rowOut, 1).Value2 = "No generated PSU SIS_Element_Number values found."
        ws.Range("A" & rowOut & ":H" & rowOut).Merge
    ElseIf psuSeen.count = 0 Then
        ws.Cells(rowOut, 1).Value2 = "No generated PSU SIS_Element_Number values found."
        ws.Range("A" & rowOut & ":H" & rowOut).Merge
    Else
        For Each key In psuSeen.keys
            psuInfo = psuSeen(key)
            ws.Cells(rowOut, 1).Value2 = CStr(psuInfo(0))
            ws.Cells(rowOut, 2).Value2 = CStr(psuInfo(1))
            ws.Cells(rowOut, 3).Value2 = CStr(psuInfo(2))
            ws.Cells(rowOut, 4).Value2 = CStr(psuInfo(3))
            ws.Cells(rowOut, 5).Value2 = Replace(CStr(psuInfo(4)), "|", ", ")
            ws.Cells(rowOut, 6).Value2 = CStr(psuInfo(5))
            If RefreshWorksheetExists(wb, CStr(psuInfo(5))) Then
                ws.Hyperlinks.Add anchor:=ws.Cells(rowOut, 6), Address:="", _
                                  SubAddress:="'" & CStr(psuInfo(5)) & "'!A1", _
                                  TextToDisplay:=CStr(psuInfo(5))
            End If
            If UBound(psuInfo) >= 6 Then
                ws.Cells(rowOut, 7).Value2 = CStr(psuInfo(6))
            Else
                ws.Cells(rowOut, 7).Value2 = "Generated 24V worksheet scan"
            End If
            ws.Cells(rowOut, 8).Value2 = "GENERATED"
            rowOut = rowOut + 1
        Next key

        listLastRow = rowOut - 1
        If listLastRow >= listFirstRow Then
            ws.Range("A" & listHeaderRow & ":H" & listLastRow).Sort _
                key1:=ws.Range("A" & listFirstRow), Order1:=xlAscending, _
                key2:=ws.Range("B" & listFirstRow), Order2:=xlAscending, _
                Key3:=ws.Range("C" & listFirstRow), Order3:=xlAscending, _
                header:=xlYes
        End If
    End If

    ws.Columns("A:I").AutoFit
    ws.Columns("D:D").columnWidth = 28
    ws.Columns("G:G").columnWidth = 32
End Sub
Private Sub RefreshDeleteLegacyPSUMissingSummary(ByVal wb As Workbook)
    Const LEGACY_SHEET_NAME As String = "PSU_MISSING_SUMMARY"
    On Error Resume Next
    If RefreshWorksheetExists(wb, LEGACY_SHEET_NAME) Then
        wb.Worksheets(LEGACY_SHEET_NAME).Delete
    End If
    On Error GoTo 0
End Sub

'-------------------------------------------------------------------------------
' Procedure : RefreshSetPowerSupplyEntry
' Scope/Type: Private Function
' Purpose   : Refreshes set power supply entry.
' Parameters:
' existingText (String) - Supplies existing text.
' busName (String) - Supplies bus name.
' psuName (String) - Supplies PSU name.
' forceBusPrefix (Boolean) - Supplies force bus prefix.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshSetPowerSupplyEntry(ByVal existingText As String, _
                                            ByVal busName As String, _
                                            ByVal psuName As String, _
                                            ByVal forceBusPrefix As Boolean) As String

    Dim bus1Value As String
    Dim bus2Value As String

    busName = RefreshNormalizeBus(busName)
    psuName = RefreshNormalizePSU(psuName)

    If Not forceBusPrefix Then
        RefreshSetPowerSupplyEntry = psuName
        Exit Function
    End If

    bus1Value = RefreshExtractPowerSupplyEntry(existingText, "BUS-1")
    bus2Value = RefreshExtractPowerSupplyEntry(existingText, "BUS-2")

    If UCase$(busName) = "BUS-1" Then
        bus1Value = psuName
    ElseIf UCase$(busName) = "BUS-2" Then
        bus2Value = psuName
    End If

    If Len(bus1Value) = 0 Then bus1Value = MISSING_PSU_TEXT_REFRESH
    If Len(bus2Value) = 0 Then bus2Value = MISSING_PSU_TEXT_REFRESH

    RefreshSetPowerSupplyEntry = "BUS-1=" & bus1Value & " | BUS-2=" & bus2Value

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshExtractPowerSupplyEntry
' Scope/Type: Private Function
' Purpose   : Refreshes extract power supply entry.
' Parameters:
' psuText (String) - Supplies PSU text.
' busName (String) - Supplies bus name.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshExtractPowerSupplyEntry(ByVal psuText As String, ByVal busName As String) As String

    Dim parts() As String
    Dim i As Long
    Dim p As String
    Dim eqPos As Long
    Dim leftText As String
    Dim rightText As String

    psuText = Trim$(CStr(psuText))
    busName = UCase$(RefreshNormalizeBus(busName))

    If Len(psuText) = 0 Then Exit Function

    If InStr(1, psuText, "=", vbTextCompare) = 0 Then
        RefreshExtractPowerSupplyEntry = RefreshNormalizePSU(psuText)
        Exit Function
    End If

    parts = Split(Replace(psuText, ";", "|"), "|")

    For i = LBound(parts) To UBound(parts)
        p = Trim$(parts(i))
        eqPos = InStr(1, p, "=", vbTextCompare)
        If eqPos > 0 Then
            leftText = RefreshNormalizeBus(Left$(p, eqPos - 1))
            rightText = RefreshNormalizePSU(mid$(p, eqPos + 1))
            If UCase$(leftText) = busName Then
                RefreshExtractPowerSupplyEntry = rightText
                Exit Function
            End If
        End If
    Next i

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshGetBusList
' Scope/Type: Private Function
' Purpose   : Refreshes get bus list.
' Parameters:
' busText (String) - Supplies bus text.
' Returns   : Collection.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshGetBusList(ByVal busText As Variant) As Collection

    Dim col As Collection
    Dim u As String

    Set col = New Collection
    u = UCase$(RefreshSafeText(busText))

    If InStr(1, u, "BUS-1", vbTextCompare) > 0 Or InStr(1, u, "BUS1", vbTextCompare) > 0 Then col.Add "BUS-1"
    If InStr(1, u, "BUS-2", vbTextCompare) > 0 Or InStr(1, u, "BUS2", vbTextCompare) > 0 Then col.Add "BUS-2"

    Set RefreshGetBusList = col

End Function


Private Function RefreshGetPD6BusList(ByVal wsPD6 As Worksheet, _
                                      ByVal rowNum As Long, _
                                      ByVal cBus As Long, _
                                      ByVal cLoad1 As Long, _
                                      ByVal cLoad2 As Long) As Collection

    Dim result As Collection
    Dim displayBuses As Collection
    Dim item As Variant

    Set result = New Collection

    If cLoad1 > 0 Then
        If RefreshHasPositiveLoad( _
             wsPD6.Cells(rowNum, cLoad1).Value2) Then
            RefreshAddUniqueBus result, "BUS-1"
        End If
    End If

    If cLoad2 > 0 Then
        If RefreshHasPositiveLoad( _
             wsPD6.Cells(rowNum, cLoad2).Value2) Then
            RefreshAddUniqueBus result, "BUS-2"
        End If
    End If

    If cBus > 0 Then
        Set displayBuses = _
            RefreshGetBusList(wsPD6.Cells(rowNum, cBus).Value2)
        For Each item In displayBuses
            RefreshAddUniqueBus result, CStr(item)
        Next item
    End If

    Set RefreshGetPD6BusList = result
End Function

Private Function RefreshHasPositiveLoad( _
                 ByVal valueIn As Variant) As Boolean
    RefreshHasPositiveLoad = (RefreshParseAmps(valueIn) > 0#)
End Function

Private Sub RefreshAddUniqueBus(ByVal busList As Collection, _
                                ByVal busName As String)

    Dim item As Variant

    busName = RefreshNormalizeBus(busName)
    If Len(busName) = 0 Then Exit Sub

    For Each item In busList
        If StrComp(CStr(item), busName, vbTextCompare) = 0 Then _
            Exit Sub
    Next item

    busList.Add busName
End Sub

Private Function RefreshBusListDisplay( _
                 ByVal busList As Collection) As String

    Dim hasBus1 As Boolean
    Dim hasBus2 As Boolean
    Dim item As Variant

    For Each item In busList
        If UCase$(CStr(item)) = "BUS-1" Then hasBus1 = True
        If UCase$(CStr(item)) = "BUS-2" Then hasBus2 = True
    Next item

    If hasBus1 And hasBus2 Then
        RefreshBusListDisplay = "BUS-1 / BUS-2"
    ElseIf hasBus1 Then
        RefreshBusListDisplay = "BUS-1"
    ElseIf hasBus2 Then
        RefreshBusListDisplay = "BUS-2"
    End If
End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshIsGenerated24VSheet
' Scope/Type: Private Function
' Purpose   : Refreshes is generated 24 v sheet.
' Parameters:
' sheetName (String) - Supplies sheet name.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshIsGenerated24VSheet(ByVal sheetName As String) As Boolean

    Dim u As String
    u = UCase$(Trim$(sheetName))

    If u = UCase$(SH_24V_INDEX_REFRESH) Then Exit Function
    If u = "24V_POWER_GENERATOR" Then Exit Function
    If u = "24V DATA POWER" Or u = "24V_DATA_POWER" Then Exit Function
    'Audit/report sheets share the 24V_ prefix but are not generated panel sheets.
    If u = UCase$(SH_24V_OVERLOAD_REPORT) Then Exit Function
    If u = UCase$(SH_24V_NOT_GENERATED) Then Exit Function
    If u = "PSU_MISSING_REQUIREMENTS" Then Exit Function

    RefreshIsGenerated24VSheet = _
        (Left$(u, 4) = "24V_" Or Right$(u, 4) = "_24V")
End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshPanelNameFrom24VSheet
' Scope/Type: Private Function
' Purpose   : Refreshes panel name from 24 v sheet.
' Parameters:
' sheetName (String) - Supplies sheet name.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshPanelNameFrom24VSheet(ByVal sheetName As String) As String

    If UCase$(Left$(sheetName, 4)) = "24V_" Then
        RefreshPanelNameFrom24VSheet = mid$(sheetName, 5)
    ElseIf UCase$(Right$(sheetName, 4)) = "_24V" Then
        RefreshPanelNameFrom24VSheet = Left$(sheetName, Len(sheetName) - 4)
    Else
        RefreshPanelNameFrom24VSheet = sheetName
    End If
End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshIsPSUSectionHeader
' Scope/Type: Private Function
' Purpose   : Refreshes is PSU section header.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' rowNum (Long) - Supplies row number.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshIsPSUSectionHeader(ByVal ws As Worksheet, _
                                           ByVal rowNum As Long) As Boolean

    Dim colA As String
    Dim colB As String
    Dim colC As String
    Dim colD As String
    Dim colE As String

    colA = UCase$(RefreshSafeText(ws.Cells(rowNum, 1).Value2))
    colB = UCase$(RefreshSafeText(ws.Cells(rowNum, 2).Value2))
    colC = UCase$(RefreshSafeText(ws.Cells(rowNum, 3).Value2))
    colD = UCase$(RefreshSafeText(ws.Cells(rowNum, 4).Value2))
    colE = UCase$(RefreshSafeText(ws.Cells(rowNum, 5).Value2))

    If colA <> "PWG" Or colB <> "BUS POWER" Then Exit Function

    'Column C can be overwritten by a manual PSU entry. Columns D and E are
    'also checked so the section is still recognized and scanned safely.
    RefreshIsPSUSectionHeader = _
        (colC = "POWER SUPPLY") Or _
        (colD = "BLOCK") Or _
        (InStr(1, colE, "TERMINAL", vbTextCompare) > 0)
End Function
'-------------------------------------------------------------------------------
' Procedure : RefreshIsDeviceTableHeader
' Scope/Type: Private Function
' Purpose   : Refreshes is device table header.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' rowNum (Long) - Supplies row number.
' busNameOut (String) - Supplies bus name out.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshIsDeviceTableHeader(ByVal ws As Worksheet, ByVal rowNum As Long, ByRef busNameOut As String) As Boolean

    Dim lastCol As Long
    Dim c As Long
    Dim headerText As String

    busNameOut = vbNullString

    If UCase$(RefreshSafeText(ws.Cells(rowNum, 1).Value2)) <> "SIS_ELEMENT_NUMBER" Then Exit Function

    lastCol = ws.Cells(rowNum, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lastCol
        headerText = UCase$(RefreshSafeText(ws.Cells(rowNum, c).Value2))
        If InStr(1, headerText, "POWER BUS-1 TERMINAL", vbTextCompare) > 0 Or _
           InStr(1, headerText, "POWER BUS 1 TERMINAL", vbTextCompare) > 0 Or _
           InStr(1, headerText, "BUS-1 TERMINAL", vbTextCompare) > 0 Then
            busNameOut = "BUS-1"
            RefreshIsDeviceTableHeader = True
            Exit Function
        End If
        If InStr(1, headerText, "POWER BUS-2 TERMINAL", vbTextCompare) > 0 Or _
           InStr(1, headerText, "POWER BUS 2 TERMINAL", vbTextCompare) > 0 Or _
           InStr(1, headerText, "BUS-2 TERMINAL", vbTextCompare) > 0 Then
            busNameOut = "BUS-2"
            RefreshIsDeviceTableHeader = True
            Exit Function
        End If
    Next c

End Function

Private Function RefreshSafeText(ByVal valueIn As Variant) As String
    On Error GoTo SafeExit

    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    RefreshSafeText = Trim$(CStr(valueIn))
    Exit Function

SafeExit:
    RefreshSafeText = vbNullString
End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshNormalizePSU
' Scope/Type: Private Function
' Purpose   : Refreshes normalize PSU.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshNormalizePSU(ByVal valueIn As Variant) As String

    Dim s As String

    s = RefreshSafeText(valueIn)

    'V22.9: Capacity-safe generated sections use descriptive placeholders such as:
    '  MISSING BUS-1 PSU REQUIRED #1
    '  MISSING BUS-2 PSU REQUIRED #1 - DEVICE OVER LIMIT
    'Those values must remain logical MISSING assignments when Step10A back-syncs
    'PD6_IMPORT and when the index missing quantities are recalculated.
    If RefreshIsMissingPSUValue(s) Then
        RefreshNormalizePSU = MISSING_PSU_TEXT_REFRESH
    Else
        RefreshNormalizePSU = s
    End If

End Function

Private Function RefreshIsMissingPSUValue(ByVal valueIn As Variant) As Boolean

    Dim u As String

    u = UCase$(RefreshSafeText(valueIn))
    u = Replace(u, Chr$(160), " ")
    u = Trim$(u)

    If Len(u) = 0 Then
        RefreshIsMissingPSUValue = True
        Exit Function
    End If

    If u = MISSING_PSU_TEXT_REFRESH Then
        RefreshIsMissingPSUValue = True
        Exit Function
    End If

    If Left$(u, Len(MISSING_PSU_TEXT_REFRESH)) = MISSING_PSU_TEXT_REFRESH Then
        RefreshIsMissingPSUValue = True
        Exit Function
    End If

    If InStr(1, u, "PSU REQUIRED", vbTextCompare) > 0 Then
        RefreshIsMissingPSUValue = True
        Exit Function
    End If

    If InStr(1, u, "DEVICE OVER LIMIT", vbTextCompare) > 0 And _
       InStr(1, u, "PSU", vbTextCompare) > 0 Then
        RefreshIsMissingPSUValue = True
    End If

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshNormalizeBus
' Scope/Type: Private Function
' Purpose   : Refreshes normalize bus.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshNormalizeBus(ByVal valueIn As Variant) As String

    Dim u As String

    u = UCase$(RefreshSafeText(valueIn))
    u = Replace(u, " ", "")
    u = Replace(u, "_", "-")

    If InStr(1, u, "BUS-1", vbTextCompare) > 0 Or InStr(1, u, "BUS1", vbTextCompare) > 0 Then
        RefreshNormalizeBus = "BUS-1"
    ElseIf InStr(1, u, "BUS-2", vbTextCompare) > 0 Or InStr(1, u, "BUS2", vbTextCompare) > 0 Then
        RefreshNormalizeBus = "BUS-2"
    Else
        RefreshNormalizeBus = vbNullString
    End If

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshNormalizePanelKey
' Scope/Type: Private Function
' Purpose   : Refreshes normalize panel key.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshNormalizePanelKey(ByVal valueIn As Variant) As String

    Dim s As String

    s = UCase$(RefreshSafeText(valueIn))
    s = Replace(s, " ", "")
    s = Replace(s, "_", "")
    s = Replace(s, "-", "")

    RefreshNormalizePanelKey = s

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshNormalizeLabelKey
' Scope/Type: Private Function
' Purpose   : Refreshes normalize label key.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshNormalizeLabelKey(ByVal valueIn As Variant) As String

    Dim s As String

    s = UCase$(RefreshSafeText(valueIn))
    s = Trim$(s)

    'Older generated IO sheets may omit the derived -K4/-K5 suffix while
    'current PD6 Control_ID includes it. Normalize only those two suffixes.
    'Do not strip K1/K2 because they can identify distinct power devices.
    If Right$(s, 3) = "-K4" Or Right$(s, 3) = "-K5" Then
        s = Left$(s, Len(s) - 3)
    End If

    RefreshNormalizeLabelKey = s
End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshFormatPSUCell
' Scope/Type: Private Sub
' Purpose   : Refreshes format PSU cell.
' Parameters:
' targetCell (Range) - Supplies target cell.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub RefreshFormatPSUCell(ByVal targetCell As Range, _
                                 Optional ByVal hasActiveDevices As Boolean = True)

    'Only active BUS sections are visually marked missing. Blank companion BUS
    'rows with no devices remain unmarked and are excluded from the index count.
    If hasActiveDevices And RefreshIsMissingPSUValue(targetCell.Value2) Then
        targetCell.Font.Color = vbRed
        targetCell.Font.Bold = True
    Else
        targetCell.Font.ColorIndex = xlAutomatic
        targetCell.Font.Bold = False
    End If
End Sub
'-------------------------------------------------------------------------------
' Procedure : RefreshFindHeaderRow
' Scope/Type: Private Function
' Purpose   : Refreshes find header row.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' requiredHeaders (Variant) - Supplies required headers.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshFindHeaderRow(ByVal ws As Worksheet, ByVal requiredHeaders As Variant) As Long

    Dim maxRows As Long
    Dim r As Long
    Dim i As Long
    Dim foundAll As Boolean
    Dim headers As Variant

    'Accept either a single header string or an Array of required headers.
    'The V22.1 failure occurred because LBound/UBound was called on a String.
    If IsArray(requiredHeaders) Then
        headers = requiredHeaders
    Else
        headers = Array(requiredHeaders)
    End If

    maxRows = Application.WorksheetFunction.Min(30, ws.rows.count)

    For r = 1 To maxRows
        foundAll = True
        For i = LBound(headers) To UBound(headers)
            If RefreshFindHeaderCol(ws, r, RefreshSafeText(headers(i))) = 0 Then
                foundAll = False
                Exit For
            End If
        Next i
        If foundAll Then
            RefreshFindHeaderRow = r
            Exit Function
        End If
    Next r

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshFindHeaderCol
' Scope/Type: Private Function
' Purpose   : Refreshes find header column.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' headerRow (Long) - Supplies header row.
' names() (Variant) - Supplies names.
' Returns   : Variant) As Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshFindHeaderCol(ByVal ws As Worksheet, ByVal headerRow As Long, ParamArray names() As Variant) As Long

    Dim lastCol As Long
    Dim c As Long
    Dim i As Long
    Dim cellText As String
    Dim targetText As String

    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column

    For c = 1 To lastCol
        cellText = RefreshNormalizeHeader(ws.Cells(headerRow, c).Value2)
        For i = LBound(names) To UBound(names)
            targetText = RefreshNormalizeHeader(CStr(names(i)))
            If cellText = targetText Then
                RefreshFindHeaderCol = c
                Exit Function
            End If
        Next i
    Next c

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshNormalizeHeader
' Scope/Type: Private Function
' Purpose   : Refreshes normalize header.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshNormalizeHeader(ByVal valueIn As Variant) As String

    Dim s As String

    s = UCase$(RefreshSafeText(valueIn))
    s = Replace(s, " ", "")
    s = Replace(s, "_", "")
    s = Replace(s, "-", "")
    s = Replace(s, "/", "")
    s = Replace(s, "(", "")
    s = Replace(s, ")", "")

    RefreshNormalizeHeader = s

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshLastUsedRow
' Scope/Type: Private Function
' Purpose   : Refreshes last used row.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshLastUsedRow(ByVal ws As Worksheet) As Long

    Dim f As Range

    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    If f Is Nothing Then
        RefreshLastUsedRow = 1
    Else
        RefreshLastUsedRow = f.Row
    End If

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshWorksheetExists
' Scope/Type: Private Function
' Purpose   : Refreshes worksheet exists.
' Parameters:
' wb (Workbook) - Supplies workbook.
' sheetName (String) - Supplies sheet name.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshWorksheetExists(ByVal wb As Workbook, ByVal sheetName As String) As Boolean

    Dim ws As Worksheet

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    RefreshWorksheetExists = Not ws Is Nothing

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshEnsureWorksheet
' Scope/Type: Private Function
' Purpose   : Refreshes ensure worksheet.
' Parameters:
' wb (Workbook) - Supplies workbook.
' sheetName (String) - Supplies sheet name.
' Returns   : Worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Function RefreshEnsureWorksheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet

    If RefreshWorksheetExists(wb, sheetName) Then
        Set RefreshEnsureWorksheet = wb.Worksheets(sheetName)
    Else
        Set RefreshEnsureWorksheet = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        RefreshEnsureWorksheet.Name = sheetName
    End If

End Function

'-------------------------------------------------------------------------------
' Procedure : RefreshStyleHeader
' Scope/Type: Private Sub
' Purpose   : Refreshes style header.
' Parameters:
' rng (Range) - Supplies range.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
Private Sub RefreshStyleHeader(ByVal rng As Range)

    With rng
        .Font.Bold = True
        .Font.Color = vbWhite
        .Interior.Color = RGB(31, 78, 121)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With

End Sub

'===============================================================================
' V23.2 STEP10A PREFLIGHT, USER CHOICE, AND OVERLOAD-SKIP SUPPORT
'===============================================================================


'===============================================================================
' V23.3 GENERATED-LABEL RECONCILIATION AND OVERLOAD/TERMINAL AUDIT
'===============================================================================

Public Sub ONGEN_SYNC_PD6_LABELS_TO_GENERATED_24V()

    Dim correctedCount As Long
    Dim ambiguousCount As Long
    Dim unresolvedCount As Long
    Dim overloadSections As Long
    Dim overloadTerminals As Long
    Dim oldEvents As Boolean
    Dim oldScreen As Boolean

    On Error GoTo EH

    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.StatusBar = "ONGEN: synchronizing PD6 labels to generated 24V worksheets..."

    correctedCount = RefreshV233SyncGeneratedLabels( _
                         ThisWorkbook, ambiguousCount, unresolvedCount)

    RefreshV233BuildOverloadTerminalReport _
        ThisWorkbook, overloadSections, overloadTerminals

    Application.StatusBar = False
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    MsgBox "Generated 24V label synchronization complete." & vbCrLf & _
           "Labels corrected from PD6_IMPORT: " & CStr(correctedCount) & vbCrLf & _
           "Ambiguous labels not changed: " & CStr(ambiguousCount) & vbCrLf & _
           "Unresolved labels not changed: " & CStr(unresolvedCount) & vbCrLf & _
           "Overloaded PSU sections: " & CStr(overloadSections) & vbCrLf & _
           "Overloaded terminals: " & CStr(overloadTerminals) & vbCrLf & _
           "Report: " & SH_24V_OVERLOAD_REPORT, vbInformation
    Exit Sub

EH:
    Application.StatusBar = False
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    MsgBox "Generated-label synchronization failed." & vbCrLf & _
           "Error " & CStr(Err.Number) & ": " & Err.description, vbCritical
End Sub

Public Sub ONGEN_REFRESH_24V_OVERLOAD_TERMINAL_REPORT()

    Dim overloadSections As Long
    Dim overloadTerminals As Long

    On Error GoTo EH

    Application.ScreenUpdating = False
    Application.StatusBar = "ONGEN: building 24V overload and terminal report..."

    RefreshV233BuildOverloadTerminalReport _
        ThisWorkbook, overloadSections, overloadTerminals

    Application.StatusBar = False
    Application.ScreenUpdating = True

    ThisWorkbook.Worksheets(SH_24V_OVERLOAD_REPORT).Activate
    ThisWorkbook.Worksheets(SH_24V_OVERLOAD_REPORT).Range("A1").Select

    MsgBox "24V overload and terminal report refreshed." & vbCrLf & _
           "Overloaded PSU sections: " & CStr(overloadSections) & vbCrLf & _
           "Overloaded terminals: " & CStr(overloadTerminals), vbInformation
    Exit Sub

EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "24V overload report failed." & vbCrLf & _
           "Error " & CStr(Err.Number) & ": " & Err.description, vbCritical
End Sub

Public Sub ONGEN_REFRESH_24V_NOT_GENERATED_REPORT()

    Dim issueSummary As String
    Dim freshnessIssueCount As Long
    Dim capacityIssueCount As Long
    Dim correctedCount As Long
    Dim ambiguousCount As Long
    Dim unresolvedCount As Long
    Dim oldEvents As Boolean
    Dim oldScreen As Boolean

    On Error GoTo EH

    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    Application.EnableEvents = False
    Application.ScreenUpdating = False

    Set mStep10ALabelCorrections = New Collection
    Application.StatusBar = _
        "ONGEN: synchronizing generated labels before building missing-device report..."
    correctedCount = RefreshV233SyncGeneratedLabels( _
                         ThisWorkbook, ambiguousCount, unresolvedCount)

    Application.StatusBar = _
        "ONGEN: building required 24V devices not generated report..."
    If Not RefreshStep10APreflight( _
               ThisWorkbook, issueSummary, freshnessIssueCount, _
               capacityIssueCount) Then

        Err.Raise vbObjectError + 2401, _
                  "ONGEN_REFRESH_24V_NOT_GENERATED_REPORT", issueSummary
    End If

    Application.StatusBar = False
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    If RefreshWorksheetExists(ThisWorkbook, SH_24V_NOT_GENERATED) Then
        ThisWorkbook.Worksheets(SH_24V_NOT_GENERATED).Activate
        ThisWorkbook.Worksheets(SH_24V_NOT_GENERATED).Range("A1").Select
    End If

    MsgBox "24V not-generated report refreshed." & vbCrLf & _
           "Generated labels corrected: " & CStr(correctedCount) & vbCrLf & _
           "Ambiguous labels left unchanged: " & CStr(ambiguousCount) & vbCrLf & _
           "Unresolved generated labels: " & CStr(unresolvedCount) & vbCrLf & _
           "Freshness issues: " & CStr(freshnessIssueCount) & vbCrLf & _
           "Report: " & SH_24V_NOT_GENERATED, vbInformation
    Exit Sub

EH:
    Application.StatusBar = False
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    MsgBox "24V not-generated report failed." & vbCrLf & _
           "Error " & CStr(Err.Number) & ": " & Err.description, vbCritical
End Sub


Private Function RefreshV233SyncGeneratedLabels( _
    ByVal wb As Workbook, _
    ByRef ambiguousCount As Long, _
    ByRef unresolvedCount As Long) As Long

    Dim wsPD6 As Worksheet
    Dim ws As Worksheet
    Dim exactMap As Object
    Dim headerRow As Long
    Dim cPanel As Long
    Dim cSisSequence As Long
    Dim cElement As Long
    Dim cControl As Long
    Dim cBusPower As Long
    Dim cLoadBus1 As Long
    Dim cLoadBus2 As Long
    Dim lastRow As Long
    Dim r As Long
    Dim panelKey As String
    Dim sisSequence As String
    Dim canonicalLabel As String
    Dim baseLabel As String
    Dim mapKey As String
    Dim oldLabel As String
    Dim currentBus As String
    Dim detectedBus As String
    Dim foundLabel As String
    Dim correctedCount As Long

    ambiguousCount = 0
    unresolvedCount = 0
    Set mStep10ALabelCorrections = New Collection

    If Not RefreshWorksheetExists(wb, SH_PD6_REFRESH) Then Exit Function
    Set wsPD6 = wb.Worksheets(SH_PD6_REFRESH)

    headerRow = RefreshFindHeaderRow( _
                    wsPD6, Array("SIS_sequence", "SIS_Element_Number", "PNL"))
    If headerRow = 0 Then Exit Function

    cPanel = RefreshFindHeaderCol(wsPD6, headerRow, "PNL", "PANEL")
    cSisSequence = RefreshFindHeaderCol( _
                       wsPD6, headerRow, "SIS_sequence", "SIS SEQUENCE")
    cElement = RefreshFindHeaderCol( _
                   wsPD6, headerRow, "SIS_Element_Number", "SIS ELEMENT NUMBER")
    cControl = RefreshFindHeaderCol( _
                   wsPD6, headerRow, "Control_ID", "CONTROL ID")
    cBusPower = RefreshFindHeaderCol( _
                    wsPD6, headerRow, "Bus Power", "BUS POWER", "Power Bus")
    cLoadBus1 = RefreshFindHeaderCol( _
                    wsPD6, headerRow, "Load BUS-1", "LOAD BUS 1", "Load Bus1")
    cLoadBus2 = RefreshFindHeaderCol( _
                    wsPD6, headerRow, "Load BUS-2", "LOAD BUS 2", "Load Bus2")

    If cPanel = 0 Or cSisSequence = 0 Then Exit Function
    If cElement = 0 And cControl = 0 Then Exit Function

    Set exactMap = CreateObject("Scripting.Dictionary")
    exactMap.CompareMode = vbTextCompare

    lastRow = RefreshLastUsedRow(wsPD6)
    For r = headerRow + 1 To lastRow
        If RefreshV234PD6RowRequires24V( _
               wsPD6, r, cBusPower, cLoadBus1, cLoadBus2) Then

            panelKey = RefreshNormalizePanelKey( _
                           wsPD6.Cells(r, cPanel).Value2)
            sisSequence = UCase$(RefreshSafeText( _
                              wsPD6.Cells(r, cSisSequence).Value2))

            canonicalLabel = vbNullString
            If cControl > 0 Then
                canonicalLabel = RefreshSafeText( _
                                     wsPD6.Cells(r, cControl).Value2)
            End If
            If Len(canonicalLabel) = 0 And cElement > 0 Then
                canonicalLabel = RefreshSafeText( _
                                     wsPD6.Cells(r, cElement).Value2)
            End If

            If Len(panelKey) > 0 And Len(sisSequence) > 0 And _
               Len(canonicalLabel) > 0 Then

                If RefreshV234CanonicalMatchesSIS( _
                       canonicalLabel, sisSequence) Then

                    baseLabel = RefreshV234LabelCore(canonicalLabel)
                    mapKey = panelKey & "|" & baseLabel

                    If exactMap.Exists(mapKey) Then
                        If StrComp(CStr(exactMap(mapKey)), _
                                   canonicalLabel, vbTextCompare) <> 0 Then
                            exactMap(mapKey) = "#AMBIGUOUS#"
                        End If
                    Else
                        exactMap.Add mapKey, canonicalLabel
                    End If
                End If
            End If
        End If
    Next r

    For Each ws In wb.Worksheets
        If RefreshIsGenerated24VSheet(ws.Name) Then
            panelKey = RefreshNormalizePanelKey( _
                           RefreshPanelNameFrom24VSheet(ws.Name))
            currentBus = vbNullString
            lastRow = RefreshLastUsedRow(ws)

            For r = 1 To lastRow
                detectedBus = vbNullString
                If RefreshIsPSUSectionHeader(ws, r) Then
                    currentBus = vbNullString
                ElseIf RefreshIsDeviceTableHeader(ws, r, detectedBus) Then
                    currentBus = detectedBus
                ElseIf Len(currentBus) > 0 Then
                    oldLabel = RefreshSafeText(ws.Cells(r, 1).Value2)

                    If Len(oldLabel) > 0 Then
                        baseLabel = RefreshV234LabelCore(oldLabel)
                        mapKey = panelKey & "|" & baseLabel
                        foundLabel = vbNullString

                        If exactMap.Exists(mapKey) Then
                            If CStr(exactMap(mapKey)) = "#AMBIGUOUS#" Then
                                ambiguousCount = ambiguousCount + 1
                            Else
                                foundLabel = CStr(exactMap(mapKey))
                                If StrComp(oldLabel, foundLabel, _
                                           vbBinaryCompare) <> 0 Then

                                    ws.Cells(r, 1).Value2 = foundLabel
                                    correctedCount = correctedCount + 1
                                    mStep10ALabelCorrections.Add Array( _
                                        ws.Name, r, panelKey, currentBus, _
                                        oldLabel, foundLabel, _
                                        "PD6 panel + exact SIS_sequence core")
                                End If
                            End If
                        Else
                            unresolvedCount = unresolvedCount + 1
                        End If
                    End If
                End If
            Next r
        End If
    Next ws

    RefreshV233SyncGeneratedLabels = correctedCount
End Function

Private Function RefreshV234PD6RowRequires24V( _
    ByVal wsPD6 As Worksheet, _
    ByVal rowNum As Long, _
    ByVal cBusPower As Long, _
    ByVal cLoadBus1 As Long, _
    ByVal cLoadBus2 As Long) As Boolean

    If cLoadBus1 > 0 Then
        If RefreshParseAmps(wsPD6.Cells(rowNum, cLoadBus1).Value2) > 0# Then
            RefreshV234PD6RowRequires24V = True
            Exit Function
        End If
    End If

    If cLoadBus2 > 0 Then
        If RefreshParseAmps(wsPD6.Cells(rowNum, cLoadBus2).Value2) > 0# Then
            RefreshV234PD6RowRequires24V = True
            Exit Function
        End If
    End If

    If cBusPower > 0 Then
        RefreshV234PD6RowRequires24V = _
            (Len(RefreshNormalizeBus( _
                 wsPD6.Cells(rowNum, cBusPower).Value2)) > 0)
    End If
End Function

Private Function RefreshV234CanonicalMatchesSIS( _
    ByVal canonicalLabel As String, _
    ByVal sisSequence As String) As Boolean

    Dim coreText As String
    Dim sisText As String

    coreText = RefreshV234LabelCore(canonicalLabel)
    sisText = UCase$(Trim$(sisSequence))

    If Len(coreText) = 0 Or Len(sisText) = 0 Then Exit Function

    If coreText = sisText Then
        RefreshV234CanonicalMatchesSIS = True
    ElseIf Len(coreText) > Len(sisText) Then
        RefreshV234CanonicalMatchesSIS = _
            (Right$(coreText, Len(sisText) + 1) = "-" & sisText)
    End If
End Function

Private Function RefreshV234LabelCore(ByVal valueIn As Variant) As String

    Dim s As String
    Dim p As Long
    Dim suffixText As String

    s = UCase$(RefreshSafeText(valueIn))
    s = Trim$(s)

    p = InStrRev(s, "-K", -1, vbTextCompare)
    If p > 0 And p + 1 < Len(s) Then
        suffixText = mid$(s, p + 2)
        If RefreshV234IsAllDigits(suffixText) Then
            s = Left$(s, p - 1)
        End If
    End If

    RefreshV234LabelCore = s
End Function

Private Function RefreshV234IsAllDigits(ByVal valueIn As String) As Boolean

    Dim i As Long
    Dim ch As String

    valueIn = Trim$(valueIn)
    If Len(valueIn) = 0 Then Exit Function

    For i = 1 To Len(valueIn)
        ch = mid$(valueIn, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i

    RefreshV234IsAllDigits = True
End Function

Private Sub RefreshV233BuildOverloadTerminalReport( _
    ByVal wb As Workbook, _
    ByRef overloadSections As Long, _
    ByRef overloadTerminals As Long)

    Dim wsReport As Worksheet
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim sectionRow As Long
    Dim nextSectionRow As Long
    Dim outputRow As Long
    Dim correctionStartRow As Long
    Dim labelItem As Variant

    overloadSections = 0
    overloadTerminals = 0

    Set wsReport = RefreshEnsureWorksheet(wb, SH_24V_OVERLOAD_REPORT)
    wsReport.Cells.UnMerge
    wsReport.Cells.Clear

    RefreshV233PrepareReportHeader wsReport
    outputRow = 5

    For Each ws In wb.Worksheets
        If RefreshIsGenerated24VSheet(ws.Name) Then
            lastRow = RefreshLastUsedRow(ws)
            sectionRow = 1

            Do While sectionRow <= lastRow
                If RefreshIsPSUSectionHeader(ws, sectionRow) Then
                    nextSectionRow = RefreshV233NextSectionRow( _
                                         ws, sectionRow + 1, lastRow)
                    RefreshV233AuditBusSection _
                        ws, wsReport, sectionRow, nextSectionRow - 1, _
                        sectionRow + 1, outputRow, _
                        overloadSections, overloadTerminals
                    RefreshV233AuditBusSection _
                        ws, wsReport, sectionRow, nextSectionRow - 1, _
                        sectionRow + 2, outputRow, _
                        overloadSections, overloadTerminals
                    sectionRow = nextSectionRow
                Else
                    sectionRow = sectionRow + 1
                End If
            Loop
        End If
    Next ws

    If outputRow = 5 Then
        wsReport.Cells(outputRow, 1).Value2 = "OK"
        wsReport.Cells(outputRow, 2).Value2 = "NO OVERLOAD"
        wsReport.Cells(outputRow, 18).Value2 = _
            "No generated PSU section exceeds 40A and no terminal exceeds 20A."
        wsReport.Range(wsReport.Cells(outputRow, 1), _
                       wsReport.Cells(outputRow, 18)).Interior.Color = _
            RGB(198, 239, 206)
        outputRow = outputRow + 1
    End If

    correctionStartRow = outputRow + 2
    RefreshV233WriteLabelCorrectionSection _
        wsReport, correctionStartRow, mStep10ALabelCorrections

    wsReport.Range("B2").Value2 = Now
    wsReport.Range("E2").Value2 = overloadSections
    wsReport.Range("H2").Value2 = overloadTerminals
    If mStep10ALabelCorrections Is Nothing Then
        wsReport.Range("K2").Value2 = 0
    Else
        wsReport.Range("K2").Value2 = mStep10ALabelCorrections.count
    End If
    wsReport.Range("N2").Value2 = PSU_CAPACITY_AMPS_REFRESH
    wsReport.Range("Q2").Value2 = TERMINAL_CAPACITY_AMPS_REFRESH

    RefreshV233FinishReport wsReport, outputRow - 1

    'The workbook navigation event installs the standard Home and Launcher
    'buttons when this report worksheet is activated.
End Sub

Private Sub RefreshV233PrepareReportHeader(ByVal ws As Worksheet)

    Dim headers As Variant
    Dim c As Long

    ws.Range("A1:R1").Merge
    ws.Range("A1").Value2 = _
        "Generated 24V Overload, Terminal Options, and Label Synchronization Audit"
    ws.Range("A1:R1").Interior.Color = RGB(31, 78, 121)
    ws.Range("A1:R1").Font.Color = vbWhite
    ws.Range("A1:R1").Font.Bold = True
    ws.Range("A1:R1").HorizontalAlignment = xlCenter
    ws.rows(1).RowHeight = 25

    ws.Range("A2").Value2 = "Run time"
    ws.Range("D2").Value2 = "Overloaded PSU sections"
    ws.Range("G2").Value2 = "Overloaded terminals"
    ws.Range("J2").Value2 = "Labels corrected"
    ws.Range("M2").Value2 = "PSU limit"
    ws.Range("P2").Value2 = "Terminal limit"

    headers = Array( _
        "Severity", "Issue", "Panel", "Worksheet", "Header Row", _
        "PWG", "Bus", "Power Supply", "Section Total A", _
        "PSU Limit A", "Device Row", "Device", "Device Load A", _
        "Current Terminal", "Current Terminal A", _
        "Possible Terminals", "Best Recommendation", "Notes")

    For c = LBound(headers) To UBound(headers)
        ws.Cells(4, c + 1).Value2 = headers(c)
    Next c

    RefreshStyleHeader ws.Range("A4:R4")
End Sub

Private Function RefreshV233NextSectionRow( _
    ByVal ws As Worksheet, _
    ByVal startRow As Long, _
    ByVal lastRow As Long) As Long

    Dim r As Long

    For r = startRow To lastRow
        If RefreshIsPSUSectionHeader(ws, r) Then
            RefreshV233NextSectionRow = r
            Exit Function
        End If
    Next r

    RefreshV233NextSectionRow = lastRow + 1
End Function

Private Sub RefreshV233AuditBusSection( _
    ByVal ws As Worksheet, _
    ByVal wsReport As Worksheet, _
    ByVal sectionHeaderRow As Long, _
    ByVal sectionEndRow As Long, _
    ByVal busRow As Long, _
    ByRef outputRow As Long, _
    ByRef overloadSections As Long, _
    ByRef overloadTerminals As Long)

    Dim busName As String
    Dim psuText As String
    Dim pwgText As String
    Dim panelText As String
    Dim terminalNames As Collection
    Dim devices As Collection
    Dim terminalLoads As Object
    Dim overTerminalNames As Object
    Dim deviceItem As Variant
    Dim totalLoad As Double
    Dim sectionOver As Boolean
    Dim terminalOver As Boolean
    Dim termItem As Variant
    Dim currentLoad As Double
    Dim issueText As String
    Dim possibleText As String
    Dim bestText As String
    Dim notesText As String
    Dim moveText As String
    Dim overage As Double

    If busRow < 1 Or busRow > ws.rows.count Then Exit Sub

    busName = RefreshNormalizeBus(ws.Cells(busRow, 2).Value2)
    If Len(busName) = 0 Then Exit Sub

    psuText = RefreshNormalizePSU(ws.Cells(busRow, 3).Value2)
    pwgText = RefreshSafeText(ws.Cells(busRow, 1).Value2)
    panelText = RefreshPanelNameFrom24VSheet(ws.Name)

    Set terminalNames = RefreshV233ReadSectionTerminals(ws, busRow)
    Set devices = New Collection
    Set terminalLoads = CreateObject("Scripting.Dictionary")
    Set overTerminalNames = CreateObject("Scripting.Dictionary")
    terminalLoads.CompareMode = vbTextCompare
    overTerminalNames.CompareMode = vbTextCompare

    RefreshV233CollectBusDevices _
        ws, sectionHeaderRow, sectionEndRow, busName, _
        devices, terminalLoads, totalLoad

    For Each termItem In terminalLoads.keys
        currentLoad = CDbl(terminalLoads(termItem))
        If Len(CStr(termItem)) > 0 And _
           currentLoad > TERMINAL_CAPACITY_AMPS_REFRESH + 0.000001 Then
            overTerminalNames(CStr(termItem)) = currentLoad
        End If
    Next termItem

    sectionOver = _
        (totalLoad > PSU_CAPACITY_AMPS_REFRESH + 0.000001)
    terminalOver = (overTerminalNames.count > 0)

    If Not sectionOver And Not terminalOver Then Exit Sub

    If sectionOver Then overloadSections = overloadSections + 1
    overloadTerminals = overloadTerminals + overTerminalNames.count

    issueText = IIf(sectionOver, "PSU OVERLOAD", "TERMINAL OVERLOAD")
    overage = totalLoad - PSU_CAPACITY_AMPS_REFRESH

    If sectionOver Then
        moveText = RefreshV233SuggestedMove(devices, overage)
        possibleText = RefreshV233AllTerminalText(terminalNames)
        bestText = moveText & _
            ". Suggested new-PSU terminals: " & possibleText
        notesText = "Section exceeds 40A by " & _
                    RefreshV233AmpText(overage) & _
                    ". Reassigning terminals on the same PSU cannot fix the total."
    Else
        possibleText = vbNullString
        bestText = "Move one or more devices from the overloaded terminal " & _
                   "to a valid terminal listed on the device rows."
        notesText = "Section total is within 40A; terminal balancing can fix this issue."
    End If

    RefreshV233WriteReportRow _
        wsReport, outputRow, "ERROR", issueText, panelText, _
        ws.Name, sectionHeaderRow, pwgText, busName, psuText, _
        totalLoad, PSU_CAPACITY_AMPS_REFRESH, 0, _
        "SECTION SUMMARY", 0, vbNullString, 0, _
        possibleText, bestText, notesText
    outputRow = outputRow + 1

    For Each deviceItem In devices
        If sectionOver Or overTerminalNames.Exists(CStr(deviceItem(4))) Then
            currentLoad = RefreshV233DictDouble( _
                              terminalLoads, CStr(deviceItem(4)))

            If sectionOver Then
                possibleText = RefreshV233AllTerminalText(terminalNames)
                If CDbl(deviceItem(3)) > TERMINAL_CAPACITY_AMPS_REFRESH Then
                    possibleText = "DEVICE LOAD EXCEEDS 20A"
                End If
                bestText = "Candidate for the new PSU section; use the section summary move set."
            Else
                possibleText = RefreshV233PossibleCurrentTerminals( _
                                   terminalNames, terminalLoads, _
                                   CStr(deviceItem(4)), CDbl(deviceItem(3)), _
                                   bestText)
            End If

            RefreshV233WriteReportRow _
                wsReport, outputRow, "WARNING", "DEVICE OPTION", _
                panelText, ws.Name, sectionHeaderRow, pwgText, _
                busName, psuText, totalLoad, _
                PSU_CAPACITY_AMPS_REFRESH, CLng(deviceItem(0)), _
                CStr(deviceItem(1)), CDbl(deviceItem(3)), _
                CStr(deviceItem(4)), currentLoad, _
                possibleText, bestText, _
                "Type: " & CStr(deviceItem(2))
            outputRow = outputRow + 1
        End If
    Next deviceItem
End Sub

Private Function RefreshV233ReadSectionTerminals( _
    ByVal ws As Worksheet, _
    ByVal busRow As Long) As Collection

    Dim result As New Collection
    Dim c As Long
    Dim terminalText As String

    For c = 5 To 8
        terminalText = RefreshNormalizeTerminalValue( _
                           ws.Cells(busRow, c).Value2)
        If Len(terminalText) = 0 Then
            terminalText = RefreshDefaultTerminalName(c - 4)
        End If
        result.Add terminalText
    Next c

    Set RefreshV233ReadSectionTerminals = result
End Function

Private Sub RefreshV233CollectBusDevices( _
    ByVal ws As Worksheet, _
    ByVal sectionHeaderRow As Long, _
    ByVal sectionEndRow As Long, _
    ByVal targetBus As String, _
    ByVal devices As Collection, _
    ByVal terminalLoads As Object, _
    ByRef totalLoad As Double)

    Dim r As Long
    Dim currentBus As String
    Dim detectedBus As String
    Dim deviceLabel As String
    Dim typeText As String
    Dim loadValue As Double
    Dim terminalText As String

    currentBus = vbNullString
    totalLoad = 0

    For r = sectionHeaderRow + 1 To sectionEndRow
        detectedBus = vbNullString

        If RefreshIsDeviceTableHeader(ws, r, detectedBus) Then
            currentBus = detectedBus
        ElseIf RefreshIsPSUSectionHeader(ws, r) Then
            Exit For
        ElseIf currentBus = targetBus Then
            deviceLabel = RefreshSafeText(ws.Cells(r, 1).Value2)
            typeText = RefreshSafeText(ws.Cells(r, 2).Value2)

            If Len(deviceLabel) > 0 And Len(typeText) > 0 Then
                loadValue = RefreshParseAmps(ws.Cells(r, 3).Value2)
                terminalText = RefreshNormalizeTerminalValue( _
                                   ws.Cells(r, 7).Value2)

                devices.Add Array( _
                    r, deviceLabel, typeText, loadValue, terminalText)

                totalLoad = totalLoad + loadValue
                RefreshV233AddDouble terminalLoads, terminalText, loadValue
            End If
        End If
    Next r
End Sub

Private Sub RefreshV233AddDouble( _
    ByVal dictObj As Object, _
    ByVal keyText As String, _
    ByVal amount As Double)

    If dictObj.Exists(keyText) Then
        dictObj(keyText) = CDbl(dictObj(keyText)) + amount
    Else
        dictObj.Add keyText, amount
    End If
End Sub

Private Function RefreshV233DictDouble( _
    ByVal dictObj As Object, _
    ByVal keyText As String) As Double

    If dictObj.Exists(keyText) Then
        RefreshV233DictDouble = CDbl(dictObj(keyText))
    End If
End Function

Private Function RefreshV233PossibleCurrentTerminals( _
    ByVal terminalNames As Collection, _
    ByVal terminalLoads As Object, _
    ByVal currentTerminal As String, _
    ByVal deviceLoad As Double, _
    ByRef bestText As String) As String

    Dim terminalItem As Variant
    Dim terminalText As String
    Dim projectedLoad As Double
    Dim bestLoad As Double
    Dim bestTerminal As String
    Dim result As String

    bestLoad = 1E+30
    bestText = vbNullString

    For Each terminalItem In terminalNames
        terminalText = CStr(terminalItem)

        If StrComp(terminalText, currentTerminal, vbTextCompare) <> 0 Then
            projectedLoad = RefreshV233DictDouble( _
                                terminalLoads, terminalText) + deviceLoad

            If projectedLoad <= _
               TERMINAL_CAPACITY_AMPS_REFRESH + 0.000001 Then

                If Len(result) > 0 Then result = result & ", "
                result = result & terminalText & " [" & _
                         RefreshV233InsideDescription(terminalText) & _
                         "] -> " & RefreshV233AmpText(projectedLoad)

                If projectedLoad < bestLoad Then
                    bestLoad = projectedLoad
                    bestTerminal = terminalText
                End If
            End If
        End If
    Next terminalItem

    If Len(bestTerminal) > 0 Then
        bestText = "Move to " & bestTerminal & " [" & _
                   RefreshV233InsideDescription(bestTerminal) & _
                   "]; projected " & RefreshV233AmpText(bestLoad)
    Else
        result = "NO CURRENT-PSU TERMINAL AVAILABLE"
        bestText = "A new PSU section is required."
    End If

    RefreshV233PossibleCurrentTerminals = result
End Function

Private Function RefreshV233AllTerminalText( _
    ByVal terminalNames As Collection) As String

    Dim item As Variant
    Dim result As String
    Dim terminalText As String

    For Each item In terminalNames
        terminalText = CStr(item)
        If Len(result) > 0 Then result = result & ", "
        result = result & terminalText & " [" & _
                 RefreshV233InsideDescription(terminalText) & "]"
    Next item

    RefreshV233AllTerminalText = result
End Function

Private Function RefreshV233InsideDescription( _
    ByVal terminalText As String) As String

    Select Case UCase$(Trim$(terminalText))
        Case "X1TERM05"
            RefreshV233InsideDescription = "DC1+/DC1-"
        Case "X1TERM07"
            RefreshV233InsideDescription = "DC2+/DC2-"
        Case "X1TERM09"
            RefreshV233InsideDescription = "DC3+/DC3-"
        Case "X1TERM11"
            RefreshV233InsideDescription = "DC4+/DC4-"
        Case Else
            RefreshV233InsideDescription = "VERIFY"
    End Select
End Function

Private Function RefreshV233SuggestedMove( _
    ByVal devices As Collection, _
    ByVal requiredLoad As Double) As String

    Dim item As Variant
    Dim bestSingleLabel As String
    Dim bestSingleLoad As Double
    Dim used As Object
    Dim i As Long
    Dim bestIndex As Long
    Dim bestLoad As Double
    Dim selectedLoad As Double
    Dim result As String

    If requiredLoad <= 0 Then
        RefreshV233SuggestedMove = "No device movement required"
        Exit Function
    End If

    bestSingleLoad = 1E+30
    For Each item In devices
        If CDbl(item(3)) >= requiredLoad And _
           CDbl(item(3)) < bestSingleLoad Then
            bestSingleLoad = CDbl(item(3))
            bestSingleLabel = CStr(item(1))
        End If
    Next item

    If Len(bestSingleLabel) > 0 Then
        RefreshV233SuggestedMove = _
            "Move " & bestSingleLabel & " (" & _
            RefreshV233AmpText(bestSingleLoad) & _
            ") to a new PSU section"
        Exit Function
    End If

    Set used = CreateObject("Scripting.Dictionary")

    Do While selectedLoad < requiredLoad And used.count < devices.count
        bestIndex = 0
        bestLoad = -1

        For i = 1 To devices.count
            If Not used.Exists(CStr(i)) Then
                item = devices(i)
                If CDbl(item(3)) > bestLoad Then
                    bestLoad = CDbl(item(3))
                    bestIndex = i
                End If
            End If
        Next i

        If bestIndex = 0 Then Exit Do

        used.Add CStr(bestIndex), True
        item = devices(bestIndex)

        If Len(result) > 0 Then result = result & ", "
        result = result & CStr(item(1)) & _
                 " (" & RefreshV233AmpText(CDbl(item(3))) & ")"
        selectedLoad = selectedLoad + CDbl(item(3))
    Loop

    RefreshV233SuggestedMove = _
        "Move " & result & " to a new PSU section (" & _
        RefreshV233AmpText(selectedLoad) & " total)"
End Function

Private Function RefreshV233AmpText(ByVal valueIn As Double) As String
    RefreshV233AmpText = Format$(valueIn, "0.###") & "A"
End Function

Private Sub RefreshV233WriteReportRow( _
    ByVal ws As Worksheet, _
    ByVal rowNum As Long, _
    ByVal severity As String, _
    ByVal issueText As String, _
    ByVal panelText As String, _
    ByVal sheetText As String, _
    ByVal headerRow As Long, _
    ByVal pwgText As String, _
    ByVal busName As String, _
    ByVal psuText As String, _
    ByVal sectionTotal As Double, _
    ByVal psuLimit As Double, _
    ByVal deviceRow As Long, _
    ByVal deviceLabel As String, _
    ByVal deviceLoad As Double, _
    ByVal currentTerminal As String, _
    ByVal currentTerminalLoad As Double, _
    ByVal possibleTerminals As String, _
    ByVal recommendation As String, _
    ByVal notesText As String)

    ws.Cells(rowNum, 1).Value2 = severity
    ws.Cells(rowNum, 2).Value2 = issueText
    ws.Cells(rowNum, 3).Value2 = panelText
    ws.Cells(rowNum, 4).Value2 = sheetText
    ws.Cells(rowNum, 5).Value2 = headerRow
    ws.Cells(rowNum, 6).Value2 = pwgText
    ws.Cells(rowNum, 7).Value2 = busName
    ws.Cells(rowNum, 8).Value2 = psuText
    ws.Cells(rowNum, 9).Value2 = sectionTotal
    ws.Cells(rowNum, 10).Value2 = psuLimit

    If deviceRow > 0 Then ws.Cells(rowNum, 11).Value2 = deviceRow
    ws.Cells(rowNum, 12).Value2 = deviceLabel
    If deviceLoad > 0 Then ws.Cells(rowNum, 13).Value2 = deviceLoad
    ws.Cells(rowNum, 14).Value2 = currentTerminal
    If currentTerminalLoad > 0 Then
        ws.Cells(rowNum, 15).Value2 = currentTerminalLoad
    End If
    ws.Cells(rowNum, 16).Value2 = possibleTerminals
    ws.Cells(rowNum, 17).Value2 = recommendation
    ws.Cells(rowNum, 18).Value2 = notesText

    If severity = "ERROR" Then
        ws.Range(ws.Cells(rowNum, 1), _
                 ws.Cells(rowNum, 18)).Interior.Color = _
            RGB(255, 199, 206)
    Else
        ws.Range(ws.Cells(rowNum, 1), _
                 ws.Cells(rowNum, 18)).Interior.Color = _
            RGB(255, 235, 156)
    End If
End Sub

Private Sub RefreshV233WriteLabelCorrectionSection( _
    ByVal ws As Worksheet, _
    ByVal startRow As Long, _
    ByVal correctionLog As Collection)

    Dim headers As Variant
    Dim item As Variant
    Dim r As Long
    Dim c As Long

    ws.Range(ws.Cells(startRow, 1), _
             ws.Cells(startRow, 18)).Merge
    ws.Cells(startRow, 1).Value2 = _
        "Generated label corrections applied from PD6_IMPORT"
    ws.Range(ws.Cells(startRow, 1), _
             ws.Cells(startRow, 18)).Interior.Color = RGB(31, 78, 121)
    ws.Range(ws.Cells(startRow, 1), _
             ws.Cells(startRow, 18)).Font.Color = vbWhite
    ws.Range(ws.Cells(startRow, 1), _
             ws.Cells(startRow, 18)).Font.Bold = True

    headers = Array( _
        "Worksheet", "Row", "Panel", "Bus", _
        "Old Label", "New Label", "Match Rule")

    For c = LBound(headers) To UBound(headers)
        ws.Cells(startRow + 1, c + 1).Value2 = headers(c)
    Next c
    RefreshStyleHeader _
        ws.Range(ws.Cells(startRow + 1, 1), ws.Cells(startRow + 1, 7))

    r = startRow + 2

    If correctionLog Is Nothing Then
        ws.Cells(r, 1).Value2 = "No label corrections were required."
    ElseIf correctionLog.count = 0 Then
        ws.Cells(r, 1).Value2 = "No label corrections were required."
    Else
        For Each item In correctionLog
            ws.Cells(r, 1).Value2 = CStr(item(0))
            ws.Cells(r, 2).Value2 = CLng(item(1))
            ws.Cells(r, 3).Value2 = CStr(item(2))
            ws.Cells(r, 4).Value2 = CStr(item(3))
            ws.Cells(r, 5).Value2 = CStr(item(4))
            ws.Cells(r, 6).Value2 = CStr(item(5))
            ws.Cells(r, 7).Value2 = CStr(item(6))
            ws.Range(ws.Cells(r, 1), _
                     ws.Cells(r, 7)).Interior.Color = RGB(198, 239, 206)
            r = r + 1
        Next item
    End If
End Sub

Private Sub RefreshV233FinishReport( _
    ByVal ws As Worksheet, _
    ByVal lastOverloadRow As Long)

    ws.Columns("A:R").AutoFit
    ws.Columns("D:D").columnWidth = 19
    ws.Columns("H:H").columnWidth = 30
    ws.Columns("L:L").columnWidth = 30
    ws.Columns("P:P").columnWidth = 48
    ws.Columns("Q:R").columnWidth = 55
    ws.Columns("P:R").WrapText = True
    ws.Columns("I:J").NumberFormat = "0.###"
    ws.Columns("M:M").NumberFormat = "0.###"
    ws.Columns("O:O").NumberFormat = "0.###"

    If lastOverloadRow >= 5 Then
        ws.Range("A4:R" & CStr(lastOverloadRow)).AutoFilter
    End If

    ws.Activate
    ws.Range("A5").Select
    ActiveWindow.FreezePanes = True
End Sub


Private Function RefreshStep10APreflight(ByVal wb As Workbook, _
                                         ByRef issueSummary As String, _
                                         ByRef freshnessIssueCount As Long, _
                                         ByRef capacityIssueCount As Long) As Boolean

    Dim wsPD6 As Worksheet
    Dim wsAudit As Worksheet
    Dim wsNotGenerated As Worksheet
    Dim expectedCount As Object
    Dim expectedDetail As Object
    Dim generatedCount As Object
    Dim generatedDetail As Object
    Dim sectionLoad As Object
    Dim terminalLoad As Object
    Dim missingCount As Long
    Dim obsoleteCount As Long
    Dim overPSUCount As Long
    Dim overTerminalCount As Long
    Dim expectedBusRows As Long
    Dim generatedBusRows As Long
    Dim auditRow As Long
    Dim notGeneratedRow As Long
    Dim key As Variant
    Dim diff As Long
    Dim detail As Variant
    Dim totalValue As Double
    Dim sectionSkipKey As String
    Dim terminalSkipKey As String
    Dim categoryText As String
    Dim explanationText As String
    Dim missingStatus As String
    Dim alternateBus As String
    Dim alternateKey As String

    On Error GoTo EH

    issueSummary = vbNullString
    freshnessIssueCount = 0
    capacityIssueCount = 0
    RefreshStep10APreflight = False

    If Not RefreshWorksheetExists(wb, SH_PD6_REFRESH) Then
        issueSummary = "PD6_IMPORT was not found."
        Exit Function
    End If

    Set mStep10AOverloadedSections = CreateObject("Scripting.Dictionary")
    Set mStep10AOverloadedTerminals = CreateObject("Scripting.Dictionary")
    mStep10AOverloadedSections.CompareMode = vbTextCompare
    mStep10AOverloadedTerminals.CompareMode = vbTextCompare

    Set expectedCount = CreateObject("Scripting.Dictionary")
    Set expectedDetail = CreateObject("Scripting.Dictionary")
    Set generatedCount = CreateObject("Scripting.Dictionary")
    Set generatedDetail = CreateObject("Scripting.Dictionary")
    Set sectionLoad = CreateObject("Scripting.Dictionary")
    Set terminalLoad = CreateObject("Scripting.Dictionary")

    expectedCount.CompareMode = vbTextCompare
    expectedDetail.CompareMode = vbTextCompare
    generatedCount.CompareMode = vbTextCompare
    generatedDetail.CompareMode = vbTextCompare
    sectionLoad.CompareMode = vbTextCompare
    terminalLoad.CompareMode = vbTextCompare

    Set wsPD6 = wb.Worksheets(SH_PD6_REFRESH)
    Set wsAudit = RefreshPrepareStep10AAuditSheet(wb)
    Set wsNotGenerated = RefreshPrepareNotGeneratedSheet(wb)
    auditRow = 5
    notGeneratedRow = 5

    Application.StatusBar = "ONGEN Step 10A: building expected PD6 device/BUS list..."
    expectedBusRows = RefreshBuildExpectedBusKeyMap( _
                          wsPD6, expectedCount, expectedDetail)

    Application.StatusBar = "ONGEN Step 10A: scanning generated 24V device/BUS list..."
    generatedBusRows = RefreshBuildGeneratedBusKeyMap( _
                           wb, generatedCount, generatedDetail, _
                           sectionLoad, terminalLoad)

    For Each key In expectedCount.keys
        diff = CLng(expectedCount(key))
        If generatedCount.Exists(CStr(key)) Then
            diff = diff - CLng(generatedCount(CStr(key)))
        End If

        If diff > 0 Then
            missingCount = missingCount + diff
            detail = expectedDetail(CStr(key))
            RefreshWriteStep10AAuditRow wsAudit, auditRow, _
                "ERROR", "MISSING_FROM_GENERATED", _
                CStr(detail(1)), vbNullString, CLng(detail(0)), _
                CStr(detail(2)), CStr(detail(3)), _
                CStr(detail(5)), CStr(detail(6)), _
                CDbl(detail(7)), diff, _
                "Required current PD6 device/BUS record is absent from the generated 24V sheets.", _
                "Add or correct this device/BUS record in the generated panel sheet, then run Step10B or Step10A. Step07 is optional only for full regeneration.", _
                "MISSING_FROM_GENERATED|" & CStr(key)
            auditRow = auditRow + 1

            If CStr(detail(2)) = "BUS-1" Then
                alternateBus = "BUS-2"
            Else
                alternateBus = "BUS-1"
            End If
            alternateKey = RefreshNormalizePanelKey(CStr(detail(1))) & "|" & _
                           RefreshNormalizeLabelKey(CStr(detail(3))) & "|" & _
                           alternateBus

            If generatedCount.Exists(alternateKey) Then
                missingStatus = "PARTIAL DEVICE - " & CStr(detail(2)) & " NOT GENERATED"
            Else
                missingStatus = "DEVICE NOT GENERATED"
            End If

            RefreshWriteNotGeneratedRow _
                wsNotGenerated, notGeneratedRow, missingStatus, _
                detail, diff, CStr(key)
            notGeneratedRow = notGeneratedRow + 1
        End If
    Next key

    For Each key In generatedCount.keys
        diff = CLng(generatedCount(key))
        If expectedCount.Exists(CStr(key)) Then
            diff = diff - CLng(expectedCount(CStr(key)))
        End If

        If diff > 0 Then
            obsoleteCount = obsoleteCount + diff
            detail = generatedDetail(CStr(key))
            RefreshWriteStep10AAuditRow wsAudit, auditRow, _
                "ERROR", "OBSOLETE_GENERATED_ROW", _
                CStr(detail(1)), CStr(detail(0)), CLng(detail(2)), _
                CStr(detail(3)), CStr(detail(4)), _
                CStr(detail(5)), CStr(detail(6)), _
                CDbl(detail(8)), diff, _
                "Generated device/BUS record no longer exists as a current PD6 requirement.", _
                "Delete or correct this generated row, then run Step10B or Step10A. Step07 is not required.", _
                "OBSOLETE_GENERATED_ROW|" & CStr(key)
            auditRow = auditRow + 1
        End If
    Next key

    For Each key In sectionLoad.keys
        totalValue = CDbl(sectionLoad(key))
        If totalValue > PSU_CAPACITY_AMPS_REFRESH + 0.0000001 Then
            overPSUCount = overPSUCount + 1
            detail = Split(CStr(key), "|")
            sectionSkipKey = RefreshStep10ASectionSkipKey( _
                                 CStr(detail(1)), CLng(detail(2)), _
                                 CStr(detail(3)))
            mStep10AOverloadedSections(sectionSkipKey) = True

            If RefreshIsMissingPSUValue(CStr(detail(4))) Then
                categoryText = "MISSING_PSU_CAPACITY_OVER_40A"
                explanationText = _
                    "The devices grouped under this missing-PSU placeholder require more than one 40A PSU section."
            Else
                categoryText = "PSU_SECTION_OVER_40A"
                explanationText = "Generated BUS section exceeds the 40A PSU limit."
            End If

            RefreshWriteStep10AAuditRow wsAudit, auditRow, _
                "ERROR", categoryText, _
                CStr(detail(0)), CStr(detail(1)), CLng(detail(2)), _
                CStr(detail(3)), vbNullString, CStr(detail(4)), _
                vbNullString, totalValue, 1, explanationText, _
                "Split or reassign the PSU section in the generated sheet, then run Step10B or Step10A. Step07 is optional.", _
                categoryText & "|" & CStr(key)
            auditRow = auditRow + 1
        End If
    Next key

    For Each key In terminalLoad.keys
        totalValue = CDbl(terminalLoad(key))
        If totalValue > TERMINAL_CAPACITY_AMPS_REFRESH + 0.0000001 Then
            overTerminalCount = overTerminalCount + 1
            detail = Split(CStr(key), "|")
            sectionSkipKey = RefreshStep10ASectionSkipKey( _
                                 CStr(detail(1)), CLng(detail(2)), _
                                 CStr(detail(3)))
            terminalSkipKey = sectionSkipKey & "|" & _
                              UCase$(RefreshNormalizeTerminalValue(detail(5)))
            mStep10AOverloadedTerminals(terminalSkipKey) = True
            'Skip the complete section in safe mode so no device from a section
            'with a known terminal overload can be written back to PD6.
            mStep10AOverloadedSections(sectionSkipKey) = True

            RefreshWriteStep10AAuditRow wsAudit, auditRow, _
                "ERROR", "TERMINAL_OVER_20A", _
                CStr(detail(0)), CStr(detail(1)), CLng(detail(2)), _
                CStr(detail(3)), vbNullString, CStr(detail(4)), _
                CStr(detail(5)), totalValue, 1, _
                "Generated terminal exceeds the shared Step06/Step10A 20A terminal limit.", _
                "Split or reassign this terminal in the generated sheet, then run Step10B or Step10A. Step07 is optional.", _
                "TERMINAL_OVER_20A|" & CStr(key)
            auditRow = auditRow + 1
        End If
    Next key

    freshnessIssueCount = missingCount + obsoleteCount
    capacityIssueCount = overPSUCount + overTerminalCount

    RefreshFinishNotGeneratedSheet _
        wsNotGenerated, missingCount, expectedBusRows, generatedBusRows, _
        notGeneratedRow - 1

    RefreshFinishStep10AAuditSheet wsAudit, expectedBusRows, generatedBusRows, _
                                   missingCount, obsoleteCount, overPSUCount, _
                                   overTerminalCount

    issueSummary = _
        "Expected PD6 device/BUS records: " & CStr(expectedBusRows) & vbCrLf & _
        "Generated device/BUS records: " & CStr(generatedBusRows) & vbCrLf & _
        "Required records missing from generated sheets: " & CStr(missingCount) & vbCrLf & _
        "Obsolete generated records: " & CStr(obsoleteCount) & vbCrLf & _
        "Generated PSU sections over 40A: " & CStr(overPSUCount) & vbCrLf & _
        "Generated terminals over 20A: " & CStr(overTerminalCount)

    RefreshStep10APreflight = True
    Exit Function

EH:
    issueSummary = "Error " & CStr(Err.Number) & ": " & Err.description
    RefreshStep10APreflight = False
End Function

Private Function RefreshBuildExpectedBusKeyMap( _
                 ByVal wsPD6 As Worksheet, _
                 ByVal keyCount As Object, _
                 ByVal keyDetail As Object) As Long

    Dim headerRow As Long
    Dim lastRow As Long
    Dim r As Long
    Dim cPNL As Long
    Dim cSwitchGroup As Long
    Dim cType As Long
    Dim cControl As Long
    Dim cSisElem As Long
    Dim cSisSeq As Long
    Dim cBus As Long
    Dim cPSU As Long
    Dim cTerm1 As Long
    Dim cTerm2 As Long
    Dim cLoad As Long
    Dim cLoad1 As Long
    Dim cLoad2 As Long
    Dim labelText As String
    Dim panelText As String
    Dim switchGroupText As String
    Dim typeText As String
    Dim controlText As String
    Dim sisElementText As String
    Dim sisSequenceText As String
    Dim psuText As String
    Dim terminalText As String
    Dim busList As Collection
    Dim busItem As Variant
    Dim busName As String
    Dim key As String
    Dim loadValue As Double
    Dim countRows As Long

    headerRow = RefreshFindHeaderRow(wsPD6, Array("SIS_ELEMENT_NUMBER"))
    If headerRow = 0 Then headerRow = 1

    cPNL = RefreshFindHeaderCol(wsPD6, headerRow, "PNL", "Panel")
    cSwitchGroup = RefreshFindHeaderCol( _
                       wsPD6, headerRow, "SwitchGroup", "SWITCHGROUP")
    cType = RefreshFindHeaderCol(wsPD6, headerRow, "TYPE", "Device Type")
    cControl = RefreshFindHeaderCol(wsPD6, headerRow, _
                                    "Control_ID", "CONTROL_ID", "Control ID")
    cSisElem = RefreshFindHeaderCol(wsPD6, headerRow, _
                                    "SIS_Element_Number", "SIS_ELEMENT_NUMBER")
    cSisSeq = RefreshFindHeaderCol(wsPD6, headerRow, _
                                   "SIS_sequence", "SIS_SEQUENCE", "Sequence")
    cBus = RefreshFindHeaderCol(wsPD6, headerRow, _
                                "Bus Power", "BUS POWER", "Power Bus")
    cPSU = RefreshFindHeaderCol(wsPD6, headerRow, _
                                "Power Supply", "POWER SUPPLY", "PSU")
    cTerm1 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Power BUS-1 Terminal", "BUS-1 Terminal")
    cTerm2 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Power BUS-2 Terminal", "BUS-2 Terminal")
    cLoad = RefreshFindHeaderCol(wsPD6, headerRow, _
                                 "Load", "CURRENT_LOAD")
    cLoad1 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Load BUS-1", "LOAD BUS 1", "Load Bus1")
    cLoad2 = RefreshFindHeaderCol(wsPD6, headerRow, _
                                  "Load BUS-2", "LOAD BUS 2", "Load Bus2")

    lastRow = RefreshLastUsedRow(wsPD6)

    For r = headerRow + 1 To lastRow
        controlText = vbNullString
        sisElementText = vbNullString
        sisSequenceText = vbNullString

        If cControl > 0 Then
            controlText = RefreshSafeText(wsPD6.Cells(r, cControl).Value2)
        End If
        If cSisElem > 0 Then
            sisElementText = RefreshSafeText(wsPD6.Cells(r, cSisElem).Value2)
        End If
        If cSisSeq > 0 Then
            sisSequenceText = RefreshSafeText(wsPD6.Cells(r, cSisSeq).Value2)
        End If

        labelText = controlText
        If Len(labelText) = 0 Then labelText = sisElementText
        If Len(labelText) = 0 Then labelText = sisSequenceText
        If Len(labelText) = 0 Then GoTo NextExpectedRow

        Set busList = RefreshGetPD6BusList(wsPD6, r, cBus, cLoad1, cLoad2)
        If busList.count = 0 Then GoTo NextExpectedRow

        panelText = vbNullString
        If cPNL > 0 Then panelText = RefreshSafeText(wsPD6.Cells(r, cPNL).Value2)

        switchGroupText = vbNullString
        If cSwitchGroup > 0 Then
            switchGroupText = RefreshSafeText( _
                                  wsPD6.Cells(r, cSwitchGroup).Value2)
        End If

        typeText = vbNullString
        If cType > 0 Then typeText = RefreshSafeText(wsPD6.Cells(r, cType).Value2)

        psuText = vbNullString
        If cPSU > 0 Then psuText = RefreshSafeText(wsPD6.Cells(r, cPSU).Value2)

        For Each busItem In busList
            busName = RefreshNormalizeBus(CStr(busItem))
            If Len(busName) = 0 Then GoTo NextExpectedBus

            terminalText = vbNullString
            loadValue = 0#
            If busName = "BUS-1" Then
                If cTerm1 > 0 Then
                    terminalText = RefreshSafeText( _
                                       wsPD6.Cells(r, cTerm1).Value2)
                End If
                If cLoad1 > 0 Then
                    loadValue = RefreshParseAmps( _
                                    wsPD6.Cells(r, cLoad1).Value2)
                End If
            ElseIf busName = "BUS-2" Then
                If cTerm2 > 0 Then
                    terminalText = RefreshSafeText( _
                                       wsPD6.Cells(r, cTerm2).Value2)
                End If
                If cLoad2 > 0 Then
                    loadValue = RefreshParseAmps( _
                                    wsPD6.Cells(r, cLoad2).Value2)
                End If
            End If

            If loadValue <= 0# And cLoad > 0 Then
                loadValue = RefreshParseAmps(wsPD6.Cells(r, cLoad).Value2)
            End If

            key = RefreshNormalizePanelKey(panelText) & "|" & _
                  RefreshNormalizeLabelKey(labelText) & "|" & busName

            RefreshIncrementStep10AKey keyCount, key
            If Not keyDetail.Exists(key) Then
                keyDetail.Add key, Array( _
                    r, panelText, busName, labelText, typeText, _
                    psuText, terminalText, loadValue, switchGroupText, _
                    sisSequenceText, sisElementText, controlText)
            End If
            countRows = countRows + 1

NextExpectedBus:
        Next busItem
NextExpectedRow:
    Next r

    RefreshBuildExpectedBusKeyMap = countRows
End Function

Private Function RefreshBuildGeneratedBusKeyMap( _
                 ByVal wb As Workbook, _
                 ByVal keyCount As Object, _
                 ByVal keyDetail As Object, _
                 ByVal sectionLoad As Object, _
                 ByVal terminalLoad As Object) As Long

    Dim ws As Worksheet
    Dim lastRow As Long
    Dim r As Long
    Dim rr As Long
    Dim panelText As String
    Dim panelKey As String
    Dim busName As String
    Dim nextBus As String
    Dim deviceLabel As String
    Dim alternateDeviceLabel As String
    Dim psuByBus As Object
    Dim sectionHeaderRow As Long
    Dim key As String
    Dim sectionKey As String
    Dim terminalKey As String
    Dim psuText As String
    Dim terminalText As String
    Dim loadValue As Double
    Dim countRows As Long

    For Each ws In wb.Worksheets
        If RefreshIsGenerated24VSheet(ws.Name) Then
            panelText = RefreshPanelNameFrom24VSheet(ws.Name)
            panelKey = RefreshNormalizePanelKey(panelText)
            lastRow = RefreshLastUsedRow(ws)
            Set psuByBus = CreateObject("Scripting.Dictionary")
            psuByBus.CompareMode = vbTextCompare
            sectionHeaderRow = 0

            For r = 1 To lastRow
                If RefreshIsPSUSectionHeader(ws, r) Then
                    sectionHeaderRow = r
                    psuByBus.RemoveAll
                    RefreshCaptureStep10ASectionPSU ws, r + 1, psuByBus
                    RefreshCaptureStep10ASectionPSU ws, r + 2, psuByBus

                ElseIf RefreshIsDeviceTableHeader(ws, r, busName) Then
                    rr = r + 1
                    Do While rr <= lastRow
                        If RefreshIsPSUSectionHeader(ws, rr) Then Exit Do
                        nextBus = vbNullString
                        If RefreshIsDeviceTableHeader(ws, rr, nextBus) Then Exit Do

                        deviceLabel = RefreshSafeText(ws.Cells(rr, 1).Value2)
                        If Len(deviceLabel) > 0 Then
                            psuText = vbNullString
                            If psuByBus.Exists(RefreshNormalizeBus(busName)) Then _
                                psuText = RefreshSafeText(psuByBus(RefreshNormalizeBus(busName)))
                            terminalText = RefreshNormalizeTerminalValue(ws.Cells(rr, 7).Value2)
                            loadValue = RefreshParseAmps(ws.Cells(rr, 3).Value2)

                            key = panelKey & "|" & _
                                  RefreshNormalizeLabelKey(deviceLabel) & "|" & _
                                  RefreshNormalizeBus(busName)
                            RefreshIncrementStep10AKey keyCount, key
                            If Not keyDetail.Exists(key) Then
                                keyDetail.Add key, Array(ws.Name, panelText, rr, _
                                                        RefreshNormalizeBus(busName), _
                                                        deviceLabel, psuText, _
                                                        terminalText, vbNullString, _
                                                        loadValue)
                            End If

                            'Do not add alternate labels to generatedCount. They are lookup aliases,
                            'not additional physical BUS rows.
                            sectionKey = panelText & "|" & ws.Name & "|" & _
                                         CStr(sectionHeaderRow) & "|" & _
                                         RefreshNormalizeBus(busName) & "|" & psuText
                            RefreshAddStep10ANumeric sectionLoad, sectionKey, loadValue

                            If Len(terminalText) > 0 Then
                                terminalKey = sectionKey & "|" & terminalText
                                RefreshAddStep10ANumeric terminalLoad, terminalKey, loadValue
                            End If
                            countRows = countRows + 1
                        End If
                        rr = rr + 1
                    Loop
                End If
            Next r
        End If
    Next ws

    RefreshBuildGeneratedBusKeyMap = countRows
End Function

Private Sub RefreshCaptureStep10ASectionPSU(ByVal ws As Worksheet, _
                                             ByVal rowNum As Long, _
                                             ByVal psuByBus As Object)
    Dim busName As String

    If rowNum < 1 Or rowNum > ws.rows.count Then Exit Sub
    busName = RefreshNormalizeBus(ws.Cells(rowNum, 2).Value2)
    If Len(busName) = 0 Then Exit Sub
    psuByBus(busName) = RefreshNormalizePSU(ws.Cells(rowNum, 3).Value2)
End Sub

Private Sub RefreshIncrementStep10AKey(ByVal dict As Object, ByVal key As String)
    If dict.Exists(key) Then
        dict(key) = CLng(dict(key)) + 1
    Else
        dict.Add key, 1&
    End If
End Sub

Private Sub RefreshAddStep10ANumeric(ByVal dict As Object, _
                                     ByVal key As String, _
                                     ByVal valueToAdd As Double)
    If dict.Exists(key) Then
        dict(key) = CDbl(dict(key)) + valueToAdd
    Else
        dict.Add key, valueToAdd
    End If
End Sub

Private Function RefreshStep10ASectionSkipKey(ByVal sheetName As String, _
                                               ByVal sectionHeaderRow As Long, _
                                               ByVal busName As String) As String
    RefreshStep10ASectionSkipKey = UCase$(Trim$(sheetName)) & "|" & _
                                   CStr(sectionHeaderRow) & "|" & _
                                   RefreshNormalizeBus(busName)
End Function

Private Function RefreshShouldSkipGeneratedDevice(ByVal sheetName As String, _
                                                   ByVal sectionHeaderRow As Long, _
                                                   ByVal busName As String, _
                                                   ByVal terminalName As String) As Boolean
    Dim sectionKey As String
    Dim terminalKey As String

    If Not mStep10ASkipOverloads Then Exit Function
    If mStep10AOverloadedSections Is Nothing Then Exit Function

    sectionKey = RefreshStep10ASectionSkipKey( _
                     sheetName, sectionHeaderRow, busName)
    If mStep10AOverloadedSections.Exists(sectionKey) Then
        RefreshShouldSkipGeneratedDevice = True
        Exit Function
    End If

    If Not mStep10AOverloadedTerminals Is Nothing Then
        terminalKey = sectionKey & "|" & _
                      UCase$(RefreshNormalizeTerminalValue(terminalName))
        If mStep10AOverloadedTerminals.Exists(terminalKey) Then _
            RefreshShouldSkipGeneratedDevice = True
    End If
End Function

Private Function RefreshPrepareNotGeneratedSheet( _
    ByVal wb As Workbook) As Worksheet

    Dim ws As Worksheet
    Dim headers As Variant
    Dim c As Long

    If RefreshWorksheetExists(wb, SH_24V_NOT_GENERATED) Then
        Set ws = wb.Worksheets(SH_24V_NOT_GENERATED)
        ws.Cells.UnMerge
        ws.Cells.Clear
    Else
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ws.Name = SH_24V_NOT_GENERATED
    End If

    ws.Range("A1:P1").Merge
    ws.Range("A1").Value2 = _
        "PD6 24V Device/BUS Records Not Present on Generated Worksheets"
    ws.Range("A2").Value2 = "Run time"
    ws.Range("B2").Value2 = Now
    ws.Range("D2").Value2 = "Expected BUS records"
    ws.Range("G2").Value2 = "Generated BUS records"
    ws.Range("J2").Value2 = "Not generated BUS records"

    headers = Array( _
        "Status", "PD6 Row", "Panel", "SwitchGroup", "Type", _
        "SIS_sequence", "SIS_Element_Number", "Control_ID", _
        "Required Bus", "Load A", "Existing Power Supply", _
        "Existing Terminal", "Quantity", "Match Key", _
        "Reason", "Recommended Action")

    For c = LBound(headers) To UBound(headers)
        ws.Cells(4, c + 1).Value2 = headers(c)
    Next c

    ws.Range("A1:P1").Interior.Color = RGB(31, 78, 121)
    ws.Range("A1:P1").Font.Color = vbWhite
    ws.Range("A1:P1").Font.Bold = True
    ws.Range("A4:P4").Interior.Color = RGB(31, 78, 121)
    ws.Range("A4:P4").Font.Color = vbWhite
    ws.Range("A4:P4").Font.Bold = True

    Set RefreshPrepareNotGeneratedSheet = ws
End Function

Private Sub RefreshWriteNotGeneratedRow( _
    ByVal ws As Worksheet, _
    ByVal rowNum As Long, _
    ByVal statusText As String, _
    ByVal detail As Variant, _
    ByVal quantity As Long, _
    ByVal matchKey As String)

    ws.Cells(rowNum, 1).Value2 = statusText
    ws.Cells(rowNum, 2).Value2 = CLng(detail(0))
    ws.Cells(rowNum, 3).Value2 = CStr(detail(1))
    ws.Cells(rowNum, 4).Value2 = CStr(detail(8))
    ws.Cells(rowNum, 5).Value2 = CStr(detail(4))
    ws.Cells(rowNum, 6).Value2 = CStr(detail(9))
    ws.Cells(rowNum, 7).Value2 = CStr(detail(10))
    ws.Cells(rowNum, 8).Value2 = CStr(detail(11))
    ws.Cells(rowNum, 9).Value2 = CStr(detail(2))
    ws.Cells(rowNum, 10).Value2 = CDbl(detail(7))
    ws.Cells(rowNum, 11).Value2 = CStr(detail(5))
    ws.Cells(rowNum, 12).Value2 = CStr(detail(6))
    ws.Cells(rowNum, 13).Value2 = quantity
    ws.Cells(rowNum, 14).Value2 = matchKey

    If Left$(statusText, 7) = "PARTIAL" Then
        ws.Cells(rowNum, 15).Value2 = _
            "The device exists on the generated worksheet, but this required BUS record is absent."
    Else
        ws.Cells(rowNum, 15).Value2 = _
            "No generated 24V device/BUS record matches this current PD6 requirement."
    End If

    ws.Cells(rowNum, 16).Value2 = _
        "Run Step06 and Step07 to generate the missing BUS record. " & _
        "Step10A will preserve the current PD6 assignment until it exists."

    If Left$(statusText, 7) = "PARTIAL" Then
        ws.Range(ws.Cells(rowNum, 1), _
                 ws.Cells(rowNum, 16)).Interior.Color = RGB(255, 235, 156)
    Else
        ws.Range(ws.Cells(rowNum, 1), _
                 ws.Cells(rowNum, 16)).Interior.Color = RGB(255, 199, 206)
    End If
End Sub

Private Sub RefreshFinishNotGeneratedSheet( _
    ByVal ws As Worksheet, _
    ByVal missingRows As Long, _
    ByVal expectedRows As Long, _
    ByVal generatedRows As Long, _
    ByVal lastDataRow As Long)

    ws.Range("E2").Value2 = expectedRows
    ws.Range("H2").Value2 = generatedRows
    ws.Range("M2").Value2 = missingRows

    If missingRows = 0 Then
        ws.Cells(5, 1).Value2 = "OK"
        ws.Cells(5, 15).Value2 = _
            "Every current PD6 24V device/BUS requirement is present on a generated worksheet."
        ws.Range("A5:P5").Interior.Color = RGB(198, 239, 206)
        lastDataRow = 5
    End If

    ws.Columns("A:P").AutoFit
    ws.Columns("F:H").columnWidth = 28
    ws.Columns("K:K").columnWidth = 36
    ws.Columns("N:N").columnWidth = 50
    ws.Columns("O:P").columnWidth = 55
    ws.Columns("N:P").WrapText = True
    ws.Columns("J:J").NumberFormat = "0.###"

    If lastDataRow >= 5 Then
        ws.Range("A4:P" & CStr(lastDataRow)).AutoFilter
    End If

    ws.Activate
    ws.Range("A5").Select
    ActiveWindow.FreezePanes = True
End Sub


Private Function RefreshPrepareStep10AAuditSheet(ByVal wb As Workbook) As Worksheet
    Dim ws As Worksheet
    Dim headers As Variant
    Dim c As Long
    Dim r As Long
    Dim lastRow As Long
    Dim issueKey As String
    Dim issueStatus As String

    Set mStep10APriorIssueKeys = CreateObject("Scripting.Dictionary")
    Set mStep10ACurrentIssueKeys = CreateObject("Scripting.Dictionary")
    mStep10APriorIssueKeys.CompareMode = vbTextCompare
    mStep10ACurrentIssueKeys.CompareMode = vbTextCompare
    mStep10AResolvedCleared = 0

    If RefreshWorksheetExists(wb, SH_STEP10A_AUDIT) Then
        Set ws = wb.Worksheets(SH_STEP10A_AUDIT)
        lastRow = RefreshLastUsedRow(ws)
        For r = 5 To lastRow
            issueKey = RefreshSafeText(ws.Cells(r, 14).Value2)
            If Len(issueKey) = 0 Then issueKey = RefreshDerivedAuditIssueKey(ws, r)
            issueStatus = UCase$(RefreshSafeText(ws.Cells(r, 15).Value2))
            If Len(issueKey) > 0 And (Len(issueStatus) = 0 Or issueStatus = "ACTIVE") Then
                If Not mStep10APriorIssueKeys.Exists(issueKey) Then _
                    mStep10APriorIssueKeys.Add issueKey, True
            End If
        Next r
        ws.Cells.UnMerge
        ws.Cells.Clear
    Else
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ws.Name = SH_STEP10A_AUDIT
    End If

    ws.Range("A1:O1").Merge
    ws.Range("A1").Value2 = "Step 10A / 10B Generated-Sheet Synchronization Audit"
    ws.Range("A2").Value2 = "Run time"
    ws.Range("B2").Value2 = Now

    headers = Array( _
        "Severity", "Category", "Panel", "Worksheet", "Source Row", _
        "Bus", "Device", "PSU", "Terminal", "Load/Total A", _
        "Quantity", "Explanation", "Recommended Action", "Issue Key", "Status")
    For c = LBound(headers) To UBound(headers)
        ws.Cells(4, c + 1).Value2 = headers(c)
    Next c

    ws.Range("A1:O1").Font.Bold = True
    ws.Range("A4:O4").Font.Bold = True
    ws.Range("A1:O1").Interior.Color = RGB(31, 78, 121)
    ws.Range("A1:O1").Font.Color = vbWhite
    ws.Range("A4:O4").Interior.Color = RGB(31, 78, 121)
    ws.Range("A4:O4").Font.Color = vbWhite

    Set RefreshPrepareStep10AAuditSheet = ws
End Function

Private Function RefreshDerivedAuditIssueKey(ByVal ws As Worksheet, _
                                             ByVal rowNum As Long) As String
    Dim categoryText As String
    categoryText = RefreshSafeText(ws.Cells(rowNum, 2).Value2)
    If Len(categoryText) = 0 Then Exit Function

    RefreshDerivedAuditIssueKey = UCase$(categoryText) & "|" & _
        UCase$(RefreshSafeText(ws.Cells(rowNum, 3).Value2)) & "|" & _
        UCase$(RefreshSafeText(ws.Cells(rowNum, 4).Value2)) & "|" & _
        CStr(CLng(val(RefreshSafeText(ws.Cells(rowNum, 5).Value2)))) & "|" & _
        UCase$(RefreshSafeText(ws.Cells(rowNum, 6).Value2)) & "|" & _
        UCase$(RefreshSafeText(ws.Cells(rowNum, 7).Value2)) & "|" & _
        UCase$(RefreshSafeText(ws.Cells(rowNum, 8).Value2)) & "|" & _
        UCase$(RefreshSafeText(ws.Cells(rowNum, 9).Value2))
End Function
Private Sub RefreshWriteStep10AAuditRow(ByVal ws As Worksheet, _
                                         ByVal rowNum As Long, _
                                         ByVal severity As String, _
                                         ByVal category As String, _
                                         ByVal panelText As String, _
                                         ByVal sheetText As String, _
                                         ByVal sourceRow As Long, _
                                         ByVal busName As String, _
                                         ByVal deviceLabel As String, _
                                         ByVal psuText As String, _
                                         ByVal terminalText As String, _
                                         ByVal loadValue As Double, _
                                         ByVal quantity As Long, _
                                         ByVal explanation As String, _
                                         ByVal recommendedAction As String, _
                                         Optional ByVal issueKey As String = "")

    If Len(issueKey) = 0 Then
        issueKey = UCase$(category) & "|" & UCase$(panelText) & "|" & _
                   UCase$(sheetText) & "|" & CStr(sourceRow) & "|" & _
                   UCase$(busName) & "|" & UCase$(deviceLabel) & "|" & _
                   UCase$(psuText) & "|" & UCase$(terminalText)
    End If

    ws.Cells(rowNum, 1).Value2 = severity
    ws.Cells(rowNum, 2).Value2 = category
    ws.Cells(rowNum, 3).Value2 = panelText
    ws.Cells(rowNum, 4).Value2 = sheetText
    ws.Cells(rowNum, 5).Value2 = sourceRow
    ws.Cells(rowNum, 6).Value2 = busName
    ws.Cells(rowNum, 7).Value2 = deviceLabel
    ws.Cells(rowNum, 8).Value2 = psuText
    ws.Cells(rowNum, 9).Value2 = terminalText
    ws.Cells(rowNum, 10).Value2 = loadValue
    ws.Cells(rowNum, 11).Value2 = quantity
    ws.Cells(rowNum, 12).Value2 = explanation
    ws.Cells(rowNum, 13).Value2 = recommendedAction
    ws.Cells(rowNum, 14).Value2 = issueKey
    ws.Cells(rowNum, 15).Value2 = "ACTIVE"

    If Not mStep10ACurrentIssueKeys Is Nothing Then
        If Not mStep10ACurrentIssueKeys.Exists(issueKey) Then _
            mStep10ACurrentIssueKeys.Add issueKey, True
    End If

    If severity = "ERROR" Then
        ws.Range(ws.Cells(rowNum, 1), ws.Cells(rowNum, 15)).Interior.Color = RGB(255, 199, 206)
    Else
        ws.Range(ws.Cells(rowNum, 1), ws.Cells(rowNum, 15)).Interior.Color = RGB(255, 235, 156)
    End If
End Sub
Private Sub RefreshFinishStep10AAuditSheet(ByVal ws As Worksheet, _
                                            ByVal expectedRows As Long, _
                                            ByVal generatedRows As Long, _
                                            ByVal missingRows As Long, _
                                            ByVal obsoleteRows As Long, _
                                            ByVal overPSURows As Long, _
                                            ByVal overTerminalRows As Long)

    Dim key As Variant
    Dim activeIssues As Long

    mStep10AResolvedCleared = 0
    If Not mStep10APriorIssueKeys Is Nothing Then
        For Each key In mStep10APriorIssueKeys.keys
            If mStep10ACurrentIssueKeys Is Nothing Then
                mStep10AResolvedCleared = mStep10AResolvedCleared + 1
            ElseIf Not mStep10ACurrentIssueKeys.Exists(CStr(key)) Then
                mStep10AResolvedCleared = mStep10AResolvedCleared + 1
            End If
        Next key
    End If
    If Not mStep10ACurrentIssueKeys Is Nothing Then activeIssues = mStep10ACurrentIssueKeys.count

    ws.Range("D2").Value2 = "Expected BUS records"
    ws.Range("E2").Value2 = expectedRows
    ws.Range("F2").Value2 = "Generated BUS records"
    ws.Range("G2").Value2 = generatedRows
    ws.Range("H2").Value2 = "Missing"
    ws.Range("I2").Value2 = missingRows
    ws.Range("J2").Value2 = "Obsolete"
    ws.Range("K2").Value2 = obsoleteRows
    ws.Range("L2").Value2 = "Capacity errors"
    ws.Range("M2").Value2 = overPSURows + overTerminalRows
    ws.Range("N2").Value2 = "Active issues"
    ws.Range("O2").Value2 = activeIssues

    ws.Range("D3").Value2 = "PSU limit"
    ws.Range("E3").Value2 = PSU_CAPACITY_AMPS_REFRESH
    ws.Range("F3").Value2 = "Terminal limit"
    ws.Range("G3").Value2 = TERMINAL_CAPACITY_AMPS_REFRESH
    ws.Range("H3").Value2 = "PSU >40A"
    ws.Range("I3").Value2 = overPSURows
    ws.Range("J3").Value2 = "Terminal >20A"
    ws.Range("K3").Value2 = overTerminalRows
    ws.Range("L3").Value2 = "Resolved/Cleared"
    ws.Range("M3").Value2 = mStep10AResolvedCleared

    ws.Columns("A:O").AutoFit
    ws.Columns("G:G").columnWidth = 28
    ws.Columns("H:I").columnWidth = 24
    ws.Columns("L:N").columnWidth = 48
    ws.Range("L:N").WrapText = True
    ws.rows(1).RowHeight = 24
End Sub
Private Sub RefreshOpenStep10AAudit(ByVal wb As Workbook)
    If RefreshWorksheetExists(wb, SH_STEP10A_AUDIT) Then
        wb.Worksheets(SH_STEP10A_AUDIT).Activate
        wb.Worksheets(SH_STEP10A_AUDIT).Range("A1").Select
    End If
End Sub

