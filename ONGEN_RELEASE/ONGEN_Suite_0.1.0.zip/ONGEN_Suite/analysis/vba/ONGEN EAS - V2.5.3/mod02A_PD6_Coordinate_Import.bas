Attribute VB_Name = "mod02A_PD6_Coordinate_Import"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod02A_PD6_Coordinate_Import
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : mod02A_PD6_Coordinate_Import
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Compile-safe standalone PD6 coordinate import and audit workflow.
'-------------------------------------------------------------------------------

Option Explicit

Private Const COORD_DEST_SHEET As String = "PD6_IMPORT"
Private Const COORD_AUDIT_SHEET As String = "PD6_COORDINATE_AUDIT"
Private Const COORD_NUMBER_FORMAT As String = "0.000"
Private Const COORD_COMPARE_TOLERANCE As Double = 0.000001

Private mCoordMatchedCount As Long
Private mCoordUnmatchedCount As Long
Private mCoordInvalidCount As Long
Private mCoordConflictCount As Long
Private mCoordDuplicateSameCount As Long

'===============================================================================
' PUBLIC ENTRY POINT
' This routine is intentionally NOT called by the main PD6 import workflow.
' Run it only when a coordinate workbook needs to be synchronized to PD6_IMPORT.
'===============================================================================
Public Sub Step05E_Import_PD6_XYZ_From_Workbook()

    Dim selectedFile As Variant
    Dim wbSource As Object
    Dim wsSource As Object
    Dim wsDest As Object
    Dim sourceWasOpened As Boolean
    Dim oldCalculation As Long
    Dim oldScreenUpdating As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim sourceName As String

    On Error GoTo ErrHandler

    oldCalculation = Application.Calculation
    oldScreenUpdating = Application.ScreenUpdating
    oldEnableEvents = Application.EnableEvents
    oldDisplayAlerts = Application.DisplayAlerts

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual

    Set wsDest = Coord_GetSheet(ThisWorkbook, COORD_DEST_SHEET)
    If wsDest Is Nothing Then
        Err.Raise vbObjectError + 2401, "Step05E_Import_PD6_XYZ_From_Workbook", _
                  "PD6_IMPORT was not found. Run Step 05 first."
    End If

    Coord_EnsurePD6CoordinateHeaders wsDest

    selectedFile = Application.GetOpenFilename( _
        FileFilter:="Excel Workbooks (*.xlsx;*.xlsm;*.xlsb;*.xls),*.xlsx;*.xlsm;*.xlsb;*.xls", _
        title:="Select workbook containing SIS_SEQUENCE and X / Y / Z coordinates", _
        MultiSelect:=False)

    If VarType(selectedFile) = vbBoolean Then
        If selectedFile = False Then GoTo SafeExit
    End If

    Set wbSource = Coord_FindOpenWorkbook(CStr(selectedFile))
    If wbSource Is Nothing Then
        Set wbSource = Workbooks.Open( _
            fileName:=CStr(selectedFile), _
            UpdateLinks:=0, _
            ReadOnly:=True, _
            AddToMru:=False, _
            Notify:=False)
        sourceWasOpened = True
    End If

    Set wsSource = Coord_FindCoordinateSheet(wbSource)
    If wsSource Is Nothing Then
        Err.Raise vbObjectError + 2402, "Step05E_Import_PD6_XYZ_From_Workbook", _
                  "No worksheet contains the required headers SIS_SEQUENCE, X, Y, and Z."
    End If

    sourceName = wbSource.Name & "!" & wsSource.Name

    Coord_ResetCounters
    Coord_SynchronizePD6Coordinates wsDest, wsSource

    On Error Resume Next
    AppendLog "Step05E_Import_PD6_XYZ_From_Workbook", "OK", _
              "Source=" & sourceName & "; matched=" & CStr(mCoordMatchedCount) & _
              "; unmatched=" & CStr(mCoordUnmatchedCount) & _
              "; invalid=" & CStr(mCoordInvalidCount) & _
              "; conflicts=" & CStr(mCoordConflictCount) & _
              "; repeated-identical=" & CStr(mCoordDuplicateSameCount) & "."
    On Error GoTo ErrHandler

    MsgBox "PD6 coordinate synchronization completed." & vbCrLf & vbCrLf & _
           "Source: " & sourceName & vbCrLf & _
           "PD6 rows matched: " & Format$(mCoordMatchedCount, "#,##0") & vbCrLf & _
           "PD6 rows without a coordinate match: " & Format$(mCoordUnmatchedCount, "#,##0") & vbCrLf & _
           "Invalid source coordinate rows: " & Format$(mCoordInvalidCount, "#,##0") & vbCrLf & _
           "Conflicting duplicate SIS_SEQUENCE values: " & Format$(mCoordConflictCount, "#,##0") & vbCrLf & _
           "Repeated identical source rows: " & Format$(mCoordDuplicateSameCount, "#,##0") & vbCrLf & vbCrLf & _
           "Run Step 05D to recalculate PSU/BUS assignments using the new XYZ distances.", _
           vbInformation, "ONGEN PD6 XYZ Coordinate Import"

SafeExit:
    On Error Resume Next
    If sourceWasOpened Then wbSource.Close SaveChanges:=False
    Application.Calculation = oldCalculation
    Application.DisplayAlerts = oldDisplayAlerts
    Application.EnableEvents = oldEnableEvents
    Application.ScreenUpdating = oldScreenUpdating
    On Error GoTo 0
    Exit Sub

ErrHandler:
    On Error Resume Next
    AppendLog "Step05E_Import_PD6_XYZ_From_Workbook", "ERROR", _
              "Error " & CStr(Err.Number) & ": " & Err.description
    MsgBox "PD6 coordinate synchronization failed." & vbCrLf & vbCrLf & _
           "Error " & CStr(Err.Number) & ": " & Err.description, _
           vbCritical, "ONGEN PD6 XYZ Coordinate Import"
    Resume SafeExit

End Sub

Public Sub Step05E_Ensure_PD6_XYZ_Headers()

    Dim ws As Object

    On Error GoTo ErrHandler
    Set ws = Coord_GetSheet(ThisWorkbook, COORD_DEST_SHEET)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 2403, "Step05E_Ensure_PD6_XYZ_Headers", _
                  "PD6_IMPORT was not found."
    End If

    Coord_EnsurePD6CoordinateHeaders ws
    MsgBox "PD6_IMPORT coordinate headers are ready: X, Y, Z, ROTATION_DEG.", _
           vbInformation, "ONGEN PD6 XYZ Headers"
    Exit Sub

ErrHandler:
    MsgBox "Unable to prepare PD6 coordinate headers: " & Err.description, _
           vbCritical, "ONGEN PD6 XYZ Headers"

End Sub

Private Sub Coord_ResetCounters()
    mCoordMatchedCount = 0
    mCoordUnmatchedCount = 0
    mCoordInvalidCount = 0
    mCoordConflictCount = 0
    mCoordDuplicateSameCount = 0
End Sub

'===============================================================================
' CORE SYNCHRONIZATION
'===============================================================================
Private Sub Coord_SynchronizePD6Coordinates(ByVal wsDest As Object, ByVal wsSource As Object)

    Dim coordMap As Object
    Dim conflictMap As Object
    Dim sourceRowMap As Object
    Dim wsAudit As Object
    Dim auditData() As Variant
    Dim auditCount As Long
    Dim maxAuditRows As Long

    Dim cSrcSeq As Long
    Dim cSrcX As Long
    Dim cSrcY As Long
    Dim cSrcZ As Long
    Dim cSrcRot As Long
    Dim cDestSeq As Long
    Dim cDestX As Long
    Dim cDestY As Long
    Dim cDestZ As Long
    Dim cDestRot As Long
    Dim lastSrcRow As Long
    Dim lastDestRow As Long
    Dim rowCount As Long
    Dim r As Long
    Dim idx As Long

    Dim srcSeq As Variant
    Dim srcX As Variant
    Dim srcY As Variant
    Dim srcZ As Variant
    Dim srcRot As Variant
    Dim destSeq As Variant
    Dim outX As Variant
    Dim outY As Variant
    Dim outZ As Variant
    Dim outRot As Variant
    Dim key As String
    Dim xVal As Double
    Dim yVal As Double
    Dim zVal As Double
    Dim rotVal As Double
    Dim hasRotation As Boolean
    Dim currentCoord As Variant
    Dim previousCoord As Variant
    Dim sourceRowText As String

    cSrcSeq = Coord_HeaderCol(wsSource, Array("SIS_SEQUENCE", "SIS_Sequence", "SIS sequence", "Sequence"))
    cSrcX = Coord_HeaderCol(wsSource, Array("X", "X_COORD", "X COORDINATE", "X_COORDINATE"))
    cSrcY = Coord_HeaderCol(wsSource, Array("Y", "Y_COORD", "Y COORDINATE", "Y_COORDINATE"))
    cSrcZ = Coord_HeaderCol(wsSource, Array("Z", "Z_COORD", "Z COORDINATE", "Z_COORDINATE"))
    cSrcRot = Coord_HeaderCol(wsSource, Array("ROTATION_DEG", "ROTATION DEG", "ROTATION", "ROTATION_DEGREES"))

    cDestSeq = Coord_HeaderCol(wsDest, Array("SIS_SEQUENCE", "SIS_Sequence", "SIS_sequence", "Sequence"))
    cDestX = Coord_HeaderCol(wsDest, Array("X"))
    cDestY = Coord_HeaderCol(wsDest, Array("Y"))
    cDestZ = Coord_HeaderCol(wsDest, Array("Z"))
    cDestRot = Coord_HeaderCol(wsDest, Array("ROTATION_DEG", "ROTATION DEG"))

    If cSrcSeq = 0 Or cSrcX = 0 Or cSrcY = 0 Or cSrcZ = 0 Then
        Err.Raise vbObjectError + 2404, "Coord_SynchronizePD6Coordinates", _
                  "The coordinate source is missing SIS_SEQUENCE, X, Y, or Z."
    End If

    If cDestSeq = 0 Or cDestX = 0 Or cDestY = 0 Or cDestZ = 0 Or cDestRot = 0 Then
        Err.Raise vbObjectError + 2405, "Coord_SynchronizePD6Coordinates", _
                  "PD6_IMPORT is missing one or more coordinate destination headers."
    End If

    lastSrcRow = Coord_LastUsedRow(wsSource)
    lastDestRow = Coord_LastUsedRow(wsDest)
    If lastSrcRow < 2 Then
        Err.Raise vbObjectError + 2406, "Coord_SynchronizePD6Coordinates", _
                  "The coordinate source contains no data rows."
    End If

    Set coordMap = CreateObject("Scripting.Dictionary")
    Set conflictMap = CreateObject("Scripting.Dictionary")
    Set sourceRowMap = CreateObject("Scripting.Dictionary")
    coordMap.CompareMode = vbTextCompare
    conflictMap.CompareMode = vbTextCompare
    sourceRowMap.CompareMode = vbTextCompare

    srcSeq = Coord_ReadColumn(wsSource, lastSrcRow, cSrcSeq)
    srcX = Coord_ReadColumn(wsSource, lastSrcRow, cSrcX)
    srcY = Coord_ReadColumn(wsSource, lastSrcRow, cSrcY)
    srcZ = Coord_ReadColumn(wsSource, lastSrcRow, cSrcZ)
    srcRot = Coord_ReadColumn(wsSource, lastSrcRow, cSrcRot)

    maxAuditRows = lastSrcRow - 1
    If lastDestRow > 1 Then maxAuditRows = maxAuditRows + lastDestRow - 1
    maxAuditRows = maxAuditRows + 10
    ReDim auditData(1 To maxAuditRows, 1 To 5)

    For idx = 1 To lastSrcRow - 1
        key = Coord_NormalizeSISKey(Coord_ArrayText(srcSeq, idx))

        ' Coordinate exports can contain unnamed CAD geometry.  A blank
        ' SIS_SEQUENCE cannot be matched to PD6 and is intentionally ignored.
        If Len(key) = 0 Then GoTo NextSourceRow

        If Not Coord_TryDouble(Coord_ArrayValue(srcX, idx), xVal) Or _
           Not Coord_TryDouble(Coord_ArrayValue(srcY, idx), yVal) Or _
           Not Coord_TryDouble(Coord_ArrayValue(srcZ, idx), zVal) Then
            mCoordInvalidCount = mCoordInvalidCount + 1
            Coord_AddAudit auditData, auditCount, "INVALID SOURCE", key, idx + 1, 0, _
                           "X, Y, and Z must all be numeric."
            GoTo NextSourceRow
        End If

        rotVal = 0#
        hasRotation = False
        If cSrcRot > 0 Then
            If Len(Trim$(Coord_ArrayText(srcRot, idx))) > 0 Then
                If Not Coord_TryDouble(Coord_ArrayValue(srcRot, idx), rotVal) Then
                    mCoordInvalidCount = mCoordInvalidCount + 1
                    Coord_AddAudit auditData, auditCount, "INVALID SOURCE", key, idx + 1, 0, _
                                   "ROTATION_DEG is not numeric."
                    GoTo NextSourceRow
                End If
                hasRotation = True
            End If
        End If

        If hasRotation Then
            currentCoord = Array(xVal, yVal, zVal, rotVal)
        Else
            currentCoord = Array(xVal, yVal, zVal, Empty)
        End If

        If conflictMap.Exists(key) Then
            sourceRowText = CStr(conflictMap(key))
            If InStr(1, sourceRowText, CStr(idx + 1), vbTextCompare) = 0 Then
                conflictMap(key) = sourceRowText & "," & CStr(idx + 1)
            End If
            GoTo NextSourceRow
        End If

        If coordMap.Exists(key) Then
            previousCoord = coordMap(key)
            If Coord_CoordinatesEqual(previousCoord, currentCoord) Then
                mCoordDuplicateSameCount = mCoordDuplicateSameCount + 1
                Coord_AddAudit auditData, auditCount, "REPEATED IDENTICAL", key, idx + 1, 0, _
                               "Same coordinates as source row " & CStr(sourceRowMap(key)) & "."
            Else
                mCoordConflictCount = mCoordConflictCount + 1
                conflictMap(key) = CStr(sourceRowMap(key)) & "," & CStr(idx + 1)
                coordMap.Remove key
                sourceRowMap.Remove key
                Coord_AddAudit auditData, auditCount, "CONFLICT", key, idx + 1, 0, _
                               "Conflicting coordinates; SIS_SEQUENCE was not imported."
            End If
        Else
            coordMap.Add key, currentCoord
            sourceRowMap.Add key, idx + 1
        End If

NextSourceRow:
    Next idx

    If lastDestRow < 2 Then
        Set wsAudit = Coord_WriteAuditSheet(auditData, auditCount, wsSource.Name)
        Exit Sub
    End If

    rowCount = lastDestRow - 1
    destSeq = Coord_ReadColumn(wsDest, lastDestRow, cDestSeq)
    outX = Coord_ReadColumn(wsDest, lastDestRow, cDestX)
    outY = Coord_ReadColumn(wsDest, lastDestRow, cDestY)
    outZ = Coord_ReadColumn(wsDest, lastDestRow, cDestZ)
    outRot = Coord_ReadColumn(wsDest, lastDestRow, cDestRot)

    For idx = 1 To rowCount
        key = Coord_NormalizeSISKey(Coord_ArrayText(destSeq, idx))
        If Len(key) = 0 Then GoTo NextDestRow

        If conflictMap.Exists(key) Then
            mCoordUnmatchedCount = mCoordUnmatchedCount + 1
            Coord_AddAudit auditData, auditCount, "PD6 CONFLICT", key, 0, idx + 1, _
                           "Source rows " & CStr(conflictMap(key)) & " contain conflicting coordinates."
        ElseIf coordMap.Exists(key) Then
            currentCoord = coordMap(key)
            outX(idx, 1) = currentCoord(0)
            outY(idx, 1) = currentCoord(1)
            outZ(idx, 1) = currentCoord(2)
            outRot(idx, 1) = currentCoord(3)
            mCoordMatchedCount = mCoordMatchedCount + 1
        Else
            mCoordUnmatchedCount = mCoordUnmatchedCount + 1
            Coord_AddAudit auditData, auditCount, "NO MATCH", key, 0, idx + 1, _
                           "No coordinate source row matched this PD6 SIS_SEQUENCE."
        End If

NextDestRow:
    Next idx

    wsDest.Range(wsDest.Cells(2, cDestX), wsDest.Cells(lastDestRow, cDestX)).Value2 = outX
    wsDest.Range(wsDest.Cells(2, cDestY), wsDest.Cells(lastDestRow, cDestY)).Value2 = outY
    wsDest.Range(wsDest.Cells(2, cDestZ), wsDest.Cells(lastDestRow, cDestZ)).Value2 = outZ
    wsDest.Range(wsDest.Cells(2, cDestRot), wsDest.Cells(lastDestRow, cDestRot)).Value2 = outRot

    wsDest.Columns(cDestX).NumberFormat = COORD_NUMBER_FORMAT
    wsDest.Columns(cDestY).NumberFormat = COORD_NUMBER_FORMAT
    wsDest.Columns(cDestZ).NumberFormat = COORD_NUMBER_FORMAT
    wsDest.Columns(cDestRot).NumberFormat = COORD_NUMBER_FORMAT
    wsDest.Columns(cDestX).columnWidth = 14
    wsDest.Columns(cDestY).columnWidth = 14
    wsDest.Columns(cDestZ).columnWidth = 14
    wsDest.Columns(cDestRot).columnWidth = 16

    Set wsAudit = Coord_WriteAuditSheet(auditData, auditCount, wsSource.Name)

End Sub

'===============================================================================
' HEADER / WORKBOOK HELPERS
'===============================================================================
Private Sub Coord_EnsurePD6CoordinateHeaders(ByVal ws As Object)

    Dim requiredHeaders As Variant
    Dim i As Long
    Dim c As Long
    Dim lastCol As Long

    requiredHeaders = Array("X", "Y", "Z", "ROTATION_DEG")

    For i = LBound(requiredHeaders) To UBound(requiredHeaders)
        c = Coord_HeaderCol(ws, Array(CStr(requiredHeaders(i))))
        If c = 0 Then
            lastCol = Coord_LastUsedCol(ws)
            If lastCol < 1 Then lastCol = 0
            ws.Cells(1, lastCol + 1).value = CStr(requiredHeaders(i))
        End If
    Next i

    lastCol = Coord_LastUsedCol(ws)
    With ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol))
        .Font.Bold = True
    End With
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)).AutoFilter

End Sub

Private Function Coord_FindCoordinateSheet(ByVal wb As Object) As Object

    Dim ws As Object

    If wb Is Nothing Then Exit Function

    For Each ws In wb.Worksheets
        If Coord_HeaderCol(ws, Array("SIS_SEQUENCE", "SIS_Sequence", "SIS sequence", "Sequence")) > 0 And _
           Coord_HeaderCol(ws, Array("X", "X_COORD", "X COORDINATE", "X_COORDINATE")) > 0 And _
           Coord_HeaderCol(ws, Array("Y", "Y_COORD", "Y COORDINATE", "Y_COORDINATE")) > 0 And _
           Coord_HeaderCol(ws, Array("Z", "Z_COORD", "Z COORDINATE", "Z_COORDINATE")) > 0 Then
            Set Coord_FindCoordinateSheet = ws
            Exit Function
        End If
    Next ws

End Function

Private Function Coord_FindOpenWorkbook(ByVal fullPath As String) As Object

    Dim wb As Object

    For Each wb In Application.Workbooks
        If StrComp(wb.FullName, fullPath, vbTextCompare) = 0 Then
            Set Coord_FindOpenWorkbook = wb
            Exit Function
        End If
    Next wb

End Function

Private Function Coord_GetSheet(ByVal wb As Object, ByVal requestedSheetName As String) As Object

    On Error Resume Next
    Set Coord_GetSheet = wb.Worksheets(requestedSheetName)
    On Error GoTo 0

End Function

Private Function Coord_HeaderCol(ByVal ws As Object, ByVal aliases As Variant) As Long

    Dim lastCol As Long
    Dim c As Long
    Dim i As Long
    Dim cellKey As String
    Dim aliasKey As String

    Coord_HeaderCol = 0
    If ws Is Nothing Then Exit Function

    lastCol = Coord_LastUsedCol(ws)
    If lastCol < 1 Then Exit Function

    For c = 1 To lastCol
        cellKey = Coord_NormalizeHeader(CStr(ws.Cells(1, c).value))
        If Len(cellKey) > 0 Then
            For i = LBound(aliases) To UBound(aliases)
                aliasKey = Coord_NormalizeHeader(CStr(aliases(i)))
                If cellKey = aliasKey Then
                    Coord_HeaderCol = c
                    Exit Function
                End If
            Next i
        End If
    Next c

End Function

Private Function Coord_LastUsedRow(ByVal ws As Object) As Long

    Dim lastCell As Object

    On Error Resume Next
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), _
                                 LookIn:=xlFormulas, LookAt:=xlPart, _
                                 SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                 MatchCase:=False)
    On Error GoTo 0

    If lastCell Is Nothing Then
        Coord_LastUsedRow = 1
    Else
        Coord_LastUsedRow = lastCell.Row
    End If

End Function

Private Function Coord_LastUsedCol(ByVal ws As Object) As Long

    Dim lastCell As Object

    On Error Resume Next
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), _
                                 LookIn:=xlFormulas, LookAt:=xlPart, _
                                 SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, _
                                 MatchCase:=False)
    On Error GoTo 0

    If lastCell Is Nothing Then
        Coord_LastUsedCol = 0
    Else
        Coord_LastUsedCol = lastCell.Column
    End If

End Function

Private Function Coord_ReadColumn(ByVal ws As Object, ByVal lastRow As Long, ByVal colNum As Long) As Variant

    Dim blankData() As Variant
    Dim rowCount As Long

    rowCount = lastRow - 1
    If rowCount < 1 Then rowCount = 1

    If colNum > 0 Then
        Coord_ReadColumn = ws.Range(ws.Cells(2, colNum), ws.Cells(lastRow, colNum)).Value2
    Else
        ReDim blankData(1 To rowCount, 1 To 1)
        Coord_ReadColumn = blankData
    End If

End Function

Private Function Coord_ArrayValue(ByRef dataIn As Variant, ByVal indexValue As Long) As Variant

    On Error GoTo BlankValue
    If IsError(dataIn(indexValue, 1)) Or IsNull(dataIn(indexValue, 1)) Then GoTo BlankValue
    Coord_ArrayValue = dataIn(indexValue, 1)
    Exit Function

BlankValue:
    Coord_ArrayValue = Empty

End Function

Private Function Coord_ArrayText(ByRef dataIn As Variant, ByVal indexValue As Long) As String

    Dim valueIn As Variant

    valueIn = Coord_ArrayValue(dataIn, indexValue)
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then
        Coord_ArrayText = vbNullString
    Else
        Coord_ArrayText = Trim$(CStr(valueIn))
    End If

End Function

Private Function Coord_NormalizeHeader(ByVal valueIn As String) As String

    Dim i As Long
    Dim ch As String
    Dim resultText As String

    valueIn = UCase$(Trim$(Replace(valueIn, ChrW(160), " ")))

    For i = 1 To Len(valueIn)
        ch = mid$(valueIn, i, 1)
        If ch Like "[A-Z0-9]" Then resultText = resultText & ch
    Next i

    Coord_NormalizeHeader = resultText

End Function

Private Function Coord_NormalizeSISKey(ByVal valueIn As String) As String

    valueIn = Replace(valueIn, ChrW(160), " ")
    valueIn = Replace(valueIn, vbTab, " ")
    valueIn = UCase$(Trim$(valueIn))

    Do While InStr(1, valueIn, "  ", vbBinaryCompare) > 0
        valueIn = Replace(valueIn, "  ", " ")
    Loop

    valueIn = Replace(valueIn, " ", vbNullString)

    'Some CAD exports serialize empty identifiers as numeric zero.
    If valueIn = "0" Or valueIn = "0.0" Or valueIn = "0.00" Then valueIn = vbNullString

    Coord_NormalizeSISKey = valueIn

End Function

Private Function Coord_TryDouble(ByVal valueIn As Variant, ByRef valueOut As Double) As Boolean

    Dim textValue As String

    Coord_TryDouble = False

    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function

    If IsNumeric(valueIn) Then
        valueOut = CDbl(valueIn)
        Coord_TryDouble = True
        Exit Function
    End If

    textValue = Trim$(CStr(valueIn))
    textValue = Replace(textValue, ",", vbNullString)
    If IsNumeric(textValue) Then
        valueOut = CDbl(textValue)
        Coord_TryDouble = True
    End If

End Function

Private Function Coord_CoordinatesEqual(ByVal leftCoord As Variant, ByVal rightCoord As Variant) As Boolean

    Dim i As Long
    Dim leftBlank As Boolean
    Dim rightBlank As Boolean

    For i = 0 To 2
        If Abs(CDbl(leftCoord(i)) - CDbl(rightCoord(i))) > COORD_COMPARE_TOLERANCE Then Exit Function
    Next i

    leftBlank = IsEmpty(leftCoord(3)) Or Len(Trim$(CStr(leftCoord(3)))) = 0
    rightBlank = IsEmpty(rightCoord(3)) Or Len(Trim$(CStr(rightCoord(3)))) = 0

    If leftBlank Xor rightBlank Then Exit Function
    If Not leftBlank Then
        If Abs(CDbl(leftCoord(3)) - CDbl(rightCoord(3))) > COORD_COMPARE_TOLERANCE Then Exit Function
    End If

    Coord_CoordinatesEqual = True

End Function

'===============================================================================
' AUDIT OUTPUT
'===============================================================================
Private Sub Coord_AddAudit(ByRef auditData() As Variant, ByRef auditCount As Long, ByVal statusText As String, ByVal sisSequence As String, ByVal sourceRow As Long, ByVal pd6Row As Long, ByVal detailText As String)

    auditCount = auditCount + 1
    If auditCount > UBound(auditData, 1) Then Exit Sub

    auditData(auditCount, 1) = statusText
    auditData(auditCount, 2) = sisSequence
    If sourceRow > 0 Then auditData(auditCount, 3) = sourceRow
    If pd6Row > 0 Then auditData(auditCount, 4) = pd6Row
    auditData(auditCount, 5) = detailText

End Sub

Private Function Coord_WriteAuditSheet(ByRef auditData() As Variant, ByVal auditCount As Long, ByVal sourceSheetName As String) As Object

    Dim ws As Object
    Dim outputData() As Variant
    Dim r As Long
    Dim c As Long

    Set ws = Coord_GetSheet(ThisWorkbook, COORD_AUDIT_SHEET)
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = COORD_AUDIT_SHEET
    Else
        ws.Cells.Clear
    End If

    ws.Cells(1, 1).value = "STATUS"
    ws.Cells(1, 2).value = "SIS_SEQUENCE"
    ws.Cells(1, 3).value = "SOURCE_ROW"
    ws.Cells(1, 4).value = "PD6_ROW"
    ws.Cells(1, 5).value = "DETAIL"

    If auditCount > 0 Then
        ReDim outputData(1 To auditCount, 1 To 5)
        For r = 1 To auditCount
            For c = 1 To 5
                outputData(r, c) = auditData(r, c)
            Next c
        Next r
        ws.Range(ws.Cells(2, 1), ws.Cells(auditCount + 1, 5)).Value2 = outputData
    Else
        ws.Cells(2, 1).value = "OK"
        ws.Cells(2, 5).value = "No coordinate import exceptions were found."
    End If

    With ws.Range("A1:E1")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = vbWhite
        .AutoFilter
    End With

    ws.Columns("A:E").EntireColumn.AutoFit
    If ws.Columns("E").columnWidth > 70 Then ws.Columns("E").columnWidth = 70
    ws.Range("G1").value = "COORDINATE SOURCE SHEET"
    ws.Range("H1").value = sourceSheetName
    ws.Range("G1").Font.Bold = True

    Set Coord_WriteAuditSheet = ws

End Function

