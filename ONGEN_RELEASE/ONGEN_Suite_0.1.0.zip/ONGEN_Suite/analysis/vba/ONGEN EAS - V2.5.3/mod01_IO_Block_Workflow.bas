Attribute VB_Name = "mod01_IO_Block_Workflow"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod01_IO_Block_Workflow
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE AUDIT UPDATE
' Module        : mod01_IO_Block_Workflow
' Release       : V25.8.4-C02 BAS Audit Repair
' Author/Owner  : Lee Pierre
' Purpose       : Step 01-04 IO workflow and full-width tagged Step 04 export.
'-------------------------------------------------------------------------------
Option Explicit
' ONGEN V25.9.2 STEP01 FIX: import detailed generated IO sheets only; exclude raw/summary sheets.

'===============================================================================
' ONGEN V25.9.2 - PHASE 1 WORKFLOW REPAIR
' Restores the missing public Step01-Step04 procedures expected by the MAIN UI.
' Also restores the lightweight workflow wrappers historically owned by mod01.
'===============================================================================

Private Sub P1R_PrepareIOInputHeader(ByVal ws As Worksheet)
    Dim headers As Variant
    headers = Array("Device", "Device Type", "Channel IO", "Type", "Signal Name", _
                    "Port Location", "Part# Ref.", "Module Type", "IO Block", _
                    "Block ID", "PWG", "Panel", "Location", "Notes")
    ws.Range("A1").Resize(1, UBound(headers) + 1).value = headers
    StyleHeader ws.Range("A1:N1")
End Sub

Private Sub P1R_PrepareIOGeneratorHeader(ByVal ws As Worksheet)
    Dim headers As Variant
    headers = Array("Device", "Device Type", "Channel IO", "Type", "Signal Name", _
                    "Port Location", "Part# Ref.", "Module Type", "IO Block", _
                    "Block ID", "PWG", "Panel", "Location", "Notes", "Block", _
                    "Terminal", "IO BLOCK TERMINAL STD (OPTIONAL)", _
                    "IO BLOCK TERMINAL SAFE (OPTIONAL)", "TYPE")
    ws.Range("A1").Resize(1, UBound(headers) + 1).value = headers
    StyleHeader ws.Range("A1:S1")
End Sub

Private Sub P1R_ApplyIOBlockFormulas(ByVal ws As Worksheet, ByVal lastRow As Long)
    Dim q As String
    If lastRow < 2 Then Exit Sub
    q = Chr$(34) & Chr$(34)
    ws.Range("S2:S" & lastRow).FormulaR1C1 = _
        "=IFERROR(INDEX(DATA_IO_BLOCK!C12,MATCH(RC2,DATA_IO_BLOCK!C11,0))," & q & ")"
    ws.Range("O2:O" & lastRow).FormulaR1C1 = _
        "=IFERROR(INDEX(DATA_IO_BLOCK!C2,MATCH(RC19,DATA_IO_BLOCK!C1,0))," & q & ")"
    ws.Range("P2:P" & lastRow).FormulaR1C1 = _
        "=IFERROR(INDEX(DATA_IO_BLOCK!C3,MATCH(RC19,DATA_IO_BLOCK!C1,0))," & q & ")"
    ws.Range("O:S").Interior.Color = RGB(234, 244, 255)
End Sub

Private Function P1R_MergeNotes(ByVal existingNote As String, ByVal newNote As String) As String
    existingNote = Trim$(existingNote)
    newNote = Trim$(newNote)
    If Len(newNote) = 0 Then
        P1R_MergeNotes = existingNote
    ElseIf Len(existingNote) = 0 Then
        P1R_MergeNotes = newNote
    ElseIf StrComp(existingNote, newNote, vbTextCompare) = 0 Then
        P1R_MergeNotes = existingNote
    ElseIf InStr(1, "|" & UCase$(existingNote) & "|", _
                      "|" & UCase$(newNote) & "|", vbTextCompare) > 0 Then
        P1R_MergeNotes = existingNote
    Else
        P1R_MergeNotes = existingNote & " | " & newNote
    End If
End Function

Private Function P1R_SplitDeviceTypeToNotes(ByVal ws As Worksheet) As Long
    Dim colDevType As Long, colNotes As Long, lastRow As Long, r As Long
    Dim arrDevType As Variant, arrNotes As Variant
    Dim s As String, leftPart As String, rightPart As String, dashPos As Long
    Dim splitCount As Long

    colDevType = HeaderCol(ws, "Device Type", "Device type", "Item Type", "TYPE")
    colNotes = HeaderCol(ws, "Notes", "Note", "Description")
    If colDevType = 0 Then Err.Raise vbObjectError + 5101, , _
        "Could not find the Device Type / Item Type header on " & ws.Name & "."
    If colNotes = 0 Then
        colNotes = 14
        ws.Cells(1, colNotes).value = "Notes"
        StyleHeader ws.Cells(1, colNotes)
    End If

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then Exit Function
    arrDevType = ws.Range(ws.Cells(2, colDevType), ws.Cells(lastRow, colDevType)).value
    arrNotes = ws.Range(ws.Cells(2, colNotes), ws.Cells(lastRow, colNotes)).value

    For r = 1 To UBound(arrDevType, 1)
        s = Trim$(CStr(arrDevType(r, 1)))
        If Len(s) > 0 Then
            dashPos = InStr(1, s, "-", vbTextCompare)
            If dashPos > 1 And dashPos < Len(s) Then
                leftPart = Trim$(Left$(s, dashPos - 1))
                rightPart = Trim$(mid$(s, dashPos + 1))
                If Len(leftPart) > 0 And Len(rightPart) > 0 Then
                    arrDevType(r, 1) = leftPart
                    arrNotes(r, 1) = P1R_MergeNotes(CStr(arrNotes(r, 1)), rightPart)
                    splitCount = splitCount + 1
                End If
            End If
        End If
    Next r

    ws.Range(ws.Cells(2, colDevType), ws.Cells(lastRow, colDevType)).value = arrDevType
    ws.Range(ws.Cells(2, colNotes), ws.Cells(lastRow, colNotes)).value = arrNotes
    P1R_SplitDeviceTypeToNotes = splitCount
End Function

Public Sub Step01_Import_ONGEN_Generated_IO()
    Dim filePath As String
    Dim wbSrc As Workbook
    Dim wsSrc As Worksheet
    Dim wsDest As Worksheet
    Dim destRow As Long
    Dim srcLast As Long
    Dim r As Long
    Dim imported As Long
    Dim hasUsefulHeaders As Boolean

    On Error GoTo ErrHandler
    ResetApplicationState False

    filePath = PickWorkbookFile("Select ONGEN generated IO workbook")
    If Len(filePath) = 0 Then GoTo SafeExit

    Set wbSrc = Workbooks.Open(fileName:=filePath, ReadOnly:=True, UpdateLinks:=0)
    Set wsDest = EnsureSheet(SH_IO_INPUT)
    P1R_PrepareIOInputHeader wsDest
    wsDest.rows("2:" & wsDest.rows.count).ClearContents
    destRow = 2

    For Each wsSrc In wbSrc.Worksheets
        'Only import the detailed generated IO sheets.
        'The raw IO_DEVICE_LIST and the Network/IO Block summary sheets do not
        'contain the full channel data and must never be treated as generated IO rows.
        hasUsefulHeaders = _
            (HeaderCol(wsSrc, "Device", "Device Name") > 0 And _
             HeaderCol(wsSrc, "Part# Ref.", "Part# Ref", "Part Ref", "Part Number") > 0)

        If hasUsefulHeaders Then
            srcLast = LastUsedRow(wsSrc)
            For r = 2 To srcLast
                If Len(PickValue(wsSrc, r, "Device", "Device Name")) > 0 Or _
                   Len(PickValue(wsSrc, r, "IO Block", "IO_BLOCK")) > 0 Then
                    wsDest.Cells(destRow, 1).value = PickValue(wsSrc, r, "Device", "Device Name")
                    wsDest.Cells(destRow, 2).value = PickValue(wsSrc, r, "Device Type", "Device type", "Item Type", "TYPE")
                    wsDest.Cells(destRow, 3).value = PickValue(wsSrc, r, "Channel IO", "CHANNEL_IO", "Channel", "IO")
                    wsDest.Cells(destRow, 4).value = PickValue(wsSrc, r, "Type", "IO Type", "Signal Type")
                    wsDest.Cells(destRow, 5).value = PickValue(wsSrc, r, "Signal Name", "Signal")
                    wsDest.Cells(destRow, 6).value = PickValue(wsSrc, r, "Port Location", "Port")
                    wsDest.Cells(destRow, 7).value = PickValue(wsSrc, r, "Part# Ref.", "Part# Ref", "Part Ref", "Part Number")
                    wsDest.Cells(destRow, 8).value = PickValue(wsSrc, r, "Module Type", "Module")
                    wsDest.Cells(destRow, 9).value = PickValue(wsSrc, r, "IO Block", "IO_BLOCK")
                    wsDest.Cells(destRow, 10).value = PickValue(wsSrc, r, "Block ID", "BlockID")
                    wsDest.Cells(destRow, 11).value = PickValue(wsSrc, r, "PWG", "SwitchGroup")
                    wsDest.Cells(destRow, 12).value = PickValue(wsSrc, r, "Panel", "PNL")
                    wsDest.Cells(destRow, 13).value = PickValue(wsSrc, r, "Location", "Area_Number", "AREA_NUMBER")
                    wsDest.Cells(destRow, 14).value = PickValue(wsSrc, r, "Notes", "Note", "Description")
                    destRow = destRow + 1
                    imported = imported + 1
                End If
            Next r
        End If
    Next wsSrc

    wbSrc.Close SaveChanges:=False
    Set wbSrc = Nothing

    P1R_SplitDeviceTypeToNotes wsDest
    wsDest.Columns("A:N").AutoFit
    AppendLog "Step01_Import_ONGEN_Generated_IO", "OK", _
              CStr(imported) & " detailed generated IO rows imported. Summary/input sheets excluded."
    MsgBox imported & " detailed ONGEN IO rows imported into " & SH_IO_INPUT & "." & vbCrLf & _
           "Raw IO_DEVICE_LIST and IO/network summary sheets were excluded.", vbInformation

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    On Error Resume Next
    If Not wbSrc Is Nothing Then wbSrc.Close SaveChanges:=False
    ResetApplicationState True
    AppendLog "Step01_Import_ONGEN_Generated_IO", "ERROR", Err.description
    MsgBox "Import failed: " & Err.description, vbCritical
End Sub

Public Sub Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST()
    Dim wsIn As Worksheet, wsOut As Worksheet
    Dim lastRow As Long, outLast As Long, splitCount As Long
    On Error GoTo ErrHandler
    ResetApplicationState False
    Set wsIn = EnsureSheet(SH_IO_INPUT)
    Set wsOut = EnsureSheet(SH_IO_GEN)
    P1R_PrepareIOInputHeader wsIn
    P1R_PrepareIOGeneratorHeader wsOut
    lastRow = LastUsedRow(wsIn)
    If lastRow < 2 Then
        MsgBox "No IO rows found in " & SH_IO_INPUT & ".", vbExclamation
        GoTo SafeExit
    End If
    splitCount = P1R_SplitDeviceTypeToNotes(wsIn)
    wsOut.rows("2:" & wsOut.rows.count).ClearContents
    lastRow = LastUsedRow(wsIn)
    wsOut.Range("A2:N" & lastRow).value = wsIn.Range("A2:N" & lastRow).value
    outLast = LastUsedRow(wsOut)
    P1R_ApplyIOBlockFormulas wsOut, outLast
    wsOut.Columns("A:S").AutoFit
    AppendLog "Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST", "OK", _
              CStr(outLast - 1) & " rows built; Device Type split count=" & CStr(splitCount) & "."
    MsgBox "IO_BLOCK_GENERATOR was built with " & (outLast - 1) & " rows.", vbInformation
SafeExit:
    ResetApplicationState True
    Exit Sub
ErrHandler:
    ResetApplicationState True
    AppendLog "Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST", "ERROR", Err.description
    MsgBox "Build failed: " & Err.description, vbCritical
End Sub

Public Sub Step03_Refresh_IO_BLOCK_DATA_Formulas()
    Dim ws As Worksheet, lastRow As Long
    On Error GoTo ErrHandler
    ResetApplicationState False
    Set ws = EnsureSheet(SH_IO_GEN)
    P1R_PrepareIOGeneratorHeader ws
    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then lastRow = 500
    P1R_ApplyIOBlockFormulas ws, lastRow
    AppendLog "Step03_Refresh_IO_BLOCK_DATA_Formulas", "OK", _
              "Formulas refreshed through row " & CStr(lastRow) & "."
    MsgBox "IO_BLOCK_GENERATOR formulas refreshed through row " & lastRow & ".", vbInformation
SafeExit:
    ResetApplicationState True
    Exit Sub
ErrHandler:
    ResetApplicationState True
    AppendLog "Step03_Refresh_IO_BLOCK_DATA_Formulas", "ERROR", Err.description
    MsgBox "Formula refresh failed: " & Err.description, vbCritical
End Sub
Public Sub Step04_Export_Beckhoff_ONGEN_Input()
    Dim ws As Worksheet, wsOut As Worksheet, wbOut As Workbook, savePath As String
    Dim lastRow As Long, lastCol As Long, tagCol As Long, r As Long
    Dim colDevice As Long, colBlockID As Long, colPanel As Long, colArea As Long
    Dim colDeviceType As Long, colSignalType As Long, colSignalName As Long, colNotes As Long
    Dim colCableGroup As Long, evidence As String, cableGroup As String

    On Error GoTo ErrHandler
    ResetApplicationState False
    Set ws = EnsureSheet(SH_IO_GEN)
    lastRow = LastUsedRow(ws)
    lastCol = LastUsedCol(ws)
    If lastRow < 2 Or lastCol < 1 Then
        MsgBox "No rows found in " & SH_IO_GEN & ". Build the IO block generator first.", vbExclamation
        GoTo SafeExit
    End If

    colDevice = HeaderCol(ws, "DEVICE", "DEVICE NAME", "SIS_SEQUENCE")
    colBlockID = HeaderCol(ws, "BLOCK ID", "BLOCKID")
    colPanel = HeaderCol(ws, "PANEL", "PNL")
    colArea = HeaderCol(ws, "LOCATION", "AREA_NUMBER", "AREA")
    colDeviceType = HeaderCol(ws, "DEVICE TYPE", "ITEM TYPE")
    colSignalType = HeaderCol(ws, "TYPE", "SIGNAL TYPE", "CHANNEL TYPE")
    colSignalName = HeaderCol(ws, "SIGNAL NAME", "SIGNAL")
    colNotes = HeaderCol(ws, "NOTES", "DESCRIPTION")
    colCableGroup = HeaderCol(ws, "PHYSICAL_CABLE_GROUP", "CABLE_GROUP", "CABLE GROUP", "CABLE_ID_GROUP")

    If colDevice = 0 Then
        Err.Raise vbObjectError + 30401, "Step04_Export_Beckhoff_ONGEN_Input", _
                  "IO_BLOCK_GENERATOR is missing the Device header required to create IO cable tags."
    End If

    savePath = PickSaveAsPath("Save Beckhoff ONGEN input workbook", "Beckhoff_ONGEN_Input.xlsx")
    If Len(savePath) = 0 Then GoTo SafeExit

    ONGEN_CableID_BeginRun
    Set wbOut = Workbooks.Add(xlWBATWorksheet)
    Set wsOut = wbOut.Worksheets(1)
    wsOut.Name = SafeSheetName(SH_IO_GEN)

    'Export the complete used IO_BLOCK_GENERATOR width, including future added columns.
    wsOut.Range("A1").Resize(lastRow, lastCol).Value2 = _
        ws.Range("A1").Resize(lastRow, lastCol).Value2

    tagCol = HeaderCol(wsOut, "TAG")
    If tagCol = 0 Then
        tagCol = lastCol + 1
        wsOut.Cells(1, tagCol).Value2 = "tag"
    Else
        wsOut.Cells(1, tagCol).Value2 = "tag"
    End If

    For r = 2 To lastRow
        If Len(Trim$(CStr(ws.Cells(r, colDevice).Value2))) > 0 Then
            evidence = P1R_CellText(ws, r, colBlockID) & "|" & _
                       P1R_CellText(ws, r, colDeviceType) & "|" & _
                       P1R_CellText(ws, r, colSignalType) & "|" & _
                       P1R_CellText(ws, r, colSignalName) & "|" & _
                       P1R_CellText(ws, r, colDevice) & "|" & _
                       P1R_CellText(ws, r, colNotes)
            cableGroup = P1R_CellText(ws, r, colCableGroup)
            wsOut.Cells(r, tagCol).Value2 = ONGEN_ExportTag_IO( _
                P1R_CellText(ws, r, colDevice), P1R_CellText(ws, r, colBlockID), _
                P1R_CellText(ws, r, colPanel), P1R_CellText(ws, r, colArea), evidence, cableGroup)
        End If
    Next r

    wsOut.rows(1).Font.Bold = True
    wsOut.Range(wsOut.Cells(1, 1), wsOut.Cells(lastRow, IIf(tagCol > lastCol, tagCol, lastCol))).Columns.AutoFit

    On Error Resume Next
    NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook wbOut
    On Error GoTo ErrHandler
    wbOut.SaveAs fileName:=savePath, FileFormat:=xlOpenXMLWorkbook
    wbOut.Close SaveChanges:=False
    Set wbOut = Nothing

    AppendLog "Step04_Export_Beckhoff_ONGEN_Input", "OK", _
              savePath & " | Source columns exported: " & CStr(lastCol) & " | tag column=" & CStr(tagCol)
    MsgBox "Beckhoff ONGEN input exported with the complete IO_BLOCK_GENERATOR and cable tag column:" & _
           vbCrLf & savePath, vbInformation
SafeExit:
    ResetApplicationState True
    Exit Sub
ErrHandler:
    On Error Resume Next
    If Not wbOut Is Nothing Then wbOut.Close SaveChanges:=False
    ResetApplicationState True
    AppendLog "Step04_Export_Beckhoff_ONGEN_Input", "ERROR", Err.description
    MsgBox "Export failed: " & Err.description, vbCritical
End Sub
Private Function P1R_CellText(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal colNum As Long) As String
    If colNum <= 0 Then Exit Function
    P1R_CellText = Trim$(CStr(ws.Cells(rowNum, colNum).Value2))
End Function

Public Sub PATCH_IO_DEVICE_LIST_Split_DeviceType_To_Notes()
    Dim ws As Worksheet, splitCount As Long
    On Error GoTo ErrHandler
    ResetApplicationState False
    Set ws = EnsureSheet(SH_IO_INPUT)
    P1R_PrepareIOInputHeader ws
    splitCount = P1R_SplitDeviceTypeToNotes(ws)
    ws.Columns("A:N").AutoFit
    AppendLog "PATCH_IO_DEVICE_LIST_Split_DeviceType_To_Notes", "OK", CStr(splitCount) & " rows split."
    MsgBox "Device Type / Notes split complete. Rows updated: " & splitCount, vbInformation
SafeExit:
    ResetApplicationState True
    Exit Sub
ErrHandler:
    ResetApplicationState True
    AppendLog "PATCH_IO_DEVICE_LIST_Split_DeviceType_To_Notes", "ERROR", Err.description
    MsgBox "Device Type / Notes split failed: " & Err.description, vbCritical
End Sub

Public Sub Step_PATCH_Split_DeviceType_Notes()
    PATCH_IO_DEVICE_LIST_Split_DeviceType_To_Notes
End Sub

Private Sub P1R_RunExternalMacro(ByVal macroName As String, ByVal friendlyName As String)
    Dim wbMacroPath As String
    On Error GoTo TryLocalOnly
    AppendLog friendlyName, "START", macroName
    wbMacroPath = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
    Application.Run wbMacroPath
    AppendLog friendlyName, "OK", macroName & " completed."
    Exit Sub
TryLocalOnly:
    Err.Clear
    On Error GoTo MacroFailed
    Application.Run macroName
    AppendLog friendlyName, "OK", macroName & " completed."
    Exit Sub
MacroFailed:
    AppendLog friendlyName, "ERROR", macroName & ": " & Err.description
    MsgBox friendlyName & " could not run." & vbCrLf & _
           "Required macro: " & macroName & vbCrLf & Err.description, vbCritical
End Sub

Private Sub P1R_EnsureNetworkWorkflowSheets()
    Dim ws As Worksheet
    Set ws = EnsureSheet("AREA")
    If Len(Trim$(CStr(ws.Range("A1").value))) = 0 Then ws.Range("A1").value = "Area Number"
    Set ws = EnsureSheet("IO_Topology")
    If Len(Trim$(CStr(ws.Range("A1").value))) = 0 Then ws.Range("A1").value = "IO_Topology"
End Sub

Public Sub Step10A_Refresh_Missing_Status_From_Generated_Sheets()
    P1R_RunExternalMacro "Step10_Refresh_Missing_Status_From_Generated_Sheets", _
                         "10A - Refresh 24V Index / PD6_IMPORT"
End Sub

Public Sub Step11_Import_IO_Topology_Uplinks_From_CSV()
    P1R_EnsureNetworkWorkflowSheets
    P1R_RunExternalMacro "Import_IO_Topology_Uplinks_From_CSV", "11 - Import IO Topology CSV/XLSX"
End Sub

Public Sub Step11B_Prepare_Auto_Network_From_PD6()
    P1R_EnsureNetworkWorkflowSheets
    P1R_RunExternalMacro "Prepare_Auto_Network_From_PD6", "11B - Prepare Auto Network From PD6"
End Sub

Public Sub Step12_Create_RCP_Clean_Sheets()
    P1R_EnsureNetworkWorkflowSheets
    P1R_RunExternalMacro "Create_All_RCP_Clean_Sheets", "12 - Create RCP Clean Sheets"
End Sub

Public Sub Step12A_Refresh_RCP_Clean_Data_Formulas()
    P1R_EnsureNetworkWorkflowSheets
    P1R_RunExternalMacro "Refresh_All_RCP_Clean_Sheet_Formulas", "12A - Refresh RCP Clean DATA/Formulas"
End Sub

Public Sub Step13_Export_RCP_Clean_Sheets()
    P1R_RunExternalMacro "Export_RCP_Clean_Sheets_To_New_Workbook", "13 - Export RCP Values Only"
End Sub

Public Sub Step14_Build_All_RCP_Clean_Then_Export()
    P1R_EnsureNetworkWorkflowSheets
    P1R_RunExternalMacro "Build_All_RCP_Clean_Then_Export", "14 - Legacy RCP Clean + Export"
End Sub

