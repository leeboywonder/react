Attribute VB_Name = "ONGEN_RESTORE_REFERENCE_MAIN"
Option Explicit

'===============================================================================
' ONGEN V30 - REFERENCE MAIN LAYOUT + SECURITY REPAIR
'
' PURPOSE
'   Restores the workbook to the reference MAIN layout:
'     PHASE 0 | SETUP + VALIDATION
'     PHASE 1 | I/O ENGINEERING
'     PHASE 2 | PD6 ENGINEERING DATA
'     PHASE 3 | POWER GENERATION
'     PHASE 4 | NETWORK + RCP GENERATION
'     PHASE 5 | VFD + RELEASE OUTPUTS
'     PHASE 6 | FINAL QA + RELEASE
'
'   Then restores:
'     - Admin/User security
'     - Admin/Recovery panel on right side of MAIN
'     - READ ME
'     - CTRL_FUNCTION headers
'     - worksheet navigation
'
' IMPORTANT
'   This module does NOT replace the production MAIN builder.
'   It deliberately calls the existing:
'
'       Step00_Create_MAIN_Buttons_And_ProgressBar
'
'   so the full reference phase layout stays controlled by the production
'   mod00_UI_Buttons_ProgressBar module.
'
' MAIN COMMAND
'       ONGEN_RESTORE_REFERENCE_MAIN
'===============================================================================

Private Const MAIN_SHEET As String = "MAIN"
Private Const FUNCTION_SHEET As String = "CTRL_FUNCTION"
Private Const README_SHEET As String = "READ ME"

Public Sub ONGEN_RESTORE_REFERENCE_MAIN()
    On Error GoTo EH

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False

    'Temporarily allow structural/UI repair.
    On Error Resume Next
    ThisWorkbook.Unprotect Password:="ONGEN-STRUCTURE-2026"
    ThisWorkbook.Worksheets(MAIN_SHEET).Unprotect Password:="ONGEN-STRUCTURE-2026"
    On Error GoTo EH

    '1. Rebuild the full reference Phase 0-6 MAIN layout from the production UI.
    Application.Run "'" & ThisWorkbook.Name & "'!Step00_Create_MAIN_Buttons_And_ProgressBar"

    '2. Restore navigation controls on existing sheets.
    On Error Resume Next
    Application.Run "'" & ThisWorkbook.Name & "'!NAV_Install_Return_To_MAIN_Buttons_All_Sheets", False, False
    If Err.Number <> 0 Then
        Err.Clear
        Application.Run "'" & ThisWorkbook.Name & "'!NAV_Install_Return_To_MAIN_Buttons_All_Sheets", False
    End If
    On Error GoTo EH

    '3. Restore current workbook support features.
    ONGEN_REPAIR_FUNCTION_HEADERS
    ONGEN_REPAIR_READ_ME
    ONGEN_INSTALL_REFERENCE_ADMIN_PANEL

    '4. Apply final User Mode state.
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_APPLY_STARTUP_SECURITY"

    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN MAIN reference layout restored." & vbCrLf & vbCrLf & _
           "The Phase 0-6 dashboard was rebuilt from the production MAIN builder," & vbCrLf & _
           "then Admin/User security, navigation, READ ME, and function headers were restored.", _
           vbInformation, "ONGEN MAIN Repair"
    Exit Sub

EH:
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN MAIN reference repair stopped." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN MAIN Repair"
End Sub

'===============================================================================
' ADMIN / RECOVERY PANEL
' Matches the reference workbook placement on the RIGHT side of MAIN.
'===============================================================================

Public Sub ONGEN_INSTALL_REFERENCE_ADMIN_PANEL()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(MAIN_SHEET)

    Dim names As Variant
    names = Array( _
        "ONGEN_ADMIN_PANEL_BG", _
        "ONGEN_ADMIN_PANEL_TITLE", _
        "ONGEN_ADMIN_LOGIN_BTN", _
        "ONGEN_ADMIN_SHEET_LAUNCHER_BTN", _
        "ONGEN_ADMIN_LOGOUT_BTN", _
        "ONGEN_ADMIN_CHANGE_PASSWORD_BTN", _
        "ONGEN_ADMIN_REPAIR_BTN", _
        "ONGEN_ADMIN_RELOAD_UI_BTN", _
        "ONGEN_ADMIN_VFD_SETUP_BTN", _
        "ONGEN_ADMIN_INSTALL_UI_BTN", _
        "ONGEN_ADMIN_CLEAR_BTN" _
    )

    Dim i As Long
    For i = LBound(names) To UBound(names)
        On Error Resume Next
        ws.Shapes(CStr(names(i))).Delete
        On Error GoTo 0
    Next i

    Dim leftX As Double
    Dim topY As Double
    Dim w As Double
    Dim h As Double
    Dim gap As Double

    'Reference workbook admin strip begins around Excel column P.
    leftX = ws.Columns("P").Left + 8
    topY = 12
    w = 220
    h = 28
    gap = 6

    ONGEN_AddPanel ws, leftX - 8, topY - 4, w + 16, 330, "ONGEN_ADMIN_PANEL_BG"

    ONGEN_AddLabel ws, leftX, topY, w, 24, _
                   "ADMIN / RECOVERY", "ONGEN_ADMIN_PANEL_TITLE"
    topY = topY + 32

    'Visible in User Mode.
    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "ADMIN LOGIN", "ONGEN_ADMIN_LOGIN", _
                    "ONGEN_ADMIN_LOGIN_BTN", False
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "0B WORKSHEET NAVIGATOR", "NAV_Open_Worksheet_Launcher", _
                    "ONGEN_ADMIN_SHEET_LAUNCHER_BTN", False
    topY = topY + h + gap

    'Admin only.
    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "EXIT ADMIN MODE", "ONGEN_ADMIN_LOGOUT", _
                    "ONGEN_ADMIN_LOGOUT_BTN", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "CHANGE ADMIN PASSWORD", "ONGEN_ADMIN_CHANGE_PASSWORD", _
                    "ONGEN_ADMIN_CHANGE_PASSWORD_BTN", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "REPAIR CURRENT FEATURES", "ONGEN_RESTORE_REFERENCE_MAIN", _
                    "ONGEN_ADMIN_REPAIR_BTN", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "RELOAD MAIN / UI", "ONGEN_RELOAD_ALL_UI_BUTTONS", _
                    "ONGEN_ADMIN_RELOAD_UI_BTN", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "VFD SETUP", "ONGEN_VFD_SETUP", _
                    "ONGEN_ADMIN_VFD_SETUP_BTN", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "INSTALL / REPAIR UI", "ONGEN_EAS_INSTALL_UI", _
                    "ONGEN_ADMIN_INSTALL_UI_BTN", True

    'Reference workbook also carries a recovery clear control below the admin strip.
    ONGEN_AddButton ws, leftX, topY + h + 14, w, h, _
                    "18 CLEAR GENERATED DATA", "ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE", _
                    "ONGEN_ADMIN_CLEAR_BTN", False
End Sub

'===============================================================================
' CTRL_FUNCTION HEADER REPAIR
' Preserves all existing rows below Row 1.
'===============================================================================

Public Sub ONGEN_REPAIR_FUNCTION_HEADERS()
    Dim ws As Worksheet
    Set ws = ONGEN_GetOrCreateSheet(FUNCTION_SHEET)

    Dim headers As Variant
    headers = Array( _
        "CONTROL_FUNCTION_NUMBER", _
        "TYPE", _
        "BLOCK", _
        "NOTE", _
        "conveyor Type", _
        "PART_NUM_1", _
        "MANUF_NAME_1", _
        "PART_NUM_2", _
        "MANUF_NAME_2", _
        "PART_NUM_3", _
        "MANUF_NAME_3", _
        "PART_NUM_4", _
        "MANUF_NAME_4", _
        "PART_NUM_5", _
        "MANUF_NAME_5" _
    )

    Dim i As Long
    For i = LBound(headers) To UBound(headers)
        ws.Cells(1, i + 1).value = CStr(headers(i))
    Next i

    With ws.Range("A1:O1")
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(31, 78, 121)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With

    ws.rows(1).RowHeight = 30
    ws.Columns("A:O").AutoFit
End Sub

'===============================================================================
' READ ME
'===============================================================================

Public Sub ONGEN_REPAIR_READ_ME()
    Dim ws As Worksheet
    Set ws = ONGEN_GetOrCreateSheet(README_SHEET)

    If Len(Trim$(CStr(ws.Range("A1").value))) > 0 Then Exit Sub

    ws.Range("A1").value = "ONGEN Engineering Automation Suite - READ ME"
    ws.Range("A3").value = "USER MODE"
    ws.Range("A4").value = "Engineering sheet data remains editable."
    ws.Range("A5").value = "Workbook structure and MAIN buttons are protected."

    ws.Range("A7").value = "ADMIN MODE"
    ws.Range("A8").value = "Use ADMIN LOGIN on MAIN."
    ws.Range("A9").value = "Initial administrator password: zayden"
    ws.Range("A10").value = "Use CHANGE ADMIN PASSWORD after login."

    ws.Range("A12").value = "MAIN REPAIR COMMAND"
    ws.Range("A13").value = "ONGEN_RESTORE_REFERENCE_MAIN"

    With ws.Range("A1:F1")
        .Merge
        .Font.Bold = True
        .Font.Size = 16
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(31, 78, 121)
    End With

    ws.Columns("A").columnWidth = 72
End Sub

'===============================================================================
' SHAPE HELPERS
'===============================================================================

Private Sub ONGEN_AddPanel(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, _
                           ByVal w As Double, ByVal h As Double, ByVal shapeName As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)

    shp.Name = shapeName
    shp.Fill.ForeColor.RGB = RGB(242, 242, 242)
    shp.Line.ForeColor.RGB = RGB(180, 180, 180)
    shp.Locked = True
End Sub

Private Sub ONGEN_AddLabel(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, _
                           ByVal w As Double, ByVal h As Double, ByVal caption As String, _
                           ByVal shapeName As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, x, y, w, h)

    shp.Name = shapeName
    shp.TextFrame2.TextRange.text = caption
    shp.TextFrame2.TextRange.Font.Bold = msoTrue
    shp.TextFrame2.TextRange.Font.Size = 12
    shp.Line.Visible = msoFalse
    shp.Fill.Visible = msoFalse
    shp.Locked = True
End Sub

Private Sub ONGEN_AddButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, _
                            ByVal w As Double, ByVal h As Double, ByVal caption As String, _
                            ByVal macroName As String, ByVal shapeName As String, _
                            ByVal adminOnly As Boolean)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)

    shp.Name = shapeName
    shp.TextFrame2.TextRange.text = caption
    shp.TextFrame2.TextRange.Font.Bold = msoTrue
    shp.TextFrame2.TextRange.Font.Size = 9
    shp.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle

    If adminOnly Then
        shp.Fill.ForeColor.RGB = RGB(192, 80, 77)
        shp.AlternativeText = "ONGEN_ROLE=ADMIN | " & macroName
    Else
        shp.Fill.ForeColor.RGB = RGB(31, 78, 121)
        shp.AlternativeText = "ONGEN_ROLE=USER | " & macroName
    End If

    shp.Line.ForeColor.RGB = RGB(255, 255, 255)
    shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
    shp.OnAction = "'" & ThisWorkbook.Name & "'!" & macroName
    shp.Locked = True
End Sub

Private Function ONGEN_GetOrCreateSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set ONGEN_GetOrCreateSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0

    If ONGEN_GetOrCreateSheet Is Nothing Then
        Set ONGEN_GetOrCreateSheet = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ONGEN_GetOrCreateSheet.Name = sheetName
    End If
End Function
