Attribute VB_Name = "mod00_UI_Buttons_ProgressBar"
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.7.6-PREMIUM-MAIN-REBUILD-RELEASE
' Module        : mod00_UI_Buttons_ProgressBar
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : V25.7.6 premium MAIN full-rebuild release.
' Notes         : Preserves the premium Phase 0-6 MAIN format and prevents duplicate/stacked buttons by fully rebuilding MAIN.
'-------------------------------------------------------------------------------

' UI PATCH 2026-07-17: clear 05B button for recalculating current PD6_IMPORT.
Option Explicit

' ONGEN Engineering Automation Suite V20.0 synchronized UI release

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R9
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-13
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

'====================================================================================
' Module Name : mod00_UI_Buttons_ProgressBar
' Author     : Lee Pierre
' Version     : V2.4 Released - External Label List Export
' Purpose     : Creates and audits the complete MAIN command dashboard, reloads all
'               workflow buttons, and uses workbook-qualified macro assignments.
'
' How to use:
'   1) Import this .bas file into the combined macro-enabled workbook.
'   2) Make sure the separated workflow modules are also imported:
'        mod00_ONGEN_Common.bas
'        mod01_IO_Block_Workflow.bas
'        mod02_PD6_Import.bas
'        mod03_24V_Power_Generator.bas
'        mod04_480V_VFD_Generator.bas
'        mod05_Export_Validate_Clear.bas
'        mod06_Refresh_Missing_Status_From_Generated_Sheets.bas
'        IMPORT_IO_TOPOLOGY.bas
'        create_clean_PNL.bas  (updated version includes DATA lookup formulas)
'        export_clean_PNLsheet_gen.bas
'        CREATE_RCP_MAP.bas optional legacy all-in-one clean/export
'   3) Run: ONGEN_RELOAD_ALL_UI_BUTTONS
'   4) Auto_Open checks the button inventory whenever the workbook opens.
'
' Notes:
'   - This module does NOT replace the step macros.
'   - The buttons call wrapper macros in this module.
'   - The wrappers then run the existing Step01...Step99 macros.
'   - Progress bar is created using Excel shapes on the MAIN sheet.
'   - frmPDLauncher remains optional; all core commands are also available on MAIN.
'   - Release package: ONGEN V18 / UI V3.0. Only this module creates MAIN UI shapes.
'   - Adds a manual RIO / IO-S within-route normalization button.
'====================================================================================

' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_MAIN_SHEET As String = "MAIN"
' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_LOG_SHEET As String = "PROCESS_LOG"
' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_AUDIT_SHEET As String = "UI_BUTTON_AUDIT"
' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_RELEASE_VERSION As String = "ONGEN V25.7.6 / PREMIUM PHASE MAIN REBUILD"

' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_TAG As String = "ONGEN_UI_"
' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_PROGRESS_BACK As String = "ONGEN_UI_PROGRESS_BACK"
' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_PROGRESS_FILL As String = "ONGEN_UI_PROGRESS_FILL"
' LINE EXPLANATION: Defines a named constant used by the module.
Private Const UI_PROGRESS_TEXT As String = "ONGEN_UI_PROGRESS_TEXT"

' LINE EXPLANATION: Executes this VBA workflow instruction.
Private mTotalSteps As Long
' LINE EXPLANATION: Executes this VBA workflow instruction.
Private mCurrentStep As Long
' LINE EXPLANATION: Executes this VBA workflow instruction.
Private mProgressMessage As String
' LINE EXPLANATION: Executes this VBA workflow instruction.
Private mSilentBuild As Boolean


'====================================================================================
' AUTO REPAIR / RELEASE ENTRY POINTS
'====================================================================================
' Startup behavior:
'   1. Temporarily unlock the protected Workflow Guide for navigation repair.
'   2. Verify/rebuild required MAIN controls if needed.
'   3. Repair worksheet navigation silently.
'   4. Always finish startup in secured User Mode.
'====================================================================================

Public Sub Auto_Open()

    On Error Resume Next

    ONGEN_PREPARE_STARTUP_NAVIGATION

    UI_EnsureAllButtonsLoaded False

    NAV_Install_Return_To_MAIN_Buttons_All_Sheets False, False

    ONGEN_APPLY_STARTUP_SECURITY

    On Error GoTo 0

End Sub

Public Sub ONGEN_RELOAD_ALL_UI_BUTTONS()
    'Compatibility entry point. In V25.7.6, reload performs a complete MAIN rebuild
    'so repeated runs cannot stack new controls over older buttons.
    ONGEN_REBUILD_MAIN_FROM_SCRATCH
End Sub

Public Sub ONGEN_REBUILD_MAIN_FROM_SCRATCH()
    'Complete MAIN reset and rebuild.
    'The actual build routine deletes ALL existing shapes on MAIN, clears the cells,
    'and then recreates the premium Phase 0-6 dashboard.
    On Error GoTo EH

    mSilentBuild = False
    Step00_Create_MAIN_Buttons_And_ProgressBar

    'Keep worksheet navigation synchronized after rebuilding MAIN.
    On Error Resume Next
    NAV_Install_Return_To_MAIN_Buttons_All_Sheets False
    On Error GoTo 0
    Exit Sub

EH:
    MsgBox "MAIN rebuild failed:" & vbCrLf & _
           Err.Number & " - " & Err.description, _
           vbExclamation, "ONGEN EAS"
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub UI_EnsureAllButtonsLoaded(Optional ByVal forceRebuild As Boolean = False)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim needsRebuild As Boolean

    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo RebuildUI

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    needsRebuild = forceRebuild Or Not UI_IsButtonInventoryComplete()
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If Not needsRebuild Then Exit Sub

' LINE EXPLANATION: Defines a jump label used by the procedure error or cleanup path.
RebuildUI:
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    Err.Clear
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mSilentBuild = True
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    Step00_Create_MAIN_Buttons_And_ProgressBar
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mSilentBuild = False
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Audit_UI_Buttons()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_WriteButtonAudit True
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Workflow_Guide()
    On Error GoTo EH
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_Create_Or_Open_Workflow_Guide"
    Exit Sub
EH:
    MsgBox "The ONGEN workflow guide could not be opened." & vbCrLf & _
           "Confirm that mod00_ONGEN_Workflow_Guide.bas is imported.", _
           vbExclamation, "ONGEN Workflow Guide"
End Sub

Public Sub BTN_Open_UI_Button_Audit()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet UI_AUDIT_SHEET
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Refresh_All_Workbook()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "UI_RefreshAll", "Refresh Workbook Data and Formulas"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' V16.2-R9: Export the external IO, network, and power label report.
Public Sub BTN_Export_Label_List_Report()
    ' Run the label exporter through the common UI step wrapper.
    UI_RunOneStep "Export_ONGEN_Label_List_Report", _
                  "Export IO / Network / Power Label Report"
End Sub

'====================================================================================
' MAIN SETUP MACRO
'====================================================================================
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub Step00_Create_MAIN_Buttons_And_ProgressBar()
    Dim ws As Worksheet
    Dim topY As Double
    Dim phaseH As Double

    On Error GoTo EH
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    Set ws = UI_GetOrCreateSheetSafe(UI_MAIN_SHEET)
    UI_DeleteAllMainShapes ws
    UI_PrepareMainSheet ws
    UI_CreateProcessLogSheet

    UI_PremiumHeader ws
    UI_PremiumProgressStrip ws

    topY = 118

    phaseH = UI_AddPremiumPhase(ws, 0, "SETUP + VALIDATION", _
        "Install or repair the ONGEN interface, keep worksheet navigation synchronized, open the guide, and refresh workbook data.", _
        topY, RGB(22, 42, 58), RGB(92, 200, 190), _
        Array( _
            Array("0A Rebuild MAIN", "ONGEN_REBUILD_MAIN_FROM_SCRATCH"), _
            Array("0B Install Navigation", "BTN_Install_Return_To_MAIN_Buttons"), _
            Array("0C Workflow Guide", "BTN_Open_Workflow_Guide"), _
            Array("0D Refresh Workbook", "BTN_Refresh_All_Workbook"), _
            Array("0E Verify / Repair Buttons", "ONGEN_VERIFY_AND_REPAIR_MAIN_BUTTONS") _
        ))
    topY = topY + phaseH + 12

    phaseH = UI_AddPremiumPhase(ws, 1, "I/O ENGINEERING", _
        "Import ONGEN I/O data, build I/O blocks, refresh formulas, and export the AutoCAD I/O module input.", _
        topY, RGB(23, 63, 95), RGB(47, 128, 237), _
        Array( _
            Array("01 Import ONGEN I/O", "BTN_Run_Step01"), _
            Array("02 Build I/O Blocks", "BTN_Run_Step02"), _
            Array("03 Refresh I/O Data", "BTN_Run_Step03"), _
            Array("04 Export I/O Input", "BTN_Run_Step04"), _
            Array("Run I/O Workflow", "BTN_Run_Beckhoff_IO_Workflow") _
        ))
    topY = topY + phaseH + 12

    phaseH = UI_AddPremiumPhase(ws, 2, "PD6 ENGINEERING DATA", _
        "Import and validate PD6, recalculate engineering data, backfill I/O references, coordinates, Kx values, and PSU terminal assignments.", _
        topY, RGB(33, 53, 85), RGB(108, 142, 191), _
        Array( _
            Array("05 Import SIS TAG PD6", "BTN_Run_Step05"), _
            Array("05A Ensure Headers", "BTN_Run_PD6_Ensure_Headers"), _
            Array("05B Recalculate PD6", "BTN_Run_PD6_Recalculate"), _
            Array("05C Backfill From I/O", "BTN_Run_PD6_Backfill"), _
            Array("05D Reassign PSU / Term", "BTN_Run_PD6_Reassign"), _
            Array("05E Import XYZ", "BTN_Run_PD6_Coordinate_Import"), _
            Array("05F Backfill Network Kx", "BTN_Run_PD6_Network_Kx_Backfill"), _
            Array("05G Sync Kx to Power", "BTN_Run_Step05G_Power_Kx_Sync_UI") _
        ))
    topY = topY + phaseH + 12

    phaseH = UI_AddPremiumPhase(ws, 3, "POWER GENERATION", _
        "Refresh 24V source data, build 24V and 480V/VFD generators, export power inputs, and audit missing or corrected PSU assignments.", _
        topY, RGB(91, 44, 111), RGB(195, 155, 211), _
        Array( _
            Array("06 Refresh 24V Data", "BTN_Run_Step06"), _
            Array("07 Build 24V Generator", "BTN_Run_Step07"), _
            Array("08 Build 480V / VFD", "BTN_Run_Step08"), _
            Array("09 Export Power Input", "BTN_Run_Step09"), _
            Array("10A Refresh PSU Status", "BTN_Run_Refresh_Missing_PSU"), _
            Array("10B Recheck PSU Audit", "BTN_Run_Recheck_Step10A_Audit"), _
            Array("Run Power Workflow", "BTN_Run_Power_Workflow") _
        ))
    topY = topY + phaseH + 12

    phaseH = UI_AddPremiumPhase(ws, 4, "NETWORK + RCP GENERATION", _
        "Choose the CSV topology import or automatic PD6 network path, then create/refresh Network Clean sheets and RCP outputs before downstream VFD use.", _
        topY, RGB(15, 93, 94), RGB(0, 166, 166), _
        Array( _
            Array("11 Import Topology CSV", "BTN_Run_Step11"), _
            Array("11B Prepare Auto Network", "BTN_Run_Step11B"), _
            Array("12 Create RCP Clean", "BTN_Run_Step12"), _
            Array("12A Refresh Clean", "BTN_Run_Step12A"), _
            Array("13 Export RCP Values", "BTN_Run_Step13"), _
            Array("Normalize RIO / IO-S", "BTN_Enforce_RIO_IOS_Grouping"), _
            Array("Run CSV Network / RCP", "BTN_Run_Network_RCP_Workflow"), _
            Array("Run Auto Network / RCP", "BTN_Run_Auto_Network_RCP_Workflow") _
        ))
    topY = topY + phaseH + 12

    phaseH = UI_AddPremiumPhase(ws, 5, "VFD + RELEASE OUTPUTS", _
        "Prepare VFD drawing data and queues, backfill Network Clean From/To information, and build the separate all-discipline cable-tag schedule.", _
        topY, RGB(125, 78, 0), RGB(245, 176, 65), _
        Array( _
            Array("15A Install VFD Data", "BTN_VFD_Install_Workflow"), _
            Array("15B Build 480V + Queue", "BTN_VFD_Build_And_Refresh"), _
            Array("15C Refresh VFD Queue", "BTN_VFD_Refresh_Queue"), _
            Array("15D Rebuild From Plan", "BTN_VFD_Rebuild_Queue"), _
            Array("15E Open Drawing Queue", "BTN_VFD_Open_Queue"), _
            Array("15F Open Sheet Plan", "BTN_VFD_Open_Sheet_Plan"), _
            Array("15G Backfill VFD Network", "BTN_VFD_Backfill_Network"), _
            Array("15H Build All Cable Tags", "BTN_Build_All_Cable_Tags") _
        ))
    topY = topY + phaseH + 12

    phaseH = UI_AddPremiumPhase(ws, 6, "FINAL QA + RELEASE", _
        "Validate the workbook, export the combined label report, review process results, and use final cleanup only after controlled release files are complete.", _
        topY, RGB(123, 36, 28), RGB(236, 112, 99), _
        Array( _
            Array("16 Validate Workbook", "BTN_Run_Step10"), _
            Array("17 Export Label Report", "BTN_Export_Label_List_Report"), _
            Array("Open Validation / Log", "BTN_Open_Validation_Sheet"), _
            Array("18 Final Clear Data", "BTN_Run_Step99") _
        ))

    UI_PremiumFooter ws, topY + phaseH + 12
    UI_SetProgress 0, 1, "Ready. Run Phase 0 first, then continue through Phases 1 to 6."
    UI_WriteButtonAudit False

    ws.Activate
    ws.Range("A1").Select
    ActiveWindow.Zoom = 80

    UI_AppendLog "SETUP", "SUCCESS", "Premium phase MAIN dashboard fully rebuilt with key workflow buttons: " & UI_RELEASE_VERSION

CleanExit:
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    If Not mSilentBuild Then
        MsgBox "ONGEN MAIN dashboard rebuilt from scratch." & vbCrLf & _
               "All prior MAIN shapes were removed, then the premium phase layout and key workflow buttons were recreated.", _
               vbInformation, "ONGEN EAS"
    End If
    Exit Sub

EH:
    UI_AppendLog "SETUP", "FAILED", Err.Number & " - " & Err.description
    MsgBox "MAIN dashboard build failed:" & vbCrLf & Err.description, vbExclamation, "ONGEN EAS"
    Resume CleanExit
End Sub

Private Function UI_AddPremiumPhase(ByVal ws As Worksheet, ByVal phaseNo As Long, ByVal title As String, _
                                    ByVal description As String, ByVal topY As Double, _
                                    ByVal fillColor As Long, ByVal accentColor As Long, _
                                    ByVal actions As Variant) As Double
    Dim card As Shape
    Dim hdr As Shape
    Dim desc As Shape
    Dim actionCount As Long
    Dim rowCount As Long
    Dim cardH As Double
    Dim i As Long
    Dim colNo As Long
    Dim rowNo As Long
    Dim x As Double
    Dim y As Double

    actionCount = UBound(actions) - LBound(actions) + 1
    rowCount = (actionCount + 3) \ 4
    If rowCount < 1 Then rowCount = 1
    cardH = 104 + ((rowCount - 1) * 58)

    Set card = UI_PremiumRoundRect(ws, 25, topY, 1160, cardH, RGB(255, 255, 255), RGB(200, 216, 224), 1)
    card.Name = UI_TAG & "PHASE_CARD_" & CStr(phaseNo)
    card.ZOrder msoSendToBack

    Set hdr = UI_PremiumRoundRect(ws, 38, topY + 10, 220, cardH - 20, fillColor, accentColor, 1.25)
    hdr.Name = UI_TAG & "PHASE_HEADER_" & CStr(phaseNo)
    hdr.TextFrame2.TextRange.text = "PHASE " & CStr(phaseNo) & vbCrLf & title
    With hdr.TextFrame2.TextRange.Font
        .Size = 13
        .Bold = msoTrue
        .Fill.ForeColor.RGB = RGB(255, 255, 255)
    End With
    hdr.TextFrame2.VerticalAnchor = msoAnchorMiddle
    hdr.TextFrame2.MarginLeft = 14
    hdr.TextFrame2.MarginRight = 10

    Set desc = UI_PremiumRoundRect(ws, 275, topY + 13, 265, cardH - 26, RGB(244, 248, 251), RGB(210, 226, 234), 1)
    desc.Name = UI_TAG & "PHASE_DESC_" & CStr(phaseNo)
    desc.TextFrame2.TextRange.text = description
    With desc.TextFrame2.TextRange.Font
        .Size = 9.5
        .Fill.ForeColor.RGB = RGB(36, 68, 82)
    End With
    desc.TextFrame2.MarginLeft = 12
    desc.TextFrame2.MarginRight = 10
    desc.TextFrame2.VerticalAnchor = msoAnchorMiddle

    For i = LBound(actions) To UBound(actions)
        colNo = (i - LBound(actions)) Mod 4
        rowNo = (i - LBound(actions)) \ 4
        x = 560 + (colNo * 150)
        y = topY + 24 + (rowNo * 58)
        UI_AddPremiumButton ws, x, y, 138, 48, CStr(actions(i)(0)), CStr(actions(i)(1)), fillColor, accentColor
    Next i

    UI_AddPremiumPhase = cardH
End Function

Private Sub UI_AddPremiumButton(ByVal ws As Worksheet, ByVal leftPos As Double, ByVal topPos As Double, _
                                ByVal widthVal As Double, ByVal heightVal As Double, _
                                ByVal caption As String, ByVal macroName As String, _
                                ByVal fillColor As Long, ByVal accentColor As Long)
    Dim shp As Shape

    Set shp = UI_PremiumRoundRect(ws, leftPos, topPos, widthVal, heightVal, fillColor, accentColor, 1.25)
    shp.Name = UI_TAG & "BTN_" & Replace(Replace(Replace(Replace(caption, " ", "_"), "/", "_"), "+", "_"), "-", "_")
    shp.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
    shp.AlternativeText = "ONGEN command: " & macroName & " | " & UI_RELEASE_VERSION
    shp.TextFrame2.TextRange.text = caption
    With shp.TextFrame2.TextRange.Font
        .Size = 9.1
        .Bold = msoTrue
        .Fill.ForeColor.RGB = RGB(255, 255, 255)
    End With
    shp.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle
    shp.TextFrame2.MarginLeft = 5
    shp.TextFrame2.MarginRight = 5
End Sub

Private Sub UI_PremiumHeader(ByVal ws As Worksheet)
    Dim shp As Shape

    Set shp = UI_PremiumRoundRect(ws, 25, 18, 1160, 66, RGB(11, 31, 51), RGB(0, 166, 166), 1.5)
    shp.Name = UI_TAG & "PREMIUM_TITLE"
    shp.TextFrame2.TextRange.text = "ONGEN Engineering Automation Suite | Guided Release Workflow | " & UI_RELEASE_VERSION
    With shp.TextFrame2.TextRange.Font
        .Size = 20
        .Bold = msoTrue
        .Fill.ForeColor.RGB = RGB(255, 255, 255)
    End With
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle
    shp.TextFrame2.MarginLeft = 20

    Set shp = UI_PremiumRoundRect(ws, 25, 88, 1160, 22, RGB(234, 243, 247), RGB(178, 209, 220), 1)
    shp.Name = UI_TAG & "PREMIUM_SUBTITLE"
    shp.TextFrame2.TextRange.text = "Keep the dashboard simple: run the numbered phases in order. Expanded rows show only the key production steps required inside that phase."
    With shp.TextFrame2.TextRange.Font
        .Size = 10
        .Fill.ForeColor.RGB = RGB(18, 50, 71)
    End With
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle
    shp.TextFrame2.MarginLeft = 14
End Sub

Private Sub UI_PremiumProgressStrip(ByVal ws As Worksheet)
    Dim shp As Shape

    Set shp = UI_PremiumRoundRect(ws, 25, 112, 1160, 5, RGB(215, 227, 234), RGB(215, 227, 234), 0)
    shp.Name = UI_PROGRESS_BACK

    Set shp = UI_PremiumRoundRect(ws, 25, 112, 8, 5, RGB(0, 166, 166), RGB(47, 128, 237), 0)
    shp.Name = UI_PROGRESS_FILL

    Set shp = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, 25, 96, 1160, 15)
    shp.Name = UI_PROGRESS_TEXT
    shp.TextFrame2.TextRange.text = "Ready"
    With shp.TextFrame2.TextRange.Font
        .Size = 8.5
        .Bold = msoTrue
        .Fill.ForeColor.RGB = RGB(18, 50, 71)
    End With
    shp.Line.Visible = msoFalse
    shp.Fill.Visible = msoFalse
End Sub

Private Sub UI_PremiumFooter(ByVal ws As Worksheet, ByVal topY As Double)
    Dim shp As Shape

    Set shp = UI_PremiumRoundRect(ws, 25, topY, 1160, 56, RGB(234, 243, 247), RGB(178, 209, 220), 1)
    shp.Name = UI_TAG & "PREMIUM_FOOTER"
    shp.TextFrame2.TextRange.text = _
        "Network rule: Phase 4 uses either Step 11 CSV topology import OR Step 11B automatic PD6 network preparation before Clean sheets. " & _
        "Release rule: validate data and outputs before Step 18 final cleanup."
    With shp.TextFrame2.TextRange.Font
        .Size = 10.25
        .Bold = msoTrue
        .Fill.ForeColor.RGB = RGB(18, 50, 71)
    End With
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle
    shp.TextFrame2.MarginLeft = 18
    shp.TextFrame2.MarginRight = 18
End Sub

Private Function UI_PremiumRoundRect(ByVal ws As Worksheet, ByVal leftPos As Double, ByVal topPos As Double, _
                                     ByVal widthVal As Double, ByVal heightVal As Double, _
                                     ByVal fillColor As Long, ByVal lineColor As Long, _
                                     ByVal lineWeight As Double) As Shape
    Set UI_PremiumRoundRect = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPos, topPos, widthVal, heightVal)
    With UI_PremiumRoundRect
        .Fill.Visible = msoTrue
        .Fill.ForeColor.RGB = fillColor
        .Line.Visible = msoTrue
        .Line.ForeColor.RGB = lineColor
        .Line.Weight = lineWeight
        .Shadow.Visible = msoTrue
        .Shadow.Transparency = 0.82
        .Shadow.Blur = 8
        .Shadow.OffsetX = 1.5
        .Shadow.OffsetY = 1.5
        .Placement = xlFreeFloating
    End With
End Function

'====================================================================================
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step01()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step01_Import_ONGEN_Generated_IO", "01 - Import ONGEN Generated IO"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step02()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST", "02 - Build IO_BLOCK_GENERATOR"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step03()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step03_Refresh_IO_BLOCK_DATA_Formulas", "03 - Refresh IO Block DATA Formulas"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step04()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step04_Export_Beckhoff_ONGEN_Input", "04 - Export Beckhoff ONGEN Input"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step05()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step05_Import_SIS_TAG_PD6_From_PD_Workbook", "05 - Import SIS_TAG_PD6 From PD Workbook"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_PD6_Network_Kx_Backfill()
    UI_RunOneStep "Step05F_Backfill_Kx_From_Network_Clean", "05F - Backfill Kx From Network Clean"
End Sub

Public Sub BTN_Run_Step05G_Power_Kx_Sync_UI()
    UI_RunOneStep "Step05G_Sync_Kx_To_Generated_Power", "05G - Sync Kx To Generated 24V / 480V"
End Sub

Public Sub BTN_Run_Step06()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step06_Refresh_24V_Power_Formulas_From_DATA", "06 - Refresh 24V Power Formulas From DATA"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step07()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step07_Build_24V_Power_Generator_From_PD6", "07 - Build 24V Power Generator From PD6"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step08()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step08_Build_480V_VFD_Generator_From_PD6", "08 - Build 480V VFD Generator From PD6"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step09()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step09_Export_SNR_24V_Input", "09 - Export 24V A:H / 480V A:J"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Refresh_Missing_PSU()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step10A_Refresh_Missing_Status_From_Generated_Sheets", "10A - Refresh 24V Index / PD6_IMPORT"
' LINE EXPLANATION: Ends the current procedure.
End Sub

Public Sub BTN_Run_Recheck_Step10A_Audit()
    UI_RunOneStep "Step10B_Recheck_And_Clear_Solved_Audit_Issues", _
                  "10B - Recheck / Clear Solved Step10A Audit Issues"
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step10()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step10_Validate_Workbook", "10 - Validate Workbook"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step99()
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim answer As VbMsgBoxResult
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    answer = MsgBox("This will clear generated data. Continue?", vbQuestion + vbYesNo, "Clear Generated Data")
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If answer <> vbYes Then Exit Sub
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step99_Clear_Generated_Data", "99 - Clear Generated Data"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_PD6_Ensure_Headers()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step05_Ensure_PD6_IMPORT_Headers", "PD6 - Ensure Required Headers"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_PD6_Reassign()
    UI_RunOneStep "Step05_Reassign_PD6_BUS_PSU_Terminals", "PD6 - Reassign PSU / Terminals"
End Sub

Public Sub BTN_Run_PD6_Coordinate_Import()
    UI_RunOneStep "Step05E_Import_PD6_XYZ_From_Workbook", "05E - Import PD6 XYZ Coordinates"
End Sub

Public Sub BTN_Run_PD6_Recalculate()
    UI_RunOneStep "Step05_Recalculate_PD6_IMPORT_Calculations", "05B - Recalculate PD6 Calculations"
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_PD6_Backfill()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step05_Backfill_PD6_From_IO_DEVICE_LIST_Only", "PD6 - Backfill From IO_DEVICE_LIST"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Split_DeviceType_Notes()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step_PATCH_Split_DeviceType_Notes", "IO_DEVICE_LIST - Split Device Type / Notes"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Legacy_Simple_Buttons()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step00_Create_Control_Buttons", "MAIN - Legacy Simple Buttons"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step11()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step11_Import_IO_Topology_Uplinks_From_CSV", "11 - Import IO Topology CSV"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step11B()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step11B_Prepare_Auto_Network_From_PD6", "11B - Prepare Auto Network From PD6"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step12()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step12_Create_RCP_Clean_Sheets", "12 - Create RCP Clean Sheets"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step12A()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step12A_Refresh_RCP_Clean_Data_Formulas", "12A - Refresh RCP Clean DATA/Formulas"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step13()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step13_Export_RCP_Clean_Sheets", "13 - Export RCP Values Only"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Step14()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Step14_Build_All_RCP_Clean_Then_Export", "14 - Legacy Clean + Export"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Enforce_RIO_IOS_Grouping()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Enforce_RIO_IOS_Network_Grouping", "Network - Normalize RIO / IO-S Within SwitchGroup Routes"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_PD_Launcher()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "UI_ShowLauncher", "Open Worksheet Launcher"
' LINE EXPLANATION: Ends the current procedure.
End Sub

 ' V22.7: Installs or repairs Return Home and Sheet Launcher buttons.
Public Sub BTN_Install_Return_To_MAIN_Buttons()
    On Error GoTo EH
    NAV_Install_Return_To_MAIN_Buttons_All_Sheets True
    Exit Sub
EH:
    MsgBox "The worksheet navigation buttons could not be installed." & vbCrLf & _
           "Confirm modSheetHomeNavigation is imported." & vbCrLf & Err.description, _
           vbExclamation, "ONGEN Worksheet Navigation"
End Sub

' V22.7: Audits Return Home and Sheet Launcher buttons.
Public Sub BTN_Audit_Return_To_MAIN_Buttons()
    On Error GoTo EH
    NAV_Audit_Return_To_MAIN_Buttons
    Exit Sub
EH:
    MsgBox "The worksheet navigation audit could not run." & vbCrLf & _
           "Confirm modSheetHomeNavigation is imported." & vbCrLf & Err.description, _
           vbExclamation, "ONGEN Worksheet Navigation"
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Validation_Sheet()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "VALIDATION"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Process_Log()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "PROCESS_LOG"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Missing_PSU_Summary()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "24v_Power Generator"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_IO_Device_List()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "IO_DEVICE_LIST"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_PD6_Import()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "PD6_IMPORT"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Ecosystem_Setup()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Setup_ONGEN_Ecosystem", "Setup / Repair ONGEN Route Ecosystem"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Ecosystem_Sync()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Sync_All_ONGEN_Routes", "Synchronize IO / 24V / Network Routes"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Route_Config()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "IO_ROUTE_CONFIG"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Route_Master()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "IO_ROUTE_MASTER"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Route_Errors()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    BTN_Open_Worksheet "IO_ROUTE_ERRORS"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Open_Route_Folder()
    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo EH
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    Application.Run "'" & ThisWorkbook.Name & "'!Open_ONGEN_Route_Folder"
    ' LINE EXPLANATION: Leaves the current procedure or control structure immediately.
    Exit Sub
' LINE EXPLANATION: Defines a jump label used by the procedure error or cleanup path.
EH:
    ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
    MsgBox "The route-folder command is unavailable." & vbCrLf & _
           "Import modONGEN_Ecosystem.bas." & vbCrLf & _
           Err.description, vbExclamation, "ONGEN Route Folder"
' LINE EXPLANATION: Ends the current procedure.
End Sub


' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Select_Route_Folder()
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunOneStep "Select_ONGEN_Route_Folder", "Select ONGEN Route Folder"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_VFD_Install_Workflow()
    UI_RunOneStep "VFD_DWG_Install_Workflow", "Install / Refresh VFD Data Model"
End Sub

Public Sub BTN_VFD_Refresh_Queue()
    UI_RunOneStep "VFD_DWG_Refresh_Queue", "Refresh VFD Drawing Queue"
End Sub

Public Sub BTN_VFD_Rebuild_Queue()
    UI_RunOneStep "VFD_DWG_Rebuild_Queue_From_Plan", "Rebuild VFD Queue From Sheet Plan"
End Sub

Public Sub BTN_VFD_Build_And_Refresh()
    UI_RunOneStep "VFD_DWG_Build_480V_And_Refresh", "Build 480V Generator and Refresh VFD Queue"
End Sub

Public Sub BTN_VFD_Backfill_Network()
    UI_RunOneStep "VFD_DWG_Backfill_Network_From_Step11B", "Backfill VFD Network From Network Clean"
End Sub

Public Sub BTN_Build_All_Cable_Tags()
    UI_RunOneStep "Build_ONGEN_Combined_Label_List", "15H - Build Combined Cable Tag Output"
End Sub

'Backward-compatible legacy entry point. The cable-tag build is intentionally separate.
Public Sub BTN_VFD_Backfill_Network_And_Cable_Tags()
    BTN_VFD_Backfill_Network
End Sub


Public Sub BTN_VFD_One_Per_Sheet()
    UI_RunOneStep "VFD_DWG_Use_One_VFD_Per_Sheet", "Set One VFD Per PWR/IO Sheet"
End Sub

Public Sub BTN_VFD_Two_Per_Sheet()
    UI_RunOneStep "VFD_DWG_Use_Two_VFD_Per_Sheet", "Set Two VFDs Per PWR/IO Sheet"
End Sub

Public Sub BTN_VFD_Add_Device()
    UI_RunOneStep "VFD_DWG_Add_Device_To_Selected_VFD", "Add Device to Selected VFD"
End Sub

Public Sub BTN_VFD_Add_Circuit()
    UI_RunOneStep "VFD_DWG_Add_Circuit_To_Selected_VFD", "Add Circuit to Selected VFD"
End Sub

Public Sub BTN_VFD_Open_Queue()
    UI_RunOneStep "VFD_DWG_Open_Queue", "Open VFD Drawing Queue"
End Sub

Public Sub BTN_VFD_Open_Placement()
    UI_RunOneStep "VFD_DWG_Open_Device_Placement", "Open VFD Device Placement"
End Sub

Public Sub BTN_VFD_Open_Config()
    UI_RunOneStep "VFD_DWG_Open_Config", "Open VFD Drawing Configuration"
End Sub

Public Sub BTN_VFD_Open_Device_Library()
    UI_RunOneStep "VFD_DWG_Open_Device_Library", "Open VFD Device Library"
End Sub

Public Sub BTN_VFD_Open_Sheet_Plan()
    UI_RunOneStep "VFD_DWG_Open_Sheet_Plan", "Open VFD Sheet Plan"
End Sub

Public Sub BTN_VFD_Open_Seed_Library()
    UI_RunOneStep "VFD_DWG_Open_Seed_Library", "Open VFD Seed Library"
End Sub

Public Sub BTN_VFD_Open_Circuit_Library()
    UI_RunOneStep "VFD_DWG_Open_Circuit_Library", "Open VFD Circuit Library"
End Sub

Public Sub BTN_VFD_Open_Circuit_Placement()
    UI_RunOneStep "VFD_DWG_Open_Circuit_Placement", "Open VFD Circuit Placement"
End Sub

Public Sub BTN_VFD_Open_Attribute_Map()
    UI_RunOneStep "VFD_DWG_Open_Attribute_Map", "Open VFD Attribute Map"
End Sub

'Legacy compatibility only. No dedicated VFD repair button is created.
Public Sub BTN_VFD_Repair_Buttons()
    ONGEN_RELOAD_ALL_UI_BUTTONS
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub BTN_Open_Worksheet(ByVal sheetName As String)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim ws As Worksheet

    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error Resume Next
    ' LINE EXPLANATION: Assigns an object reference.
    Set ws = ThisWorkbook.Worksheets(sheetName)
    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo 0

    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If ws Is Nothing Then
        ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
        MsgBox "Worksheet '" & sheetName & "' does not exist yet.", _
               vbExclamation, "ONGEN Workbook"
        ' LINE EXPLANATION: Leaves the current procedure or control structure immediately.
        Exit Sub
    ' LINE EXPLANATION: Ends the current conditional block.
    End If

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    ws.Visible = xlSheetVisible
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    ws.Activate
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    ws.Range("A1").Select
' LINE EXPLANATION: Ends the current procedure.
End Sub

'====================================================================================
' BUTTON WRAPPER MACROS - GROUPED WORKFLOWS
'====================================================================================
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Full_Workflow()
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim steps As Variant

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    steps = Array( _
        Array("Step01_Import_ONGEN_Generated_IO", "01 - Import ONGEN Generated IO"), _
        Array("Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST", "02 - Build IO_BLOCK_GENERATOR"), _
        Array("Step03_Refresh_IO_BLOCK_DATA_Formulas", "03 - Refresh IO Block DATA Formulas"), _
        Array("Step04_Export_Beckhoff_ONGEN_Input", "04 - Export Beckhoff ONGEN Input"), _
        Array("Step05_Import_SIS_TAG_PD6_From_PD_Workbook", "05 - Import SIS_TAG_PD6 From PD Workbook"), _
        Array("Step06_Refresh_24V_Power_Formulas_From_DATA", "06 - Refresh 24V Power Formulas From DATA"), _
        Array("Step07_Build_24V_Power_Generator_From_PD6", "07 - Build 24V Power Generator From PD6"), _
        Array("Step10A_Refresh_Missing_Status_From_Generated_Sheets", "10A - Refresh 24V Index / PD6_IMPORT"), _
        Array("Step08_Build_480V_VFD_Generator_From_PD6", "08 - Build 480V VFD Generator From PD6"), _
        Array("Step09_Export_SNR_24V_Input", "09 - Export 24V A:H / 480V A:J"), _
        Array("Step10_Validate_Workbook", "10 - Validate Workbook") _
    )

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunStepArray steps, "FULL WORKFLOW"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Beckhoff_IO_Workflow()
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim steps As Variant

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    steps = Array( _
        Array("Step01_Import_ONGEN_Generated_IO", "01 - Import ONGEN Generated IO"), _
        Array("Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST", "02 - Build IO_BLOCK_GENERATOR"), _
        Array("Step03_Refresh_IO_BLOCK_DATA_Formulas", "03 - Refresh IO Block DATA Formulas"), _
        Array("Step04_Export_Beckhoff_ONGEN_Input", "04 - Export Beckhoff ONGEN Input") _
    )

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunStepArray steps, "BECKHOFF IO WORKFLOW"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Power_Workflow()
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim steps As Variant

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    steps = Array( _
        Array("Step05_Import_SIS_TAG_PD6_From_PD_Workbook", "05 - Import SIS_TAG_PD6 From PD Workbook"), _
        Array("Step06_Refresh_24V_Power_Formulas_From_DATA", "06 - Refresh 24V Power Formulas From DATA"), _
        Array("Step07_Build_24V_Power_Generator_From_PD6", "07 - Build 24V Power Generator From PD6"), _
        Array("Step10A_Refresh_Missing_Status_From_Generated_Sheets", "10A - Refresh 24V Index / PD6_IMPORT"), _
        Array("Step08_Build_480V_VFD_Generator_From_PD6", "08 - Build 480V VFD Generator From PD6"), _
        Array("Step09_Export_SNR_24V_Input", "09 - Export 24V A:H / 480V A:J"), _
        Array("Step10_Validate_Workbook", "10 - Validate Workbook") _
    )

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunStepArray steps, "PD6 / POWER WORKFLOW"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Network_RCP_Workflow()
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim steps As Variant

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    steps = Array( _
        Array("Step11_Import_IO_Topology_Uplinks_From_CSV", "11 - Import IO Topology CSV"), _
        Array("Step12_Create_RCP_Clean_Sheets", "12 - Create RCP Clean Sheets"), _
        Array("Step12A_Refresh_RCP_Clean_Data_Formulas", "12A - Refresh RCP Clean DATA/Formulas"), _
        Array("Step13_Export_RCP_Clean_Sheets", "13 - Export RCP Values Only") _
    )

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunStepArray steps, "CSV SCHEMATIC CTRL NETWORK / RCP WORKFLOW"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Public Sub BTN_Run_Auto_Network_RCP_Workflow()
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim steps As Variant

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    steps = Array( _
        Array("Step11B_Prepare_Auto_Network_From_PD6", "11B - Prepare Auto Network From PD6"), _
        Array("Step12_Create_RCP_Clean_Sheets", "12 - Create RCP Clean Sheets"), _
        Array("Step12A_Refresh_RCP_Clean_Data_Formulas", "12A - Refresh RCP Clean DATA/Formulas"), _
        Array("Step13_Export_RCP_Clean_Sheets", "13 - Export RCP Values Only") _
    )

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunStepArray steps, "AUTO PD6 NETWORK / RCP WORKFLOW"
' LINE EXPLANATION: Ends the current procedure.
End Sub

'====================================================================================
' RUNNER / PROGRESS ENGINE
'====================================================================================
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_RunOneStep(ByVal macroName As String, ByVal stepTitle As String)
    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo EH

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_CreateProcessLogSheet
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_ProgressStart 1, stepTitle
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetProgress 0, 1, "Starting: " & stepTitle
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_AppendLog stepTitle, "START", macroName

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    Application.StatusBar = stepTitle & "..."
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    DoEvents

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_RunMacro macroName

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetProgress 1, 1, "Completed: " & stepTitle
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_AppendLog stepTitle, "SUCCESS", macroName
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    Application.StatusBar = False

    ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
    MsgBox stepTitle & " completed.", vbInformation, "Step Complete"
    ' LINE EXPLANATION: Leaves the current procedure or control structure immediately.
    Exit Sub

' LINE EXPLANATION: Defines a jump label used by the procedure error or cleanup path.
EH:
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetProgress 0, 1, "Error: " & stepTitle
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_AppendLog stepTitle, "ERROR", Err.description
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    Application.StatusBar = False
    ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
    MsgBox stepTitle & " failed." & vbCrLf & vbCrLf & Err.description, vbCritical, "Step Error"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_RunStepArray(ByVal steps As Variant, ByVal workflowName As String)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim i As Long
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim macroName As String
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim stepTitle As String
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim total As Long

    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo EH

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_CreateProcessLogSheet
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    total = UBound(steps) - LBound(steps) + 1
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_ProgressStart total, workflowName
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_AppendLog workflowName, "START", "Running " & CStr(total) & " steps."

    ' LINE EXPLANATION: Starts a counted loop.
    For i = LBound(steps) To UBound(steps)
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        macroName = CStr(steps(i)(0))
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        stepTitle = CStr(steps(i)(1))

        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        UI_SetProgress CLng(i - LBound(steps)), total, "Running: " & stepTitle
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        Application.StatusBar = workflowName & " - " & stepTitle
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        UI_AppendLog stepTitle, "START", macroName
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        DoEvents

        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        UI_RunMacro macroName

        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        UI_SetProgress CLng(i - LBound(steps) + 1), total, "Completed: " & stepTitle
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        UI_AppendLog stepTitle, "SUCCESS", macroName
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        DoEvents
    ' LINE EXPLANATION: Moves to the next loop item or counter value.
    Next i

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetProgress total, total, workflowName & " completed."
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_AppendLog workflowName, "SUCCESS", "All workflow steps completed."
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    Application.StatusBar = False
    ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
    MsgBox workflowName & " completed.", vbInformation, "Workflow Complete"
    ' LINE EXPLANATION: Leaves the current procedure or control structure immediately.
    Exit Sub

' LINE EXPLANATION: Defines a jump label used by the procedure error or cleanup path.
EH:
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetProgress mCurrentStep, mTotalSteps, "Error: " & workflowName
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_AppendLog workflowName, "ERROR", "Stopped at: " & stepTitle & " | " & Err.description
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    Application.StatusBar = False
    ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
    MsgBox workflowName & " failed." & vbCrLf & vbCrLf & _
           "Stopped at: " & stepTitle & vbCrLf & _
           Err.description, vbCritical, "Workflow Error"
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_RunMacro(ByVal macroName As String)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim wbMacroPath As String

    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo MacroFailed

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    wbMacroPath = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    Application.Run wbMacroPath
    ' LINE EXPLANATION: Leaves the current procedure or control structure immediately.
    Exit Sub

' LINE EXPLANATION: Defines a jump label used by the procedure error or cleanup path.
MacroFailed:
    ' LINE EXPLANATION: Stops processing and raises a controlled error with a descriptive message.
    Err.Raise vbObjectError + 513, "UI_RunMacro", _
        "Could not run workbook macro: " & macroName & vbCrLf & _
        "Workbook: " & ThisWorkbook.Name & vbCrLf & vbCrLf & _
        "The MAIN button is attached correctly, but its target procedure is missing, not Public, or failed during startup." & vbCrLf & _
        "Import the released matching module and run Debug > Compile VBAProject."
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_ProgressStart(ByVal totalSteps As Long, ByVal messageText As String)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mTotalSteps = totalSteps
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mCurrentStep = 0
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mProgressMessage = messageText
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetProgress 0, totalSteps, messageText
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_SetProgress(ByVal currentStep As Long, ByVal totalSteps As Long, ByVal messageText As String)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim ws As Worksheet
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shpBack As Shape
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shpFill As Shape
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shpText As Shape
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim pct As Double
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim labelText As String

    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error Resume Next
    ' LINE EXPLANATION: Assigns an object reference.
    Set ws = ThisWorkbook.Worksheets(UI_MAIN_SHEET)
    ' LINE EXPLANATION: Assigns an object reference.
    Set shpBack = ws.Shapes(UI_PROGRESS_BACK)
    ' LINE EXPLANATION: Assigns an object reference.
    Set shpFill = ws.Shapes(UI_PROGRESS_FILL)
    ' LINE EXPLANATION: Assigns an object reference.
    Set shpText = ws.Shapes(UI_PROGRESS_TEXT)
    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo 0

    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If ws Is Nothing Then Exit Sub
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If shpBack Is Nothing Or shpFill Is Nothing Or shpText Is Nothing Then Exit Sub

    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If totalSteps <= 0 Then totalSteps = 1
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If currentStep < 0 Then currentStep = 0
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If currentStep > totalSteps Then currentStep = totalSteps

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    pct = currentStep / totalSteps
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mCurrentStep = currentStep
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mTotalSteps = totalSteps
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    mProgressMessage = messageText

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpFill.Left = shpBack.Left
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpFill.Top = shpBack.Top
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpFill.Height = shpBack.Height
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpFill.Width = shpBack.Width * pct

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    labelText = Format(pct, "0%") & "  |  " & messageText
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetShapeText shpText, labelText

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    Application.StatusBar = labelText
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    DoEvents
' LINE EXPLANATION: Ends the current procedure.
End Sub

'====================================================================================
' UI CREATION HELPERS
'====================================================================================
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Function UI_GetOrCreateSheetSafe(ByVal requestedName As String) As Object
    Dim wsResult As Object

    On Error Resume Next
    Set wsResult = ThisWorkbook.Worksheets(requestedName)
    On Error GoTo CreateFailed

    If wsResult Is Nothing Then
        If ThisWorkbook.Worksheets.count = 0 Then
            Set wsResult = ThisWorkbook.Worksheets.Add
        Else
            Set wsResult = ThisWorkbook.Worksheets.Add(Before:=ThisWorkbook.Worksheets(1))
        End If
        wsResult.Name = requestedName
    End If

    Set UI_GetOrCreateSheetSafe = wsResult
    Exit Function

CreateFailed:
    Set UI_GetOrCreateSheetSafe = Nothing
End Function

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_PrepareMainSheet(ByVal ws As Worksheet)
    ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
    With ws
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        .Cells.Clear
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Cells.Interior.Color = RGB(242, 246, 250)
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Range("A1").value = "ToolChain"
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .rows.RowHeight = 18
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Columns("A:K").columnWidth = 14
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Columns("A").columnWidth = 4
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Columns("B:H").columnWidth = 16
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        .Activate
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        ActiveWindow.DisplayGridlines = False
    ' LINE EXPLANATION: Ends the current With block.
    End With
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_DeleteAllMainShapes(ByVal ws As Worksheet)
    'V25.7.6: MAIN is a generated dashboard. Delete every existing drawing object
    'before reconstructing it so legacy buttons, old premium cards, text boxes,
    'Form Controls, and previous release shapes cannot remain underneath the new UI.
    Dim i As Long

    On Error Resume Next

    'Delete all worksheet shapes from back to front.
    For i = ws.Shapes.count To 1 Step -1
        ws.Shapes(i).Delete
    Next i

    'Extra safety for ActiveX/OLE controls that may survive as OLEObjects.
    For i = ws.OLEObjects.count To 1 Step -1
        ws.OLEObjects(i).Delete
    Next i

    On Error GoTo 0
End Sub

Private Sub UI_DeleteOldShapes(ByVal ws As Worksheet)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim i As Long
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim j As Long
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim deleteShape As Boolean
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shapeName As String
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim childName As String

    ' LINE EXPLANATION: Starts a counted loop.
    For i = ws.Shapes.count To 1 Step -1
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        deleteShape = False
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        shapeName = UCase$(ws.Shapes(i).Name)

        ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
        If UI_IsManagedShapeName(shapeName) Then
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            deleteShape = True
        ' LINE EXPLANATION: Tests the next condition when the earlier condition was false.
        ElseIf ws.Shapes(i).Type = msoGroup Then
            ' LINE EXPLANATION: Configures VBA error handling for the following statements.
            On Error Resume Next
            ' LINE EXPLANATION: Starts a counted loop.
            For j = 1 To ws.Shapes(i).GroupItems.count
                ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
                childName = UCase$(ws.Shapes(i).GroupItems(j).Name)
                ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
                If UI_IsManagedShapeName(childName) Then
                    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
                    deleteShape = True
                    ' LINE EXPLANATION: Leaves the current procedure or control structure immediately.
                    Exit For
                ' LINE EXPLANATION: Ends the current conditional block.
                End If
            ' LINE EXPLANATION: Moves to the next loop item or counter value.
            Next j
            ' LINE EXPLANATION: Configures VBA error handling for the following statements.
            On Error GoTo 0
        ' LINE EXPLANATION: Ends the current conditional block.
        End If

        ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
        If deleteShape Then ws.Shapes(i).Delete
    ' LINE EXPLANATION: Moves to the next loop item or counter value.
    Next i
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Function UI_IsManagedShapeName(ByVal shapeName As String) As Boolean
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    UI_IsManagedShapeName = _
        (Left$(shapeName, Len(UI_TAG)) = UCase$(UI_TAG)) Or _
        (Left$(shapeName, Len("VFD_DWG_UI_")) = "VFD_DWG_UI_") Or _
        (Left$(shapeName, Len("ONGEN_BTN_")) = "ONGEN_BTN_")
' LINE EXPLANATION: Ends the current procedure.
End Function

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_AddTitle(ByVal ws As Worksheet, ByVal leftX As Double, ByVal topY As Double)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shp As Shape

    ' LINE EXPLANATION: Assigns an object reference.
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftX, topY, 760, 54)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Name = UI_TAG & "TITLE"
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Fill.ForeColor.RGB = RGB(31, 78, 121)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Line.Visible = msoFalse
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetShapeText shp, "Swisslog Electrical Engineer Schematic Workflow - " & UI_RELEASE_VERSION
    ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
    With shp.TextFrame.Characters.Font
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Color = vbWhite
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Bold = True
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Size = 16
    ' LINE EXPLANATION: Ends the current With block.
    End With
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_AddProgressBar(ByVal ws As Worksheet, ByVal leftX As Double, ByVal topY As Double, ByVal barW As Double, ByVal barH As Double)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shpBack As Shape
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shpFill As Shape
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shpText As Shape

    ' LINE EXPLANATION: Assigns an object reference.
    Set shpBack = ws.Shapes.AddShape(msoShapeRectangle, leftX, topY, barW, barH)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpBack.Name = UI_PROGRESS_BACK
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpBack.Fill.ForeColor.RGB = RGB(217, 217, 217)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpBack.Line.ForeColor.RGB = RGB(128, 128, 128)

    ' LINE EXPLANATION: Assigns an object reference.
    Set shpFill = ws.Shapes.AddShape(msoShapeRectangle, leftX, topY, 1, barH)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpFill.Name = UI_PROGRESS_FILL
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpFill.Fill.ForeColor.RGB = RGB(112, 173, 71)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpFill.Line.Visible = msoFalse

    ' LINE EXPLANATION: Assigns an object reference.
    Set shpText = ws.Shapes.AddShape(msoShapeRectangle, leftX, topY, barW, barH)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpText.Name = UI_PROGRESS_TEXT
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpText.Fill.Visible = msoFalse
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shpText.Line.Visible = msoFalse
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetShapeText shpText, "Ready."
    ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
    With shpText.TextFrame.Characters.Font
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Color = RGB(0, 0, 0)
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Bold = True
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Size = 10
    ' LINE EXPLANATION: Ends the current With block.
    End With
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_AddSectionHeader(ByVal ws As Worksheet, ByVal leftX As Double, ByVal topY As Double, ByVal headerW As Double, ByVal caption As String)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shp As Shape
    ' LINE EXPLANATION: Assigns an object reference.
    Set shp = ws.Shapes.AddShape(msoShapeRectangle, leftX, topY, headerW, 22)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Name = UI_TAG & "SECTION_" & Replace(caption, " ", "_")
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Fill.ForeColor.RGB = RGB(64, 64, 64)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Line.Visible = msoFalse
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetShapeText shp, caption
    ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
    With shp.TextFrame.Characters.Font
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Color = vbWhite
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Bold = True
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Size = 10
    ' LINE EXPLANATION: Ends the current With block.
    End With
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_AddButton(ByVal ws As Worksheet, ByVal leftX As Double, ByVal topY As Double, ByVal btnW As Double, ByVal btnH As Double, ByVal caption As String, ByVal macroName As String, ByVal fillColor As Long)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shp As Shape
    ' LINE EXPLANATION: Assigns an object reference.
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftX, topY, btnW, btnH)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Name = UI_TAG & "BTN_" & Replace(Replace(caption, " ", "_"), "/", "_")
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Fill.ForeColor.RGB = fillColor
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Line.ForeColor.RGB = RGB(255, 255, 255)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Line.Weight = 1
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.AlternativeText = "ONGEN command: " & macroName & " | " & UI_RELEASE_VERSION
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetShapeText shp, caption
    ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
    With shp.TextFrame.Characters.Font
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Color = vbWhite
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Bold = True
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Size = 10
    ' LINE EXPLANATION: Ends the current With block.
    End With
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_AddInstructions(ByVal ws As Worksheet, ByVal leftX As Double, ByVal topY As Double)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shp As Shape
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim txt As String

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    txt = "Instructions:" & vbCrLf & _
          "1. Run Level 0 first: repair the UI, install worksheet navigation buttons, and open the workflow guide." & vbCrLf & _
          "2. Continue in order through Levels 1 to 6. The Run After column in ONGEN_WORKFLOW_GUIDE shows prerequisites." & vbCrLf & _
          "3. Step 05B recalculates current PD6_IMPORT data but does not change PSU or terminal assignments." & vbCrLf & _
          "4. Step 05D separately reassigns BUS, PSU, and terminals from 480v_DATA_POWER." & vbCrLf & _
          "5. Choose either CSV topology Step 11 or automatic network Step 11B before Steps 12, 12A, and 13." & vbCrLf & _
          "6. Complete validation before label exports or final cleanup." & vbCrLf & _
          "7. Step 18 is destructive. Run it only after backups and all required exports are complete." & vbCrLf & _
          "8. Advanced tools are optional and should be used after the numbered levels."

    ' LINE EXPLANATION: Assigns an object reference.
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftX, topY, 760, 150)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Name = UI_TAG & "INSTRUCTIONS"
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Fill.ForeColor.RGB = RGB(255, 255, 255)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.Line.ForeColor.RGB = RGB(191, 191, 191)
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    UI_SetShapeText shp, txt
    ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
    With shp.TextFrame.Characters.Font
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Color = RGB(64, 64, 64)
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Size = 10
    ' LINE EXPLANATION: Ends the current With block.
    End With
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_SetShapeText(ByVal shp As Shape, ByVal txt As String)
    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error Resume Next
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.TextFrame.Characters.text = txt
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.TextFrame.HorizontalAlignment = xlHAlignCenter
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.TextFrame.VerticalAlignment = xlVAlignCenter
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.TextFrame2.TextRange.text = txt
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle
    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo 0
' LINE EXPLANATION: Ends the current procedure.
End Sub


'====================================================================================
' BUTTON INVENTORY AUDIT
'====================================================================================
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Function UI_ExpectedButtonActions() As Variant
    Dim s As String

    s = "ONGEN_REBUILD_MAIN_FROM_SCRATCH|BTN_Install_Return_To_MAIN_Buttons|BTN_Open_Workflow_Guide|BTN_Refresh_All_Workbook"
    s = s & "|ONGEN_VERIFY_AND_REPAIR_MAIN_BUTTONS"
    s = s & "|BTN_Run_Step01|BTN_Run_Step02|BTN_Run_Step03|BTN_Run_Step04|BTN_Run_Beckhoff_IO_Workflow"
    s = s & "|BTN_Run_Step05|BTN_Run_PD6_Ensure_Headers|BTN_Run_PD6_Recalculate|BTN_Run_PD6_Backfill|BTN_Run_PD6_Reassign"
    s = s & "|BTN_Run_PD6_Coordinate_Import|BTN_Run_PD6_Network_Kx_Backfill|BTN_Run_Step05G_Power_Kx_Sync_UI"
    s = s & "|BTN_Run_Step06|BTN_Run_Step07|BTN_Run_Step08|BTN_Run_Step09|BTN_Run_Refresh_Missing_PSU"
    s = s & "|BTN_Run_Recheck_Step10A_Audit|BTN_Run_Power_Workflow"
    s = s & "|BTN_Run_Step11|BTN_Run_Step11B|BTN_Run_Step12|BTN_Run_Step12A|BTN_Run_Step13|BTN_Enforce_RIO_IOS_Grouping"
    s = s & "|BTN_Run_Network_RCP_Workflow|BTN_Run_Auto_Network_RCP_Workflow"
    s = s & "|BTN_VFD_Install_Workflow|BTN_VFD_Build_And_Refresh|BTN_VFD_Refresh_Queue|BTN_VFD_Rebuild_Queue"
    s = s & "|BTN_VFD_Open_Queue|BTN_VFD_Open_Sheet_Plan|BTN_VFD_Backfill_Network|BTN_Build_All_Cable_Tags"
    s = s & "|BTN_Run_Step10|BTN_Export_Label_List_Report|BTN_Open_Validation_Sheet|BTN_Run_Step99"

    UI_ExpectedButtonActions = Split(s, "|")
End Function


' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Function UI_NormalizeOnAction(ByVal onActionText As String) As String
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim p As Long
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim s As String

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    s = Trim$(onActionText)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    p = InStrRev(s, "!")
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If p > 0 Then s = mid$(s, p + 1)
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    UI_NormalizeOnAction = Replace(s, "'", "")
' LINE EXPLANATION: Ends the current procedure.
End Function

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Function UI_IsButtonInventoryComplete() As Boolean
    Dim ws As Worksheet
    Dim counts As Object
    Dim expected As Variant
    Dim item As Variant
    Dim shp As Shape
    Dim actionName As String
    Dim shapeName As String

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(UI_MAIN_SHEET)
    On Error GoTo 0
    If ws Is Nothing Then Exit Function

    Set counts = CreateObject("Scripting.Dictionary")
    counts.CompareMode = vbTextCompare

    For Each shp In ws.Shapes
        shapeName = UCase$(shp.Name)
        If Left$(shapeName, Len("VFD_DWG_UI_")) = "VFD_DWG_UI_" Then Exit Function
        If Len(shp.OnAction) > 0 Then
            actionName = UI_NormalizeOnAction(shp.OnAction)
            If Not counts.Exists(actionName) Then counts.Add actionName, 0
            counts(actionName) = CLng(counts(actionName)) + 1
        End If
    Next shp

    expected = UI_ExpectedButtonActions()
    For Each item In expected
        If Not counts.Exists(CStr(item)) Then Exit Function
        If CLng(counts(CStr(item))) <> 1 Then Exit Function
    Next item

    UI_IsButtonInventoryComplete = True
End Function

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_WriteButtonAudit(ByVal showResult As Boolean)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim wsMain As Worksheet
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim wsAudit As Worksheet
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim actual As Object
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shapeMap As Object
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim expected As Variant
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim item As Variant
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim shp As Shape
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim rowOut As Long
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim missingCount As Long
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim actionName As String

    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo EH

    ' LINE EXPLANATION: Assigns an object reference.
    Set wsMain = UI_GetOrCreateSheetSafe(UI_MAIN_SHEET)
    ' LINE EXPLANATION: Assigns an object reference.
    Set wsAudit = UI_GetOrCreateSheetSafe(UI_AUDIT_SHEET)
    ' LINE EXPLANATION: Assigns an object reference.
    Set actual = CreateObject("Scripting.Dictionary")
    ' LINE EXPLANATION: Assigns an object reference.
    Set shapeMap = CreateObject("Scripting.Dictionary")
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    actual.CompareMode = vbTextCompare
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    shapeMap.CompareMode = vbTextCompare

    ' LINE EXPLANATION: Starts a loop through every item in a collection.
    For Each shp In wsMain.Shapes
        ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
        If Len(shp.OnAction) > 0 Then
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            actionName = UI_NormalizeOnAction(shp.OnAction)
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            actual(actionName) = shp.OnAction
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            shapeMap(actionName) = shp.Name
        ' LINE EXPLANATION: Ends the current conditional block.
        End If
    ' LINE EXPLANATION: Moves to the next loop item or counter value.
    Next shp

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    wsAudit.Cells.Clear
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    wsAudit.Range("A1:F1").value = Array("Release", "Expected Macro", "Button Shape", "Assigned OnAction", "Status", "Audit Time")
    ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
    With wsAudit.Range("A1:F1")
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Font.Bold = True
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Font.Color = vbWhite
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        .Interior.Color = RGB(31, 78, 121)
    ' LINE EXPLANATION: Ends the current With block.
    End With

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    expected = UI_ExpectedButtonActions()
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    rowOut = 2
    ' LINE EXPLANATION: Starts a loop through every item in a collection.
    For Each item In expected
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        wsAudit.Cells(rowOut, "A").value = UI_RELEASE_VERSION
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        wsAudit.Cells(rowOut, "B").value = CStr(item)
        ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
        If actual.Exists(CStr(item)) Then
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            wsAudit.Cells(rowOut, "C").value = shapeMap(CStr(item))
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            wsAudit.Cells(rowOut, "D").value = actual(CStr(item))
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            wsAudit.Cells(rowOut, "E").value = "OK"
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            wsAudit.Cells(rowOut, "E").Interior.Color = RGB(198, 239, 206)
        ' LINE EXPLANATION: Runs the alternate branch when the preceding condition was false.
        Else
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            wsAudit.Cells(rowOut, "E").value = "MISSING"
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            wsAudit.Cells(rowOut, "E").Interior.Color = RGB(255, 199, 206)
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            missingCount = missingCount + 1
        ' LINE EXPLANATION: Ends the current conditional block.
        End If
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        wsAudit.Cells(rowOut, "F").value = Now
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        rowOut = rowOut + 1
    ' LINE EXPLANATION: Moves to the next loop item or counter value.
    Next item

    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    wsAudit.Columns("A:F").AutoFit
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    wsAudit.Range("F:F").NumberFormat = "yyyy-mm-dd hh:mm:ss"

    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    UI_AppendLog "UI BUTTON AUDIT", IIf(missingCount = 0, "SUCCESS", "WARNING"), _
                 CStr(missingCount) & " missing of " & CStr(UBound(expected) - LBound(expected) + 1) & " expected buttons."

    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If showResult Then
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        wsAudit.Visible = xlSheetVisible
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        wsAudit.Activate
        ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
        If missingCount = 0 Then
            ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
            MsgBox "All expected UI buttons are present and workbook-qualified." & vbCrLf & UI_RELEASE_VERSION, _
                   vbInformation, "UI Button Audit"
        ' LINE EXPLANATION: Runs the alternate branch when the preceding condition was false.
        Else
            ' LINE EXPLANATION: Displays status, guidance, or an error message to the user.
            MsgBox CStr(missingCount) & " expected button(s) are missing." & vbCrLf & _
                   "Run Reload All UI Buttons.", vbExclamation, "UI Button Audit"
        ' LINE EXPLANATION: Ends the current conditional block.
        End If
    ' LINE EXPLANATION: Ends the current conditional block.
    End If
    ' LINE EXPLANATION: Leaves the current procedure or control structure immediately.
    Exit Sub

' LINE EXPLANATION: Defines a jump label used by the procedure error or cleanup path.
EH:
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If showResult Then MsgBox "UI button audit failed: " & Err.description, vbExclamation, "UI Button Audit"
' LINE EXPLANATION: Ends the current procedure.
End Sub

'====================================================================================
' LOG HELPERS
'====================================================================================
' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_CreateProcessLogSheet()
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim ws As Worksheet

    ' LINE EXPLANATION: Assigns an object reference.
    Set ws = UI_GetOrCreateSheetSafe(UI_LOG_SHEET)

    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If Len(Trim$(CStr(ws.Range("A1").value))) = 0 Then
        ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
        ws.Range("A1:E1").value = Array("Date/Time", "Step", "Result", "Details", "User")
        ' LINE EXPLANATION: Starts a block that applies several operations to the same object.
        With ws.Range("A1:E1")
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            .Font.Bold = True
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            .Font.Color = vbWhite
            ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
            .Interior.Color = RGB(31, 78, 121)
        ' LINE EXPLANATION: Ends the current With block.
        End With
        ' LINE EXPLANATION: Executes this VBA workflow instruction.
        ws.Columns("A:E").AutoFit
    ' LINE EXPLANATION: Ends the current conditional block.
    End If
' LINE EXPLANATION: Ends the current procedure.
End Sub

' LINE EXPLANATION: Starts a procedure and declares its name, scope, parameters, and return type when applicable.
Private Sub UI_AppendLog(ByVal stepName As String, ByVal resultText As String, ByVal details As String)
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim ws As Worksheet
    ' LINE EXPLANATION: Declares variables used by the current procedure.
    Dim nextRow As Long

    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error Resume Next
    ' LINE EXPLANATION: Assigns an object reference.
    Set ws = UI_GetOrCreateSheetSafe(UI_LOG_SHEET)
    ' LINE EXPLANATION: Configures VBA error handling for the following statements.
    On Error GoTo 0
    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If ws Is Nothing Then Exit Sub

    ' LINE EXPLANATION: Tests a condition and runs the following action or block when it is true.
    If Len(Trim$(CStr(ws.Range("A1").value))) = 0 Then UI_CreateProcessLogSheet

    ' LINE EXPLANATION: Moves to the next loop item or counter value.
    nextRow = ws.Cells(ws.rows.count, "A").End(xlUp).Row + 1
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    ws.Cells(nextRow, "A").value = Now
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    ws.Cells(nextRow, "B").value = stepName
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    ws.Cells(nextRow, "C").value = resultText
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    ws.Cells(nextRow, "D").value = details
    ' LINE EXPLANATION: Calculates, assigns, or updates a value used by the workflow.
    ws.Cells(nextRow, "E").value = Environ$("Username")
    ' LINE EXPLANATION: Executes this VBA workflow instruction.
    ws.Columns("A:E").AutoFit
' LINE EXPLANATION: Ends the current procedure.
End Sub


Public Sub ONGEN_VERIFY_AND_REPAIR_MAIN_BUTTONS()
    On Error GoTo EH

    If UI_IsButtonInventoryComplete() Then
        UI_WriteButtonAudit False
        ONGEN_VERIFY_ALL_MAIN_BUTTONS
        Exit Sub
    End If

    If MsgBox("One or more MAIN buttons are missing, duplicated, or not attached to the expected macro." & vbCrLf & vbCrLf & _
              "Rebuild the MAIN dashboard now and repair all button attachments?", _
              vbYesNo + vbQuestion + vbDefaultButton1, "ONGEN MAIN Button Repair") = vbYes Then
        ONGEN_REBUILD_MAIN_FROM_SCRATCH
        UI_WriteButtonAudit False
        ONGEN_VERIFY_ALL_MAIN_BUTTONS
    Else
        UI_WriteButtonAudit True
    End If
    Exit Sub
EH:
    MsgBox "MAIN button verification/repair failed:" & vbCrLf & Err.Number & " - " & Err.description, _
           vbExclamation, "ONGEN MAIN Button Repair"
End Sub

'====================================================================================
' V25.7.6 COMPLETE BUTTON VERIFICATION
'====================================================================================
Public Sub ONGEN_VERIFY_ALL_MAIN_BUTTONS()
    Dim expected As Variant, actual As Object
    Dim ws As Worksheet, shp As Shape
    Dim i As Long, actionName As String
    Dim missing As String, foundCount As Long

    Set ws = UI_GetOrCreateSheetSafe(UI_MAIN_SHEET)
    Set actual = CreateObject("Scripting.Dictionary")
    actual.CompareMode = vbTextCompare

    For Each shp In ws.Shapes
        If Len(shp.OnAction) > 0 Then
            actionName = UI_NormalizeOnAction(shp.OnAction)
            If Len(actionName) > 0 Then actual(actionName) = True
        End If
    Next shp

    expected = UI_ExpectedButtonActions()
    For i = LBound(expected) To UBound(expected)
        If actual.Exists(CStr(expected(i))) Then
            foundCount = foundCount + 1
        Else
            missing = missing & vbCrLf & " - " & CStr(expected(i))
        End If
    Next i

    If Len(missing) = 0 Then
        MsgBox "MAIN button inventory PASS." & vbCrLf & _
               "All " & CStr(UBound(expected) - LBound(expected) + 1) & " required macro buttons are present.", _
               vbInformation, "ONGEN MAIN Button Audit"
    Else
        MsgBox "MAIN button inventory incomplete." & vbCrLf & _
               "Found: " & foundCount & " of " & CStr(UBound(expected) - LBound(expected) + 1) & vbCrLf & _
               "Missing:" & missing, vbExclamation, "ONGEN MAIN Button Audit"
    End If
End Sub


'====================================================================================
' V25.7.6 KEY BUTTON LINK REFERENCE
'====================================================================================
Public Sub ONGEN_SHOW_KEY_BUTTON_LINKS()
    Dim msg As String
    msg = "Verified canonical MAIN links:" & vbCrLf & vbCrLf & _
          "15G Backfill VFD Network" & vbTab & "-> VFD_DWG_Backfill_Network_From_Step11B" & vbCrLf & _
          "15H Build All Cable Tags" & vbTab & "-> Build_ONGEN_Combined_Label_List" & vbCrLf & _
          "17 Export Label Report" & vbTab & "-> Export_ONGEN_Label_List_Report" & vbCrLf & vbCrLf & _
          "Run Debug > Compile VBAProject after importing the released modules."
    MsgBox msg, vbInformation, "ONGEN EAS V25.7.6 Button Links"
End Sub
