Attribute VB_Name = "mod04_480V_VFD_Generator"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod04_480V_VFD_Generator
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : mod04_480V_VFD_Generator
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Step08 overwrite or generate-missing-only operation integrated.
' Notes         : Missing-only seeds the unique VFD map from the existing generator and appends only previously absent devices.
'-------------------------------------------------------------------------------



' ONGEN V20.7 UNIQUE VFD SOURCE FIX 2026-07-18
' One physical VFD produces exactly one VFD_480V_Generator row.
' Duplicate PD6 BUS/source rows are ignored by canonical SIS identity.
' Re-entry guard prevents accidental double execution.
' VFD PSU terminal and description output is read from 480v_DATA_POWER[PSUDESC].

'-------------------------------------------------------------------------------
' FULLY COMMENTED MAINTENANCE RELEASE
' Documentation Release : ONGEN V16.2-R2-COMMENTED
' Baseline              : ONGEN V16.2-R1 executable logic
' Functional Changes    : None - original VBA statements are preserved
' Commenting Method     : One explanation per logical VBA statement
' Continuation Rule     : Statements joined with _ receive one group comment
' Author/Owner          : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

' [LINE EXPLANATION] Requires every variable in this module to be declared before use, reducing spelling and type-related bugs.
Option Explicit

' ONGEN V19.2 repair: VFD feeder terminal/description read from 480v_DATA_POWER.

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R1
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-12
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

'==========================================================
' Module : mod04_480V_VFD_Generator
' Author     : Lee Pierre
' Release: PD6 LOAD + BUS-2 24V PSU FEEDER + 480V PANEL + NO TOP ROWS FIX
'
' Purpose:
'   Build worksheet VFD_480V_Generator from PD6_IMPORT.
'
' Corrected Rules:
'   1) VFD Load is taken directly from PD6_IMPORT[Load].
'      If PD6_IMPORT[Load] is blank, the code falls back to the previous
'      480v_DATA_POWER lookup:
'
'      PD6_IMPORT[Motor Power (Main Drive)]
'          -> match 480v_DATA_POWER[KW]
'          -> return 480v_DATA_POWER[MOVIFLEX]
'
'   2) VFD Block / Terminal (IN) / Terminal (OUT) are looked up from
'      480v_DATA_POWER by matching PD6_IMPORT[TYPE] to
'      480v_DATA_POWER[Device Type].
'
'   3) Power BUS-2 is the 24V PSU feeding the VFD.
'      Preferred source is the generated 24V panel sheet.
'      Fallback source is PD6_IMPORT[Power Supply] on the BUS-2 row.
'
'   4) Inside PSU TERM is added to the VFD output.
'      Preferred source is the generated 24V panel sheet.
'      Fallback is DATA_POWER terminal mapping / DC# inference.
'
'   5) 480V Panel is added to the VFD output from PD6_IMPORT[PNL].
'
'   6) 480v_DATA_POWER terminal rows are read as a template list.
'
'   7) Control_ID overrides SIS_Element_Number in generated output when not blank.
'
'   8) Blank reference rows no longer create repeated SIS_ELEMENT_NUMBER output rows.
'      Duplicate reference terminal definitions are also removed.
'
'   9) Generated TYPE text is DATA_IO_BLOCK[DESC] when available.
'      Blank Device Type / Block cells below a device section inherit the
'      previous Device Type / Block so VFD terminal rows are not lost.
'
' Output Sheet:
'   VFD_480V_Generator
'
' Depends on:
'   mod00_ONGEN_Common for EnsureSheet, ResetApplicationState,
'   AppendLog, StyleHeader, StyleSubHeader, SH_PD6, SH_480V, SH_24V.
'==========================================================

' [LINE EXPLANATION] Defines SH_480V_DATA as a String constant with value "480v_DATA_POWER". Edit this line to change sheet 480 v data globally.
Private Const SH_480V_DATA As String = "480v_DATA_POWER"
' The PSU terminal template is read from SH_480V_DATA.
Private Const PSU_TEMPLATE_TERMINAL_COUNT_VFD As Long = 4
Private mVFDPSUTemplate As Object
Private mStep08Running As Boolean
' [LINE EXPLANATION] Defines SH_DATA_IO_LOCAL as a String constant with value "DATA_IO_BLOCK". Edit this line to change sheet data IO local globally.
Private Const SH_DATA_IO_LOCAL As String = "DATA_IO_BLOCK"

' [LINE EXPLANATION] Defines OUT_FIRST_DATA_ROW as a Long constant with value 2. Edit this line to change out first data row globally.
Private Const OUT_FIRST_DATA_ROW As Long = 2
' [LINE EXPLANATION] Defines HEADER_ROW as a Long constant with value 1. Edit this line to change header row globally.
Private Const HEADER_ROW As Long = 1
' [LINE EXPLANATION] Defines MAX_SCAN_COLS as a Long constant with value 80. Edit this line to change maximum scan cols globally.
Private Const MAX_SCAN_COLS As Long = 80

'-------------------------------------------------------------------------------
' Procedure : Step08_Build_480V_VFD_Generator_From_PD6
' Scope/Type: Public Sub
' Purpose   : Builds 480 v VFD generator from pd 6.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Step08_Build_480V_VFD_Generator_From_PD6. Builds 480 v VFD generator from pd 6.
Public Sub Step08_Build_480V_VFD_Generator_From_PD6()

    ' [LINE EXPLANATION] Declares procedure-level storage for wsPD6 (Worksheet).
    Dim wsPD6 As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for wsOut (Worksheet).
    Dim wsOut As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for PD6Hdr (Object).
    Dim PD6Hdr As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for dataMaps (Object).
    Dim dataMaps As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for feederMap (Object).
    Dim feederMap As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for PD6FeederMap (Object).
    Dim PD6FeederMap As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for insideTermMap (Object).
    Dim insideTermMap As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for typeDescMap (Object).
    Dim typeDescMap As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for hasBus2 (Object).
    Dim hasBus2 As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for terminalSeqState (Object).
    Dim terminalSeqState As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for seen (Object).
    Dim seen As Object

    ' [LINE EXPLANATION] Declares procedure-level storage for LastRow (Long).
    Dim lastRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for arr (Variant).
    Dim arr As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for outRow (Long).
    Dim outRow As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for sis (String).
    Dim sis As String
    ' [LINE EXPLANATION] Declares procedure-level storage for typ (String).
    Dim typ As String
    ' [LINE EXPLANATION] Declares procedure-level storage for typDesc (String).
    Dim typDesc As String
    ' [LINE EXPLANATION] Declares procedure-level storage for pwg (String).
    Dim pwg As String
    ' [LINE EXPLANATION] Declares procedure-level storage for busText (String).
    Dim busText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for sysType (String).
    Dim sysType As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorVolt (String).
    Dim motorVolt As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorKW (String).
    Dim motorKW As String
    ' [LINE EXPLANATION] Declares procedure-level storage for panel480V (String).
    Dim panel480V As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowKey (String).
    Dim rowKey As String

    ' [LINE EXPLANATION] Declares procedure-level storage for loadVal (String).
    Dim loadVal As String
    ' [LINE EXPLANATION] Declares procedure-level storage for blockName (String).
    Dim blockName As String
    ' [LINE EXPLANATION] Declares procedure-level storage for tin (String).
    Dim tin As String
    ' [LINE EXPLANATION] Declares procedure-level storage for tout (String).
    Dim tout As String
    ' [LINE EXPLANATION] Declares procedure-level storage for psuBus2 (String).
    Dim psuBus2 As String
    ' [LINE EXPLANATION] Declares procedure-level storage for termBus2 (String).
    Dim termBus2 As String
    ' [LINE EXPLANATION] Declares procedure-level storage for insidePSUTerm (String).
    Dim insidePSUTerm As String
    ' [LINE EXPLANATION] Declares procedure-level storage for netTerminalIn (String).
    Dim netTerminalIn As String
    ' [LINE EXPLANATION] Declares procedure-level storage for netTerminalOut (String).
    Dim netTerminalOut As String
    ' [LINE EXPLANATION] Declares procedure-level storage for blockIO (String).
    Dim blockIO As String
    ' [LINE EXPLANATION] Declares procedure-level storage for bus1In (String).
    Dim bus1In As String
    ' [LINE EXPLANATION] Declares procedure-level storage for bus1Out (String).
    Dim bus1Out As String
    ' [LINE EXPLANATION] Declares procedure-level storage for bus2In (String).
    Dim bus2In As String
    ' [LINE EXPLANATION] Declares procedure-level storage for bus2Out (String).
    Dim bus2Out As String
    ' [LINE EXPLANATION] Declares procedure-level storage for feederInfo (Variant).
    Dim feederInfo As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for termInfo (Variant).
    Dim termInfo As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for termRowsForType (Collection).
    Dim termRowsForType As Collection
    ' [LINE EXPLANATION] Declares procedure-level storage for termEntry (Variant).
    Dim termEntry As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for termIndex (Long).
    Dim termIndex As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for built (Long).
    Dim built As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for skippedBus1 (Long).
    Dim skippedBus1 As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for missingLoad (Long).
    Dim missingLoad As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for missingBlock (Long).
    Dim missingBlock As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for missingFeeder (Long).
    Dim missingFeeder As Long
    Dim duplicateVFD As Long
    Dim errNumber As Long
    Dim errSource As String
    Dim errDescription As String
    Dim generationMode As Long
    Dim existingOutputCount As Long

    ' [LINE EXPLANATION] Routes any runtime error raised after this line to the ErrHandler label.
    On Error GoTo ErrHandler

    If mStep08Running Then
        MsgBox "Step 08 is already running. The duplicate request was ignored.", _
               vbInformation, "480V VFD Generator"
        Exit Sub
    End If
    mStep08Running = True

    ' [LINE EXPLANATION] Calls ResetApplicationState, which resets application state, using the supplied argument values.
    ResetApplicationState False
    Set mVFDPSUTemplate = Nothing

    ' [LINE EXPLANATION] Stores the object returned by EnsureSheet(SH_PD6) in wsPD6.
    Set wsPD6 = EnsureSheet(SH_PD6)
    ' [LINE EXPLANATION] Stores the object returned by EnsureSheet(SH_480V) in wsOut.
    Set wsOut = EnsureSheet(SH_480V)

    If ONGEN_WorksheetHasData(wsOut, HEADER_ROW) Then existingOutputCount = 1
    generationMode = ONGEN_RequestGenerationModeForCount( _
                         "Step 08 - Build 480V VFD Generator", _
                         existingOutputCount, "480V VFD generator worksheet")
    If generationMode = ONGEN_GEN_CANCEL Then GoTo SafeExit

    ' [LINE EXPLANATION] Stores the object returned by VFD_BuildHeaderMap(wsPD6, HEADER_ROW) in PD6Hdr.
    Set PD6Hdr = VFD_BuildHeaderMap(wsPD6, HEADER_ROW)
    ' [LINE EXPLANATION] Stores the object returned by Build480VDataMaps() in dataMaps.
    Set dataMaps = Build480VDataMaps()
    ' [LINE EXPLANATION] Calls UpdatePD6VFDLoadsFrom480V, which updates pd 6 VFD loads from 480 v, using the supplied argument values.
    UpdatePD6VFDLoadsFrom480V wsPD6, PD6Hdr, dataMaps
    ' [LINE EXPLANATION] Stores the object returned by Build24VFeederMap() in feederMap.
    Set feederMap = Build24VFeederMap()
    ' [LINE EXPLANATION] Stores the object returned by BuildInsidePSUTermMap() in insideTermMap.
    Set insideTermMap = BuildInsidePSUTermMap()
    ' [LINE EXPLANATION] Stores the object returned by BuildVFDTypeDescMap() in typeDescMap.
    Set typeDescMap = BuildVFDTypeDescMap()
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in terminalSeqState.
    Set terminalSeqState = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets terminalSeqState.CompareMode to vbTextCompare.
    terminalSeqState.CompareMode = vbTextCompare
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in seen.
    Set seen = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets seen.CompareMode to vbTextCompare.
    seen.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Sets LastRow to VFD_LastUsedRow(wsPD6).
    lastRow = VFD_LastUsedRow(wsPD6)
    ' [LINE EXPLANATION] Sets lastCol to VFD_LastUsedCol(wsPD6).
    lastCol = VFD_LastUsedCol(wsPD6)

    If generationMode = ONGEN_GEN_MISSING_ONLY Then
        VFD_SeedSeenFromExisting wsOut, seen
        If VFD_LastUsedRow(wsOut) < OUT_FIRST_DATA_ROW Then Write480VHeader wsOut
        outRow = VFD_LastUsedRow(wsOut) + 1
        If outRow < OUT_FIRST_DATA_ROW Then outRow = OUT_FIRST_DATA_ROW
    Else
        wsOut.Cells.Clear
        Write480VHeader wsOut
        outRow = OUT_FIRST_DATA_ROW
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when LastRow < 2 Or lastCol = 0 is true.
    If lastRow < 2 Or lastCol = 0 Then
        ' [LINE EXPLANATION] Calls AppendLog, which appends log, using the supplied argument values.
        AppendLog "Step08_Build_480V_VFD_Generator_From_PD6", "OK", "PD6_IMPORT has no data rows."
        ' [LINE EXPLANATION] Displays a message box to the user using "No PD6_IMPORT rows were found for the 480V VFD generator.", vbInformation.
        MsgBox "No PD6_IMPORT rows were found for the 480V VFD generator.", vbInformation
        ' [LINE EXPLANATION] Jumps directly to the SafeExit label in the current procedure.
        GoTo SafeExit
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets arr to wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(LastRow, lastCol)).value.
    arr = wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(lastRow, lastCol)).value
    ' [LINE EXPLANATION] Stores the object returned by BuildVFDHasBus2Map(arr, PD6Hdr, LastRow) in hasBus2.
    Set hasBus2 = BuildVFDHasBus2Map(arr, PD6Hdr, lastRow)
    ' [LINE EXPLANATION] Stores the object returned by BuildPD6Bus2FeederMap(arr, PD6Hdr, LastRow, insideTermMap) in PD6FeederMap.
    Set PD6FeederMap = BuildPD6Bus2FeederMap(arr, PD6Hdr, lastRow, insideTermMap)

    ' [LINE EXPLANATION] Loops r from 2 through LastRow.
    For r = 2 To lastRow

        ' [LINE EXPLANATION] Sets sis to VFD_Pick(arr, r, PD6Hdr, "Control_ID", "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS_sequence"....
        sis = VFD_Pick(arr, r, PD6Hdr, "Control_ID", "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS_sequence", "SIS_SEQUENCE")
        ' [LINE EXPLANATION] Sets typ to VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC").
        typ = VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC")
        ' [LINE EXPLANATION] Sets typDesc to GetVFDTypeDesc(typeDescMap, typ).
        typDesc = GetVFDTypeDesc(typeDescMap, typ)
        ' [LINE EXPLANATION] Sets pwg to VFD_Pick(arr, r, PD6Hdr, "SwitchGroup", "SWITCHGROUP", "PWG").
        pwg = VFD_Pick(arr, r, PD6Hdr, "SwitchGroup", "SWITCHGROUP", "PWG")
        ' [LINE EXPLANATION] Sets busText to NormalizeBusName(VFD_Pick(arr, r, PD6Hdr, "Bus Power", "BUS POWER", "Power Bus")).
        busText = NormalizeBusName(VFD_Pick(arr, r, PD6Hdr, "Bus Power", "BUS POWER", "Power Bus"))
        ' [LINE EXPLANATION] Sets sysType to VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type").
        sysType = VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type")
        ' [LINE EXPLANATION] Sets motorVolt to VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE").
        motorVolt = VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE")
        ' [LINE EXPLANATION] Sets motorKW to VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE").
        motorKW = VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE")
        ' [LINE EXPLANATION] Sets panel480V to VFD_Pick(arr, r, PD6Hdr, "PNL", "Panel", "PANEL", "480V Panel").
        panel480V = VFD_Pick(arr, r, PD6Hdr, "PNL", "Panel", "PANEL", "480V Panel")

        ' [LINE EXPLANATION] When Not IsVFDPowerRow(typ, sysType, motorVolt, motorKW) is true, executes the inline action GoTo nextRow.
        If Not IsVFDPowerRow(typ, sysType, motorVolt, motorKW) Then GoTo nextRow
        ' [LINE EXPLANATION] When Len(sis) = 0 is true, executes the inline action GoTo nextRow.
        If Len(sis) = 0 Then GoTo nextRow

        ' [LINE EXPLANATION] Sets rowKey to VFD_RowIdentityKey(sis, typ, motorKW).
        rowKey = VFD_DeviceIdentityKey(sis)

        'When Step05 split VFD into BUS-1 and BUS-2 rows, only BUS-2 should feed
        'this 480V generator because BUS-2 is the 24V PSU feeder for VFD controls.
        ' [LINE EXPLANATION] Starts a conditional block that runs when busText = "BUS-1" And hasBus2.Exists(rowKey) is true.
        If busText = "BUS-1" And hasBus2.Exists(rowKey) Then
            ' [LINE EXPLANATION] Sets skippedBus1 to skippedBus1 + 1.
            skippedBus1 = skippedBus1 + 1
            ' [LINE EXPLANATION] Jumps directly to the nextRow label in the current procedure.
            GoTo nextRow
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If

        ' One physical VFD may appear more than once in PD6 because of BUS rows,
        ' legacy Control_ID/SIS variations, or previous imports. Keep one row only.
        If seen.Exists(rowKey) Then
            duplicateVFD = duplicateVFD + 1
            GoTo nextRow
        End If
        seen.Add rowKey, True

        'Authoritative VFD load source: 480v_DATA_POWER[KW] -> [MOVIFLEX].
        ' [LINE EXPLANATION] Sets loadVal to Get480VLoadByKW(dataMaps, motorKW).
        loadVal = Get480VLoadByKW(dataMaps, motorKW)

        ' [LINE EXPLANATION] Stores the object returned by Get480VDeviceTermRows(dataMaps, typ) in termRowsForType.
        Set termRowsForType = Get480VDeviceTermRows(dataMaps, typ)

        ' [LINE EXPLANATION] When Len(loadVal) = 0 is true, executes the inline action missingLoad = missingLoad + 1.
        If Len(loadVal) = 0 Then missingLoad = missingLoad + 1

        ' [LINE EXPLANATION] Sets psuBus2 to "".
        psuBus2 = ""
        ' [LINE EXPLANATION] Sets termBus2 to "".
        termBus2 = ""
        ' [LINE EXPLANATION] Sets insidePSUTerm to "".
        insidePSUTerm = ""

        ' [LINE EXPLANATION] Sets feederInfo to Get24VFeederInfo(feederMap, sis, typ).
        feederInfo = Get24VFeederInfo(feederMap, sis, typ)
        ' [LINE EXPLANATION] Starts a conditional block that runs when IsArray(feederInfo) is true.
        If IsArray(feederInfo) Then
            ' [LINE EXPLANATION] Sets psuBus2 to Trim$(CStr(feederInfo(0))).
            psuBus2 = Trim$(CStr(feederInfo(0)))
            ' [LINE EXPLANATION] Sets termBus2 to Trim$(CStr(feederInfo(1))).
            termBus2 = Trim$(CStr(feederInfo(1)))
            ' [LINE EXPLANATION] Sets insidePSUTerm to Trim$(CStr(feederInfo(2))).
            insidePSUTerm = Trim$(CStr(feederInfo(2)))
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If

        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(psuBus2) = 0 Or Len(termBus2) = 0 Or Len(insidePSUTerm) = 0 is true.
        If Len(psuBus2) = 0 Or Len(termBus2) = 0 Or Len(insidePSUTerm) = 0 Then
            ' [LINE EXPLANATION] Sets feederInfo to GetPD6Bus2FeederInfo(PD6FeederMap, rowKey).
            feederInfo = GetPD6Bus2FeederInfo(PD6FeederMap, rowKey)
            ' [LINE EXPLANATION] Starts a conditional block that runs when IsArray(feederInfo) is true.
            If IsArray(feederInfo) Then
                ' [LINE EXPLANATION] When Len(psuBus2) = 0 is true, executes the inline action psuBus2 = Trim$(CStr(feederInfo(0))).
                If Len(psuBus2) = 0 Then psuBus2 = Trim$(CStr(feederInfo(0)))
                ' [LINE EXPLANATION] When Len(termBus2) = 0 is true, executes the inline action termBus2 = Trim$(CStr(feederInfo(1))).
                If Len(termBus2) = 0 Then termBus2 = Trim$(CStr(feederInfo(1)))
                ' [LINE EXPLANATION] When Len(insidePSUTerm) = 0 is true, executes the inline action insidePSUTerm = Trim$(CStr(feederInfo(2))).
                If Len(insidePSUTerm) = 0 Then insidePSUTerm = Trim$(CStr(feederInfo(2)))
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If

        ' [LINE EXPLANATION] When Len(psuBus2) = 0 is true, executes the inline action psuBus2 = VFD_Pick(arr, r, PD6Hdr, "Power Supply", "POWER SUPP....
        If Len(psuBus2) = 0 Then psuBus2 = VFD_Pick(arr, r, PD6Hdr, "Power Supply", "POWER SUPPLY", "PSU")
        ' [LINE EXPLANATION] When Len(termBus2) = 0 is true, executes the inline action termBus2 = VFD_Pick(arr, r, PD6Hdr, "Power BUS-2 Terminal", "B....
        If Len(termBus2) = 0 Then termBus2 = VFD_Pick(arr, r, PD6Hdr, "Power BUS-2 Terminal", "BUS-2 Terminal", "Power Bus-2 Terminal", "PWR TERM")
        ' [LINE EXPLANATION] When Len(insidePSUTerm) = 0 is true, executes the inline action insidePSUTerm = GetInsidePSUTerm(insideTermMap, termBus2).
        If Len(insidePSUTerm) = 0 Then insidePSUTerm = GetInsidePSUTerm(insideTermMap, termBus2)

        ' Always publish the physical terminal and description from 480v_DATA_POWER.
        If Len(Trim$(termBus2)) > 0 And UCase$(Trim$(termBus2)) <> "MISSING" Then
            termBus2 = VFD_GetPhysicalPSUTerminal(termBus2)
            insidePSUTerm = VFD_GetPSUDescription(termBus2)
        End If

        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(psuBus2) = 0 is true.
        If Len(psuBus2) = 0 Then
            ' [LINE EXPLANATION] When Len(pwg) > 0 is true, executes the inline action psuBus2 = pwg & "-PSU".
            If Len(pwg) > 0 Then psuBus2 = pwg & "-PSU"
            ' [LINE EXPLANATION] Sets missingFeeder to missingFeeder + 1.
            missingFeeder = missingFeeder + 1
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If

        ' VFD_480V_Generator is a device source table, not a terminal-detail table.
        ' Merge all available terminal-template fields into one output row per VFD.
        If termRowsForType Is Nothing Then Set termRowsForType = New Collection
        termEntry = VFD_MergeTermRows(termRowsForType, _
                                      Get480VDeviceValue(dataMaps, typ, "BLOCK", ""), _
                                      Get480VDeviceValue(dataMaps, typ, "TIN", ""), _
                                      Get480VDeviceValue(dataMaps, typ, "TOUT", ""))

        blockName = VFD_EntryText(termEntry, 0)
        tin = VFD_EntryText(termEntry, 1)
        tout = VFD_EntryText(termEntry, 2)
        netTerminalIn = VFD_EntryText(termEntry, 3)
        netTerminalOut = VFD_EntryText(termEntry, 4)
        blockIO = VFD_EntryText(termEntry, 5)
        bus1In = VFD_EntryText(termEntry, 6)
        bus1Out = VFD_EntryText(termEntry, 7)
        bus2In = VFD_EntryText(termEntry, 8)
        bus2Out = VFD_EntryText(termEntry, 9)

        If Len(blockName) = 0 Or Len(tin) = 0 Or Len(tout) = 0 Then missingBlock = missingBlock + 1

        wsOut.Cells(outRow, 1).value = sis
        wsOut.Cells(outRow, 2).value = typDesc
        wsOut.Cells(outRow, 3).value = panel480V
        wsOut.Cells(outRow, 4).value = loadVal
        wsOut.Cells(outRow, 5).value = blockName
        wsOut.Cells(outRow, 6).value = tin
        wsOut.Cells(outRow, 7).value = tout
        wsOut.Cells(outRow, 8).value = psuBus2
        wsOut.Cells(outRow, 9).value = termBus2
        wsOut.Cells(outRow, 10).value = insidePSUTerm
        wsOut.Cells(outRow, 11).value = netTerminalIn
        wsOut.Cells(outRow, 12).value = netTerminalOut
        wsOut.Cells(outRow, 13).value = blockIO
        wsOut.Cells(outRow, 14).value = bus1In
        wsOut.Cells(outRow, 15).value = bus1Out
        wsOut.Cells(outRow, 16).value = bus2In
        wsOut.Cells(outRow, 17).value = bus2Out

        outRow = outRow + 1
        built = built + 1

' [LINE EXPLANATION] Defines the nextRow jump label used by GoTo statements in this procedure.
nextRow:
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

    ' [LINE EXPLANATION] Calls the Columns member of wsOut with ("A:Q").AutoFit.
    wsOut.Columns("A:Q").AutoFit

    ' [LINE EXPLANATION] Calls AppendLog, which appends log, using the supplied argument values. This logical statement spans 6 physical lines.
    AppendLog "Step08_Build_480V_VFD_Generator_From_PD6", "OK", _
        CStr(built) & " unique VFD device row(s) built. " & _
        CStr(duplicateVFD) & " duplicate PD6 VFD row(s) ignored. " & _
        CStr(skippedBus1) & " BUS-1 duplicate rows skipped. " & _
        CStr(missingLoad) & " rows missing KW/MOVIFLEX load lookup. " & _
        CStr(missingBlock) & " rows missing 480v_DATA_POWER block/terminal lookup. " & _
        CStr(missingFeeder) & " rows missing BUS-2 feeder lookup."

    ' [LINE EXPLANATION] Displays a message box to the user using "480V VFD generator built with " & CStr(built) & " row(s)." & vbCrLf & "Load = 480v_DATA_POWER[MOVIFLEX] matched by Motor Power.... This logical statement spans...
    MsgBox "480V VFD generator built with " & CStr(built) & " unique VFD device row(s)." & vbCrLf & _
           CStr(duplicateVFD) & " duplicate PD6 VFD row(s) were ignored." & vbCrLf & _
           "Load = 480v_DATA_POWER[MOVIFLEX] matched by Motor Power (Main Drive) to KW." & vbCrLf & _
           "Power BUS-2 / Terminal / Inside PSU TERM = 24V BUS-2 feeder assignment.", vbInformation

' [LINE EXPLANATION] Defines the SafeExit cleanup/exit entry point so normal and error paths can restore Excel safely.
SafeExit:
    ONGEN_ClearGenerationMode
    mStep08Running = False
    ' [LINE EXPLANATION] Calls ResetApplicationState, which resets application state, using the supplied argument values.
    ResetApplicationState True
    ' [LINE EXPLANATION] Ends Step08_Build_480V_VFD_Generator_From_PD6 immediately without running the remaining statements.
    Exit Sub

' [LINE EXPLANATION] Defines the ErrHandler error-handling entry point used by On Error or GoTo statements.
ErrHandler:
    mStep08Running = False
    errNumber = Err.Number
    errSource = Err.source
    errDescription = Err.description
    If Len(Trim$(errDescription)) = 0 Then errDescription = "Unspecified VBA runtime error."
    On Error Resume Next
    ResetApplicationState True
    AppendLog "Step08_Build_480V_VFD_Generator_From_PD6", "ERROR", _
              "Number=" & CStr(errNumber) & "; Source=" & errSource & "; Description=" & errDescription
    On Error GoTo 0
    MsgBox "480V VFD build failed." & vbCrLf & _
           "Error " & CStr(errNumber) & ": " & errDescription, _
           vbCritical, "480V VFD Generator"

' [LINE EXPLANATION] Ends procedure Step08_Build_480V_VFD_Generator_From_PD6.
End Sub


Private Sub VFD_SeedSeenFromExisting(ByVal ws As Worksheet, ByVal seen As Object)
    Dim lastExistingRow As Long
    Dim r As Long
    Dim sis As String
    Dim keyText As String

    If ws Is Nothing Then Exit Sub
    If seen Is Nothing Then Exit Sub

    lastExistingRow = VFD_LastUsedRow(ws)
    For r = OUT_FIRST_DATA_ROW To lastExistingRow
        sis = Trim$(CStr(ws.Cells(r, 1).Value2))
        If Len(sis) > 0 Then
            keyText = VFD_DeviceIdentityKey(sis)
            If Len(keyText) > 0 Then
                If Not seen.Exists(keyText) Then seen.Add keyText, True
            End If
        End If
    Next r
End Sub

'-------------------------------------------------------------------------------
' Procedure : Write480VHeader
' Scope/Type: Private Sub
' Purpose   : Writes 480 v header.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Write480VHeader. Writes 480 v header.
Private Sub Write480VHeader(ByVal ws As Worksheet)

    ' [LINE EXPLANATION] Writes Array("SIS_ELEMENT_NUMBER", "TYPE", "480V Panel", "Load", "Block", "Terminal (IN)", "Termina... into ws.Range("A1:Q1").value.
    ws.Range("A1:Q1").value = Array("SIS_ELEMENT_NUMBER", "TYPE", "480V Panel", "Load", "Block", "Terminal (IN)", "Terminal (OUT)", "Power BUS-2", "Terminal", "Inside PSU TERM", "NET TERMINAL (IN)", "NET TERMINAL (OUT)", "Block IO", "BUS-1-IN", "BUS-1-OUT", "BUS-2-IN", "BUS-2-OUT")

    ' [LINE EXPLANATION] Calls StyleHeader, which performs the style header workflow, using the supplied argument values.
    StyleHeader ws.Range("A1:Q1")

    ' [LINE EXPLANATION] When ws.AutoFilterMode is true, executes the inline action ws.AutoFilterMode = False.
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ' [LINE EXPLANATION] Calls the Range member of ws with ("A1:Q1").AutoFilter.
    ws.Range("A1:Q1").AutoFilter

' [LINE EXPLANATION] Ends procedure Write480VHeader.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Build480VDataMaps
' Scope/Type: Private Function
' Purpose   : Builds 480 v data maps.
' Parameters: None.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Build480VDataMaps. Builds 480 v data maps.
Private Function Build480VDataMaps() As Object

    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for maps (Object).
    Dim maps As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for kwLoad (Object).
    Dim kwLoad As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for devBlock (Object).
    Dim devBlock As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for devTin (Object).
    Dim devTin As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for devTout (Object).
    Dim devTout As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for termRows (Object).
    Dim termRows As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for hdr (Object).
    Dim hdr As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for arr (Variant).
    Dim arr As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for LastRow (Long).
    Dim lastRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cKW (Long).
    Dim cKW As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cMoviflex (Long).
    Dim cMoviflex As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cDev (Long).
    Dim cDev As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cBlock (Long).
    Dim cBlock As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cTin (Long).
    Dim cTin As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cTout (Long).
    Dim cTout As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cNetIn (Long).
    Dim cNetIn As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cNetOut (Long).
    Dim cNetOut As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cBlockIO (Long).
    Dim cBlockIO As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cBus1In (Long).
    Dim cBus1In As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cBus1Out (Long).
    Dim cBus1Out As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cBus2In (Long).
    Dim cBus2In As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cBus2Out (Long).
    Dim cBus2Out As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for keyText (String).
    Dim keyText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for devText (String).
    Dim devText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for currentDevKey (String).
    Dim currentDevKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for newDevKey (String).
    Dim newDevKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for currentBlock (String).
    Dim currentBlock As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rawBlock (String).
    Dim rawBlock As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowBlock (String).
    Dim rowBlock As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowTin (String).
    Dim rowTin As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowTout (String).
    Dim rowTout As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowNetIn (String).
    Dim rowNetIn As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowNetOut (String).
    Dim rowNetOut As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowBlockIO (String).
    Dim rowBlockIO As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowBus1In (String).
    Dim rowBus1In As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowBus1Out (String).
    Dim rowBus1Out As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowBus2In (String).
    Dim rowBus2In As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowBus2Out (String).
    Dim rowBus2Out As String
    ' [LINE EXPLANATION] Declares procedure-level storage for col (Collection).
    Dim col As Collection
    ' [LINE EXPLANATION] Declares procedure-level storage for entry (Variant).
    Dim entry As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for entryKey (String).
    Dim entryKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for termEntrySeen (Object).
    Dim termEntrySeen As Object

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in maps.
    Set maps = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in kwLoad.
    Set kwLoad = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in devBlock.
    Set devBlock = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in devTin.
    Set devTin = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in devTout.
    Set devTout = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in termRows.
    Set termRows = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in termEntrySeen.
    Set termEntrySeen = CreateObject("Scripting.Dictionary")

    ' [LINE EXPLANATION] Sets kwLoad.CompareMode to vbTextCompare.
    kwLoad.CompareMode = vbTextCompare
    ' [LINE EXPLANATION] Sets devBlock.CompareMode to vbTextCompare.
    devBlock.CompareMode = vbTextCompare
    ' [LINE EXPLANATION] Sets devTin.CompareMode to vbTextCompare.
    devTin.CompareMode = vbTextCompare
    ' [LINE EXPLANATION] Sets devTout.CompareMode to vbTextCompare.
    devTout.CompareMode = vbTextCompare
    ' [LINE EXPLANATION] Sets termRows.CompareMode to vbTextCompare.
    termRows.CompareMode = vbTextCompare
    ' [LINE EXPLANATION] Sets termEntrySeen.CompareMode to vbTextCompare.
    termEntrySeen.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Adds an item to maps using "KWLOAD", kwLoad.
    maps.Add "KWLOAD", kwLoad
    ' [LINE EXPLANATION] Adds an item to maps using "BLOCK", devBlock.
    maps.Add "BLOCK", devBlock
    ' [LINE EXPLANATION] Adds an item to maps using "TIN", devTin.
    maps.Add "TIN", devTin
    ' [LINE EXPLANATION] Adds an item to maps using "TOUT", devTout.
    maps.Add "TOUT", devTout
    ' [LINE EXPLANATION] Adds an item to maps using "TERMROWS", termRows.
    maps.Add "TERMROWS", termRows

    ' [LINE EXPLANATION] Stores the object returned by VFD_GetSheetIfExists(SH_480V_DATA) in ws.
    Set ws = VFD_GetSheetIfExists(SH_480V_DATA)
    ' [LINE EXPLANATION] Starts a conditional block that runs when ws Is Nothing is true.
    If ws Is Nothing Then
        ' [LINE EXPLANATION] Calls AppendLog, which appends log, using the supplied argument values.
        AppendLog "Build480VDataMaps", "WARNING", SH_480V_DATA & " sheet not found."
        ' [LINE EXPLANATION] Stores the object returned by maps in Build480VDataMaps.
        Set Build480VDataMaps = maps
        ' [LINE EXPLANATION] Returns immediately from Build480VDataMaps using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Stores the object returned by VFD_BuildHeaderMap(ws, HEADER_ROW) in hdr.
    Set hdr = VFD_BuildHeaderMap(ws, HEADER_ROW)
    ' [LINE EXPLANATION] Sets cKW to VFD_HeaderCol(hdr, "KW", "Motor Power (Main Drive)", "Motor Power").
    cKW = VFD_HeaderCol(hdr, "KW", "Motor Power (Main Drive)", "Motor Power")
    ' [LINE EXPLANATION] Sets cMoviflex to VFD_HeaderCol(hdr, "MOVIFLEX", "MOVI-FLEX", "Load", "LOAD").
    cMoviflex = VFD_HeaderCol(hdr, "MOVIFLEX", "MOVI-FLEX", "Load", "LOAD")
    ' [LINE EXPLANATION] Sets cDev to VFD_HeaderCol(hdr, "Device Type", "TYPE", "TYPE/DESC").
    cDev = VFD_HeaderCol(hdr, "Device Type", "TYPE", "TYPE/DESC")
    ' [LINE EXPLANATION] Sets cBlock to VFD_HeaderCol(hdr, "Block", "BLOCK").
    cBlock = VFD_HeaderCol(hdr, "Block", "BLOCK")
    ' [LINE EXPLANATION] Sets cTin to VFD_HeaderCol(hdr, "Terminal (IN)", "Terminal IN", "TERM IN", "TIN").
    cTin = VFD_HeaderCol(hdr, "Terminal (IN)", "Terminal IN", "TERM IN", "TIN")
    ' [LINE EXPLANATION] Sets cTout to VFD_HeaderCol(hdr, "Terminal (OUT)", "Terminal OUT", "TERM OUT", "TOUT").
    cTout = VFD_HeaderCol(hdr, "Terminal (OUT)", "Terminal OUT", "TERM OUT", "TOUT")
    ' [LINE EXPLANATION] Sets cNetIn to VFD_HeaderCol(hdr, "NET TERMINAL (IN)", "NET TERMINAL IN").
    cNetIn = VFD_HeaderCol(hdr, "NET TERMINAL (IN)", "NET TERMINAL IN")
    ' [LINE EXPLANATION] Sets cNetOut to VFD_HeaderCol(hdr, "NET TERMINAL (OUT)", "NET TERMINAL OUT").
    cNetOut = VFD_HeaderCol(hdr, "NET TERMINAL (OUT)", "NET TERMINAL OUT")
    ' [LINE EXPLANATION] Sets cBlockIO to VFD_HeaderCol(hdr, "Block IO", "BLOCK_IO", "IO BLOCK").
    cBlockIO = VFD_HeaderCol(hdr, "Block IO", "BLOCK_IO", "IO BLOCK")
    ' [LINE EXPLANATION] Sets cBus1In to VFD_HeaderCol(hdr, "BUS-1-IN", "BUS 1 IN").
    cBus1In = VFD_HeaderCol(hdr, "BUS-1-IN", "BUS 1 IN")
    ' [LINE EXPLANATION] Sets cBus1Out to VFD_HeaderCol(hdr, "BUS-1-OUT", "BUS 1 OUT").
    cBus1Out = VFD_HeaderCol(hdr, "BUS-1-OUT", "BUS 1 OUT")
    ' [LINE EXPLANATION] Sets cBus2In to VFD_HeaderCol(hdr, "BUS-2-IN", "BUS 2 IN").
    cBus2In = VFD_HeaderCol(hdr, "BUS-2-IN", "BUS 2 IN")
    ' [LINE EXPLANATION] Sets cBus2Out to VFD_HeaderCol(hdr, "BUS-2-OUT", "BUS 2 OUT").
    cBus2Out = VFD_HeaderCol(hdr, "BUS-2-OUT", "BUS 2 OUT")

    ' [LINE EXPLANATION] Sets LastRow to VFD_LastUsedRow(ws).
    lastRow = VFD_LastUsedRow(ws)
    ' [LINE EXPLANATION] Sets lastCol to VFD_LastUsedCol(ws).
    lastCol = VFD_LastUsedCol(ws)
    ' [LINE EXPLANATION] Starts a conditional block that runs when LastRow < 2 Or lastCol = 0 is true.
    If lastRow < 2 Or lastCol = 0 Then
        ' [LINE EXPLANATION] Stores the object returned by maps in Build480VDataMaps.
        Set Build480VDataMaps = maps
        ' [LINE EXPLANATION] Returns immediately from Build480VDataMaps using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets arr to ws.Range(ws.Cells(1, 1), ws.Cells(LastRow, lastCol)).value.
    arr = ws.Range(ws.Cells(1, 1), ws.Cells(lastRow, lastCol)).value

    ' [LINE EXPLANATION] Starts a conditional block that runs when cKW > 0 And cMoviflex > 0 is true.
    If cKW > 0 And cMoviflex > 0 Then
        ' [LINE EXPLANATION] Loops r from 2 through LastRow.
        For r = 2 To lastRow
            ' [LINE EXPLANATION] Sets keyText to KWKey(VFD_ArrayValue(arr, r, cKW)).
            keyText = KWKey(VFD_ArrayValue(arr, r, cKW))
            ' [LINE EXPLANATION] When Len(keyText) > 0 is true, executes the inline action kwLoad(keyText) = Trim$(CStr(VFD_ArrayValue(arr, r, cMoviflex))).
            If Len(keyText) > 0 Then kwLoad(keyText) = Trim$(CStr(VFD_ArrayValue(arr, r, cMoviflex)))
        ' [LINE EXPLANATION] Advances the r loop to its next iteration.
        Next r
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Calls AppendLog, which appends log, using the supplied argument values.
        AppendLog "Build480VDataMaps", "WARNING", SH_480V_DATA & " missing KW or MOVIFLEX header."
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when cDev > 0 is true.
    If cDev > 0 Then
        ' [LINE EXPLANATION] Sets currentDevKey to "".
        currentDevKey = ""
        ' [LINE EXPLANATION] Sets currentBlock to "".
        currentBlock = ""

        ' [LINE EXPLANATION] Loops r from 2 through LastRow.
        For r = 2 To lastRow
            ' [LINE EXPLANATION] Sets devText to Trim$(CStr(VFD_ArrayValue(arr, r, cDev))).
            devText = Trim$(CStr(VFD_ArrayValue(arr, r, cDev)))
            ' [LINE EXPLANATION] Starts a conditional block that runs when Len(devText) > 0 is true.
            If Len(devText) > 0 Then
                ' [LINE EXPLANATION] Sets newDevKey to DeviceTypeKey(devText).
                newDevKey = DeviceTypeKey(devText)
                ' [LINE EXPLANATION] When newDevKey <> currentDevKey is true, executes the inline action currentBlock = "".
                If newDevKey <> currentDevKey Then currentBlock = ""
                ' [LINE EXPLANATION] Sets currentDevKey to newDevKey.
                currentDevKey = newDevKey
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If

            ' [LINE EXPLANATION] Sets rawBlock to "".
            rawBlock = ""
            ' [LINE EXPLANATION] Sets rowBlock to "".
            rowBlock = ""
            ' [LINE EXPLANATION] Sets rowTin to "".
            rowTin = ""
            ' [LINE EXPLANATION] Sets rowTout to "".
            rowTout = ""
            ' [LINE EXPLANATION] Sets rowNetIn to "".
            rowNetIn = ""
            ' [LINE EXPLANATION] Sets rowNetOut to "".
            rowNetOut = ""
            ' [LINE EXPLANATION] Sets rowBlockIO to "".
            rowBlockIO = ""
            ' [LINE EXPLANATION] Sets rowBus1In to "".
            rowBus1In = ""
            ' [LINE EXPLANATION] Sets rowBus1Out to "".
            rowBus1Out = ""
            ' [LINE EXPLANATION] Sets rowBus2In to "".
            rowBus2In = ""
            ' [LINE EXPLANATION] Sets rowBus2Out to "".
            rowBus2Out = ""

            ' [LINE EXPLANATION] When cBlock > 0 is true, executes the inline action rawBlock = Trim$(CStr(VFD_ArrayValue(arr, r, cBlock))).
            If cBlock > 0 Then rawBlock = Trim$(CStr(VFD_ArrayValue(arr, r, cBlock)))
            ' [LINE EXPLANATION] Sets rowBlock to rawBlock.
            rowBlock = rawBlock
            ' [LINE EXPLANATION] When Len(rawBlock) > 0 is true, executes the inline action currentBlock = rawBlock.
            If Len(rawBlock) > 0 Then currentBlock = rawBlock
            ' [LINE EXPLANATION] When Len(rowBlock) = 0 is true, executes the inline action rowBlock = currentBlock.
            If Len(rowBlock) = 0 Then rowBlock = currentBlock

            ' [LINE EXPLANATION] When cTin > 0 is true, executes the inline action rowTin = Trim$(CStr(VFD_ArrayValue(arr, r, cTin))).
            If cTin > 0 Then rowTin = Trim$(CStr(VFD_ArrayValue(arr, r, cTin)))
            ' [LINE EXPLANATION] When cTout > 0 is true, executes the inline action rowTout = Trim$(CStr(VFD_ArrayValue(arr, r, cTout))).
            If cTout > 0 Then rowTout = Trim$(CStr(VFD_ArrayValue(arr, r, cTout)))
            ' [LINE EXPLANATION] When cNetIn > 0 is true, executes the inline action rowNetIn = Trim$(CStr(VFD_ArrayValue(arr, r, cNetIn))).
            If cNetIn > 0 Then rowNetIn = Trim$(CStr(VFD_ArrayValue(arr, r, cNetIn)))
            ' [LINE EXPLANATION] When cNetOut > 0 is true, executes the inline action rowNetOut = Trim$(CStr(VFD_ArrayValue(arr, r, cNetOut))).
            If cNetOut > 0 Then rowNetOut = Trim$(CStr(VFD_ArrayValue(arr, r, cNetOut)))
            ' [LINE EXPLANATION] When cBlockIO > 0 is true, executes the inline action rowBlockIO = Trim$(CStr(VFD_ArrayValue(arr, r, cBlockIO))).
            If cBlockIO > 0 Then rowBlockIO = Trim$(CStr(VFD_ArrayValue(arr, r, cBlockIO)))
            ' [LINE EXPLANATION] When cBus1In > 0 is true, executes the inline action rowBus1In = Trim$(CStr(VFD_ArrayValue(arr, r, cBus1In))).
            If cBus1In > 0 Then rowBus1In = Trim$(CStr(VFD_ArrayValue(arr, r, cBus1In)))
            ' [LINE EXPLANATION] When cBus1Out > 0 is true, executes the inline action rowBus1Out = Trim$(CStr(VFD_ArrayValue(arr, r, cBus1Out))).
            If cBus1Out > 0 Then rowBus1Out = Trim$(CStr(VFD_ArrayValue(arr, r, cBus1Out)))
            ' [LINE EXPLANATION] When cBus2In > 0 is true, executes the inline action rowBus2In = Trim$(CStr(VFD_ArrayValue(arr, r, cBus2In))).
            If cBus2In > 0 Then rowBus2In = Trim$(CStr(VFD_ArrayValue(arr, r, cBus2In)))
            ' [LINE EXPLANATION] When cBus2Out > 0 is true, executes the inline action rowBus2Out = Trim$(CStr(VFD_ArrayValue(arr, r, cBus2Out))).
            If cBus2Out > 0 Then rowBus2Out = Trim$(CStr(VFD_ArrayValue(arr, r, cBus2Out)))

            ' [LINE EXPLANATION] Starts a conditional block that runs when Len(currentDevKey) > 0 is true.
            If Len(currentDevKey) > 0 Then
                'Do not create a terminal record merely because Block was inherited.
                'A source row must contain an explicit Block or at least one terminal value.
                ' [LINE EXPLANATION] Starts a conditional block that runs when Len(rawBlock) > 0 Or Len(rowTin) > 0 Or Len(rowTout) > 0 Or Len(rowNetIn) > 0 Or Len(rowNetOut) > 0 Or Len(rowBlockIO... is true. This logical statement spans 3...
                If Len(rawBlock) > 0 Or Len(rowTin) > 0 Or Len(rowTout) > 0 Or _
                   Len(rowNetIn) > 0 Or Len(rowNetOut) > 0 Or Len(rowBlockIO) > 0 Or _
                   Len(rowBus1In) > 0 Or Len(rowBus1Out) > 0 Or Len(rowBus2In) > 0 Or Len(rowBus2Out) > 0 Then

                    ' [LINE EXPLANATION] Sets entryKey to currentDevKey & "|" & UCase$(rowBlock) & "|" & UCase$(rowTin) & "|" & UCase$(rowTout) & "|" & UCa.... This logical statement spans 4 physical lines.
                    entryKey = currentDevKey & "|" & UCase$(rowBlock) & "|" & UCase$(rowTin) & "|" & _
                               UCase$(rowTout) & "|" & UCase$(rowNetIn) & "|" & UCase$(rowNetOut) & "|" & _
                               UCase$(rowBlockIO) & "|" & UCase$(rowBus1In) & "|" & UCase$(rowBus1Out) & "|" & _
                               UCase$(rowBus2In) & "|" & UCase$(rowBus2Out)

                    ' [LINE EXPLANATION] Starts a conditional block that runs when Not termEntrySeen.Exists(entryKey) is true.
                    If Not termEntrySeen.Exists(entryKey) Then
                        ' [LINE EXPLANATION] Adds an item to termEntrySeen using entryKey, True.
                        termEntrySeen.Add entryKey, True

                        ' [LINE EXPLANATION] Starts a conditional block that runs when Not termRows.Exists(currentDevKey) is true.
                        If Not termRows.Exists(currentDevKey) Then
                            ' [LINE EXPLANATION] Stores the object returned by New Collection in col.
                            Set col = New Collection
                            ' [LINE EXPLANATION] Adds an item to termRows using currentDevKey, col.
                            termRows.Add currentDevKey, col
                        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
                        Else
                            ' [LINE EXPLANATION] Stores the object returned by termRows(currentDevKey) in col.
                            Set col = termRows(currentDevKey)
                        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                        End If

                        ' [LINE EXPLANATION] Sets entry to Array(rowBlock, rowTin, rowTout, rowNetIn, rowNetOut, rowBlockIO, rowBus1In, rowBus1Out, rowBus2I....
                        entry = Array(rowBlock, rowTin, rowTout, rowNetIn, rowNetOut, rowBlockIO, rowBus1In, rowBus1Out, rowBus2In, rowBus2Out)
                        ' [LINE EXPLANATION] Adds an item to col using entry.
                        col.Add entry

                        ' [LINE EXPLANATION] When Not devBlock.Exists(currentDevKey) And Len(rowBlock) > 0 is true, executes the inline action devBlock.Add currentDevKey, rowBlock.
                        If Not devBlock.Exists(currentDevKey) And Len(rowBlock) > 0 Then devBlock.Add currentDevKey, rowBlock
                        ' [LINE EXPLANATION] When Not devTin.Exists(currentDevKey) And Len(rowTin) > 0 is true, executes the inline action devTin.Add currentDevKey, rowTin.
                        If Not devTin.Exists(currentDevKey) And Len(rowTin) > 0 Then devTin.Add currentDevKey, rowTin
                        ' [LINE EXPLANATION] When Not devTout.Exists(currentDevKey) And Len(rowTout) > 0 is true, executes the inline action devTout.Add currentDevKey, rowTout.
                        If Not devTout.Exists(currentDevKey) And Len(rowTout) > 0 Then devTout.Add currentDevKey, rowTout
                    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                    End If
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Advances the r loop to its next iteration.
        Next r
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Calls AppendLog, which appends log, using the supplied argument values.
        AppendLog "Build480VDataMaps", "WARNING", SH_480V_DATA & " missing Device Type header."
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Stores the object returned by maps in Build480VDataMaps.
    Set Build480VDataMaps = maps

' [LINE EXPLANATION] Ends function Build480VDataMaps.
End Function

'-------------------------------------------------------------------------------
' Procedure : BuildVFDTypeDescMap
' Scope/Type: Private Function
' Purpose   : Builds VFD type desc map.
' Parameters: None.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function BuildVFDTypeDescMap. Builds VFD type desc map.
Private Function BuildVFDTypeDescMap() As Object

    'Reads DATA_IO_BLOCK[TYPE] -> DATA_IO_BLOCK[DESC] for friendly output text.
    'PD6_IMPORT[TYPE] is still used for all 480V logic and DATA lookups.

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for hdr (Object).
    Dim hdr As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for arr (Variant).
    Dim arr As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for LastRow (Long).
    Dim lastRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cType (Long).
    Dim cType As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cDesc (Long).
    Dim cDesc As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String
    ' [LINE EXPLANATION] Declares procedure-level storage for v (String).
    Dim v As String

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in d.
    Set d = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets d.CompareMode to vbTextCompare.
    d.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Stores the object returned by VFD_GetSheetIfExists(SH_DATA_IO_LOCAL) in ws.
    Set ws = VFD_GetSheetIfExists(SH_DATA_IO_LOCAL)
    ' [LINE EXPLANATION] Starts a conditional block that runs when ws Is Nothing is true.
    If ws Is Nothing Then
        ' [LINE EXPLANATION] Stores the object returned by d in BuildVFDTypeDescMap.
        Set BuildVFDTypeDescMap = d
        ' [LINE EXPLANATION] Returns immediately from BuildVFDTypeDescMap using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Stores the object returned by VFD_BuildHeaderMap(ws, HEADER_ROW) in hdr.
    Set hdr = VFD_BuildHeaderMap(ws, HEADER_ROW)
    ' [LINE EXPLANATION] Sets cType to VFD_HeaderCol(hdr, "TYPE", "Device Type", "TYPE/DESC").
    cType = VFD_HeaderCol(hdr, "TYPE", "Device Type", "TYPE/DESC")
    ' [LINE EXPLANATION] Sets cDesc to VFD_HeaderCol(hdr, "DESC", "Description", "TYPE DESC", "TYPE_DESCRIPTION").
    cDesc = VFD_HeaderCol(hdr, "DESC", "Description", "TYPE DESC", "TYPE_DESCRIPTION")

    ' [LINE EXPLANATION] Starts a conditional block that runs when cType = 0 Or cDesc = 0 is true.
    If cType = 0 Or cDesc = 0 Then
        ' [LINE EXPLANATION] Stores the object returned by d in BuildVFDTypeDescMap.
        Set BuildVFDTypeDescMap = d
        ' [LINE EXPLANATION] Returns immediately from BuildVFDTypeDescMap using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets LastRow to VFD_LastUsedRow(ws).
    lastRow = VFD_LastUsedRow(ws)
    ' [LINE EXPLANATION] Sets lastCol to VFD_LastUsedCol(ws).
    lastCol = VFD_LastUsedCol(ws)
    ' [LINE EXPLANATION] Starts a conditional block that runs when LastRow < 2 Or lastCol < cType Or lastCol < cDesc is true.
    If lastRow < 2 Or lastCol < cType Or lastCol < cDesc Then
        ' [LINE EXPLANATION] Stores the object returned by d in BuildVFDTypeDescMap.
        Set BuildVFDTypeDescMap = d
        ' [LINE EXPLANATION] Returns immediately from BuildVFDTypeDescMap using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets arr to ws.Range(ws.Cells(1, 1), ws.Cells(LastRow, lastCol)).value.
    arr = ws.Range(ws.Cells(1, 1), ws.Cells(lastRow, lastCol)).value

    ' [LINE EXPLANATION] Loops r from 2 through LastRow.
    For r = 2 To lastRow
        ' [LINE EXPLANATION] Sets k to DeviceTypeKey(VFD_ArrayValue(arr, r, cType)).
        k = DeviceTypeKey(VFD_ArrayValue(arr, r, cType))
        ' [LINE EXPLANATION] Sets v to Trim$(CStr(VFD_ArrayValue(arr, r, cDesc))).
        v = Trim$(CStr(VFD_ArrayValue(arr, r, cDesc)))
        ' [LINE EXPLANATION] When Len(k) > 0 And Len(v) > 0 is true, executes the inline action d(k) = v.
        If Len(k) > 0 And Len(v) > 0 Then d(k) = v
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

    ' [LINE EXPLANATION] Stores the object returned by d in BuildVFDTypeDescMap.
    Set BuildVFDTypeDescMap = d

' [LINE EXPLANATION] Ends function BuildVFDTypeDescMap.
End Function

'-------------------------------------------------------------------------------
' Procedure : GetVFDTypeDesc
' Scope/Type: Private Function
' Purpose   : Returns VFD type desc.
' Parameters:
' typeDescMap (Object) - Supplies type desc map.
' typeText (String) - Supplies type text.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetVFDTypeDesc. Returns VFD type desc.
Private Function GetVFDTypeDesc(ByVal typeDescMap As Object, ByVal typeText As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String

    ' [LINE EXPLANATION] Sets the return value of GetVFDTypeDesc to typeText.
    GetVFDTypeDesc = typeText
    ' [LINE EXPLANATION] When typeDescMap Is Nothing is true, executes the inline action Exit Function.
    If typeDescMap Is Nothing Then Exit Function

    ' [LINE EXPLANATION] Sets k to DeviceTypeKey(typeText).
    k = DeviceTypeKey(typeText)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
    If Len(k) > 0 Then
        ' [LINE EXPLANATION] When typeDescMap.Exists(k) is true, executes the inline action GetVFDTypeDesc = CStr(typeDescMap(k)).
        If typeDescMap.Exists(k) Then GetVFDTypeDesc = CStr(typeDescMap(k))
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function GetVFDTypeDesc.
End Function

'-------------------------------------------------------------------------------
' Procedure : BuildVFDHasBus2Map
' Scope/Type: Private Function
' Purpose   : Builds VFD has bus 2 map.
' Parameters:
' arr (Variant) - Supplies array.
' PD6Hdr (Object) - Supplies pd 6 header.
' LastRow (Long) - Supplies last row.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function BuildVFDHasBus2Map. Builds VFD has bus 2 map.
Private Function BuildVFDHasBus2Map(ByRef arr As Variant, ByVal PD6Hdr As Object, ByVal lastRow As Long) As Object

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for sis (String).
    Dim sis As String
    ' [LINE EXPLANATION] Declares procedure-level storage for typ (String).
    Dim typ As String
    ' [LINE EXPLANATION] Declares procedure-level storage for sysType (String).
    Dim sysType As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorVolt (String).
    Dim motorVolt As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorKW (String).
    Dim motorKW As String
    ' [LINE EXPLANATION] Declares procedure-level storage for busText (String).
    Dim busText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowKey (String).
    Dim rowKey As String

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in d.
    Set d = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets d.CompareMode to vbTextCompare.
    d.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Loops r from 2 through LastRow.
    For r = 2 To lastRow
        ' [LINE EXPLANATION] Sets sis to VFD_Pick(arr, r, PD6Hdr, "Control_ID", "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS_sequence"....
        sis = VFD_Pick(arr, r, PD6Hdr, "Control_ID", "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS_sequence", "SIS_SEQUENCE")
        ' [LINE EXPLANATION] Sets typ to VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC").
        typ = VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC")
        ' [LINE EXPLANATION] Sets sysType to VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type").
        sysType = VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type")
        ' [LINE EXPLANATION] Sets motorVolt to VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE").
        motorVolt = VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE")
        ' [LINE EXPLANATION] Sets motorKW to VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE").
        motorKW = VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE")
        ' [LINE EXPLANATION] Sets busText to NormalizeBusName(VFD_Pick(arr, r, PD6Hdr, "Bus Power", "BUS POWER", "Power Bus")).
        busText = NormalizeBusName(VFD_Pick(arr, r, PD6Hdr, "Bus Power", "BUS POWER", "Power Bus"))

        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(sis) > 0 is true.
        If Len(sis) > 0 Then
            ' [LINE EXPLANATION] Starts a conditional block that runs when IsVFDPowerRow(typ, sysType, motorVolt, motorKW) is true.
            If IsVFDPowerRow(typ, sysType, motorVolt, motorKW) Then
                ' [LINE EXPLANATION] Starts a conditional block that runs when busText = "BUS-2" is true.
                If busText = "BUS-2" Then
                    ' [LINE EXPLANATION] Sets rowKey to VFD_RowIdentityKey(sis, typ, motorKW).
                    rowKey = VFD_DeviceIdentityKey(sis)
                    ' [LINE EXPLANATION] When Len(rowKey) > 0 is true, executes the inline action d(rowKey) = True.
                    If Len(rowKey) > 0 Then d(rowKey) = True
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

    ' [LINE EXPLANATION] Stores the object returned by d in BuildVFDHasBus2Map.
    Set BuildVFDHasBus2Map = d

' [LINE EXPLANATION] Ends function BuildVFDHasBus2Map.
End Function

'-------------------------------------------------------------------------------
' Procedure : Build24VFeederMap
' Scope/Type: Private Function
' Purpose   : Builds 24 v feeder map.
' Parameters: None.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Build24VFeederMap. Builds 24 v feeder map.
Private Function Build24VFeederMap() As Object

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for LastRow (Long).
    Dim lastRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for rr (Long).
    Dim rr As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for currentBus2PSU (String).
    Dim currentBus2PSU As String
    ' [LINE EXPLANATION] Declares procedure-level storage for cSis (Long).
    Dim cSIS As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cType (Long).
    Dim cType As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cTerm (Long).
    Dim cTerm As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cInside (Long).
    Dim cInside As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for sis (String).
    Dim sis As String
    ' [LINE EXPLANATION] Declares procedure-level storage for typ (String).
    Dim typ As String
    ' [LINE EXPLANATION] Declares procedure-level storage for termText (String).
    Dim termText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for insideText (String).
    Dim insideText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for firstKey (String).
    Dim firstKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for sheetKey (String).
    Dim sheetKey As String

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in d.
    Set d = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets d.CompareMode to vbTextCompare.
    d.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Loops through each ws contained in ThisWorkbook.Worksheets.
    For Each ws In ThisWorkbook.Worksheets
        ' [LINE EXPLANATION] Sets sheetKey to UCase$(Trim$(ws.name)).
        sheetKey = UCase$(Trim$(ws.Name))
        ' [LINE EXPLANATION] Starts a conditional block that runs when Left$(sheetKey, 4) = "24V_" And sheetKey <> UCase$(SH_24V) is true.
        If Left$(sheetKey, 4) = "24V_" And sheetKey <> UCase$(SH_24V) Then

            ' [LINE EXPLANATION] Sets LastRow to VFD_LastUsedRow(ws).
            lastRow = VFD_LastUsedRow(ws)
            ' [LINE EXPLANATION] Sets currentBus2PSU to "".
            currentBus2PSU = ""

            ' [LINE EXPLANATION] Loops r from 1 through LastRow.
            For r = 1 To lastRow

                ' [LINE EXPLANATION] Starts a conditional block that runs when VFD_HeaderKey(ws.Cells(r, 1).value) = "PWG" And VFD_HeaderKey(ws.Cells(r, 2).value) = "BUSPOWER" And VFD_HeaderKey(ws... is true. This logical statement spans 3...
                If VFD_HeaderKey(ws.Cells(r, 1).value) = "PWG" And _
                   VFD_HeaderKey(ws.Cells(r, 2).value) = "BUSPOWER" And _
                   VFD_HeaderKey(ws.Cells(r, 3).value) = "POWERSUPPLY" Then

                    ' [LINE EXPLANATION] Starts a conditional block that runs when r + 2 <= LastRow is true.
                    If r + 2 <= lastRow Then
                        ' [LINE EXPLANATION] Starts a conditional block that runs when NormalizeBusName(CStr(ws.Cells(r + 2, 2).value)) = "BUS-2" is true.
                        If NormalizeBusName(CStr(ws.Cells(r + 2, 2).value)) = "BUS-2" Then
                            ' [LINE EXPLANATION] Sets currentBus2PSU to Trim$(CStr(ws.Cells(r + 2, 3).value)).
                            currentBus2PSU = Trim$(CStr(ws.Cells(r + 2, 3).value))
                        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                        End If
                    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                    End If
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If

                ' [LINE EXPLANATION] Starts a conditional block that runs when VFD_HeaderKey(ws.Cells(r, 1).value) = "SISELEMENTNUMBER" is true.
                If VFD_HeaderKey(ws.Cells(r, 1).value) = "SISELEMENTNUMBER" Then

                    ' [LINE EXPLANATION] Sets cSis to VFD_FindHeaderInRow(ws, r, "SIS_ELEMENT_NUMBER", "SIS_ELEMENT", "SIS_SEQUENCE").
                    cSIS = VFD_FindHeaderInRow(ws, r, "SIS_ELEMENT_NUMBER", "SIS_ELEMENT", "SIS_SEQUENCE")
                    ' [LINE EXPLANATION] Sets cType to VFD_FindHeaderInRow(ws, r, "TYPE", "TYPE/DESC", "Device Type").
                    cType = VFD_FindHeaderInRow(ws, r, "TYPE", "TYPE/DESC", "Device Type")
                    ' [LINE EXPLANATION] Sets cTerm to VFD_FindHeaderInRow(ws, r, "Power BUS-2 Terminal", "Power Bus-2 Terminal", "BUS-2 Terminal", "PWR....
                    cTerm = VFD_FindHeaderInRow(ws, r, "Power BUS-2 Terminal", "Power Bus-2 Terminal", "BUS-2 Terminal", "PWR TERM")
                    ' [LINE EXPLANATION] Sets cInside to VFD_FindHeaderInRow(ws, r, "Inside PSU TERM", "INSIDE PNL TERM", "Inside Terminal").
                    cInside = VFD_FindHeaderInRow(ws, r, "Inside PSU TERM", "INSIDE PNL TERM", "Inside Terminal")

                    ' [LINE EXPLANATION] Starts a conditional block that runs when cSis > 0 And cTerm > 0 is true.
                    If cSIS > 0 And cTerm > 0 Then
                        ' [LINE EXPLANATION] Sets rr to r + 1.
                        rr = r + 1
                        ' [LINE EXPLANATION] Starts a loop that repeats while rr <= LastRow.
                        Do While rr <= lastRow
                            ' [LINE EXPLANATION] Sets firstKey to VFD_HeaderKey(ws.Cells(rr, 1).value).
                            firstKey = VFD_HeaderKey(ws.Cells(rr, 1).value)
                            ' [LINE EXPLANATION] When firstKey = "PWG" Or firstKey = "SISELEMENTNUMBER" is true, executes the inline action Exit Do.
                            If firstKey = "PWG" Or firstKey = "SISELEMENTNUMBER" Then Exit Do

                            ' [LINE EXPLANATION] Sets sis to Trim$(CStr(ws.Cells(rr, cSis).value)).
                            sis = Trim$(CStr(ws.Cells(rr, cSIS).value))
                            ' [LINE EXPLANATION] When Len(sis) = 0 is true, executes the inline action Exit Do.
                            If Len(sis) = 0 Then Exit Do

                            ' [LINE EXPLANATION] Sets typ to "".
                            typ = ""
                            ' [LINE EXPLANATION] Sets termText to "".
                            termText = ""
                            ' [LINE EXPLANATION] Sets insideText to "".
                            insideText = ""

                            ' [LINE EXPLANATION] When cType > 0 is true, executes the inline action typ = Trim$(CStr(ws.Cells(rr, cType).value)).
                            If cType > 0 Then typ = Trim$(CStr(ws.Cells(rr, cType).value))
                            ' [LINE EXPLANATION] When cTerm > 0 is true, executes the inline action termText = Trim$(CStr(ws.Cells(rr, cTerm).value)).
                            If cTerm > 0 Then termText = Trim$(CStr(ws.Cells(rr, cTerm).value))
                            ' [LINE EXPLANATION] When cInside > 0 is true, executes the inline action insideText = Trim$(CStr(ws.Cells(rr, cInside).value)).
                            If cInside > 0 Then insideText = Trim$(CStr(ws.Cells(rr, cInside).value))

                            ' Supports both older logical 24V sheets and the new physical terminal output.
                            If Len(termText) > 0 And UCase$(termText) <> "MISSING" Then
                                termText = VFD_GetPhysicalPSUTerminal(termText)
                                insideText = VFD_GetPSUDescription(termText)
                            End If

                            ' [LINE EXPLANATION] Starts a conditional block that runs when Len(currentBus2PSU) > 0 Or Len(termText) > 0 Or Len(insideText) > 0 is true.
                            If Len(currentBus2PSU) > 0 Or Len(termText) > 0 Or Len(insideText) > 0 Then
                                ' [LINE EXPLANATION] Calls VFD_AddFeeder, which performs the VFD add feeder workflow, using the supplied argument values.
                                VFD_AddFeeder d, sis, typ, currentBus2PSU, termText, insideText
                            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                            End If

                            ' [LINE EXPLANATION] Sets rr to rr + 1.
                            rr = rr + 1
                        ' [LINE EXPLANATION] Returns to the beginning of the current Do loop.
                        Loop
                    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                    End If
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Advances the r loop to its next iteration.
            Next r
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the ws loop to its next iteration.
    Next ws

    ' [LINE EXPLANATION] Stores the object returned by d in Build24VFeederMap.
    Set Build24VFeederMap = d

' [LINE EXPLANATION] Ends function Build24VFeederMap.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_AddFeeder
' Scope/Type: Private Sub
' Purpose   : Performs the VFD add feeder workflow.
' Parameters:
' d (Object) - Supplies d.
' sis (String) - Supplies SIS.
' typ (String) - Supplies typ.
' psu (String) - Supplies PSU.
' termText (String) - Supplies term text.
' insideText (String) - Supplies inside text.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub VFD_AddFeeder. Performs the VFD add feeder workflow.
Private Sub VFD_AddFeeder(ByVal d As Object, ByVal sis As String, ByVal typ As String, ByVal psu As String, ByVal termText As String, ByVal insideText As String)

    ' [LINE EXPLANATION] Declares procedure-level storage for key1 (String).
    Dim key1 As String
    ' [LINE EXPLANATION] Declares procedure-level storage for key2 (String).
    Dim key2 As String
    ' [LINE EXPLANATION] Declares procedure-level storage for info (Variant).
    Dim info As Variant

    ' [LINE EXPLANATION] When Len(Trim$(sis)) = 0 is true, executes the inline action Exit Sub.
    If Len(Trim$(sis)) = 0 Then Exit Sub

    ' [LINE EXPLANATION] Sets info to Array(psu, termText, insideText).
    info = Array(psu, termText, insideText)
    ' [LINE EXPLANATION] Sets key1 to VFD_FeederKey(sis, typ).
    key1 = VFD_FeederKey(sis, typ)
    ' [LINE EXPLANATION] Sets key2 to VFD_FeederKey(sis, "").
    key2 = VFD_FeederKey(sis, "")

    ' [LINE EXPLANATION] When Len(key1) > 0 is true, executes the inline action d(key1) = info.
    If Len(key1) > 0 Then d(key1) = info
    ' [LINE EXPLANATION] When Len(key2) > 0 is true, executes the inline action d(key2) = info.
    If Len(key2) > 0 Then d(key2) = info

' [LINE EXPLANATION] Ends procedure VFD_AddFeeder.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Get24VFeederInfo
' Scope/Type: Private Function
' Purpose   : Returns 24 v feeder info.
' Parameters:
' feederMap (Object) - Supplies feeder map.
' sis (String) - Supplies SIS.
' typ (String) - Supplies typ.
' Returns   : Variant.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get24VFeederInfo. Returns 24 v feeder info.
Private Function Get24VFeederInfo(ByVal feederMap As Object, ByVal sis As String, ByVal typ As String) As Variant

    ' [LINE EXPLANATION] Declares procedure-level storage for key1 (String).
    Dim key1 As String
    ' [LINE EXPLANATION] Declares procedure-level storage for key2 (String).
    Dim key2 As String

    ' [LINE EXPLANATION] Sets key1 to VFD_FeederKey(sis, typ).
    key1 = VFD_FeederKey(sis, typ)
    ' [LINE EXPLANATION] Sets key2 to VFD_FeederKey(sis, "").
    key2 = VFD_FeederKey(sis, "")

    ' [LINE EXPLANATION] Starts a conditional block that runs when feederMap.Exists(key1) is true.
    If feederMap.Exists(key1) Then
        ' [LINE EXPLANATION] Sets the return value of Get24VFeederInfo to feederMap(key1).
        Get24VFeederInfo = feederMap(key1)
    ' [LINE EXPLANATION] Tests the next alternative condition: feederMap.Exists(key2).
    ElseIf feederMap.Exists(key2) Then
        ' [LINE EXPLANATION] Sets the return value of Get24VFeederInfo to feederMap(key2).
        Get24VFeederInfo = feederMap(key2)
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of Get24VFeederInfo to Empty.
        Get24VFeederInfo = Empty
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Get24VFeederInfo.
End Function

'-------------------------------------------------------------------------------
' Procedure : BuildPD6Bus2FeederMap
' Scope/Type: Private Function
' Purpose   : Builds pd 6 bus 2 feeder map.
' Parameters:
' arr (Variant) - Supplies array.
' PD6Hdr (Object) - Supplies pd 6 header.
' LastRow (Long) - Supplies last row.
' insideTermMap (Object) - Supplies inside term map.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function BuildPD6Bus2FeederMap. Builds pd 6 bus 2 feeder map.
Private Function BuildPD6Bus2FeederMap(ByRef arr As Variant, ByVal PD6Hdr As Object, ByVal lastRow As Long, ByVal insideTermMap As Object) As Object

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for sis (String).
    Dim sis As String
    ' [LINE EXPLANATION] Declares procedure-level storage for typ (String).
    Dim typ As String
    ' [LINE EXPLANATION] Declares procedure-level storage for sysType (String).
    Dim sysType As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorVolt (String).
    Dim motorVolt As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorKW (String).
    Dim motorKW As String
    ' [LINE EXPLANATION] Declares procedure-level storage for busText (String).
    Dim busText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for rowKey (String).
    Dim rowKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for psuText (String).
    Dim psuText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for termText (String).
    Dim termText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for insideText (String).
    Dim insideText As String

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in d.
    Set d = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets d.CompareMode to vbTextCompare.
    d.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Loops r from 2 through LastRow.
    For r = 2 To lastRow
        ' [LINE EXPLANATION] Sets sis to VFD_Pick(arr, r, PD6Hdr, "Control_ID", "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS_sequence"....
        sis = VFD_Pick(arr, r, PD6Hdr, "Control_ID", "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS_sequence", "SIS_SEQUENCE")
        ' [LINE EXPLANATION] Sets typ to VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC").
        typ = VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC")
        ' [LINE EXPLANATION] Sets sysType to VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type").
        sysType = VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type")
        ' [LINE EXPLANATION] Sets motorVolt to VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE").
        motorVolt = VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE")
        ' [LINE EXPLANATION] Sets motorKW to VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE").
        motorKW = VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE")
        ' [LINE EXPLANATION] Sets busText to NormalizeBusName(VFD_Pick(arr, r, PD6Hdr, "Bus Power", "BUS POWER", "Power Bus")).
        busText = NormalizeBusName(VFD_Pick(arr, r, PD6Hdr, "Bus Power", "BUS POWER", "Power Bus"))

        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(sis) > 0 is true.
        If Len(sis) > 0 Then
            ' [LINE EXPLANATION] Starts a conditional block that runs when busText = "BUS-2" And IsVFDPowerRow(typ, sysType, motorVolt, motorKW) is true.
            If busText = "BUS-2" And IsVFDPowerRow(typ, sysType, motorVolt, motorKW) Then
                ' [LINE EXPLANATION] Sets rowKey to VFD_RowIdentityKey(sis, typ, motorKW).
                rowKey = VFD_DeviceIdentityKey(sis)
                ' [LINE EXPLANATION] Sets psuText to VFD_Pick(arr, r, PD6Hdr, "Power Supply", "POWER SUPPLY", "PSU").
                psuText = VFD_Pick(arr, r, PD6Hdr, "Power Supply", "POWER SUPPLY", "PSU")
                ' [LINE EXPLANATION] Sets termText to VFD_Pick(arr, r, PD6Hdr, "Power BUS-2 Terminal", "BUS-2 Terminal", "Power Bus-2 Terminal", "PWR T....
                termText = VFD_Pick(arr, r, PD6Hdr, "Power BUS-2 Terminal", "BUS-2 Terminal", "Power Bus-2 Terminal", "PWR TERM")
                ' [LINE EXPLANATION] Sets insideText to GetInsidePSUTerm(insideTermMap, termText).
                insideText = GetInsidePSUTerm(insideTermMap, termText)
                If Len(termText) > 0 And UCase$(termText) <> "MISSING" Then
                    termText = VFD_GetPhysicalPSUTerminal(termText)
                    insideText = VFD_GetPSUDescription(termText)
                End If
                ' [LINE EXPLANATION] When Len(rowKey) > 0 is true, executes the inline action d(rowKey) = Array(psuText, termText, insideText).
                If Len(rowKey) > 0 Then d(rowKey) = Array(psuText, termText, insideText)
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

    ' [LINE EXPLANATION] Stores the object returned by d in BuildPD6Bus2FeederMap.
    Set BuildPD6Bus2FeederMap = d

' [LINE EXPLANATION] Ends function BuildPD6Bus2FeederMap.
End Function

'-------------------------------------------------------------------------------
' Procedure : GetPD6Bus2FeederInfo
' Scope/Type: Private Function
' Purpose   : Returns pd 6 bus 2 feeder info.
' Parameters:
' PD6FeederMap (Object) - Supplies pd 6 feeder map.
' rowKey (String) - Supplies row key.
' Returns   : Variant.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetPD6Bus2FeederInfo. Returns pd 6 bus 2 feeder info.
Private Function GetPD6Bus2FeederInfo(ByVal PD6FeederMap As Object, ByVal rowKey As String) As Variant

    ' [LINE EXPLANATION] Starts a conditional block that runs when Not PD6FeederMap Is Nothing is true.
    If Not PD6FeederMap Is Nothing Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when PD6FeederMap.Exists(rowKey) is true.
        If PD6FeederMap.Exists(rowKey) Then
            ' [LINE EXPLANATION] Sets the return value of GetPD6Bus2FeederInfo to PD6FeederMap(rowKey).
            GetPD6Bus2FeederInfo = PD6FeederMap(rowKey)
            ' [LINE EXPLANATION] Returns immediately from GetPD6Bus2FeederInfo using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets the return value of GetPD6Bus2FeederInfo to Empty.
    GetPD6Bus2FeederInfo = Empty

' [LINE EXPLANATION] Ends function GetPD6Bus2FeederInfo.
End Function

'-------------------------------------------------------------------------------
' Procedure : Get480VDeviceTermRows
' Scope/Type: Private Function
' Purpose   : Returns 480 v device term rows.
' Parameters:
' maps (Object) - Supplies maps.
' deviceType (String) - Supplies device type.
' Returns   : Collection.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get480VDeviceTermRows. Returns 480 v device term rows.
Private Function Get480VDeviceTermRows(ByVal maps As Object, ByVal deviceType As String) As Collection

    ' [LINE EXPLANATION] Declares procedure-level storage for termRows (Object).
    Dim termRows As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for keyText (String).
    Dim keyText As String

    ' [LINE EXPLANATION] Stores the object returned by maps("TERMROWS") in termRows.
    Set termRows = maps("TERMROWS")
    ' [LINE EXPLANATION] Sets keyText to DeviceTypeKey(deviceType).
    keyText = DeviceTypeKey(deviceType)

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) > 0 And Not termRows.Exists(keyText) is true.
    If Len(keyText) > 0 And Not termRows.Exists(keyText) Then
        ' [LINE EXPLANATION] When Left$(keyText, 3) = "VFD" And termRows.Exists("VFD") is true, executes the inline action keyText = "VFD".
        If Left$(keyText, 3) = "VFD" And termRows.Exists("VFD") Then keyText = "VFD"
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) > 0 is true.
    If Len(keyText) > 0 Then
        ' [LINE EXPLANATION] When termRows.Exists(keyText) is true, executes the inline action Set Get480VDeviceTermRows = termRows(keyText).
        If termRows.Exists(keyText) Then Set Get480VDeviceTermRows = termRows(keyText)
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Get480VDeviceTermRows.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_MergeTermRows
' Purpose   : Returns one complete terminal-template record for one VFD.
'-------------------------------------------------------------------------------
Private Function VFD_MergeTermRows(ByVal sourceRows As Collection, _
                                   ByVal fallbackBlock As String, _
                                   ByVal fallbackTin As String, _
                                   ByVal fallbackTout As String) As Variant
    Dim result(0 To 9) As String
    Dim bestEntry As Variant, entry As Variant
    Dim bestScore As Long, score As Long
    Dim i As Long, j As Long

    If Not sourceRows Is Nothing Then
        For i = 1 To sourceRows.count
            entry = sourceRows(i)
            score = 0
            For j = 0 To 9
                If Len(VFD_EntryText(entry, j)) > 0 Then score = score + 1
            Next j
            If score > bestScore Then
                bestScore = score
                bestEntry = entry
            End If
        Next i

        If bestScore > 0 Then
            For j = 0 To 9
                result(j) = VFD_EntryText(bestEntry, j)
            Next j
        End If

        'Fill only blanks from other reference rows. This preserves one coherent
        'primary terminal record while retaining secondary NET/BUS terminal data.
        For i = 1 To sourceRows.count
            entry = sourceRows(i)
            For j = 0 To 9
                If Len(result(j)) = 0 Then result(j) = VFD_EntryText(entry, j)
            Next j
        Next i
    End If

    If Len(result(0)) = 0 Then result(0) = Trim$(fallbackBlock)
    If Len(result(1)) = 0 Then result(1) = Trim$(fallbackTin)
    If Len(result(2)) = 0 Then result(2) = Trim$(fallbackTout)
    VFD_MergeTermRows = result
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_DeviceIdentityKey
' Purpose   : Canonical identity used to prevent duplicate physical VFD rows.
'-------------------------------------------------------------------------------
Private Function VFD_DeviceIdentityKey(ByVal sis As String) As String
    Dim s As String, suffixText As String, p As Long
    s = UCase$(Trim$(sis))
    s = Replace(s, " ", "")

    'Control_ID commonly adds -K7 while SIS_ELEMENT_NUMBER does not. They are the
    'same physical VFD and therefore must share one source identity.
    p = InStrRev(s, "-K", -1, vbTextCompare)
    If p > 0 Then
        suffixText = mid$(s, p + 2)
        If Len(suffixText) > 0 And IsNumeric(suffixText) Then s = Left$(s, p - 1)
    End If
    VFD_DeviceIdentityKey = s
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_EntryText
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD entry text.
' Parameters:
' entry (Variant) - Supplies entry.
' itemIndex (Long) - Supplies item index.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_EntryText. Calculates or returns VFD entry text.
Private Function VFD_EntryText(ByVal entry As Variant, ByVal itemIndex As Long) As String
    ' [LINE EXPLANATION] Routes any runtime error raised after this line to the SafeExit label.
    On Error GoTo SafeExit
    ' [LINE EXPLANATION] Starts a conditional block that runs when IsArray(entry) is true.
    If IsArray(entry) Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when itemIndex >= LBound(entry) And itemIndex <= UBound(entry) is true.
        If itemIndex >= LBound(entry) And itemIndex <= UBound(entry) Then
            ' [LINE EXPLANATION] Sets the return value of VFD_EntryText to Trim$(CStr(entry(itemIndex))).
            VFD_EntryText = Trim$(CStr(entry(itemIndex)))
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
' [LINE EXPLANATION] Defines the SafeExit cleanup/exit entry point so normal and error paths can restore Excel safely.
SafeExit:
' [LINE EXPLANATION] Ends function VFD_EntryText.
End Function

'-------------------------------------------------------------------------------
' Procedure : UpdatePD6VFDLoadsFrom480V
' Scope/Type: Private Sub
' Purpose   : Updates pd 6 VFD loads from 480 v.
' Parameters:
' wsPD6 (Worksheet) - Supplies worksheet pd 6.
' PD6Hdr (Object) - Supplies pd 6 header.
' maps (Object) - Supplies maps.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub UpdatePD6VFDLoadsFrom480V. Updates pd 6 VFD loads from 480 v.
Private Sub UpdatePD6VFDLoadsFrom480V(ByVal wsPD6 As Worksheet, ByVal PD6Hdr As Object, ByVal maps As Object)

    ' [LINE EXPLANATION] Declares procedure-level storage for LastRow (Long).
    Dim lastRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for arr (Variant).
    Dim arr As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cLoad (Long).
    Dim cLoad As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for typ (String).
    Dim typ As String
    ' [LINE EXPLANATION] Declares procedure-level storage for sysType (String).
    Dim sysType As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorVolt (String).
    Dim motorVolt As String
    ' [LINE EXPLANATION] Declares procedure-level storage for motorKW (String).
    Dim motorKW As String
    ' [LINE EXPLANATION] Declares procedure-level storage for loadVal (String).
    Dim loadVal As String

    ' [LINE EXPLANATION] Sets cLoad to VFD_HeaderCol(PD6Hdr, "Load", "LOAD").
    cLoad = VFD_HeaderCol(PD6Hdr, "Load", "LOAD")
    ' [LINE EXPLANATION] Starts a conditional block that runs when cLoad = 0 is true.
    If cLoad = 0 Then
        ' [LINE EXPLANATION] Sets cLoad to VFD_LastUsedCol(wsPD6) + 1.
        cLoad = VFD_LastUsedCol(wsPD6) + 1
        ' [LINE EXPLANATION] Writes "Load" into wsPD6.Cells(HEADER_ROW, cLoad).value.
        wsPD6.Cells(HEADER_ROW, cLoad).value = "Load"
        ' [LINE EXPLANATION] Sets PD6Hdr(VFD_HeaderKey("Load")) to cLoad.
        PD6Hdr(VFD_HeaderKey("Load")) = cLoad
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets LastRow to VFD_LastUsedRow(wsPD6).
    lastRow = VFD_LastUsedRow(wsPD6)
    ' [LINE EXPLANATION] Sets lastCol to VFD_LastUsedCol(wsPD6).
    lastCol = VFD_LastUsedCol(wsPD6)
    ' [LINE EXPLANATION] When LastRow < 2 is true, executes the inline action Exit Sub.
    If lastRow < 2 Then Exit Sub

    ' [LINE EXPLANATION] Sets arr to wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(LastRow, lastCol)).value.
    arr = wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(lastRow, lastCol)).value

    ' [LINE EXPLANATION] Loops r from 2 through LastRow.
    For r = 2 To lastRow
        ' [LINE EXPLANATION] Sets typ to VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC").
        typ = VFD_Pick(arr, r, PD6Hdr, "TYPE", "Device Type", "TYPE/DESC")
        ' [LINE EXPLANATION] Sets sysType to VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type").
        sysType = VFD_Pick(arr, r, PD6Hdr, "System Type", "SYSTEM TYPE", "Conveyor Type")
        ' [LINE EXPLANATION] Sets motorVolt to VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE").
        motorVolt = VFD_Pick(arr, r, PD6Hdr, "Motor Voltage (Main Drive)", "Motor Voltage", "MOTOR VOLTAGE MAIN DRIVE")
        ' [LINE EXPLANATION] Sets motorKW to VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE").
        motorKW = VFD_Pick(arr, r, PD6Hdr, "Motor Power (Main Drive)", "Motor Power", "KW", "MOTOR POWER MAIN DRIVE")

        ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, UCase$(Trim$(typ)), "VFD", vbTextCompare) > 0 is true.
        If InStr(1, UCase$(Trim$(typ)), "VFD", vbTextCompare) > 0 Then
            ' [LINE EXPLANATION] Sets loadVal to Get480VLoadByKW(maps, motorKW).
            loadVal = Get480VLoadByKW(maps, motorKW)
            ' [LINE EXPLANATION] Writes loadVal into wsPD6.Cells(r, cLoad).value.
            wsPD6.Cells(r, cLoad).value = loadVal
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

' [LINE EXPLANATION] Ends procedure UpdatePD6VFDLoadsFrom480V.
End Sub

'-------------------------------------------------------------------------------
' Procedure : GetNext480VDeviceTermInfo
' Scope/Type: Private Function
' Purpose   : Returns next 480 v device term info.
' Parameters:
' maps (Object) - Supplies maps.
' deviceType (String) - Supplies device type.
' panel480V (String) - Supplies panel 480 v.
' pwg (String) - Supplies power group.
' seqState (Object) - Supplies seq state.
' Returns   : Variant.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetNext480VDeviceTermInfo. Returns next 480 v device term info.
Private Function GetNext480VDeviceTermInfo(ByVal maps As Object, ByVal deviceType As String, ByVal panel480V As String, ByVal pwg As String, ByVal seqState As Object) As Variant

    ' [LINE EXPLANATION] Declares procedure-level storage for termRows (Object).
    Dim termRows As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for col (Collection).
    Dim col As Collection
    ' [LINE EXPLANATION] Declares procedure-level storage for keyText (String).
    Dim keyText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for seqKey (String).
    Dim seqKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for scopeText (String).
    Dim scopeText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for idx (Long).
    Dim idx As Long

    ' [LINE EXPLANATION] Stores the object returned by maps("TERMROWS") in termRows.
    Set termRows = maps("TERMROWS")
    ' [LINE EXPLANATION] Sets keyText to DeviceTypeKey(deviceType).
    keyText = DeviceTypeKey(deviceType)

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) > 0 And Not termRows.Exists(keyText) is true.
    If Len(keyText) > 0 And Not termRows.Exists(keyText) Then
        ' [LINE EXPLANATION] When Left$(keyText, 3) = "VFD" And termRows.Exists("VFD") is true, executes the inline action keyText = "VFD".
        If Left$(keyText, 3) = "VFD" And termRows.Exists("VFD") Then keyText = "VFD"
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) = 0 Or Not termRows.Exists(keyText) is true.
    If Len(keyText) = 0 Or Not termRows.Exists(keyText) Then
        ' [LINE EXPLANATION] Sets the return value of GetNext480VDeviceTermInfo to Empty.
        GetNext480VDeviceTermInfo = Empty
        ' [LINE EXPLANATION] Returns immediately from GetNext480VDeviceTermInfo using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Stores the object returned by termRows(keyText) in col.
    Set col = termRows(keyText)
    ' [LINE EXPLANATION] Starts a conditional block that runs when col.count = 0 is true.
    If col.count = 0 Then
        ' [LINE EXPLANATION] Sets the return value of GetNext480VDeviceTermInfo to Empty.
        GetNext480VDeviceTermInfo = Empty
        ' [LINE EXPLANATION] Returns immediately from GetNext480VDeviceTermInfo using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets scopeText to UCase$(Trim$(panel480V)).
    scopeText = UCase$(Trim$(panel480V))
    ' [LINE EXPLANATION] When Len(scopeText) = 0 is true, executes the inline action scopeText = UCase$(Trim$(pwg)).
    If Len(scopeText) = 0 Then scopeText = UCase$(Trim$(pwg))
    ' [LINE EXPLANATION] When Len(scopeText) = 0 is true, executes the inline action scopeText = "GLOBAL".
    If Len(scopeText) = 0 Then scopeText = "GLOBAL"

    ' [LINE EXPLANATION] Sets seqKey to scopeText & "|" & keyText.
    seqKey = scopeText & "|" & keyText
    ' [LINE EXPLANATION] Sets idx to 1.
    idx = 1
    ' [LINE EXPLANATION] When seqState.Exists(seqKey) is true, executes the inline action idx = CLng(seqState(seqKey)) + 1.
    If seqState.Exists(seqKey) Then idx = CLng(seqState(seqKey)) + 1
    ' [LINE EXPLANATION] Sets seqState(seqKey) to idx.
    seqState(seqKey) = idx

    ' [LINE EXPLANATION] When idx > col.count is true, executes the inline action idx = col.count.
    If idx > col.count Then idx = col.count
    ' [LINE EXPLANATION] Sets the return value of GetNext480VDeviceTermInfo to col(idx).
    GetNext480VDeviceTermInfo = col(idx)

' [LINE EXPLANATION] Ends function GetNext480VDeviceTermInfo.
End Function

'-------------------------------------------------------------------------------
' Data-driven PSU template helpers
'-------------------------------------------------------------------------------
Private Function VFD_GetPSUTemplate() As Object
    Dim ws As Worksheet
    Dim d As Object
    Dim headerRow As Long
    Dim cDwg As Long, cTerm As Long, cDesc As Long
    Dim r As Long, c As Long, lastRow As Long, lastCol As Long
    Dim h As String, currentDwg As String, termText As String, descText As String
    Dim termCount As Long

    If Not mVFDPSUTemplate Is Nothing Then
        Set VFD_GetPSUTemplate = mVFDPSUTemplate
        Exit Function
    End If

    Set ws = VFD_GetSheetIfExists(SH_480V_DATA)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 4801, "VFD_GetPSUTemplate", _
                  "Worksheet '" & SH_480V_DATA & "' was not found."
    End If

    lastRow = VFD_LastUsedRow(ws)
    lastCol = VFD_LastUsedCol(ws)

    For r = 1 To WorksheetFunction.Min(lastRow, 30)
        cDwg = 0: cTerm = 0: cDesc = 0
        For c = 1 To lastCol
            h = VFD_HeaderKey(ws.Cells(r, c).value)
            Select Case h
                Case "PSUDWG": cDwg = c
                Case "PSUTERM": cTerm = c
                Case "PSUDESC", "DESCPSU", "PSUDESCRIPTION": cDesc = c
            End Select
        Next c
        If cDwg > 0 And cTerm > 0 And cDesc > 0 Then
            headerRow = r
            Exit For
        End If
    Next r

    If headerRow = 0 Then
        Err.Raise vbObjectError + 4802, "VFD_GetPSUTemplate", _
                  "Headers PSU DWG, PSU TERM, and PSUDESC were not found on the same row of '" & _
                  SH_480V_DATA & "'."
    End If

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    For r = headerRow + 1 To lastRow
        If Len(Trim$(CStr(ws.Cells(r, cDwg).value))) > 0 Then
            currentDwg = Trim$(CStr(ws.Cells(r, cDwg).value))
        End If
        termText = Trim$(CStr(ws.Cells(r, cTerm).value))
        descText = Trim$(CStr(ws.Cells(r, cDesc).value))

        If Len(termText) > 0 Or Len(descText) > 0 Then
            If Len(currentDwg) = 0 Then
                Err.Raise vbObjectError + 4803, "VFD_GetPSUTemplate", _
                          "The first PSU TERM row must have a PSU DWG value in '" & SH_480V_DATA & "'."
            End If
            If Len(termText) = 0 Or Len(descText) = 0 Then
                Err.Raise vbObjectError + 4804, "VFD_GetPSUTemplate", _
                          "Every PSU template row must contain both PSU TERM and PSUDESC. Check row " & CStr(r) & "."
            End If

            termCount = termCount + 1
            If termCount = 1 Then d("DWG") = currentDwg
            d("DWG" & CStr(termCount)) = currentDwg
            d("TERM" & CStr(termCount)) = termText
            d("PSUDESC" & CStr(termCount)) = descText
            If termCount = PSU_TEMPLATE_TERMINAL_COUNT_VFD Then Exit For
        End If
    Next r

    If termCount <> PSU_TEMPLATE_TERMINAL_COUNT_VFD Then
        Err.Raise vbObjectError + 4805, "VFD_GetPSUTemplate", _
                  "Exactly four usable PSU TERM/PSUDESC rows are required under the PSU headers in '" & _
                  SH_480V_DATA & "'. Found " & CStr(termCount) & "."
    End If

    Set mVFDPSUTemplate = d
    Set VFD_GetPSUTemplate = mVFDPSUTemplate
End Function

Private Function VFD_GetPSUTerminalIndex(ByVal terminalText As String) As Long
    Dim template As Object
    Dim i As Long
    Dim k As String
    Dim s As String
    Dim p As Long
    Dim logicalIndex As Long

    s = UCase$(Trim$(Replace(CStr(terminalText), Chr$(160), " ")))
    If Len(Replace(s, " ", "")) = 0 Or s = "MISSING" Then Exit Function

    Set template = VFD_GetPSUTemplate()
    k = terminalKey(s)

    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_VFD
        If k = terminalKey(CStr(template("TERM" & CStr(i)))) Then
            VFD_GetPSUTerminalIndex = i
            Exit Function
        End If
    Next i

    s = Replace(Replace(s, " ", ""), "-", "")
    If Left$(s, 1) = "X" Then
        p = InStr(2, s, "TERM", vbTextCompare)
        If p > 2 And IsNumeric(mid$(s, 2, p - 2)) Then
            logicalIndex = CLng(mid$(s, 2, p - 2))
            If logicalIndex >= 1 And logicalIndex <= PSU_TEMPLATE_TERMINAL_COUNT_VFD Then
                If mid$(s, p + 4) = "01" Then VFD_GetPSUTerminalIndex = logicalIndex
            End If
        End If
    End If
End Function

Private Function VFD_GetPhysicalPSUTerminal(ByVal terminalText As String) As String
    Dim idx As Long
    Dim template As Object
    Dim cleanText As String

    cleanText = Trim$(Replace(CStr(terminalText), Chr$(160), " "))
    If Len(cleanText) = 0 Then Exit Function
    If UCase$(cleanText) = "MISSING" Then
        VFD_GetPhysicalPSUTerminal = "MISSING"
        Exit Function
    End If

    idx = VFD_GetPSUTerminalIndex(cleanText)
    If idx = 0 Then
        Err.Raise vbObjectError + 4806, "VFD_GetPhysicalPSUTerminal", _
                  "Terminal '" & cleanText & "' cannot be matched to 480v_DATA_POWER[PSU TERM]. " & _
                  "Valid values are: " & VFD_GetConfiguredTerminalList()
    End If

    Set template = VFD_GetPSUTemplate()
    VFD_GetPhysicalPSUTerminal = CStr(template("TERM" & CStr(idx)))
End Function

Private Function VFD_GetPSUDescription(ByVal terminalText As String) As String
    Dim idx As Long
    Dim template As Object
    Dim cleanText As String

    cleanText = Trim$(Replace(CStr(terminalText), Chr$(160), " "))
    If Len(cleanText) = 0 Or UCase$(cleanText) = "MISSING" Then Exit Function

    idx = VFD_GetPSUTerminalIndex(cleanText)
    If idx = 0 Then
        Err.Raise vbObjectError + 4807, "VFD_GetPSUDescription", _
                  "Terminal '" & cleanText & "' cannot be matched to 480v_DATA_POWER[PSU TERM]. " & _
                  "Valid values are: " & VFD_GetConfiguredTerminalList()
    End If

    Set template = VFD_GetPSUTemplate()
    VFD_GetPSUDescription = CStr(template("PSUDESC" & CStr(idx)))
End Function

'-------------------------------------------------------------------------------
' Procedure : BuildInsidePSUTermMap
' Scope/Type: Private Function
' Purpose   : Builds inside PSU term map.
' Parameters: None.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function BuildInsidePSUTermMap. Builds inside PSU term map.

Private Function VFD_GetConfiguredTerminalList() As String
    Dim template As Object
    Dim i As Long
    Dim result As String

    Set template = VFD_GetPSUTemplate()
    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_VFD
        If Len(result) > 0 Then result = result & ", "
        result = result & CStr(template("TERM" & CStr(i)))
    Next i
    VFD_GetConfiguredTerminalList = result
End Function

Private Function BuildInsidePSUTermMap() As Object
    Dim d As Object
    Dim template As Object
    Dim i As Long
    Dim logicalTerm As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    Set template = VFD_GetPSUTemplate()

    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_VFD
        logicalTerm = "X" & Format$(i, "00") & "TERM01"
        d(terminalKey(logicalTerm)) = CStr(template("PSUDESC" & CStr(i)))
        d(terminalKey(CStr(template("TERM" & CStr(i))))) = CStr(template("PSUDESC" & CStr(i)))
    Next i

    Set BuildInsidePSUTermMap = d
End Function

'-------------------------------------------------------------------------------
' Procedure : GetPD6VFDLoad
' Scope/Type: Private Function
' Purpose   : Returns pd 6 VFD load.
' Parameters:
' arr (Variant) - Supplies array.
' rowNum (Long) - Supplies row number.
' PD6Hdr (Object) - Supplies pd 6 header.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetPD6VFDLoad. Returns pd 6 VFD load.
Private Function GetPD6VFDLoad(ByRef arr As Variant, ByVal rowNum As Long, ByVal PD6Hdr As Object) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for v (String).
    Dim v As String

    'The VFD_480V_Generator Load column must mirror PD6_IMPORT[Load].
    ' [LINE EXPLANATION] Sets v to VFD_Pick(arr, rowNum, PD6Hdr, "Load", "LOAD").
    v = VFD_Pick(arr, rowNum, PD6Hdr, "Load", "LOAD")

    'Safety fallback for older workbook revisions where the 480V drive load was
    'stored under Load BUS-1 instead of Load.
    ' [LINE EXPLANATION] When Len(v) = 0 is true, executes the inline action v = VFD_Pick(arr, rowNum, PD6Hdr, "Load BUS-1", "BUS-1 Load",....
    If Len(v) = 0 Then v = VFD_Pick(arr, rowNum, PD6Hdr, "Load BUS-1", "BUS-1 Load", "Load Bus 1")

    ' [LINE EXPLANATION] Sets the return value of GetPD6VFDLoad to v.
    GetPD6VFDLoad = v

' [LINE EXPLANATION] Ends function GetPD6VFDLoad.
End Function

'-------------------------------------------------------------------------------
' Procedure : Get480VLoadByKW
' Scope/Type: Private Function
' Purpose   : Returns 480 v load by kw.
' Parameters:
' maps (Object) - Supplies maps.
' motorKW (String) - Supplies motor kw.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get480VLoadByKW. Returns 480 v load by kw.
Private Function Get480VLoadByKW(ByVal maps As Object, ByVal motorKW As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for keyText (String).
    Dim keyText As String

    ' [LINE EXPLANATION] Stores the object returned by maps("KWLOAD") in d.
    Set d = maps("KWLOAD")
    ' [LINE EXPLANATION] Sets keyText to KWKey(motorKW).
    keyText = KWKey(motorKW)

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) > 0 And d.Exists(keyText) is true.
    If Len(keyText) > 0 And d.Exists(keyText) Then
        ' [LINE EXPLANATION] Sets the return value of Get480VLoadByKW to CStr(d(keyText)).
        Get480VLoadByKW = CStr(d(keyText))
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of Get480VLoadByKW to "".
        Get480VLoadByKW = ""
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Get480VLoadByKW.
End Function

'-------------------------------------------------------------------------------
' Procedure : Get480VDeviceValue
' Scope/Type: Private Function
' Purpose   : Returns 480 v device value.
' Parameters:
' maps (Object) - Supplies maps.
' deviceType (String) - Supplies device type.
' mapName (String) - Supplies map name.
' fallback (String) - Supplies fallback; default = "".
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get480VDeviceValue. Returns 480 v device value.
Private Function Get480VDeviceValue(ByVal maps As Object, ByVal deviceType As String, ByVal mapName As String, Optional ByVal fallback As String = "") As String

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for keyText (String).
    Dim keyText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for v (String).
    Dim v As String

    ' [LINE EXPLANATION] Stores the object returned by maps(mapName) in d.
    Set d = maps(mapName)
    ' [LINE EXPLANATION] Sets keyText to DeviceTypeKey(deviceType).
    keyText = DeviceTypeKey(deviceType)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) > 0 And Not d.Exists(keyText) is true.
    If Len(keyText) > 0 And Not d.Exists(keyText) Then
        ' [LINE EXPLANATION] When Left$(keyText, 3) = "VFD" And d.Exists("VFD") is true, executes the inline action keyText = "VFD".
        If Left$(keyText, 3) = "VFD" And d.Exists("VFD") Then keyText = "VFD"
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) > 0 And d.Exists(keyText) is true.
    If Len(keyText) > 0 And d.Exists(keyText) Then
        ' [LINE EXPLANATION] Sets v to Trim$(CStr(d(keyText))).
        v = Trim$(CStr(d(keyText)))
        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(v) > 0 is true.
        If Len(v) > 0 Then
            ' [LINE EXPLANATION] Sets the return value of Get480VDeviceValue to v.
            Get480VDeviceValue = v
        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
        Else
            ' [LINE EXPLANATION] Sets the return value of Get480VDeviceValue to fallback.
            Get480VDeviceValue = fallback
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of Get480VDeviceValue to fallback.
        Get480VDeviceValue = fallback
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Get480VDeviceValue.
End Function

'-------------------------------------------------------------------------------
' Procedure : GetInsidePSUTerm
' Scope/Type: Private Function
' Purpose   : Returns inside PSU term.
' Parameters:
' insideTermMap (Object) - Supplies inside term map.
' terminalText (String) - Supplies terminal text.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetInsidePSUTerm. Returns inside PSU term.
Private Function GetInsidePSUTerm(ByVal insideTermMap As Object, ByVal terminalText As String) As String
    Dim k As String

    k = terminalKey(terminalText)
    If Len(k) > 0 And insideTermMap.Exists(k) Then
        GetInsidePSUTerm = CStr(insideTermMap(k))
    ElseIf Len(Trim$(terminalText)) > 0 And UCase$(Trim$(terminalText)) <> "MISSING" Then
        GetInsidePSUTerm = VFD_GetPSUDescription(terminalText)
    Else
        GetInsidePSUTerm = ""
    End If
End Function

'-------------------------------------------------------------------------------
' Procedure : IsVFDPowerRow
' Scope/Type: Private Function
' Purpose   : Checks whether VFD power row.
' Parameters:
' typ (String) - Supplies typ.
' sysType (String) - Supplies sys type.
' motorVolt (String) - Supplies motor volt.
' motorKW (String) - Supplies motor kw.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function IsVFDPowerRow. Checks whether VFD power row.
Private Function IsVFDPowerRow(ByVal typ As String, ByVal sysType As String, ByVal motorVolt As String, ByVal motorKW As String) As Boolean

    ' [LINE EXPLANATION] Declares procedure-level storage for t (String).
    Dim t As String
    ' [LINE EXPLANATION] Declares procedure-level storage for u (String).
    Dim u As String

    ' [LINE EXPLANATION] Sets t to UCase$(Trim$(typ)).
    t = UCase$(Trim$(typ))
    ' [LINE EXPLANATION] Sets u to UCase$(typ & " " & sysType & " " & motorVolt).
    u = UCase$(typ & " " & sysType & " " & motorVolt)

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(t) = 0 is true.
    If Len(t) = 0 Then
        ' [LINE EXPLANATION] Sets the return value of IsVFDPowerRow to False.
        IsVFDPowerRow = False
        ' [LINE EXPLANATION] Returns immediately from IsVFDPowerRow using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when Left$(t, 3) = "PSU" Or Left$(t, 3) = "PC2" is true.
    If Left$(t, 3) = "PSU" Or Left$(t, 3) = "PC2" Then
        ' [LINE EXPLANATION] Sets the return value of IsVFDPowerRow to False.
        IsVFDPowerRow = False
        ' [LINE EXPLANATION] Returns immediately from IsVFDPowerRow using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, t, "VFD", vbTextCompare) > 0 is true.
    If InStr(1, t, "VFD", vbTextCompare) > 0 Then
        ' [LINE EXPLANATION] Sets the return value of IsVFDPowerRow to True.
        IsVFDPowerRow = True
        ' [LINE EXPLANATION] Returns immediately from IsVFDPowerRow using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(KWKey(motorKW)) > 0 is true.
    If Len(KWKey(motorKW)) > 0 Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, u, "400", vbTextCompare) > 0 Or InStr(1, u, "460", vbTextCompare) > 0 Or InStr(1, u, "480", vbTextCompare) > 0 is true. This logical statement spans 3...
        If InStr(1, u, "400", vbTextCompare) > 0 Or _
           InStr(1, u, "460", vbTextCompare) > 0 Or _
           InStr(1, u, "480", vbTextCompare) > 0 Then
            ' [LINE EXPLANATION] Sets the return value of IsVFDPowerRow to True.
            IsVFDPowerRow = True
            ' [LINE EXPLANATION] Returns immediately from IsVFDPowerRow using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets the return value of IsVFDPowerRow to False.
    IsVFDPowerRow = False

' [LINE EXPLANATION] Ends function IsVFDPowerRow.
End Function

'-------------------------------------------------------------------------------
' Procedure : NormalizeBusName
' Scope/Type: Private Function
' Purpose   : Normalizes bus name.
' Parameters:
' busIn (String) - Supplies bus in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function NormalizeBusName. Normalizes bus name.
Private Function NormalizeBusName(ByVal busIn As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for u (String).
    Dim u As String

    ' [LINE EXPLANATION] Sets u to UCase$(Trim$(busIn)).
    u = UCase$(Trim$(busIn))
    ' [LINE EXPLANATION] Sets u to Replace(u, " ", "").
    u = Replace(u, " ", "")
    ' [LINE EXPLANATION] Sets u to Replace(u, "_", "-").
    u = Replace(u, "_", "-")

    ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, u, "2", vbTextCompare) > 0 is true.
    If InStr(1, u, "2", vbTextCompare) > 0 Then
        ' [LINE EXPLANATION] Sets the return value of NormalizeBusName to "BUS-2".
        NormalizeBusName = "BUS-2"
    ' [LINE EXPLANATION] Tests the next alternative condition: InStr(1, u, "1", vbTextCompare) > 0.
    ElseIf InStr(1, u, "1", vbTextCompare) > 0 Then
        ' [LINE EXPLANATION] Sets the return value of NormalizeBusName to "BUS-1".
        NormalizeBusName = "BUS-1"
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of NormalizeBusName to u.
        NormalizeBusName = u
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function NormalizeBusName.
End Function

'-------------------------------------------------------------------------------
' Procedure : KWKey
' Scope/Type: Private Function
' Purpose   : Calculates or returns kw key.
' Parameters:
' valueIn (Variant) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function KWKey. Calculates or returns kw key.
Private Function KWKey(ByVal valueIn As Variant) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, "KW", "").
    s = Replace(s, "KW", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "K.W.", "").
    s = Replace(s, "K.W.", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "KILOWATT", "").
    s = Replace(s, "KILOWATT", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "HP", "").
    s = Replace(s, "HP", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, s, ",", vbTextCompare) > 0 And InStr(1, s, ".", vbTextCompare) = 0 is true.
    If InStr(1, s, ",", vbTextCompare) > 0 And InStr(1, s, ".", vbTextCompare) = 0 Then
        ' [LINE EXPLANATION] Sets s to Replace(s, ",", ".").
        s = Replace(s, ",", ".")
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets s to Replace(s, ",", "").
        s = Replace(s, ",", "")
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when IsNumeric(s) is true.
    If IsNumeric(s) Then
        ' [LINE EXPLANATION] Sets the return value of KWKey to Format$(CDbl(s), "0.####").
        KWKey = Format$(CDbl(s), "0.####")
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of KWKey to s.
        KWKey = s
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function KWKey.
End Function

'-------------------------------------------------------------------------------
' Procedure : DeviceTypeKey
' Scope/Type: Private Function
' Purpose   : Calculates or returns device type key.
' Parameters:
' valueIn (Variant) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function DeviceTypeKey. Calculates or returns device type key.
Private Function DeviceTypeKey(ByVal valueIn As Variant) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "_", "/").
    s = Replace(s, "_", "/")
    ' [LINE EXPLANATION] Sets s to Replace(s, "-", "/").
    s = Replace(s, "-", "/")

    ' [LINE EXPLANATION] Sets the return value of DeviceTypeKey to s.
    DeviceTypeKey = s

' [LINE EXPLANATION] Ends function DeviceTypeKey.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_RowIdentityKey
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD row identity key.
' Parameters:
' sis (String) - Supplies SIS.
' typ (String) - Supplies typ.
' motorKW (String) - Supplies motor kw.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_RowIdentityKey. Calculates or returns VFD row identity key.
Private Function VFD_RowIdentityKey(ByVal sis As String, ByVal typ As String, ByVal motorKW As String) As String

    VFD_RowIdentityKey = VFD_DeviceIdentityKey(sis)
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_FeederKey
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD feeder key.
' Parameters:
' sis (String) - Supplies SIS.
' typ (String) - Supplies typ.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_FeederKey. Calculates or returns VFD feeder key.
Private Function VFD_FeederKey(ByVal sis As String, ByVal typ As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String
    ' [LINE EXPLANATION] Declares procedure-level storage for t (String).
    Dim t As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(sis)).
    s = UCase$(Trim$(sis))
    ' [LINE EXPLANATION] Sets t to DeviceTypeKey(typ).
    t = DeviceTypeKey(typ)

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(s) = 0 is true.
    If Len(s) = 0 Then
        ' [LINE EXPLANATION] Sets the return value of VFD_FeederKey to "".
        VFD_FeederKey = ""
    ' [LINE EXPLANATION] Tests the next alternative condition: Len(t) = 0.
    ElseIf Len(t) = 0 Then
        ' [LINE EXPLANATION] Sets the return value of VFD_FeederKey to s.
        VFD_FeederKey = s
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of VFD_FeederKey to s & "|" & t.
        VFD_FeederKey = s & "|" & t
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function VFD_FeederKey.
End Function

'-------------------------------------------------------------------------------
' Procedure : TerminalKey
' Scope/Type: Private Function
' Purpose   : Calculates or returns terminal key.
' Parameters:
' valueIn (Variant) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function TerminalKey. Calculates or returns terminal key.
Private Function terminalKey(ByVal valueIn As Variant) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "-", "").
    s = Replace(s, "-", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "_", "").
    s = Replace(s, "_", "")

    ' [LINE EXPLANATION] Sets the return value of TerminalKey to s.
    terminalKey = s

' [LINE EXPLANATION] Ends function TerminalKey.
End Function

'-------------------------------------------------------------------------------
' Procedure : TerminalNumber
' Scope/Type: Private Function
' Purpose   : Calculates or returns terminal number.
' Parameters:
' terminalText (String) - Supplies terminal text.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function TerminalNumber. Calculates or returns terminal number.
Private Function TerminalNumber(ByVal terminalText As String) As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for u (String).
    Dim u As String
    ' [LINE EXPLANATION] Declares procedure-level storage for p (Long).
    Dim p As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for nText (String).
    Dim nText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for ch (String).
    Dim ch As String

    ' [LINE EXPLANATION] Sets u to UCase$(Trim$(terminalText)).
    u = UCase$(Trim$(terminalText))
    ' [LINE EXPLANATION] Sets p to InStr(1, u, "X", vbTextCompare).
    p = InStr(1, u, "X", vbTextCompare)
    ' [LINE EXPLANATION] When p = 0 is true, executes the inline action Exit Function.
    If p = 0 Then Exit Function

    ' [LINE EXPLANATION] Loops i from p + 1 through Len(u).
    For i = p + 1 To Len(u)
        ' [LINE EXPLANATION] Sets ch to mid$(u, i, 1).
        ch = mid$(u, i, 1)
        ' [LINE EXPLANATION] Starts a conditional block that runs when ch Like "#" is true.
        If ch Like "#" Then
            ' [LINE EXPLANATION] Sets nText to nText & ch.
            nText = nText & ch
        ' [LINE EXPLANATION] Tests the next alternative condition: Len(nText) > 0.
        ElseIf Len(nText) > 0 Then
            ' [LINE EXPLANATION] Immediately leaves the current for loop.
            Exit For
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i

    ' [LINE EXPLANATION] When IsNumeric(nText) is true, executes the inline action TerminalNumber = CLng(nText).
    If IsNumeric(nText) Then TerminalNumber = CLng(nText)

' [LINE EXPLANATION] Ends function TerminalNumber.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_BuildHeaderMap
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD build header map.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' headerRow (Long) - Supplies header row; default = 1.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_BuildHeaderMap. Calculates or returns VFD build header map.
Private Function VFD_BuildHeaderMap(ByVal ws As Worksheet, Optional ByVal headerRow As Long = 1) As Object

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for c (Long).
    Dim c As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in d.
    Set d = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets d.CompareMode to vbTextCompare.
    d.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Sets lastCol to VFD_LastUsedCol(ws).
    lastCol = VFD_LastUsedCol(ws)
    ' [LINE EXPLANATION] Starts a conditional block that runs when lastCol = 0 is true.
    If lastCol = 0 Then
        ' [LINE EXPLANATION] Stores the object returned by d in VFD_BuildHeaderMap.
        Set VFD_BuildHeaderMap = d
        ' [LINE EXPLANATION] Returns immediately from VFD_BuildHeaderMap using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Loops c from 1 through lastCol.
    For c = 1 To lastCol
        ' [LINE EXPLANATION] Sets k to VFD_HeaderKey(ws.Cells(headerRow, c).value).
        k = VFD_HeaderKey(ws.Cells(headerRow, c).value)
        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
        If Len(k) > 0 Then
            ' [LINE EXPLANATION] When Not d.Exists(k) is true, executes the inline action d.Add k, c.
            If Not d.Exists(k) Then d.Add k, c
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the c loop to its next iteration.
    Next c

    ' [LINE EXPLANATION] Stores the object returned by d in VFD_BuildHeaderMap.
    Set VFD_BuildHeaderMap = d

' [LINE EXPLANATION] Ends function VFD_BuildHeaderMap.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_HeaderCol
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD header column.
' Parameters:
' HeaderMap (Object) - Supplies header map.
' names() (Variant) - Supplies names.
' Returns   : Variant) As Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_HeaderCol. Calculates or returns VFD header column.
Private Function VFD_HeaderCol(ByVal headerMap As Object, ParamArray names() As Variant) As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String

    ' [LINE EXPLANATION] Loops i from LBound(names) through UBound(names).
    For i = LBound(names) To UBound(names)
        ' [LINE EXPLANATION] Sets k to VFD_HeaderKey(CStr(names(i))).
        k = VFD_HeaderKey(CStr(names(i)))
        ' [LINE EXPLANATION] Starts a conditional block that runs when HeaderMap.Exists(k) is true.
        If headerMap.Exists(k) Then
            ' [LINE EXPLANATION] Sets the return value of VFD_HeaderCol to CLng(HeaderMap(k)).
            VFD_HeaderCol = CLng(headerMap(k))
            ' [LINE EXPLANATION] Returns immediately from VFD_HeaderCol using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i

    ' [LINE EXPLANATION] Sets the return value of VFD_HeaderCol to 0.
    VFD_HeaderCol = 0

' [LINE EXPLANATION] Ends function VFD_HeaderCol.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_FindHeaderInRow
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD find header in row.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' rowNum (Long) - Supplies row number.
' names() (Variant) - Supplies names.
' Returns   : Variant) As Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_FindHeaderInRow. Calculates or returns VFD find header in row.
Private Function VFD_FindHeaderInRow(ByVal ws As Worksheet, ByVal rowNum As Long, ParamArray names() As Variant) As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for maxCol (Long).
    Dim maxCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for c (Long).
    Dim c As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cellKey (String).
    Dim cellKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for targetKey (String).
    Dim targetKey As String

    ' [LINE EXPLANATION] Sets maxCol to VFD_LastUsedCol(ws).
    maxCol = VFD_LastUsedCol(ws)
    ' [LINE EXPLANATION] When maxCol > MAX_SCAN_COLS is true, executes the inline action maxCol = MAX_SCAN_COLS.
    If maxCol > MAX_SCAN_COLS Then maxCol = MAX_SCAN_COLS

    ' [LINE EXPLANATION] Loops c from 1 through maxCol.
    For c = 1 To maxCol
        ' [LINE EXPLANATION] Sets cellKey to VFD_HeaderKey(ws.Cells(rowNum, c).value).
        cellKey = VFD_HeaderKey(ws.Cells(rowNum, c).value)
        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(cellKey) > 0 is true.
        If Len(cellKey) > 0 Then
            ' [LINE EXPLANATION] Loops i from LBound(names) through UBound(names).
            For i = LBound(names) To UBound(names)
                ' [LINE EXPLANATION] Sets targetKey to VFD_HeaderKey(CStr(names(i))).
                targetKey = VFD_HeaderKey(CStr(names(i)))
                ' [LINE EXPLANATION] Starts a conditional block that runs when cellKey = targetKey is true.
                If cellKey = targetKey Then
                    ' [LINE EXPLANATION] Sets the return value of VFD_FindHeaderInRow to c.
                    VFD_FindHeaderInRow = c
                    ' [LINE EXPLANATION] Returns immediately from VFD_FindHeaderInRow using its current return value.
                    Exit Function
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Advances the i loop to its next iteration.
            Next i
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the c loop to its next iteration.
    Next c

    ' [LINE EXPLANATION] Sets the return value of VFD_FindHeaderInRow to 0.
    VFD_FindHeaderInRow = 0

' [LINE EXPLANATION] Ends function VFD_FindHeaderInRow.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_HeaderKey
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD header key.
' Parameters:
' valueIn (Variant) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_HeaderKey. Calculates or returns VFD header key.
Private Function VFD_HeaderKey(ByVal valueIn As Variant) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, Chr$(160), " ").
    s = Replace(s, Chr$(160), " ")
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "_", "").
    s = Replace(s, "_", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "-", "").
    s = Replace(s, "-", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "/", "").
    s = Replace(s, "/", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "(", "").
    s = Replace(s, "(", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ")", "").
    s = Replace(s, ")", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ".", "").
    s = Replace(s, ".", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ":", "").
    s = Replace(s, ":", "")

    ' [LINE EXPLANATION] Sets the return value of VFD_HeaderKey to s.
    VFD_HeaderKey = s

' [LINE EXPLANATION] Ends function VFD_HeaderKey.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_Pick
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD pick.
' Parameters:
' arr (Variant) - Supplies array.
' rowNum (Long) - Supplies row number.
' HeaderMap (Object) - Supplies header map.
' names() (Variant) - Supplies names.
' Returns   : Variant) As String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_Pick. Calculates or returns VFD pick.
Private Function VFD_Pick(ByRef arr As Variant, ByVal rowNum As Long, ByVal headerMap As Object, ParamArray names() As Variant) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for c (Long).
    Dim c As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String
    ' [LINE EXPLANATION] Declares procedure-level storage for v (String).
    Dim v As String

    'Pick the first nonblank value. This allows Control_ID to override
    'SIS_Element_Number, while still falling back when Control_ID is blank.
    ' [LINE EXPLANATION] Loops i from LBound(names) through UBound(names).
    For i = LBound(names) To UBound(names)
        ' [LINE EXPLANATION] Sets k to VFD_HeaderKey(CStr(names(i))).
        k = VFD_HeaderKey(CStr(names(i)))
        ' [LINE EXPLANATION] Starts a conditional block that runs when HeaderMap.Exists(k) is true.
        If headerMap.Exists(k) Then
            ' [LINE EXPLANATION] Sets c to CLng(HeaderMap(k)).
            c = CLng(headerMap(k))
            ' [LINE EXPLANATION] Sets v to Trim$(CStr(VFD_ArrayValue(arr, rowNum, c))).
            v = Trim$(CStr(VFD_ArrayValue(arr, rowNum, c)))
            ' [LINE EXPLANATION] Starts a conditional block that runs when Len(v) > 0 is true.
            If Len(v) > 0 Then
                ' [LINE EXPLANATION] Sets the return value of VFD_Pick to v.
                VFD_Pick = v
                ' [LINE EXPLANATION] Returns immediately from VFD_Pick using its current return value.
                Exit Function
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i

    ' [LINE EXPLANATION] Sets the return value of VFD_Pick to "".
    VFD_Pick = ""

' [LINE EXPLANATION] Ends function VFD_Pick.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_ArrayValue
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD array value.
' Parameters:
' arr (Variant) - Supplies array.
' rowNum (Long) - Supplies row number.
' colNum (Long) - Supplies column number.
' Returns   : Variant.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_ArrayValue. Calculates or returns VFD array value.
Private Function VFD_ArrayValue(ByRef arr As Variant, ByVal rowNum As Long, ByVal colNum As Long) As Variant

    ' [LINE EXPLANATION] Starts a conditional block that runs when rowNum < LBound(arr, 1) Or rowNum > UBound(arr, 1) is true.
    If rowNum < LBound(arr, 1) Or rowNum > UBound(arr, 1) Then
        ' [LINE EXPLANATION] Sets the return value of VFD_ArrayValue to "".
        VFD_ArrayValue = ""
    ' [LINE EXPLANATION] Tests the next alternative condition: colNum < LBound(arr, 2) Or colNum > UBound(arr, 2).
    ElseIf colNum < LBound(arr, 2) Or colNum > UBound(arr, 2) Then
        ' [LINE EXPLANATION] Sets the return value of VFD_ArrayValue to "".
        VFD_ArrayValue = ""
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of VFD_ArrayValue to arr(rowNum, colNum).
        VFD_ArrayValue = arr(rowNum, colNum)
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function VFD_ArrayValue.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_LastUsedRow
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD last used row.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_LastUsedRow. Calculates or returns VFD last used row.
Private Function VFD_LastUsedRow(ByVal ws As Worksheet) As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for f (Range).
    Dim f As Range

    ' [LINE EXPLANATION] Stores the object returned by ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByR... in f.
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    ' [LINE EXPLANATION] Starts a conditional block that runs when f Is Nothing is true.
    If f Is Nothing Then
        ' [LINE EXPLANATION] Sets the return value of VFD_LastUsedRow to 1.
        VFD_LastUsedRow = 1
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of VFD_LastUsedRow to f.Row.
        VFD_LastUsedRow = f.Row
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function VFD_LastUsedRow.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_LastUsedCol
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD last used column.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_LastUsedCol. Calculates or returns VFD last used column.
Private Function VFD_LastUsedCol(ByVal ws As Worksheet) As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for f (Range).
    Dim f As Range

    ' [LINE EXPLANATION] Stores the object returned by ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByC... in f.
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    ' [LINE EXPLANATION] Starts a conditional block that runs when f Is Nothing is true.
    If f Is Nothing Then
        ' [LINE EXPLANATION] Sets the return value of VFD_LastUsedCol to 0.
        VFD_LastUsedCol = 0
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of VFD_LastUsedCol to f.Column.
        VFD_LastUsedCol = f.Column
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function VFD_LastUsedCol.
End Function

'-------------------------------------------------------------------------------
' Procedure : VFD_GetSheetIfExists
' Scope/Type: Private Function
' Purpose   : Calculates or returns VFD get sheet if exists.
' Parameters:
' sheetName (String) - Supplies sheet name.
' Returns   : Worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function VFD_GetSheetIfExists. Calculates or returns VFD get sheet if exists.
Private Function VFD_GetSheetIfExists(ByVal sheetName As String) As Worksheet

    ' [LINE EXPLANATION] Temporarily suppresses runtime errors so the next optional or cleanup operation can be attempted safely; Err should be checked or normal handling restored afterward.
    On Error Resume Next
    ' [LINE EXPLANATION] Stores the object returned by ThisWorkbook.Worksheets(sheetName) in VFD_GetSheetIfExists.
    Set VFD_GetSheetIfExists = ThisWorkbook.Worksheets(sheetName)
    ' [LINE EXPLANATION] Turns off the temporary error handler and restores normal VBA error behavior.
    On Error GoTo 0

' [LINE EXPLANATION] Ends function VFD_GetSheetIfExists.
End Function

