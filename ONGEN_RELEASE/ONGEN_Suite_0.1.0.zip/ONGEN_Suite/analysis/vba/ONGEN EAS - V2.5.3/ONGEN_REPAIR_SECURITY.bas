Attribute VB_Name = "ONGEN_REPAIR_SECURITY"
Option Explicit

'===============================================================================
' ONGEN SECURITY / NAVIGATION BUTTON REPAIR
'
' MAIN COMMAND
'   ONGEN_REPAIR_SECURITY_AND_NAV_BUTTONS
'
' Repairs workbook-qualified OnAction links for:
'   - Admin / Recovery panel
'   - MAIN Sheet Launcher button
'   - Return To Home buttons
'   - Sheet Launcher buttons
'   - Phase 0 structural controls
'
' Also provides:
'   ONGEN_AUDIT_SECURITY_AND_NAV_BUTTONS
'===============================================================================

Private Const MAIN_SHEET As String = "MAIN"
Private Const AUDIT_SHEET As String = "ADMIN_BUTTON_AUDIT"

Public Sub ONGEN_REPAIR_SECURITY_AND_NAV_BUTTONS()
    On Error GoTo EH

    Application.ScreenUpdating = False
    Application.EnableEvents = False

    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(MAIN_SHEET)

    'Admin / Recovery panel.
    ONGEN_LinkShape ws, "ONGEN_ADMIN_LOGIN_BTN", "ONGEN_ADMIN_LOGIN"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_SHEET_LAUNCHER_BTN", "NAV_Open_Worksheet_Launcher"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_LOGOUT_BTN", "ONGEN_ADMIN_LOGOUT"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_CHANGE_PASSWORD_BTN", "ONGEN_ADMIN_CHANGE_PASSWORD"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_REPAIR_BTN", "ONGEN_RESTORE_REFERENCE_MAIN"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_RELOAD_UI_BTN", "ONGEN_RELOAD_ALL_UI_BUTTONS"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_VFD_SETUP_BTN", "ONGEN_VFD_SETUP"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_INSTALL_UI_BTN", "ONGEN_EAS_INSTALL_UI"
    ONGEN_LinkShape ws, "ONGEN_ADMIN_CLEAR_BTN", "ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE"

    'MAIN worksheet launcher duplicate/shortcut.
    ONGEN_LinkShape ws, "ONGEN_UI_BTN_0B_Sheet_Launcher", "NAV_Open_Worksheet_Launcher"

    'Phase 0 structural controls.
    ONGEN_LinkShape ws, "ONGEN_UI_BTN_0A_Rebuild_MAIN", "ONGEN_REBUILD_MAIN_FROM_SCRATCH"
    ONGEN_LinkShape ws, "ONGEN_UI_BTN_0E_Verify___Repair_Buttons", "ONGEN_VERIFY_AND_REPAIR_MAIN_BUTTONS"

    'Repair navigation buttons on every worksheet.
    ONGEN_RepairWorksheetNavigationButtons

    'Create an explicit audit sheet for the security/admin layer.
    ONGEN_AUDIT_SECURITY_AND_NAV_BUTTONS

    'Reapply User Mode visibility/protection.
    On Error Resume Next
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_USER_MODE", False
    On Error GoTo EH

    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN security and navigator button links repaired.", _
           vbInformation, "ONGEN Button Repair"
    Exit Sub

EH:
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "Button repair stopped." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN Button Repair"
End Sub

Private Sub ONGEN_RepairWorksheetNavigationButtons()
    Dim ws As Worksheet

    For Each ws In ThisWorkbook.Worksheets
        If StrComp(ws.Name, MAIN_SHEET, vbTextCompare) <> 0 Then
            ONGEN_LinkShape ws, "btnReturnToMAIN", "NAV_Return_To_MAIN"
            ONGEN_LinkShape ws, "btnWorksheetLauncher", "NAV_Open_Worksheet_Launcher"
        End If
    Next ws
End Sub

Private Sub ONGEN_LinkShape(ByVal ws As Worksheet, ByVal shapeName As String, ByVal macroName As String)
    Dim shp As Shape

    On Error Resume Next
    Set shp = ws.Shapes(shapeName)
    On Error GoTo 0

    If shp Is Nothing Then Exit Sub

    On Error Resume Next
    shp.OnAction = "'" & ThisWorkbook.Name & "'!" & macroName
    On Error GoTo 0
End Sub

Public Sub ONGEN_AUDIT_SECURITY_AND_NAV_BUTTONS()
    Dim wsAudit As Worksheet
    Set wsAudit = ONGEN_GetOrCreateAuditSheet

    wsAudit.Cells.Clear

    wsAudit.Range("A1:F1").value = Array( _
        "Worksheet", _
        "Shape / Control", _
        "Expected Macro", _
        "Assigned OnAction", _
        "Status", _
        "Audit Time" _
    )

    Dim rowOut As Long
    rowOut = 2

    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(MAIN_SHEET)

    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_LOGIN_BTN", "ONGEN_ADMIN_LOGIN"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_SHEET_LAUNCHER_BTN", "NAV_Open_Worksheet_Launcher"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_LOGOUT_BTN", "ONGEN_ADMIN_LOGOUT"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_CHANGE_PASSWORD_BTN", "ONGEN_ADMIN_CHANGE_PASSWORD"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_REPAIR_BTN", "ONGEN_RESTORE_REFERENCE_MAIN"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_RELOAD_UI_BTN", "ONGEN_RELOAD_ALL_UI_BUTTONS"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_VFD_SETUP_BTN", "ONGEN_VFD_SETUP"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_INSTALL_UI_BTN", "ONGEN_EAS_INSTALL_UI"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_ADMIN_CLEAR_BTN", "ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_UI_BTN_0B_Sheet_Launcher", "NAV_Open_Worksheet_Launcher"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_UI_BTN_0A_Rebuild_MAIN", "ONGEN_REBUILD_MAIN_FROM_SCRATCH"
    ONGEN_AuditOne wsAudit, rowOut, ws, "ONGEN_UI_BTN_0E_Verify___Repair_Buttons", "ONGEN_VERIFY_AND_REPAIR_MAIN_BUTTONS"

    For Each ws In ThisWorkbook.Worksheets
        If StrComp(ws.Name, MAIN_SHEET, vbTextCompare) <> 0 Then
            ONGEN_AuditOne wsAudit, rowOut, ws, "btnReturnToMAIN", "NAV_Return_To_MAIN"
            ONGEN_AuditOne wsAudit, rowOut, ws, "btnWorksheetLauncher", "NAV_Open_Worksheet_Launcher"
        End If
    Next ws

    With wsAudit.Range("A1:F1")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
    End With

    wsAudit.Columns("A:F").AutoFit
End Sub

Private Sub ONGEN_AuditOne( _
    ByVal wsAudit As Worksheet, _
    ByRef rowOut As Long, _
    ByVal sourceSheet As Worksheet, _
    ByVal shapeName As String, _
    ByVal expectedMacro As String)

    Dim shp As Shape
    Dim assigned As String
    Dim statusText As String

    On Error Resume Next
    Set shp = sourceSheet.Shapes(shapeName)
    On Error GoTo 0

    If shp Is Nothing Then
        statusText = "MISSING CONTROL"
        assigned = ""
    Else
        On Error Resume Next
        assigned = shp.OnAction
        On Error GoTo 0

        If ONGEN_NormalizeMacroName(assigned) = UCase$(expectedMacro) Then
            statusText = "OK"
        ElseIf Len(Trim$(assigned)) = 0 Then
            statusText = "NO CODE LINK"
        Else
            statusText = "WRONG LINK"
        End If
    End If

    wsAudit.Cells(rowOut, 1).value = sourceSheet.Name
    wsAudit.Cells(rowOut, 2).value = shapeName
    wsAudit.Cells(rowOut, 3).value = expectedMacro
    wsAudit.Cells(rowOut, 4).value = assigned
    wsAudit.Cells(rowOut, 5).value = statusText
    wsAudit.Cells(rowOut, 6).value = Now

    rowOut = rowOut + 1
End Sub

Private Function ONGEN_NormalizeMacroName(ByVal actionText As String) As String
    Dim s As String
    Dim p As Long

    s = Trim$(actionText)

    'Strip workbook qualifier: 'Book.xlsm'!Macro
    p = InStrRev(s, "!")
    If p > 0 Then s = mid$(s, p + 1)

    s = Replace$(s, "'", "")
    s = Replace$(s, """", "")
    s = Trim$(s)

    ONGEN_NormalizeMacroName = UCase$(s)
End Function

Private Function ONGEN_GetOrCreateAuditSheet() As Worksheet
    On Error Resume Next
    Set ONGEN_GetOrCreateAuditSheet = ThisWorkbook.Worksheets(AUDIT_SHEET)
    On Error GoTo 0

    If ONGEN_GetOrCreateAuditSheet Is Nothing Then
        On Error Resume Next
        ThisWorkbook.Unprotect Password:="ONGEN-STRUCTURE-2026"
        On Error GoTo 0

        Set ONGEN_GetOrCreateAuditSheet = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ONGEN_GetOrCreateAuditSheet.Name = AUDIT_SHEET
    End If
End Function
