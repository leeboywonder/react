Attribute VB_Name = "mod08_Label_List_Exporter"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod08_Label_List_Exporter
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : 24V branch-suffix functional update applied.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : mod08_Label_List_Exporter
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Static procedure, declaration, and public-name audit completed.
' Notes         : Logic retained from the uploaded workbook; comments preserved and suite header standardized.
'-------------------------------------------------------------------------------

Option Explicit

'===============================================================================
' ONGEN LABEL LIST REPORT EXPORTER
' Module Name    : mod08_Label_List_Exporter
' Release        : V16.2-R9.1
' Author         : Lee Pierre, Principal Electrical Engineer
' Purpose        : Exports IO device, network, and power label registers into a
'                  separate .xlsx workbook without adding report worksheets to
'                  the source ONGEN workbook.
'
' MAIN COMMANDS
'   Export_ONGEN_Label_List_Report
'       Creates the external label report.
'
'   LABEL_Install_MAIN_Button
'       Installs or repairs a standalone MAIN-sheet export button. This command
'       is useful when the complete V2.4 UI module is not installed.
'
' EXPORTED WORKSHEETS
'   README
'   ALL LABELS
'   IO DEVICE LABELS
'   NETWORK LABELS
'   POWER LABELS
'
' LABEL RULES
'   Physical cable IDs: functional PREFIX-#### permanent sequence
'   Panel, SIS sequence, From/To, terminals, route, and sheet remain separate fields
'   IO labels         : Device-BlockID-Port
'
' The cable sequence resets independently for each package and type code.
' Format$(sequence, "000") uses three minimum digits and automatically expands
' beyond 999 when necessary.
'===============================================================================

Private Const LABEL_MAIN_SHEET As String = "MAIN"
Private Const LABEL_BUTTON_NAME As String = "ONGEN_LABEL_EXPORT_BUTTON"
Private Const LABEL_BUTTON_CAPTION As String = "Export IO / Network / Power Labels"
Private Const LABEL_REPORT_PREFIX As String = "ONGEN_Label_List_Report_"

Private Const LABEL_SHEET_README As String = "README"
Private Const LABEL_SHEET_ALL As String = "ALL LABELS"
Private Const LABEL_SHEET_IO As String = "IO DEVICE LABELS"
Private Const LABEL_SHEET_NETWORK As String = "NETWORK LABELS"
Private Const LABEL_SHEET_POWER As String = "POWER LABELS"


'===============================================================================
' PUBLIC ENTRY POINTS
'===============================================================================

Public Sub Export_ONGEN_Label_List_Report()
    Dim ioRows As Collection
    Dim networkRows As Collection
    Dim powerRows As Collection
    Dim allRows As Collection
    Dim cableCounters As Object

    Dim outputWorkbook As Workbook
    Dim savePath As Variant

    Dim previousCalculation As XlCalculation
    Dim previousScreenUpdating As Boolean
    Dim previousEnableEvents As Boolean
    Dim previousDisplayAlerts As Boolean
    Dim previousStatusBar As Variant

    Dim currentStage As String
    Dim errorNumber As Long
    Dim errorDescription As String
    Dim errorSource As String
    Dim workbookWasCreated As Boolean

    On Error GoTo EH

    ' Identify the operation currently running so any failure message points to
    ' the exact export stage rather than displaying only a generic error.
    currentStage = "Preserving Excel settings"

    ' Preserve the user's current Excel application settings.
    previousCalculation = Application.Calculation
    previousScreenUpdating = Application.ScreenUpdating
    previousEnableEvents = Application.EnableEvents
    previousDisplayAlerts = Application.DisplayAlerts
    previousStatusBar = Application.StatusBar

    currentStage = "Preparing Excel for export"

    ' Improve export speed and prevent workbook events from running during build.
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "ONGEN: Collecting IO, network, and power labels..."

    currentStage = "Creating label collections"
    ONGEN_CableID_BeginRun

    ' Create collections that hold the exported report rows.
    Set ioRows = New Collection
    Set networkRows = New Collection
    Set powerRows = New Collection
    Set allRows = New Collection

    ' Create a late-bound dictionary so no Microsoft Scripting Runtime reference
    ' is required in the workbook.
    Set cableCounters = CreateObject("Scripting.Dictionary")
    cableCounters.CompareMode = vbTextCompare

    currentStage = "Collecting IO device labels"

    ' Collect IO-device labels from IO_DEVICE_LIST.
    LABEL_CollectIOLabels ioRows, allRows

    currentStage = "Collecting network labels"

    ' Collect network labels from topology sheets or NETWORK_AUTO_SUMMARY.
    LABEL_CollectNetworkLabels networkRows, allRows, cableCounters

    currentStage = "Collecting power labels"

    ' Collect 24VDC and 480VAC power labels.
    LABEL_CollectPowerLabels powerRows, allRows, cableCounters

    currentStage = "Requesting the report save location"

    ' Ask the user where the external report should be saved.
    savePath = LABEL_GetSavePath()

    ' GetSaveAsFilename returns Boolean False when the user selects Cancel.
    If VarType(savePath) = vbBoolean Then
        If savePath = False Then GoTo CleanExit
    End If

    ' Add the required extension when the user omits it.
    If LCase$(Right$(CStr(savePath), 5)) <> ".xlsx" Then
        savePath = CStr(savePath) & ".xlsx"
    End If

    currentStage = "Checking the selected report path"

    ' Never overwrite an existing report without explicit user approval.
    If Len(Dir$(CStr(savePath), vbNormal Or vbHidden Or vbSystem Or vbReadOnly)) > 0 Then
        If MsgBox( _
            "The selected report file already exists." & vbCrLf & vbCrLf & _
            CStr(savePath) & vbCrLf & vbCrLf & _
            "Replace the existing file?", _
            vbYesNo + vbQuestion + vbDefaultButton2, _
            "Replace Existing Label Report?") <> vbYes Then

            GoTo CleanExit
        End If
    End If

    currentStage = "Creating the external workbook"
    Application.StatusBar = "ONGEN: Building the external label report..."

    ' Create a new workbook containing one initial worksheet.
    Set outputWorkbook = Workbooks.Add(xlWBATWorksheet)
    workbookWasCreated = True

    currentStage = "Building and formatting report worksheets"

    ' Build and format every external report worksheet.
    LABEL_BuildExportWorkbook outputWorkbook, ioRows, networkRows, powerRows, allRows

    currentStage = "Saving the external workbook"

    'Remove any ONGEN navigation controls from the external report only.
    NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook outputWorkbook

    ' Save the report as a standard macro-free .xlsx workbook.
    outputWorkbook.SaveAs fileName:=CStr(savePath), FileFormat:=xlOpenXMLWorkbook

    currentStage = "Opening the exported report summary"

    ' Keep the exported workbook open and activate its summary worksheet.
    outputWorkbook.Worksheets(LABEL_SHEET_README).Activate

    MsgBox "The ONGEN label list report was exported successfully." & vbCrLf & vbCrLf & _
           "IO device labels: " & Format$(ioRows.count, "#,##0") & vbCrLf & _
           "Network labels: " & Format$(networkRows.count, "#,##0") & vbCrLf & _
           "Power labels: " & Format$(powerRows.count, "#,##0") & vbCrLf & _
           "Combined labels: " & Format$(allRows.count, "#,##0") & vbCrLf & vbCrLf & _
           "Saved to:" & vbCrLf & CStr(savePath), _
           vbInformation, _
           "ONGEN Label List Export"

CleanExit:
    ' Restore all Excel application settings even when the user cancels or an
    ' error occurs. Each assignment is protected so one restoration issue does
    ' not prevent the remaining settings from being restored.
    On Error Resume Next
    Application.StatusBar = previousStatusBar
    Application.Calculation = previousCalculation
    Application.DisplayAlerts = previousDisplayAlerts
    Application.EnableEvents = previousEnableEvents
    Application.ScreenUpdating = previousScreenUpdating
    On Error GoTo 0
    Exit Sub

EH:
    ' Capture the real VBA error before running any cleanup statements.
    ' The previous R9 handler cleared Err and therefore displayed Error 0.
    errorNumber = Err.Number
    errorDescription = Err.description
    errorSource = Err.source

    ' Close only an unfinished new workbook. A successfully saved report remains
    ' open so the user's completed output is never discarded.
    On Error Resume Next
    If workbookWasCreated Then
        If Not outputWorkbook Is Nothing Then
            If Len(outputWorkbook.Path) = 0 Then
                outputWorkbook.Close SaveChanges:=False
            End If
        End If
    End If
    On Error GoTo 0

    MsgBox "The ONGEN label list report could not be exported." & vbCrLf & vbCrLf & _
           "Stage: " & currentStage & vbCrLf & _
           "Error " & CStr(errorNumber) & ": " & errorDescription & vbCrLf & _
           "Source: " & errorSource, _
           vbCritical, _
           "ONGEN Label List Export"

    Resume CleanExit
End Sub


Public Sub Build_ONGEN_Combined_Label_List()
    Dim ioRows As Collection, networkRows As Collection, powerRows As Collection, allRows As Collection
    Dim cableCounters As Object
    Dim ws As Worksheet

    On Error GoTo EH
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    ONGEN_CableID_BeginRun
    Set ioRows = New Collection
    Set networkRows = New Collection
    Set powerRows = New Collection
    Set allRows = New Collection
    Set cableCounters = CreateObject("Scripting.Dictionary")
    cableCounters.CompareMode = vbTextCompare

    LABEL_CollectIOLabels ioRows, allRows
    LABEL_CollectNetworkLabels networkRows, allRows, cableCounters
    LABEL_CollectPowerLabels powerRows, allRows, cableCounters

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("CABLE_TAG_OUTPUT")
    On Error GoTo EH
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = "CABLE_TAG_OUTPUT"
    Else
        ws.Cells.Clear
    End If

    LABEL_WriteReportSheet ws, "ONGEN Combined Label Register - Option A Functional Cable IDs", _
        Array("Label ID", "Category", "Type Code", "Package", "Area", "Panel", _
              "SwitchGroup", "From", "From Terminal", "To", "To Terminal", _
              "Device / Route Type", "Port / Bus", "Load / Length", "Description", _
              "Source Sheet", "Status", "Notes", "Quantity"), allRows, "ONGENAllLabels"

    MsgBox "Step 15H refreshed CABLE_TAG_OUTPUT inside this workbook." & vbCrLf & _
           "Combined records: " & Format$(allRows.count, "#,##0") & vbCrLf & _
           "Permanent cable tags use the approved PREFIX-#### functional format (WIO/WSF/WNET/WDC/WPWR/WMTR).", _
           vbInformation, "ONGEN Step 15H"
CleanExit:
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Exit Sub
EH:
    MsgBox "Step 15H combined label list failed:" & vbCrLf & Err.Number & " - " & Err.description, _
           vbCritical, "ONGEN Step 15H"
    Resume CleanExit
End Sub

Public Sub LABEL_Install_MAIN_Button()
    Dim ws As Worksheet
    Dim buttonShape As Shape
    Dim topPosition As Double
    Dim leftPosition As Double
    Dim i As Long

    On Error GoTo EH

    ' Get the existing MAIN worksheet.
    Set ws = ThisWorkbook.Worksheets(LABEL_MAIN_SHEET)

    ' Delete the previous standalone button so its caption and macro assignment
    ' are always repaired.
    On Error Resume Next
    ws.Shapes(LABEL_BUTTON_NAME).Delete
    On Error GoTo EH

    ' Place the standalone button below all existing shapes on MAIN.
    leftPosition = 28
    topPosition = 24

    For i = 1 To ws.Shapes.count
        If ws.Shapes(i).Top + ws.Shapes(i).Height + 18 > topPosition Then
            topPosition = ws.Shapes(i).Top + ws.Shapes(i).Height + 18
        End If
    Next i

    ' Create a rounded rectangular button.
    Set buttonShape = ws.Shapes.AddShape( _
        msoShapeRoundedRectangle, _
        leftPosition, _
        topPosition, _
        235, _
        34)

    ' Assign a stable name that is not removed by the ONGEN UI shape cleanup.
    buttonShape.Name = LABEL_BUTTON_NAME

    ' Qualify the macro assignment with this workbook's name.
    buttonShape.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & _
                           "'!Export_ONGEN_Label_List_Report"

    ' Apply the ONGEN dark-blue button appearance.
    With buttonShape
        .Fill.ForeColor.RGB = RGB(31, 78, 121)
        .Fill.Transparency = 0
        .Line.ForeColor.RGB = RGB(255, 255, 255)
        .Line.Weight = 1
        .Shadow.Visible = msoFalse
        .Placement = xlFreeFloating
    End With

    ' Write the visible caption through both Excel text interfaces. Using both
    ' interfaces prevents blank shape text on some Office installations.
    On Error Resume Next

    With buttonShape.TextFrame2
        .TextRange.text = LABEL_BUTTON_CAPTION
        .TextRange.Font.Name = "Arial"
        .TextRange.Font.Size = 9
        .TextRange.Font.Bold = msoTrue
        .TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
        .HorizontalAnchor = msoAnchorCenter
        .VerticalAnchor = msoAnchorMiddle
        .MarginLeft = 4
        .MarginRight = 4
        .MarginTop = 1
        .MarginBottom = 1
    End With

    With buttonShape.TextFrame
        .Characters.text = LABEL_BUTTON_CAPTION
        .HorizontalAlignment = xlHAlignCenter
        .VerticalAlignment = xlVAlignCenter

        With .Characters.Font
            .Name = "Arial"
            .Size = 9
            .Bold = True
            .Color = RGB(255, 255, 255)
        End With
    End With

    On Error GoTo EH

    MsgBox "The MAIN button was installed successfully:" & vbCrLf & _
           LABEL_BUTTON_CAPTION, _
           vbInformation, _
           "ONGEN Label Export Button"
    Exit Sub

EH:
    MsgBox "The label export button could not be installed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbExclamation, _
           "ONGEN Label Export Button"
End Sub


'===============================================================================
' IO DEVICE LABEL COLLECTION
'===============================================================================

Private Sub LABEL_CollectIOLabels(ByRef ioRows As Collection, ByRef allRows As Collection)
    Dim ws As Worksheet
    Dim headerMap As Object, aggregate As Object, rec As Object
    Dim lastRow As Long, lastCol As Long, rowNumber As Long
    Dim colCableGroup As Long
    Dim deviceName As String, deviceType As String, signalType As String, signalName As String
    Dim portLocation As String, ioBlock As String, blockID As String, switchGroup As String
    Dim panel As String, areaNumber As String, notesText As String, cableGroup As String
    Dim identityToken As String, key As String, rowClass As String, cableType As String
    Dim packageCode As String, cableID As String, statusText As String, dictionaryKey As Variant

    On Error GoTo EH

    If Not LABEL_WorksheetExists("IO_DEVICE_LIST", ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets("IO_DEVICE_LIST")
    lastRow = LABEL_LastUsedRow(ws)
    lastCol = LABEL_LastUsedColumn(ws)
    If lastRow < 2 Or lastCol < 1 Then Exit Sub

    Set headerMap = LABEL_CreateHeaderMap(ws, 1, lastCol)
    colCableGroup = LABEL_FindHeaderColumn(headerMap, Array("PHYSICAL_CABLE_GROUP", "CABLE_GROUP", "CABLE GROUP", "CABLE_ID_GROUP"))

    Set aggregate = CreateObject("Scripting.Dictionary")
    aggregate.CompareMode = vbTextCompare

    For rowNumber = 2 To lastRow
        deviceName = LABEL_CellByHeader(ws, rowNumber, headerMap, "DEVICE", "DEVICE NAME", "SIS_SEQUENCE")
        deviceType = LABEL_CellByHeader(ws, rowNumber, headerMap, "DEVICE TYPE", "ITEM TYPE", "TYPE")
        signalType = LABEL_CellByHeader(ws, rowNumber, headerMap, "TYPE", "SIGNAL TYPE", "CHANNEL TYPE")
        signalName = LABEL_CellByHeader(ws, rowNumber, headerMap, "SIGNAL NAME", "SIGNAL")
        portLocation = LABEL_CellByHeader(ws, rowNumber, headerMap, "PORT LOCATION", "PORT")
        ioBlock = LABEL_CellByHeader(ws, rowNumber, headerMap, "IO BLOCK", "MODULE")
        blockID = LABEL_CellByHeader(ws, rowNumber, headerMap, "BLOCK ID", "BLOCKID")
        switchGroup = LABEL_CellByHeader(ws, rowNumber, headerMap, "PWG", "SWITCHGROUP", "POWER GROUP")
        panel = LABEL_CellByHeader(ws, rowNumber, headerMap, "PANEL", "PNL")
        areaNumber = LABEL_CellByHeader(ws, rowNumber, headerMap, "LOCATION", "AREA_NUMBER", "AREA")
        notesText = LABEL_CellByHeader(ws, rowNumber, headerMap, "NOTES", "DESCRIPTION")
        If Len(deviceName) = 0 And Len(blockID) = 0 And Len(portLocation) = 0 Then GoTo NextIORow

        If colCableGroup > 0 Then cableGroup = Trim$(CStr(ws.Cells(rowNumber, colCableGroup).Value2)) Else cableGroup = vbNullString
        If Len(cableGroup) > 0 Then
            identityToken = "GROUP:" & cableGroup
        Else
            identityToken = "BLOCK:" & blockID
        End If

        key = UCase$(panel & "|" & deviceName & "|" & identityToken)
        If Not aggregate.Exists(key) Then
            Set rec = CreateObject("Scripting.Dictionary")
            rec.CompareMode = vbTextCompare
            rec("DEVICE") = deviceName
            rec("PANEL") = panel
            rec("AREA") = areaNumber
            rec("SWITCHGROUP") = switchGroup
            rec("IDENTITY") = identityToken
            rec("CLASS") = vbNullString
            rec("DEVICE_TYPE") = vbNullString
            rec("SIGNAL_TYPE") = vbNullString
            rec("SIGNAL_NAME") = vbNullString
            rec("IO_BLOCK") = vbNullString
            rec("BLOCK_ID") = vbNullString
            rec("PORTS") = vbNullString
            rec("NOTES") = vbNullString
            rec("SOURCE_ROWS") = vbNullString
            aggregate.Add key, rec
        Else
            Set rec = aggregate(key)
        End If

        LABEL_AppendUniqueDictText rec, "DEVICE_TYPE", deviceType, " / "
        LABEL_AppendUniqueDictText rec, "SIGNAL_TYPE", signalType, " / "
        LABEL_AppendUniqueDictText rec, "SIGNAL_NAME", signalName, " / "
        LABEL_AppendUniqueDictText rec, "IO_BLOCK", ioBlock, " / "
        LABEL_AppendUniqueDictText rec, "BLOCK_ID", blockID, " / "
        LABEL_AppendUniqueDictText rec, "PORTS", LABEL_NormalizePort(portLocation), " / "
        LABEL_AppendUniqueDictText rec, "NOTES", notesText, " / "
        LABEL_AppendUniqueDictText rec, "SOURCE_ROWS", CStr(rowNumber), ","
        If Len(CStr(rec("AREA"))) = 0 Then rec("AREA") = areaNumber
        If Len(CStr(rec("SWITCHGROUP"))) = 0 Then rec("SWITCHGROUP") = switchGroup

        'Classifier priority:
        '  1) Explicit ONGEN IO/S or IO/D abbreviation.
        '  2) Semantic evidence from signal/device fields (S_IN, S_OUT, EST, EPC,
        '     safety/standard descriptions, DI/DO/AI/AO).
        'Part-number and hardware-model fields are intentionally NOT passed here.
        rowClass = LABEL_IOCableRoleFromEvidence( _
                   blockID & "|" & deviceType & "|" & signalType & "|" & _
                   signalName & "|" & deviceName & "|" & notesText)
        If rowClass = "SAF" Then
            rec("CLASS") = "SAF"
        ElseIf rowClass = "IO" And Len(CStr(rec("CLASS"))) = 0 Then
            rec("CLASS") = "IO"
        End If
NextIORow:
    Next rowNumber

    For Each dictionaryKey In aggregate.keys
        Set rec = aggregate(dictionaryKey)
        cableType = CStr(rec("CLASS"))
        If cableType = "SAF" Then
            statusText = "OK - IO/S SAFETY CABLE"
        ElseIf cableType = "IO" Then
            statusText = "OK - IO/D STANDARD CABLE"
        Else
            cableType = "GEN"
            statusText = "CHECK - I/O CLASSIFICATION EVIDENCE NOT FOUND"
        End If

        panel = CStr(rec("PANEL"))
        areaNumber = CStr(rec("AREA"))
        packageCode = panel
        If Len(packageCode) = 0 And Len(areaNumber) > 0 Then packageCode = "AREA-" & areaNumber
        If Len(packageCode) = 0 Then packageCode = "UNASSIGNED"

        cableID = ONGEN_CableID_Get( _
            cableType & "|" & packageCode & "|" & CStr(rec("DEVICE")) & "|" & CStr(rec("IDENTITY")), _
            vbNullString, cableType)

        ioRows.Add Array( _
            cableID, _
            IIf(cableType = "SAF", "SAFETY IO CABLE", IIf(cableType = "IO", "STANDARD IO CABLE", "GENERAL CABLE")), _
            packageCode, areaNumber, panel, CStr(rec("SWITCHGROUP")), _
            CStr(rec("DEVICE")), CStr(rec("DEVICE_TYPE")), CStr(rec("SIGNAL_TYPE")), _
            CStr(rec("SIGNAL_NAME")), CStr(rec("IO_BLOCK")), CStr(rec("BLOCK_ID")), _
            CStr(rec("PORTS")), CStr(rec("DEVICE")), _
            LABEL_JoinNonBlank(CStr(rec("BLOCK_ID")), CStr(rec("PORTS")), vbNullString, " "), _
            IIf(cableType = "SAF", "Safety I/O cable", IIf(cableType = "IO", "Standard / non-safety I/O cable", "General / unclassified cable")), _
            CStr(rec("NOTES")), ws.Name, statusText, 1)

        LABEL_AddAllRow allRows, _
            cableID, _
            IIf(cableType = "SAF", "SAFETY IO CABLE", IIf(cableType = "IO", "STANDARD IO CABLE", "GENERAL CABLE")), _
            cableType, packageCode, areaNumber, panel, CStr(rec("SWITCHGROUP")), _
            CStr(rec("DEVICE")), vbNullString, CStr(rec("BLOCK_ID")), CStr(rec("PORTS")), _
            CStr(rec("DEVICE_TYPE")), CStr(rec("SIGNAL_TYPE")), vbNullString, _
            IIf(cableType = "SAF", "Safety I/O cable", IIf(cableType = "IO", "Standard / non-safety I/O cable", "General / unclassified cable")), _
            ws.Name, statusText, CStr(rec("NOTES")), 1
    Next dictionaryKey

    Exit Sub
EH:
    Err.Raise Err.Number, "LABEL_CollectIOLabels", Err.description
End Sub
Private Function LABEL_IOCableRoleFromEvidence(ByVal sourceText As String) As String
    LABEL_IOCableRoleFromEvidence = ONGEN_CableID_IOCableRoleFromEvidence(sourceText)
End Function
Private Function LABEL_HasCableEvidenceToken(ByVal sourceText As String, _
                                             ByVal tokenText As String) As Boolean
    Dim s As String
    s = UCase$(sourceText)
    s = Replace(s, "-", " ")
    s = Replace(s, "_", " ")
    s = Replace(s, "/", " ")
    s = Replace(s, "\", " ")
    s = Replace(s, ".", " ")
    s = Replace(s, ",", " ")
    s = Replace(s, ":", " ")
    s = Replace(s, ";", " ")
    s = Replace(s, "(", " ")
    s = Replace(s, ")", " ")
    s = Replace(s, "[", " ")
    s = Replace(s, "]", " ")
    s = Replace(s, "|", " ")
    Do While InStr(1, s, "  ", vbBinaryCompare) > 0
        s = Replace(s, "  ", " ")
    Loop
    s = " " & Trim$(s) & " "
    LABEL_HasCableEvidenceToken = (InStr(1, s, " " & UCase$(Trim$(tokenText)) & " ", vbBinaryCompare) > 0)
End Function

Private Sub LABEL_AppendUniqueDictText(ByVal rec As Object, ByVal fieldName As String, _
                                       ByVal valueText As String, Optional ByVal separatorText As String = " / ")
    Dim cleanValue As String, currentText As String, paddedList As String
    cleanValue = Trim$(valueText)
    If Len(cleanValue) = 0 Then Exit Sub
    currentText = CStr(rec(fieldName))
    paddedList = separatorText & currentText & separatorText
    If InStr(1, paddedList, separatorText & cleanValue & separatorText, vbTextCompare) = 0 Then
        If Len(currentText) > 0 Then currentText = currentText & separatorText
        rec(fieldName) = currentText & cleanValue
    End If
End Sub

Private Function LABEL_FindHeaderColumn(ByVal headerMap As Object, ByVal aliases As Variant) As Long
    Dim i As Long, key As String
    If headerMap Is Nothing Then Exit Function
    For i = LBound(aliases) To UBound(aliases)
        key = UCase$(Trim$(CStr(aliases(i))))
        If headerMap.Exists(key) Then
            LABEL_FindHeaderColumn = CLng(headerMap(key))
            Exit Function
        End If
    Next i
End Function

'===============================================================================
' NETWORK LABEL COLLECTION
'===============================================================================

Private Sub LABEL_CollectNetworkLabels( _
    ByRef networkRows As Collection, _
    ByRef allRows As Collection, _
    ByVal cableCounters As Object)

    Dim ws As Worksheet
    Dim cleanPanels As Object
    Dim panel As String
    Dim anyTopology As Boolean

    On Error GoTo EH
    Set cleanPanels = CreateObject("Scripting.Dictionary")
    cleanPanels.CompareMode = vbTextCompare

    'Prefer Step 12 Clean topology. It contains the canonical SIS/device chain used
    'by Step 13 and the drawing cable output, preventing duplicate WNET IDs for one cable.
    For Each ws In ThisWorkbook.Worksheets
        If LABEL_IsNetworkCleanSheet(ws) Then
            panel = LABEL_PanelFromTopologySheetName(ws.Name)
            If Right$(UCase$(panel), 8) = " - CLEAN" Then panel = Left$(panel, Len(panel) - 8)
            panel = Trim$(panel)
            If Len(panel) > 0 Then cleanPanels(panel) = True
            LABEL_CollectNetworkFromCleanSheet ws, networkRows, allRows, cableCounters
            anyTopology = True
        End If
    Next ws

    'Use raw topology only for panels that do not yet have a Clean sheet.
    For Each ws In ThisWorkbook.Worksheets
        If LABEL_IsNetworkTopologySheet(ws) Then
            panel = LABEL_PanelFromTopologySheetName(ws.Name)
            If Not cleanPanels.Exists(panel) Then
                LABEL_CollectNetworkFromTopologySheet ws, networkRows, allRows, cableCounters
                anyTopology = True
            End If
        End If
    Next ws

    If Not anyTopology Then
        LABEL_CollectNetworkFromSummary networkRows, allRows, cableCounters
    End If
    Exit Sub
EH:
    Err.Raise Err.Number, "LABEL_CollectNetworkLabels", Err.description
End Sub

Private Sub LABEL_CollectNetworkFromCleanSheet( _
    ByVal ws As Worksheet, _
    ByRef networkRows As Collection, _
    ByRef allRows As Collection, _
    ByVal cableCounters As Object)

    Dim headerMap As Object
    Dim colPort As Long, colSis As Long, colDevice As Long, colType As Long
    Dim lastRow As Long, r As Long, segmentNumber As Long
    Dim panel As String, areaNumber As String, switchGroup As String, packageCode As String
    Dim portText As String, currentRef As String, previousRef As String
    Dim sourceEndpoint As String, destinationEndpoint As String, deviceType As String
    Dim cableID As String, record As Variant

    On Error GoTo EH
    Set headerMap = LABEL_CreateHeaderMap(ws, 1, LABEL_LastUsedColumn(ws))
    colPort = LABEL_FindHeaderColumn(headerMap, Array("SWITCH PORT", "PORT"))
    colSis = LABEL_FindHeaderColumn(headerMap, Array("SIS NUMBER", "SIS_ELEMENT_NUMBER"))
    colDevice = LABEL_FindHeaderColumn(headerMap, Array("DEVICE", "DEVICE NAME"))
    colType = LABEL_FindHeaderColumn(headerMap, Array("TYPE", "DEVICE TYPE"))
    If colPort = 0 Or (colSis = 0 And colDevice = 0) Then Exit Sub

    panel = ws.Name
    If Right$(UCase$(panel), 8) = " - CLEAN" Then panel = Left$(panel, Len(panel) - 8)
    panel = Trim$(panel)
    areaNumber = LABEL_AreaFromPanelOrSheet(panel, ws.Name)
    packageCode = LABEL_PackageFromArea(areaNumber)
    lastRow = LABEL_LastUsedRow(ws)

    For r = 2 To lastRow
        If Len(Trim$(CStr(ws.Cells(r, colPort).Value2))) > 0 Then
            portText = ONGEN_CableID_NormalizeNetworkPort(CStr(ws.Cells(r, colPort).Value2))
            previousRef = Trim$(panel & "-NSW01 " & portText)
            segmentNumber = 0
        End If

        currentRef = vbNullString
        If colSis > 0 Then currentRef = Trim$(CStr(ws.Cells(r, colSis).Value2))
        If Len(currentRef) = 0 And colDevice > 0 Then currentRef = Trim$(CStr(ws.Cells(r, colDevice).Value2))
        If Len(currentRef) = 0 Or Len(portText) = 0 Then GoTo NextCleanNetworkRow

        segmentNumber = segmentNumber + 1
        switchGroup = LABEL_SwitchGroupFromElement(currentRef)
        If colType > 0 Then deviceType = Trim$(CStr(ws.Cells(r, colType).Value2)) Else deviceType = vbNullString
        sourceEndpoint = IIf(segmentNumber = 1, previousRef, previousRef & " NET OUT")
        destinationEndpoint = currentRef & " NET IN"
        cableID = ONGEN_ExportTag_NET(panel, portText, previousRef, currentRef)

        record = Array(cableID, "NET", packageCode, areaNumber, panel, switchGroup, _
                       panel & "-NSW01", portText, sourceEndpoint, destinationEndpoint, _
                       IIf(Len(deviceType) > 0, deviceType, "NETWORK ROUTE"), vbNullString, vbNullString, _
                       "Industrial Ethernet copper", "Canonical Step 12 Clean topology segment " & CStr(segmentNumber), _
                       ws.Name, "OK", vbNullString)
        networkRows.Add record
        LABEL_AddAllRow allRows, cableID, "NETWORK", "NET", packageCode, areaNumber, panel, _
                        switchGroup, sourceEndpoint, vbNullString, destinationEndpoint, vbNullString, _
                        IIf(Len(deviceType) > 0, deviceType, "NETWORK ROUTE"), portText, vbNullString, _
                        "Industrial Ethernet cable", ws.Name, "OK", vbNullString, 1
        previousRef = currentRef
NextCleanNetworkRow:
    Next r
    Exit Sub
EH:
    Err.Raise Err.Number, "LABEL_CollectNetworkFromCleanSheet", ws.Name & ": " & Err.description
End Sub

Private Sub LABEL_CollectNetworkFromTopologySheet( _
    ByVal ws As Worksheet, _
    ByRef networkRows As Collection, _
    ByRef allRows As Collection, _
    ByVal cableCounters As Object)

    Dim lastColumn As Long
    Dim lastRow As Long
    Dim columnNumber As Long
    Dim rowNumber As Long

    Dim portText As String
    Dim metadata As String
    Dim areaNumber As String
    Dim panel As String
    Dim switchGroup As String
    Dim networkSwitch As String
    Dim routeType As String
    Dim routeLength As String
    Dim routeStatus As String
    Dim notesText As String
    Dim upstreamSwitch As String
    Dim upstreamPort As String

    Dim sourceEndpoint As String
    Dim destinationEndpoint As String
    Dim previousDevice As String
    Dim currentDevice As String
    Dim cableID As String
    Dim packageCode As String
    Dim segmentNumber As Long
    Dim deviceCount As Long
    Dim record As Variant

    On Error GoTo EH

    lastColumn = LABEL_LastUsedColumn(ws)

    For columnNumber = 1 To lastColumn
        portText = ONGEN_CableID_NormalizeNetworkPort(CStr(ws.Cells(1, columnNumber).Value2))

        ' Ignore non-port columns.
        If Not LABEL_IsPortHeader(portText) Then GoTo NextNetworkColumn

        metadata = Trim$(CStr(ws.Cells(2, columnNumber).Value2))
        areaNumber = LABEL_MetadataValue(metadata, "AREA")
        panel = LABEL_MetadataValue(metadata, "PANEL")
        switchGroup = LABEL_MetadataValue(metadata, "SWG")
        networkSwitch = LABEL_MetadataValue(metadata, "PANEL_SWITCH_NAME")
        routeType = LABEL_MetadataValue(metadata, "ROUTE_FAMILY")
        routeLength = LABEL_MetadataValue(metadata, "LEN_M")
        routeStatus = LABEL_MetadataValue(metadata, "STATUS")
        notesText = LABEL_MetadataValue(metadata, "NOTE")
        upstreamSwitch = LABEL_MetadataValue(metadata, "UPSTREAM_SWITCH")
        upstreamPort = LABEL_MetadataValue(metadata, "UPSTREAM_PORT")

        ' Apply readable fallbacks for imported topology sheets that do not use
        ' the automatic metadata format.
        If Len(panel) = 0 Then panel = LABEL_PanelFromTopologySheetName(ws.Name)
        If Len(areaNumber) = 0 Then areaNumber = LABEL_AreaFromPanelOrSheet(panel, ws.Name)
        If Len(networkSwitch) = 0 Then networkSwitch = LABEL_DefaultNetworkSwitchName(panel, ws.Name)
        If Len(routeType) = 0 Then routeType = LABEL_MetadataValue(metadata, "ROUTE")
        If Len(routeType) = 0 Then routeType = "NETWORK ROUTE"
        If Len(routeStatus) = 0 Then routeStatus = "OK"

        packageCode = LABEL_PackageFromArea(areaNumber)

        ' X09 is normally an uplink from an upstream switch into the panel switch.
        If portText = "X09" And Len(upstreamSwitch) > 0 Then
            sourceEndpoint = Trim$(upstreamSwitch & " " & upstreamPort)
            destinationEndpoint = Trim$(networkSwitch & " X09")
            cableID = ONGEN_ExportTag_NET(panel, portText, sourceEndpoint, destinationEndpoint)

            record = Array( _
                cableID, _
                "NET", _
                packageCode, _
                areaNumber, _
                panel, _
                switchGroup, _
                networkSwitch, _
                portText, _
                sourceEndpoint, _
                destinationEndpoint, _
                routeType, _
                routeLength, _
                1, _
                "Industrial Ethernet copper", _
                "Network switch uplink", _
                ws.Name, _
                routeStatus, _
                notesText)

            networkRows.Add record

            LABEL_AddAllRow allRows, _
                cableID, "NETWORK", "NET", packageCode, areaNumber, panel, _
                switchGroup, sourceEndpoint, vbNullString, destinationEndpoint, _
                vbNullString, routeType, portText, routeLength, _
                "Network switch uplink", ws.Name, routeStatus, notesText, 1

            GoTo NextNetworkColumn
        End If

        ' Start each normal route at the panel network-switch port.
        previousDevice = Trim$(networkSwitch & " " & portText)
        segmentNumber = 0
        deviceCount = 0

        lastRow = ws.Cells(ws.rows.count, columnNumber).End(xlUp).Row

        For rowNumber = 3 To lastRow
            currentDevice = LABEL_CleanTopologyDevice( _
                CStr(ws.Cells(rowNumber, columnNumber).Value2))

            If Len(currentDevice) > 0 Then
                segmentNumber = segmentNumber + 1
                deviceCount = deviceCount + 1

                If segmentNumber = 1 Then
                    sourceEndpoint = previousDevice
                Else
                    sourceEndpoint = previousDevice & " NET OUT"
                End If

                destinationEndpoint = currentDevice & " NET IN"
                cableID = ONGEN_ExportTag_NET(panel, portText, previousDevice, currentDevice)

                ' Store the full route length on the first segment because the
                ' topology provides a port total rather than per-segment lengths.
                If segmentNumber = 1 Then
                    record = Array( _
                        cableID, "NET", packageCode, areaNumber, panel, switchGroup, _
                        networkSwitch, portText, sourceEndpoint, destinationEndpoint, _
                        routeType, routeLength, vbNullString, _
                        "Industrial Ethernet copper", _
                        "Network route segment 1; route length is the port total", _
                        ws.Name, routeStatus, notesText)
                Else
                    record = Array( _
                        cableID, "NET", packageCode, areaNumber, panel, switchGroup, _
                        networkSwitch, portText, sourceEndpoint, destinationEndpoint, _
                        routeType, vbNullString, vbNullString, _
                        "Industrial Ethernet copper", _
                        "Network daisy-chain segment " & CStr(segmentNumber), _
                        ws.Name, routeStatus, notesText)
                End If

                networkRows.Add record

                LABEL_AddAllRow allRows, _
                    cableID, "NETWORK", "NET", packageCode, areaNumber, panel, _
                    switchGroup, sourceEndpoint, vbNullString, destinationEndpoint, _
                    vbNullString, routeType, portText, _
                    IIf(segmentNumber = 1, routeLength, vbNullString), _
                    CStr(record(14)), ws.Name, routeStatus, notesText, 1

                previousDevice = currentDevice
            End If
        Next rowNumber

NextNetworkColumn:
    Next columnNumber

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_CollectNetworkFromTopologySheet", _
              ws.Name & ": " & Err.description
End Sub


Private Sub LABEL_CollectNetworkFromSummary( _
    ByRef networkRows As Collection, _
    ByRef allRows As Collection, _
    ByVal cableCounters As Object)

    Dim ws As Worksheet
    Dim headerMap As Object
    Dim lastRow As Long
    Dim lastColumn As Long
    Dim rowNumber As Long

    Dim panel As String
    Dim areaNumber As String
    Dim switchGroup As String
    Dim portText As String
    Dim routeType As String
    Dim deviceCount As String
    Dim routeLength As String
    Dim firstSequence As String
    Dim statusText As String
    Dim notesText As String
    Dim networkSwitch As String
    Dim sourceEndpoint As String
    Dim destinationEndpoint As String
    Dim cableID As String
    Dim packageCode As String
    Dim record As Variant

    On Error GoTo EH

    If Not LABEL_WorksheetExists("NETWORK_AUTO_SUMMARY", ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets("NETWORK_AUTO_SUMMARY")

    lastRow = LABEL_LastUsedRow(ws)
    lastColumn = LABEL_LastUsedColumn(ws)
    If lastRow < 2 Then Exit Sub

    Set headerMap = LABEL_CreateHeaderMap(ws, 1, lastColumn)

    For rowNumber = 2 To lastRow
        panel = LABEL_CellByHeader(ws, rowNumber, headerMap, "PANEL")
        areaNumber = LABEL_CellByHeader(ws, rowNumber, headerMap, "AREA")
        switchGroup = LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "SWITCHGROUP", "SWITCH GROUP")
        portText = ONGEN_CableID_NormalizeNetworkPort(LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "SWITCH PORT", "PORT"))
        routeType = LABEL_CellByHeader(ws, rowNumber, headerMap, "ROUTE TYPE")
        deviceCount = LABEL_CellByHeader(ws, rowNumber, headerMap, "DEVICE COUNT")
        routeLength = LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "ROUTE LENGTH (M)", "ROUTE LENGTH")
        firstSequence = LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "FIRST SEQUENCE")
        statusText = LABEL_CellByHeader(ws, rowNumber, headerMap, "STATUS")
        notesText = LABEL_CellByHeader(ws, rowNumber, headerMap, "NOTES")
        networkSwitch = LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "PANEL NETWORK SWITCH")

        If Len(panel) = 0 And Len(portText) = 0 And Len(firstSequence) = 0 Then
            GoTo NextSummaryRow
        End If

        If Len(networkSwitch) = 0 Then
            networkSwitch = LABEL_DefaultNetworkSwitchName(panel, vbNullString)
        End If

        sourceEndpoint = Trim$(networkSwitch & " " & portText)
        destinationEndpoint = firstSequence & " NET IN"
        packageCode = LABEL_PackageFromArea(areaNumber)
        cableID = ONGEN_ExportTag_NET(panel, portText, sourceEndpoint, destinationEndpoint)

        record = Array( _
            cableID, "NET", packageCode, areaNumber, panel, switchGroup, _
            networkSwitch, portText, sourceEndpoint, destinationEndpoint, _
            routeType, routeLength, deviceCount, _
            "Industrial Ethernet copper", _
            "Route-summary fallback; downstream segments are not individually listed", _
            ws.Name, statusText, notesText)

        networkRows.Add record

        LABEL_AddAllRow allRows, _
            cableID, "NETWORK", "NET", packageCode, areaNumber, panel, _
            switchGroup, sourceEndpoint, vbNullString, destinationEndpoint, _
            vbNullString, routeType, portText, routeLength, _
            "Route-summary fallback", ws.Name, statusText, notesText, 1

NextSummaryRow:
    Next rowNumber

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_CollectNetworkFromSummary", Err.description
End Sub


'===============================================================================
' POWER LABEL COLLECTION
'===============================================================================

Private Sub LABEL_CollectPowerLabels( _
    ByRef powerRows As Collection, _
    ByRef allRows As Collection, _
    ByVal cableCounters As Object)

    Dim ws As Worksheet

    On Error GoTo EH

    ' Read every generated 24V panel worksheet. Support both legacy 24V_<Panel>
    ' and the current <Panel>_24v naming convention used by Step 07.
    For Each ws In ThisWorkbook.Worksheets
        If LABEL_Is24VPanelSheet(ws) Then
            LABEL_Collect24VFromSheet _
                ws, powerRows, allRows, cableCounters
        End If
    Next ws

    ' Read the generated 480V VFD list when present.
    LABEL_Collect480VFromGenerator _
        powerRows, allRows, cableCounters

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_CollectPowerLabels", Err.description
End Sub


Private Sub LABEL_Collect24VFromSheet( _
    ByVal ws As Worksheet, _
    ByRef powerRows As Collection, _
    ByRef allRows As Collection, _
    ByVal cableCounters As Object)

    Dim lastRow As Long
    Dim rowNumber As Long

    Dim currentSwitchGroup As String
    Dim currentBus As String
    Dim bus1PSU As String
    Dim bus2PSU As String
    Dim currentPSU As String

    Dim firstCell As String
    Dim secondCell As String
    Dim seventhCell As String

    Dim sisElement As String
    Dim deviceType As String
    Dim loadText As String
    Dim deviceTerminalIn As String
    Dim sourceTerminal As String
    Dim insidePanelTerminal As String
    Dim areaNumber As String
    Dim switchGroup As String
    Dim panel As String
    Dim packageCode As String
    Dim cableID As String
    Dim statusText As String
    Dim notesText As String
    Dim record As Variant

    On Error GoTo EH

    lastRow = LABEL_LastUsedRow(ws)
    panel = LABEL_PanelFrom24VSheetName(ws.Name)

    For rowNumber = 1 To lastRow
        firstCell = Trim$(CStr(ws.Cells(rowNumber, 1).Value2))
        secondCell = UCase$(Trim$(CStr(ws.Cells(rowNumber, 2).Value2)))
        seventhCell = UCase$(Trim$(CStr(ws.Cells(rowNumber, 7).Value2)))

        'Reset section state so a missing BUS row can never inherit a PSU from the prior PWG.
        If UCase$(firstCell) = "PWG" And secondCell = "BUS POWER" Then
            currentBus = vbNullString: currentPSU = vbNullString
            bus1PSU = vbNullString: bus2PSU = vbNullString
            currentSwitchGroup = vbNullString
            GoTo NextPowerRow
        End If

        ' Capture the current power-supply assignment rows.
        If secondCell = "BUS-1" Or secondCell = "BUS-2" Then
            currentSwitchGroup = firstCell

            If secondCell = "BUS-1" Then
                bus1PSU = Trim$(CStr(ws.Cells(rowNumber, 3).Value2))
            Else
                bus2PSU = Trim$(CStr(ws.Cells(rowNumber, 3).Value2))
            End If

            GoTo NextPowerRow
        End If

        ' Identify the start of a BUS-1 or BUS-2 device table.
        If UCase$(firstCell) = "SIS_ELEMENT_NUMBER" Then
            If InStr(1, seventhCell, "BUS-1", vbTextCompare) > 0 Then
                currentBus = "BUS-1"
                currentPSU = bus1PSU
            ElseIf InStr(1, seventhCell, "BUS-2", vbTextCompare) > 0 Then
                currentBus = "BUS-2"
                currentPSU = bus2PSU
            Else
                currentBus = vbNullString
                currentPSU = vbNullString
            End If

            GoTo NextPowerRow
        End If

        ' Ignore blank rows and rows outside a recognized device table.
        If Len(firstCell) = 0 Or Len(currentBus) = 0 Then GoTo NextPowerRow

        ' Exclude any table header that was not caught by the exact comparison.
        If UCase$(firstCell) = "PWG" Then GoTo NextPowerRow

        sisElement = firstCell
        deviceType = Trim$(CStr(ws.Cells(rowNumber, 2).Value2))
        loadText = Trim$(CStr(ws.Cells(rowNumber, 3).Value2))
        deviceTerminalIn = Trim$(CStr(ws.Cells(rowNumber, 5).Value2))
        sourceTerminal = Trim$(CStr(ws.Cells(rowNumber, 7).Value2))
        insidePanelTerminal = Trim$(CStr(ws.Cells(rowNumber, 8).Value2))

        areaNumber = LABEL_AreaFromElement(sisElement)
        switchGroup = LABEL_SwitchGroupFromElement(sisElement)
        If Len(switchGroup) = 0 Then switchGroup = currentSwitchGroup

        packageCode = LABEL_PackageFromArea(areaNumber)
        'Use the same PSU + DC-pair branch identity as the Step 09 SNR export.
        cableID = ONGEN_ExportTag_DC( _
            panel, currentBus, currentPSU, sisElement, sourceTerminal, insidePanelTerminal)

        If Len(currentPSU) = 0 Or UCase$(currentPSU) = "MISSING" Then
            statusText = "MISSING PSU"
            currentPSU = "MISSING PSU"
        ElseIf Len(deviceTerminalIn) = 0 Or Len(sourceTerminal) = 0 Then
            statusText = "CHECK TERMINAL"
        Else
            statusText = "OK"
        End If

        notesText = currentBus & " 24VDC feed"

        record = Array( _
            cableID, _
            "DC", _
            packageCode, _
            areaNumber, _
            panel, _
            switchGroup, _
            currentBus, _
            currentPSU, _
            LABEL_JoinNonBlank(sourceTerminal, insidePanelTerminal, _
                               vbNullString, " / "), _
            sisElement, _
            deviceTerminalIn, _
            deviceType, _
            loadText, _
            "24VDC multi-core", _
            notesText, _
            ws.Name, _
            statusText, _
            vbNullString)

        powerRows.Add record

        LABEL_AddAllRow allRows, _
            cableID, "POWER", "DC", packageCode, areaNumber, panel, _
            switchGroup, currentPSU, CStr(record(8)), sisElement, _
            deviceTerminalIn, deviceType, currentBus, loadText, _
            notesText, ws.Name, statusText, vbNullString, 1

NextPowerRow:
    Next rowNumber

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_Collect24VFromSheet", _
              ws.Name & ": " & Err.description
End Sub


Private Sub LABEL_Collect480VFromGenerator( _
    ByRef powerRows As Collection, _
    ByRef allRows As Collection, _
    ByVal cableCounters As Object)

    Dim ws As Worksheet
    Dim headerMap As Object
    Dim lastRow As Long
    Dim lastColumn As Long
    Dim rowNumber As Long

    Dim sisElement As String
    Dim deviceType As String
    Dim panel As String
    Dim loadText As String
    Dim terminalIn As String
    Dim areaNumber As String
    Dim switchGroup As String
    Dim packageCode As String
    Dim cableID As String
    Dim sisSequence As String
    Dim motorID As String
    Dim motorCableID As String
    Dim statusText As String
    Dim record As Variant

    On Error GoTo EH

    If Not LABEL_WorksheetExists("VFD_480V_Generator", ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets("VFD_480V_Generator")

    lastRow = LABEL_LastUsedRow(ws)
    lastColumn = LABEL_LastUsedColumn(ws)
    If lastRow < 2 Then Exit Sub

    Set headerMap = LABEL_CreateHeaderMap(ws, 1, lastColumn)

    For rowNumber = 2 To lastRow
        sisElement = LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER")
        deviceType = LABEL_CellByHeader(ws, rowNumber, headerMap, "TYPE")
        panel = LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "480V PANEL", "PANEL", "PNL")
        loadText = LABEL_CellByHeader(ws, rowNumber, headerMap, "LOAD")
        terminalIn = LABEL_CellByHeader(ws, rowNumber, headerMap, _
            "TERMINAL (IN)", "TERMINAL IN")
        sisSequence = LABEL_CellByHeader(ws, rowNumber, headerMap, "SIS_SEQUENCE", "SIS SEQUENCE")

        If Len(sisElement) = 0 Then GoTo Next480VRow

        areaNumber = LABEL_AreaFromElement(sisElement)
        switchGroup = LABEL_SwitchGroupFromElement(sisElement)
        packageCode = LABEL_PackageFromArea(areaNumber)
        cableID = ONGEN_CableID_Get("PWR|" & panel & "|" & sisElement)

        If Len(panel) = 0 Or Len(terminalIn) = 0 Then
            statusText = "CHECK PANEL / TERMINAL"
        Else
            statusText = "OK"
        End If

        record = Array( _
            cableID, _
            "PWR", _
            packageCode, _
            areaNumber, _
            panel, _
            switchGroup, _
            "480VAC", _
            panel & " 480VAC DISTRIBUTION", _
            vbNullString, _
            sisElement, _
            terminalIn, _
            deviceType, _
            loadText, _
            "AC power cable", _
            "480VAC feed to VFD", _
            ws.Name, _
            statusText, _
            vbNullString)

        powerRows.Add record

        LABEL_AddAllRow allRows, _
            cableID, "POWER", "PWR", packageCode, areaNumber, panel, _
            switchGroup, CStr(record(7)), vbNullString, sisElement, terminalIn, _
            deviceType, "480VAC", loadText, "480VAC feed to VFD", _
            ws.Name, statusText, vbNullString, 1

        'Also create the VFD-to-motor physical power cable required by the label standard.
        motorID = LABEL_DeriveMotorID(sisElement, sisSequence, areaNumber, switchGroup)
        motorCableID = ONGEN_CableID_Get("MTR|" & panel & "|" & sisElement & "|" & motorID)
        record = Array( _
            motorCableID, "MTR", packageCode, areaNumber, panel, switchGroup, _
            "480VAC MOTOR", sisElement, "U/V/W/PE", motorID, "U/V/W/PE", _
            "MOTOR", loadText, "Motor power cable", "VFD-to-motor power", _
            ws.Name, "REVIEW - VERIFY MOTOR CABLE", vbNullString)
        powerRows.Add record
        LABEL_AddAllRow allRows, _
            motorCableID, "POWER", "MTR", packageCode, areaNumber, panel, _
            switchGroup, sisElement, "U/V/W/PE", motorID, "U/V/W/PE", _
            "MOTOR", "480VAC MOTOR", loadText, "VFD-to-motor power", _
            ws.Name, "REVIEW - VERIFY MOTOR CABLE", vbNullString, 1

Next480VRow:
    Next rowNumber

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_Collect480VFromGenerator", Err.description
End Sub


'===============================================================================
' EXTERNAL WORKBOOK BUILD
'===============================================================================

Private Sub LABEL_BuildExportWorkbook( _
    ByVal outputWorkbook As Workbook, _
    ByVal ioRows As Collection, _
    ByVal networkRows As Collection, _
    ByVal powerRows As Collection, _
    ByVal allRows As Collection)

    Dim wsReadMe As Worksheet
    Dim wsAll As Worksheet
    Dim wsIO As Worksheet
    Dim wsNetwork As Worksheet
    Dim wsPower As Worksheet

    On Error GoTo EH

    ' Rename the initial worksheet and add the four register worksheets.
    Set wsReadMe = outputWorkbook.Worksheets(1)
    wsReadMe.Name = LABEL_SHEET_README

    Set wsAll = outputWorkbook.Worksheets.Add(After:=wsReadMe)
    wsAll.Name = LABEL_SHEET_ALL

    Set wsIO = outputWorkbook.Worksheets.Add(After:=wsAll)
    wsIO.Name = LABEL_SHEET_IO

    Set wsNetwork = outputWorkbook.Worksheets.Add(After:=wsIO)
    wsNetwork.Name = LABEL_SHEET_NETWORK

    Set wsPower = outputWorkbook.Worksheets.Add(After:=wsNetwork)
    wsPower.Name = LABEL_SHEET_POWER

    ' Build the README and summary worksheet.
    LABEL_WriteReadme wsReadMe, ioRows.count, networkRows.count, _
                      powerRows.count, allRows.count

    ' Build the combined register.
    LABEL_WriteReportSheet _
        wsAll, _
        "ONGEN Combined Label Register", _
        Array( _
            "Label ID", "Category", "Type Code", "Package", "Area", "Panel", _
            "SwitchGroup", "From", "From Terminal", "To", "To Terminal", _
            "Device / Route Type", "Port / Bus", "Load / Length", _
            "Description", "Source Sheet", "Status", "Notes", "Quantity"), _
        allRows, _
        "ONGENAllLabels"

    ' Build the IO device register.
    LABEL_WriteReportSheet _
        wsIO, _
        "ONGEN IO Device Label Register", _
        Array( _
            "Label ID", "Category", "Package", "Area", "Panel", "SwitchGroup", _
            "Device", "Device Type", "Signal Type(s)", "Signal Name(s)", _
            "IO Block", "Block ID", "Port", "From Endpoint", "To Endpoint", _
            "Description", "Notes", "Source Sheet", "Status", "Quantity"), _
        ioRows, _
        "ONGENIOLabels"

    ' Build the network cable register.
    LABEL_WriteReportSheet _
        wsNetwork, _
        "ONGEN Network Cable Label Register", _
        Array( _
            "Cable ID", "Type Code", "Package", "Area", "Panel", "SwitchGroup", _
            "Network Switch", "Switch Port", "From", "To", "Route Type", _
            "Route Length (m)", "Device Count", "Cable Category", _
            "Description", "Source Sheet", "Status", "Notes"), _
        networkRows, _
        "ONGENNetworkLabels"

    ' Build the power cable register.
    LABEL_WriteReportSheet _
        wsPower, _
        "ONGEN Power Cable Label Register", _
        Array( _
            "Cable ID", "Type Code", "Package", "Area", "Panel", "SwitchGroup", _
            "Voltage / Bus", "Power Source", "Source Terminal", _
            "Destination Device", "Destination Terminal", "Device Type", "Load", _
            "Cable Category", "Description", "Source Sheet", "Status", "Notes"), _
        powerRows, _
        "ONGENPowerLabels"

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_BuildExportWorkbook", Err.description
End Sub


Private Sub LABEL_WriteReadme( _
    ByVal ws As Worksheet, _
    ByVal ioCount As Long, _
    ByVal networkCount As Long, _
    ByVal powerCount As Long, _
    ByVal allCount As Long)

    On Error GoTo EH

    ws.Cells.Clear

    ' Create the report title.
    ws.Range("A1:F1").Merge
    ws.Range("A1").value = "ONGEN LABEL LIST REPORT"
    LABEL_FormatTitleRange ws.Range("A1:F1")

    ' Write release and source information one row at a time so the code works
    ' consistently in all supported Excel versions.
    ws.Range("A3").value = "Generated"
    ws.Range("B3").value = Format$(Now, "yyyy-mm-dd hh:nn:ss")
    ws.Range("A4").value = "Source Workbook"
    ws.Range("B4").value = ThisWorkbook.Name
    ws.Range("A5").value = "Source Path"
    ws.Range("B5").value = ThisWorkbook.FullName
    ws.Range("A6").value = "Release"
    ws.Range("B6").value = "V16.2-R9.1"
    ws.Range("A7").value = "IO Device Labels"
    ws.Range("B7").value = ioCount
    ws.Range("A8").value = "Network Labels"
    ws.Range("B8").value = networkCount
    ws.Range("A9").value = "Power Labels"
    ws.Range("B9").value = powerCount
    ws.Range("A10").value = "Combined Labels"
    ws.Range("B10").value = allCount
    ws.Range("A11").value = "Source Workbook Modified"
    ws.Range("B11").value = "No report worksheets were added"

    ws.Range("A3:A11").Font.Bold = True
    ws.Range("A3:A11").Interior.Color = RGB(217, 234, 247)

    ' Document the generated label rules.
    ws.Range("A13:F13").Merge
    ws.Range("A13").value = "Label Identification Rules"
    LABEL_FormatSectionRange ws.Range("A13:F13")

    ws.Range("A14").value = "IO Device"
    ws.Range("B14").value = "Device-BlockID-Port"
    ws.Range("A15").value = "Network"
    ws.Range("B15").value = "AE<Area>-NET-CNNN"
    ws.Range("A16").value = "24VDC Power"
    ws.Range("B16").value = "AE<Area>-DC-CNNN"
    ws.Range("A17").value = "480VAC Power"
    ws.Range("B17").value = "AE<Area>-PWR-CNNN"
    ws.Range("A18").value = "Sequence"
    ws.Range("B18").value = "Resets independently by package and type code"

    ws.Range("A14:A18").Font.Bold = True

    ' Explain the data sources and limitations.
    ws.Range("A20:F20").Merge
    ws.Range("A20").value = "Data Sources and Notes"
    LABEL_FormatSectionRange ws.Range("A20:F20")

    ws.Range("A21:F27").Merge
    ws.Range("A21").value = _
        "IO labels are generated from IO_DEVICE_LIST and are consolidated by " & _
        "Panel + Device + Block ID + physical X-port. Network labels are generated " & _
        "from raw X01-X09 topology sheets when available. If no topology sheet " & _
        "exists, NETWORK_AUTO_SUMMARY is used as a route-level fallback. Power " & _
        "labels are generated from 24v_* panel sheets and VFD_480V_Generator. " & _
        "Network topology stores total route length rather than individual segment " & _
        "lengths, so the route total is shown on the first segment."

    With ws.Range("A21:F27")
        .WrapText = True
        .VerticalAlignment = xlTop
        .Interior.Color = RGB(242, 242, 242)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(191, 191, 191)
    End With

    ' Apply readable widths.
    ws.Columns("A").columnWidth = 28
    ws.Columns("B").columnWidth = 65
    ws.Columns("C:F").columnWidth = 12

    ' Do not AutoFit rows that contain merged cells. Excel can raise error 1004
    ' when AutoFit is applied to merged title, section, or narrative ranges.
    ws.rows("2:12").AutoFit
    ws.rows("14:19").AutoFit
    ws.rows("1").RowHeight = 30
    ws.rows("13").RowHeight = 22
    ws.rows("20").RowHeight = 22
    ws.rows("21:27").RowHeight = 20

    ' Freeze the summary only when an Excel window is available.
    ws.Activate
    If Application.Windows.count > 0 Then
        ActiveWindow.FreezePanes = False
        ws.Range("A3").Select
        ActiveWindow.FreezePanes = True
    End If

    ' Configure printing.
    With ws.PageSetup
        .Orientation = xlLandscape
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .Zoom = False
    End With

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_WriteReadme", Err.description
End Sub


Private Sub LABEL_WriteReportSheet( _
    ByVal ws As Worksheet, _
    ByVal reportTitle As String, _
    ByVal headers As Variant, _
    ByVal records As Collection, _
    ByVal tableName As String)

    Dim columnCount As Long
    Dim lastColumnLetter As String
    Dim headerRow As Long
    Dim firstDataRow As Long
    Dim lastDataRow As Long
    Dim dataArray As Variant
    Dim reportRange As Range
    Dim reportTable As ListObject
    Dim columnNumber As Long

    On Error GoTo EH

    ws.Cells.Clear

    columnCount = UBound(headers) - LBound(headers) + 1
    lastColumnLetter = LABEL_ColumnLetter(columnCount)
    headerRow = 6
    firstDataRow = headerRow + 1

    ' Create a merged report title.
    ws.Range("A1:" & lastColumnLetter & "1").Merge
    ws.Range("A1").value = reportTitle
    LABEL_FormatTitleRange ws.Range("A1:" & lastColumnLetter & "1")

    ' Add report metadata above the table.
    ws.Range("A2").value = "Generated"
    ws.Range("B2").value = Format$(Now, "yyyy-mm-dd hh:nn:ss")
    ws.Range("A3").value = "Source Workbook"
    ws.Range("B3").value = ThisWorkbook.Name
    ws.Range("A4").value = "Record Count"
    ws.Range("B4").value = records.count

    ws.Range("A2:A4").Font.Bold = True
    ws.Range("A2:A4").Interior.Color = RGB(217, 234, 247)

    ' Write the column headings.
    For columnNumber = 1 To columnCount
        ws.Cells(headerRow, columnNumber).value = _
            CStr(headers(LBound(headers) + columnNumber - 1))
    Next columnNumber

    LABEL_FormatHeaderRange _
        ws.Range("A" & headerRow & ":" & lastColumnLetter & headerRow)

    ' Write all report rows in one block for performance.
    If records.count > 0 Then
        dataArray = LABEL_CollectionToArray(records, columnCount)
        lastDataRow = headerRow + records.count

        ws.Range( _
            ws.Cells(firstDataRow, 1), _
            ws.Cells(lastDataRow, columnCount)).value = dataArray

        Set reportRange = ws.Range( _
            ws.Cells(headerRow, 1), _
            ws.Cells(lastDataRow, columnCount))

        ' Convert the data to a filterable Excel table.
        Set reportTable = ws.ListObjects.Add( _
            xlSrcRange, reportRange, , xlYes)

        reportTable.Name = tableName
        reportTable.TableStyle = "TableStyleMedium2"
    Else
        lastDataRow = headerRow

        ' Keep filtering available even when the category has no rows.
        ws.Range( _
            ws.Cells(headerRow, 1), _
            ws.Cells(headerRow, columnCount)).AutoFilter
    End If

    ' Apply general body formatting.
    With ws.Range( _
        ws.Cells(firstDataRow, 1), _
        ws.Cells(Application.Max(firstDataRow, lastDataRow), columnCount))
        .VerticalAlignment = xlTop
        .WrapText = True
    End With

    ' Autofit only the non-merged report area. Row 1 is a merged title and can
    ' cause Excel error 1004 when entire worksheet columns are auto-fitted.
    ws.Range( _
        ws.Cells(2, 1), _
        ws.Cells(Application.Max(headerRow, lastDataRow), columnCount)).Columns.AutoFit

    For columnNumber = 1 To columnCount
        If ws.Columns(columnNumber).columnWidth < 10 Then
            ws.Columns(columnNumber).columnWidth = 10
        ElseIf ws.Columns(columnNumber).columnWidth > 38 Then
            ws.Columns(columnNumber).columnWidth = 38
        End If
    Next columnNumber

    ' Make endpoint, description, and note columns easier to read.
    LABEL_SetColumnWidthByHeader ws, headerRow, "From", 28
    LABEL_SetColumnWidthByHeader ws, headerRow, "To", 28
    LABEL_SetColumnWidthByHeader ws, headerRow, "From Endpoint", 28
    LABEL_SetColumnWidthByHeader ws, headerRow, "To Endpoint", 28
    LABEL_SetColumnWidthByHeader ws, headerRow, "Description", 34
    LABEL_SetColumnWidthByHeader ws, headerRow, "Notes", 38

    ' Freeze the title/metadata/header section when a window is available.
    ws.Activate
    If Application.Windows.count > 0 Then
        ActiveWindow.FreezePanes = False
        ws.Cells(firstDataRow, 1).Select
        ActiveWindow.FreezePanes = True
    End If

    ' Configure print layout.
    With ws.PageSetup
        .Orientation = xlLandscape
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .Zoom = False
        .PrintTitleRows = "$1:$" & CStr(headerRow)
    End With

    Exit Sub

EH:
    Err.Raise Err.Number, "LABEL_WriteReportSheet", _
              ws.Name & ": " & Err.description
End Sub


'===============================================================================
' COMMON RECORD HELPERS
'===============================================================================

Private Sub LABEL_AddAllRow( _
    ByRef allRows As Collection, _
    ByVal labelID As String, _
    ByVal category As String, _
    ByVal typeCode As String, _
    ByVal packageCode As String, _
    ByVal areaNumber As String, _
    ByVal panel As String, _
    ByVal switchGroup As String, _
    ByVal fromEndpoint As String, _
    ByVal fromTerminal As String, _
    ByVal toEndpoint As String, _
    ByVal toTerminal As String, _
    ByVal deviceOrRouteType As String, _
    ByVal portOrBus As String, _
    ByVal loadOrLength As String, _
    ByVal description As String, _
    ByVal sourceSheet As String, _
    ByVal statusText As String, _
    ByVal notesText As String, _
    ByVal quantity As Long)

    ' Store the common fields used by the combined label register.
    allRows.Add Array( _
        labelID, category, typeCode, packageCode, areaNumber, panel, _
        switchGroup, fromEndpoint, fromTerminal, toEndpoint, toTerminal, _
        deviceOrRouteType, portOrBus, loadOrLength, description, sourceSheet, _
        statusText, notesText, quantity)
End Sub


Private Function LABEL_CollectionToArray( _
    ByVal records As Collection, _
    ByVal columnCount As Long) As Variant

    Dim dataArray() As Variant
    Dim record As Variant
    Dim rowNumber As Long
    Dim columnNumber As Long

    ' Convert the collection into the two-dimensional array required by Range.Value.
    ReDim dataArray(1 To records.count, 1 To columnCount)

    For rowNumber = 1 To records.count
        record = records(rowNumber)

        For columnNumber = 1 To columnCount
            dataArray(rowNumber, columnNumber) = _
                record(LBound(record) + columnNumber - 1)
        Next columnNumber
    Next rowNumber

    LABEL_CollectionToArray = dataArray
End Function


Private Function LABEL_NextCableID( _
    ByVal areaNumber As String, _
    ByVal typeCode As String, _
    ByVal counters As Object) As String

    'Legacy compatibility only. Current collectors call ONGEN_CableID_Get with
    'a physical-cable key. This fallback remains short and <= 10 characters.
    LABEL_NextCableID = ONGEN_CableID_Get("LEGACY|" & areaNumber & "|" & typeCode & "|" & CStr(Timer))
End Function


Private Function LABEL_DeriveMotorID(ByVal sisElement As String, ByVal sisSequence As String, _
                                     ByVal areaNumber As String, ByVal switchGroup As String) As String
    Dim baseText As String, p As Long
    baseText = Trim$(sisSequence)
    If Len(baseText) = 0 Then baseText = Trim$(sisElement)
    p = InStr(1, UCase$(baseText), "-VFD", vbTextCompare)
    If p > 0 Then baseText = Left$(baseText, p - 1)
    p = InStrRev(UCase$(baseText), "-K")
    If p > 0 Then baseText = Left$(baseText, p - 1)
    If Len(areaNumber) > 0 And Len(switchGroup) > 0 And InStr(1, baseText, "-", vbTextCompare) = 0 Then
        LABEL_DeriveMotorID = areaNumber & "-" & switchGroup & "-" & baseText & "-MTR"
    Else
        LABEL_DeriveMotorID = baseText & "-MTR"
    End If
End Function


Private Function LABEL_PackageFromArea(ByVal areaNumber As String) As String
    Dim cleanedArea As String

    cleanedArea = LABEL_KeepLettersAndNumbers(areaNumber)

    If Len(cleanedArea) = 0 Or cleanedArea = "0" Then
        LABEL_PackageFromArea = "PKG"
    ElseIf UCase$(Left$(cleanedArea, 2)) = "AE" Then
        LABEL_PackageFromArea = UCase$(cleanedArea)
    Else
        LABEL_PackageFromArea = "AE" & UCase$(cleanedArea)
    End If
End Function


Private Function LABEL_AreaFromElement(ByVal sisElement As String) As String
    Dim parts() As String

    sisElement = Trim$(sisElement)
    If Len(sisElement) = 0 Then Exit Function

    parts = Split(sisElement, "-")

    If UBound(parts) >= 0 Then
        If IsNumeric(parts(0)) Then
            LABEL_AreaFromElement = Trim$(parts(0))
        End If
    End If
End Function


Private Function LABEL_SwitchGroupFromElement(ByVal sisElement As String) As String
    Dim parts() As String

    sisElement = Trim$(sisElement)
    If Len(sisElement) = 0 Then Exit Function

    parts = Split(sisElement, "-")

    If UBound(parts) >= 1 Then
        LABEL_SwitchGroupFromElement = Trim$(parts(1))
    End If
End Function


Private Function LABEL_AreaFromPanelOrSheet( _
    ByVal panel As String, _
    ByVal sheetName As String) As String

    Dim textValue As String
    Dim i As Long
    Dim digitText As String

    ' First try to resolve the panel directly from PD6_IMPORT. This supports
    ' imported topology sheets whose names are panel IDs such as RCP-101.
    LABEL_AreaFromPanelOrSheet = LABEL_AreaFromPD6Panel(panel)
    If Len(LABEL_AreaFromPanelOrSheet) > 0 Then Exit Function

    ' Next look for an explicit AE area identifier in the panel or sheet name.
    textValue = UCase$(panel & " " & sheetName)

    For i = 1 To Len(textValue)
        If mid$(textValue, i, 2) = "AE" Then
            digitText = LABEL_ReadFollowingDigits(textValue, i + 2)
            If Len(digitText) > 0 Then
                LABEL_AreaFromPanelOrSheet = digitText
                Exit Function
            End If
        End If
    Next i
End Function


Private Function LABEL_AreaFromPD6Panel(ByVal panel As String) As String
    Dim ws As Worksheet
    Dim headerMap As Object
    Dim lastRow As Long
    Dim lastColumn As Long
    Dim rowNumber As Long
    Dim sourcePanel As String

    panel = Trim$(panel)
    If Len(panel) = 0 Then Exit Function
    If Not LABEL_WorksheetExists("PD6_IMPORT", ThisWorkbook) Then Exit Function

    Set ws = ThisWorkbook.Worksheets("PD6_IMPORT")
    lastRow = LABEL_LastUsedRow(ws)
    lastColumn = LABEL_LastUsedColumn(ws)
    Set headerMap = LABEL_CreateHeaderMap(ws, 1, lastColumn)

    For rowNumber = 2 To lastRow
        sourcePanel = LABEL_CellByHeader(ws, rowNumber, headerMap, "PNL", "PANEL")

        If StrComp(sourcePanel, panel, vbTextCompare) = 0 Then
            LABEL_AreaFromPD6Panel = LABEL_CellByHeader( _
                ws, rowNumber, headerMap, "AREA_NUMBER", "AREA")
            Exit Function
        End If
    Next rowNumber
End Function


Private Function LABEL_ReadFollowingDigits( _
    ByVal textValue As String, _
    ByVal startPosition As Long) As String

    Dim i As Long
    Dim oneCharacter As String
    Dim resultText As String

    For i = startPosition To Len(textValue)
        oneCharacter = mid$(textValue, i, 1)

        If oneCharacter Like "#" Then
            resultText = resultText & oneCharacter
        ElseIf Len(resultText) > 0 Then
            Exit For
        End If
    Next i

    LABEL_ReadFollowingDigits = resultText
End Function


Private Function LABEL_NormalizePort(ByVal portLocation As String) As String
    Dim normalizedText As String
    Dim separatorPosition As Long

    normalizedText = UCase$(Trim$(portLocation))

    ' Remove the channel suffix from values such as X01.1 and X01.2.
    separatorPosition = InStr(1, normalizedText, ".", vbBinaryCompare)
    If separatorPosition > 0 Then
        normalizedText = Left$(normalizedText, separatorPosition - 1)
    End If

    LABEL_NormalizePort = normalizedText
End Function


Private Function LABEL_JoinNonBlank( _
    ByVal firstValue As String, _
    ByVal secondValue As String, _
    ByVal thirdValue As String, _
    ByVal delimiter As String) As String

    Dim resultText As String

    If Len(Trim$(firstValue)) > 0 Then resultText = Trim$(firstValue)

    If Len(Trim$(secondValue)) > 0 Then
        If Len(resultText) > 0 Then resultText = resultText & delimiter
        resultText = resultText & Trim$(secondValue)
    End If

    If Len(Trim$(thirdValue)) > 0 Then
        If Len(resultText) > 0 Then resultText = resultText & delimiter
        resultText = resultText & Trim$(thirdValue)
    End If

    LABEL_JoinNonBlank = resultText
End Function


Private Function LABEL_AppendUnique( _
    ByVal existingText As String, _
    ByVal newText As String) As String

    existingText = Trim$(existingText)
    newText = Trim$(newText)

    If Len(newText) = 0 Then
        LABEL_AppendUnique = existingText
    ElseIf Len(existingText) = 0 Then
        LABEL_AppendUnique = newText
    ElseIf InStr(1, "," & UCase$(existingText) & ",", _
                 "," & UCase$(newText) & ",", vbTextCompare) > 0 Then
        LABEL_AppendUnique = existingText
    Else
        LABEL_AppendUnique = existingText & ", " & newText
    End If
End Function


'===============================================================================
' NETWORK TOPOLOGY HELPERS
'===============================================================================

Private Function LABEL_IsNetworkCleanSheet(ByVal ws As Worksheet) As Boolean
    Dim headerMap As Object
    If InStr(1, UCase$(ws.Name), "CLEAN", vbTextCompare) = 0 Then Exit Function
    Set headerMap = LABEL_CreateHeaderMap(ws, 1, LABEL_LastUsedColumn(ws))
    LABEL_IsNetworkCleanSheet = (LABEL_FindHeaderColumn(headerMap, Array("SWITCH PORT", "PORT")) > 0 And _
                                 (LABEL_FindHeaderColumn(headerMap, Array("SIS NUMBER", "SIS_ELEMENT_NUMBER")) > 0 Or _
                                  LABEL_FindHeaderColumn(headerMap, Array("DEVICE", "DEVICE NAME")) > 0))
End Function

Private Function LABEL_IsNetworkTopologySheet(ByVal ws As Worksheet) As Boolean
    Dim normalizedName As String
    Dim lastColumn As Long
    Dim columnNumber As Long
    Dim portHeaderCount As Long

    normalizedName = UCase$(ws.Name)

    ' Skip summary, configuration, audit, and generated clean sheets.
    If InStr(1, normalizedName, "CLEAN", vbTextCompare) > 0 Then Exit Function
    If normalizedName = "NETWORK_AUTO_SUMMARY" Then Exit Function
    If normalizedName = "NETWORK_AUTO_EXCLUDED" Then Exit Function
    If normalizedName = "AREA_NETWORK_SWITCH_MAP" Then Exit Function
    If normalizedName = "IO_ROUTE_MASTER" Then Exit Function
    If normalizedName = "IO_ROUTE_ERRORS" Then Exit Function
    If normalizedName = "IO_ROUTE_CONFIG" Then Exit Function
    If normalizedName = "MAIN" Then Exit Function

    lastColumn = LABEL_LastUsedColumn(ws)
    If lastColumn < 2 Then Exit Function

    ' A raw topology sheet has several X01-X09 port headings in row 1.
    For columnNumber = 1 To Application.Min(lastColumn, 50)
        If LABEL_IsPortHeader( _
            UCase$(Trim$(CStr(ws.Cells(1, columnNumber).Value2)))) Then

            portHeaderCount = portHeaderCount + 1
        End If
    Next columnNumber

    LABEL_IsNetworkTopologySheet = (portHeaderCount >= 2)
End Function


Private Function LABEL_IsPortHeader(ByVal portText As String) As Boolean
    'Raw topology imports may use X1..X9 while other workflows use X01..X09.
    LABEL_IsPortHeader = (Len(ONGEN_CableID_NormalizeNetworkPort(portText)) > 0)
End Function


Private Function LABEL_MetadataValue( _
    ByVal metadata As String, _
    ByVal keyName As String) As String

    Dim fields() As String
    Dim i As Long
    Dim separatorPosition As Long
    Dim fieldName As String
    Dim fieldValue As String

    metadata = Trim$(metadata)
    keyName = UCase$(Trim$(keyName))

    If Len(metadata) = 0 Or Len(keyName) = 0 Then Exit Function

    fields = Split(metadata, "|")

    For i = LBound(fields) To UBound(fields)
        separatorPosition = InStr(1, fields(i), "=", vbBinaryCompare)

        If separatorPosition > 0 Then
            fieldName = UCase$(Trim$(Left$(fields(i), separatorPosition - 1)))
            fieldValue = Trim$(mid$(fields(i), separatorPosition + 1))

            If fieldName = keyName Then
                LABEL_MetadataValue = fieldValue
                Exit Function
            End If
        End If
    Next i
End Function


Private Function LABEL_CleanTopologyDevice(ByVal topologyText As String) As String
    Dim bracketPosition As Long

    topologyText = Trim$(topologyText)
    If Len(topologyText) = 0 Then Exit Function

    ' Ignore metadata accidentally copied into the device area.
    If InStr(1, topologyText, "AUTO NETWORK|", vbTextCompare) > 0 Then Exit Function
    If InStr(1, topologyText, "STATUS=AVAILABLE", vbTextCompare) > 0 Then Exit Function

    ' Keep the device identifier and remove the descriptive text in brackets.
    bracketPosition = InStr(1, topologyText, "[", vbBinaryCompare)

    If bracketPosition > 1 Then
        topologyText = Trim$(Left$(topologyText, bracketPosition - 1))
    End If

    LABEL_CleanTopologyDevice = topologyText
End Function


Private Function LABEL_PanelFromTopologySheetName(ByVal sheetName As String) As String
    Dim normalizedName As String
    Dim markerPosition As Long

    normalizedName = sheetName

    ' Remove common AUTO or topology suffixes while preserving the panel ID.
    markerPosition = InStr(1, UCase$(normalizedName), "_NSW", vbTextCompare)
    If markerPosition > 1 Then normalizedName = Left$(normalizedName, markerPosition - 1)

    markerPosition = InStr(1, UCase$(normalizedName), "-NSW", vbTextCompare)
    If markerPosition > 1 Then normalizedName = Left$(normalizedName, markerPosition - 1)

    markerPosition = InStr(1, UCase$(normalizedName), "_NETWORK", vbTextCompare)
    If markerPosition > 1 Then normalizedName = Left$(normalizedName, markerPosition - 1)

    LABEL_PanelFromTopologySheetName = Trim$(normalizedName)
End Function


Private Function LABEL_DefaultNetworkSwitchName( _
    ByVal panel As String, _
    ByVal sheetName As String) As String

    If Len(Trim$(panel)) > 0 Then
        LABEL_DefaultNetworkSwitchName = Trim$(panel) & "-NSW01"
    ElseIf Len(Trim$(sheetName)) > 0 Then
        LABEL_DefaultNetworkSwitchName = Trim$(sheetName) & "-NSW01"
    Else
        LABEL_DefaultNetworkSwitchName = "NETWORK SWITCH"
    End If
End Function


'===============================================================================
' WORKBOOK / HEADER HELPERS
'===============================================================================

Private Function LABEL_WorksheetExists( _
    ByVal sheetName As String, _
    ByVal workbookObject As Workbook) As Boolean

    Dim ws As Worksheet

    On Error Resume Next
    Set ws = workbookObject.Worksheets(sheetName)
    LABEL_WorksheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function


Private Function LABEL_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim lastCell As Range

    On Error Resume Next

    Set lastCell = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    On Error GoTo 0

    If lastCell Is Nothing Then
        LABEL_LastUsedRow = 1
    Else
        LABEL_LastUsedRow = lastCell.Row
    End If
End Function


Private Function LABEL_LastUsedColumn(ByVal ws As Worksheet) As Long
    Dim lastCell As Range

    On Error Resume Next

    Set lastCell = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByColumns, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    On Error GoTo 0

    If lastCell Is Nothing Then
        LABEL_LastUsedColumn = 1
    Else
        LABEL_LastUsedColumn = lastCell.Column
    End If
End Function


Private Function LABEL_CreateHeaderMap( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal lastColumn As Long) As Object

    Dim headerMap As Object
    Dim columnNumber As Long
    Dim normalizedHeader As String

    Set headerMap = CreateObject("Scripting.Dictionary")
    headerMap.CompareMode = vbTextCompare

    For columnNumber = 1 To lastColumn
        normalizedHeader = LABEL_NormalizeHeader( _
            CStr(ws.Cells(headerRow, columnNumber).Value2))

        If Len(normalizedHeader) > 0 Then
            If Not headerMap.Exists(normalizedHeader) Then
                headerMap.Add normalizedHeader, columnNumber
            End If
        End If
    Next columnNumber

    Set LABEL_CreateHeaderMap = headerMap
End Function


Private Function LABEL_CellByHeader( _
    ByVal ws As Worksheet, _
    ByVal rowNumber As Long, _
    ByVal headerMap As Object, _
    ParamArray aliases() As Variant) As String

    Dim i As Long
    Dim normalizedAlias As String

    For i = LBound(aliases) To UBound(aliases)
        normalizedAlias = LABEL_NormalizeHeader(CStr(aliases(i)))

        If headerMap.Exists(normalizedAlias) Then
            LABEL_CellByHeader = Trim$(CStr( _
                ws.Cells(rowNumber, CLng(headerMap(normalizedAlias))).Value2))
            Exit Function
        End If
    Next i
End Function


Private Function LABEL_NormalizeHeader(ByVal headerText As String) As String
    Dim normalizedText As String

    normalizedText = UCase$(Trim$(headerText))
    normalizedText = Replace(normalizedText, vbCr, " ")
    normalizedText = Replace(normalizedText, vbLf, " ")
    normalizedText = Replace(normalizedText, "_", " ")
    normalizedText = Replace(normalizedText, "-", " ")
    normalizedText = Replace(normalizedText, "(", " ")
    normalizedText = Replace(normalizedText, ")", " ")
    normalizedText = Replace(normalizedText, "/", " ")
    normalizedText = Replace(normalizedText, ".", " ")

    Do While InStr(1, normalizedText, "  ", vbBinaryCompare) > 0
        normalizedText = Replace(normalizedText, "  ", " ")
    Loop

    LABEL_NormalizeHeader = Trim$(normalizedText)
End Function


Private Function LABEL_Is24VPanelSheet(ByVal ws As Worksheet) As Boolean
    Dim n As String, lastRow As Long, r As Long
    n = UCase$(Trim$(ws.Name))

    'Support both legacy 24V_<Panel> and current <Panel>_24V naming, but do not
    'mistake support/report sheets such as 24V_NOT_GENERATED or
    '24V_OVERLOAD_TERMINALS for a generated panel power sheet.
    If n = UCase$("24v_Power Generator") Then Exit Function
    If Left$(n, 4) <> "24V_" And Right$(n, 4) <> "_24V" Then Exit Function

    lastRow = LABEL_LastUsedRow(ws)
    For r = 1 To lastRow
        If LABEL_NormalizeHeader(CStr(ws.Cells(r, 1).Value2)) = "PWG" And _
           LABEL_NormalizeHeader(CStr(ws.Cells(r, 2).Value2)) = "BUS POWER" Then
            LABEL_Is24VPanelSheet = True
            Exit Function
        End If
    Next r
End Function

Private Function LABEL_PanelFrom24VSheetName(ByVal sheetName As String) As String
    Dim s As String
    s = Trim$(sheetName)
    If UCase$(Left$(s, 4)) = "24V_" Then
        s = mid$(s, 5)
    ElseIf UCase$(Right$(s, 4)) = "_24V" Then
        s = Left$(s, Len(s) - 4)
    End If
    LABEL_PanelFrom24VSheetName = Trim$(s)
End Function


Private Function LABEL_KeepLettersAndNumbers(ByVal textValue As String) As String
    Dim i As Long
    Dim oneCharacter As String
    Dim resultText As String

    For i = 1 To Len(textValue)
        oneCharacter = mid$(textValue, i, 1)

        If oneCharacter Like "[A-Za-z0-9]" Then
            resultText = resultText & oneCharacter
        End If
    Next i

    LABEL_KeepLettersAndNumbers = resultText
End Function


'===============================================================================
' SAVE / FORMAT HELPERS
'===============================================================================

Private Function LABEL_GetSavePath() As Variant
    Dim defaultFolder As String
    Dim defaultFileName As String

    If Len(ThisWorkbook.Path) > 0 Then
        defaultFolder = ThisWorkbook.Path
    Else
        defaultFolder = Environ$("USERPROFILE") & "\Documents"
    End If

    defaultFileName = defaultFolder & Application.PathSeparator & _
                      LABEL_REPORT_PREFIX & _
                      Format$(Now, "yyyymmdd_hhnnss") & ".xlsx"

    LABEL_GetSavePath = Application.GetSaveAsFilename( _
        InitialFileName:=defaultFileName, _
        FileFilter:="Excel Workbook (*.xlsx), *.xlsx", _
        title:="Save ONGEN IO / Network / Power Label Report")
End Function


Private Sub LABEL_FormatTitleRange(ByVal titleRange As Range)
    With titleRange
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
        .Font.Size = 16
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .RowHeight = 30
    End With
End Sub


Private Sub LABEL_FormatSectionRange(ByVal sectionRange As Range)
    With sectionRange
        .Interior.Color = RGB(68, 114, 196)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .RowHeight = 22
    End With
End Sub


Private Sub LABEL_FormatHeaderRange(ByVal headerRange As Range)
    With headerRange
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .RowHeight = 30
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(255, 255, 255)
    End With
End Sub


Private Sub LABEL_SetColumnWidthByHeader( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal headerText As String, _
    ByVal columnWidth As Double)

    Dim lastColumn As Long
    Dim columnNumber As Long

    lastColumn = LABEL_LastUsedColumn(ws)

    For columnNumber = 1 To lastColumn
        If StrComp( _
            Trim$(CStr(ws.Cells(headerRow, columnNumber).Value2)), _
            headerText, _
            vbTextCompare) = 0 Then

            ws.Columns(columnNumber).columnWidth = columnWidth
            Exit Sub
        End If
    Next columnNumber
End Sub


Private Function LABEL_ColumnLetter(ByVal columnNumber As Long) As String
    Dim resultText As String
    Dim remainderValue As Long

    ' Convert a positive column number to its Excel A, B, ..., AA notation.
    Do While columnNumber > 0
        remainderValue = (columnNumber - 1) Mod 26
        resultText = Chr$(65 + remainderValue) & resultText
        columnNumber = (columnNumber - 1) \ 26
    Loop

    LABEL_ColumnLetter = resultText
End Function

