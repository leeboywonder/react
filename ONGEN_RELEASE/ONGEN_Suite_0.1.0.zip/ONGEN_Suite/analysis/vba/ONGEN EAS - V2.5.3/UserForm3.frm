Attribute VB_Name = "UserForm3"
Attribute VB_Base = "0{C993EF93-64E4-465D-B5F2-65DC474ACBEE}{1D341FD3-240E-4327-AF38-77BE9109F959}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
