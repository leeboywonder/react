Attribute VB_Name = "mod00_ONGEN_Workflow_Core"
Option Explicit
'===============================================================================
' ONGEN EAS - CLEAN WORKFLOW CONTROLLER
' Author: Lee Pierre, Principal Electrical Engineer
' Purpose: Permanent production module for the ONGEN Engineering Automation Suite.
'          This module is part of the V26.3 clean workflow baseline.
'===============================================================================



'===============================================================================
' ONGEN EAS - CLEAN WORKFLOW CONTROLLER
'===============================================================================

Private Const ONGEN_BASELINE_SETUP_SHEET As String = "ONGEN_SYSTEM_SETUP"
Private Const ONGEN_BASELINE_REVISION As String = "2026.09.22-CLEAN-NEW-WORKBOOK-BASELINE"


Public Sub ONGEN_INITIALIZE_NEW_WORKBOOK()
    If ONGEN_INITIALIZE_NEW_WORKBOOK_SILENT(True) Then
        MsgBox _
            "ONGEN EAS clean workbook baseline is ready." & vbCrLf & vbCrLf & _
            "Revision: " & ONGEN_BASELINE_REVISION, _
            vbInformation, _
            "ONGEN EAS"
    Else
        MsgBox _
            "ONGEN EAS baseline initialization did not complete." & vbCrLf & _
            "Run ONGEN_BASELINE_DIAGNOSTIC for the current state.", _
            vbExclamation, _
            "ONGEN EAS"
    End If
End Sub


Public Function ONGEN_INITIALIZE_NEW_WORKBOOK_SILENT( _
    Optional ByVal forceInitialize As Boolean = False) As Boolean

    On Error GoTo Failed

    If Not forceInitialize Then
        If ONGEN_BaselineMarkerCurrent() Then
            ONGEN_INITIALIZE_NEW_WORKBOOK_SILENT = True
            Exit Function
        End If
    End If

    Dim oldScreen As Boolean
    Dim oldEvents As Boolean
    Dim oldAlerts As Boolean

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False

    If Not VFD_DWG_INITIALIZE_BASELINE_SILENT() Then
        Err.Raise vbObjectError + 21901, _
                  "ONGEN_INITIALIZE_NEW_WORKBOOK_SILENT", _
                  "VFD drawing baseline initialization failed."
    End If

    VFD_FUNCTION_INSTALL_SILENT

    On Error Resume Next
    NAV_Install_Return_To_MAIN_Buttons_All_Sheets False, False
    On Error GoTo Failed

    ONGEN_WriteBaselineMarker

    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    ONGEN_INITIALIZE_NEW_WORKBOOK_SILENT = True
    Exit Function

Failed:
    On Error Resume Next
    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    ONGEN_INITIALIZE_NEW_WORKBOOK_SILENT = False
End Function


Public Sub ONGEN_BASELINE_DIAGNOSTIC()
    Dim msg As String

    msg = "ONGEN EAS Clean Baseline Diagnostic" & vbCrLf & vbCrLf & _
          "Revision: " & ONGEN_BASELINE_REVISION & vbCrLf & _
          "Baseline marker current: " & CStr(ONGEN_BaselineMarkerCurrent()) & vbCrLf & _
          "VFD_DWG_CONFIG: " & CStr(ONGEN_BaselineSheetExists("VFD_DWG_CONFIG")) & vbCrLf & _
          "VFD_DWG_CIRCUIT_LIBRARY: " & CStr(ONGEN_BaselineSheetExists("VFD_DWG_CIRCUIT_LIBRARY")) & vbCrLf & _
          "VFD_DWG_DEVICE_LIBRARY: " & CStr(ONGEN_BaselineSheetExists("VFD_DWG_DEVICE_LIBRARY")) & vbCrLf & _
          "VFD_DWG_FUNCTION_DEVICE_MAP: " & CStr(ONGEN_BaselineSheetExists("VFD_DWG_FUNCTION_DEVICE_MAP")) & vbCrLf & _
          "VFD_FUNCTION_ASSIGNMENT: " & CStr(ONGEN_BaselineSheetExists("VFD_FUNCTION_ASSIGNMENT")) & vbCrLf & _
          "VFD_DWG_QUEUE: " & CStr(ONGEN_BaselineSheetExists("VFD_DWG_QUEUE"))

    MsgBox msg, vbInformation, "ONGEN EAS"
End Sub


Private Function ONGEN_BaselineMarkerCurrent() As Boolean
    On Error GoTo Nope
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(ONGEN_BASELINE_SETUP_SHEET)
    ONGEN_BaselineMarkerCurrent = _
        (Trim$(CStr(ws.Range("B2").Value2)) = ONGEN_BASELINE_REVISION)
    Exit Function
Nope:
    ONGEN_BaselineMarkerCurrent = False
End Function


Private Sub ONGEN_WriteBaselineMarker()
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(ONGEN_BASELINE_SETUP_SHEET)
    On Error GoTo 0

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = ONGEN_BASELINE_SETUP_SHEET
    End If

    ws.Range("A1:B3").ClearContents
    ws.Range("A1").Value2 = "ONGEN EAS CLEAN BASELINE"
    ws.Range("A2").Value2 = "BASELINE_REVISION"
    ws.Range("B2").Value2 = ONGEN_BASELINE_REVISION
    ws.Range("A3").Value2 = "LAST_INITIALIZED"
    ws.Range("B3").Value2 = Now
    ws.Visible = xlSheetVeryHidden
End Sub


Private Function ONGEN_BaselineSheetExists(ByVal sheetName As String) As Boolean
    On Error Resume Next
    ONGEN_BaselineSheetExists = Not ThisWorkbook.Worksheets(sheetName) Is Nothing
    On Error GoTo 0
End Function



Public Sub ONGEN_STEP15H_BUILD_ALL_CABLE_TAGS()
    On Error GoTo FailHandler

    Application.StatusBar = "ONGEN Step 15H: Building baseline cable tags..."
    Application.Run "'" & ThisWorkbook.Name & "'!Build_ONGEN_Combined_Label_List"

    Application.StatusBar = "ONGEN Step 15H: Building WNET cable tags..."
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_Network_Append_WNET_To_Output"

    Application.StatusBar = False
    Exit Sub

FailHandler:
    Application.StatusBar = False

    MsgBox _
        "Step 15H - Build Combined Cable Tag Output failed." & vbCrLf & vbCrLf & _
        "Error " & CStr(Err.Number) & ": " & Err.description, _
        vbCritical, _
        "ONGEN Workflow"
End Sub


Public Sub ONGEN_STEP17_EXPORT_LABEL_REPORT()
    On Error GoTo FailHandler

    Application.Run _
        "'" & ThisWorkbook.Name & "'!ONGEN_Export_Label_List_Report_CORE"
    Exit Sub

FailHandler:
    MsgBox _
        "Step 17 - Export Label Report failed." & vbCrLf & vbCrLf & _
        "Error " & CStr(Err.Number) & ": " & Err.description, _
        vbCritical, _
        "ONGEN Workflow"
End Sub


Public Sub ONGEN_BIND_CLEAN_STEP17_BUTTON()
    On Error GoTo FailHandler

    Dim ws As Worksheet
    Dim shp As Shape
    Dim actionName As String
    Dim macroName As String
    Dim changed As Long

    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            actionName = vbNullString

            On Error Resume Next
            actionName = shp.OnAction
            On Error GoTo FailHandler

            macroName = ONGEN_NormalizeAction(actionName)

            If StrComp( _
                macroName, _
                "BTN_Export_Label_List_Report", _
                vbTextCompare) = 0 Then

                shp.OnAction = _
                    "'" & Replace(ThisWorkbook.Name, "'", "''") & _
                    "'!ONGEN_STEP17_EXPORT_LABEL_REPORT"

                changed = changed + 1
            End If
        Next shp
    Next ws

    MsgBox _
        "Clean Step 17 button binding complete." & vbCrLf & _
        "Buttons changed: " & CStr(changed) & vbCrLf & vbCrLf & _
        "Step 17 now runs ONGEN_STEP17_EXPORT_LABEL_REPORT.", _
        vbInformation, _
        "ONGEN Workflow"
    Exit Sub

FailHandler:
    MsgBox _
        "Step 17 button binding failed." & vbCrLf & _
        "Error " & CStr(Err.Number) & ": " & Err.description, _
        vbCritical, _
        "ONGEN Workflow"
End Sub


Private Function ONGEN_NormalizeAction(ByVal actionName As String) As String
    Dim s As String

    s = Trim$(actionName)

    If InStrRev(s, "!") > 0 Then
        s = mid$(s, InStrRev(s, "!") + 1)
    End If

    s = Replace$(s, "'", "")
    ONGEN_NormalizeAction = Trim$(s)
End Function


'Final release clear is intentionally owned by mod05_ONGEN_Safe_Clear.

'UI buttons should call ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE directly.

