Attribute VB_Name = "CREATE_RCP_MAP"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : CREATE_RCP_MAP
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : CREATE_RCP_MAP
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Shared missing-only output protection and Step11B compatibility integrated.
' Notes         : Protects existing generated worksheets and restores them after missing-only generation or failure.
'-------------------------------------------------------------------------------

' Require every variable to be declared before use, which prevents spelling mistakes from creating unintended variables.
' [R7 LINE] Requires explicit variable declarations to prevent misspelled variables.
Option Explicit

Private mONGENProtectionActive As Boolean

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R7
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-13
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

'PD6 automatic network map. Existing CSV Step 11 remains available.
'
'DATA-DRIVEN NETWORK TYPE RULE
'  The DATA worksheet table is the only source of network-enabled device types.
'  CONTROL DEVICE supplies the output description, DEVICE TYPE supplies the canonical type,
'  every ALTERNATE column supplies a valid input alias, and BLOCK / TERMINAL columns supply
'  the clean-sheet drawing lookup. No row is network-enabled unless it exists in this table.
'
'NETWORK CAPACITY RULES
'  AREA main-panel switch: 8 local-panel outfeeds per switch, X01-X08.
'    More than 8 panels automatically creates AREA switch 2, 3, etc., and restarts X01.
'  RCP panel switch: 8 device outfeeds per switch, X01-X08.
'    When another panel switch is required, the user receives a Yes/No/Cancel dialog.
'  X09 is the dedicated uplink on every generated panel network-switch map.
'  RACK/RCK keeps X01 priority on the first panel switch whenever available.
'  RIO and IO/S are isolated together first inside each Panel + SwitchGroup.
'  When preferred isolation would require unavailable ports, the user chooses either
'  an additional panel network switch or controlled mixing with other devices.
'  The 80 m maximum and Panel + SwitchGroup boundaries always remain mandatory.

' Define the fixed configuration value AN_SOURCE_SHEET so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_SOURCE_SHEET As String = "PD6_IMPORT"
' Define the fixed configuration value AN_DATA_SHEET so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_DATA_SHEET As String = "DATA"
' Define the fixed configuration value AN_SUMMARY_SHEET so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_SUMMARY_SHEET As String = "NETWORK_AUTO_SUMMARY"
' Define the fixed configuration value AN_EXCLUDED_SHEET so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_EXCLUDED_SHEET As String = "NETWORK_AUTO_EXCLUDED"
' Define the fixed configuration value AN_AREA_SWITCH_SHEET so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_AREA_SWITCH_SHEET As String = "AREA_NETWORK_SWITCH_MAP"
' Define the fixed configuration value AN_MAX_ROUTE_METERS so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_MAX_ROUTE_METERS As Double = 80#
' Define the fixed configuration value AN_FIRST_DEVICE_PORT so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_FIRST_DEVICE_PORT As Long = 1
' Define the fixed configuration value AN_LAST_DEVICE_PORT so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_LAST_DEVICE_PORT As Long = 8
' Define the fixed configuration value AN_UPLINK_PORT so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_UPLINK_PORT As Long = 9
' Define the fixed configuration value AN_PORTS_PER_SWITCH so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_PORTS_PER_SWITCH As Long = 8
' Define the fixed configuration value AN_MARKER so it can be changed in one location.
' [R7 LINE] Defines a fixed module setting used by the routing or launcher workflow.
Private Const AN_MARKER As String = "AUTO NETWORK"

' [R7 LINE] Starts Sub Prepare_Auto_Network_From_PD6; the following statements perform or calculate this named workflow.
Public Sub Prepare_Auto_Network_From_PD6()
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim wb As Workbook, wsSrc As Worksheet, wsOut As Worksheet
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim wsSummary As Worksheet, wsExcluded As Worksheet, wsArea As Worksheet
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim wsAreaSwitch As Worksheet
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim headers As Object, devices As Object, groupFlags As Object, mixGroups As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim routeCounts As Object, trialMixGroups As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim preapprovedSwitchCounts As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panelSheets As Object, panelSeen As Object, panelAreas As Object, areaMains As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panelRacks As Object, allowedTypes As Object, areaAssignments As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim data As Variant, items As Variant, rec As Variant, records As Variant
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim lastRow As Long, lastCol As Long, i As Long, n As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim colPanel As Long, colSwg As Long, colSeq As Long, colType As Long, colLen As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim colArea As Long, colControlCard As Long, colSystemType As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panel As String, swg As String, sisSeq As String, deviceType As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim canonicalType As String, mainType As String, mainAreaNumber As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim areaNumber As String, controlCard As String, systemType As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim dataDescription As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim routeLength As Double, sortSequence As Double, description As String, topologyText As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As String, groupKey As String, baseGroupKey As String, firstArea As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim duplicateCount As Long, skippedTypeCount As Long, excludedCount As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim summaryRow As Long, excludedRow As Long, routeCount As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim overflowRouteCount As Long, overflowDeviceCount As Long, missingUplinkCount As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim rackCount As Long, hasPanelRack As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim currentPanel As String, currentGroup As String, sheetName As String, currentPanelArea As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim portNumber As Long, outputRow As Long, outputCol As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim segmentCount As Long, segmentZeroLength As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim segmentLength As Double, segmentFirstSeq As String, segmentLastSeq As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim segmentArea As String, segmentSwg As String, segmentRouteFamily As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim segmentPanelSwitch As Long, panelSwitchNumber As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim keepGroupTogether As Boolean, panelExpansionDeclined As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim answer As VbMsgBoxResult
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panelKey As Variant, dedicatedCount As Long, mixedCount As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim extraAreaSwitchCount As Long, totalAreaSwitchCount As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim extraPanelSwitchCount As Long, panelExpansionDeclinedCount As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim oldCalc As XlCalculation
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim oldCalcCaptured As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim savedErrNumber As Long, savedErrDescription As String, savedErrSource As String

    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo ErrHandler

    ' [R7 LINE] Calculates or updates oldCalc using the expression in this statement.
    oldCalc = Application.Calculation
    ' [R7 LINE] Calculates or updates oldCalcCaptured using the expression in this statement.
    oldCalcCaptured = True
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to wb.
    Set wb = ThisWorkbook
    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsSrc.
    Set wsSrc = wb.Worksheets(AN_SOURCE_SHEET)
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo ErrHandler
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If wsSrc Is Nothing Then Err.Raise vbObjectError + 7100, , "Worksheet '" & AN_SOURCE_SHEET & "' was not found."

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to allowedTypes.
    Set allowedTypes = AN_LoadNetworkDeviceTypes(wb)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If allowedTypes.count = 0 Then
        ' Stop the workflow with a controlled error because continuing would create an invalid or incomplete network result.
        ' [R7 LINE] Stops the workflow with a controlled error because continuing would create an invalid result.
        Err.Raise vbObjectError + 7101, , _
            "No valid network mapping table was found on the DATA worksheet." & vbCrLf & _
            "Expected headers include CONTROL DEVICE, DEVICE TYPE, one or more ALTERNATE columns, BLOCK, TERMINAL (IN), and TERMINAL (OUT)."
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates LastRow using the expression in this statement.
    lastRow = AN_LastUsedRow(wsSrc)
    ' [R7 LINE] Calculates or updates lastCol using the expression in this statement.
    lastCol = AN_LastUsedCol(wsSrc)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If lastRow < 2 Then Err.Raise vbObjectError + 7102, , "PD6_IMPORT does not contain device rows."

    ' [R7 LINE] Calculates or updates data using the expression in this statement.
    data = wsSrc.Range(wsSrc.Cells(1, 1), wsSrc.Cells(lastRow, lastCol)).Value2
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to headers.
    Set headers = AN_BuildHeaderMap(data, lastCol)

    ' [R7 LINE] Calculates or updates colPanel using the expression in this statement.
    colPanel = AN_HeaderCol(headers, "PNL", "PANEL")
    ' [R7 LINE] Calculates or updates colSwg using the expression in this statement.
    colSwg = AN_HeaderCol(headers, "SWITCHGROUP", "SWITCH GROUP", "PWG")
    ' [R7 LINE] Calculates or updates colSeq using the expression in this statement.
    colSeq = AN_HeaderCol(headers, "SIS_SEQUENCE", "SIS SEQUENCE", "SEQUENCE")
    ' [R7 LINE] Calculates or updates colType using the expression in this statement.
    colType = AN_HeaderCol(headers, "TYPE", "DEVICE TYPE")
    ' [R7 LINE] Calculates or updates colLen using the expression in this statement.
    colLen = AN_HeaderCol(headers, "MODULE LENGTH (ML)", "MODULE LENGTH", "ML")
    ' [R7 LINE] Calculates or updates colArea using the expression in this statement.
    colArea = AN_HeaderCol(headers, "AREA_NUMBER", "AREA NUMBER", "LOCATION")
    ' [R7 LINE] Calculates or updates colControlCard using the expression in this statement.
    colControlCard = AN_HeaderCol(headers, "CONTROL CARD", "CONTROL_CARD")
    ' [R7 LINE] Calculates or updates colSystemType using the expression in this statement.
    colSystemType = AN_HeaderCol(headers, "SYSTEM TYPE", "SYSTEM_TYPE")

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If colPanel = 0 Or colSwg = 0 Or colSeq = 0 Or colType = 0 Or colLen = 0 Or colArea = 0 Then
        ' Stop the workflow with a controlled error because continuing would create an invalid or incomplete network result.
        ' [R7 LINE] Stops the workflow with a controlled error because continuing would create an invalid result.
        Err.Raise vbObjectError + 7103, , _
            "PD6_IMPORT requires PNL, SwitchGroup, SIS_sequence, TYPE, Module Length (ML), and AREA_Number headers."
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.ScreenUpdating = False
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.EnableEvents = False
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.DisplayAlerts = False
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Calculation = xlCalculationManual
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.StatusBar = "Preparing DATA-driven automatic RCP network map..."

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to devices.
    Set devices = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to groupFlags.
    Set groupFlags = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to mixGroups.
    Set mixGroups = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to preapprovedSwitchCounts.
    Set preapprovedSwitchCounts = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to panelSheets.
    Set panelSheets = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to panelSeen.
    Set panelSeen = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to panelAreas.
    Set panelAreas = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to areaMains.
    Set areaMains = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to panelRacks.
    Set panelRacks = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Calculates or updates devices.CompareMode using the expression in this statement.
    devices.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates groupFlags.CompareMode using the expression in this statement.
    groupFlags.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates mixGroups.CompareMode using the expression in this statement.
    mixGroups.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates preapprovedSwitchCounts.CompareMode using the expression in this statement.
    preapprovedSwitchCounts.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates panelSheets.CompareMode using the expression in this statement.
    panelSheets.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates panelSeen.CompareMode using the expression in this statement.
    panelSeen.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates panelAreas.CompareMode using the expression in this statement.
    panelAreas.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates areaMains.CompareMode using the expression in this statement.
    areaMains.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates panelRacks.CompareMode using the expression in this statement.
    panelRacks.CompareMode = vbTextCompare

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsExcluded.
    Set wsExcluded = AN_GetOrCreateSheet(wb, AN_EXCLUDED_SHEET)
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsExcluded.Cells.Clear
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsExcluded.Range("A1:H1").value = Array("Source Row", "Panel", "AREA_Number", "SwitchGroup", _
        "SIS Sequence", "TYPE", "Module Length", "Reason")
    ' [R7 LINE] Calculates or updates excludedRow using the expression in this statement.
    excludedRow = 2

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 2 To UBound(data, 1)
        ' [R7 LINE] Calculates or updates deviceType using the expression in this statement.
        deviceType = AN_ArrayText(data, i, colType)
        ' [R7 LINE] Calculates or updates panel using the expression in this statement.
        panel = AN_ArrayText(data, i, colPanel)
        ' [R7 LINE] Calculates or updates swg using the expression in this statement.
        swg = AN_ArrayText(data, i, colSwg)
        ' [R7 LINE] Calculates or updates sisSeq using the expression in this statement.
        sisSeq = AN_ArrayText(data, i, colSeq)
        ' [R7 LINE] Calculates or updates areaNumber using the expression in this statement.
        areaNumber = AN_ArrayText(data, i, colArea)
        ' [R7 LINE] Calculates or updates controlCard using the expression in this statement.
        controlCard = AN_ArrayText(data, i, colControlCard)
        ' [R7 LINE] Calculates or updates systemType using the expression in this statement.
        systemType = AN_ArrayText(data, i, colSystemType)
        ' [R7 LINE] Calculates or updates sisSeq using the expression in this statement.
        sisSeq = PD6Net_NormalizeSequence(sisSeq, areaNumber, swg)

        ' [R7 LINE] Calculates or updates mainType using the expression in this statement.
        mainType = AN_AreaMainTypeFromData(deviceType, sisSeq, allowedTypes)
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(mainType) > 0 Then
            ' [R7 LINE] Calculates or updates mainAreaNumber using the expression in this statement.
            mainAreaNumber = AN_MainAreaNumber(mainType, sisSeq, areaNumber)
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Len(mainAreaNumber) = 0 Or Len(sisSeq) = 0 Then
                ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                AN_WriteExcluded wsExcluded, excludedRow, i, panel, areaNumber, swg, sisSeq, _
                    deviceType, AN_ArrayText(data, i, colLen), "AREA MAIN PANEL IS MISSING AN AREA IDENTIFIER OR SIS_SEQUENCE"
                ' [R7 LINE] Calculates or updates excludedCount using the expression in this statement.
                excludedCount = excludedCount + 1
            ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
            Else
                ' [R7 LINE] Calculates or updates sortSequence using the expression in this statement.
                sortSequence = PD6Net_FirstNumber(sisSeq)
                ' [R7 LINE] Calculates or updates dataDescription using the expression in this statement.
                dataDescription = AN_DataControlDeviceForType(allowedTypes, mainType)
                ' [R7 LINE] Calculates or updates topologyText using the expression in this statement.
                topologyText = AN_MainPanelTopologyText(swg, sisSeq, mainType, dataDescription)
                ' [R7 LINE] Calculates or updates key using the expression in this statement.
                key = UCase$(mainAreaNumber) & "|" & UCase$(sisSeq) & "|" & mainType
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Not areaMains.Exists(key) Then
                    ' [R7 LINE] Calculates or updates rec using the expression in this statement.
                    rec = Array(mainAreaNumber, panel, swg, sisSeq, mainType, sortSequence, topologyText, i)
                    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                    areaMains.Add key, rec
                ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                Else
                    ' [R7 LINE] Calculates or updates duplicateCount using the expression in this statement.
                    duplicateCount = duplicateCount + 1
                ' [R7 LINE] Ends the current conditional block.
                End If
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Len(firstArea) = 0 Then firstArea = mainAreaNumber
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Calculates or updates canonicalType using the expression in this statement.
            canonicalType = AN_CanonicalRouteTypeFromData(deviceType, sisSeq, controlCard, systemType, allowedTypes)
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Len(canonicalType) = 0 Then
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Len(Trim$(deviceType)) > 0 Then skippedTypeCount = skippedTypeCount + 1
            ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
            ElseIf canonicalType = "RACK" Then
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Len(panel) = 0 Or Len(areaNumber) = 0 Then
                    ' [R7 LINE] Calculates or updates description using the expression in this statement.
                    description = vbNullString
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If Len(panel) = 0 Then description = "Missing Panel"
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If Len(areaNumber) = 0 Then
                        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                        If Len(description) > 0 Then description = description & "; "
                        ' [R7 LINE] Calculates or updates description using the expression in this statement.
                        description = description & "Missing AREA_Number"
                    ' [R7 LINE] Ends the current conditional block.
                    End If
                    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                    AN_WriteExcluded wsExcluded, excludedRow, i, panel, areaNumber, swg, sisSeq, _
                        deviceType, AN_ArrayText(data, i, colLen), description
                    ' [R7 LINE] Calculates or updates excludedCount using the expression in this statement.
                    excludedCount = excludedCount + 1
                ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                Else
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If Len(sisSeq) = 0 Then sisSeq = panel & " RACK"
                    ' [R7 LINE] Calculates or updates sortSequence using the expression in this statement.
                    sortSequence = PD6Net_FirstNumber(sisSeq)
                    ' [R7 LINE] Calculates or updates dataDescription using the expression in this statement.
                    dataDescription = AN_DataControlDeviceForRoute(allowedTypes, deviceType, sisSeq, controlCard, systemType)
                    ' [R7 LINE] Calculates or updates topologyText using the expression in this statement.
                    topologyText = AN_RackTopologyText(panel, dataDescription)
                    ' [R7 LINE] Calculates or updates key using the expression in this statement.
                    key = UCase$(Trim$(panel))

                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If panelRacks.Exists(key) Then
                        ' [R7 LINE] Calculates or updates rec using the expression in this statement.
                        rec = panelRacks(key)
                        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                        If sortSequence < CDbl(rec(4)) Then
                            ' [R7 LINE] Calculates or updates rec using the expression in this statement.
                            rec = Array(panel, swg, sisSeq, "RACK", sortSequence, topologyText, areaNumber, i)
                            ' [R7 LINE] Calculates or updates panelRacks(key) using the expression in this statement.
                            panelRacks(key) = rec
                        ' [R7 LINE] Ends the current conditional block.
                        End If
                        ' [R7 LINE] Calculates or updates duplicateCount using the expression in this statement.
                        duplicateCount = duplicateCount + 1
                    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                    Else
                        ' [R7 LINE] Calculates or updates rec using the expression in this statement.
                        rec = Array(panel, swg, sisSeq, "RACK", sortSequence, topologyText, areaNumber, i)
                        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                        panelRacks.Add key, rec
                    ' [R7 LINE] Ends the current conditional block.
                    End If

                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If Not panelAreas.Exists(UCase$(panel)) Then panelAreas.Add UCase$(panel), areaNumber
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If Len(firstArea) = 0 Then firstArea = areaNumber
                ' [R7 LINE] Ends the current conditional block.
                End If
            ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
            ElseIf Len(panel) = 0 Or Len(swg) = 0 Or Len(sisSeq) = 0 Or Len(areaNumber) = 0 Then
                ' [R7 LINE] Calculates or updates description using the expression in this statement.
                description = PD6Net_MissingReason(panel, swg, sisSeq)
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Len(areaNumber) = 0 Then
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If Len(description) > 0 Then description = description & "; "
                    ' [R7 LINE] Calculates or updates description using the expression in this statement.
                    description = description & "Missing AREA_Number"
                ' [R7 LINE] Ends the current conditional block.
                End If
                ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                AN_WriteExcluded wsExcluded, excludedRow, i, panel, areaNumber, swg, sisSeq, _
                    deviceType, AN_ArrayText(data, i, colLen), description
                ' [R7 LINE] Calculates or updates excludedCount using the expression in this statement.
                excludedCount = excludedCount + 1
            ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
            Else
                ' [R7 LINE] Calculates or updates routeLength using the expression in this statement.
                routeLength = PD6Net_ModuleLengthMeters(AN_ArrayValue(data, i, colLen))
                ' [R7 LINE] Calculates or updates sortSequence using the expression in this statement.
                sortSequence = PD6Net_FirstNumber(sisSeq)
                ' [R7 LINE] Calculates or updates description using the expression in this statement.
                description = AN_RouteDescription(canonicalType, deviceType, sisSeq, controlCard, systemType, allowedTypes)
                ' [R7 LINE] Calculates or updates topologyText using the expression in this statement.
                topologyText = PD6Net_TopologyCellText(swg, sisSeq, canonicalType, description)

                ' [R7 LINE] Calculates or updates key using the expression in this statement.
                key = UCase$(Trim$(panel)) & "|" & UCase$(Trim$(swg)) & "|" & _
                      UCase$(Trim$(sisSeq)) & "|" & canonicalType

                ' [R7 LINE] Calculates or updates groupKey using the expression in this statement.
                groupKey = AN_RouteGroupKey(panel, swg, canonicalType, mixGroups)
                ' [R7 LINE] Calculates or updates baseGroupKey using the expression in this statement.
                baseGroupKey = AN_BaseSwitchGroupKey(panel, swg)

                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If devices.Exists(key) Then
                    ' [R7 LINE] Calculates or updates rec using the expression in this statement.
                    rec = devices(key)
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If routeLength > CDbl(rec(4)) Then
                        ' [R7 LINE] Calculates or updates rec(4) using the expression in this statement.
                        rec(4) = routeLength
                        ' [R7 LINE] Calculates or updates devices(key) using the expression in this statement.
                        devices(key) = rec
                    ' [R7 LINE] Ends the current conditional block.
                    End If
                    ' [R7 LINE] Calculates or updates duplicateCount using the expression in this statement.
                    duplicateCount = duplicateCount + 1
                ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                Else
                    ' [R7 LINE] Calculates or updates rec using the expression in this statement.
                    rec = Array(panel, swg, sisSeq, canonicalType, routeLength, sortSequence, _
                                description, topologyText, areaNumber, i, AN_DevicePriority(canonicalType))
                    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                    devices.Add key, rec
                ' [R7 LINE] Ends the current conditional block.
                End If

                'Track whether this Panel + SwitchGroup contains the preferred RIO/IO-S
                'family, general devices, or both. A value of 3 means mixing can save ports.
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Not groupFlags.Exists(baseGroupKey) Then groupFlags.Add baseGroupKey, 0
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If AN_IsRIOIOSRouteType(canonicalType) Then
                    ' [R7 LINE] Calculates or updates groupFlags(baseGroupKey) using the expression in this statement.
                    groupFlags(baseGroupKey) = CLng(groupFlags(baseGroupKey)) Or 1
                ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                Else
                    ' [R7 LINE] Calculates or updates groupFlags(baseGroupKey) using the expression in this statement.
                    groupFlags(baseGroupKey) = CLng(groupFlags(baseGroupKey)) Or 2
                ' [R7 LINE] Ends the current conditional block.
                End If

                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Not panelAreas.Exists(UCase$(panel)) Then panelAreas.Add UCase$(panel), areaNumber
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Len(firstArea) = 0 Then firstArea = areaNumber
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If devices.count = 0 Then
        ' Stop the workflow with a controlled error because continuing would create an invalid or incomplete network result.
        ' [R7 LINE] Stops the workflow with a controlled error because continuing would create an invalid result.
        Err.Raise vbObjectError + 7104, , _
            "No eligible RCP network devices were found. Check the DATA worksheet DEVICE TYPE table."
    ' [R7 LINE] Ends the current conditional block.
    End If

    'Build the preferred-isolation route plan first. RIO and IO/S share one family,
    'while all other devices use a separate family inside the same Panel + SwitchGroup.
    ' [R7 LINE] Calculates or updates records using the expression in this statement.
    records = AN_BuildRouteRecords(devices, mixGroups, n)
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to routeCounts.
    Set routeCounts = AN_CountRoutesByPanel(records, n, panelRacks)

    'Only ask when preferred isolation actually causes first-switch port pressure and
    'mixing within the same Panel + SwitchGroup would reduce the route count.
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For Each panelKey In routeCounts.keys
        ' [R7 LINE] Calculates or updates dedicatedCount using the expression in this statement.
        dedicatedCount = CLng(routeCounts(panelKey))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If dedicatedCount > AN_PORTS_PER_SWITCH Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If AN_PanelHasMixOpportunity(groupFlags, CStr(panelKey)) Then
                ' [R7 LINE] Assigns the required workbook object or dictionary reference to trialMixGroups.
                Set trialMixGroups = AN_SelectRequiredPanelMixGroups( _
                    devices, groupFlags, CStr(panelKey), mixGroups, panelRacks, _
                    AN_PORTS_PER_SWITCH, mixedCount)

                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If mixedCount > 0 And mixedCount < dedicatedCount Then
                    ' [R7 LINE] Calculates or updates answer using the expression in this statement.
                    answer = AN_AskRIOIOSCapacityChoice(CStr(panelKey), dedicatedCount, mixedCount)
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If answer = vbYes Then
                        'Yes keeps the preferred isolation and pre-approves the number of
                        'panel network switches required by the isolated route plan.
                        ' [R7 LINE] Calculates or updates preapprovedSwitchCounts(CStr(panelKey)) using the expression in this statement.
                        preapprovedSwitchCounts(CStr(panelKey)) = _
                            AN_CeilingDivide(dedicatedCount, AN_PORTS_PER_SWITCH)
                    ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
                    ElseIf answer = vbNo Then
                        'No authorizes controlled mixing only in eligible Panel + SwitchGroup
                        'families. The final map still splits every route at 80 m.
                        ' [R7 LINE] Assigns the required workbook object or dictionary reference to mixGroups.
                        Set mixGroups = trialMixGroups
                    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                    Else
                        ' [R7 LINE] Stops the workflow with a controlled error because continuing would create an invalid result.
                        Err.Raise vbObjectError + 7105, , _
                            "Automatic network generation was canceled by the user."
                    ' [R7 LINE] Ends the current conditional block.
                    End If
                ' [R7 LINE] Ends the current conditional block.
                End If
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next panelKey

    'Rebuild and sort the final record plan after all isolation/mixing choices are known.
    ' [R7 LINE] Calculates or updates records using the expression in this statement.
    records = AN_BuildRouteRecords(devices, mixGroups, n)

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    AN_SetNetworkMode wb, "AUTO"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    If Not ONGEN_GenerationProtectionActive() Then AN_DeletePriorAutoRawSheets wb

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsAreaSwitch.
    Set wsAreaSwitch = AN_GetOrCreateSheet(wb, AN_AREA_SWITCH_SHEET)
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to areaAssignments.
    Set areaAssignments = AN_BuildAreaPanelAssignments(panelAreas, areaMains, wsAreaSwitch, _
        extraAreaSwitchCount, totalAreaSwitchCount)

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsSummary.
    Set wsSummary = AN_GetOrCreateSheet(wb, AN_SUMMARY_SHEET)
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells.Clear
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("A1:N1").value = Array("Panel", "Area", "SwitchGroup", "Switch Port", _
        "Route Type", "Device Count", "Route Length (m)", "First Sequence", "Last Sequence", _
        "Missing/Zero Length", "Status", "Notes", "Panel Network Switch", "Upstream Switch / Port")
    ' [R7 LINE] Calculates or updates summaryRow using the expression in this statement.
    summaryRow = 2

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(firstArea) = 0 Then firstArea = "0"
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsArea.
    Set wsArea = AN_GetOrCreateSheet(wb, "AREA")
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsArea.Range("A1").value = "Area Number"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsArea.Range("A2").value = firstArea

    ' [R7 LINE] Calculates or updates currentPanel using the expression in this statement.
    currentPanel = vbNullString
    ' [R7 LINE] Calculates or updates currentGroup using the expression in this statement.
    currentGroup = vbNullString
    ' [R7 LINE] Calculates or updates portNumber using the expression in this statement.
    portNumber = AN_FIRST_DEVICE_PORT - 1

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 1 To n
        ' [R7 LINE] Calculates or updates panel using the expression in this statement.
        panel = CStr(records(i, 1))
        ' [R7 LINE] Calculates or updates swg using the expression in this statement.
        swg = CStr(records(i, 2))
        ' [R7 LINE] Calculates or updates groupKey using the expression in this statement.
        groupKey = CStr(records(i, 13))

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If StrComp(panel, currentPanel, vbTextCompare) <> 0 Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If segmentCount > 0 Then
                ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                AN_FinalizeSegment wsOut, wsSummary, summaryRow, portNumber, currentPanel, _
                    segmentArea, segmentSwg, segmentCount, segmentLength, segmentFirstSeq, _
                    segmentLastSeq, segmentZeroLength, segmentRouteFamily, segmentPanelSwitch, _
                    panelExpansionDeclined, routeCount, overflowRouteCount
            ' [R7 LINE] Ends the current conditional block.
            End If

            ' [R7 LINE] Calculates or updates currentPanel using the expression in this statement.
            currentPanel = panel
            ' [R7 LINE] Calculates or updates currentGroup using the expression in this statement.
            currentGroup = vbNullString
            ' [R7 LINE] Calculates or updates currentPanelArea using the expression in this statement.
            currentPanelArea = CStr(records(i, 9))
            ' [R7 LINE] Calculates or updates panelSwitchNumber using the expression in this statement.
            panelSwitchNumber = 1
            ' [R7 LINE] Calculates or updates panelExpansionDeclined using the expression in this statement.
            panelExpansionDeclined = False
            ' [R7 LINE] Calculates or updates sheetName using the expression in this statement.
            sheetName = AN_AutoPanelSwitchSheetName(wb, panel, panelSwitchNumber)
            ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsOut.
            Set wsOut = AN_GetOrCreateSheet(wb, sheetName)
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            wsOut.Cells.Clear
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            AN_InitializeTopologySheet wsOut, panel, currentPanelArea, panelSwitchNumber
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            AN_WriteAreaUplink wsOut, wsSummary, summaryRow, areaMains, areaAssignments, panel, _
                currentPanelArea, routeCount, missingUplinkCount
            ' [R7 LINE] Calculates or updates hasPanelRack using the expression in this statement.
            hasPanelRack = False
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            AN_WritePanelRack wsOut, wsSummary, summaryRow, panelRacks, panel, currentPanelArea, _
                routeCount, rackCount, hasPanelRack
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If hasPanelRack Then
                ' [R7 LINE] Calculates or updates portNumber using the expression in this statement.
                portNumber = AN_FIRST_DEVICE_PORT
            ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
            Else
                ' [R7 LINE] Calculates or updates portNumber using the expression in this statement.
                portNumber = AN_FIRST_DEVICE_PORT - 1
            ' [R7 LINE] Ends the current conditional block.
            End If
            ' [R7 LINE] Calculates or updates panelSheets(sheetName) using the expression in this statement.
            panelSheets(sheetName) = sheetName
            ' [R7 LINE] Calculates or updates panelSeen(UCase$(panel)) using the expression in this statement.
            panelSeen(UCase$(panel)) = True
            ' [R7 LINE] Calculates or updates segmentCount using the expression in this statement.
            segmentCount = 0
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If StrComp(groupKey, currentGroup, vbTextCompare) <> 0 Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If segmentCount > 0 Then
                ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                AN_FinalizeSegment wsOut, wsSummary, summaryRow, portNumber, currentPanel, _
                    segmentArea, segmentSwg, segmentCount, segmentLength, segmentFirstSeq, _
                    segmentLastSeq, segmentZeroLength, segmentRouteFamily, segmentPanelSwitch, _
                    panelExpansionDeclined, routeCount, overflowRouteCount
            ' [R7 LINE] Ends the current conditional block.
            End If

            ' [R7 LINE] Calculates or updates currentGroup using the expression in this statement.
            currentGroup = groupKey
            'All routes, including RIO / IO-S routes, retain the normal 80 m split rule.
            ' [R7 LINE] Calculates or updates keepGroupTogether using the expression in this statement.
            keepGroupTogether = False
            ' [R7 LINE] Calculates or updates portNumber using the expression in this statement.
            portNumber = portNumber + 1

            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If portNumber > AN_LAST_DEVICE_PORT And Not panelExpansionDeclined Then
                ' [R7 LINE] Calculates or updates answer using the expression in this statement.
                answer = AN_GetPanelSwitchDecision(panel, panelSwitchNumber + 1, preapprovedSwitchCounts)
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If answer = vbYes Then
                    ' [R7 LINE] Calculates or updates panelSwitchNumber using the expression in this statement.
                    panelSwitchNumber = panelSwitchNumber + 1
                    ' [R7 LINE] Calculates or updates extraPanelSwitchCount using the expression in this statement.
                    extraPanelSwitchCount = extraPanelSwitchCount + 1
                    ' [R7 LINE] Calculates or updates sheetName using the expression in this statement.
                    sheetName = AN_AutoPanelSwitchSheetName(wb, panel, panelSwitchNumber)
                    ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsOut.
                    Set wsOut = AN_GetOrCreateSheet(wb, sheetName)
                    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                    wsOut.Cells.Clear
                    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                    AN_InitializeTopologySheet wsOut, panel, currentPanelArea, panelSwitchNumber
                    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                    AN_WriteAdditionalPanelSwitchUplink wsOut, wsSummary, summaryRow, panel, _
                        currentPanelArea, panelSwitchNumber, routeCount
                    ' [R7 LINE] Calculates or updates panelSheets(sheetName) using the expression in this statement.
                    panelSheets(sheetName) = sheetName
                    ' [R7 LINE] Calculates or updates portNumber using the expression in this statement.
                    portNumber = AN_FIRST_DEVICE_PORT
                ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
                ElseIf answer = vbNo Then
                    ' [R7 LINE] Calculates or updates panelExpansionDeclined using the expression in this statement.
                    panelExpansionDeclined = True
                    ' [R7 LINE] Calculates or updates panelExpansionDeclinedCount using the expression in this statement.
                    panelExpansionDeclinedCount = panelExpansionDeclinedCount + 1
                ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                Else
                    ' Stop the workflow with a controlled error because continuing would create an invalid or incomplete network result.
                    ' [R7 LINE] Stops the workflow with a controlled error because continuing would create an invalid result.
                    Err.Raise vbObjectError + 7105, , "Automatic network generation was canceled by the user."
                ' [R7 LINE] Ends the current conditional block.
                End If
            ' [R7 LINE] Ends the current conditional block.
            End If

            ' [R7 LINE] Calculates or updates outputRow using the expression in this statement.
            outputRow = 3
            ' [R7 LINE] Calculates or updates segmentCount using the expression in this statement.
            segmentCount = 0
            ' [R7 LINE] Calculates or updates segmentLength using the expression in this statement.
            segmentLength = 0#
            ' [R7 LINE] Calculates or updates segmentZeroLength using the expression in this statement.
            segmentZeroLength = 0
            ' [R7 LINE] Calculates or updates segmentFirstSeq using the expression in this statement.
            segmentFirstSeq = vbNullString
            ' [R7 LINE] Calculates or updates segmentLastSeq using the expression in this statement.
            segmentLastSeq = vbNullString
            ' [R7 LINE] Calculates or updates segmentArea using the expression in this statement.
            segmentArea = CStr(records(i, 9))
            ' [R7 LINE] Calculates or updates segmentSwg using the expression in this statement.
            segmentSwg = swg
            ' [R7 LINE] Calculates or updates segmentRouteFamily using the expression in this statement.
            segmentRouteFamily = AN_RouteFamilyFromGroupKey(groupKey)
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If portNumber <= AN_LAST_DEVICE_PORT Then segmentPanelSwitch = panelSwitchNumber Else segmentPanelSwitch = 0

        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf segmentCount > 0 And segmentLength + CDbl(records(i, 5)) > AN_MAX_ROUTE_METERS Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Not keepGroupTogether Then
                ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                AN_FinalizeSegment wsOut, wsSummary, summaryRow, portNumber, currentPanel, _
                    segmentArea, segmentSwg, segmentCount, segmentLength, segmentFirstSeq, _
                    segmentLastSeq, segmentZeroLength, segmentRouteFamily, segmentPanelSwitch, _
                    panelExpansionDeclined, routeCount, overflowRouteCount

                ' [R7 LINE] Calculates or updates portNumber using the expression in this statement.
                portNumber = portNumber + 1
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If portNumber > AN_LAST_DEVICE_PORT And Not panelExpansionDeclined Then
                    ' [R7 LINE] Calculates or updates answer using the expression in this statement.
                    answer = AN_GetPanelSwitchDecision(panel, panelSwitchNumber + 1, preapprovedSwitchCounts)
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If answer = vbYes Then
                        ' [R7 LINE] Calculates or updates panelSwitchNumber using the expression in this statement.
                        panelSwitchNumber = panelSwitchNumber + 1
                        ' [R7 LINE] Calculates or updates extraPanelSwitchCount using the expression in this statement.
                        extraPanelSwitchCount = extraPanelSwitchCount + 1
                        ' [R7 LINE] Calculates or updates sheetName using the expression in this statement.
                        sheetName = AN_AutoPanelSwitchSheetName(wb, panel, panelSwitchNumber)
                        ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsOut.
                        Set wsOut = AN_GetOrCreateSheet(wb, sheetName)
                        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                        wsOut.Cells.Clear
                        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                        AN_InitializeTopologySheet wsOut, panel, currentPanelArea, panelSwitchNumber
                        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                        AN_WriteAdditionalPanelSwitchUplink wsOut, wsSummary, summaryRow, panel, _
                            currentPanelArea, panelSwitchNumber, routeCount
                        ' [R7 LINE] Calculates or updates panelSheets(sheetName) using the expression in this statement.
                        panelSheets(sheetName) = sheetName
                        ' [R7 LINE] Calculates or updates portNumber using the expression in this statement.
                        portNumber = AN_FIRST_DEVICE_PORT
                    ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
                    ElseIf answer = vbNo Then
                        ' [R7 LINE] Calculates or updates panelExpansionDeclined using the expression in this statement.
                        panelExpansionDeclined = True
                        ' [R7 LINE] Calculates or updates panelExpansionDeclinedCount using the expression in this statement.
                        panelExpansionDeclinedCount = panelExpansionDeclinedCount + 1
                    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
                    Else
                        ' Stop the workflow with a controlled error because continuing would create an invalid or incomplete network result.
                        ' [R7 LINE] Stops the workflow with a controlled error because continuing would create an invalid result.
                        Err.Raise vbObjectError + 7105, , "Automatic network generation was canceled by the user."
                    ' [R7 LINE] Ends the current conditional block.
                    End If
                ' [R7 LINE] Ends the current conditional block.
                End If

                ' [R7 LINE] Calculates or updates outputRow using the expression in this statement.
                outputRow = 3
                ' [R7 LINE] Calculates or updates segmentCount using the expression in this statement.
                segmentCount = 0
                ' [R7 LINE] Calculates or updates segmentLength using the expression in this statement.
                segmentLength = 0#
                ' [R7 LINE] Calculates or updates segmentZeroLength using the expression in this statement.
                segmentZeroLength = 0
                ' [R7 LINE] Calculates or updates segmentFirstSeq using the expression in this statement.
                segmentFirstSeq = vbNullString
                ' [R7 LINE] Calculates or updates segmentLastSeq using the expression in this statement.
                segmentLastSeq = vbNullString
                ' [R7 LINE] Calculates or updates segmentArea using the expression in this statement.
                segmentArea = CStr(records(i, 9))
                ' [R7 LINE] Calculates or updates segmentSwg using the expression in this statement.
                segmentSwg = swg
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If portNumber <= AN_LAST_DEVICE_PORT Then segmentPanelSwitch = panelSwitchNumber Else segmentPanelSwitch = 0
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If portNumber <= AN_LAST_DEVICE_PORT Then
            ' [R7 LINE] Calculates or updates outputCol using the expression in this statement.
            outputCol = portNumber
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            wsOut.Cells(outputRow, outputCol).value = CStr(records(i, 8))
            ' [R7 LINE] Calculates or updates outputRow using the expression in this statement.
            outputRow = outputRow + 1
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            AN_WriteExcluded wsExcluded, excludedRow, CLng(records(i, 10)), panel, CStr(records(i, 9)), _
                swg, CStr(records(i, 3)), CStr(records(i, 4)), CStr(records(i, 5)), _
                "NO AVAILABLE PANEL NETWORK PORT. USER DECLINED OR DID NOT ADD ANOTHER NETWORK SWITCH."
            ' [R7 LINE] Calculates or updates overflowDeviceCount using the expression in this statement.
            overflowDeviceCount = overflowDeviceCount + 1
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If segmentCount = 0 Then segmentFirstSeq = CStr(records(i, 3))
        ' [R7 LINE] Calculates or updates segmentLastSeq using the expression in this statement.
        segmentLastSeq = CStr(records(i, 3))
        ' [R7 LINE] Calculates or updates segmentCount using the expression in this statement.
        segmentCount = segmentCount + 1
        ' [R7 LINE] Calculates or updates segmentLength using the expression in this statement.
        segmentLength = segmentLength + CDbl(records(i, 5))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If CDbl(records(i, 5)) <= 0# Then segmentZeroLength = segmentZeroLength + 1
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If segmentCount > 0 Then
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        AN_FinalizeSegment wsOut, wsSummary, summaryRow, portNumber, currentPanel, _
            segmentArea, segmentSwg, segmentCount, segmentLength, segmentFirstSeq, _
            segmentLastSeq, segmentZeroLength, segmentRouteFamily, segmentPanelSwitch, _
            panelExpansionDeclined, routeCount, overflowRouteCount
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' Loop through every object or value in the referenced collection.
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For Each rec In panelSheets.items
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to wsOut.
        Set wsOut = wb.Worksheets(CStr(rec))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        AN_StyleTopologySheet wsOut
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next rec

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    AN_StyleReportSheet wsSummary, "A:N"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    AN_StyleReportSheet wsExcluded, "A:H"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    AN_StyleReportSheet wsAreaSwitch, "A:H"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P1:Q17").Clear
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P1:Q1").value = Array("AUTO NETWORK TOTALS", "VALUE")
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P2").value = "DATA type/alias keys loaded": wsSummary.Range("Q2").value = allowedTypes.count
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P3").value = "Mapped switchgroup devices": wsSummary.Range("Q3").value = devices.count - overflowDeviceCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P4").value = "RCP panels": wsSummary.Range("Q4").value = panelSeen.count
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P5").value = "Area network switches": wsSummary.Range("Q5").value = totalAreaSwitchCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P6").value = "Additional area switches": wsSummary.Range("Q6").value = extraAreaSwitchCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P7").value = "Additional panel switches approved": wsSummary.Range("Q7").value = extraPanelSwitchCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P8").value = "Panel switch expansions declined": wsSummary.Range("Q8").value = panelExpansionDeclinedCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P9").value = "X01 RACK/RCK routes": wsSummary.Range("Q9").value = rackCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P10").value = "Missing area main-panel uplinks": wsSummary.Range("Q10").value = missingUplinkCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P11").value = "Overflow routes": wsSummary.Range("Q11").value = overflowRouteCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P12").value = "Overflow devices": wsSummary.Range("Q12").value = overflowDeviceCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P13").value = "Duplicate PD6 rows removed": wsSummary.Range("Q13").value = duplicateCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P14").value = "TYPE rows not enabled by DATA": wsSummary.Range("Q14").value = skippedTypeCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P15").value = "Eligible rows excluded": wsSummary.Range("Q15").value = excludedCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P16").value = "Maximum route length (m)": wsSummary.Range("Q16").value = AN_MAX_ROUTE_METERS
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Range("P17").value = "Ports per network switch": wsSummary.Range("Q17").value = AN_PORTS_PER_SWITCH
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    AN_StyleReportSheet wsSummary, "P:Q"

    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.StatusBar = False
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Calculation = oldCalc
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.DisplayAlerts = True
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.EnableEvents = True
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.ScreenUpdating = True

    ' Display the workflow result, warning, or error details to the user.
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    MsgBox "Automatic RCP network map prepared from PD6_IMPORT." & vbCrLf & vbCrLf & _
           "DATA type/alias keys loaded: " & allowedTypes.count & vbCrLf & _
           "RCP panels: " & panelSeen.count & vbCrLf & _
           "Area network switches: " & totalAreaSwitchCount & _
               " (additional: " & extraAreaSwitchCount & ")" & vbCrLf & _
           "Additional panel switches approved: " & extraPanelSwitchCount & vbCrLf & _
           "Panel switch expansions declined: " & panelExpansionDeclinedCount & vbCrLf & _
           "Mapped switchgroup devices: " & (devices.count - overflowDeviceCount) & vbCrLf & _
           "Overflow devices: " & overflowDeviceCount & vbCrLf & vbCrLf & _
           "AREA switches automatically restart X01-X08 after every eight panels." & vbCrLf & _
           "Panel switches restart X01-X08 only after user approval. X09 stays reserved for uplink." & vbCrLf & _
           "RIO and IO/S are isolated together first inside each Panel + SwitchGroup." & vbCrLf & _
           "When ports are insufficient, the user chooses controlled mixing or additional NWS capacity." & vbCrLf & _
           "The 80 m route limit remains active for isolated and mixed routes." & vbCrLf & _
           "Next: run Step 12, Step 12A, and Step 13.", _
           vbInformation, "Step 11B - DATA-Driven Auto Network Ready"
    ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
    Exit Sub

' Begin the named error-handling or cleanup section.
' [R7 LINE] Defines a named execution label used by normal cleanup or error handling.
ErrHandler:
    ' [R7 LINE] Calculates or updates savedErrNumber using the expression in this statement.
    savedErrNumber = Err.Number
    ' [R7 LINE] Calculates or updates savedErrDescription using the expression in this statement.
    savedErrDescription = Err.description
    ' [R7 LINE] Calculates or updates savedErrSource using the expression in this statement.
    savedErrSource = Err.source

    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.StatusBar = False
    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If oldCalcCaptured Then Application.Calculation = oldCalc
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.DisplayAlerts = True
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.EnableEvents = True
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.ScreenUpdating = True
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(savedErrDescription) = 0 Then savedErrDescription = "Unknown VBA error."
    ' Display the workflow result, warning, or error details to the user.
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    MsgBox "Automatic network preparation failed." & vbCrLf & vbCrLf & _
           "Error " & CStr(savedErrNumber) & ": " & savedErrDescription & _
           IIf(Len(savedErrSource) > 0, vbCrLf & "Source: " & savedErrSource, ""), _
           vbCritical, "Step 11B Error"
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

'Compatibility macro retained for the existing Step 14 button.
' [R7 LINE] Starts Sub Build_All_RCP_Clean_Then_Export; the following statements perform or calculate this named workflow.
Public Sub Build_All_RCP_Clean_Then_Export()
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo EH
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Run "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!Create_All_RCP_Clean_Sheets"
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Run "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!Refresh_All_RCP_Clean_Sheet_Formulas"
    ' [R7 LINE] Changes or restores an Excel application setting, refresh action, calculation, or navigation state.
    Application.Run "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!Export_RCP_Clean_Sheets_To_New_Workbook"
    ' [R7 LINE] Leaves the current Sub immediately after the required work is complete.
    Exit Sub
' Begin the named error-handling or cleanup section.
' [R7 LINE] Defines a named execution label used by normal cleanup or error handling.
EH:
    ' Display the workflow result, warning, or error details to the user.
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    MsgBox "Legacy RCP clean/export failed." & vbCrLf & Err.description, vbCritical
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub AN_InitializeTopologySheet; the following statements perform or calculate this named workflow.
'Compatibility entry point used by the UI button. The current auto-network routine
'already enforces RIO + IO/S grouping inside each Panel + SwitchGroup.
Public Sub Enforce_RIO_IOS_Network_Grouping()
    Prepare_Auto_Network_From_PD6
End Sub

Private Sub AN_InitializeTopologySheet(ByVal ws As Worksheet, ByVal panel As String, _
    ByVal areaNumber As String, ByVal panelSwitchNumber As Long)

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim c As Long, switchName As String
    ' [R7 LINE] Calculates or updates switchName using the expression in this statement.
    switchName = AN_PanelSwitchName(panel, panelSwitchNumber)

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For c = AN_FIRST_DEVICE_PORT To AN_UPLINK_PORT
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(1, c).value = "X" & Format$(c, "00")
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(2, c).value = AN_MARKER & "|AREA=" & areaNumber & "|PANEL=" & panel & _
            "|PANEL_SWITCH=" & panelSwitchNumber & "|PANEL_SWITCH_NAME=" & switchName & _
            "|PORT=X" & Format$(c, "00") & "|STATUS=AVAILABLE"
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next c
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub AN_WriteAreaUplink; the following statements perform or calculate this named workflow.
Private Sub AN_WriteAreaUplink(ByVal wsTopology As Worksheet, ByVal wsSummary As Worksheet, _
    ByRef summaryRow As Long, ByVal areaMains As Object, ByVal areaAssignments As Object, _
    ByVal panel As String, ByVal areaNumber As String, ByRef routeCount As Long, _
    ByRef missingUplinkCount As Long)

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim mainRec As Variant, found As Boolean, metadata As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim assignment As Variant, upstreamSwitch As String, upstreamPort As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim assignmentNote As String, panelSwitchName As String, notesText As String

    ' [R7 LINE] Calculates or updates panelSwitchName using the expression in this statement.
    panelSwitchName = AN_PanelSwitchName(panel, 1)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If areaAssignments.Exists(UCase$(Trim$(panel))) Then
        ' [R7 LINE] Calculates or updates assignment using the expression in this statement.
        assignment = areaAssignments(UCase$(Trim$(panel)))
        ' [R7 LINE] Calculates or updates upstreamSwitch using the expression in this statement.
        upstreamSwitch = CStr(assignment(3))
        ' [R7 LINE] Calculates or updates upstreamPort using the expression in this statement.
        upstreamPort = "X" & Format$(CLng(assignment(2)), "00")
        ' [R7 LINE] Calculates or updates assignmentNote using the expression in this statement.
        assignmentNote = CStr(assignment(4))
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Calculates or updates upstreamSwitch using the expression in this statement.
        upstreamSwitch = "AREA" & areaNumber & "-NSW01"
        ' [R7 LINE] Calculates or updates upstreamPort using the expression in this statement.
        upstreamPort = "UNASSIGNED"
        ' [R7 LINE] Calculates or updates assignmentNote using the expression in this statement.
        assignmentNote = "No AREA switch assignment was available for this panel."
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates mainRec using the expression in this statement.
    mainRec = AN_GetAreaMainRecord(areaMains, areaNumber, found)

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If found Then
        ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
        notesText = "Area uplink from " & upstreamSwitch & " " & upstreamPort & "."
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(assignmentNote) > 0 Then notesText = notesText & " " & assignmentNote
        ' [R7 LINE] Calculates or updates metadata using the expression in this statement.
        metadata = AN_MARKER & "|AREA=" & areaNumber & "|PANEL=" & panel & _
                   "|PANEL_SWITCH=1|PANEL_SWITCH_NAME=" & panelSwitchName & _
                   "|PORT=X09|ROUTE=AREA UPLINK|MAIN_TYPE=" & CStr(mainRec(4)) & _
                   "|MAIN_SEQ=" & CStr(mainRec(3)) & "|UPSTREAM_SWITCH=" & upstreamSwitch & _
                   "|UPSTREAM_PORT=" & upstreamPort & "|NOTE=" & AN_MetadataSafe(notesText)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsTopology.Cells(2, AN_UPLINK_PORT).value = metadata
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsTopology.Cells(3, AN_UPLINK_PORT).value = CStr(mainRec(6))

        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 1).value = panel
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 2).value = areaNumber
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 3).value = CStr(mainRec(2))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 4).value = "X09"
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 5).value = "AREA UPLINK"
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 6).value = 1
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 7).value = 0
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 8).value = CStr(mainRec(3))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 9).value = CStr(mainRec(3))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 10).value = 0
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 11).value = "OK"
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 12).value = notesText
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 13).value = panelSwitchName
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 14).value = upstreamSwitch & " " & upstreamPort
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
        notesText = "No AE, PLC, IPC, or PNL area-main device enabled by DATA was found. " & _
            "Logical assignment: " & upstreamSwitch & " " & upstreamPort & "."
        ' [R7 LINE] Calculates or updates metadata using the expression in this statement.
        metadata = AN_MARKER & "|AREA=" & areaNumber & "|PANEL=" & panel & _
            "|PANEL_SWITCH=1|PANEL_SWITCH_NAME=" & panelSwitchName & _
            "|PORT=X09|ROUTE=AREA UPLINK|UPSTREAM_SWITCH=" & upstreamSwitch & _
            "|UPSTREAM_PORT=" & upstreamPort & "|STATUS=MISSING AREA MAIN PANEL|NOTE=" & _
            AN_MetadataSafe(notesText)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsTopology.Cells(2, AN_UPLINK_PORT).value = metadata

        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 1).value = panel
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 2).value = areaNumber
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 4).value = "X09"
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 5).value = "AREA UPLINK"
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 6).value = 0
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 11).value = "MISSING AREA MAIN PANEL"
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 12).value = notesText
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 13).value = panelSwitchName
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsSummary.Cells(summaryRow, 14).value = upstreamSwitch & " " & upstreamPort
        ' [R7 LINE] Calculates or updates missingUplinkCount using the expression in this statement.
        missingUplinkCount = missingUplinkCount + 1
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates summaryRow using the expression in this statement.
    summaryRow = summaryRow + 1
    ' [R7 LINE] Calculates or updates routeCount using the expression in this statement.
    routeCount = routeCount + 1
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub AN_WritePanelRack; the following statements perform or calculate this named workflow.
Private Sub AN_WritePanelRack(ByVal wsTopology As Worksheet, ByVal wsSummary As Worksheet, _
    ByRef summaryRow As Long, ByVal panelRacks As Object, ByVal panel As String, _
    ByVal areaNumber As String, ByRef routeCount As Long, ByRef rackCount As Long, _
    ByRef hasPanelRack As Boolean)

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim rackRec As Variant, key As String, metadata As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panelSwitchName As String, notesText As String
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = UCase$(Trim$(panel))
    ' [R7 LINE] Calculates or updates hasPanelRack using the expression in this statement.
    hasPanelRack = False
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not panelRacks.Exists(key) Then Exit Sub

    ' [R7 LINE] Calculates or updates panelSwitchName using the expression in this statement.
    panelSwitchName = AN_PanelSwitchName(panel, 1)
    ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
    notesText = "RACK/RCK has X01 priority on the first panel network switch."
    ' [R7 LINE] Calculates or updates rackRec using the expression in this statement.
    rackRec = panelRacks(key)
    ' [R7 LINE] Calculates or updates metadata using the expression in this statement.
    metadata = AN_MARKER & "|AREA=" & areaNumber & "|PANEL=" & panel & _
               "|PANEL_SWITCH=1|PANEL_SWITCH_NAME=" & panelSwitchName & _
               "|PORT=X01|ROUTE=PANEL RACK|TYPE=RACK|SOURCE_TYPE=RACK/RCK|NOTE=" & _
               AN_MetadataSafe(notesText)
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsTopology.Cells(2, AN_FIRST_DEVICE_PORT).value = metadata
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsTopology.Cells(3, AN_FIRST_DEVICE_PORT).value = CStr(rackRec(5))

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 1).value = panel
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 2).value = areaNumber
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 3).value = CStr(rackRec(1))
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 4).value = "X01"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 5).value = "PANEL RACK"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 6).value = 1
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 7).value = 0
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 8).value = CStr(rackRec(2))
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 9).value = CStr(rackRec(2))
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 10).value = 0
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 11).value = "OK"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 12).value = notesText
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 13).value = panelSwitchName

    ' [R7 LINE] Calculates or updates summaryRow using the expression in this statement.
    summaryRow = summaryRow + 1
    ' [R7 LINE] Calculates or updates routeCount using the expression in this statement.
    routeCount = routeCount + 1
    ' [R7 LINE] Calculates or updates rackCount using the expression in this statement.
    rackCount = rackCount + 1
    ' [R7 LINE] Calculates or updates hasPanelRack using the expression in this statement.
    hasPanelRack = True
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub AN_WriteAdditionalPanelSwitchUplink; the following statements perform or calculate this named workflow.
Private Sub AN_WriteAdditionalPanelSwitchUplink(ByVal wsTopology As Worksheet, _
    ByVal wsSummary As Worksheet, ByRef summaryRow As Long, ByVal panel As String, _
    ByVal areaNumber As String, ByVal panelSwitchNumber As Long, ByRef routeCount As Long)

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim switchName As String, upstreamName As String, notesText As String, metadata As String
    ' [R7 LINE] Calculates or updates switchName using the expression in this statement.
    switchName = AN_PanelSwitchName(panel, panelSwitchNumber)
    ' [R7 LINE] Calculates or updates upstreamName using the expression in this statement.
    upstreamName = AN_PanelSwitchName(panel, panelSwitchNumber - 1)
    ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
    notesText = "Additional panel network switch added after user approval. X01-X08 restarted."

    ' [R7 LINE] Calculates or updates metadata using the expression in this statement.
    metadata = AN_MARKER & "|AREA=" & areaNumber & "|PANEL=" & panel & _
        "|PANEL_SWITCH=" & panelSwitchNumber & "|PANEL_SWITCH_NAME=" & switchName & _
        "|PORT=X09|ROUTE=PANEL SWITCH UPLINK|UPSTREAM_SWITCH=" & upstreamName & _
        "|UPSTREAM_PORT=CASCADE|NOTE=" & AN_MetadataSafe(notesText)
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsTopology.Cells(2, AN_UPLINK_PORT).value = metadata
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsTopology.Cells(3, AN_UPLINK_PORT).value = Replace(panel, "-", "_") & _
        "_NSW" & Format$(panelSwitchNumber, "00") & "_UPLINK [NETWORK SWITCH UPLINK]"

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 1).value = panel
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 2).value = areaNumber
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 4).value = "X09"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 5).value = "PANEL SWITCH UPLINK"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 6).value = 1
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 7).value = 0
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 11).value = "ADDED BY USER APPROVAL"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 12).value = notesText
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 13).value = switchName
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 14).value = upstreamName & " CASCADE"
    ' [R7 LINE] Calculates or updates summaryRow using the expression in this statement.
    summaryRow = summaryRow + 1
    ' [R7 LINE] Calculates or updates routeCount using the expression in this statement.
    routeCount = routeCount + 1
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_BuildAreaPanelAssignments; the following statements perform or calculate this named workflow.
Private Function AN_BuildAreaPanelAssignments(ByVal panelAreas As Object, ByVal areaMains As Object, _
    ByVal ws As Worksheet, ByRef extraSwitchCount As Long, ByRef totalSwitchCount As Long) As Object

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim result As Object, keys As Variant, rows() As Variant, assignment As Variant
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, n As Long, currentArea As String, areaIndex As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim switchNo As Long, portNo As Long, lastSwitchNo As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panel As String, areaNumber As String, switchName As String, notesText As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim mainRec As Variant, found As Boolean, mainType As String, mainSeq As String

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to result.
    Set result = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Calculates or updates result.CompareMode using the expression in this statement.
    result.CompareMode = vbTextCompare
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells.Clear
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Range("A1:H1").value = Array("AREA_Number", "Main Panel Type", "Main Panel SIS", _
        "Area Network Switch", "Outfeed Port", "Local Panel", "Local Panel Uplink", "Notes")

    ' [R7 LINE] Calculates or updates n using the expression in this statement.
    n = panelAreas.count
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If n = 0 Then
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_BuildAreaPanelAssignments.
        Set AN_BuildAreaPanelAssignments = result
        ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
        Exit Function
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates keys using the expression in this statement.
    keys = panelAreas.keys
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ReDim rows(1 To n, 1 To 3)
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 0 To UBound(keys)
        ' [R7 LINE] Calculates or updates panel using the expression in this statement.
        panel = CStr(keys(i))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        rows(i + 1, 1) = CStr(panelAreas(panel))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        rows(i + 1, 2) = panel
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        rows(i + 1, 3) = PD6Net_FirstNumber(panel)
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    AN_SortAreaPanels rows, n

    ' [R7 LINE] Calculates or updates currentArea using the expression in this statement.
    currentArea = vbNullString
    ' [R7 LINE] Calculates or updates areaIndex using the expression in this statement.
    areaIndex = 0
    ' [R7 LINE] Calculates or updates lastSwitchNo using the expression in this statement.
    lastSwitchNo = 0

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 1 To n
        ' [R7 LINE] Calculates or updates areaNumber using the expression in this statement.
        areaNumber = CStr(rows(i, 1))
        ' [R7 LINE] Calculates or updates panel using the expression in this statement.
        panel = CStr(rows(i, 2))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If StrComp(areaNumber, currentArea, vbTextCompare) <> 0 Then
            ' [R7 LINE] Calculates or updates currentArea using the expression in this statement.
            currentArea = areaNumber
            ' [R7 LINE] Calculates or updates areaIndex using the expression in this statement.
            areaIndex = 0
            ' [R7 LINE] Calculates or updates lastSwitchNo using the expression in this statement.
            lastSwitchNo = 0
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Calculates or updates areaIndex using the expression in this statement.
        areaIndex = areaIndex + 1
        ' [R7 LINE] Calculates or updates switchNo using the expression in this statement.
        switchNo = ((areaIndex - 1) \ AN_PORTS_PER_SWITCH) + 1
        ' [R7 LINE] Calculates or updates portNo using the expression in this statement.
        portNo = ((areaIndex - 1) Mod AN_PORTS_PER_SWITCH) + 1

        ' [R7 LINE] Calculates or updates mainRec using the expression in this statement.
        mainRec = AN_GetAreaMainRecord(areaMains, areaNumber, found)
        ' [R7 LINE] Calculates or updates mainType using the expression in this statement.
        mainType = vbNullString
        ' [R7 LINE] Calculates or updates mainSeq using the expression in this statement.
        mainSeq = vbNullString
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If found Then
            ' [R7 LINE] Calculates or updates mainType using the expression in this statement.
            mainType = CStr(mainRec(4))
            ' [R7 LINE] Calculates or updates mainSeq using the expression in this statement.
            mainSeq = CStr(mainRec(3))
        ' [R7 LINE] Ends the current conditional block.
        End If
        ' [R7 LINE] Calculates or updates switchName using the expression in this statement.
        switchName = AN_AreaSwitchName(areaNumber, mainType, switchNo)

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If switchNo > lastSwitchNo Then
            ' [R7 LINE] Calculates or updates totalSwitchCount using the expression in this statement.
            totalSwitchCount = totalSwitchCount + 1
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If switchNo > 1 Then extraSwitchCount = extraSwitchCount + 1
            ' [R7 LINE] Calculates or updates lastSwitchNo using the expression in this statement.
            lastSwitchNo = switchNo
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If switchNo > 1 Then
            ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
            notesText = "Additional area network switch automatically added because this AREA_Number has more than 8 local panels."
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
            notesText = "Primary area network switch."
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Calculates or updates assignment using the expression in this statement.
        assignment = Array(areaNumber, switchNo, portNo, switchName, notesText, mainType, mainSeq)
        ' [R7 LINE] Calculates or updates result(UCase$(Trim$(panel))) using the expression in this statement.
        result(UCase$(Trim$(panel))) = assignment

        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 1).value = areaNumber
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 2).value = mainType
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 3).value = mainSeq
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 4).value = switchName
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 5).value = "X" & Format$(portNo, "00")
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 6).value = panel
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 7).value = "X09"
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Cells(i + 1, 8).value = notesText
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_BuildAreaPanelAssignments.
    Set AN_BuildAreaPanelAssignments = result
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub AN_SortAreaPanels; the following statements perform or calculate this named workflow.
Private Sub AN_SortAreaPanels(ByRef rows As Variant, ByVal n As Long)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, j As Long, c As Long, temp(1 To 3) As Variant
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 2 To n
        ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
        For c = 1 To 3: temp(c) = rows(i, c): Next c
        ' [R7 LINE] Calculates or updates j using the expression in this statement.
        j = i - 1
        ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
        Do While j >= 1 And AN_CompareAreaPanelRow(rows, j, temp) > 0
            ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
            For c = 1 To 3: rows(j + 1, c) = rows(j, c): Next c
            ' [R7 LINE] Calculates or updates j using the expression in this statement.
            j = j - 1
        ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
        Loop
        ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
        For c = 1 To 3: rows(j + 1, c) = temp(c): Next c
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_CompareAreaPanelRow; the following statements perform or calculate this named workflow.
Private Function AN_CompareAreaPanelRow(ByRef rows As Variant, ByVal rowNum As Long, _
    ByRef pivot() As Variant) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim cmp As Long
    ' [R7 LINE] Calculates or updates cmp using the expression in this statement.
    cmp = AN_CompareNatural(CStr(rows(rowNum, 1)), CStr(pivot(1)))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = AN_CompareNatural(CStr(rows(rowNum, 2)), CStr(pivot(2)))
    ' [R7 LINE] Calculates or updates AN_CompareAreaPanelRow using the expression in this statement.
    AN_CompareAreaPanelRow = cmp
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_AreaSwitchName; the following statements perform or calculate this named workflow.
Private Function AN_AreaSwitchName(ByVal areaNumber As String, ByVal mainType As String, _
    ByVal switchNumber As Long) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim prefix As String
    ' [R7 LINE] Calculates or updates prefix using the expression in this statement.
    prefix = UCase$(Trim$(mainType))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(prefix) = 0 Then prefix = "AREA"
    ' [R7 LINE] Calculates or updates AN_AreaSwitchName using the expression in this statement.
    AN_AreaSwitchName = prefix & Trim$(areaNumber) & "-NSW" & Format$(switchNumber, "00")
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_PanelSwitchName; the following statements perform or calculate this named workflow.
Private Function AN_PanelSwitchName(ByVal panel As String, ByVal switchNumber As Long) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim txt As String
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = UCase$(Trim$(panel))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(txt) = 0 Then txt = "RCP"
    ' [R7 LINE] Calculates or updates AN_PanelSwitchName using the expression in this statement.
    AN_PanelSwitchName = txt & "-NSW" & Format$(switchNumber, "00")
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_AskAddPanelNetworkSwitch; the following statements perform or calculate this named workflow.
Private Function AN_AskAddPanelNetworkSwitch(ByVal panel As String, ByVal switchNumber As Long) As VbMsgBoxResult
    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    AN_AskAddPanelNetworkSwitch = MsgBox( _
        "Panel " & panel & " requires more than eight local network routes." & vbCrLf & vbCrLf & _
        "Add " & AN_PanelSwitchName(panel, switchNumber) & _
        " and restart device-port assignment at X01-X08?" & vbCrLf & vbCrLf & _
        "Yes = add the switch and continue" & vbCrLf & _
        "No = do not add it; remaining routes are reported as overflow" & vbCrLf & _
        "Cancel = stop automatic network generation", _
        vbYesNoCancel + vbQuestion + vbDefaultButton1, _
        "Additional Panel Network Switch Required")
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_MetadataSafe; the following statements perform or calculate this named workflow.
Private Function AN_MetadataSafe(ByVal txt As String) As String
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, "|", "/")
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, vbCr, " ")
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, vbLf, " ")
    ' [R7 LINE] Calculates or updates AN_MetadataSafe using the expression in this statement.
    AN_MetadataSafe = Trim$(txt)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_GetAreaMainRecord; the following statements perform or calculate this named workflow.
Private Function AN_GetAreaMainRecord(ByVal areaMains As Object, ByVal areaNumber As String, _
    ByRef found As Boolean) As Variant

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim item As Variant, best As Variant
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim bestSeq As Double, itemSeq As Double, bestPriority As Long, itemPriority As Long

    ' [R7 LINE] Calculates or updates bestSeq using the expression in this statement.
    bestSeq = 1E+99
    ' [R7 LINE] Calculates or updates bestPriority using the expression in this statement.
    bestPriority = 999
    ' [R7 LINE] Calculates or updates found using the expression in this statement.
    found = False

    ' Loop through every object or value in the referenced collection.
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For Each item In areaMains.items
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If StrComp(CStr(item(0)), areaNumber, vbTextCompare) = 0 Then
            ' [R7 LINE] Calculates or updates itemSeq using the expression in this statement.
            itemSeq = CDbl(item(5))
            ' [R7 LINE] Calculates or updates itemPriority using the expression in this statement.
            itemPriority = AN_MainTypePriority(CStr(item(4)))
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Not found Or itemSeq < bestSeq Or _
               (itemSeq = bestSeq And itemPriority < bestPriority) Then
                ' [R7 LINE] Calculates or updates best using the expression in this statement.
                best = item
                ' [R7 LINE] Calculates or updates bestSeq using the expression in this statement.
                bestSeq = itemSeq
                ' [R7 LINE] Calculates or updates bestPriority using the expression in this statement.
                bestPriority = itemPriority
                ' [R7 LINE] Calculates or updates found using the expression in this statement.
                found = True
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next item

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If found Then AN_GetAreaMainRecord = best
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub AN_FinalizeSegment; the following statements perform or calculate this named workflow.
Private Sub AN_FinalizeSegment(ByVal wsTopology As Worksheet, ByVal wsSummary As Worksheet, _
    ByRef summaryRow As Long, ByVal portNumber As Long, ByVal panel As String, _
    ByVal areaNumber As String, ByVal swg As String, ByVal deviceCount As Long, _
    ByVal lengthMeters As Double, ByVal firstSequence As String, ByVal lastSequence As String, _
    ByVal zeroLengthCount As Long, ByVal routeFamily As String, _
    ByVal panelSwitchNumber As Long, _
    ByVal expansionDeclined As Boolean, ByRef routeCount As Long, ByRef overflowRouteCount As Long)

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim statusText As String, metadata As String, portText As String, notesText As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panelSwitchName As String, routeTypeText As String
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If deviceCount <= 0 Then Exit Sub
    ' [R7 LINE] Chooses a processing branch based on the current value.
    Select Case UCase$(Trim$(routeFamily))
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "RIO_IOS": routeTypeText = "RIO/IO-S ISOLATED"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "MIXED": routeTypeText = "RIO/IO-S MIXED"
        ' [R7 LINE] Handles values not matched by the preceding Case branches.
        Case Else: routeTypeText = "SWITCHGROUP"
    ' [R7 LINE] Ends the current Select Case block.
    End Select
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(areaNumber) = 0 Then areaNumber = "0"

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If portNumber > AN_LAST_DEVICE_PORT Or panelSwitchNumber <= 0 Then
        ' [R7 LINE] Calculates or updates portText using the expression in this statement.
        portText = "NO PORT"
        ' [R7 LINE] Calculates or updates statusText using the expression in this statement.
        statusText = "PANEL NETWORK SWITCH CAPACITY EXCEEDED"
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If expansionDeclined Then
            ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
            notesText = "Another panel network switch was required but the user selected No."
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
            notesText = "X01-X08 are full and no additional panel network switch was available."
        ' [R7 LINE] Ends the current conditional block.
        End If
        ' [R7 LINE] Calculates or updates panelSwitchName using the expression in this statement.
        panelSwitchName = "NOT ADDED"
        ' [R7 LINE] Calculates or updates overflowRouteCount using the expression in this statement.
        overflowRouteCount = overflowRouteCount + 1
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Calculates or updates portText using the expression in this statement.
        portText = "X" & Format$(portNumber, "00")
        ' [R7 LINE] Calculates or updates panelSwitchName using the expression in this statement.
        panelSwitchName = AN_PanelSwitchName(panel, panelSwitchNumber)
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If panelSwitchNumber > 1 Then
            ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
            notesText = "Additional panel network switch approved by user; port sequence restarted at X01."
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
            notesText = "Primary panel network switch."
        ' [R7 LINE] Ends the current conditional block.
        End If
        ' [R7 LINE] Calculates or updates metadata using the expression in this statement.
        metadata = AN_MARKER & "|AREA=" & areaNumber & "|PANEL=" & panel & _
                   "|PANEL_SWITCH=" & panelSwitchNumber & "|PANEL_SWITCH_NAME=" & panelSwitchName & _
                   "|SWG=" & swg & "|PORT=" & portText & _
                   "|ROUTE_FAMILY=" & UCase$(Trim$(routeFamily)) & "|LEN_M=" & Format$(lengthMeters, "0.000") & "|COUNT=" & deviceCount & _
                   "|NOTE=" & AN_MetadataSafe(notesText)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        wsTopology.Cells(2, portNumber).value = metadata

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If lengthMeters > AN_MAX_ROUTE_METERS + 0.000001 Then
            ' [R7 LINE] Calculates or updates statusText using the expression in this statement.
            statusText = "OVER 80m - CHECK SINGLE DEVICE OR SOURCE LENGTH"
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf zeroLengthCount > 0 Then
            ' [R7 LINE] Calculates or updates statusText using the expression in this statement.
            statusText = "CHECK MISSING/ZERO LENGTH"
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Calculates or updates statusText using the expression in this statement.
            statusText = "OK"
        ' [R7 LINE] Ends the current conditional block.
        End If
        ' [R7 LINE] Chooses a processing branch based on the current value.
        Select Case UCase$(Trim$(routeFamily))
            ' [R7 LINE] Handles this value or group of values in the current Select Case block.
            Case "RIO_IOS"
                ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
                notesText = notesText & " Preferred isolated RIO/IO-S route; 80 m split remains active."
            ' [R7 LINE] Handles this value or group of values in the current Select Case block.
            Case "MIXED"
                ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
                notesText = notesText & " Mixed by user approval inside the same Panel + SwitchGroup; 80 m split remains active."
            ' [R7 LINE] Handles values not matched by the preceding Case branches.
            Case Else
                ' [R7 LINE] Calculates or updates notesText using the expression in this statement.
                notesText = notesText & " Standard SwitchGroup route; 80 m split remains active."
        ' [R7 LINE] Ends the current Select Case block.
        End Select
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 1).value = panel
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 2).value = areaNumber
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 3).value = swg
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 4).value = portText
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 5).value = routeTypeText
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 6).value = deviceCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 7).value = Round(lengthMeters, 3)
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 8).value = firstSequence
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 9).value = lastSequence
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 10).value = zeroLengthCount
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 11).value = statusText
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 12).value = notesText
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    wsSummary.Cells(summaryRow, 13).value = panelSwitchName
    ' [R7 LINE] Calculates or updates summaryRow using the expression in this statement.
    summaryRow = summaryRow + 1
    ' [R7 LINE] Calculates or updates routeCount using the expression in this statement.
    routeCount = routeCount + 1
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub AN_WriteExcluded; the following statements perform or calculate this named workflow.
Private Sub AN_WriteExcluded(ByVal ws As Worksheet, ByRef outRow As Long, ByVal sourceRow As Long, _
    ByVal panel As String, ByVal areaNumber As String, ByVal swg As String, ByVal sisSeq As String, _
    ByVal deviceType As String, ByVal moduleLength As String, ByVal reason As String)

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 1).value = sourceRow
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 2).value = panel
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 3).value = areaNumber
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 4).value = swg
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 5).value = sisSeq
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 6).value = deviceType
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 7).value = moduleLength
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(outRow, 8).value = reason
    ' [R7 LINE] Calculates or updates outRow using the expression in this statement.
    outRow = outRow + 1
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_AreaMainType; the following statements perform or calculate this named workflow.
Private Function AN_AreaMainType(ByVal rawType As String, ByVal sisSeq As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim t As String, seqType As String
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = AN_NormalizeType(rawType)

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If t = "AE" Or t = "PLC" Or t = "IPC" Then
        ' [R7 LINE] Calculates or updates AN_AreaMainType using the expression in this statement.
        AN_AreaMainType = t
        ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
        Exit Function
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If t = "PNL" Or t = "PANEL" Then
        ' [R7 LINE] Calculates or updates seqType using the expression in this statement.
        seqType = AN_MainTypeFromSequence(sisSeq)
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(seqType) > 0 Then AN_AreaMainType = seqType
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_AreaMainTypeFromData; the following statements perform or calculate this named workflow.
Private Function AN_AreaMainTypeFromData(ByVal rawType As String, ByVal sisSeq As String, _
    ByVal allowedTypes As Object) As String
    'Classification may recognize AE/PLC/IPC from SIS_sequence, but eligibility must
    'still come from the actual TYPE (or its direct spelling alias) listed in DATA.
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim inferred As String, rawKey As String
    ' [R7 LINE] Calculates or updates inferred using the expression in this statement.
    inferred = AN_AreaMainType(rawType, sisSeq)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(inferred) = 0 Then Exit Function

    ' [R7 LINE] Calculates or updates rawKey using the expression in this statement.
    rawKey = AN_NormalizeTypeKey(rawType)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If rawKey = "PNL" Or rawKey = "PANEL" Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If AN_DataTypeEnabled(allowedTypes, rawType, "PNL", "PANEL") Then
            ' [R7 LINE] Calculates or updates AN_AreaMainTypeFromData using the expression in this statement.
            AN_AreaMainTypeFromData = inferred
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
    ElseIf AN_DataTypeEnabled(allowedTypes, rawType, inferred) Then
        ' [R7 LINE] Calculates or updates AN_AreaMainTypeFromData using the expression in this statement.
        AN_AreaMainTypeFromData = inferred
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_MainTypeFromSequence; the following statements perform or calculate this named workflow.
Private Function AN_MainTypeFromSequence(ByVal sisSeq As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim txt As String, parts() As String, i As Long, token As String, suffixText As String
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = UCase$(Trim$(sisSeq))
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, "_", "-")
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, "/", "-")
    ' [R7 LINE] Calculates or updates parts using the expression in this statement.
    parts = Split(txt, "-")

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = LBound(parts) To UBound(parts)
        ' [R7 LINE] Calculates or updates token using the expression in this statement.
        token = Trim$(parts(i))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Left$(token, 2) = "AE" Then
            ' [R7 LINE] Calculates or updates suffixText using the expression in this statement.
            suffixText = mid$(token, 3)
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Len(suffixText) = 0 Or IsNumeric(suffixText) Then
                ' [R7 LINE] Calculates or updates AN_MainTypeFromSequence using the expression in this statement.
                AN_MainTypeFromSequence = "AE"
                ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
                Exit Function
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf Left$(token, 3) = "PLC" Then
            ' [R7 LINE] Calculates or updates suffixText using the expression in this statement.
            suffixText = mid$(token, 4)
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Len(suffixText) = 0 Or IsNumeric(suffixText) Then
                ' [R7 LINE] Calculates or updates AN_MainTypeFromSequence using the expression in this statement.
                AN_MainTypeFromSequence = "PLC"
                ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
                Exit Function
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf Left$(token, 3) = "IPC" Then
            ' [R7 LINE] Calculates or updates suffixText using the expression in this statement.
            suffixText = mid$(token, 4)
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Len(suffixText) = 0 Or IsNumeric(suffixText) Then
                ' [R7 LINE] Calculates or updates AN_MainTypeFromSequence using the expression in this statement.
                AN_MainTypeFromSequence = "IPC"
                ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
                Exit Function
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_MainAreaNumber; the following statements perform or calculate this named workflow.
Private Function AN_MainAreaNumber(ByVal mainType As String, ByVal sisSeq As String, _
    ByVal fallbackArea As String) As String

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim txt As String, parts() As String, i As Long, token As String, suffixText As String
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = UCase$(Trim$(sisSeq))
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, "_", "-")
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, "/", "-")
    ' [R7 LINE] Calculates or updates parts using the expression in this statement.
    parts = Split(txt, "-")

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = LBound(parts) To UBound(parts)
        ' [R7 LINE] Calculates or updates token using the expression in this statement.
        token = Trim$(parts(i))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If mainType = "AE" And Left$(token, 2) = "AE" Then
            ' [R7 LINE] Calculates or updates suffixText using the expression in this statement.
            suffixText = mid$(token, 3)
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf mainType = "PLC" And Left$(token, 3) = "PLC" Then
            ' [R7 LINE] Calculates or updates suffixText using the expression in this statement.
            suffixText = mid$(token, 4)
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf mainType = "IPC" And Left$(token, 3) = "IPC" Then
            ' [R7 LINE] Calculates or updates suffixText using the expression in this statement.
            suffixText = mid$(token, 4)
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Calculates or updates suffixText using the expression in this statement.
            suffixText = vbNullString
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(suffixText) > 0 And IsNumeric(suffixText) Then
            ' [R7 LINE] Calculates or updates AN_MainAreaNumber using the expression in this statement.
            AN_MainAreaNumber = suffixText
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i

    ' [R7 LINE] Calculates or updates AN_MainAreaNumber using the expression in this statement.
    AN_MainAreaNumber = Trim$(fallbackArea)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_CanonicalRouteTypeFromData; the following statements perform or calculate this named workflow.
Private Function AN_CanonicalRouteTypeFromData(ByVal rawType As String, ByVal sisSeq As String, _
    ByVal controlCard As String, ByVal systemType As String, ByVal allowedTypes As Object) As String

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim recordKey As String, canonicalDataType As String

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(AN_AreaMainTypeFromData(rawType, sisSeq, allowedTypes)) > 0 Then Exit Function

    ' [R7 LINE] Calculates or updates recordKey using the expression in this statement.
    recordKey = AN_FindDataRecordKey(rawType, sisSeq, controlCard, systemType, allowedTypes)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(recordKey) = 0 Then Exit Function

    ' [R7 LINE] Calculates or updates canonicalDataType using the expression in this statement.
    canonicalDataType = AN_DataRecordField(CStr(allowedTypes(recordKey)), 0)
    ' [R7 LINE] Calculates or updates AN_CanonicalRouteTypeFromData using the expression in this statement.
    AN_CanonicalRouteTypeFromData = AN_InternalRouteType(canonicalDataType)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_FindDataRecordKey; the following statements perform or calculate this named workflow.
Private Function AN_FindDataRecordKey(ByVal rawType As String, ByVal sisSeq As String, _
    ByVal controlCard As String, ByVal systemType As String, ByVal allowedTypes As Object) As String

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As String, hint As String, inferredMain As String

    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = AN_NormalizeTypeKey(rawType)

    'PNL rows are classified by SIS_sequence before the repeated PNL DATA key is used.
    ' [R7 LINE] Calculates or updates inferredMain using the expression in this statement.
    inferredMain = AN_AreaMainType(rawType, sisSeq)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(inferredMain) > 0 Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If allowedTypes.Exists(AN_NormalizeTypeKey(inferredMain)) Then
            ' [R7 LINE] Calculates or updates AN_FindDataRecordKey using the expression in this statement.
            AN_FindDataRecordKey = AN_NormalizeTypeKey(inferredMain)
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If (key = "PNL" Or key = "PANEL") And InStr(1, UCase$(sisSeq), "RIO", vbTextCompare) > 0 Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If allowedTypes.Exists("RIO") Then
            ' [R7 LINE] Calculates or updates AN_FindDataRecordKey using the expression in this statement.
            AN_FindDataRecordKey = "RIO"
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(key) > 0 Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If allowedTypes.Exists(key) Then
            ' [R7 LINE] Calculates or updates AN_FindDataRecordKey using the expression in this statement.
            AN_FindDataRecordKey = key
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If

    'Numbered IO variants such as IO/D-1 and IO/S-2 resolve to an existing DATA row.
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Left$(key, 4) = "IO_D" Or Left$(key, 3) = "IOD" Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If allowedTypes.Exists("IO_D") Then
            ' [R7 LINE] Calculates or updates AN_FindDataRecordKey using the expression in this statement.
            AN_FindDataRecordKey = "IO_D"
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
    ElseIf Left$(key, 4) = "IO_S" Or Left$(key, 3) = "IOS" Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If allowedTypes.Exists("IO_S") Then
            ' [R7 LINE] Calculates or updates AN_FindDataRecordKey using the expression in this statement.
            AN_FindDataRecordKey = "IO_S"
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If

    'Generic VFD rows are resolved to a DATA row using the existing drive hints.
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Left$(key, 3) = "VFD" Then
        ' [R7 LINE] Calculates or updates hint using the expression in this statement.
        hint = UCase$(controlCard & " " & systemType)
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If InStr(hint, "MOVIMOT") > 0 Or InStr(hint, "MFE") > 0 Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If allowedTypes.Exists("VFD_MC") Then
                ' [R7 LINE] Calculates or updates AN_FindDataRecordKey using the expression in this statement.
                AN_FindDataRecordKey = "VFD_MC"
                ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
                Exit Function
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf allowedTypes.Exists("VFD_MF") Then
            ' [R7 LINE] Calculates or updates AN_FindDataRecordKey using the expression in this statement.
            AN_FindDataRecordKey = "VFD_MF"
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If

    'SCNx family names use the SCN row only when that DATA row exists.
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Left$(key, 3) = "SCN" Or Left$(key, 7) = "SCANNER" Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If allowedTypes.Exists("SCN") Then AN_FindDataRecordKey = "SCN"
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_InternalRouteType; the following statements perform or calculate this named workflow.
Private Function AN_InternalRouteType(ByVal canonicalDataType As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As String
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = AN_NormalizeTypeKey(canonicalDataType)

    ' [R7 LINE] Chooses a processing branch based on the current value.
    Select Case key
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "RACK", "RCK", "RK"
            ' [R7 LINE] Calculates or updates AN_InternalRouteType using the expression in this statement.
            AN_InternalRouteType = "RACK"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "RIO"
            ' [R7 LINE] Calculates or updates AN_InternalRouteType using the expression in this statement.
            AN_InternalRouteType = "RIO"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "IO_S", "IOS"
            ' [R7 LINE] Calculates or updates AN_InternalRouteType using the expression in this statement.
            AN_InternalRouteType = "IO/S"
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "IO_D", "IOD"
            ' [R7 LINE] Calculates or updates AN_InternalRouteType using the expression in this statement.
            AN_InternalRouteType = "IO/D"
        ' [R7 LINE] Handles values not matched by the preceding Case branches.
        Case Else
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Left$(key, 3) = "VFD" Then
                ' [R7 LINE] Calculates or updates AN_InternalRouteType using the expression in this statement.
                AN_InternalRouteType = "VFD"
            ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
            ElseIf Left$(key, 3) = "SCN" Or Left$(key, 7) = "SCANNER" Then
                ' [R7 LINE] Calculates or updates AN_InternalRouteType using the expression in this statement.
                AN_InternalRouteType = "SCN"
            ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
            Else
                ' [R7 LINE] Calculates or updates AN_InternalRouteType using the expression in this statement.
                AN_InternalRouteType = canonicalDataType
            ' [R7 LINE] Ends the current conditional block.
            End If
    ' [R7 LINE] Ends the current Select Case block.
    End Select
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_RouteDescription; the following statements perform or calculate this named workflow.
Private Function AN_RouteDescription(ByVal canonicalType As String, ByVal rawType As String, _
    ByVal sisSeq As String, ByVal controlCard As String, ByVal systemType As String, _
    ByVal allowedTypes As Object) As String

    ' [R7 LINE] Calculates or updates AN_RouteDescription using the expression in this statement.
    AN_RouteDescription = AN_DataControlDeviceForRoute(allowedTypes, rawType, sisSeq, controlCard, systemType)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(AN_RouteDescription) = 0 Then
        ' [R7 LINE] Calculates or updates AN_RouteDescription using the expression in this statement.
        AN_RouteDescription = PD6Net_DeviceDescription(canonicalType, controlCard, systemType)
    ' [R7 LINE] Ends the current conditional block.
    End If
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(AN_RouteDescription) = 0 Then AN_RouteDescription = Trim$(rawType)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_DataControlDeviceForRoute; the following statements perform or calculate this named workflow.
Private Function AN_DataControlDeviceForRoute(ByVal allowedTypes As Object, ByVal rawType As String, _
    ByVal sisSeq As String, ByVal controlCard As String, ByVal systemType As String) As String

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim recordKey As String
    ' [R7 LINE] Calculates or updates recordKey using the expression in this statement.
    recordKey = AN_FindDataRecordKey(rawType, sisSeq, controlCard, systemType, allowedTypes)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(recordKey) = 0 Then Exit Function
    ' [R7 LINE] Calculates or updates AN_DataControlDeviceForRoute using the expression in this statement.
    AN_DataControlDeviceForRoute = AN_DataRecordField(CStr(allowedTypes(recordKey)), 1)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_DataControlDeviceForType; the following statements perform or calculate this named workflow.
Private Function AN_DataControlDeviceForType(ByVal allowedTypes As Object, ByVal typeOrAlias As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As String
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = AN_NormalizeTypeKey(typeOrAlias)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(key) = 0 Then Exit Function
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not allowedTypes.Exists(key) Then Exit Function
    ' [R7 LINE] Calculates or updates AN_DataControlDeviceForType using the expression in this statement.
    AN_DataControlDeviceForType = AN_DataRecordField(CStr(allowedTypes(key)), 1)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_DataRecordField; the following statements perform or calculate this named workflow.
Private Function AN_DataRecordField(ByVal recordText As String, ByVal fieldIndex As Long) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim parts() As String
    ' [R7 LINE] Calculates or updates parts using the expression in this statement.
    parts = Split(recordText, Chr$(30))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If fieldIndex >= LBound(parts) And fieldIndex <= UBound(parts) Then
        ' [R7 LINE] Calculates or updates AN_DataRecordField using the expression in this statement.
        AN_DataRecordField = parts(fieldIndex)
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_LoadNetworkDeviceTypes; the following statements perform or calculate this named workflow.
Private Function AN_LoadNetworkDeviceTypes(ByVal wb As Workbook) As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim result As Object, ws As Worksheet
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim lastRow As Long, lastCol As Long, r As Long, c As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim bestHeaderRow As Long, bestScore As Long, score As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim colControl As Long, colType As Long, bestControl As Long, bestType As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim colBlock As Long, colTermIn As Long, colTermOut As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim altColumns As Collection, bestAltColumns As Collection
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim headerKey As String, canonicalType As String, controlDevice As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim blockName As String, terminalIn As String, terminalOut As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim aliasText As String, recordText As String, altCol As Variant
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim controlCompact As String

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to result.
    Set result = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Calculates or updates result.CompareMode using the expression in this statement.
    result.CompareMode = vbTextCompare

    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
    Set ws = wb.Worksheets(AN_DATA_SHEET)
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If ws Is Nothing Then
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_LoadNetworkDeviceTypes.
        Set AN_LoadNetworkDeviceTypes = result
        ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
        Exit Function
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates LastRow using the expression in this statement.
    lastRow = AN_LastUsedRow(ws)
    ' [R7 LINE] Calculates or updates lastCol using the expression in this statement.
    lastCol = AN_LastUsedCol(ws)

    'Select the strongest table header row. This avoids older A:D helper layouts and
    'prefers the CONTROL DEVICE / DEVICE TYPE / ALTERNATE / BLOCK table shown by the user.
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For r = 1 To lastRow
        ' [R7 LINE] Calculates or updates colControl using the expression in this statement.
        colControl = 0: colType = 0: colBlock = 0: colTermIn = 0: colTermOut = 0
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to altColumns.
        Set altColumns = New Collection

        ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
        For c = 1 To lastCol
            ' [R7 LINE] Calculates or updates headerKey using the expression in this statement.
            headerKey = AN_CompactDataHeader(CStr(ws.Cells(r, c).value))
            ' [R7 LINE] Chooses a processing branch based on the current value.
            Select Case headerKey
                ' [R7 LINE] Handles this value or group of values in the current Select Case block.
                Case "CONTROLDEVICE", "CONTROLDEVICEDESCRIPTION", "DEVICE", "DEVICEDESCRIPTION"
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If colControl = 0 Then colControl = c
                ' [R7 LINE] Handles this value or group of values in the current Select Case block.
                Case "DEVICETYPE", "NETWORKDEVICETYPE", "ITEMTYPE", "TYPE"
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If colType = 0 Then colType = c
                ' [R7 LINE] Handles this value or group of values in the current Select Case block.
                Case "BLOCK", "BLOCKNAME", "AUTOCADBLOCK"
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If colBlock = 0 Then colBlock = c
                ' [R7 LINE] Handles this value or group of values in the current Select Case block.
                Case "TERMINALIN", "INTERMINAL", "INPUTTERMINAL"
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If colTermIn = 0 Then colTermIn = c
                ' [R7 LINE] Handles this value or group of values in the current Select Case block.
                Case "TERMINALOUT", "OUTTERMINAL", "OUTPUTTERMINAL"
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If colTermOut = 0 Then colTermOut = c
                ' [R7 LINE] Handles values not matched by the preceding Case branches.
                Case Else
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If Left$(headerKey, 9) = "ALTERNATE" Or Left$(headerKey, 5) = "ALIAS" Then
                        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                        altColumns.Add c
                    ' [R7 LINE] Ends the current conditional block.
                    End If
            ' [R7 LINE] Ends the current Select Case block.
            End Select
        ' [R7 LINE] Advances to the next item in the current For loop.
        Next c

        ' [R7 LINE] Calculates or updates score using the expression in this statement.
        score = 0
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If colControl > 0 Then score = score + 20
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If colType > 0 Then score = score + 30
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If altColumns.count > 0 Then score = score + 20 + altColumns.count
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If colBlock > 0 Then score = score + 10
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If colTermIn > 0 Then score = score + 10
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If colTermOut > 0 Then score = score + 10

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If score > bestScore Then
            ' [R7 LINE] Calculates or updates bestScore using the expression in this statement.
            bestScore = score
            ' [R7 LINE] Calculates or updates bestHeaderRow using the expression in this statement.
            bestHeaderRow = r
            ' [R7 LINE] Calculates or updates bestControl using the expression in this statement.
            bestControl = colControl
            ' [R7 LINE] Calculates or updates bestType using the expression in this statement.
            bestType = colType
            ' [R7 LINE] Calculates or updates colBlock using the expression in this statement.
            colBlock = colBlock
            ' [R7 LINE] Calculates or updates colTermIn using the expression in this statement.
            colTermIn = colTermIn
            ' [R7 LINE] Calculates or updates colTermOut using the expression in this statement.
            colTermOut = colTermOut
            ' [R7 LINE] Assigns the required workbook object or dictionary reference to bestAltColumns.
            Set bestAltColumns = altColumns
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next r

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If bestHeaderRow = 0 Or bestType = 0 Then
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_LoadNetworkDeviceTypes.
        Set AN_LoadNetworkDeviceTypes = result
        ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
        Exit Function
    ' [R7 LINE] Ends the current conditional block.
    End If

    'Re-read the selected row to retain the exact output columns.
    ' [R7 LINE] Calculates or updates colControl using the expression in this statement.
    colControl = 0: colType = 0: colBlock = 0: colTermIn = 0: colTermOut = 0
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to altColumns.
    Set altColumns = New Collection
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For c = 1 To lastCol
        ' [R7 LINE] Calculates or updates headerKey using the expression in this statement.
        headerKey = AN_CompactDataHeader(CStr(ws.Cells(bestHeaderRow, c).value))
        ' [R7 LINE] Chooses a processing branch based on the current value.
        Select Case headerKey
            ' [R7 LINE] Handles this value or group of values in the current Select Case block.
            Case "CONTROLDEVICE", "CONTROLDEVICEDESCRIPTION", "DEVICE", "DEVICEDESCRIPTION"
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If colControl = 0 Then colControl = c
            ' [R7 LINE] Handles this value or group of values in the current Select Case block.
            Case "DEVICETYPE", "NETWORKDEVICETYPE", "ITEMTYPE", "TYPE"
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If colType = 0 Then colType = c
            ' [R7 LINE] Handles this value or group of values in the current Select Case block.
            Case "BLOCK", "BLOCKNAME", "AUTOCADBLOCK"
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If colBlock = 0 Then colBlock = c
            ' [R7 LINE] Handles this value or group of values in the current Select Case block.
            Case "TERMINALIN", "INTERMINAL", "INPUTTERMINAL"
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If colTermIn = 0 Then colTermIn = c
            ' [R7 LINE] Handles this value or group of values in the current Select Case block.
            Case "TERMINALOUT", "OUTTERMINAL", "OUTPUTTERMINAL"
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If colTermOut = 0 Then colTermOut = c
            ' [R7 LINE] Handles values not matched by the preceding Case branches.
            Case Else
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Left$(headerKey, 9) = "ALTERNATE" Or Left$(headerKey, 5) = "ALIAS" Then altColumns.Add c
        ' [R7 LINE] Ends the current Select Case block.
        End Select
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next c

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For r = bestHeaderRow + 1 To lastRow
        ' [R7 LINE] Calculates or updates canonicalType using the expression in this statement.
        canonicalType = Trim$(CStr(ws.Cells(r, colType).value))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(canonicalType) > 0 Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If colControl > 0 Then controlDevice = Trim$(CStr(ws.Cells(r, colControl).value)) Else controlDevice = ""
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If colBlock > 0 Then blockName = Trim$(CStr(ws.Cells(r, colBlock).value)) Else blockName = ""
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If colTermIn > 0 Then terminalIn = Trim$(CStr(ws.Cells(r, colTermIn).value)) Else terminalIn = ""
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If colTermOut > 0 Then terminalOut = Trim$(CStr(ws.Cells(r, colTermOut).value)) Else terminalOut = ""

            ' [R7 LINE] Calculates or updates recordText using the expression in this statement.
            recordText = canonicalType & Chr$(30) & controlDevice & Chr$(30) & blockName & Chr$(30) & terminalIn & Chr$(30) & terminalOut
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            AN_AddDataAlias result, canonicalType, recordText

            ' Loop through every object or value in the referenced collection.
            ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
            For Each altCol In altColumns
                ' [R7 LINE] Calculates or updates aliasText using the expression in this statement.
                aliasText = Trim$(CStr(ws.Cells(r, CLng(altCol)).value))
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If Len(aliasText) > 0 Then AN_AddDataAlias result, aliasText, recordText
            ' [R7 LINE] Advances to the next item in the current For loop.
            Next altCol

            'The three PNL rows identify their area-main role through CONTROL DEVICE.
            ' [R7 LINE] Calculates or updates controlCompact using the expression in this statement.
            controlCompact = AN_CompactDataHeader(controlDevice)
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If InStr(1, controlCompact, "AEAREAMAINPANEL", vbTextCompare) > 0 Then AN_AddDataAlias result, "AE", recordText
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If InStr(1, controlCompact, "PLCAREAMAINPANEL", vbTextCompare) > 0 Then AN_AddDataAlias result, "PLC", recordText
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If InStr(1, controlCompact, "IPCAREAMAINPANEL", vbTextCompare) > 0 Then AN_AddDataAlias result, "IPC", recordText
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next r

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_LoadNetworkDeviceTypes.
    Set AN_LoadNetworkDeviceTypes = result
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub AN_AddDataAlias; the following statements perform or calculate this named workflow.
Private Sub AN_AddDataAlias(ByVal catalog As Object, ByVal aliasText As String, ByVal recordText As String)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As String
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = AN_NormalizeTypeKey(aliasText)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(key) = 0 Then Exit Sub
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not catalog.Exists(key) Then catalog.Add key, recordText
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_CompactDataHeader; the following statements perform or calculate this named workflow.
Private Function AN_CompactDataHeader(ByVal value As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As String
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = UCase$(Trim$(value))
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, "_", "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, " ", "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, "-", "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, "/", "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, "\", "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, "(", "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, ")", "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, vbCr, "")
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = Replace(key, vbLf, "")
    ' [R7 LINE] Calculates or updates AN_CompactDataHeader using the expression in this statement.
    AN_CompactDataHeader = key
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_IsDeviceTypeHeader; the following statements perform or calculate this named workflow.
Private Function AN_IsDeviceTypeHeader(ByVal value As String) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As String
    ' [R7 LINE] Calculates or updates key using the expression in this statement.
    key = AN_CompactDataHeader(value)
    ' [R7 LINE] Chooses a processing branch based on the current value.
    Select Case key
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "DEVICETYPE", "DEVICETYPES", "TYPE", "ITEMTYPE", "ITEMTYPES", _
             "NETWORKTYPE", "NETWORKTYPES", "NETWORKDEVICETYPE", "NETWORKDEVICETYPES", _
             "CONTROLDEVICETYPE", "CONTROLDEVICETYPES", "DEVICECATEGORY", _
             "TYPEDESC", "TYPEDESCRIPTION"
            ' [R7 LINE] Calculates or updates AN_IsDeviceTypeHeader using the expression in this statement.
            AN_IsDeviceTypeHeader = True
    ' [R7 LINE] Ends the current Select Case block.
    End Select
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_DataTypeEnabled; the following statements perform or calculate this named workflow.
Private Function AN_DataTypeEnabled(ByVal allowedTypes As Object, ParamArray candidates() As Variant) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, key As String
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = LBound(candidates) To UBound(candidates)
        ' [R7 LINE] Calculates or updates key using the expression in this statement.
        key = AN_NormalizeTypeKey(CStr(candidates(i)))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(key) > 0 Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If allowedTypes.Exists(key) Then
                ' [R7 LINE] Calculates or updates AN_DataTypeEnabled using the expression in this statement.
                AN_DataTypeEnabled = True
                ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
                Exit Function
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_NormalizeTypeKey; the following statements perform or calculate this named workflow.
Private Function AN_NormalizeTypeKey(ByVal rawType As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim t As String
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = UCase$(Trim$(rawType))
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = Replace(t, "\", "/")
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = Replace(t, "-", "_")
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = Replace(t, "/", "_")
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = Replace(t, " ", "_")
    ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
    Do While InStr(t, "__") > 0
        ' [R7 LINE] Calculates or updates t using the expression in this statement.
        t = Replace(t, "__", "_")
    ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
    Loop
    ' [R7 LINE] Calculates or updates AN_NormalizeTypeKey using the expression in this statement.
    AN_NormalizeTypeKey = t
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_NormalizeType; the following statements perform or calculate this named workflow.
Private Function AN_NormalizeType(ByVal rawType As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim t As String
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = UCase$(Trim$(rawType))
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = Replace(t, " ", "")
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = Replace(t, "_", "/")
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = Replace(t, "\", "/")
    ' [R7 LINE] Calculates or updates AN_NormalizeType using the expression in this statement.
    AN_NormalizeType = t
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_BaseSwitchGroupKey; the following statements perform or calculate this named workflow.
Private Function AN_BaseSwitchGroupKey(ByVal panel As String, ByVal swg As String) As String
    'Panel and SwitchGroup are the permanent routing boundary for every policy.
    ' [R7 LINE] Calculates or updates AN_BaseSwitchGroupKey using the expression in this statement.
    AN_BaseSwitchGroupKey = UCase$(Trim$(panel)) & "|" & UCase$(Trim$(swg))
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_RouteGroupKey; the following statements perform or calculate this named workflow.
Private Function AN_RouteGroupKey(ByVal panel As String, ByVal swg As String, _
    ByVal canonicalType As String, ByVal mixGroups As Object) As String

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim baseKey As String, routeFamily As String
    ' [R7 LINE] Calculates or updates baseKey using the expression in this statement.
    baseKey = AN_BaseSwitchGroupKey(panel, swg)

    'Default: RIO and IO/S are one preferred-isolation family and all other
    'devices are a separate GENERAL family. A user-approved group becomes MIXED.
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not mixGroups Is Nothing Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If mixGroups.Exists(baseKey) Then
            ' [R7 LINE] Calculates or updates routeFamily using the expression in this statement.
            routeFamily = "MIXED"
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(routeFamily) = 0 Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If AN_IsRIOIOSRouteType(canonicalType) Then
            ' [R7 LINE] Calculates or updates routeFamily using the expression in this statement.
            routeFamily = "RIO_IOS"
        ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
        Else
            ' [R7 LINE] Calculates or updates routeFamily using the expression in this statement.
            routeFamily = "GENERAL"
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates AN_RouteGroupKey using the expression in this statement.
    AN_RouteGroupKey = baseKey & "|" & routeFamily
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_RouteFamilyFromGroupKey; the following statements perform or calculate this named workflow.
Private Function AN_RouteFamilyFromGroupKey(ByVal groupKey As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim p As Long
    ' [R7 LINE] Calculates or updates p using the expression in this statement.
    p = InStrRev(groupKey, "|")
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If p > 0 Then
        ' [R7 LINE] Calculates or updates AN_RouteFamilyFromGroupKey using the expression in this statement.
        AN_RouteFamilyFromGroupKey = UCase$(mid$(groupKey, p + 1))
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Calculates or updates AN_RouteFamilyFromGroupKey using the expression in this statement.
        AN_RouteFamilyFromGroupKey = "GENERAL"
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_IsRIOIOSRouteType; the following statements perform or calculate this named workflow.
Private Function AN_IsRIOIOSRouteType(ByVal canonicalType As String) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim t As String
    ' [R7 LINE] Calculates or updates t using the expression in this statement.
    t = UCase$(Trim$(canonicalType))
    ' [R7 LINE] Calculates or updates AN_IsRIOIOSRouteType using the expression in this statement.
    AN_IsRIOIOSRouteType = (t = "RIO" Or t = "IO/S" Or t = "IO_S" Or t = "IOS")
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_DeviceFamilyPriority; the following statements perform or calculate this named workflow.
Private Function AN_DeviceFamilyPriority(ByVal canonicalType As String) As Long
    'RIO and IO/S are always placed first inside a user-approved mixed route.
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If AN_IsRIOIOSRouteType(canonicalType) Then
        ' [R7 LINE] Calculates or updates AN_DeviceFamilyPriority using the expression in this statement.
        AN_DeviceFamilyPriority = 0
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Calculates or updates AN_DeviceFamilyPriority using the expression in this statement.
        AN_DeviceFamilyPriority = 1
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_DevicePriority; the following statements perform or calculate this named workflow.
Private Function AN_DevicePriority(ByVal canonicalType As String) As Long
    ' [R7 LINE] Chooses a processing branch based on the current value.
    Select Case UCase$(Trim$(canonicalType))
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "RIO": AN_DevicePriority = 0
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "IO/S", "IO_S", "IOS": AN_DevicePriority = 1
        ' [R7 LINE] Handles values not matched by the preceding Case branches.
        Case Else: AN_DevicePriority = 2
    ' [R7 LINE] Ends the current Select Case block.
    End Select
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_BuildRouteRecords; the following statements perform or calculate this named workflow.
Private Function AN_BuildRouteRecords(ByVal devices As Object, ByVal mixGroups As Object, _
    ByRef recordCount As Long) As Variant

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim items As Variant, rec As Variant, records() As Variant
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim finalGroupMin As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, groupKey As String

    ' [R7 LINE] Calculates or updates recordCount using the expression in this statement.
    recordCount = devices.count
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If recordCount = 0 Then Exit Function

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to finalGroupMin.
    Set finalGroupMin = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Calculates or updates finalGroupMin.CompareMode using the expression in this statement.
    finalGroupMin.CompareMode = vbTextCompare
    ' [R7 LINE] Calculates or updates items using the expression in this statement.
    items = devices.items

    'Calculate the minimum sequence for each final route group after policy choices.
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 0 To UBound(items)
        ' [R7 LINE] Calculates or updates rec using the expression in this statement.
        rec = items(i)
        ' [R7 LINE] Calculates or updates groupKey using the expression in this statement.
        groupKey = AN_RouteGroupKey(CStr(rec(0)), CStr(rec(1)), CStr(rec(3)), mixGroups)
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Not finalGroupMin.Exists(groupKey) Then
            ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
            finalGroupMin.Add groupKey, CDbl(rec(5))
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf CDbl(rec(5)) < CDbl(finalGroupMin(groupKey)) Then
            ' [R7 LINE] Calculates or updates finalGroupMin(groupKey) using the expression in this statement.
            finalGroupMin(groupKey) = CDbl(rec(5))
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ReDim records(1 To recordCount, 1 To 13)
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 0 To UBound(items)
        ' [R7 LINE] Calculates or updates rec using the expression in this statement.
        rec = items(i)
        ' [R7 LINE] Calculates or updates groupKey using the expression in this statement.
        groupKey = AN_RouteGroupKey(CStr(rec(0)), CStr(rec(1)), CStr(rec(3)), mixGroups)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 1) = rec(0)   'Panel
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 2) = rec(1)   'SwitchGroup
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 3) = rec(2)   'SIS sequence
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 4) = rec(3)   'Canonical type
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 5) = rec(4)   'Route length
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 6) = rec(5)   'Sort sequence
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 7) = rec(6)   'Description
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 8) = rec(7)   'Topology cell
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 9) = rec(8)   'Area
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 10) = rec(9)  'Source row
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 11) = finalGroupMin(groupKey)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 12) = rec(10) 'Device priority
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        records(i + 1, 13) = groupKey
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If recordCount > 1 Then AN_QuickSort records, 1, recordCount
    ' [R7 LINE] Calculates or updates AN_BuildRouteRecords using the expression in this statement.
    AN_BuildRouteRecords = records
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_CountRoutesByPanel; the following statements perform or calculate this named workflow.
Private Function AN_CountRoutesByPanel(ByRef records As Variant, ByVal recordCount As Long, _
    ByVal panelRacks As Object) As Object

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim result As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim currentPanel As String, currentGroup As String, panel As String, groupKey As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, routeCount As Long, segmentLength As Double, itemLength As Double

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to result.
    Set result = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Calculates or updates result.CompareMode using the expression in this statement.
    result.CompareMode = vbTextCompare

    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = 1 To recordCount
        ' [R7 LINE] Calculates or updates panel using the expression in this statement.
        panel = CStr(records(i, 1))
        ' [R7 LINE] Calculates or updates groupKey using the expression in this statement.
        groupKey = CStr(records(i, 13))
        ' [R7 LINE] Calculates or updates itemLength using the expression in this statement.
        itemLength = CDbl(records(i, 5))

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If StrComp(panel, currentPanel, vbTextCompare) <> 0 Then
            ' [R7 LINE] Calculates or updates currentPanel using the expression in this statement.
            currentPanel = panel
            ' [R7 LINE] Calculates or updates currentGroup using the expression in this statement.
            currentGroup = vbNullString
            ' [R7 LINE] Calculates or updates segmentLength using the expression in this statement.
            segmentLength = 0#
            ' [R7 LINE] Calculates or updates routeCount using the expression in this statement.
            routeCount = 0
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If panelRacks.Exists(UCase$(Trim$(panel))) Then routeCount = 1
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If StrComp(groupKey, currentGroup, vbTextCompare) <> 0 Then
            ' [R7 LINE] Calculates or updates currentGroup using the expression in this statement.
            currentGroup = groupKey
            ' [R7 LINE] Calculates or updates routeCount using the expression in this statement.
            routeCount = routeCount + 1
            ' [R7 LINE] Calculates or updates segmentLength using the expression in this statement.
            segmentLength = 0#
        ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
        ElseIf segmentLength > 0# And segmentLength + itemLength > AN_MAX_ROUTE_METERS Then
            ' [R7 LINE] Calculates or updates routeCount using the expression in this statement.
            routeCount = routeCount + 1
            ' [R7 LINE] Calculates or updates segmentLength using the expression in this statement.
            segmentLength = 0#
        ' [R7 LINE] Ends the current conditional block.
        End If

        ' [R7 LINE] Calculates or updates segmentLength using the expression in this statement.
        segmentLength = segmentLength + itemLength
        ' [R7 LINE] Calculates or updates result(UCase$(Trim$(panel))) using the expression in this statement.
        result(UCase$(Trim$(panel))) = routeCount
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_CountRoutesByPanel.
    Set AN_CountRoutesByPanel = result
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_PanelHasMixOpportunity; the following statements perform or calculate this named workflow.
Private Function AN_PanelHasMixOpportunity(ByVal groupFlags As Object, ByVal panel As String) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As Variant, prefix As String
    ' [R7 LINE] Calculates or updates prefix using the expression in this statement.
    prefix = UCase$(Trim$(panel)) & "|"
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For Each key In groupFlags.keys
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Left$(UCase$(CStr(key)), Len(prefix)) = prefix Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If CLng(groupFlags(key)) = 3 Then
                ' [R7 LINE] Calculates or updates AN_PanelHasMixOpportunity using the expression in this statement.
                AN_PanelHasMixOpportunity = True
                ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
                Exit Function
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next key
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub AN_AddPanelMixGroups; the following statements perform or calculate this named workflow.
Private Sub AN_AddPanelMixGroups(ByVal groupFlags As Object, ByVal panel As String, _
    ByVal mixGroups As Object)

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim key As Variant, prefix As String
    ' [R7 LINE] Calculates or updates prefix using the expression in this statement.
    prefix = UCase$(Trim$(panel)) & "|"
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For Each key In groupFlags.keys
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Left$(UCase$(CStr(key)), Len(prefix)) = prefix Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If CLng(groupFlags(key)) = 3 Then mixGroups(CStr(key)) = True
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next key
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_SelectRequiredPanelMixGroups; the following statements perform or calculate this named workflow.
Private Function AN_SelectRequiredPanelMixGroups(ByVal devices As Object, _
    ByVal groupFlags As Object, ByVal panel As String, ByVal existingMixGroups As Object, _
    ByVal panelRacks As Object, ByVal targetRoutes As Long, _
    ByRef resultingRouteCount As Long) As Object

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim selected As Object, trial As Object, counts As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim records As Variant, key As Variant, bestKey As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim recordCount As Long, currentCount As Long, testCount As Long, bestCount As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim prefix As String

    ' [R7 LINE] Assigns the required workbook object or dictionary reference to selected.
    Set selected = AN_CopyDictionary(existingMixGroups)
    ' [R7 LINE] Calculates or updates records using the expression in this statement.
    records = AN_BuildRouteRecords(devices, selected, recordCount)
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to counts.
    Set counts = AN_CountRoutesByPanel(records, recordCount, panelRacks)
    ' [R7 LINE] Calculates or updates currentCount using the expression in this statement.
    currentCount = AN_DictionaryLong(counts, UCase$(Trim$(panel)))
    ' [R7 LINE] Calculates or updates prefix using the expression in this statement.
    prefix = UCase$(Trim$(panel)) & "|"

    'Add only the individual Panel + SwitchGroup mix permissions that actually
    'reduce route demand, stopping as soon as the first NWS has enough ports.
    ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
    Do While currentCount > targetRoutes
        ' [R7 LINE] Calculates or updates bestKey using the expression in this statement.
        bestKey = vbNullString
        ' [R7 LINE] Calculates or updates bestCount using the expression in this statement.
        bestCount = currentCount

        ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
        For Each key In groupFlags.keys
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If Left$(UCase$(CStr(key)), Len(prefix)) = prefix Then
                ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                If CLng(groupFlags(key)) = 3 And Not selected.Exists(CStr(key)) Then
                    ' [R7 LINE] Assigns the required workbook object or dictionary reference to trial.
                    Set trial = AN_CopyDictionary(selected)
                    ' [R7 LINE] Calculates or updates trial(CStr(key)) using the expression in this statement.
                    trial(CStr(key)) = True
                    ' [R7 LINE] Calculates or updates records using the expression in this statement.
                    records = AN_BuildRouteRecords(devices, trial, recordCount)
                    ' [R7 LINE] Assigns the required workbook object or dictionary reference to counts.
                    Set counts = AN_CountRoutesByPanel(records, recordCount, panelRacks)
                    ' [R7 LINE] Calculates or updates testCount using the expression in this statement.
                    testCount = AN_DictionaryLong(counts, UCase$(Trim$(panel)))
                    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
                    If testCount < bestCount Then
                        ' [R7 LINE] Calculates or updates bestCount using the expression in this statement.
                        bestCount = testCount
                        ' [R7 LINE] Calculates or updates bestKey using the expression in this statement.
                        bestKey = CStr(key)
                    ' [R7 LINE] Ends the current conditional block.
                    End If
                ' [R7 LINE] Ends the current conditional block.
                End If
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Advances to the next item in the current For loop.
        Next key

        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(bestKey) = 0 Then Exit Do
        ' [R7 LINE] Calculates or updates selected(bestKey) using the expression in this statement.
        selected(bestKey) = True
        ' [R7 LINE] Calculates or updates currentCount using the expression in this statement.
        currentCount = bestCount
    ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
    Loop

    ' [R7 LINE] Calculates or updates resultingRouteCount using the expression in this statement.
    resultingRouteCount = currentCount
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_SelectRequiredPanelMixGroups.
    Set AN_SelectRequiredPanelMixGroups = selected
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_CopyDictionary; the following statements perform or calculate this named workflow.
Private Function AN_CopyDictionary(ByVal source As Object) As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim result As Object, key As Variant
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to result.
    Set result = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Calculates or updates result.CompareMode using the expression in this statement.
    result.CompareMode = vbTextCompare
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For Each key In source.keys
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        result.Add CStr(key), source(key)
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next key
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_CopyDictionary.
    Set AN_CopyDictionary = result
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_DictionaryLong; the following statements perform or calculate this named workflow.
Private Function AN_DictionaryLong(ByVal values As Object, ByVal key As String) As Long
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not values Is Nothing Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If values.Exists(key) Then AN_DictionaryLong = CLng(values(key))
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_CeilingDivide; the following statements perform or calculate this named workflow.
Private Function AN_CeilingDivide(ByVal numerator As Long, ByVal denominator As Long) As Long
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If denominator <= 0 Then Exit Function
    ' [R7 LINE] Calculates or updates AN_CeilingDivide using the expression in this statement.
    AN_CeilingDivide = (numerator + denominator - 1) \ denominator
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_AskRIOIOSCapacityChoice; the following statements perform or calculate this named workflow.
Private Function AN_AskRIOIOSCapacityChoice(ByVal panel As String, _
    ByVal isolatedRoutes As Long, ByVal mixedRoutes As Long) As VbMsgBoxResult

    ' [R7 LINE] Displays the routing choice, completion summary, warning, or error message to the user.
    AN_AskRIOIOSCapacityChoice = MsgBox( _
        "Panel " & panel & " requires " & isolatedRoutes & _
        " switch route(s) when RIO/IO-S are isolated first." & vbCrLf & _
        "Controlled mixing can reduce the plan to " & mixedRoutes & " route(s)." & vbCrLf & vbCrLf & _
        "YES = Add the required panel network switch(es) and keep RIO/IO-S isolated" & vbCrLf & _
        "NO = Allow RIO/IO-S to mix with other devices only inside the same Panel + SwitchGroup" & vbCrLf & _
        "CANCEL = Stop network generation" & vbCrLf & vbCrLf & _
        "The 80 m maximum remains active for either choice.", _
        vbYesNoCancel + vbQuestion + vbDefaultButton1, _
        "RIO / IO-S Preferred Isolation Needs More Ports")
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_GetPanelSwitchDecision; the following statements perform or calculate this named workflow.
Private Function AN_GetPanelSwitchDecision(ByVal panel As String, ByVal switchNumber As Long, _
    ByVal preapprovedSwitchCounts As Object) As VbMsgBoxResult

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim approvedCount As Long
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Not preapprovedSwitchCounts Is Nothing Then
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If preapprovedSwitchCounts.Exists(UCase$(Trim$(panel))) Then
            ' [R7 LINE] Calculates or updates approvedCount using the expression in this statement.
            approvedCount = CLng(preapprovedSwitchCounts(UCase$(Trim$(panel))))
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If switchNumber <= approvedCount Then
                ' [R7 LINE] Calculates or updates AN_GetPanelSwitchDecision using the expression in this statement.
                AN_GetPanelSwitchDecision = vbYes
                ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
                Exit Function
            ' [R7 LINE] Ends the current conditional block.
            End If
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Ends the current conditional block.
    End If
    ' [R7 LINE] Calculates or updates AN_GetPanelSwitchDecision using the expression in this statement.
    AN_GetPanelSwitchDecision = AN_AskAddPanelNetworkSwitch(panel, switchNumber)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_MainTypePriority; the following statements perform or calculate this named workflow.
Private Function AN_MainTypePriority(ByVal mainType As String) As Long
    ' [R7 LINE] Chooses a processing branch based on the current value.
    Select Case UCase$(mainType)
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "AE": AN_MainTypePriority = 1
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "PLC": AN_MainTypePriority = 2
        ' [R7 LINE] Handles this value or group of values in the current Select Case block.
        Case "IPC": AN_MainTypePriority = 3
        ' [R7 LINE] Handles values not matched by the preceding Case branches.
        Case Else: AN_MainTypePriority = 9
    ' [R7 LINE] Ends the current Select Case block.
    End Select
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_RackTopologyText; the following statements perform or calculate this named workflow.
Private Function AN_RackTopologyText(ByVal panel As String, Optional ByVal dataDescription As String = "") As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim panelText As String
    ' [R7 LINE] Calculates or updates panelText using the expression in this statement.
    panelText = Trim$(panel)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(panelText) = 0 Then panelText = "RCP"
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(Trim$(dataDescription)) = 0 Then dataDescription = "IO RACK"
    ' [R7 LINE] Calculates or updates AN_RackTopologyText using the expression in this statement.
    AN_RackTopologyText = panelText & " RACK [" & Trim$(dataDescription) & "]"
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_MainPanelTopologyText; the following statements perform or calculate this named workflow.
Private Function AN_MainPanelTopologyText(ByVal swg As String, ByVal sisSeq As String, _
    ByVal mainType As String, Optional ByVal dataDescription As String = "") As String

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(Trim$(dataDescription)) = 0 Then dataDescription = mainType & " AREA MAIN PANEL"
    ' [R7 LINE] Calculates or updates AN_MainPanelTopologyText using the expression in this statement.
    AN_MainPanelTopologyText = "IO_" & Replace(Trim$(swg), "-", "_") & "_" & _
        Replace(Trim$(sisSeq), "-", "_") & " [" & Trim$(dataDescription) & "]"
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_BuildHeaderMap; the following statements perform or calculate this named workflow.
Private Function AN_BuildHeaderMap(ByVal data As Variant, ByVal lastCol As Long) As Object
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim d As Object, c As Long, k As String
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to d.
    Set d = CreateObject("Scripting.Dictionary")
    ' [R7 LINE] Calculates or updates d.CompareMode using the expression in this statement.
    d.CompareMode = vbTextCompare
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For c = 1 To lastCol
        ' [R7 LINE] Calculates or updates k using the expression in this statement.
        k = AN_NormalizeHeader(CStr(data(1, c)))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If Len(k) > 0 Then d(k) = c
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next c
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_BuildHeaderMap.
    Set AN_BuildHeaderMap = d
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_HeaderCol; the following statements perform or calculate this named workflow.
Private Function AN_HeaderCol(ByVal headers As Object, ParamArray aliases() As Variant) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, k As String
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = LBound(aliases) To UBound(aliases)
        ' [R7 LINE] Calculates or updates k using the expression in this statement.
        k = AN_NormalizeHeader(CStr(aliases(i)))
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If headers.Exists(k) Then
            ' [R7 LINE] Calculates or updates AN_HeaderCol using the expression in this statement.
            AN_HeaderCol = CLng(headers(k))
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_NormalizeHeader; the following statements perform or calculate this named workflow.
Private Function AN_NormalizeHeader(ByVal txt As String) As String
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = UCase$(Trim$(txt))
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, "_", " ")
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, vbCr, " ")
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(txt, vbLf, " ")
    ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
    Do While InStr(txt, "  ") > 0
        ' [R7 LINE] Calculates or updates txt using the expression in this statement.
        txt = Replace(txt, "  ", " ")
    ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
    Loop
    ' [R7 LINE] Calculates or updates AN_NormalizeHeader using the expression in this statement.
    AN_NormalizeHeader = txt
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_ArrayText; the following statements perform or calculate this named workflow.
Private Function AN_ArrayText(ByVal data As Variant, ByVal rowNum As Long, ByVal colNum As Long) As String
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If colNum <= 0 Then Exit Function
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If IsError(data(rowNum, colNum)) Or IsEmpty(data(rowNum, colNum)) Then Exit Function
    ' [R7 LINE] Calculates or updates AN_ArrayText using the expression in this statement.
    AN_ArrayText = Trim$(CStr(data(rowNum, colNum)))
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_ArrayValue; the following statements perform or calculate this named workflow.
Private Function AN_ArrayValue(ByVal data As Variant, ByVal rowNum As Long, ByVal colNum As Long) As Variant
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If colNum <= 0 Then
        ' [R7 LINE] Calculates or updates AN_ArrayValue using the expression in this statement.
        AN_ArrayValue = Empty
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Calculates or updates AN_ArrayValue using the expression in this statement.
        AN_ArrayValue = data(rowNum, colNum)
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub AN_QuickSort; the following statements perform or calculate this named workflow.
Private Sub AN_QuickSort(ByRef a As Variant, ByVal lo As Long, ByVal hi As Long)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, j As Long, c As Long, mid As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim pivot(1 To 13) As Variant, tmp As Variant

    ' [R7 LINE] Calculates or updates i using the expression in this statement.
    i = lo
    ' [R7 LINE] Calculates or updates j using the expression in this statement.
    j = hi
    ' [R7 LINE] Calculates or updates mid using the expression in this statement.
    mid = (lo + hi) \ 2
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For c = 1 To 13
        ' [R7 LINE] Calculates or updates pivot(c) using the expression in this statement.
        pivot(c) = a(mid, c)
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next c

    ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
    Do While i <= j
        ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
        Do While AN_CompareRowToPivot(a, i, pivot) < 0
            ' [R7 LINE] Calculates or updates i using the expression in this statement.
            i = i + 1
        ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
        Loop
        ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
        Do While AN_CompareRowToPivot(a, j, pivot) > 0
            ' [R7 LINE] Calculates or updates j using the expression in this statement.
            j = j - 1
        ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
        Loop
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If i <= j Then
            ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
            For c = 1 To 13
                ' [R7 LINE] Calculates or updates tmp using the expression in this statement.
                tmp = a(i, c)
                ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                a(i, c) = a(j, c)
                ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
                a(j, c) = tmp
            ' [R7 LINE] Advances to the next item in the current For loop.
            Next c
            ' [R7 LINE] Calculates or updates i using the expression in this statement.
            i = i + 1
            ' [R7 LINE] Calculates or updates j using the expression in this statement.
            j = j - 1
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
    Loop

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If lo < j Then AN_QuickSort a, lo, j
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If i < hi Then AN_QuickSort a, i, hi
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_CompareRowToPivot; the following statements perform or calculate this named workflow.
Private Function AN_CompareRowToPivot(ByRef a As Variant, ByVal rowNum As Long, ByRef p() As Variant) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim cmp As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim rowFamily As Long, pivotFamily As Long

    'Panel and SwitchGroup are sorted first because neither isolation nor mixing may
    'cross those permanent boundaries.
    ' [R7 LINE] Calculates or updates cmp using the expression in this statement.
    cmp = AN_CompareNatural(CStr(a(rowNum, 1)), CStr(p(1)))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = AN_CompareNatural(CStr(a(rowNum, 2)), CStr(p(2)))

    'Within a SwitchGroup, RIO is first, then IO/S, then all general devices.
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then
        ' [R7 LINE] Calculates or updates rowFamily using the expression in this statement.
        rowFamily = AN_DeviceFamilyPriority(CStr(a(rowNum, 4)))
        ' [R7 LINE] Calculates or updates pivotFamily using the expression in this statement.
        pivotFamily = AN_DeviceFamilyPriority(CStr(p(4)))
        ' [R7 LINE] Calculates or updates cmp using the expression in this statement.
        cmp = AN_CompareDouble(CDbl(rowFamily), CDbl(pivotFamily))
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = AN_CompareDouble(CDbl(a(rowNum, 11)), CDbl(p(11)))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = StrComp(CStr(a(rowNum, 13)), CStr(p(13)), vbTextCompare)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = AN_CompareDouble(CDbl(a(rowNum, 12)), CDbl(p(12)))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = AN_CompareDouble(CDbl(a(rowNum, 6)), CDbl(p(6)))
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = StrComp(CStr(a(rowNum, 3)), CStr(p(3)), vbTextCompare)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If cmp = 0 Then cmp = StrComp(CStr(a(rowNum, 4)), CStr(p(4)), vbTextCompare)
    ' [R7 LINE] Calculates or updates AN_CompareRowToPivot using the expression in this statement.
    AN_CompareRowToPivot = Sgn(cmp)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_CompareNatural; the following statements perform or calculate this named workflow.
Private Function AN_CompareNatural(ByVal a As String, ByVal b As String) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim na As Double, nb As Double
    ' [R7 LINE] Calculates or updates na using the expression in this statement.
    na = PD6Net_FirstNumber(a)
    ' [R7 LINE] Calculates or updates nb using the expression in this statement.
    nb = PD6Net_FirstNumber(b)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If na <> nb Then
        ' [R7 LINE] Calculates or updates AN_CompareNatural using the expression in this statement.
        AN_CompareNatural = Sgn(na - nb)
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Calculates or updates AN_CompareNatural using the expression in this statement.
        AN_CompareNatural = Sgn(StrComp(a, b, vbTextCompare))
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_CompareDouble; the following statements perform or calculate this named workflow.
Private Function AN_CompareDouble(ByVal a As Double, ByVal b As Double) As Long
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If a < b Then
        ' [R7 LINE] Calculates or updates AN_CompareDouble using the expression in this statement.
        AN_CompareDouble = -1
    ' [R7 LINE] Evaluates the next alternative condition when earlier conditions were false.
    ElseIf a > b Then
        ' [R7 LINE] Calculates or updates AN_CompareDouble using the expression in this statement.
        AN_CompareDouble = 1
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub AN_SetNetworkMode; the following statements perform or calculate this named workflow.
Private Sub AN_SetNetworkMode(ByVal wb As Workbook, ByVal modeName As String)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim ws As Worksheet
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
    Set ws = AN_GetOrCreateSheet(wb, "IO_Topology")
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Range("A1").value = "IO_Topology"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Range("B1").value = "MODE=" & UCase$(modeName)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub AN_DeletePriorAutoRawSheets; the following statements perform or calculate this named workflow.
Private Sub AN_DeletePriorAutoRawSheets(ByVal wb As Workbook)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long, ws As Worksheet
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = wb.Worksheets.count To 1 Step -1
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
        Set ws = wb.Worksheets(i)
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If AN_IsRawRCPSheet(ws.Name) Then
            ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
            If AN_IsAutoSheet(ws) Then ws.Delete
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_IsRawRCPSheet; the following statements perform or calculate this named workflow.
Private Function AN_IsRawRCPSheet(ByVal sheetName As String) As Boolean
    ' [R7 LINE] Calculates or updates AN_IsRawRCPSheet using the expression in this statement.
    AN_IsRawRCPSheet = (UCase$(Left$(Trim$(sheetName), 3)) = "RCP" And _
                        Right$(UCase$(Trim$(sheetName)), 8) <> " - CLEAN")
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_IsAutoSheet; the following statements perform or calculate this named workflow.
Private Function AN_IsAutoSheet(ByVal ws As Worksheet) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim lastCol As Long, c As Long
    ' [R7 LINE] Calculates or updates lastCol using the expression in this statement.
    lastCol = AN_LastUsedCol(ws)
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For c = 1 To lastCol
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If InStr(1, CStr(ws.Cells(2, c).value), AN_MARKER, vbTextCompare) > 0 Then
            ' [R7 LINE] Calculates or updates AN_IsAutoSheet using the expression in this statement.
            AN_IsAutoSheet = True
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next c
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_AutoPanelSheetName; the following statements perform or calculate this named workflow.
Private Function AN_AutoPanelSheetName(ByVal wb As Workbook, ByVal panel As String) As String
    ' [R7 LINE] Calculates or updates AN_AutoPanelSheetName using the expression in this statement.
    AN_AutoPanelSheetName = AN_AutoPanelSwitchSheetName(wb, panel, 1)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_AutoPanelSwitchSheetName; the following statements perform or calculate this named workflow.
Private Function AN_AutoPanelSwitchSheetName(ByVal wb As Workbook, ByVal panel As String, _
    ByVal panelSwitchNumber As Long) As String

    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim baseName As String, candidate As String, suffix As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim ws As Worksheet, n As Long
    ' [R7 LINE] Calculates or updates baseName using the expression in this statement.
    baseName = AN_PanelSheetName(panel)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If panelSwitchNumber > 1 Then
        ' [R7 LINE] Calculates or updates suffix using the expression in this statement.
        suffix = "-SW" & CStr(panelSwitchNumber)
        ' [R7 LINE] Calculates or updates baseName using the expression in this statement.
        baseName = Left$(baseName, 31 - Len(suffix)) & suffix
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Calculates or updates candidate using the expression in this statement.
    candidate = baseName
    ' [R7 LINE] Calculates or updates n using the expression in this statement.
    n = 1
    ' Start a loop whose exit condition is evaluated inside or at the end of the loop.
    ' [R7 LINE] Starts a loop that continues until its exit condition is satisfied.
    Do
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
        Set ws = Nothing
        ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
        ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
        On Error Resume Next
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
        Set ws = wb.Worksheets(candidate)
        ' [R7 LINE] Routes later runtime errors to the named error-handling section.
        On Error GoTo 0
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If ws Is Nothing Then
            ' [R7 LINE] Calculates or updates AN_AutoPanelSwitchSheetName using the expression in this statement.
            AN_AutoPanelSwitchSheetName = candidate
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
        ' [R7 LINE] Calculates or updates n using the expression in this statement.
        n = n + 1
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If n = 2 Then suffix = "-AUTO" Else suffix = "-AUTO" & CStr(n)
        ' [R7 LINE] Calculates or updates candidate using the expression in this statement.
        candidate = Left$(baseName, 31 - Len(suffix)) & suffix
    ' [R7 LINE] Returns to the start of the current Do loop or finishes it when the condition is met.
    Loop
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_PanelSheetName; the following statements perform or calculate this named workflow.
Private Function AN_PanelSheetName(ByVal panel As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim txt As String, badChars As Variant, i As Long
    ' [R7 LINE] Calculates or updates txt using the expression in this statement.
    txt = Replace(Trim$(panel), "_", "-")
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If UCase$(Left$(txt, 3)) <> "RCP" Then txt = "RCP-" & txt
    ' [R7 LINE] Calculates or updates badChars using the expression in this statement.
    badChars = Array("/", "\", "[", "]", ":", "*", "?", Chr$(34))
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = LBound(badChars) To UBound(badChars)
        ' [R7 LINE] Calculates or updates txt using the expression in this statement.
        txt = Replace(txt, CStr(badChars(i)), "-")
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(txt) = 0 Then txt = "RCP-AUTO"
    ' [R7 LINE] Calculates or updates AN_PanelSheetName using the expression in this statement.
    AN_PanelSheetName = Left$(txt, 31)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_GetOrCreateSheet; the following statements perform or calculate this named workflow.
Private Function AN_GetOrCreateSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_GetOrCreateSheet.
    Set AN_GetOrCreateSheet = wb.Worksheets(sheetName)
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If AN_GetOrCreateSheet Is Nothing Then
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to AN_GetOrCreateSheet.
        Set AN_GetOrCreateSheet = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ' [R7 LINE] Calculates or updates AN_GetOrCreateSheet.name using the expression in this statement.
        AN_GetOrCreateSheet.Name = sheetName
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Sub AN_StyleTopologySheet; the following statements perform or calculate this named workflow.
Private Sub AN_StyleTopologySheet(ByVal ws As Worksheet)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim lastRow As Long, c As Long
    ' [R7 LINE] Calculates or updates LastRow using the expression in this statement.
    lastRow = AN_LastUsedRow(ws)

    ' Use this object as the target for the following dot-prefixed property assignments.
    ' [R7 LINE] Uses this object as the target for the following grouped property assignments.
    With ws.Range(ws.Cells(1, 1), ws.Cells(1, AN_UPLINK_PORT))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Font.Bold = True
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Font.Color = vbWhite
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Interior.Color = RGB(31, 78, 121)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .HorizontalAlignment = xlCenter
    ' Finish the current With object block.
    ' [R7 LINE] Ends the current With block.
    End With
    ' Use this object as the target for the following dot-prefixed property assignments.
    ' [R7 LINE] Uses this object as the target for the following grouped property assignments.
    With ws.Range(ws.Cells(2, 1), ws.Cells(2, AN_UPLINK_PORT))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Interior.Color = RGB(221, 235, 247)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Font.Italic = True
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .WrapText = True
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Font.Size = 8
    ' Finish the current With object block.
    ' [R7 LINE] Ends the current With block.
    End With
    ' Use this object as the target for the following dot-prefixed property assignments.
    ' [R7 LINE] Uses this object as the target for the following grouped property assignments.
    With ws.Range(ws.Cells(1, AN_UPLINK_PORT), ws.Cells(Application.Max(3, lastRow), AN_UPLINK_PORT))
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Interior.Color = RGB(255, 242, 204)
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Borders.LineStyle = xlContinuous
    ' Finish the current With object block.
    ' [R7 LINE] Ends the current With block.
    End With
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(1, AN_UPLINK_PORT).Interior.Color = RGB(191, 144, 0)
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Cells(1, AN_UPLINK_PORT).Font.Color = vbWhite

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If lastRow >= 3 Then
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Range(ws.Cells(3, 1), ws.Cells(lastRow, AN_UPLINK_PORT)).WrapText = True
    ' [R7 LINE] Ends the current conditional block.
    End If
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Columns("A:I").AutoFit
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For c = 1 To AN_UPLINK_PORT
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If ws.Columns(c).columnWidth < 18 Then ws.Columns(c).columnWidth = 18
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If ws.Columns(c).columnWidth > 42 Then ws.Columns(c).columnWidth = 42
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next c
    ' [R7 LINE] Calculates or updates ws.rows(2).RowHeight using the expression in this statement.
    ws.rows(2).RowHeight = 42
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Sub AN_StyleReportSheet; the following statements perform or calculate this named workflow.
Private Sub AN_StyleReportSheet(ByVal ws As Worksheet, ByVal columnsText As String)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim lastRow As Long, parts As Variant
    ' [R7 LINE] Calculates or updates parts using the expression in this statement.
    parts = Split(columnsText, ":")
    ' [R7 LINE] Calculates or updates LastRow using the expression in this statement.
    lastRow = AN_LastUsedRow(ws)
    ' Use this object as the target for the following dot-prefixed property assignments.
    ' [R7 LINE] Uses this object as the target for the following grouped property assignments.
    With ws.Range(CStr(parts(0)) & "1:" & CStr(parts(1)) & "1")
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Font.Bold = True
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Font.Color = vbWhite
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        .Interior.Color = RGB(31, 78, 121)
    ' Finish the current With object block.
    ' [R7 LINE] Ends the current With block.
    End With
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Columns(columnsText).AutoFit
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If lastRow > 1 Then
        ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
        ws.Range(CStr(parts(0)) & "2:" & CStr(parts(1)) & lastRow).VerticalAlignment = xlTop
    ' [R7 LINE] Ends the current conditional block.
    End If
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function AN_LastUsedRow; the following statements perform or calculate this named workflow.
Private Function AN_LastUsedRow(ByVal ws As Worksheet) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim f As Range
    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to f.
    Set f = ws.Cells.Find("*", , xlFormulas, xlPart, xlByRows, xlPrevious)
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If f Is Nothing Then AN_LastUsedRow = 1 Else AN_LastUsedRow = f.Row
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function AN_LastUsedCol; the following statements perform or calculate this named workflow.
Private Function AN_LastUsedCol(ByVal ws As Worksheet) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim f As Range
    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to f.
    Set f = ws.Cells.Find("*", , xlFormulas, xlPart, xlByColumns, xlPrevious)
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If f Is Nothing Then AN_LastUsedCol = 1 Else AN_LastUsedCol = f.Column
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

Public Function ONGEN_GenerationProtectionActive() As Boolean
    ONGEN_GenerationProtectionActive = mONGENProtectionActive
End Function

Public Function ONGEN_CountGeneratedSheets(ByVal categoryName As String) As Long
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ONGEN_IsGeneratedCategorySheet(ws.Name, categoryName) Then
            ONGEN_CountGeneratedSheets = ONGEN_CountGeneratedSheets + 1
        End If
    Next ws
End Function

Public Function ONGEN_WorksheetHasData(ByVal ws As Worksheet, _
                                       Optional ByVal headerRow As Long = 1) As Boolean
    Dim lastCell As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), _
                                 LookIn:=xlFormulas, LookAt:=xlPart, _
                                 SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                 MatchCase:=False)
    On Error GoTo 0
    If Not lastCell Is Nothing Then ONGEN_WorksheetHasData = (lastCell.Row > headerRow)
End Function

Public Function ONGEN_ProtectMissingOnlySheets(ByVal categoryName As String) As Object
    Dim backupMap As Object
    Dim namesToProtect As Collection
    Dim ws As Worksheet
    Dim item As Variant
    Dim originalName As String
    Dim temporaryName As String
    Dim serialNumber As Long

    Set backupMap = CreateObject("Scripting.Dictionary")
    backupMap.CompareMode = vbTextCompare
    Set namesToProtect = New Collection

    For Each ws In ThisWorkbook.Worksheets
        If ONGEN_IsGeneratedCategorySheet(ws.Name, categoryName) Then namesToProtect.Add ws.Name
    Next ws

    serialNumber = 1
    For Each item In namesToProtect
        originalName = CStr(item)
        temporaryName = ONGEN_NextTemporarySheetName(serialNumber)
        With ThisWorkbook.Worksheets(originalName)
            backupMap.Add temporaryName, Array(originalName, CLng(.Visible))
            .Name = temporaryName
        End With
        serialNumber = serialNumber + 1
    Next item

    mONGENProtectionActive = (backupMap.count > 0)
    Set ONGEN_ProtectMissingOnlySheets = backupMap
End Function

Public Sub ONGEN_FinalizeMissingOnlyGeneration( _
           ByVal categoryName As String, _
           ByVal backupMap As Object, _
           ByVal generationSucceeded As Boolean)

    Dim key As Variant
    Dim info As Variant
    Dim i As Long
    Dim oldAlerts As Boolean
    Dim originalName As String
    Dim temporaryName As String

    oldAlerts = Application.DisplayAlerts
    On Error GoTo Cleanup
    Application.DisplayAlerts = False

    If Not generationSucceeded Then
        For i = ThisWorkbook.Worksheets.count To 1 Step -1
            If ONGEN_IsGeneratedCategorySheet(ThisWorkbook.Worksheets(i).Name, categoryName) Then
                ThisWorkbook.Worksheets(i).Delete
            End If
        Next i
    End If

    If Not backupMap Is Nothing Then
        For Each key In backupMap.keys
            temporaryName = CStr(key)
            info = backupMap(key)
            originalName = CStr(info(0))

            If generationSucceeded Then
                If ONGEN_WorksheetExists(originalName, ThisWorkbook) Then
                    ThisWorkbook.Worksheets(originalName).Delete
                End If
            End If

            If ONGEN_WorksheetExists(temporaryName, ThisWorkbook) Then
                With ThisWorkbook.Worksheets(temporaryName)
                    .Name = originalName
                    .Visible = CLng(info(1))
                End With
            End If
        Next key
    End If

Cleanup:
    mONGENProtectionActive = False
    Application.DisplayAlerts = oldAlerts
End Sub

Public Function ONGEN_IsGeneratedCategorySheet(ByVal sheetName As String, _
                                                ByVal categoryName As String) As Boolean
    Dim u As String
    u = UCase$(Trim$(sheetName))
    If Left$(u, 5) = "~OG25" Then Exit Function

    Select Case UCase$(Trim$(categoryName))
        Case ONGEN_CATEGORY_24V_PANEL
            If StrComp(sheetName, SH_24V, vbTextCompare) = 0 Then Exit Function
            ONGEN_IsGeneratedCategorySheet = _
                (Right$(u, 4) = "_24V" Or Left$(u, 4) = "24V_")

        Case ONGEN_CATEGORY_RAW_RCP
            ONGEN_IsGeneratedCategorySheet = _
                (Left$(u, 4) = "RCP-" Or Left$(u, 4) = "RCP ") And _
                (Right$(u, 4) <> "_24V") And _
                (Right$(u, 8) <> " - CLEAN")

        Case ONGEN_CATEGORY_CLEAN_RCP
            ONGEN_IsGeneratedCategorySheet = _
                (Right$(u, 8) = " - CLEAN" Or Right$(u, 6) = "_CLEAN")
    End Select
End Function

Private Function ONGEN_NextTemporarySheetName(ByVal startNumber As Long) As String
    Dim n As Long
    Dim candidate As String
    n = startNumber
    Do
        candidate = "~OG25" & Format$(n, "0000")
        If Not ONGEN_WorksheetExists(candidate, ThisWorkbook) Then
            ONGEN_NextTemporarySheetName = candidate
            Exit Function
        End If
        n = n + 1
    Loop
End Function

Private Function ONGEN_WorksheetExists(ByVal sheetName As String, _
                                       ByVal wb As Workbook) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0
    ONGEN_WorksheetExists = Not ws Is Nothing
End Function

