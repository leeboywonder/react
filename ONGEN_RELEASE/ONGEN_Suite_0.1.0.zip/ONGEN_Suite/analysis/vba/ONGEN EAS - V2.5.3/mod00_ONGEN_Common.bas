Attribute VB_Name = "mod00_ONGEN_Common"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod00_ONGEN_Common
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.2-INDUSTRIAL-FULL-RELEASE
' Module        : mod00_ONGEN_Common
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : V25.2 industrial generation-mode controller verified.
' Notes         : YES=overwrite, NO=generate missing only, CANCEL=no worksheet changes.
'-------------------------------------------------------------------------------


'-------------------------------------------------------------------------------
' FULLY COMMENTED MAINTENANCE RELEASE
' Documentation Release : ONGEN V16.2-R2-COMMENTED
' Baseline              : ONGEN V16.2-R1 executable logic
' Functional Changes    : None - original VBA statements are preserved
' Commenting Method     : One explanation per logical VBA statement
' Continuation Rule     : Statements joined with _ receive one group comment
' Author/Owner          : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

' [LINE EXPLANATION] Requires every variable in this module to be declared before use, reducing spelling and type-related bugs.
Option Explicit

'-------------------------------------------------------------------------------
' V25.1 INDUSTRIAL GENERATION CONTROL
'-------------------------------------------------------------------------------
Public Const ONGEN_GEN_CANCEL As Long = 0
Public Const ONGEN_GEN_OVERWRITE As Long = 1
Public Const ONGEN_GEN_MISSING_ONLY As Long = 2

Public Const ONGEN_CATEGORY_24V_PANEL As String = "24V_PANEL"
Public Const ONGEN_CATEGORY_RAW_RCP As String = "RAW_RCP"
Public Const ONGEN_CATEGORY_CLEAN_RCP As String = "CLEAN_RCP"

Private mONGENGenerationMode As Long

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R1
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-12
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------
' Author     : Lee Pierre

' [LINE EXPLANATION] Defines SH_MAIN as a String constant with value "MAIN". Edit this line to change sheet main globally.
Public Const SH_MAIN As String = "MAIN"
' [LINE EXPLANATION] Defines SH_IO_INPUT as a String constant with value "IO_DEVICE_LIST". Edit this line to change sheet IO input globally.
Public Const SH_IO_INPUT As String = "IO_DEVICE_LIST"
' [LINE EXPLANATION] Defines SH_IO_GEN as a String constant with value "IO_BLOCK_GENERATOR". Edit this line to change sheet IO gen globally.
Public Const SH_IO_GEN As String = "IO_BLOCK_GENERATOR"
' [LINE EXPLANATION] Defines SH_PD6 as a String constant with value "PD6_IMPORT". Edit this line to change sheet pd 6 globally.
Public Const SH_PD6 As String = "PD6_IMPORT"
' [LINE EXPLANATION] Defines SH_24V as a String constant with value "24v_Power Generator". Edit this line to change sheet 24 v globally.
Public Const SH_24V As String = "24v_Power Generator"
' [LINE EXPLANATION] Defines SH_480V as a String constant with value "VFD_480V_Generator". Edit this line to change sheet 480 v globally.
Public Const SH_480V As String = "VFD_480V_Generator"
' [LINE EXPLANATION] Defines SH_DATA_IO as a String constant with value "DATA_IO_BLOCK". Edit this line to change sheet data IO globally.
Public Const SH_DATA_IO As String = "DATA_IO_BLOCK"
' [LINE EXPLANATION] Defines SH_DATA_PWR as a String constant with value "DATA_POWER". Edit this line to change sheet data pwr globally.
Public Const SH_DATA_PWR As String = "DATA_POWER"
' [LINE EXPLANATION] Defines SH_VALIDATION as a String constant with value "VALIDATION". Edit this line to change sheet validation globally.
Public Const SH_VALIDATION As String = "VALIDATION"
' [LINE EXPLANATION] Defines SH_LOG as a String constant with value "EXPORT_LOG". Edit this line to change sheet log globally.
Public Const SH_LOG As String = "EXPORT_LOG"

'-------------------------------------------------------------------------------
' Procedure : Step00_Create_Control_Buttons
' Scope/Type: Public Sub
' Purpose   : Creates control buttons.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Step00_Create_Control_Buttons. Creates control buttons.
Public Sub Step00_Create_Control_Buttons()
    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for btn (Object).
    Dim btn As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for macroNames (Variant).
    Dim macroNames As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for macroText (Variant).
    Dim macroText As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for topPos (Double).
    Dim topPos As Double
    ' [LINE EXPLANATION] Declares procedure-level storage for leftPos (Double).
    Dim leftPos As Double
    ' [LINE EXPLANATION] Declares procedure-level storage for h (Double).
    Dim h As Double
    ' [LINE EXPLANATION] Declares procedure-level storage for w (Double).
    Dim w As Double

    ' [LINE EXPLANATION] Stores the object returned by EnsureSheet(SH_MAIN) in ws.
    Set ws = EnsureSheet(SH_MAIN)

    ' [LINE EXPLANATION] Temporarily suppresses runtime errors so the next optional or cleanup operation can be attempted safely; Err should be checked or normal handling restored afterward.
    On Error Resume Next
    ' [LINE EXPLANATION] Calls the Buttons member of ws with .Delete.
    ws.Buttons.Delete
    ' [LINE EXPLANATION] Turns off the temporary error handler and restores normal VBA error behavior.
    On Error GoTo 0

    ' [LINE EXPLANATION] Sets macroNames to Array( "Step01_Import_ONGEN_Generated_IO", "Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST",.... This logical statement spans 12 physical lines.
    macroNames = Array( _
        "Step01_Import_ONGEN_Generated_IO", _
        "Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST", _
        "Step03_Refresh_IO_BLOCK_DATA_Formulas", _
        "Step04_Export_Beckhoff_ONGEN_Input", _
        "Step05_Import_SIS_TAG_PD6_From_PD_Workbook", _
        "Step06_Refresh_24V_Power_Formulas_From_DATA", _
        "Step07_Build_24V_Power_Generator_From_PD6", _
        "Step08_Build_480V_VFD_Generator_From_PD6", _
        "Step09_Export_SNR_24V_Input", _
        "Step10_Validate_Workbook", _
        "Step99_Clear_Generated_Data")

    ' [LINE EXPLANATION] Sets macroText to Array( "01 Import ONGEN IO", "02 Build IO Block", "03 Refresh IO Formulas", "04 Export Beckhoff",.... This logical statement spans 12 physical lines.
    macroText = Array( _
        "01 Import ONGEN IO", _
        "02 Build IO Block", _
        "03 Refresh IO Formulas", _
        "04 Export Beckhoff", _
        "05 Import PD6", _
        "06 Refresh 24V Formulas", _
        "07 Build 24V", _
        "08 Build 480V VFD", _
        "09 Export 24V", _
        "10 Validate", _
        "99 Clear")

    ' [LINE EXPLANATION] Sets leftPos to ws.Range("J4").Left.
    leftPos = ws.Range("J4").Left
    ' [LINE EXPLANATION] Sets topPos to ws.Range("J4").Top.
    topPos = ws.Range("J4").Top
    ' [LINE EXPLANATION] Sets w to 190.
    w = 190
    ' [LINE EXPLANATION] Sets h to 24.
    h = 24

    ' [LINE EXPLANATION] Loops i from LBound(macroNames) through UBound(macroNames).
    For i = LBound(macroNames) To UBound(macroNames)
        ' [LINE EXPLANATION] Stores the object returned by ws.Buttons.Add(leftPos, topPos + (i * (h + 4)), w, h) in btn.
        Set btn = ws.Buttons.Add(leftPos, topPos + (i * (h + 4)), w, h)
        ' [LINE EXPLANATION] Sets btn.OnAction to CStr(macroNames(i)).
        btn.OnAction = CStr(macroNames(i))
        ' [LINE EXPLANATION] Sets btn.caption to CStr(macroText(i)).
        btn.caption = CStr(macroText(i))
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i

    ' [LINE EXPLANATION] Writes "Workflow Buttons" into ws.Range("J3").value.
    ws.Range("J3").value = "Workflow Buttons"
    ' [LINE EXPLANATION] Writes True into worksheet location ws.Range("J3").Font.Bold.
    ws.Range("J3").Font.Bold = True
    ' [LINE EXPLANATION] Sets ws.Columns("J:J").ColumnWidth to 28.
    ws.Columns("J:J").columnWidth = 28
    ' [LINE EXPLANATION] Calls AppendLog, which appends log, using the supplied argument values.
    AppendLog "Step00_Create_Control_Buttons", "OK", "Buttons created on MAIN sheet."
    ' [LINE EXPLANATION] Displays a message box to the user using "Workflow buttons were created on the MAIN sheet.", vbInformation.
    MsgBox "Workflow buttons were created on the MAIN sheet.", vbInformation
' [LINE EXPLANATION] Ends procedure Step00_Create_Control_Buttons.
End Sub

'-------------------------------------------------------------------------------
' Procedure : WorksheetExists
' Scope/Type: Public Function
' Purpose   : Calculates or returns worksheet exists.
' Parameters:
' sheetName (String) - Supplies sheet name.
' wb (Workbook) - Supplies workbook.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function WorksheetExists. Calculates or returns worksheet exists.
Public Function WorksheetExists(ByVal sheetName As String, Optional ByVal wb As Workbook) As Boolean
    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] When wb Is Nothing is true, executes the inline action Set wb = ThisWorkbook.
    If wb Is Nothing Then Set wb = ThisWorkbook
    ' [LINE EXPLANATION] Temporarily suppresses runtime errors so the next optional or cleanup operation can be attempted safely; Err should be checked or normal handling restored afterward.
    On Error Resume Next
    ' [LINE EXPLANATION] Stores the object returned by wb.Worksheets(sheetName) in ws.
    Set ws = wb.Worksheets(sheetName)
    ' [LINE EXPLANATION] Sets the return value of WorksheetExists to Not ws Is Nothing.
    WorksheetExists = Not ws Is Nothing
    ' [LINE EXPLANATION] Turns off the temporary error handler and restores normal VBA error behavior.
    On Error GoTo 0
' [LINE EXPLANATION] Ends function WorksheetExists.
End Function

'-------------------------------------------------------------------------------
' Procedure : EnsureSheet
' Scope/Type: Public Function
' Purpose   : Ensures sheet.
' Parameters:
' sheetName (String) - Supplies sheet name.
' wb (Workbook) - Supplies workbook.
' Returns   : Worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function EnsureSheet. Ensures sheet.
Public Function EnsureSheet(ByVal sheetName As String, Optional ByVal wb As Workbook) As Worksheet
    ' [LINE EXPLANATION] When wb Is Nothing is true, executes the inline action Set wb = ThisWorkbook.
    If wb Is Nothing Then Set wb = ThisWorkbook
    ' [LINE EXPLANATION] Starts a conditional block that runs when WorksheetExists(sheetName, wb) is true.
    If WorksheetExists(sheetName, wb) Then
        ' [LINE EXPLANATION] Stores the object returned by wb.Worksheets(sheetName) in EnsureSheet.
        Set EnsureSheet = wb.Worksheets(sheetName)
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Stores the object returned by wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count)) in EnsureSheet.
        Set EnsureSheet = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ' [LINE EXPLANATION] Sets EnsureSheet.name to sheetName.
        EnsureSheet.Name = sheetName
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
' [LINE EXPLANATION] Ends function EnsureSheet.
End Function

'-------------------------------------------------------------------------------
' Procedure : GetSheetIfExists
' Scope/Type: Public Function
' Purpose   : Returns sheet if exists.
' Parameters:
' sheetName (String) - Supplies sheet name.
' wb (Workbook) - Supplies workbook.
' Returns   : Worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetSheetIfExists. Returns sheet if exists.
Public Function GetSheetIfExists(ByVal sheetName As String, Optional ByVal wb As Workbook) As Worksheet
    ' [LINE EXPLANATION] When wb Is Nothing is true, executes the inline action Set wb = ThisWorkbook.
    If wb Is Nothing Then Set wb = ThisWorkbook
    ' [LINE EXPLANATION] When WorksheetExists(sheetName, wb) is true, executes the inline action Set GetSheetIfExists = wb.Worksheets(sheetName).
    If WorksheetExists(sheetName, wb) Then Set GetSheetIfExists = wb.Worksheets(sheetName)
' [LINE EXPLANATION] Ends function GetSheetIfExists.
End Function

'-------------------------------------------------------------------------------
' Procedure : LastUsedRow
' Scope/Type: Public Function
' Purpose   : Returns the last used row.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function LastUsedRow. Returns the last used row.
Public Function LastUsedRow(ByVal ws As Worksheet) As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for f (Range).
    Dim f As Range
    ' [LINE EXPLANATION] Temporarily suppresses runtime errors so the next optional or cleanup operation can be attempted safely; Err should be checked or normal handling restored afterward.
    On Error Resume Next
    ' [LINE EXPLANATION] Stores the object returned by ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious) in f.
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    ' [LINE EXPLANATION] Turns off the temporary error handler and restores normal VBA error behavior.
    On Error GoTo 0
    ' [LINE EXPLANATION] Starts a conditional block that runs when f Is Nothing is true.
    If f Is Nothing Then
        ' [LINE EXPLANATION] Sets the return value of LastUsedRow to 1.
        LastUsedRow = 1
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of LastUsedRow to f.Row.
        LastUsedRow = f.Row
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
' [LINE EXPLANATION] Ends function LastUsedRow.
End Function

'-------------------------------------------------------------------------------
' Procedure : LastUsedCol
' Scope/Type: Public Function
' Purpose   : Returns the last used column.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' headerRow (Long) - Supplies header row; default = 1.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function LastUsedCol. Returns the last used column.
Public Function LastUsedCol(ByVal ws As Worksheet, Optional ByVal headerRow As Long = 1) As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for f (Range).
    Dim f As Range
    ' [LINE EXPLANATION] Temporarily suppresses runtime errors so the next optional or cleanup operation can be attempted safely; Err should be checked or normal handling restored afterward.
    On Error Resume Next
    ' [LINE EXPLANATION] Stores the object returned by ws.rows(headerRow).Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPr... in f.
    Set f = ws.rows(headerRow).Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    ' [LINE EXPLANATION] Turns off the temporary error handler and restores normal VBA error behavior.
    On Error GoTo 0
    ' [LINE EXPLANATION] Starts a conditional block that runs when f Is Nothing is true.
    If f Is Nothing Then
        ' [LINE EXPLANATION] Sets the return value of LastUsedCol to 1.
        LastUsedCol = 1
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of LastUsedCol to f.Column.
        LastUsedCol = f.Column
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
' [LINE EXPLANATION] Ends function LastUsedCol.
End Function

'-------------------------------------------------------------------------------
' Procedure : NormalizeHeader
' Scope/Type: Public Function
' Purpose   : Normalizes header.
' Parameters:
' valueIn (Variant) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function NormalizeHeader. Normalizes header.
Public Function NormalizeHeader(ByVal valueIn As Variant) As String
    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String
    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "_", "").
    s = Replace(s, "_", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "-", "").
    s = Replace(s, "-", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ".", "").
    s = Replace(s, ".", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "#", "").
    s = Replace(s, "#", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "(", "").
    s = Replace(s, "(", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ")", "").
    s = Replace(s, ")", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "/", "").
    s = Replace(s, "/", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "\", "").
    s = Replace(s, "\", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "[", "").
    s = Replace(s, "[", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "]", "").
    s = Replace(s, "]", "")
    ' [LINE EXPLANATION] Sets the return value of NormalizeHeader to s.
    NormalizeHeader = s
' [LINE EXPLANATION] Ends function NormalizeHeader.
End Function

'-------------------------------------------------------------------------------
' Procedure : HeaderCol
' Scope/Type: Public Function
' Purpose   : Calculates or returns header column.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' aliases() (Variant) - Supplies aliases.
' Returns   : Variant) As Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function HeaderCol. Calculates or returns header column.
Public Function HeaderCol(ByVal ws As Worksheet, ParamArray aliases() As Variant) As Long
    ' [LINE EXPLANATION] Sets the return value of HeaderCol to HeaderColFromArray(ws, aliases).
    HeaderCol = HeaderColFromArray(ws, aliases)
' [LINE EXPLANATION] Ends function HeaderCol.
End Function

'-------------------------------------------------------------------------------
' Procedure : HeaderColFromArray
' Scope/Type: Public Function
' Purpose   : Calculates or returns header column from array.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' aliases (Variant) - Supplies aliases.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function HeaderColFromArray. Calculates or returns header column from array.
Public Function HeaderColFromArray(ByVal ws As Worksheet, ByVal aliases As Variant) As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for c (Long).
    Dim c As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for testHeader (String).
    Dim testHeader As String
    ' [LINE EXPLANATION] Declares procedure-level storage for testAlias (String).
    Dim testAlias As String

    ' [LINE EXPLANATION] Sets the return value of HeaderColFromArray to 0.
    HeaderColFromArray = 0
    ' [LINE EXPLANATION] Sets lastCol to LastUsedCol(ws, 1).
    lastCol = LastUsedCol(ws, 1)

    ' [LINE EXPLANATION] Loops c from 1 through lastCol.
    For c = 1 To lastCol
        ' [LINE EXPLANATION] Sets testHeader to NormalizeHeader(ws.Cells(1, c).value).
        testHeader = NormalizeHeader(ws.Cells(1, c).value)
        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(testHeader) > 0 is true.
        If Len(testHeader) > 0 Then
            ' [LINE EXPLANATION] Loops i from LBound(aliases) through UBound(aliases).
            For i = LBound(aliases) To UBound(aliases)
                ' [LINE EXPLANATION] Sets testAlias to NormalizeHeader(CStr(aliases(i))).
                testAlias = NormalizeHeader(CStr(aliases(i)))
                ' [LINE EXPLANATION] Starts a conditional block that runs when testHeader = testAlias is true.
                If testHeader = testAlias Then
                    ' [LINE EXPLANATION] Sets the return value of HeaderColFromArray to c.
                    HeaderColFromArray = c
                    ' [LINE EXPLANATION] Returns immediately from HeaderColFromArray using its current return value.
                    Exit Function
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Advances the i loop to its next iteration.
            Next i
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the c loop to its next iteration.
    Next c
' [LINE EXPLANATION] Ends function HeaderColFromArray.
End Function

'-------------------------------------------------------------------------------
' Procedure : PickValue
' Scope/Type: Public Function
' Purpose   : Prompts the user to select value.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' rowNum (Long) - Supplies row number.
' aliases() (Variant) - Supplies aliases.
' Returns   : Variant) As String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function PickValue. Prompts the user to select value.
Public Function PickValue(ByVal ws As Worksheet, ByVal rowNum As Long, ParamArray aliases() As Variant) As String
    ' [LINE EXPLANATION] Sets the return value of PickValue to PickValueFromArray(ws, rowNum, aliases).
    PickValue = PickValueFromArray(ws, rowNum, aliases)
' [LINE EXPLANATION] Ends function PickValue.
End Function

'-------------------------------------------------------------------------------
' Procedure : PickValueFromArray
' Scope/Type: Public Function
' Purpose   : Prompts the user to select value from array.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' rowNum (Long) - Supplies row number.
' aliases (Variant) - Supplies aliases.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function PickValueFromArray. Prompts the user to select value from array.
Public Function PickValueFromArray(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal aliases As Variant) As String
    ' [LINE EXPLANATION] Declares procedure-level storage for c (Long).
    Dim c As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for v (String).
    Dim v As String
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long

    ' [LINE EXPLANATION] Sets the return value of PickValueFromArray to "".
    PickValueFromArray = ""
    ' [LINE EXPLANATION] Loops i from LBound(aliases) through UBound(aliases).
    For i = LBound(aliases) To UBound(aliases)
        ' [LINE EXPLANATION] Sets c to HeaderCol(ws, CStr(aliases(i))).
        c = HeaderCol(ws, CStr(aliases(i)))
        ' [LINE EXPLANATION] Starts a conditional block that runs when c > 0 is true.
        If c > 0 Then
            ' [LINE EXPLANATION] Sets v to Trim$(CStr(ws.Cells(rowNum, c).value)).
            v = Trim$(CStr(ws.Cells(rowNum, c).value))
            ' [LINE EXPLANATION] Starts a conditional block that runs when Len(v) > 0 is true.
            If Len(v) > 0 Then
                ' [LINE EXPLANATION] Sets the return value of PickValueFromArray to v.
                PickValueFromArray = v
                ' [LINE EXPLANATION] Returns immediately from PickValueFromArray using its current return value.
                Exit Function
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i
' [LINE EXPLANATION] Ends function PickValueFromArray.
End Function

'-------------------------------------------------------------------------------
' Procedure : FirstExistingSheet
' Scope/Type: Public Function
' Purpose   : Returns the first existing sheet.
' Parameters:
' wb (Workbook) - Supplies workbook.
' sheetNames (Variant) - Supplies sheet names.
' Returns   : Worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function FirstExistingSheet. Returns the first existing sheet.
Public Function FirstExistingSheet(ByVal wb As Workbook, ByVal sheetNames As Variant) As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Loops i from LBound(sheetNames) through UBound(sheetNames).
    For i = LBound(sheetNames) To UBound(sheetNames)
        ' [LINE EXPLANATION] Starts a conditional block that runs when WorksheetExists(CStr(sheetNames(i)), wb) is true.
        If WorksheetExists(CStr(sheetNames(i)), wb) Then
            ' [LINE EXPLANATION] Stores the object returned by wb.Worksheets(CStr(sheetNames(i))) in FirstExistingSheet.
            Set FirstExistingSheet = wb.Worksheets(CStr(sheetNames(i)))
            ' [LINE EXPLANATION] Returns immediately from FirstExistingSheet using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i
' [LINE EXPLANATION] Ends function FirstExistingSheet.
End Function

'-------------------------------------------------------------------------------
' Procedure : PickWorkbookFile
' Scope/Type: Public Function
' Purpose   : Prompts the user to select workbook file.
' Parameters:
' dialogTitle (String) - Supplies dialog title.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function PickWorkbookFile. Prompts the user to select workbook file.
Public Function PickWorkbookFile(ByVal dialogTitle As String) As String
    ' [LINE EXPLANATION] Declares procedure-level storage for fd (Object).
    Dim fd As Object
    ' [LINE EXPLANATION] Stores the object returned by Application.FileDialog(3) in fd.
    Set fd = Application.FileDialog(3)
    ' [LINE EXPLANATION] Starts a With block for fd, allowing nested lines to omit the repeated object reference.
    With fd
        ' [LINE EXPLANATION] Sets the Title property on the object named by the active With block.
        .title = dialogTitle
        ' [LINE EXPLANATION] Sets the AllowMultiSelect property on the object named by the active With block.
        .AllowMultiSelect = False
        ' [LINE EXPLANATION] Calls or accesses Filters on the object named by the active With block.
        .Filters.Clear
        ' [LINE EXPLANATION] Calls or accesses Filters on the object named by the active With block.
        .Filters.Add "Excel Workbooks", "*.xlsx;*.xlsm;*.xlsb;*.xls"
        ' [LINE EXPLANATION] Starts a conditional block that runs when .Show <> -1 is true.
        If .Show <> -1 Then
            ' [LINE EXPLANATION] Sets the return value of PickWorkbookFile to "".
            PickWorkbookFile = ""
        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
        Else
            ' [LINE EXPLANATION] Sets the return value of PickWorkbookFile to CStr(.SelectedItems(1)).
            PickWorkbookFile = CStr(.SelectedItems(1))
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current With block.
    End With
' [LINE EXPLANATION] Ends function PickWorkbookFile.
End Function

'-------------------------------------------------------------------------------
' Procedure : PickSaveAsPath
' Scope/Type: Public Function
' Purpose   : Prompts the user to select save as path.
' Parameters:
' dialogTitle (String) - Supplies dialog title.
' defaultName (String) - Supplies default name.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function PickSaveAsPath. Prompts the user to select save as path.
Public Function PickSaveAsPath(ByVal dialogTitle As String, ByVal defaultName As String) As String
    ' [LINE EXPLANATION] Declares procedure-level storage for v (Variant).
    Dim v As Variant
    ' [LINE EXPLANATION] Sets v to Application.GetSaveAsFilename(InitialFileName:=defaultName, FileFilter:="Excel Workbook (*.xlsx),....
    v = Application.GetSaveAsFilename(InitialFileName:=defaultName, FileFilter:="Excel Workbook (*.xlsx), *.xlsx", title:=dialogTitle)
    ' [LINE EXPLANATION] Starts a conditional block that runs when VarType(v) = vbBoolean is true.
    If VarType(v) = vbBoolean Then
        ' [LINE EXPLANATION] Sets the return value of PickSaveAsPath to "".
        PickSaveAsPath = ""
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of PickSaveAsPath to CStr(v).
        PickSaveAsPath = CStr(v)
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
' [LINE EXPLANATION] Ends function PickSaveAsPath.
End Function

'-------------------------------------------------------------------------------
' Procedure : AppendLog
' Scope/Type: Public Sub
' Purpose   : Appends log.
' Parameters:
' stepName (String) - Supplies step name.
' resultText (String) - Supplies result text.
' details (String) - Supplies details.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub AppendLog. Appends log.
Public Sub AppendLog(ByVal stepName As String, ByVal resultText As String, ByVal details As String)
    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Stores the object returned by EnsureSheet(SH_LOG) in ws.
    Set ws = EnsureSheet(SH_LOG)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(CStr(ws.Range("A1").value)) = 0 is true.
    If Len(CStr(ws.Range("A1").value)) = 0 Then
        ' [LINE EXPLANATION] Writes Array("Timestamp", "Step", "Result", "Details", "User") into ws.Range("A1:E1").value.
        ws.Range("A1:E1").value = Array("Timestamp", "Step", "Result", "Details", "User")
        ' [LINE EXPLANATION] Calls StyleHeader, which performs the style header workflow, using the supplied argument values.
        StyleHeader ws.Range("A1:E1")
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
    ' [LINE EXPLANATION] Sets r to LastUsedRow(ws) + 1.
    r = LastUsedRow(ws) + 1
    ' [LINE EXPLANATION] Writes Now into ws.Cells(r, 1).value.
    ws.Cells(r, 1).value = Now
    ' [LINE EXPLANATION] Writes stepName into ws.Cells(r, 2).value.
    ws.Cells(r, 2).value = stepName
    ' [LINE EXPLANATION] Writes resultText into ws.Cells(r, 3).value.
    ws.Cells(r, 3).value = resultText
    ' [LINE EXPLANATION] Writes details into ws.Cells(r, 4).value.
    ws.Cells(r, 4).value = details
    ' [LINE EXPLANATION] Writes Environ$("Username") into ws.Cells(r, 5).value.
    ws.Cells(r, 5).value = Environ$("Username")
    ' [LINE EXPLANATION] Calls the Columns member of ws with ("A:E").AutoFit.
    ws.Columns("A:E").AutoFit
' [LINE EXPLANATION] Ends procedure AppendLog.
End Sub

'-------------------------------------------------------------------------------
' Procedure : StyleHeader
' Scope/Type: Public Sub
' Purpose   : Performs the style header workflow.
' Parameters:
' rng (Range) - Supplies range.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub StyleHeader. Performs the style header workflow.
Public Sub StyleHeader(ByVal rng As Range)
    ' [LINE EXPLANATION] Starts a With block for rng, allowing nested lines to omit the repeated object reference.
    With rng
        ' [LINE EXPLANATION] Sets the Interior property on the object named by the active With block.
        .Interior.Color = RGB(31, 78, 121)
        ' [LINE EXPLANATION] Sets the Font property on the object named by the active With block.
        .Font.Color = RGB(255, 255, 255)
        ' [LINE EXPLANATION] Sets the Font property on the object named by the active With block.
        .Font.Bold = True
        ' [LINE EXPLANATION] Sets the HorizontalAlignment property on the object named by the active With block.
        .HorizontalAlignment = xlCenter
        ' [LINE EXPLANATION] Sets the VerticalAlignment property on the object named by the active With block.
        .VerticalAlignment = xlCenter
        ' [LINE EXPLANATION] Sets the WrapText property on the object named by the active With block.
        .WrapText = True
    ' [LINE EXPLANATION] Ends the current With block.
    End With
' [LINE EXPLANATION] Ends procedure StyleHeader.
End Sub

'-------------------------------------------------------------------------------
' Procedure : StyleSubHeader
' Scope/Type: Public Sub
' Purpose   : Performs the style sub header workflow.
' Parameters:
' rng (Range) - Supplies range.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub StyleSubHeader. Performs the style sub header workflow.
Public Sub StyleSubHeader(ByVal rng As Range)
    ' [LINE EXPLANATION] Starts a With block for rng, allowing nested lines to omit the repeated object reference.
    With rng
        ' [LINE EXPLANATION] Sets the Interior property on the object named by the active With block.
        .Interior.Color = RGB(226, 240, 217)
        ' [LINE EXPLANATION] Sets the Font property on the object named by the active With block.
        .Font.Bold = True
        ' [LINE EXPLANATION] Sets the HorizontalAlignment property on the object named by the active With block.
        .HorizontalAlignment = xlCenter
        ' [LINE EXPLANATION] Sets the VerticalAlignment property on the object named by the active With block.
        .VerticalAlignment = xlCenter
        ' [LINE EXPLANATION] Sets the WrapText property on the object named by the active With block.
        .WrapText = True
    ' [LINE EXPLANATION] Ends the current With block.
    End With
' [LINE EXPLANATION] Ends procedure StyleSubHeader.
End Sub

'-------------------------------------------------------------------------------
' Procedure : ResetApplicationState
' Scope/Type: Public Sub
' Purpose   : Resets application state.
' Parameters:
' turnOn (Boolean) - Supplies turn on; default = True.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub ResetApplicationState. Resets application state.
Public Sub ResetApplicationState(Optional ByVal turnOn As Boolean = True)
    ' [LINE EXPLANATION] Starts a conditional block that runs when turnOn is true.
    If turnOn Then
        ' [LINE EXPLANATION] Controls whether Excel redraws the screen during the operation to True.
        Application.ScreenUpdating = True
        ' [LINE EXPLANATION] Controls whether workbook and worksheet event procedures can run to True.
        Application.EnableEvents = True
        ' [LINE EXPLANATION] Sets Excel calculation mode for performance or formula refresh behavior to xlCalculationAutomatic.
        Application.Calculation = xlCalculationAutomatic
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Controls whether Excel redraws the screen during the operation to False.
        Application.ScreenUpdating = False
        ' [LINE EXPLANATION] Controls whether workbook and worksheet event procedures can run to False.
        Application.EnableEvents = False
        ' [LINE EXPLANATION] Sets Excel calculation mode for performance or formula refresh behavior to xlCalculationManual.
        Application.Calculation = xlCalculationManual
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
' [LINE EXPLANATION] Ends procedure ResetApplicationState.
End Sub

'-------------------------------------------------------------------------------
' Procedure : SheetHasHeader
' Scope/Type: Public Function
' Purpose   : Calculates or returns sheet has header.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' headerName (String) - Supplies header name.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function SheetHasHeader. Calculates or returns sheet has header.
Public Function SheetHasHeader(ByVal ws As Worksheet, ByVal headerName As String) As Boolean
    ' [LINE EXPLANATION] Sets the return value of SheetHasHeader to (HeaderCol(ws, headerName) > 0).
    SheetHasHeader = (HeaderCol(ws, headerName) > 0)
' [LINE EXPLANATION] Ends function SheetHasHeader.
End Function

'-------------------------------------------------------------------------------
' Procedure : SafeSheetName
' Scope/Type: Public Function
' Purpose   : Calculates or returns safe sheet name.
' Parameters:
' s (String) - Supplies s.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function SafeSheetName. Calculates or returns safe sheet name.
Public Function SafeSheetName(ByVal s As String) As String
    ' [LINE EXPLANATION] Declares procedure-level storage for bad (Variant).
    Dim bad As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Sets bad to Array("/", "\", "?", "*", "[", "]", ":").
    bad = Array("/", "\", "?", "*", "[", "]", ":")
    ' [LINE EXPLANATION] Loops i from LBound(bad) through UBound(bad).
    For i = LBound(bad) To UBound(bad)
        ' [LINE EXPLANATION] Sets s to Replace(s, CStr(bad(i)), "-").
        s = Replace(s, CStr(bad(i)), "-")
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i
    ' [LINE EXPLANATION] Sets s to Trim$(s).
    s = Trim$(s)
    ' [LINE EXPLANATION] When Len(s) = 0 is true, executes the inline action s = "Sheet1".
    If Len(s) = 0 Then s = "Sheet1"
    ' [LINE EXPLANATION] When Len(s) > 31 is true, executes the inline action s = Left$(s, 31).
    If Len(s) > 31 Then s = Left$(s, 31)
    ' [LINE EXPLANATION] Sets the return value of SafeSheetName to s.
    SafeSheetName = s
' [LINE EXPLANATION] Ends function SafeSheetName.
End Function

'-------------------------------------------------------------------------------
' Procedure : GetMapValue
' Scope/Type: Public Function
' Purpose   : Returns map value.
' Parameters:
' mapObj (Object) - Supplies map obj.
' keyText (String) - Supplies key text.
' fallback (String) - Supplies fallback; default = "".
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetMapValue. Returns map value.
Public Function GetMapValue(ByVal mapObj As Object, ByVal keyText As String, Optional ByVal fallback As String = "") As String
    ' [LINE EXPLANATION] Sets keyText to UCase$(Trim$(keyText)).
    keyText = UCase$(Trim$(keyText))
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(keyText) = 0 is true.
    If Len(keyText) = 0 Then
        ' [LINE EXPLANATION] Sets the return value of GetMapValue to fallback.
        GetMapValue = fallback
    ' [LINE EXPLANATION] Tests the next alternative condition: mapObj.Exists(keyText).
    ElseIf mapObj.Exists(keyText) Then
        ' [LINE EXPLANATION] Sets the return value of GetMapValue to CStr(mapObj(keyText)).
        GetMapValue = CStr(mapObj(keyText))
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of GetMapValue to fallback.
        GetMapValue = fallback
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If
' [LINE EXPLANATION] Ends function GetMapValue.
End Function

'-------------------------------------------------------------------------------
' V25.1 INDUSTRIAL GENERATED-OUTPUT CONTROL
'-------------------------------------------------------------------------------
Public Function ONGEN_RequestGenerationModeForCategory( _
                ByVal stepTitle As String, _
                ByVal categoryName As String, _
                ByVal outputDescription As String) As Long

    Dim existingCount As Long
    existingCount = ONGEN_CountGeneratedSheets(categoryName)
    ONGEN_RequestGenerationModeForCategory = _
        ONGEN_RequestGenerationModeForCount(stepTitle, existingCount, outputDescription)
End Function

Public Function ONGEN_RequestGenerationModeForCount( _
                ByVal stepTitle As String, _
                ByVal existingCount As Long, _
                ByVal outputDescription As String) As Long

    Dim answer As VbMsgBoxResult

    If existingCount <= 0 Then
        mONGENGenerationMode = ONGEN_GEN_OVERWRITE
        ONGEN_RequestGenerationModeForCount = ONGEN_GEN_OVERWRITE
        Exit Function
    End If

    answer = MsgBox( _
        CStr(existingCount) & " existing " & outputDescription & " output(s) were found." & vbCrLf & vbCrLf & _
        "YES - Overwrite the existing generated output and rebuild it." & vbCrLf & _
        "NO - Preserve every existing generated output and create only missing output." & vbCrLf & _
        "CANCEL - Stop without changing generated worksheets.", _
        vbYesNoCancel + vbQuestion + vbDefaultButton2, stepTitle & " - Existing Output")

    Select Case answer
        Case vbYes: mONGENGenerationMode = ONGEN_GEN_OVERWRITE
        Case vbNo: mONGENGenerationMode = ONGEN_GEN_MISSING_ONLY
        Case Else: mONGENGenerationMode = ONGEN_GEN_CANCEL
    End Select

    ONGEN_RequestGenerationModeForCount = mONGENGenerationMode
End Function

Public Sub ONGEN_SetGenerationMode(ByVal generationMode As Long)
    mONGENGenerationMode = generationMode
End Sub

Public Function ONGEN_GetGenerationMode() As Long
    ONGEN_GetGenerationMode = mONGENGenerationMode
End Function

Public Sub ONGEN_ClearGenerationMode()
    mONGENGenerationMode = ONGEN_GEN_CANCEL
End Sub

