Attribute VB_Name = "mod08_Network_Cable_Collector"
Option Explicit

'===============================================================================
' ONGEN EAS - NETWORK WNET CABLE COLLECTOR
'
' Author : Lee Pierre
' Title  : Principal Electrical Engineer
'
' PURPOSE
' -------
' Build the permanent WNET cable-label records used by Step 15H and Step 17.
'
' AUTHORITATIVE NETWORK SOURCE
' ----------------------------
' ONLY the generated network Clean sheets are used:
'
'     RCP-101 - Clean
'     RCP-102 - Clean
'     ...
'
' Required Clean-sheet headers:
'
'     Switch Port
'     SIS Number
'     Control Tag
'     Device
'     TYPE
'     Block
'     Terminal (IN)
'     Terminal (OUT)
'
' IMPORTANT
' ---------
' The network device identity exported to CABLE_TAG_OUTPUT is the value in
' "SIS Number".  The raw RCP topology worksheet values such as:
'
'     IO_16_351_2230_K4
'
' are NOT exported as network device tags.  The Clean-sheet engineering tag:
'
'     16-351-2230-K4
'
' is used instead.
'
' ROUTE INTERPRETATION
' --------------------
' A populated "Switch Port" cell starts a new daisy-chain route.
'
' First cable on a port:
'     FROM = <RCP Panel> <Switch Port>
'     TO   = current row "SIS Number"
'
' Remaining cables on that same port:
'     FROM = previous row "SIS Number"
'     TO   = current row "SIS Number"
'
' Terminal mapping:
'     FROM TERMINAL = previous row "Terminal (OUT)"
'     TO TERMINAL   = current row "Terminal (IN)"
'
' CABLE-ID STABILITY
' ------------------
' The collector first searches CABLE_ID_REGISTRY for legacy/raw network keys.
' This allows existing WNET-#### numbers to remain attached to the same physical
' network route while the exported endpoint text is upgraded to the Clean-sheet
' SIS Number.
'
' If no historical registry key exists, the permanent cable core allocates a
' new WNET ID using the Clean-sheet physical route key.
'===============================================================================

Private Const WNET_OUTPUT_SHEET As String = "CABLE_TAG_OUTPUT"
Private Const WNET_REGISTRY_SHEET As String = "CABLE_ID_REGISTRY"

Private Const WNET_OUTPUT_HEADER_ROW As Long = 6
Private Const WNET_OUTPUT_FIRST_ROW As Long = 7

'Clean-sheet canonical headers.
Private Const HDR_SWITCH_PORT As String = "Switch Port"
Private Const HDR_SIS_NUMBER As String = "SIS Number"
Private Const HDR_CONTROL_TAG As String = "Control Tag"
Private Const HDR_DEVICE As String = "Device"
Private Const HDR_TYPE As String = "TYPE"
Private Const HDR_BLOCK As String = "Block"
Private Const HDR_TERMINAL_IN As String = "Terminal (IN)"
Private Const HDR_TERMINAL_OUT As String = "Terminal (OUT)"


'===============================================================================
' PUBLIC WORKFLOW ENTRY POINTS
'===============================================================================

Public Sub ONGEN_Network_Rebuild_WNET()
    'Standalone rebuild entry point.
    ONGEN_Network_Append_WNET_To_Output
End Sub


Public Sub ONGEN_Network_Append_WNET_To_Output()
    '---------------------------------------------------------------------------
    ' Called by the clean Step 15H workflow after the baseline combined label
    ' engine creates/refreshed CABLE_TAG_OUTPUT.
    '
    ' Existing WNET rows are removed and rebuilt exclusively from the RCP Clean
    ' worksheets.
    '---------------------------------------------------------------------------
    On Error GoTo FailHandler

    Dim oldScreen As Boolean
    Dim oldEvents As Boolean
    Dim oldCalc As XlCalculation
    Dim oldStatus As Variant

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    oldCalc = Application.Calculation
    oldStatus = Application.StatusBar

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "ONGEN: Rebuilding WNET from network Clean sheets..."

    Dim wsOut As Worksheet
    Set wsOut = WNET_GetSheet(WNET_OUTPUT_SHEET)

    If wsOut Is Nothing Then
        Err.Raise vbObjectError + 16601, _
                  "ONGEN_Network_Append_WNET_To_Output", _
                  "Worksheet '" & WNET_OUTPUT_SHEET & _
                  "' does not exist. Run Step 15H first."
    End If

    'Load the permanent cable registry before requesting any new IDs.
    ONGEN_CableID_BeginRun

    WNET_RemoveExistingOutputRows wsOut

    Dim ws As Worksheet
    Dim cleanSheetCount As Long
    Dim cableCount As Long

    For Each ws In ThisWorkbook.Worksheets
        If WNET_IsCleanNetworkSheet(ws) Then
            cleanSheetCount = cleanSheetCount + 1
            cableCount = cableCount + WNET_CollectCleanSheet(ws, wsOut)
        End If
    Next ws

    If cleanSheetCount = 0 Then
        Err.Raise vbObjectError + 16602, _
                  "ONGEN_Network_Append_WNET_To_Output", _
                  "No RCP network Clean sheets were found."
    End If

    wsOut.Range("B2").value = Now
    wsOut.Range("B2").NumberFormat = "yyyy-mm-dd hh:mm:ss"
    wsOut.Range("B3").Value2 = ThisWorkbook.Name
    wsOut.Range("B4").Value2 = _
        Application.Max(0, WNET_LastRow(wsOut) - WNET_OUTPUT_HEADER_ROW)

    Application.StatusBar = oldStatus
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    MsgBox _
        "WNET cable tags rebuilt from the network Clean sheets." & vbCrLf & vbCrLf & _
        "Clean sheets used: " & CStr(cleanSheetCount) & vbCrLf & _
        "Network cables written: " & Format$(cableCount, "#,##0") & vbCrLf & vbCrLf & _
        "Network endpoint tags now come from the 'SIS Number' column.", _
        vbInformation, _
        "ONGEN WNET Cable Tags"

    Exit Sub

FailHandler:
    Dim n As Long
    Dim d As String

    n = Err.Number
    d = Err.description

    On Error Resume Next
    Application.StatusBar = oldStatus
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    MsgBox _
        "WNET cable-tag generation failed." & vbCrLf & vbCrLf & _
        "Error " & CStr(n) & ": " & d, _
        vbCritical, _
        "ONGEN WNET Cable Tags"
End Sub


Public Sub ONGEN_DIAG_WNET_CABLE_TAGS()
    '---------------------------------------------------------------------------
    ' Diagnostic confirms that WNET is using the Clean network sheets rather
    ' than the raw RCP topology worksheets.
    '---------------------------------------------------------------------------
    Dim wsOut As Worksheet
    Set wsOut = WNET_GetSheet(WNET_OUTPUT_SHEET)

    Dim ws As Worksheet
    Dim cleanSheets As Long
    Dim cleanRows As Long
    Dim outputRows As Long

    For Each ws In ThisWorkbook.Worksheets
        If WNET_IsCleanNetworkSheet(ws) Then
            cleanSheets = cleanSheets + 1
            cleanRows = cleanRows + WNET_CountCleanCableRows(ws)
        End If
    Next ws

    If Not wsOut Is Nothing Then
        outputRows = WNET_CountOutputRows(wsOut)
    End If

    MsgBox _
        "WNET diagnostic" & vbCrLf & vbCrLf & _
        "Authoritative source: RCP-xxx - Clean" & vbCrLf & _
        "Endpoint field: SIS Number" & vbCrLf & vbCrLf & _
        "Clean sheets detected: " & CStr(cleanSheets) & vbCrLf & _
        "Clean network cable rows: " & CStr(cleanRows) & vbCrLf & _
        "WNET rows in CABLE_TAG_OUTPUT: " & CStr(outputRows), _
        vbInformation, _
        "ONGEN WNET Diagnostic"
End Sub


'===============================================================================
' CLEAN-SHEET COLLECTION
'===============================================================================

Private Function WNET_CollectCleanSheet( _
    ByVal ws As Worksheet, _
    ByVal wsOut As Worksheet) As Long

    Dim headerRow As Long
    headerRow = WNET_FindCleanHeaderRow(ws)

    If headerRow = 0 Then Exit Function

    Dim cPort As Long
    Dim cSIS As Long
    Dim cControl As Long
    Dim cDevice As Long
    Dim cType As Long
    Dim cBlock As Long
    Dim cTermIn As Long
    Dim cTermOut As Long

    cPort = WNET_FindHeader(ws, headerRow, HDR_SWITCH_PORT)
    cSIS = WNET_FindHeader(ws, headerRow, HDR_SIS_NUMBER)
    cControl = WNET_FindHeader(ws, headerRow, HDR_CONTROL_TAG)
    cDevice = WNET_FindHeader(ws, headerRow, HDR_DEVICE)
    cType = WNET_FindHeader(ws, headerRow, HDR_TYPE)
    cBlock = WNET_FindHeader(ws, headerRow, HDR_BLOCK)
    cTermIn = WNET_FindHeader(ws, headerRow, HDR_TERMINAL_IN)
    cTermOut = WNET_FindHeader(ws, headerRow, HDR_TERMINAL_OUT)

    If cPort = 0 Or cSIS = 0 Or cTermIn = 0 Or cTermOut = 0 Then
        Exit Function
    End If

    Dim panel As String
    panel = WNET_PanelFromCleanSheetName(ws.Name)

    If Len(panel) = 0 Then Exit Function

    Dim outRow As Long
    outRow = WNET_LastRow(wsOut) + 1
    If outRow < WNET_OUTPUT_FIRST_ROW Then outRow = WNET_OUTPUT_FIRST_ROW

    Dim lastRow As Long
    lastRow = WNET_LastRow(ws)

    Dim r As Long

    Dim portCell As String
    Dim activePort As String

    Dim currentSIS As String
    Dim previousSIS As String

    Dim currentIn As String
    Dim currentOut As String
    Dim previousOut As String

    Dim currentControl As String
    Dim currentDevice As String
    Dim currentType As String
    Dim currentBlock As String

    Dim fromEndpoint As String
    Dim toEndpoint As String
    Dim fromTerminal As String
    Dim toTerminal As String

    Dim areaVal As String
    Dim swgVal As String

    Dim cleanKey As String
    Dim cableID As String

    'These values are used only to find an already-issued WNET ID in the
    'permanent registry.  The exported endpoint text always remains SIS Number.
    Dim legacyFrom As String
    Dim legacyTo As String
    Dim legacyKey As String
    Dim alternateKey As String

    For r = headerRow + 1 To lastRow

        portCell = WNET_NormalizePort(WNET_CellText(ws, r, cPort))

        'A populated Switch Port begins a new physical route.
        If Len(portCell) > 0 Then
            activePort = portCell
            previousSIS = vbNullString
            previousOut = vbNullString
        End If

        currentSIS = WNET_CellText(ws, r, cSIS)

        'Rows without a current route or SIS identity are not network cables.
        If Len(activePort) > 0 And Len(currentSIS) > 0 Then

            currentIn = WNET_CellText(ws, r, cTermIn)
            currentOut = WNET_CellText(ws, r, cTermOut)
            currentControl = WNET_CellText(ws, r, cControl)
            currentDevice = WNET_CellText(ws, r, cDevice)
            currentType = WNET_CellText(ws, r, cType)
            currentBlock = WNET_CellText(ws, r, cBlock)

            areaVal = WNET_AreaFromSIS(currentSIS)
            swgVal = WNET_SwitchGroupFromSIS(currentSIS)

            If Len(previousSIS) = 0 Then
                'First cable leaving one CU2508 / network switch port.
                fromEndpoint = panel & " " & activePort
                fromTerminal = activePort

                legacyFrom = panel & " " & activePort

                'Reconstruct the raw-topology identity used by the previous
                'collector wherever possible so the already-issued WNET number
                'can be retained.
                legacyTo = WNET_LegacyRawIdentity( _
                    currentSIS, currentType, currentDevice)

                legacyKey = _
                    "NET|" & panel & "|" & activePort & "|" & _
                    legacyFrom & "|" & legacyTo

                'Older releases used <PANEL>-NSW01 for the switch endpoint and
                'sometimes already used the SIS identity on the destination.
                alternateKey = _
                    "NET|" & panel & "|" & activePort & "|" & _
                    panel & "-NSW01 " & activePort & "|" & currentSIS

            Else
                'Daisy-chain cable between two Clean-sheet SIS Number records.
                fromEndpoint = previousSIS
                fromTerminal = previousOut

                legacyFrom = WNET_LegacyRawIdentity(previousSIS)
                legacyTo = WNET_LegacyRawIdentity( _
                    currentSIS, currentType, currentDevice)

                legacyKey = _
                    "NET|" & panel & "|" & activePort & "|" & _
                    legacyFrom & "|" & legacyTo

                'Older releases may already contain a clean SIS-to-SIS key.
                alternateKey = _
                    "NET|" & panel & "|" & activePort & "|" & _
                    previousSIS & "|" & currentSIS
            End If

            toEndpoint = currentSIS
            toTerminal = currentIn

            'Canonical clean key used for any new cable allocation.
            cleanKey = _
                "NET|" & panel & "|" & activePort & "|" & _
                fromEndpoint & "|" & currentSIS

            cableID = WNET_ResolveStableCableID( _
                legacyKey, _
                alternateKey, _
                cleanKey)

            '-------------------------------------------------------------------
            ' CABLE_TAG_OUTPUT canonical row
            '-------------------------------------------------------------------
            wsOut.Cells(outRow, 1).Value2 = cableID
            wsOut.Cells(outRow, 2).Value2 = "NETWORK CABLE"
            wsOut.Cells(outRow, 3).Value2 = "NET"
            wsOut.Cells(outRow, 4).Value2 = panel
            wsOut.Cells(outRow, 5).Value2 = areaVal
            wsOut.Cells(outRow, 6).Value2 = panel
            wsOut.Cells(outRow, 7).Value2 = swgVal

            'From / To use the Clean sheet SIS Number identities.
            wsOut.Cells(outRow, 8).Value2 = fromEndpoint
            wsOut.Cells(outRow, 9).Value2 = fromTerminal
            wsOut.Cells(outRow, 10).Value2 = toEndpoint
            wsOut.Cells(outRow, 11).Value2 = toTerminal

            wsOut.Cells(outRow, 12).Value2 = "NETWORK ROUTE"
            wsOut.Cells(outRow, 13).Value2 = activePort
            wsOut.Cells(outRow, 14).Value2 = vbNullString

            wsOut.Cells(outRow, 15).Value2 = _
                "Industrial Ethernet route - Clean SIS Number"

            'Source Sheet intentionally records the authoritative Clean sheet.
            wsOut.Cells(outRow, 16).Value2 = ws.Name
            wsOut.Cells(outRow, 17).Value2 = _
                "OK - NETWORK CLEAN SIS"

            'Internal CABLE_TAG_OUTPUT note only. Step 17 release intentionally
            'does not export the Notes column.
            wsOut.Cells(outRow, 18).Value2 = _
                "Control Tag=" & currentControl & _
                " | Device=" & currentDevice & _
                " | Type=" & currentType & _
                " | Block=" & currentBlock

            wsOut.Cells(outRow, 19).Value2 = 1

            outRow = outRow + 1
            WNET_CollectCleanSheet = WNET_CollectCleanSheet + 1

            previousSIS = currentSIS
            previousOut = currentOut
        End If
    Next r
End Function


'===============================================================================
' PERMANENT WNET ID RESOLUTION
'===============================================================================

Private Function WNET_ResolveStableCableID( _
    ByVal legacyKey As String, _
    ByVal alternateKey As String, _
    ByVal cleanKey As String) As String

    '---------------------------------------------------------------------------
    ' Resolution order:
    '
    ' 1. Exact legacy/raw key from the previous RCP topology collector.
    ' 2. Older clean/SIS registry key.
    ' 3. Existing canonical Clean-sheet key.
    ' 4. Allocate a new permanent WNET ID through the shared cable-ID core.
    '
    ' This prevents a formatting/source correction from automatically causing a
    ' wholesale network cable renumber.
    '---------------------------------------------------------------------------
    Dim existingID As String

    existingID = WNET_FindRegistryCableID(legacyKey)
    If Len(existingID) > 0 Then
        WNET_ResolveStableCableID = existingID
        Exit Function
    End If

    existingID = WNET_FindRegistryCableID(alternateKey)
    If Len(existingID) > 0 Then
        WNET_ResolveStableCableID = existingID
        Exit Function
    End If

    existingID = WNET_FindRegistryCableID(cleanKey)
    If Len(existingID) > 0 Then
        WNET_ResolveStableCableID = existingID
        Exit Function
    End If

    WNET_ResolveStableCableID = _
        ONGEN_CableID_Get(cleanKey, vbNullString, "NET")
End Function


Private Function WNET_FindRegistryCableID(ByVal physicalKey As String) As String
    'Read-only lookup into CABLE_ID_REGISTRY.
    'The shared Cable-ID core remains the owner of all new ID allocation.
    physicalKey = Trim$(physicalKey)
    If Len(physicalKey) = 0 Then Exit Function

    Dim ws As Worksheet
    Set ws = WNET_GetSheet(WNET_REGISTRY_SHEET)
    If ws Is Nothing Then Exit Function

    Dim lastRow As Long
    lastRow = WNET_LastRow(ws)

    Dim r As Long
    Dim registryKey As String

    For r = 2 To lastRow
        registryKey = Trim$(CStr(ws.Cells(r, 1).Value2))

        If StrComp(registryKey, physicalKey, vbTextCompare) = 0 Then
            WNET_FindRegistryCableID = _
                Trim$(CStr(ws.Cells(r, 2).Value2))
            Exit Function
        End If
    Next r
End Function


Private Function WNET_LegacyRawIdentity( _
    ByVal sisNumber As String, _
    Optional ByVal deviceType As String = vbNullString, _
    Optional ByVal deviceName As String = vbNullString) As String

    '---------------------------------------------------------------------------
    ' Reconstructs the raw topology identity used by the previous collector.
    '
    ' Example:
    '     Clean SIS Number : 16-351-2230-K4
    '     Legacy raw value : IO_16_351_2230_K4
    '
    ' RCP internal hardware such as SWT/RACK is not converted to IO_ syntax.
    '---------------------------------------------------------------------------
    Dim sis As String
    Dim typ As String

    sis = Trim$(sisNumber)
    typ = UCase$(Trim$(deviceType))

    If Len(sis) = 0 Then Exit Function

    If typ = "SWT" Or typ = "RACK" Then
        WNET_LegacyRawIdentity = sis
        Exit Function
    End If

    If InStr(1, sis, "RCP-", vbTextCompare) > 0 Then
        WNET_LegacyRawIdentity = sis
        Exit Function
    End If

    WNET_LegacyRawIdentity = _
        "IO_" & Replace$(sis, "-", "_")
End Function


'===============================================================================
' CLEAN-SHEET IDENTIFICATION
'===============================================================================

Private Function WNET_IsCleanNetworkSheet(ByVal ws As Worksheet) As Boolean
    Dim panel As String

    panel = WNET_PanelFromCleanSheetName(ws.Name)
    If Len(panel) = 0 Then Exit Function

    Dim hr As Long
    hr = WNET_FindCleanHeaderRow(ws)

    If hr = 0 Then Exit Function

    WNET_IsCleanNetworkSheet = _
        (WNET_FindHeader(ws, hr, HDR_SWITCH_PORT) > 0 And _
         WNET_FindHeader(ws, hr, HDR_SIS_NUMBER) > 0 And _
         WNET_FindHeader(ws, hr, HDR_TERMINAL_IN) > 0 And _
         WNET_FindHeader(ws, hr, HDR_TERMINAL_OUT) > 0)
End Function


Private Function WNET_PanelFromCleanSheetName( _
    ByVal sheetName As String) As String

    Dim s As String
    Dim u As String

    s = Trim$(sheetName)
    u = UCase$(s)

    If Right$(u, 8) = " - CLEAN" Then
        s = Trim$(Left$(s, Len(s) - 8))
    ElseIf Right$(u, 6) = "_CLEAN" Then
        s = Trim$(Left$(s, Len(s) - 6))
    Else
        Exit Function
    End If

    If WNET_IsRCPPanelName(s) Then
        WNET_PanelFromCleanSheetName = s
    End If
End Function


Private Function WNET_IsRCPPanelName(ByVal panelName As String) As Boolean
    Dim s As String
    Dim suffix As String

    s = UCase$(Trim$(panelName))

    If Left$(s, 4) <> "RCP-" Then Exit Function

    suffix = mid$(s, 5)

    WNET_IsRCPPanelName = _
        (Len(suffix) > 0 And IsNumeric(suffix))
End Function


Private Function WNET_FindCleanHeaderRow(ByVal ws As Worksheet) As Long
    Dim r As Long

    For r = 1 To Application.Min(10, WNET_LastRow(ws))
        If WNET_FindHeader(ws, r, HDR_SWITCH_PORT) > 0 And _
           WNET_FindHeader(ws, r, HDR_SIS_NUMBER) > 0 Then

            WNET_FindCleanHeaderRow = r
            Exit Function
        End If
    Next r
End Function


Private Function WNET_FindHeader( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal headerText As String) As Long

    If headerRow <= 0 Then Exit Function

    Dim lastCol As Long
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column

    Dim c As Long

    For c = 1 To lastCol
        If StrComp( _
            Trim$(CStr(ws.Cells(headerRow, c).Value2)), _
            headerText, _
            vbTextCompare) = 0 Then

            WNET_FindHeader = c
            Exit Function
        End If
    Next c
End Function


'===============================================================================
' SIS / PORT PARSING
'===============================================================================

Private Function WNET_NormalizePort(ByVal value As String) As String
    Dim s As String
    Dim numberText As String
    Dim portNumber As Long

    s = UCase$(Trim$(value))

    If Len(s) < 2 Or Len(s) > 3 Then Exit Function
    If Left$(s, 1) <> "X" Then Exit Function

    numberText = mid$(s, 2)
    If Not IsNumeric(numberText) Then Exit Function

    portNumber = CLng(numberText)

    If portNumber < 1 Or portNumber > 9 Then Exit Function

    WNET_NormalizePort = _
        "X" & Format$(portNumber, "00")
End Function


Private Function WNET_AreaFromSIS(ByVal sisNumber As String) As String
    'First numeric SIS token.
    Dim parts As Variant
    Dim p As Variant

    parts = Split(Trim$(sisNumber), "-")

    For Each p In parts
        If Len(Trim$(CStr(p))) > 0 Then
            If IsNumeric(Trim$(CStr(p))) Then
                WNET_AreaFromSIS = Trim$(CStr(p))
                Exit Function
            End If
        End If
    Next p
End Function


Private Function WNET_SwitchGroupFromSIS( _
    ByVal sisNumber As String) As String

    'The second numeric SIS token is the network/SWG grouping.
    '
    'Example:
    '     16-351-2230-K4
    '          ^^^
    '
    'RCP internal SIS values such as 16--RCP-204 contain only one leading
    'numeric token, so SwitchGroup remains blank.
    Dim parts As Variant
    Dim p As Variant
    Dim numericCount As Long
    Dim token As String

    parts = Split(Trim$(sisNumber), "-")

    For Each p In parts
        token = Trim$(CStr(p))

        If Len(token) > 0 And IsNumeric(token) Then
            numericCount = numericCount + 1

            If numericCount = 2 Then
                WNET_SwitchGroupFromSIS = token
                Exit Function
            End If
        End If
    Next p
End Function


'===============================================================================
' CABLE_TAG_OUTPUT MAINTENANCE
'===============================================================================

Private Sub WNET_RemoveExistingOutputRows(ByVal ws As Worksheet)
    Dim r As Long
    Dim labelID As String
    Dim typeCode As String

    For r = WNET_LastRow(ws) To WNET_OUTPUT_FIRST_ROW Step -1
        labelID = UCase$(Trim$(CStr(ws.Cells(r, 1).Value2)))
        typeCode = UCase$(Trim$(CStr(ws.Cells(r, 3).Value2)))

        If Left$(labelID, 5) = "WNET-" Or typeCode = "NET" Then
            ws.rows(r).Delete
        End If
    Next r
End Sub


Private Function WNET_CountCleanCableRows(ByVal ws As Worksheet) As Long
    Dim hr As Long
    hr = WNET_FindCleanHeaderRow(ws)

    If hr = 0 Then Exit Function

    Dim cPort As Long
    Dim cSIS As Long

    cPort = WNET_FindHeader(ws, hr, HDR_SWITCH_PORT)
    cSIS = WNET_FindHeader(ws, hr, HDR_SIS_NUMBER)

    If cPort = 0 Or cSIS = 0 Then Exit Function

    Dim activePort As String
    Dim r As Long

    For r = hr + 1 To WNET_LastRow(ws)
        If Len(WNET_NormalizePort(WNET_CellText(ws, r, cPort))) > 0 Then
            activePort = _
                WNET_NormalizePort(WNET_CellText(ws, r, cPort))
        End If

        If Len(activePort) > 0 And _
           Len(WNET_CellText(ws, r, cSIS)) > 0 Then

            WNET_CountCleanCableRows = _
                WNET_CountCleanCableRows + 1
        End If
    Next r
End Function


Private Function WNET_CountOutputRows(ByVal ws As Worksheet) As Long
    Dim r As Long
    Dim labelID As String

    For r = WNET_OUTPUT_FIRST_ROW To WNET_LastRow(ws)
        labelID = UCase$(Trim$(CStr(ws.Cells(r, 1).Value2)))

        If Left$(labelID, 5) = "WNET-" Then
            WNET_CountOutputRows = WNET_CountOutputRows + 1
        End If
    Next r
End Function


'===============================================================================
' GENERAL UTILITIES
'===============================================================================

Private Function WNET_CellText( _
    ByVal ws As Worksheet, _
    ByVal rowNumber As Long, _
    ByVal columnNumber As Long) As String

    If columnNumber <= 0 Then Exit Function

    If IsError(ws.Cells(rowNumber, columnNumber).Value2) Then
        Exit Function
    End If

    WNET_CellText = _
        Trim$(CStr(ws.Cells(rowNumber, columnNumber).Value2))
End Function


Private Function WNET_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set WNET_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function


Private Function WNET_LastRow(ByVal ws As Worksheet) As Long
    On Error GoTo SafeExit

    Dim f As Range

    Set f = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    If Not f Is Nothing Then
        WNET_LastRow = f.Row
    End If

    Exit Function

SafeExit:
    WNET_LastRow = 0
End Function
