Attribute VB_Name = "ONGEN_REPAIR_CURRENT_FEATURES"
Option Explicit

'===============================================================================
' ONGEN EAS V30 CURRENT FEATURE REPAIR
'
' Non-destructive repair for:
'   - missing Admin/User controls on MAIN
'   - missing setup/navigation controls
'   - missing Step 18 cleanup button
'   - missing READ ME worksheet
'   - missing / damaged CTRL_FUNCTION header row
'
' Existing project and engineering data are preserved.
'
' MAIN COMMAND:
'   ONGEN_REPAIR_CURRENT_FEATURES
'===============================================================================

Private Const MAIN_SHEET As String = "MAIN"
Private Const FUNCTION_SHEET As String = "CTRL_FUNCTION"
Private Const README_SHEET As String = "READ ME"

Public Sub ONGEN_REPAIR_CURRENT_FEATURES()
    On Error GoTo EH

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.EnableEvents = False

    'Run repair with workbook structure temporarily available.
    On Error Resume Next
    ThisWorkbook.Unprotect Password:="ONGEN-STRUCTURE-2026"
    ThisWorkbook.Worksheets(MAIN_SHEET).Unprotect Password:="ONGEN-STRUCTURE-2026"
    On Error GoTo EH

    ONGEN_REPAIR_FUNCTION_HEADERS
    ONGEN_REPAIR_READ_ME
    ONGEN_REPAIR_MAIN_CURRENT_BUTTONS

    'Return to safe User Mode when finished.
    ONGEN_APPLY_STARTUP_SECURITY

    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN current-feature repair is complete." & vbCrLf & vbCrLf & _
           "Repaired:" & vbCrLf & _
           "  - User/Admin security controls" & vbCrLf & _
           "  - Setup/navigation buttons" & vbCrLf & _
           "  - Step 18 cleanup button" & vbCrLf & _
           "  - READ ME worksheet" & vbCrLf & _
           "  - CTRL_FUNCTION production headers" & vbCrLf & vbCrLf & _
           "Admin password: zayden", _
           vbInformation, "ONGEN V30 Repair"
    Exit Sub

EH:
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN current-feature repair stopped." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN V30 Repair"
End Sub

'===============================================================================
' CTRL_FUNCTION HEADERS
'
' The current AutoCAD/PD data contract uses five part/manufacturer pairs.
' This routine repairs ONLY the recognized production header contract and does
' not overwrite existing function data below row 1.
'===============================================================================

Public Sub ONGEN_REPAIR_FUNCTION_HEADERS()
    Dim ws As Worksheet
    Set ws = ONGEN_GetOrCreateSheet(FUNCTION_SHEET)

    Dim headers As Variant
    headers = Array( _
        "CONTROL_FUNCTION_NUMBER", _
        "TYPE", _
        "BLOCK", _
        "NOTE", _
        "conveyor Type", _
        "PART_NUM_1", _
        "MANUF_NAME_1", _
        "PART_NUM_2", _
        "MANUF_NAME_2", _
        "PART_NUM_3", _
        "MANUF_NAME_3", _
        "PART_NUM_4", _
        "MANUF_NAME_4", _
        "PART_NUM_5", _
        "MANUF_NAME_5" _
    )

    Dim i As Long
    For i = LBound(headers) To UBound(headers)
        ws.Cells(1, i + 1).value = CStr(headers(i))
    Next i

    With ws.Range("A1:O1")
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(31, 78, 121)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With

    ws.rows(1).RowHeight = 30
    ws.Columns("A:O").AutoFit

    'Keep text-heavy fields at reasonable widths.
    If ws.Columns("C").columnWidth < 22 Then ws.Columns("C").columnWidth = 22
    If ws.Columns("D").columnWidth < 20 Then ws.Columns("D").columnWidth = 20
    If ws.Columns("E").columnWidth < 22 Then ws.Columns("E").columnWidth = 22
End Sub

'===============================================================================
' READ ME
'===============================================================================

Public Sub ONGEN_REPAIR_READ_ME()
    Dim ws As Worksheet
    Set ws = ONGEN_GetOrCreateSheet(README_SHEET)

    ws.Cells.Clear

    ws.Range("A1").value = "ONGEN Engineering Automation Suite - Administrator / User Guide"
    ws.Range("A3").value = "USER MODE"
    ws.Range("A4").value = "Engineering worksheet data remains editable."
    ws.Range("A5").value = "Workbook structure and MAIN dashboard objects are protected."
    ws.Range("A6").value = "Admin-only setup/library worksheets are hidden using normal Excel Hidden."

    ws.Range("A8").value = "ADMIN MODE"
    ws.Range("A9").value = "Use ADMIN LOGIN on MAIN."
    ws.Range("A10").value = "Initial administrator password: zayden"
    ws.Range("A11").value = "Use CHANGE ADMIN PASSWORD after entering Admin Mode."
    ws.Range("A12").value = "Admin Mode reveals setup/library worksheets and structural controls."

    ws.Range("A14").value = "ADMIN-ONLY WORKSHEETS"
    ws.Range("A15").value = "VFD_DWG_CONFIG"
    ws.Range("A16").value = "VFD_DWG_DEVICE_LIBRARY"
    ws.Range("A17").value = "VFD_DWG_DEVICE_PLACEMENT"
    ws.Range("A18").value = "VFD_DWG_ATTRIBUTE_MAP"
    ws.Range("A19").value = "VFD_DWG_SEED_LIBRARY"
    ws.Range("A20").value = "CTRL_FUNCTION"
    ws.Range("A21").value = "DATA_POWER"
    ws.Range("A22").value = "DATA_IO_BLOCK"
    ws.Range("A23").value = "READ ME"

    ws.Range("A25").value = "RECOVERY COMMAND"
    ws.Range("A26").value = "ONGEN_REPAIR_CURRENT_FEATURES"

    With ws.Range("A1:F1")
        .Merge
        .Font.Bold = True
        .Font.Size = 16
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(31, 78, 121)
    End With

    ws.Range("A3:A3,A8:A8,A14:A14,A25:A25").Font.Bold = True
    ws.Range("A3:A3,A8:A8,A14:A14,A25:A25").Interior.Color = RGB(217, 225, 242)
    ws.Columns("A").columnWidth = 75
    ws.rows("1:30").RowHeight = 20
End Sub

'===============================================================================
' MAIN BUTTON REPAIR
'===============================================================================

Public Sub ONGEN_REPAIR_MAIN_CURRENT_BUTTONS()
    Dim ws As Worksheet
    Set ws = ONGEN_GetOrCreateSheet(MAIN_SHEET)

    'Remove only repair/security shapes created by this module.
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_PANEL"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_TITLE"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_ADMIN_LOGIN"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_ADMIN_LOGOUT"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_CHANGE_PASSWORD"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_REPAIR_FEATURES"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_RELOAD_UI"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_VFD_SETUP"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_INSTALL_UI"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_NAVIGATOR"
    ONGEN_DeleteShapeIfExists ws, "ONGEN_SEC_STEP18"

    Dim leftX As Double
    Dim topY As Double
    Dim w As Double
    Dim h As Double
    Dim gap As Double

    leftX = 805
    topY = 18
    w = 205
    h = 28
    gap = 6

    ONGEN_AddPanel ws, leftX - 8, topY - 8, w + 16, 320, "ONGEN_SEC_PANEL"
    ONGEN_AddLabel ws, leftX, topY, w, 24, "ADMIN / RECOVERY", "ONGEN_SEC_TITLE"
    topY = topY + 32

    'Always visible.
    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "ADMIN LOGIN", "ONGEN_ADMIN_LOGIN", _
                    "ONGEN_SEC_ADMIN_LOGIN", False
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "0B WORKSHEET NAVIGATOR", "NAV_Open_Worksheet_Launcher", _
                    "ONGEN_SEC_NAVIGATOR", False
    topY = topY + h + gap

    'Admin-only.
    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "EXIT ADMIN MODE", "ONGEN_ADMIN_LOGOUT", _
                    "ONGEN_SEC_ADMIN_LOGOUT", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "CHANGE ADMIN PASSWORD", "ONGEN_ADMIN_CHANGE_PASSWORD", _
                    "ONGEN_SEC_CHANGE_PASSWORD", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "REPAIR CURRENT FEATURES", "ONGEN_REPAIR_CURRENT_FEATURES", _
                    "ONGEN_SEC_REPAIR_FEATURES", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "RELOAD MAIN / UI", "ONGEN_RELOAD_ALL_UI_BUTTONS", _
                    "ONGEN_SEC_RELOAD_UI", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "VFD SETUP", "ONGEN_VFD_SETUP", _
                    "ONGEN_SEC_VFD_SETUP", True
    topY = topY + h + gap

    ONGEN_AddButton ws, leftX, topY, w, h, _
                    "INSTALL / REPAIR UI", "ONGEN_EAS_INSTALL_UI", _
                    "ONGEN_SEC_INSTALL_UI", True

    'Production cleanup button remains available in User Mode.
    ONGEN_AddButton ws, leftX, 355, w, h, _
                    "18 CLEAR GENERATED DATA", "ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE", _
                    "ONGEN_SEC_STEP18", False

    'Apply current visibility immediately.
    ONGEN_APPLY_STARTUP_SECURITY
End Sub

Private Sub ONGEN_AddPanel(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, _
                           ByVal w As Double, ByVal h As Double, ByVal shapeName As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    shp.Name = shapeName
    shp.Fill.ForeColor.RGB = RGB(242, 242, 242)
    shp.Line.ForeColor.RGB = RGB(180, 180, 180)
    shp.Locked = True
End Sub

Private Sub ONGEN_AddLabel(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, _
                           ByVal w As Double, ByVal h As Double, ByVal caption As String, _
                           ByVal shapeName As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, x, y, w, h)
    shp.Name = shapeName
    shp.TextFrame2.TextRange.text = caption
    shp.TextFrame2.TextRange.Font.Bold = msoTrue
    shp.TextFrame2.TextRange.Font.Size = 12
    shp.Line.Visible = msoFalse
    shp.Fill.Visible = msoFalse
    shp.Locked = True
End Sub

Private Sub ONGEN_AddButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, _
                            ByVal w As Double, ByVal h As Double, ByVal caption As String, _
                            ByVal macroName As String, ByVal shapeName As String, _
                            ByVal adminOnly As Boolean)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)

    shp.Name = shapeName
    shp.TextFrame2.TextRange.text = caption
    shp.TextFrame2.TextRange.Font.Bold = msoTrue
    shp.TextFrame2.TextRange.Font.Size = 9
    shp.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle

    If adminOnly Then
        shp.Fill.ForeColor.RGB = RGB(192, 80, 77)
        shp.AlternativeText = "ONGEN_ROLE=ADMIN | ONGEN command: " & macroName
    Else
        shp.Fill.ForeColor.RGB = RGB(31, 78, 121)
        shp.AlternativeText = "ONGEN command: " & macroName
    End If

    shp.Line.ForeColor.RGB = RGB(255, 255, 255)
    shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
    shp.OnAction = "'" & ThisWorkbook.Name & "'!" & macroName
    shp.Locked = True
End Sub

Private Sub ONGEN_DeleteShapeIfExists(ByVal ws As Worksheet, ByVal shapeName As String)
    On Error Resume Next
    ws.Shapes(shapeName).Delete
    On Error GoTo 0
End Sub

Private Function ONGEN_GetOrCreateSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set ONGEN_GetOrCreateSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0

    If ONGEN_GetOrCreateSheet Is Nothing Then
        Set ONGEN_GetOrCreateSheet = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ONGEN_GetOrCreateSheet.Name = sheetName
    End If
End Function
