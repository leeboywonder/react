Attribute VB_Name = "Step05F_Backfill"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : Step05F_Backfill
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
Option Explicit

'===============================================================================
' ONGEN EAS V25.3.2
' OPTIONAL NETWORK CLEAN -> PD6 Kx BACKFILL
'
' Purpose:
'   Reads every worksheet whose name ends with " - Clean", extracts the
'   Control Tag value (K1, K4, K5, K11, etc.), matches the row to PD6_IMPORT,
'   and updates only PD6_IMPORT[Control_ID].
'
' Industrial safeguards:
'   - This workflow is independent from the normal ONGEN process flow.
'   - Existing PD6 values are not changed when a match is ambiguous.
'   - Network branch codes are resolved before generic SIS matching:
'       00 -> base SIS; 01..69 -> nnA; 70..73 -> SCN-1..SCN-4.
'   - SIS_Element_Number is intentionally not changed.
'   - Every action is written to NETWORK_KX_BACKFILL_AUDIT.
'   - The user must explicitly confirm before updates are committed.
'   - A separate installer creates an optional button on MAIN.
'===============================================================================

Private Const KX_PD6_SHEET As String = "PD6_IMPORT"
Private Const KX_MAIN_SHEET As String = "MAIN"
Private Const KX_AUDIT_SHEET As String = "NETWORK_KX_BACKFILL_AUDIT"
Private Const KX_CLEAN_SUFFIX As String = " - CLEAN"
Private Const KX_BUTTON_NAME As String = "btnStep05FNetworkKxBackfill"
Private Const KX_BUTTON_CAPTION As String = "05F Backfill Kx from Network Clean"

'-------------------------------------------------------------------------------
' Main optional workflow.
'-------------------------------------------------------------------------------
Public Sub Step05F_Backfill_Kx_From_Network_Clean()
    Dim wsPD6 As Worksheet
    Dim wsAudit As Worksheet
    Dim pd6Data As Variant
    Dim cleanData As Variant
    Dim updateRows As Object
    Dim updateTags As Object
    Dim updateSources As Object
    Dim panelRows As Object
    Dim ws As Worksheet
    Dim lastPD6Row As Long
    Dim lastCleanRow As Long
    Dim headerRow As Long
    Dim cSeq As Long
    Dim cArea As Long
    Dim cSWG As Long
    Dim cType As Long
    Dim cElement As Long
    Dim cControl As Long
    Dim cPanel As Long
    Dim cCleanSIS As Long
    Dim cCleanTag As Long
    Dim cCleanType As Long
    Dim r As Long
    Dim pd6Row As Long
    Dim tagValue As String
    Dim cleanSis As String
    Dim cleanType As String
    Dim panelName As String
    Dim resultCode As String
    Dim resultDetail As String
    Dim matchedCount As Long
    Dim unchangedCount As Long
    Dim unmatchedCount As Long
    Dim ambiguousCount As Long
    Dim invalidTagCount As Long
    Dim conflictCount As Long
    Dim cleanSheetCount As Long
    Dim candidateUpdates As Long
    Dim answer As VbMsgBoxResult
    Dim oldCalc As XlCalculation
    Dim oldScreen As Boolean
    Dim oldEvents As Boolean

    On Error GoTo ErrHandler

    Set wsPD6 = KX_GetSheet(ThisWorkbook, KX_PD6_SHEET)
    If wsPD6 Is Nothing Then
        Err.Raise vbObjectError + 5310, "Step05F_Backfill_Kx_From_Network_Clean", _
                  "Worksheet '" & KX_PD6_SHEET & "' was not found."
    End If

    headerRow = KX_FindHeaderRow(wsPD6, "SIS_SEQUENCE", 15)
    If headerRow = 0 Then
        Err.Raise vbObjectError + 5311, "Step05F_Backfill_Kx_From_Network_Clean", _
                  "PD6 header 'SIS_SEQUENCE' was not found."
    End If

    cSeq = KX_FindHeaderColumn(wsPD6, headerRow, Array("SIS_SEQUENCE", "SIS SEQUENCE"))
    cArea = KX_FindHeaderColumn(wsPD6, headerRow, Array("AREA_NUMBER", "AREA NUMBER", "AREA"))
    cSWG = KX_FindHeaderColumn(wsPD6, headerRow, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cType = KX_FindHeaderColumn(wsPD6, headerRow, Array("TYPE", "DEVICE TYPE"))
    cElement = KX_FindHeaderColumn(wsPD6, headerRow, Array("SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER"))
    cControl = KX_FindHeaderColumn(wsPD6, headerRow, Array("CONTROL_ID", "CONTROL ID"))
    cPanel = KX_FindHeaderColumn(wsPD6, headerRow, Array("PNL", "PANEL"))

    If cSeq = 0 Or cElement = 0 Or cControl = 0 Or cPanel = 0 Then
        Err.Raise vbObjectError + 5312, "Step05F_Backfill_Kx_From_Network_Clean", _
                  "PD6 requires SIS_SEQUENCE, SIS_ELEMENT_NUMBER, CONTROL_ID, and PNL headers."
    End If

    lastPD6Row = KX_LastUsedRow(wsPD6)
    If lastPD6Row <= headerRow Then
        MsgBox "PD6_IMPORT contains no data rows.", vbInformation, "ONGEN Network Kx Backfill"
        Exit Sub
    End If

    pd6Data = wsPD6.Range(wsPD6.Cells(headerRow, 1), _
                           wsPD6.Cells(lastPD6Row, KX_LastUsedColumn(wsPD6, headerRow))).Value2

    Set panelRows = CreateObject("Scripting.Dictionary")
    panelRows.CompareMode = vbTextCompare
    KX_IndexPD6RowsByPanel pd6Data, panelRows, headerRow, cPanel

    Set updateRows = CreateObject("Scripting.Dictionary")
    updateRows.CompareMode = vbTextCompare
    Set updateTags = CreateObject("Scripting.Dictionary")
    updateTags.CompareMode = vbTextCompare
    Set updateSources = CreateObject("Scripting.Dictionary")
    updateSources.CompareMode = vbTextCompare

    Set wsAudit = KX_PrepareAuditSheet()

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    oldCalc = Application.Calculation
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    For Each ws In ThisWorkbook.Worksheets
        If KX_IsNetworkCleanSheet(ws.Name) Then
            cleanSheetCount = cleanSheetCount + 1
            panelName = KX_PanelFromCleanSheetName(ws.Name)
            headerRow = KX_FindHeaderRow(ws, "SIS NUMBER", 15)

            If headerRow = 0 Then
                KX_WriteAudit wsAudit, "WARNING", "HEADER_NOT_FOUND", ws.Name, 0, panelName, _
                              vbNullString, vbNullString, vbNullString, 0, vbNullString, _
                              "The clean worksheet does not contain a SIS Number header."
            Else
                cCleanSIS = KX_FindHeaderColumn(ws, headerRow, Array("SIS NUMBER", "SIS_NUMBER", "SIS"))
                cCleanTag = KX_FindHeaderColumn(ws, headerRow, Array("CONTROL TAG", "CONTROL_TAG", "KX", "K TAG"))
                cCleanType = KX_FindHeaderColumn(ws, headerRow, Array("TYPE", "DEVICE TYPE"))
                lastCleanRow = KX_LastUsedRow(ws)

                If cCleanSIS = 0 Or cCleanTag = 0 Then
                    KX_WriteAudit wsAudit, "WARNING", "REQUIRED_HEADER_MISSING", ws.Name, headerRow, panelName, _
                                  vbNullString, vbNullString, vbNullString, 0, vbNullString, _
                                  "SIS Number and Control Tag are required."
                ElseIf lastCleanRow > headerRow Then
                    cleanData = ws.Range(ws.Cells(headerRow, 1), _
                                         ws.Cells(lastCleanRow, KX_LastUsedColumn(ws, headerRow))).Value2

                    For r = 2 To UBound(cleanData, 1)
                        cleanSis = KX_Text(cleanData(r, cCleanSIS))
                        tagValue = KX_NormalizeKTag(KX_Text(cleanData(r, cCleanTag)))
                        If Len(tagValue) = 0 Then
                            tagValue = KX_ExtractKTag(cleanSis)
                        End If

                        If cCleanType > 0 Then
                            cleanType = KX_Text(cleanData(r, cCleanType))
                        Else
                            cleanType = vbNullString
                        End If

                        If Len(Trim$(cleanSis)) > 0 Or Len(tagValue) > 0 Then
                            If Not KX_IsValidKTag(tagValue) Then
                                invalidTagCount = invalidTagCount + 1
                                KX_WriteAudit wsAudit, "WARNING", "INVALID_OR_MISSING_K_TAG", ws.Name, _
                                              headerRow + r - 1, panelName, cleanSis, tagValue, _
                                              vbNullString, 0, vbNullString, _
                                              "Control Tag must be K followed by one or more digits."
                            Else
                                pd6Row = KX_FindBestPD6Match(pd6Data, panelRows, panelName, cleanSis, _
                                                           cleanType, cSeq, cArea, cSWG, cType, _
                                                           cElement, cControl, cPanel, resultCode, resultDetail)

                                Select Case resultCode
                                    Case "MATCH"
                                        candidateUpdates = candidateUpdates + 1
                                        KX_StageUpdate updateRows, updateTags, updateSources, pd6Row, tagValue, _
                                                       ws.Name & "!" & CStr(headerRow + r - 1), conflictCount, wsAudit, _
                                                       panelName, cleanSis
                                    Case "AMBIGUOUS"
                                        ambiguousCount = ambiguousCount + 1
                                        KX_WriteAudit wsAudit, "ERROR", "AMBIGUOUS_PD6_MATCH", ws.Name, _
                                                      headerRow + r - 1, panelName, cleanSis, tagValue, _
                                                      vbNullString, 0, vbNullString, resultDetail
                                    Case Else
                                        unmatchedCount = unmatchedCount + 1
                                        KX_WriteAudit wsAudit, "WARNING", "PD6_MATCH_NOT_FOUND", ws.Name, _
                                                      headerRow + r - 1, panelName, cleanSis, tagValue, _
                                                      vbNullString, 0, vbNullString, resultDetail
                                End Select
                            End If
                        End If
                    Next r
                End If
            End If
        End If
    Next ws

    If cleanSheetCount = 0 Then
        MsgBox "No worksheets ending with ' - Clean' were found." & vbCrLf & _
               "Run Step 12 first, or confirm the Network Clean worksheet names.", _
               vbExclamation, "ONGEN Network Kx Backfill"
        GoTo SafeExit
    End If

    If updateRows.count = 0 Then
        KX_FinalizeAudit wsAudit
        MsgBox "No unambiguous PD6 updates were found." & vbCrLf & vbCrLf & _
               "Review " & KX_AUDIT_SHEET & " for unmatched or ambiguous records.", _
               vbInformation, "ONGEN Network Kx Backfill"
        GoTo SafeExit
    End If

    answer = MsgBox( _
        CStr(updateRows.count) & " unique PD6 rows are ready for Kx backfill." & vbCrLf & vbCrLf & _
        "Only the PD6 Control_ID column will be changed." & vbCrLf & _
        "SIS_Element_Number and all other process data will remain unchanged." & vbCrLf & vbCrLf & _
        "Proceed with the backfill?", _
        vbQuestion + vbYesNo + vbDefaultButton2, "ONGEN Network Kx Backfill")

    If answer <> vbYes Then
        KX_WriteAudit wsAudit, "INFO", "USER_CANCELLED", KX_PD6_SHEET, 0, vbNullString, _
                      vbNullString, vbNullString, vbNullString, 0, vbNullString, _
                      "No PD6 values were changed."
        KX_FinalizeAudit wsAudit
        GoTo SafeExit
    End If

    KX_CommitUpdates wsPD6, pd6Data, headerRow, cElement, cControl, updateRows, updateTags, _
                     updateSources, wsAudit, matchedCount, unchangedCount

    KX_FinalizeAudit wsAudit
    Application.CalculateFull

    MsgBox "Network Clean Kx backfill completed." & vbCrLf & vbCrLf & _
           "PD6 rows updated: " & CStr(matchedCount) & vbCrLf & _
           "Already correct: " & CStr(unchangedCount) & vbCrLf & _
           "Unmatched clean rows: " & CStr(unmatchedCount) & vbCrLf & _
           "Ambiguous clean rows: " & CStr(ambiguousCount) & vbCrLf & _
           "Conflicting duplicate mappings: " & CStr(conflictCount) & vbCrLf & _
           "Invalid/missing K tags: " & CStr(invalidTagCount) & vbCrLf & vbCrLf & _
           "Run the existing PD6-to-480V/24V backfill step when you are ready to propagate the updated Control_ID values.", _
           vbInformation, "ONGEN Network Kx Backfill"

SafeExit:
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents
    Application.Calculation = oldCalc
    Exit Sub

ErrHandler:
    On Error Resume Next
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents
    Application.Calculation = oldCalc
    MsgBox "Network Clean Kx backfill failed:" & vbCrLf & Err.description, _
           vbCritical, "ONGEN Network Kx Backfill"
End Sub

'-------------------------------------------------------------------------------
' Optional UI installer. This does not alter or replace any existing process.
'-------------------------------------------------------------------------------
Public Sub Install_Step05F_Network_Kx_Backfill_Button()
    Dim ws As Worksheet
    Dim shp As Shape
    Dim leftPos As Double
    Dim topPos As Double

    On Error GoTo ErrHandler

    Set ws = KX_GetSheet(ThisWorkbook, KX_MAIN_SHEET)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 5320, "Install_Step05F_Network_Kx_Backfill_Button", _
                  "Worksheet '" & KX_MAIN_SHEET & "' was not found."
    End If

    On Error Resume Next
    ws.Shapes(KX_BUTTON_NAME).Delete
    On Error GoTo ErrHandler

    leftPos = ws.Range("E31").Left
    topPos = ws.Range("E31").Top

    Set shp = ws.Shapes.AddShape(5, leftPos, topPos, 250, 30)
    With shp
        .Name = KX_BUTTON_NAME
        .OnAction = "'" & ThisWorkbook.Name & "'!Step05F_Backfill_Kx_From_Network_Clean"
        .TextFrame2.TextRange.Characters.text = KX_BUTTON_CAPTION
        .TextFrame2.TextRange.Font.Bold = True
        .TextFrame2.TextRange.Font.Size = 10
        .TextFrame2.VerticalAnchor = 3
        .TextFrame2.TextRange.ParagraphFormat.Alignment = 2
        .AlternativeText = "Optional: Backfill PD6 Control_ID -Kx suffixes from Network Clean worksheets."
    End With

    MsgBox "The optional Step 05F button was installed on MAIN." & vbCrLf & _
           "All existing ONGEN processes remain unchanged.", _
           vbInformation, "ONGEN UI"
    Exit Sub

ErrHandler:
    MsgBox "Unable to install the Step 05F button:" & vbCrLf & Err.description, _
           vbCritical, "ONGEN UI"
End Sub

'-------------------------------------------------------------------------------
' Builds a panel -> PD6 array-row index.
'-------------------------------------------------------------------------------
Private Sub KX_IndexPD6RowsByPanel(ByRef pd6Data As Variant, ByRef panelRows As Object, _
                                   ByVal worksheetHeaderRow As Long, ByVal cPanel As Long)
    Dim r As Long
    Dim panelName As String
    Dim rowsForPanel As Collection

    For r = 2 To UBound(pd6Data, 1)
        panelName = UCase$(Trim$(KX_Text(pd6Data(r, cPanel))))
        If Len(panelName) > 0 Then
            If Not panelRows.Exists(panelName) Then
                Set rowsForPanel = New Collection
                panelRows.Add panelName, rowsForPanel
            Else
                Set rowsForPanel = panelRows(panelName)
            End If
            rowsForPanel.Add r
        End If
    Next r
End Sub

'-------------------------------------------------------------------------------
' Finds the unique highest-scoring PD6 match within the same panel.
'-------------------------------------------------------------------------------
Private Function KX_FindBestPD6Match(ByRef pd6Data As Variant, ByRef panelRows As Object, _
                                     ByVal panelName As String, ByVal cleanSis As String, _
                                     ByVal cleanType As String, ByVal cSeq As Long, _
                                     ByVal cArea As Long, ByVal cSWG As Long, ByVal cType As Long, _
                                     ByVal cElement As Long, ByVal cControl As Long, ByVal cPanel As Long, _
                                     ByRef resultCode As String, ByRef resultDetail As String) As Long
    Dim rowsForPanel As Collection
    Dim item As Variant
    Dim r As Long
    Dim score As Long
    Dim bestScore As Long
    Dim bestRow As Long
    Dim tieCount As Long
    Dim cleanBase As String
    Dim cleanCompact As String
    Dim cleanDigits As String
    Dim seqValue As String
    Dim seqCompact As String
    Dim seqDigits As String
    Dim areaValue As String
    Dim swgValue As String
    Dim elementValue As String
    Dim controlValue As String
    Dim compositeValue As String
    Dim pd6Type As String
    Dim expectedFull As String
    Dim expectedSeq As String
    Dim branchRule As String
    Dim exactCount As Long
    Dim exactRow As Long

    resultCode = "NOT_FOUND"
    resultDetail = "No PD6 row in panel " & panelName & " matched the Network Clean SIS Number."
    KX_FindBestPD6Match = 0

    panelName = UCase$(Trim$(panelName))
    If Not panelRows.Exists(panelName) Then
        resultDetail = "Panel " & panelName & " does not exist in PD6_IMPORT."
        Exit Function
    End If

    cleanBase = KX_RemoveKTag(cleanSis)
    cleanCompact = KX_Compact(cleanBase)
    cleanDigits = KX_DigitsOnly(cleanBase)
    Set rowsForPanel = panelRows(panelName)

    'V25.3.2: Resolve the network branch code before any broad SIS scoring.
    'This prevents repeated base SIS numbers such as 2035 from matching the
    'wrong PD6 branch.
    If KX_BuildExpectedPD6Identity(cleanBase, expectedFull, expectedSeq, branchRule) Then
        For Each item In rowsForPanel
            r = CLng(item)
            seqValue = KX_Text(pd6Data(r, cSeq))
            elementValue = KX_RemoveKTag(KX_Text(pd6Data(r, cElement)))
            controlValue = KX_RemoveKTag(KX_Text(pd6Data(r, cControl)))

            If cArea > 0 Then areaValue = KX_Text(pd6Data(r, cArea)) Else areaValue = vbNullString
            If cSWG > 0 Then swgValue = KX_Text(pd6Data(r, cSWG)) Else swgValue = vbNullString
            compositeValue = areaValue & "-" & swgValue & "-" & seqValue

            If KX_IdentityEquals(controlValue, expectedFull, expectedSeq) Or _
               KX_IdentityEquals(elementValue, expectedFull, expectedSeq) Or _
               KX_IdentityEquals(compositeValue, expectedFull, expectedSeq) Or _
               KX_IdentityEquals(seqValue, expectedFull, expectedSeq) Then
                exactCount = exactCount + 1
                exactRow = r
            End If
        Next item

        If exactCount = 1 Then
            resultCode = "MATCH"
            resultDetail = "Exact branch match: " & branchRule & " -> " & expectedFull & "."
            KX_FindBestPD6Match = exactRow
            Exit Function
        ElseIf exactCount > 1 Then
            resultCode = "AMBIGUOUS"
            resultDetail = CStr(exactCount) & " PD6 rows matched the exact branch identity " & _
                           expectedFull & ". No value was changed."
            Exit Function
        Else
            resultCode = "NOT_FOUND"
            resultDetail = "Network branch rule " & branchRule & " expected " & expectedFull & _
                           ", but no exact PD6 row was found in panel " & panelName & "."
            Exit Function
        End If
    End If

    'Legacy fallback is retained only when the clean SIS does not contain a
    'recognized area/switchgroup/base/branch structure.
    For Each item In rowsForPanel
        r = CLng(item)
        score = 0
        seqValue = KX_Text(pd6Data(r, cSeq))
        elementValue = KX_Text(pd6Data(r, cElement))
        controlValue = KX_RemoveKTag(KX_Text(pd6Data(r, cControl)))
        pd6Type = KX_Text(pd6Data(r, cType))

        If cArea > 0 Then areaValue = KX_Text(pd6Data(r, cArea)) Else areaValue = vbNullString
        If cSWG > 0 Then swgValue = KX_Text(pd6Data(r, cSWG)) Else swgValue = vbNullString
        compositeValue = areaValue & "-" & swgValue & "-" & seqValue

        If Len(controlValue) > 0 And KX_EndsWithCompact(cleanCompact, KX_Compact(controlValue)) Then score = 120
        If score < 115 And Len(elementValue) > 0 And KX_EndsWithCompact(cleanCompact, KX_Compact(elementValue)) Then score = 115
        If score < 110 And Len(compositeValue) > 2 And KX_ContainsCompact(cleanCompact, KX_Compact(compositeValue)) Then score = 110

        seqCompact = KX_Compact(seqValue)
        If score < 100 And Len(seqCompact) >= 4 And KX_ContainsCompact(cleanCompact, seqCompact) Then score = 100

        seqDigits = KX_DigitsOnly(seqValue)
        If score < 90 And Len(seqDigits) >= 4 And Len(cleanDigits) >= Len(seqDigits) Then
            If InStr(1, cleanDigits, seqDigits, vbTextCompare) > 0 Then score = 90
        End If

        If score > 0 And Len(cleanType) > 0 And Len(pd6Type) > 0 Then
            If KX_Compact(cleanType) = KX_Compact(pd6Type) Then score = score + 5
        End If

        If score > bestScore Then
            bestScore = score
            bestRow = r
            tieCount = 1
        ElseIf score > 0 And score = bestScore Then
            tieCount = tieCount + 1
        End If
    Next item

    If bestScore >= 90 And tieCount = 1 Then
        resultCode = "MATCH"
        resultDetail = "Unique legacy PD6 match with score " & CStr(bestScore) & "."
        KX_FindBestPD6Match = bestRow
    ElseIf bestScore >= 90 And tieCount > 1 Then
        resultCode = "AMBIGUOUS"
        resultDetail = CStr(tieCount) & " PD6 rows tied at match score " & CStr(bestScore) & _
                       ". No value was changed."
    Else
        resultCode = "NOT_FOUND"
        resultDetail = "No unique match reached the minimum industrial match score."
    End If
End Function

'-------------------------------------------------------------------------------
' Converts a Network Clean identity into the exact PD6 identity expected by
' ONGEN. Examples:
'   12-203-2035-00 -> 12-203-2035
'   12-203-2035-01 -> 12-203-2035-01A
'   12-203-2025-70 -> 12-203-2025-SCN-1
'-------------------------------------------------------------------------------
Private Function KX_BuildExpectedPD6Identity(ByVal cleanBase As String, _
                                             ByRef expectedFull As String, _
                                             ByRef expectedSeq As String, _
                                             ByRef branchRule As String) As Boolean
    Dim normalized As String
    Dim parts As Variant
    Dim n As Long
    Dim areaPart As String
    Dim swgPart As String
    Dim basePart As String
    Dim branchPart As String
    Dim branchNumber As Long

    normalized = KX_NormalizeSeparators(cleanBase)
    parts = Split(normalized, "-")
    n = UBound(parts) - LBound(parts) + 1
    If n < 4 Then Exit Function

    areaPart = Trim$(CStr(parts(LBound(parts))))
    swgPart = Trim$(CStr(parts(LBound(parts) + 1)))
    basePart = Trim$(CStr(parts(LBound(parts) + 2)))
    branchPart = Trim$(CStr(parts(LBound(parts) + 3)))

    If Not KX_IsDigits(areaPart) Then Exit Function
    If Not KX_IsDigits(swgPart) Then Exit Function
    If Not KX_IsDigits(basePart) Then Exit Function
    If Not KX_IsDigits(branchPart) Then Exit Function

    branchNumber = CLng(branchPart)

    Select Case branchNumber
        Case 0
            expectedSeq = basePart
            branchRule = KX_Pad2(branchNumber) & " = base SIS"
        Case 70 To 73
            expectedSeq = basePart & "-SCN-" & CStr(branchNumber - 69)
            branchRule = CStr(branchNumber) & " = SCN-" & CStr(branchNumber - 69)
        Case 1 To 69
            expectedSeq = basePart & "-" & KX_Pad2(branchNumber) & "A"
            branchRule = KX_Pad2(branchNumber) & " = " & KX_Pad2(branchNumber) & "A"
        Case Else
            Exit Function
    End Select

    expectedFull = areaPart & "-" & swgPart & "-" & expectedSeq
    KX_BuildExpectedPD6Identity = True
End Function

Private Function KX_IdentityEquals(ByVal candidate As String, ByVal expectedFull As String, _
                                   ByVal expectedSeq As String) As Boolean
    Dim candidateCompact As String
    candidateCompact = KX_Compact(KX_RemoveKTag(candidate))
    If Len(candidateCompact) = 0 Then Exit Function

    KX_IdentityEquals = (candidateCompact = KX_Compact(expectedFull) Or _
                         candidateCompact = KX_Compact(expectedSeq))
End Function

Private Function KX_NormalizeSeparators(ByVal valueIn As String) As String
    Dim s As String
    s = UCase$(Trim$(valueIn))
    s = Replace(s, "_", "-")
    s = Replace(s, " ", "-")
    Do While InStr(s, "--") > 0
        s = Replace(s, "--", "-")
    Loop
    If Left$(s, 1) = "-" Then s = mid$(s, 2)
    If Right$(s, 1) = "-" Then s = Left$(s, Len(s) - 1)
    KX_NormalizeSeparators = s
End Function

Private Function KX_IsDigits(ByVal valueIn As String) As Boolean
    Dim i As Long
    If Len(valueIn) = 0 Then Exit Function
    For i = 1 To Len(valueIn)
        If mid$(valueIn, i, 1) < "0" Or mid$(valueIn, i, 1) > "9" Then Exit Function
    Next i
    KX_IsDigits = True
End Function

Private Function KX_Pad2(ByVal numberIn As Long) As String
    KX_Pad2 = Right$("00" & CStr(numberIn), 2)
End Function

'-------------------------------------------------------------------------------
' Stages a unique PD6 row update and rejects conflicting duplicate clean mappings.
'-------------------------------------------------------------------------------
Private Sub KX_StageUpdate(ByRef updateRows As Object, ByRef updateTags As Object, _
                           ByRef updateSources As Object, ByVal pd6ArrayRow As Long, _
                           ByVal tagValue As String, ByVal sourceRef As String, _
                           ByRef conflictCount As Long, ByRef wsAudit As Worksheet, _
                           ByVal panelName As String, ByVal cleanSis As String)
    Dim key As String
    key = CStr(pd6ArrayRow)

    If updateTags.Exists(key) Then
        If StrComp(CStr(updateTags(key)), tagValue, vbTextCompare) <> 0 Then
            conflictCount = conflictCount + 1
            KX_WriteAudit wsAudit, "ERROR", "CONFLICTING_CLEAN_TAGS", sourceRef, 0, panelName, _
                          cleanSis, tagValue, vbNullString, pd6ArrayRow, CStr(updateTags(key)), _
                          "Two Network Clean records map to the same PD6 row with different K tags."
            updateRows.Remove key
            updateTags.Remove key
            updateSources.Remove key
        End If
    Else
        updateRows.Add key, pd6ArrayRow
        updateTags.Add key, tagValue
        updateSources.Add key, sourceRef
    End If
End Sub

'-------------------------------------------------------------------------------
' Commits staged Control_ID updates.
'-------------------------------------------------------------------------------
Private Sub KX_CommitUpdates(ByRef wsPD6 As Worksheet, ByRef pd6Data As Variant, _
                             ByVal worksheetHeaderRow As Long, ByVal cElement As Long, _
                             ByVal cControl As Long, ByRef updateRows As Object, _
                             ByRef updateTags As Object, ByRef updateSources As Object, _
                             ByRef wsAudit As Worksheet, ByRef matchedCount As Long, _
                             ByRef unchangedCount As Long)
    Dim key As Variant
    Dim arrayRow As Long
    Dim worksheetRow As Long
    Dim oldControl As String
    Dim newControl As String
    Dim baseControl As String
    Dim elementValue As String
    Dim tagValue As String

    For Each key In updateRows.keys
        arrayRow = CLng(updateRows(key))
        worksheetRow = worksheetHeaderRow + arrayRow - 1
        oldControl = KX_Text(pd6Data(arrayRow, cControl))
        elementValue = KX_Text(pd6Data(arrayRow, cElement))
        tagValue = CStr(updateTags(key))

        baseControl = KX_RemoveKTag(oldControl)
        If Len(baseControl) = 0 Then baseControl = KX_RemoveKTag(elementValue)

        If Len(baseControl) = 0 Then
            KX_WriteAudit wsAudit, "ERROR", "PD6_BASE_ID_MISSING", CStr(updateSources(key)), 0, _
                          KX_Text(wsPD6.Cells(worksheetRow, KX_FindHeaderColumn(wsPD6, worksheetHeaderRow, Array("PNL", "PANEL"))).Value2), _
                          vbNullString, tagValue, oldControl, worksheetRow, oldControl, _
                          "Control_ID and SIS_Element_Number are both blank."
        Else
            newControl = baseControl & "-" & tagValue
            If StrComp(oldControl, newControl, vbTextCompare) = 0 Then
                unchangedCount = unchangedCount + 1
                KX_WriteAudit wsAudit, "OK", "ALREADY_CORRECT", CStr(updateSources(key)), 0, _
                              vbNullString, vbNullString, tagValue, oldControl, worksheetRow, newControl, _
                              "PD6 Control_ID already contains the Network Clean K tag."
            Else
                wsPD6.Cells(worksheetRow, cControl).Value2 = newControl
                matchedCount = matchedCount + 1
                KX_WriteAudit wsAudit, "UPDATED", "CONTROL_ID_BACKFILLED", CStr(updateSources(key)), 0, _
                              vbNullString, vbNullString, tagValue, oldControl, worksheetRow, newControl, _
                              "Only PD6 Control_ID was updated."
            End If
        End If
    Next key
End Sub

'-------------------------------------------------------------------------------
' Audit helpers.
'-------------------------------------------------------------------------------
Private Function KX_PrepareAuditSheet() As Worksheet
    Dim ws As Worksheet
    Set ws = KX_GetSheet(ThisWorkbook, KX_AUDIT_SHEET)
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = KX_AUDIT_SHEET
    Else
        ws.Cells.Clear
    End If

    ws.Range("A1:M1").value = Array("STATUS", "ISSUE", "SOURCE_SHEET", "SOURCE_ROW", _
                                      "PANEL", "CLEAN_SIS_NUMBER", "CLEAN_K_TAG", _
                                      "OLD_PD6_CONTROL_ID", "PD6_ROW", "NEW_PD6_CONTROL_ID", _
                                      "DETAIL", "RUN_DATE", "WORKBOOK")
    ws.rows(1).Font.Bold = True
    ws.rows(1).AutoFilter
    Set KX_PrepareAuditSheet = ws
End Function

Private Sub KX_WriteAudit(ByRef ws As Worksheet, ByVal statusValue As String, _
                          ByVal issueValue As String, ByVal sourceSheet As String, _
                          ByVal sourceRow As Long, ByVal panelName As String, _
                          ByVal cleanSis As String, ByVal cleanTag As String, _
                          ByVal oldControl As String, ByVal pd6Row As Long, _
                          ByVal newControl As String, ByVal detailValue As String)
    Dim nextRow As Long
    nextRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row + 1
    ws.Cells(nextRow, 1).Resize(1, 13).value = Array(statusValue, issueValue, sourceSheet, _
        IIf(sourceRow > 0, sourceRow, vbNullString), panelName, cleanSis, cleanTag, oldControl, _
        IIf(pd6Row > 0, pd6Row, vbNullString), newControl, detailValue, Now, ThisWorkbook.Name)
End Sub

Private Sub KX_FinalizeAudit(ByRef ws As Worksheet)
    With ws
        .Columns("A:M").EntireColumn.AutoFit
        .Columns("F:F").columnWidth = 30
        .Columns("K:K").columnWidth = 45
        .Columns("K:K").WrapText = True
        .rows(1).Interior.Color = RGB(31, 78, 121)
        .rows(1).Font.Color = vbWhite
        .Activate
        .Range("A2").Select
        ActiveWindow.FreezePanes = True
    End With
End Sub

'-------------------------------------------------------------------------------
' General worksheet/header helpers.
'-------------------------------------------------------------------------------
Private Function KX_GetSheet(ByRef wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set KX_GetSheet = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function KX_IsNetworkCleanSheet(ByVal sheetName As String) As Boolean
    Dim upperName As String
    upperName = UCase$(Trim$(sheetName))
    KX_IsNetworkCleanSheet = (Len(upperName) > Len(KX_CLEAN_SUFFIX) And _
                              Right$(upperName, Len(KX_CLEAN_SUFFIX)) = KX_CLEAN_SUFFIX)
End Function

Private Function KX_PanelFromCleanSheetName(ByVal sheetName As String) As String
    Dim upperName As String
    upperName = UCase$(Trim$(sheetName))
    If Right$(upperName, Len(KX_CLEAN_SUFFIX)) = KX_CLEAN_SUFFIX Then
        KX_PanelFromCleanSheetName = Trim$(Left$(sheetName, Len(sheetName) - Len(KX_CLEAN_SUFFIX)))
    Else
        KX_PanelFromCleanSheetName = Trim$(sheetName)
    End If
End Function

Private Function KX_FindHeaderRow(ByRef ws As Worksheet, ByVal requiredHeader As String, _
                                  ByVal maxRowsToSearch As Long) As Long
    Dim r As Long
    Dim c As Long
    Dim lastCol As Long
    Dim wanted As String
    wanted = KX_HeaderKey(requiredHeader)

    For r = 1 To maxRowsToSearch
        lastCol = ws.Cells(r, ws.Columns.count).End(xlToLeft).Column
        For c = 1 To lastCol
            If KX_HeaderKey(KX_Text(ws.Cells(r, c).Value2)) = wanted Then
                KX_FindHeaderRow = r
                Exit Function
            End If
        Next c
    Next r
End Function

Private Function KX_FindHeaderColumn(ByRef ws As Worksheet, ByVal headerRow As Long, _
                                     ByVal aliases As Variant) As Long
    Dim c As Long
    Dim i As Long
    Dim lastCol As Long
    Dim cellKey As String
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column

    For c = 1 To lastCol
        cellKey = KX_HeaderKey(KX_Text(ws.Cells(headerRow, c).Value2))
        For i = LBound(aliases) To UBound(aliases)
            If cellKey = KX_HeaderKey(CStr(aliases(i))) Then
                KX_FindHeaderColumn = c
                Exit Function
            End If
        Next i
    Next c
End Function

Private Function KX_LastUsedRow(ByRef ws As Worksheet) As Long
    Dim foundCell As Range
    On Error Resume Next
    Set foundCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                                  LookAt:=xlPart, SearchOrder:=xlByRows, _
                                  SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If foundCell Is Nothing Then
        KX_LastUsedRow = 1
    Else
        KX_LastUsedRow = foundCell.Row
    End If
End Function

Private Function KX_LastUsedColumn(ByRef ws As Worksheet, ByVal headerRow As Long) As Long
    KX_LastUsedColumn = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column
End Function

'-------------------------------------------------------------------------------
' String normalization helpers.
'-------------------------------------------------------------------------------
Private Function KX_Text(ByVal valueIn As Variant) As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then
        KX_Text = vbNullString
    Else
        KX_Text = Trim$(CStr(valueIn))
    End If
End Function

Private Function KX_HeaderKey(ByVal valueIn As String) As String
    Dim s As String
    s = UCase$(Trim$(valueIn))
    s = Replace(s, "_", " ")
    s = Replace(s, "-", " ")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    KX_HeaderKey = s
End Function

Private Function KX_NormalizeKTag(ByVal valueIn As String) As String
    Dim s As String
    Dim i As Long
    Dim digits As String
    s = UCase$(Trim$(valueIn))
    s = Replace(s, "-", vbNullString)
    s = Replace(s, " ", vbNullString)
    If Left$(s, 1) <> "K" Then
        KX_NormalizeKTag = vbNullString
        Exit Function
    End If
    For i = 2 To Len(s)
        If mid$(s, i, 1) Like "#" Then
            digits = digits & mid$(s, i, 1)
        Else
            KX_NormalizeKTag = vbNullString
            Exit Function
        End If
    Next i
    If Len(digits) > 0 Then KX_NormalizeKTag = "K" & digits
End Function

Private Function KX_ExtractKTag(ByVal valueIn As String) As String
    Dim parts As Variant
    Dim i As Long
    Dim candidate As String
    parts = Split(Replace(UCase$(Trim$(valueIn)), " ", "-"), "-")
    For i = UBound(parts) To LBound(parts) Step -1
        candidate = KX_NormalizeKTag(CStr(parts(i)))
        If Len(candidate) > 0 Then
            KX_ExtractKTag = candidate
            Exit Function
        End If
    Next i
End Function

Private Function KX_IsValidKTag(ByVal valueIn As String) As Boolean
    KX_IsValidKTag = (Len(KX_NormalizeKTag(valueIn)) > 0)
End Function

Private Function KX_RemoveKTag(ByVal valueIn As String) As String
    Dim s As String
    Dim parts As Variant
    Dim i As Long
    Dim result As String
    s = Trim$(valueIn)
    If Len(s) = 0 Then Exit Function
    parts = Split(s, "-")

    For i = LBound(parts) To UBound(parts)
        If i = UBound(parts) And KX_IsValidKTag(CStr(parts(i))) Then
            ' Skip the final K tag.
        ElseIf i = UBound(parts) - 1 And Trim$(CStr(parts(i))) = "0" And _
               KX_IsValidKTag(CStr(parts(UBound(parts)))) Then
            ' Skip the optional network zero immediately before the K tag.
        Else
            If Len(result) > 0 Then result = result & "-"
            result = result & Trim$(CStr(parts(i)))
        End If
    Next i
    KX_RemoveKTag = result
End Function

Private Function KX_Compact(ByVal valueIn As String) As String
    Dim i As Long
    Dim ch As String
    Dim result As String
    valueIn = UCase$(valueIn)
    For i = 1 To Len(valueIn)
        ch = mid$(valueIn, i, 1)
        If (ch >= "A" And ch <= "Z") Or (ch >= "0" And ch <= "9") Then result = result & ch
    Next i
    KX_Compact = result
End Function

Private Function KX_DigitsOnly(ByVal valueIn As String) As String
    Dim i As Long
    Dim ch As String
    Dim result As String
    For i = 1 To Len(valueIn)
        ch = mid$(valueIn, i, 1)
        If ch Like "#" Then result = result & ch
    Next i
    KX_DigitsOnly = result
End Function

Private Function KX_ContainsCompact(ByVal largeValue As String, ByVal smallValue As String) As Boolean
    If Len(smallValue) = 0 Then Exit Function
    KX_ContainsCompact = (InStr(1, largeValue, smallValue, vbTextCompare) > 0)
End Function

Private Function KX_EndsWithCompact(ByVal largeValue As String, ByVal smallValue As String) As Boolean
    If Len(smallValue) = 0 Or Len(largeValue) < Len(smallValue) Then Exit Function
    KX_EndsWithCompact = (StrComp(Right$(largeValue, Len(smallValue)), smallValue, vbTextCompare) = 0)
End Function

