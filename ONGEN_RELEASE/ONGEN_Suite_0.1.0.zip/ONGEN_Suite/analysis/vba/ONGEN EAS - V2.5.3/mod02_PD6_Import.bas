Attribute VB_Name = "mod02_PD6_Import"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod02_PD6_Import
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : mod02_PD6_Import
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Industrial Module Length default with user-selectable XYZ distance.
' Notes         : Every eligible PSU type is used when PNL and SwitchGroup are assigned.
'                 XYZ is optional per run; Module Length remains the default and fallback.
'-------------------------------------------------------------------------------

Option Explicit
' ONGEN V25.8 PD6 MERGE: non-destructive import + PD power-return alignment.
' ONGEN V25.9.2 COMPILE FIX 2: restored PD6_PanelSwitchDisplay.
' ONGEN V25.9.2 PSU TERMINAL MATCH REPAIR: canonical Panel/SwitchGroup keys.

' V22.5 HIGH-SPEED: DATA_POWER controls BUS eligibility and amp overrides.
' Dual-BUS devices are assigned atomically in SIS sequence order.
' V22.6: exact same-sequence PSU pairs are reserved first for nearby dual-BUS devices.
' V22.14: dual-BUS devices remain on one PD6 row; no BUS-row splitting or duplicate SIS_sequence.
' Performance: bulk array reads/writes, cached PSU-row classification, and batch row deletion.
' PSU pairs favor close/same-number supplies without stranding usable PSUs.
' A soft 30A scoring target balances later rows; the hard PSU cap stays 40A.
' Step07 preserves the existing 400/480V main Load column.

Private Const BUS1_LIMIT_A As Double = 35#          'Hardware rating
Private Const BUS2_LIMIT_A As Double = 35#          'Hardware rating
Private Const PSU_ALLOC_LIMIT_A As Double = 40#     'Hard PSU cap: do not exceed the 40A power supply limit
Private Const BUS1_LIMIT_FT As Double = 35#
Private Const BUS2_LIMIT_FT As Double = 35#
Private Const TERM_LIMIT_A As Double = 16#
Private Const TERM_LIMIT_FT As Double = 20#
Private Const MAX_TERMINALS_PER_BUS As Long = 4
Private Const PSU_PAIR_MAX_NUMBER_GAP As Long = 25  'Preferred/required max numeric gap between paired BUS-1 and BUS-2 PSU names
Private Const PSU_EXACT_PAIR_DEVICE_GAP As Long = 25 'Hard priority range for an explicit same-sequence PSU-1/PSU-2 pair
Private Const PSU_PAIR_SOFT_TARGET_A As Double = 30#  'Scoring preference only; the hard PSU limit remains 40A
Private Const PSU_PAIR_BALANCE_PENALTY As Double = 10000#
Private Const PSU_PAIR_ISOLATION_PENALTY As Double = 50000000#
Private Const PSU_DEVICE_MAX_NUMBER_GAP As Long = 40  'Preferred numeric gap between device SIS_sequence and assigned PSU
Private Const PSU_MISSING_TEXT As String = "MISSING"  'Used when the required alternate PSU row does not exist

'V24.2.2 OPTIONAL XYZ DISTANCE CONFIGURATION
'The supplied coordinate export uses millimeters. Change only this constant when a
'different plant model unit is intentionally used. Supported: MM, CM, M, IN, FT.
Private Const PD6_XYZ_UNIT As String = "MM"
Private Const PD6_XYZ_ROUTE_FACTOR As Double = 1#
Private Const PD6_XYZ_SCORE_WEIGHT As Double = 1000000#
Private Const PD6_XYZ_MISSING_CANDIDATE_PENALTY As Double = 500000000000#

Private mPD6HeaderCache As Object
Private mPD6DataPowerLoadCache As Object
Private mPD6DataPowerBusCache As Object
Private mPD6LastColCache As Object
Private mPD6ControlKRuleCache As Object
Private mPD6ControlKAllocationCache As Object
Private mPD6ControlKWarningCache As Object
Private mPD6PSUTerminalTemplate As Object
Private mPD6CoordinateByRow As Object
Private mPD6PSUCoordinateBySwitchPSU As Object
Private mPD6CoordinateDistanceUsedCount As Long
Private mPD6FallbackDistanceUsedCount As Long
Private mPD6UseXYZDistance As Boolean
Private mPD6EligiblePSUCount As Long
Private mPD6ExcludedPSUCount As Long

Public Sub Step05_Import_SIS_TAG_PD6_From_PD_Workbook()

    'V25.8 ALIGNMENT:
    '  - PD6_IMPORT keeps its existing 29-column EAS layout.
    '  - The import NEVER clears or rebuilds existing PD6_IMPORT information.
    '  - Existing nonblank cells are not overwritten.
    '  - Control_ID remains an EAS-owned field and is never imported from PD.
    '  - ONGEN_MECH parent geometry is ignored when child electrical rows exist.
    '  - Missing BUS/PSU/terminal values are imported from the PD workbook's
    '    Power Supply Bus + PSU_Terminal_Assignment calculation when available.
    '  - No headers are added to or removed from the selected PD workbook.

    Dim filePath As String
    Dim wbSrc As Workbook
    Dim wsSrc As Worksheet
    Dim wsDest As Worksheet
    Dim srcSheetName As String
    Dim lastRow As Long
    Dim r As Long
    Dim destRow As Long
    Dim headers As Variant
    Dim childSeqs As Object
    Dim bestRow As Object
    Dim bestPriority As Object
    Dim destKeyRow As Object
    Dim destBlankTypeRow As Object
    Dim k As Variant
    Dim seqVal As String
    Dim typeVal As String
    Dim blockVal As String
    Dim rowKey As String
    Dim pri As Long
    Dim mergedExisting As Long
    Dim appendedNew As Long
    Dim filledCells As Long

    On Error GoTo ErrHandler
    ResetApplicationState False
    PD6_ResetSpeedCaches True

    filePath = PickWorkbookFile("Select PD workbook containing PD6 System Designed")
    If Len(filePath) = 0 Then GoTo SafeExit

    Set wbSrc = Workbooks.Open(filePath, ReadOnly:=True, UpdateLinks:=False)
    Set wsSrc = FirstExistingSheet(wbSrc, Array("PD6 System Designed", "SIS_TAG_IMPORT_PD6", "PD6_IMPORT", "PD6 Import"))
    If wsSrc Is Nothing Then
        MsgBox "Could not find source sheet 'PD6 System Designed' or 'PD6_IMPORT' in the selected workbook.", vbExclamation
        GoTo SafeExit
    End If
    srcSheetName = wsSrc.Name

    Set wsDest = GetSheetIfExists(SH_PD6)
    If wsDest Is Nothing Then
        MsgBox "PD6_IMPORT is missing from ONGEN-EAS V25.8. The V25.8 import does not create or redesign the PD6 sheet.", vbCritical
        GoTo SafeExit
    End If

    headers = PD6_CombinedHeaders()
    PD6_V258_ValidateCurrentImportHeaders wsDest, headers

    lastRow = LastUsedRow(wsSrc)
    If lastRow < 2 Then
        MsgBox "The source PD6 sheet does not contain data rows.", vbExclamation
        GoTo SafeExit
    End If

    Set childSeqs = PD6_V258_BuildSourceChildIndex(wsSrc)
    Set bestRow = CreateObject("Scripting.Dictionary"): bestRow.CompareMode = vbTextCompare
    Set bestPriority = CreateObject("Scripting.Dictionary"): bestPriority.CompareMode = vbTextCompare

    'Choose one source row per EAS key (SIS_sequence + TYPE). Parent geometry is
    'only eligible when the same SIS sequence has no child electrical row.
    For r = 2 To lastRow
        If PD6_RowHasData(wsSrc, r) Then
            seqVal = Trim$(PD6_Pick(wsSrc, r, "SIS_SEQUENCE", "SIS_sequence", "SEQUENCE", "Sequence"))
            typeVal = UCase$(Trim$(PD6_Pick(wsSrc, r, "TYPE", "Device Type", "TYPE/DESC")))
            blockVal = Trim$(PD6_Pick(wsSrc, r, "BLOCK", "BLOCK_NAME", "BLOCK NAME"))

            If Len(seqVal) > 0 Then
                If PD6_V258_IsONGENMechParent(blockVal) Then
                    If childSeqs.Exists(PD6_V258_SequenceKey(seqVal)) Then GoTo NextSourceCandidate
                End If

                rowKey = PD6_V258_RowKey(seqVal, typeVal)
                pri = PD6_V258_SourcePriority(blockVal, typeVal)
                If Not bestRow.Exists(rowKey) Then
                    bestRow.Add rowKey, r
                    bestPriority.Add rowKey, pri
                ElseIf pri > CLng(bestPriority(rowKey)) Then
                    bestRow(rowKey) = r
                    bestPriority(rowKey) = pri
                End If
            End If
        End If
NextSourceCandidate:
    Next r

    Set destKeyRow = CreateObject("Scripting.Dictionary"): destKeyRow.CompareMode = vbTextCompare
    Set destBlankTypeRow = CreateObject("Scripting.Dictionary"): destBlankTypeRow.CompareMode = vbTextCompare
    PD6_V258_IndexDestinationRows wsDest, destKeyRow, destBlankTypeRow

    destRow = LastUsedRow(wsDest)
    If destRow < 1 Then destRow = 1

    For Each k In bestRow.keys
        r = CLng(bestRow(k))
        seqVal = Trim$(PD6_Pick(wsSrc, r, "SIS_SEQUENCE", "SIS_sequence", "SEQUENCE", "Sequence"))
        typeVal = UCase$(Trim$(PD6_Pick(wsSrc, r, "TYPE", "Device Type", "TYPE/DESC")))
        rowKey = PD6_V258_RowKey(seqVal, typeVal)

        If destKeyRow.Exists(rowKey) Then
            PD6_V258_FillMissingFromSource wsDest, CLng(destKeyRow(rowKey)), wsSrc, r, filledCells
            mergedExisting = mergedExisting + 1
        ElseIf destBlankTypeRow.Exists(PD6_V258_SequenceKey(seqVal)) Then
            PD6_V258_FillMissingFromSource wsDest, CLng(destBlankTypeRow(PD6_V258_SequenceKey(seqVal))), wsSrc, r, filledCells
            destKeyRow(rowKey) = CLng(destBlankTypeRow(PD6_V258_SequenceKey(seqVal)))
            mergedExisting = mergedExisting + 1
        Else
            destRow = destRow + 1
            PD6_V258_FillMissingFromSource wsDest, destRow, wsSrc, r, filledCells
            destKeyRow(rowKey) = destRow
            appendedNew = appendedNew + 1
        End If
    Next k

    'V25.9.2 PD6 AUTHORITY RULE:
    'Step05 imports/merges the PD workbook only. The old automatic IO-list
    'backfill was removed so Step05C is truly OPTIONAL and cannot silently
    'change PD6 after a successful PD import.
    'Control_ID remains EAS-owned and missing load/BUS calculation cells may
    'still be filled only when they are blank.
    PD6_V258_FillMissingControlIDs wsDest
    PD6_V258_FillMissingLoadBusColumns wsDest

    'Use the already-calculated PD power breakout for any still-missing EAS
    'BUS/PSU/terminal fields. Existing EAS assignments remain untouched.
    PD6_V258_ImportMissingPowerFromPD wbSrc, wsDest

    AppendLog "Step05_Import_SIS_TAG_PD6_From_PD_Workbook", "OK", _
              CStr(mergedExisting) & " existing EAS rows matched, " & _
              CStr(appendedNew) & " new rows appended, " & CStr(filledCells) & _
              " blank cells filled from " & srcSheetName & ". Existing nonblank PD6 values were preserved."

    MsgBox "PD6 import/merge complete." & vbCrLf & vbCrLf & _
           "Existing rows matched: " & CStr(mergedExisting) & vbCrLf & _
           "New rows appended: " & CStr(appendedNew) & vbCrLf & _
           "Blank source fields filled: " & CStr(filledCells) & vbCrLf & vbCrLf & _
           "The PD6_IMPORT header layout was not changed." & vbCrLf & _
           "Existing nonblank EAS data was not recalculated or overwritten." & vbCrLf & _
           "Control_ID remains EAS-owned." & vbCrLf & _
           "Missing power assignments were read from the PD workbook when available.", _
           vbInformation, "ONGEN-EAS V25.8 PD6 Merge"

SafeExit:
    On Error Resume Next
    PD6_SafeCloseWorkbook wbSrc
    ResetApplicationState True
    Exit Sub

ErrHandler:
    On Error Resume Next
    PD6_SafeCloseWorkbook wbSrc
    ResetApplicationState True
    AppendLog "Step05_Import_SIS_TAG_PD6_From_PD_Workbook", "ERROR", Err.description
    MsgBox "PD6 import failed: " & Err.description, vbCritical, "ONGEN-EAS V25.8 PD6 Merge"

End Sub
Private Sub PD6_SafeCloseWorkbook(ByRef wb As Workbook)

    On Error Resume Next
    If Not wb Is Nothing Then
        wb.Close SaveChanges:=False
        Set wb = Nothing
    End If
    On Error GoTo 0

End Sub


Private Sub PD6_V258_ValidateCurrentImportHeaders(ByVal ws As Worksheet, ByVal expected As Variant)
    Dim i As Long, expectedCount As Long, actualLastCol As Long
    expectedCount = UBound(expected) - LBound(expected) + 1
    actualLastCol = LastUsedCol(ws, 1)
    If actualLastCol <> expectedCount Then
        Err.Raise vbObjectError + 25801, "PD6_V258_ValidateCurrentImportHeaders", _
                  "PD6_IMPORT must keep the current ONGEN-EAS V25.8 " & CStr(expectedCount) & _
                  "-column format. Found " & CStr(actualLastCol) & " columns. No headers were changed."
    End If
    For i = LBound(expected) To UBound(expected)
        If PD6_NormalizeHeaderKey(ws.Cells(1, i - LBound(expected) + 1).Value2) <> _
           PD6_NormalizeHeaderKey(CStr(expected(i))) Then
            Err.Raise vbObjectError + 25802, "PD6_V258_ValidateCurrentImportHeaders", _
                      "PD6_IMPORT header mismatch at column " & CStr(i - LBound(expected) + 1) & _
                      ". Expected '" & CStr(expected(i)) & "'. No headers were changed."
        End If
    Next i
End Sub

Private Function PD6_V258_BuildSourceChildIndex(ByVal wsSrc As Worksheet) As Object
    Dim d As Object, lr As Long, r As Long
    Dim seqVal As String, blockVal As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    lr = LastUsedRow(wsSrc)
    For r = 2 To lr
        seqVal = Trim$(PD6_Pick(wsSrc, r, "SIS_SEQUENCE", "SIS_sequence", "SEQUENCE", "Sequence"))
        blockVal = Trim$(PD6_Pick(wsSrc, r, "BLOCK", "BLOCK_NAME", "BLOCK NAME"))
        If Len(seqVal) > 0 And Len(blockVal) > 0 Then
            If Not PD6_V258_IsONGENMechParent(blockVal) Then d(PD6_V258_SequenceKey(seqVal)) = True
        End If
    Next r
    Set PD6_V258_BuildSourceChildIndex = d
End Function

Private Function PD6_V258_IsONGENMechParent(ByVal blockVal As String) As Boolean
    Dim s As String
    s = UCase$(Trim$(blockVal)): s = Replace$(s, " ", vbNullString)
    PD6_V258_IsONGENMechParent = (Left$(s, 10) = "ONGEN_MECH")
End Function

Private Function PD6_V258_SourcePriority(ByVal blockVal As String, ByVal typeVal As String) As Long
    Dim b As String
    b = PD6_V258_BlockKey(blockVal)
    If PD6_V258_IsONGENMechParent(blockVal) Then PD6_V258_SourcePriority = 10: Exit Function
    Select Case b
        Case "MULTICONTROL": PD6_V258_SourcePriority = 600
        Case "MOT", "VFD": PD6_V258_SourcePriority = 550
        Case "NN", "NONE": PD6_V258_SourcePriority = 500
        Case "INTERFACECARD": PD6_V258_SourcePriority = 450
        Case "IOD", "IOS", "EMIONONSAFE", "EMIOSAFE": PD6_V258_SourcePriority = 400
        Case Else: PD6_V258_SourcePriority = 300
    End Select
End Function

Private Sub PD6_V258_IndexDestinationRows(ByVal ws As Worksheet, ByVal byKey As Object, ByVal blankType As Object)
    Dim cSeq As Long, cType As Long, lr As Long, r As Long
    Dim seqVal As String, typeVal As String, k As String
    cSeq = PD6_HeaderCol(ws, "SIS_sequence", "SIS_SEQUENCE")
    cType = PD6_HeaderCol(ws, "TYPE", "Device Type")
    If cSeq = 0 Or cType = 0 Then Exit Sub
    lr = LastUsedRow(ws)
    For r = 2 To lr
        seqVal = Trim$(CStr(ws.Cells(r, cSeq).Value2))
        typeVal = UCase$(Trim$(CStr(ws.Cells(r, cType).Value2)))
        If Len(seqVal) > 0 Then
            k = PD6_V258_RowKey(seqVal, typeVal)
            If Not byKey.Exists(k) Then byKey.Add k, r
            If Len(typeVal) = 0 Then
                k = PD6_V258_SequenceKey(seqVal)
                If Not blankType.Exists(k) Then blankType.Add k, r
            End If
        End If
    Next r
End Sub

Private Sub PD6_V258_FillMissingFromSource(ByVal wsDest As Worksheet, ByVal dr As Long, _
                                           ByVal wsSrc As Worksheet, ByVal sr As Long, _
                                           ByRef filledCells As Long)
    Dim v As Variant

    PD6_V258_SetIfBlank wsDest, dr, "SIS_sequence", PD6_Pick(wsSrc, sr, "SIS_SEQUENCE", "SIS_sequence", "SEQUENCE", "Sequence"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "AREA_Number", PD6_Pick(wsSrc, sr, "AREA_NUMBER", "AREA_Number", "Area Number"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "SwitchGroup", PD6_Pick(wsSrc, sr, "SWITCHGROUP", "SwitchGroup", "PWG", "Power Work Group"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "TYPE", PD6_Pick(wsSrc, sr, "TYPE", "Device Type", "TYPE/DESC"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "SIS_Element_Number", PD6_Pick(wsSrc, sr, "SIS_ELEMENT_NUMBER", "SIS_Element_Number", "SIS Element Number"), filledCells

    'Control_ID deliberately NOT imported. ONGEN-EAS owns that calculation.

    v = PD6_Pick(wsSrc, sr, "CURRENT_LOAD", "Load", "LOAD")
    PD6_V258_SetIfBlank wsDest, dr, "Load", v, filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Conveyor Type", PD6_Pick(wsSrc, sr, "CONVEYOR TYPE", "Conveyor Type", "CONVEYOR_TYPE"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Module Length (ML)", PD6_Pick(wsSrc, sr, "Module Length (ML)", "MODULE_LENGTH_ML", "Module Length", "ML"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Motor Power (Main Drive)", PD6_Pick(wsSrc, sr, "Motor Power (Main Drive)", "Motor_Power_Main_Drive", "MOTOR_POWER_MAIN_DRIVE"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Motor Voltage (Main Drive)", PD6_Pick(wsSrc, sr, "Motor Voltage (Main Drive)", "Motor_Voltage_Main_Drive", "MOTOR_VOLTAGE_MAIN_DRIVE"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Total Qty of Sensors", PD6_Pick(wsSrc, sr, "Total Qty of Sensors", "TOTAL_QTY_OF_SENSORS"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Control Card", PD6_Pick(wsSrc, sr, "Control Card", "CONTROL_CARD"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Total Qty of Drives", PD6_Pick(wsSrc, sr, "Total Qty of Drives", "TOTAL_QTY_OF_DRIVES"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "System Type", PD6_Pick(wsSrc, sr, "SYSTEM TYPE", "System Type", "SYSTEM_TYPE"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "PNL", PD6_Pick(wsSrc, sr, "Panel", "PANEL", "PNL"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "NETWORK_IP", PD6_Pick(wsSrc, sr, "NETWORK_IP", "NETWORK IP", "Network IP", "IP"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "LPN", PD6_Pick(wsSrc, sr, "LPN", "Layout Position Number"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "X", PD6_Pick(wsSrc, sr, "X"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Y", PD6_Pick(wsSrc, sr, "Y"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "Z", PD6_Pick(wsSrc, sr, "Z"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "ROTATION_DEG", PD6_Pick(wsSrc, sr, "ROTATION_DEG", "ROTATION", "ROTATION DEG"), filledCells
    PD6_V258_SetIfBlank wsDest, dr, "NOTES", PD6_Pick(wsSrc, sr, "NOTES", "Notes", "NOTE", "Description"), filledCells
End Sub

Private Sub PD6_V258_SetIfBlank(ByVal ws As Worksheet, ByVal r As Long, ByVal headerName As String, _
                                ByVal newValue As Variant, ByRef filledCells As Long)
    Dim c As Long, oldText As String, newText As String
    c = PD6_HeaderCol(ws, headerName)
    If c = 0 Then Exit Sub
    oldText = Trim$(CStr(ws.Cells(r, c).Value2))
    If Len(oldText) > 0 Then Exit Sub
    If IsError(newValue) Or IsEmpty(newValue) Then Exit Sub
    newText = Trim$(CStr(newValue))
    If Len(newText) = 0 Then Exit Sub
    ws.Cells(r, c).Value2 = newValue
    filledCells = filledCells + 1
End Sub

Private Sub PD6_V258_FillMissingControlIDs(ByVal ws As Worksheet)
    Dim cSeq As Long, cArea As Long, cSWG As Long, cType As Long, cControl As Long
    Dim lr As Long, r As Long, v As String
    cSeq = PD6_HeaderCol(ws, "SIS_sequence", "SIS_SEQUENCE")
    cArea = PD6_HeaderCol(ws, "AREA_Number", "AREA_NUMBER")
    cSWG = PD6_HeaderCol(ws, "SwitchGroup", "SWITCHGROUP")
    cType = PD6_HeaderCol(ws, "TYPE")
    cControl = PD6_HeaderCol(ws, "Control_ID", "CONTROL_ID")
    If cSeq = 0 Or cControl = 0 Then Exit Sub
    lr = LastUsedRow(ws)
    For r = 2 To lr
        If Len(Trim$(CStr(ws.Cells(r, cControl).Value2))) = 0 Then
            v = PD6_BuildControlID(CStr(ws.Cells(r, cArea).Value2), CStr(ws.Cells(r, cSWG).Value2), _
                                   CStr(ws.Cells(r, cSeq).Value2), CStr(ws.Cells(r, cType).Value2))
            If Len(Replace$(v, "-", vbNullString)) > 0 Then ws.Cells(r, cControl).Value2 = v
        End If
    Next r
End Sub

Private Sub PD6_V258_FillMissingLoadBusColumns(ByVal ws As Worksheet)
    Dim cLoad As Long, cB1 As Long, cB2 As Long, cType As Long, cConv As Long, cSys As Long, cVolt As Long
    Dim lr As Long, r As Long, typeVal As String, convVal As String, sysVal As String, voltVal As String
    Dim loadValue As Variant, b1 As Variant, b2 As Variant
    cLoad = PD6_HeaderCol(ws, "Load")
    cB1 = PD6_HeaderCol(ws, "Load BUS-1")
    cB2 = PD6_HeaderCol(ws, "Load BUS-2")
    cType = PD6_HeaderCol(ws, "TYPE")
    cConv = PD6_HeaderCol(ws, "Conveyor Type")
    cSys = PD6_HeaderCol(ws, "System Type")
    cVolt = PD6_HeaderCol(ws, "Motor Voltage (Main Drive)")
    If cLoad = 0 Or cB1 = 0 Or cB2 = 0 Then Exit Sub
    lr = LastUsedRow(ws)
    For r = 2 To lr
        If Len(Trim$(CStr(ws.Cells(r, 1).Value2))) > 0 Then
            If Len(Trim$(CStr(ws.Cells(r, cLoad).Value2))) = 0 Or _
               Len(Trim$(CStr(ws.Cells(r, cB1).Value2))) = 0 Or _
               Len(Trim$(CStr(ws.Cells(r, cB2).Value2))) = 0 Then
                typeVal = UCase$(Trim$(CStr(ws.Cells(r, cType).Value2)))
                convVal = Trim$(CStr(ws.Cells(r, cConv).Value2))
                sysVal = UCase$(Trim$(CStr(ws.Cells(r, cSys).Value2)))
                voltVal = UCase$(Trim$(CStr(ws.Cells(r, cVolt).Value2)))
                If Len(Trim$(CStr(ws.Cells(r, cLoad).Value2))) = 0 Then
                    loadValue = PD6_CalculateLoadBUS1(ws, r, convVal, sysVal, voltVal)
                    If Len(Trim$(CStr(loadValue))) > 0 Then ws.Cells(r, cLoad).Value2 = loadValue
                Else
                    loadValue = ws.Cells(r, cLoad).Value2
                End If
                PD6_ResolveLoadBusValues typeVal, loadValue, b1, b2
                If Len(Trim$(CStr(ws.Cells(r, cB1).Value2))) = 0 And Len(Trim$(CStr(b1))) > 0 Then ws.Cells(r, cB1).Value2 = b1
                If Len(Trim$(CStr(ws.Cells(r, cB2).Value2))) = 0 And Len(Trim$(CStr(b2))) > 0 Then ws.Cells(r, cB2).Value2 = b2
            End If
        End If
    Next r
End Sub

Private Sub PD6_V258_ImportMissingPowerFromPD(ByVal wbPD As Workbook, ByVal wsDest As Worksheet)
    Dim wsTerm As Worksheet, wsBus As Worksheet, wsPower As Worksheet
    Dim psuFull As Object, assignExact As Object, assignRoot As Object, termCode As Object
    Dim r As Long, lr As Long, hr As Long
    Dim cPSU As Long, cSrc As Long, cBlock As Long, cBus As Long, cTerm As Long
    Dim cBusDevice As Long, cBusCode As Long, cBusFull As Long
    Dim seqVal As String, typeVal As String, blockVal As String, busVal As String, terminalVal As String
    Dim shortPSU As String, fullPSU As String, key As String, root As String
    Dim rec As Variant, rec1 As Variant, rec2 As Variant
    Dim cBusPower As Long, cPowerSupply As Long, cT1 As Long, cT2 As Long
    Dim candidates As Variant, i As Long, found1 As Boolean, found2 As Boolean

    Set wsTerm = FirstExistingSheet(wbPD, Array("PSU_Terminal_Assignment"))
    Set wsBus = FirstExistingSheet(wbPD, Array("Power Supply Bus"))
    If wsTerm Is Nothing Or wsBus Is Nothing Then Exit Sub
    Set wsPower = GetSheetIfExists("DATA_POWER")

    Set psuFull = CreateObject("Scripting.Dictionary"): psuFull.CompareMode = vbTextCompare
    Set assignExact = CreateObject("Scripting.Dictionary"): assignExact.CompareMode = vbTextCompare
    Set assignRoot = CreateObject("Scripting.Dictionary"): assignRoot.CompareMode = vbTextCompare
    Set termCode = CreateObject("Scripting.Dictionary"): termCode.CompareMode = vbTextCompare
    PD6_V258_BuildTerminalCodeMap wsPower, termCode

    hr = PD6_V258_FindHeaderRow(wsBus, "Device 1", "BUS", "PSU SIS Element Number")
    If hr > 0 Then
        cBusDevice = PD6_V258_HeaderColAtRow(wsBus, hr, "Device 1")
        cBusCode = PD6_V258_HeaderColAtRow(wsBus, hr, "BUS")
        cBusFull = PD6_V258_HeaderColAtRow(wsBus, hr, "PSU SIS Element Number")
        lr = LastUsedRow(wsBus)
        For r = hr + 1 To lr
            busVal = UCase$(Trim$(CStr(wsBus.Cells(r, cBusCode).Value2)))
            shortPSU = Trim$(CStr(wsBus.Cells(r, cBusDevice).Value2))
            fullPSU = Trim$(CStr(wsBus.Cells(r, cBusFull).Value2))
            If (busVal = "BUS-1" Or busVal = "BUS-2") And Len(shortPSU) > 0 Then
                If Len(fullPSU) = 0 Then fullPSU = shortPSU
                psuFull(busVal & "|" & UCase$(shortPSU)) = fullPSU
            End If
        Next r
    End If

    cPSU = PD6_HeaderCol(wsTerm, "PSU_SIS_SEQUENCE")
    cSrc = PD6_HeaderCol(wsTerm, "SOURCE_SIS_SEQUENCE")
    cBlock = PD6_HeaderCol(wsTerm, "BLOCK_NAME")
    cBus = PD6_HeaderCol(wsTerm, "BUS")
    cTerm = PD6_HeaderCol(wsTerm, "PSU_TERMINAL")
    If cPSU = 0 Or cSrc = 0 Or cBlock = 0 Or cBus = 0 Or cTerm = 0 Then Exit Sub

    lr = LastUsedRow(wsTerm)
    For r = 2 To lr
        seqVal = Trim$(CStr(wsTerm.Cells(r, cSrc).Value2))
        blockVal = PD6_V258_BlockKey(CStr(wsTerm.Cells(r, cBlock).Value2))
        busVal = UCase$(Trim$(CStr(wsTerm.Cells(r, cBus).Value2)))
        shortPSU = Trim$(CStr(wsTerm.Cells(r, cPSU).Value2))
        terminalVal = Trim$(CStr(wsTerm.Cells(r, cTerm).Value2))
        If Len(seqVal) > 0 And Len(blockVal) > 0 And (busVal = "BUS-1" Or busVal = "BUS-2") Then
            fullPSU = shortPSU
            key = busVal & "|" & UCase$(shortPSU)
            If psuFull.Exists(key) Then fullPSU = CStr(psuFull(key))
            terminalVal = PD6_V258_TermCode(termCode, terminalVal)
            rec = Array(fullPSU, terminalVal)
            key = PD6_V258_SequenceKey(seqVal) & "|" & busVal & "|" & blockVal
            If Not assignExact.Exists(key) Then assignExact.Add key, rec
            root = PD6_V258_ConveyorRoot(seqVal)
            key = root & "|" & busVal & "|" & blockVal
            If Not assignRoot.Exists(key) Then assignRoot.Add key, rec
        End If
    Next r

    cBusPower = PD6_HeaderCol(wsDest, "Bus Power")
    cPowerSupply = PD6_HeaderCol(wsDest, "Power Supply")
    cT1 = PD6_HeaderCol(wsDest, "Power BUS-1 Terminal")
    cT2 = PD6_HeaderCol(wsDest, "Power BUS-2 Terminal")
    If cBusPower = 0 Or cPowerSupply = 0 Or cT1 = 0 Or cT2 = 0 Then Exit Sub

    lr = LastUsedRow(wsDest)
    For r = 2 To lr
        seqVal = Trim$(CStr(wsDest.Cells(r, PD6_HeaderCol(wsDest, "SIS_sequence")).Value2))
        typeVal = UCase$(Trim$(CStr(wsDest.Cells(r, PD6_HeaderCol(wsDest, "TYPE")).Value2)))
        If Len(seqVal) > 0 Then
            candidates = Split(PD6_V258_BlockCandidates(typeVal), "|")
            found1 = PD6_V258_FindPowerRecord(assignExact, assignRoot, seqVal, "BUS-1", candidates, rec1)
            found2 = PD6_V258_FindPowerRecord(assignExact, assignRoot, seqVal, "BUS-2", candidates, rec2)

            If Len(Trim$(CStr(wsDest.Cells(r, cBusPower).Value2))) = 0 Then
                If found1 And found2 Then
                    wsDest.Cells(r, cBusPower).Value2 = "BUS-1/BUS-2"
                ElseIf found1 Then
                    wsDest.Cells(r, cBusPower).Value2 = "BUS-1"
                ElseIf found2 Then
                    wsDest.Cells(r, cBusPower).Value2 = "BUS-2"
                End If
            End If

            If Len(Trim$(CStr(wsDest.Cells(r, cPowerSupply).Value2))) = 0 Then
                If found1 And found2 Then
                    wsDest.Cells(r, cPowerSupply).Value2 = "BUS-1=" & CStr(rec1(0)) & " | BUS-2=" & CStr(rec2(0))
                ElseIf found1 Then
                    wsDest.Cells(r, cPowerSupply).Value2 = CStr(rec1(0))
                ElseIf found2 Then
                    wsDest.Cells(r, cPowerSupply).Value2 = CStr(rec2(0))
                End If
            End If

            If found1 Then
                If Len(Trim$(CStr(wsDest.Cells(r, cT1).Value2))) = 0 Then wsDest.Cells(r, cT1).Value2 = CStr(rec1(1))
            End If
            If found2 Then
                If Len(Trim$(CStr(wsDest.Cells(r, cT2).Value2))) = 0 Then wsDest.Cells(r, cT2).Value2 = CStr(rec2(1))
            End If
        End If
    Next r
End Sub

Private Function PD6_V258_FindPowerRecord(ByVal exactMap As Object, ByVal rootMap As Object, _
                                           ByVal seqVal As String, ByVal busVal As String, _
                                           ByVal candidates As Variant, ByRef rec As Variant) As Boolean
    Dim i As Long, key As String, b As String
    For i = LBound(candidates) To UBound(candidates)
        b = PD6_V258_BlockKey(CStr(candidates(i)))
        key = PD6_V258_SequenceKey(seqVal) & "|" & busVal & "|" & b
        If exactMap.Exists(key) Then rec = exactMap(key): PD6_V258_FindPowerRecord = True: Exit Function
    Next i
    For i = LBound(candidates) To UBound(candidates)
        b = PD6_V258_BlockKey(CStr(candidates(i)))
        key = PD6_V258_ConveyorRoot(seqVal) & "|" & busVal & "|" & b
        If rootMap.Exists(key) Then rec = rootMap(key): PD6_V258_FindPowerRecord = True: Exit Function
    Next i
End Function

Private Function PD6_V258_BlockCandidates(ByVal typeVal As String) As String
    Dim t As String
    t = UCase$(Trim$(typeVal)): t = Replace$(t, "_", "/")
    Select Case t
        Case "MC": PD6_V258_BlockCandidates = "MULTICONTROL|INTERFACE_CARD"
        Case "MS": PD6_V258_BlockCandidates = "NN|NONE|MULTICONTROL"
        Case "VFD", "VFD/MF", "VFD/MC": PD6_V258_BlockCandidates = "MOT|VFD"
        Case "IO/D": PD6_V258_BlockCandidates = "IO/D|EM_IO_NONSAFE|IO_D"
        Case "IO/S": PD6_V258_BlockCandidates = "IO/S|EM_IO_SAFE|IO_S"
        Case Else: PD6_V258_BlockCandidates = t
    End Select
End Function

Private Sub PD6_V258_BuildTerminalCodeMap(ByVal ws As Worksheet, ByVal d As Object)
    Dim cCode As Long, cDesc As Long, lr As Long, r As Long, code As String, desc As String
    If ws Is Nothing Then Exit Sub
    cCode = PD6_HeaderCol(ws, "PSU TERM", "PSU_TERM")
    cDesc = PD6_HeaderCol(ws, "PSUDESC", "PSU DESC", "PSU_DESCRIPTION")
    If cCode = 0 Then Exit Sub
    lr = LastUsedRow(ws)
    For r = 2 To lr
        code = Trim$(CStr(ws.Cells(r, cCode).Value2))
        If Len(code) > 0 Then
            d(UCase$(code)) = code
            If cDesc > 0 Then
                desc = Trim$(CStr(ws.Cells(r, cDesc).Value2))
                If Len(desc) > 0 Then d(UCase$(desc)) = code
            End If
        End If
    Next r
End Sub

Private Function PD6_V258_TermCode(ByVal d As Object, ByVal terminalVal As String) As String
    Dim k As String
    k = UCase$(Trim$(terminalVal))
    If Not d Is Nothing Then If d.Exists(k) Then PD6_V258_TermCode = CStr(d(k)): Exit Function
    PD6_V258_TermCode = terminalVal
End Function

Private Function PD6_V258_FindHeaderRow(ByVal ws As Worksheet, ByVal h1 As String, ByVal h2 As String, ByVal h3 As String) As Long
    Dim r As Long
    For r = 1 To WorksheetFunction.Min(10, LastUsedRow(ws))
        If PD6_V258_HeaderColAtRow(ws, r, h1) > 0 And PD6_V258_HeaderColAtRow(ws, r, h2) > 0 And PD6_V258_HeaderColAtRow(ws, r, h3) > 0 Then
            PD6_V258_FindHeaderRow = r
            Exit Function
        End If
    Next r
End Function

Private Function PD6_V258_HeaderColAtRow(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal wanted As String) As Long
    Dim c As Long, lc As Long
    lc = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lc
        If PD6_NormalizeHeaderKey(ws.Cells(headerRow, c).Value2) = PD6_NormalizeHeaderKey(wanted) Then
            PD6_V258_HeaderColAtRow = c
            Exit Function
        End If
    Next c
End Function

Private Function PD6_V258_RowKey(ByVal seqVal As String, ByVal typeVal As String) As String
    PD6_V258_RowKey = PD6_V258_SequenceKey(seqVal) & "|" & UCase$(Trim$(typeVal))
End Function

Private Function PD6_V258_SequenceKey(ByVal seqVal As Variant) As String
    PD6_V258_SequenceKey = UCase$(Replace$(Trim$(CStr(seqVal)), " ", vbNullString))
End Function

Private Function PD6_V258_ConveyorRoot(ByVal seqVal As Variant) As String
    Dim s As String, p As Long, a As Variant
    s = UCase$(Replace$(Trim$(CStr(seqVal)), "_", "-"))
    p = InStr(1, s, "-IO/", vbTextCompare): If p = 0 Then p = InStr(1, s, "-IO-", vbTextCompare)
    If p > 0 Then s = Left$(s, p - 1)
    a = Split(s, "-")
    If UBound(a) >= 0 Then PD6_V258_ConveyorRoot = Trim$(CStr(a(0))) Else PD6_V258_ConveyorRoot = s
End Function

Private Function PD6_V258_BlockKey(ByVal blockVal As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(blockVal)))
    s = Replace$(s, " ", vbNullString): s = Replace$(s, "_", vbNullString)
    s = Replace$(s, "-", vbNullString): s = Replace$(s, "/", vbNullString)
    PD6_V258_BlockKey = s
End Function

Public Sub Step05_Reassign_PD6_BUS_PSU_Terminals()

    Dim ws As Worksheet
    Dim stageName As String
    Dim errNumber As Long
    Dim errSource As String
    Dim errDescription As String
    Dim useXYZDistance As Boolean

    On Error GoTo ErrHandler

    If MsgBox("05D is an OPTIONAL EAS override." & vbCrLf & vbCrLf & _
              "The normal V25.8 workflow keeps the BUS, PSU, and terminal assignments imported from the PD workbook." & vbCrLf & _
              "Running 05D will recalculate those assignments inside EAS and may replace the imported PD result." & vbCrLf & vbCrLf & _
              "Continue with EAS reassignment?", _
              vbYesNo + vbExclamation + vbDefaultButton2, "05D - OPTIONAL PSU / Terminal Override") <> vbYes Then Exit Sub

    stageName = "Initialize Excel state"
    ResetApplicationState False
    PD6_ResetSpeedCaches True

    stageName = "Select PSU distance method"
    useXYZDistance = PD6_PromptUseXYZDistance("Step 05D PD6 BUS/PSU reassignment")

    stageName = "Open PD6_IMPORT"
    Set ws = GetSheetIfExists(SH_PD6)
    If ws Is Nothing Then Err.Raise vbObjectError + 25830, , "PD6_IMPORT was not found. Run Step05 import first."

    stageName = "Ensure PD6_IMPORT headers"
    Step05_Ensure_PD6_IMPORT_Headers

    stageName = "Backfill PD6_IMPORT from IO_DEVICE_LIST"
    PD6_Backfill_PD6_From_IO_DEVICE_LIST ws

    stageName = "Backfill PNL from IO_BLOCK_GENERATOR"
    PD6_Backfill_PNL_From_IO_BLOCK_GENERATOR ws

    stageName = "Recalculate load and BUS columns"
    PD6_Recalculate_LoadBusColumns ws

    stageName = "Collapse duplicate or legacy split BUS rows"
    PD6_Collapse_Existing_SplitBusRows ws

    stageName = "Read 480v_DATA_POWER PSU terminal table and assign PSU terminals"
    PD6_AssignBusPowerSupplyAndTerminals ws, useXYZDistance

    stageName = "Force-fill BUS-1 for MC/MS"
    PD6_ForceFill_BUS1_For_MC_MS ws

    stageName = "Validate one PD6 row per SIS_sequence"
    PD6_ValidateUniqueSISSequenceRows ws

    stageName = "Format PD6_IMPORT"
    ws.Range(ws.Cells(1, 1), ws.Cells(1, LastUsedCol(ws, 1))).EntireColumn.AutoFit

    AppendLog "Step05_Reassign_PD6_BUS_PSU_Terminals", "OK", _
              "PD6_IMPORT backfill, BUS, PSU, and terminals reassigned with one row per SIS_sequence."

    MsgBox "PD6_IMPORT reassignment completed." & vbCrLf & _
           "Distance method: " & PD6_DistanceModeLabel(useXYZDistance) & vbCrLf & _
           "PSU terminals were read from 480v_DATA_POWER[PSU TERM].", _
           vbInformation, "PD6 Reassign PSU / Terminals"

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    errNumber = Err.Number
    errSource = Err.source
    errDescription = Err.description
    If Len(Trim$(errDescription)) = 0 Then errDescription = "Unspecified VBA runtime error."

    On Error Resume Next
    ResetApplicationState True
    AppendLog "Step05_Reassign_PD6_BUS_PSU_Terminals", "ERROR", _
              "Stage=" & stageName & "; Number=" & CStr(errNumber) & _
              "; Source=" & errSource & "; Description=" & errDescription
    On Error GoTo 0

    MsgBox "PD6 reassignment failed." & vbCrLf & vbCrLf & _
           "Stage: " & stageName & vbCrLf & _
           "Error " & CStr(errNumber) & ": " & errDescription & _
           IIf(Len(errSource) > 0, vbCrLf & "Source: " & errSource, vbNullString), _
           vbCritical, "PD6 Reassign PSU / Terminals"
    Exit Sub

End Sub

Public Sub PD6_Prepare_24V_Power_Assignments_For_Step07()

    'V25.9.2 COMPATIBILITY ENTRY POINT - READ ONLY.
    'Older modules called this helper before Step07. It must never recalculate
    'or reassign PD6 in the PD-master workflow. The procedure now validates the
    'existing final PD6 layout only.
    Dim ws As Worksheet
    Dim headers As Variant

    On Error GoTo ErrHandler
    Set ws = GetSheetIfExists(SH_PD6)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 25820, "PD6_Prepare_24V_Power_Assignments_For_Step07", _
                  "PD6_IMPORT was not found. Import PD6 before power generation."
    End If

    headers = PD6_CombinedHeaders()
    PD6_V258_ValidateCurrentImportHeaders ws, headers

    AppendLog "PD6_Prepare_24V_Power_Assignments_For_Step07", "OK", _
              "Compatibility validation only; existing PD6 BUS/PSU/terminal assignments were not changed."
    Exit Sub

ErrHandler:
    Err.Raise Err.Number, "PD6_Prepare_24V_Power_Assignments_For_Step07", Err.description
End Sub

Public Sub Step05_Recalculate_PD6_IMPORT_Calculations()

    Dim ws As Worksheet
    Dim stageName As String
    Dim errNumber As Long
    Dim errSource As String
    Dim errDescription As String

    On Error GoTo ErrHandler

    stageName = "Initialize Excel state"
    ResetApplicationState False
    PD6_ResetSpeedCaches True

    stageName = "Open PD6_IMPORT"
    Set ws = GetSheetIfExists(SH_PD6)
    If ws Is Nothing Then Err.Raise vbObjectError + 25831, , "PD6_IMPORT was not found. Run Step05 import first."

    stageName = "Ensure PD6_IMPORT headers"
    Step05_Ensure_PD6_IMPORT_Headers

    stageName = "Recalculate Control_ID and missing SIS_Element_Number"
    PD6_Recalculate_ControlID_And_MissingSISElement ws

    stageName = "Recalculate load and BUS load columns"
    PD6_Recalculate_LoadBusColumns ws

    ws.Range(ws.Cells(1, 1), ws.Cells(1, LastUsedCol(ws, 1))).EntireColumn.AutoFit

    AppendLog "Step05_Recalculate_PD6_IMPORT_Calculations", "OK", _
              "PD6_IMPORT calculations refreshed without PSU/terminal reassignment."

    MsgBox "PD6_IMPORT calculations were refreshed." & vbCrLf & _
           "Updated: Control_ID, missing SIS_Element_Number, Load, Load BUS-1, and Load BUS-2." & vbCrLf & _
           "BUS, Power Supply, and terminal assignments were not changed.", _
           vbInformation, "PD6 Calculation Refresh"

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    errNumber = Err.Number
    errSource = Err.source
    errDescription = Err.description
    If Len(Trim$(errDescription)) = 0 Then errDescription = "Unspecified VBA runtime error."

    On Error Resume Next
    ResetApplicationState True
    AppendLog "Step05_Recalculate_PD6_IMPORT_Calculations", "ERROR", _
              "Stage=" & stageName & "; Number=" & CStr(errNumber) & _
              "; Source=" & errSource & "; Description=" & errDescription
    On Error GoTo 0

    MsgBox "PD6 calculation refresh failed." & vbCrLf & vbCrLf & _
           "Stage: " & stageName & vbCrLf & _
           "Error " & CStr(errNumber) & ": " & errDescription & _
           IIf(Len(errSource) > 0, vbCrLf & "Source: " & errSource, vbNullString), _
           vbCritical, "PD6 Calculation Refresh"
    Exit Sub

End Sub

Private Sub PD6_Recalculate_ControlID_And_MissingSISElement(ByVal ws As Worksheet)

    Dim lastRow As Long
    Dim r As Long
    Dim cArea As Long
    Dim cSwitch As Long
    Dim cSequence As Long
    Dim cType As Long
    Dim cControlID As Long
    Dim cSisElement As Long
    Dim areaVal As String
    Dim switchVal As String
    Dim sequenceVal As String
    Dim typeVal As String
    Dim controlID As String

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then Exit Sub

    cArea = PD6_HeaderCol(ws, "AREA_Number", "AREA_NUMBER", "Area Number")
    cSwitch = PD6_HeaderCol(ws, "SwitchGroup", "SWITCHGROUP", "PWG", "Power Work Group")
    cSequence = PD6_HeaderCol(ws, "SIS_sequence", "SIS_SEQUENCE", "Sequence")
    cType = PD6_HeaderCol(ws, "TYPE", "Device Type", "TYPE/DESC")
    cControlID = PD6_HeaderCol(ws, "Control_ID", "CONTROL_ID", "Control ID")
    cSisElement = PD6_HeaderCol(ws, "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS Element Number")

    If cArea = 0 Or cSwitch = 0 Or cSequence = 0 Or cType = 0 Or cControlID = 0 Then Exit Sub

    For r = 2 To lastRow
        areaVal = Trim$(CStr(ws.Cells(r, cArea).value))
        switchVal = Trim$(CStr(ws.Cells(r, cSwitch).value))
        sequenceVal = Trim$(CStr(ws.Cells(r, cSequence).value))
        typeVal = UCase$(Trim$(CStr(ws.Cells(r, cType).value)))

        If Len(areaVal & switchVal & sequenceVal & typeVal) > 0 Then
            controlID = PD6_BuildControlID(areaVal, switchVal, sequenceVal, typeVal)

            If Len(Replace$(controlID, "-", vbNullString)) > 0 Then
                ws.Cells(r, cControlID).value = controlID

                If cSisElement > 0 Then
                    If Len(Trim$(CStr(ws.Cells(r, cSisElement).value))) = 0 Then
                        ws.Cells(r, cSisElement).value = controlID
                    End If
                End If
            End If
        End If
    Next r

End Sub

Public Sub Step05_Ensure_PD6_IMPORT_Headers()

    'V25.9.2: compatibility name retained, but this is now VALIDATION ONLY.
    'The final PD6_IMPORT layout is controlled and must not be redesigned here.
    Dim ws As Worksheet
    Dim headers As Variant

    On Error GoTo ErrHandler
    Set ws = GetSheetIfExists(SH_PD6)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 25810, "Step05_Ensure_PD6_IMPORT_Headers", _
                  "PD6_IMPORT was not found. Run Step05 import first."
    End If

    headers = PD6_CombinedHeaders()
    PD6_V258_ValidateCurrentImportHeaders ws, headers

    AppendLog "Step05_Ensure_PD6_IMPORT_Headers", "OK", _
              "PD6_IMPORT final V25.8 header layout validated; no headers were added, removed, or reordered."
    MsgBox "PD6_IMPORT header validation passed." & vbCrLf & _
           "No headers were added, removed, reordered, or repaired.", _
           vbInformation, "05A - Validate PD6 Headers"
    Exit Sub

ErrHandler:
    AppendLog "Step05_Ensure_PD6_IMPORT_Headers", "ERROR", Err.description
    MsgBox "PD6 header validation failed:" & vbCrLf & vbCrLf & Err.description, _
           vbCritical, "05A - Validate PD6 Headers"

End Sub

Private Function PD6_CombinedHeaders() As Variant

    PD6_CombinedHeaders = Split("SIS_sequence|AREA_Number|SwitchGroup|TYPE|SIS_Element_Number|Control_ID|Load|Load BUS-1|Load BUS-2|Conveyor Type|Module Length (ML)|Motor Power (Main Drive)|Motor Voltage (Main Drive)|Total Qty of Sensors|Control Card|Total Qty of Drives|System Type|Bus Power|Power Supply|Power BUS-1 Terminal|Power BUS-2 Terminal|PNL|NETWORK_IP|LPN|X|Y|Z|ROTATION_DEG|NOTES", "|")

End Function

Private Sub PD6_WriteHeaders(ByVal ws As Worksheet, ByVal headers As Variant)

    Dim i As Long
    Dim headerArr() As Variant
    Dim headerCount As Long

    headerCount = UBound(headers) - LBound(headers) + 1
    ReDim headerArr(1 To 1, 1 To headerCount)

    For i = LBound(headers) To UBound(headers)
        headerArr(1, i - LBound(headers) + 1) = headers(i)
    Next i

    ws.Range(ws.Cells(1, 1), ws.Cells(1, headerCount)).value = headerArr

    PD6_ResetHeaderCache

    StyleHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, headerCount))
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(1, headerCount)).AutoFilter

End Sub

Public Sub Step05_Backfill_PD6_From_IO_DEVICE_LIST_Only()

    Dim ws As Worksheet

    On Error GoTo ErrHandler
    ResetApplicationState False
    PD6_ResetSpeedCaches True

    Set ws = GetSheetIfExists(SH_PD6)
    If ws Is Nothing Then
        MsgBox "PD6_IMPORT was not found. Run Step05 import first.", vbExclamation
        GoTo SafeExit
    End If

    Step05_Ensure_PD6_IMPORT_Headers
    PD6_Backfill_PD6_From_IO_DEVICE_LIST ws
    PD6_Backfill_PNL_From_IO_BLOCK_GENERATOR ws

    AppendLog "Step05_Backfill_PD6_From_IO_DEVICE_LIST_Only", "OK", "Backfill only completed, including PNL from IO_BLOCK_GENERATOR."
    MsgBox "PD6_IMPORT backfill from IO_DEVICE_LIST completed." & vbCrLf & _
           "AREA_Number, SwitchGroup, SIS_Element_Number, and PNL were checked and filled where possible.", vbInformation

SafeExit:
    ResetApplicationState True
    Exit Sub

ErrHandler:
    AppendLog "Step05_Backfill_PD6_From_IO_DEVICE_LIST_Only", "ERROR", Err.description
    MsgBox "Backfill failed: " & Err.description, vbCritical
    Resume SafeExit

End Sub

Private Function PD6_HeaderColPreferBlockID(ByVal ws As Worksheet) As Long

    PD6_HeaderColPreferBlockID = PD6_HeaderCol(ws, "Block ID", "BLOCK ID", "BlockID", "BLOCK_ID")
    If PD6_HeaderColPreferBlockID = 0 Then
        PD6_HeaderColPreferBlockID = PD6_HeaderCol(ws, "IO Block", "IO_BLOCK")
    End If

End Function

Private Function PD6_HeaderColPreferDevice(ByVal ws As Worksheet) As Long

    PD6_HeaderColPreferDevice = PD6_HeaderCol(ws, "Device", "DEVICE", "Device Name", "DEVICE NAME")
    If PD6_HeaderColPreferDevice = 0 Then
        PD6_HeaderColPreferDevice = PD6_HeaderCol(ws, "SIS_SEQUENCE", "SIS_sequence")
    End If

End Function

Private Sub PD6_Backfill_PD6_From_IO_DEVICE_LIST(ByVal wsPD6 As Worksheet)

    Dim wsIO As Worksheet
    Dim lastPD6 As Long
    Dim lastIO As Long
    Dim pd6Count As Long
    Dim ioCount As Long
    Dim idx As Long
    Dim rowNum As Long
    Dim keyText As String
    Dim lookupVal As Variant
    Dim didBackfill As Boolean

    Dim dictBlock As Object
    Dim dictDevice As Object

    Dim cArea As Long
    Dim cSwitch As Long
    Dim cType As Long
    Dim cSisSeq As Long
    Dim cSisElem As Long
    Dim cNotes As Long

    Dim cIOBlock As Long
    Dim cIODevice As Long
    Dim cIOPWG As Long
    Dim cIOLoc As Long

    Dim typeVal As String
    Dim sisSeqVal As String
    Dim sisElemVal As String
    Dim areaVal As String
    Dim switchVal As String
    Dim ioArea As String
    Dim ioSwitch As String
    Dim newNote As Variant

    Dim vIOBlock As Variant
    Dim vIODevice As Variant
    Dim vIOPWG As Variant
    Dim vIOLoc As Variant
    Dim vArea As Variant
    Dim vSwitch As Variant
    Dim vType As Variant
    Dim vSisSeq As Variant
    Dim vSisElem As Variant
    Dim vNotes As Variant

    Set wsIO = FirstExistingSheet(ThisWorkbook, Array("IO_DEVICE_LIST", "IO_Device_List", "IO Device List", "IO_DEVICE_LST"))
    If wsIO Is Nothing Then
        AppendLog "PD6_Backfill_PD6_From_IO_DEVICE_LIST", "WARNING", "IO_DEVICE_LIST sheet not found. PD6 backfill skipped."
        Exit Sub
    End If

    lastPD6 = LastUsedRow(wsPD6)
    lastIO = LastUsedRow(wsIO)
    If lastPD6 < 2 Or lastIO < 2 Then Exit Sub

    cArea = PD6_HeaderCol(wsPD6, "AREA_Number", "AREA_NUMBER", "Area Number")
    cSwitch = PD6_HeaderCol(wsPD6, "SwitchGroup", "SWITCHGROUP", "PWG")
    cType = PD6_HeaderCol(wsPD6, "TYPE", "Device Type", "TYPE/DESC")
    cSisSeq = PD6_HeaderCol(wsPD6, "SIS_sequence", "SIS_SEQUENCE", "Sequence")
    cSisElem = PD6_HeaderCol(wsPD6, "SIS_Element_Number", "SIS_ELEMENT_NUMBER", "SIS Element Number")
    cNotes = PD6_HeaderCol(wsPD6, "NOTES", "Notes")

    cIOBlock = PD6_HeaderColPreferBlockID(wsIO)
    cIODevice = PD6_HeaderColPreferDevice(wsIO)
    cIOPWG = PD6_HeaderCol(wsIO, "PWG", "SwitchGroup", "SWITCHGROUP")
    cIOLoc = PD6_HeaderCol(wsIO, "Location", "LOCATION", "AREA_Number", "AREA_NUMBER", "Area Number")

    If cArea = 0 Or cSwitch = 0 Or cType = 0 Or cSisSeq = 0 Or cSisElem = 0 Then
        Err.Raise vbObjectError + 545, , "PD6_IMPORT is missing AREA_Number, SwitchGroup, TYPE, SIS_sequence, or SIS_Element_Number header."
    End If

    If cIOPWG = 0 Or cIOLoc = 0 Then
        AppendLog "PD6_Backfill_PD6_From_IO_DEVICE_LIST", "WARNING", "IO_DEVICE_LIST missing PWG or Location. PD6 backfill skipped."
        Exit Sub
    End If

    ioCount = lastIO - 1&
    vIOBlock = PD6_ReadColumnFast(wsIO, lastIO, cIOBlock)
    vIODevice = PD6_ReadColumnFast(wsIO, lastIO, cIODevice)
    vIOPWG = PD6_ReadColumnFast(wsIO, lastIO, cIOPWG)
    vIOLoc = PD6_ReadColumnFast(wsIO, lastIO, cIOLoc)

    Set dictBlock = CreateObject("Scripting.Dictionary")
    Set dictDevice = CreateObject("Scripting.Dictionary")
    dictBlock.CompareMode = vbTextCompare
    dictDevice.CompareMode = vbTextCompare

    If cIOBlock > 0 Then
        For idx = 1 To ioCount
            keyText = PD6_LookupKey(PD6_ArrayValueFast(vIOBlock, idx))
            If Len(keyText) > 0 Then
                dictBlock(keyText) = Array(PD6_ArrayTextFast(vIOLoc, idx), PD6_ArrayTextFast(vIOPWG, idx))
            End If
        Next idx
    End If

    If cIODevice > 0 Then
        For idx = 1 To ioCount
            keyText = PD6_LookupKey(PD6_ArrayValueFast(vIODevice, idx))
            If Len(keyText) > 0 Then
                dictDevice(keyText) = Array(PD6_ArrayTextFast(vIOLoc, idx), PD6_ArrayTextFast(vIOPWG, idx))
            End If
        Next idx
    End If

    pd6Count = lastPD6 - 1&
    vArea = PD6_ReadColumnFast(wsPD6, lastPD6, cArea)
    vSwitch = PD6_ReadColumnFast(wsPD6, lastPD6, cSwitch)
    vType = PD6_ReadColumnFast(wsPD6, lastPD6, cType)
    vSisSeq = PD6_ReadColumnFast(wsPD6, lastPD6, cSisSeq)
    vSisElem = PD6_ReadColumnFast(wsPD6, lastPD6, cSisElem)
    vNotes = PD6_ReadColumnFast(wsPD6, lastPD6, cNotes)

    For idx = 1 To pd6Count
        rowNum = idx + 1&
        typeVal = UCase$(PD6_ArrayTextFast(vType, idx))
        sisSeqVal = PD6_ArrayTextFast(vSisSeq, idx)
        sisElemVal = PD6_ArrayTextFast(vSisElem, idx)
        areaVal = PD6_ArrayTextFast(vArea, idx)
        switchVal = PD6_ArrayTextFast(vSwitch, idx)

        If PD6_IsIOType(typeVal) Then
            If Len(areaVal) = 0 Or Len(switchVal) = 0 Then
                lookupVal = PD6_FindIOBlockBackfill(dictBlock, dictDevice, sisSeqVal, sisElemVal)
                If IsArray(lookupVal) Then
                    ioArea = CStr(lookupVal(0))
                    ioSwitch = CStr(lookupVal(1))
                    If Len(areaVal) = 0 And Len(ioArea) > 0 Then
                        wsPD6.Cells(rowNum, cArea).Value2 = ioArea
                        vArea(idx, 1) = ioArea
                        areaVal = ioArea
                        didBackfill = True
                    End If
                    If Len(switchVal) = 0 And Len(ioSwitch) > 0 Then
                        wsPD6.Cells(rowNum, cSwitch).Value2 = ioSwitch
                        vSwitch(idx, 1) = ioSwitch
                        switchVal = ioSwitch
                        didBackfill = True
                    End If
                Else
                    newNote = vNotes(idx, 1)
                    PD6_AppendNoteValueFast newNote, "Missing AREA/SwitchGroup; no matching IO_DEVICE_LIST Block ID found."
                    If CStr(newNote) <> PD6_ArrayTextFast(vNotes, idx) Then
                        vNotes(idx, 1) = newNote
                        If cNotes > 0 Then wsPD6.Cells(rowNum, cNotes).Value2 = newNote
                    End If
                End If
            End If

            If Len(areaVal) > 0 And Len(switchVal) > 0 And Len(sisSeqVal) > 0 Then
                sisElemVal = PD6_BuildIOElementFromType(areaVal, switchVal, sisSeqVal, typeVal)
                If Len(sisElemVal) > 0 Then
                    If StrComp(PD6_ArrayTextFast(vSisElem, idx), sisElemVal, vbTextCompare) <> 0 Then
                        wsPD6.Cells(rowNum, cSisElem).Value2 = sisElemVal
                        vSisElem(idx, 1) = sisElemVal
                        didBackfill = True
                    End If
                End If
            Else
                newNote = vNotes(idx, 1)
                PD6_AppendNoteValueFast newNote, "SIS_Element_Number not built; AREA_Number, SwitchGroup, or SIS_sequence is blank."
                If CStr(newNote) <> PD6_ArrayTextFast(vNotes, idx) Then
                    vNotes(idx, 1) = newNote
                    If cNotes > 0 Then wsPD6.Cells(rowNum, cNotes).Value2 = newNote
                End If
            End If

        ElseIf PD6_IsDeviceLookupType(typeVal) Then
            If Len(areaVal) = 0 Or Len(switchVal) = 0 Then
                lookupVal = PD6_FindDeviceBackfill(dictDevice, sisSeqVal, sisElemVal)
                If IsArray(lookupVal) Then
                    ioArea = CStr(lookupVal(0))
                    ioSwitch = CStr(lookupVal(1))
                    If Len(areaVal) = 0 And Len(ioArea) > 0 Then
                        wsPD6.Cells(rowNum, cArea).Value2 = ioArea
                        vArea(idx, 1) = ioArea
                        areaVal = ioArea
                        didBackfill = True
                    End If
                    If Len(switchVal) = 0 And Len(ioSwitch) > 0 Then
                        wsPD6.Cells(rowNum, cSwitch).Value2 = ioSwitch
                        vSwitch(idx, 1) = ioSwitch
                        switchVal = ioSwitch
                        didBackfill = True
                    End If
                Else
                    newNote = vNotes(idx, 1)
                    PD6_AppendNoteValueFast newNote, "Missing AREA/SwitchGroup; no matching IO_DEVICE_LIST Device found."
                    If CStr(newNote) <> PD6_ArrayTextFast(vNotes, idx) Then
                        vNotes(idx, 1) = newNote
                        If cNotes > 0 Then wsPD6.Cells(rowNum, cNotes).Value2 = newNote
                    End If
                End If
            End If

            If Len(areaVal) > 0 And Len(switchVal) > 0 And Len(sisSeqVal) > 0 Then
                sisElemVal = PD6_BuildBaseElement(areaVal, switchVal, sisSeqVal)
                If Len(sisElemVal) > 0 Then
                    If StrComp(PD6_ArrayTextFast(vSisElem, idx), sisElemVal, vbTextCompare) <> 0 Then
                        wsPD6.Cells(rowNum, cSisElem).Value2 = sisElemVal
                        vSisElem(idx, 1) = sisElemVal
                        didBackfill = True
                    End If
                End If
            Else
                newNote = vNotes(idx, 1)
                PD6_AppendNoteValueFast newNote, "SIS_Element_Number not built; AREA_Number, SwitchGroup, or SIS_sequence is blank."
                If CStr(newNote) <> PD6_ArrayTextFast(vNotes, idx) Then
                    vNotes(idx, 1) = newNote
                    If cNotes > 0 Then wsPD6.Cells(rowNum, cNotes).Value2 = newNote
                End If
            End If
        End If
    Next idx

    If didBackfill Then
        AppendLog "PD6_Backfill_PD6_From_IO_DEVICE_LIST", "OK", "Missing AREA_Number, SwitchGroup, and SIS_Element_Number values backfilled from IO_DEVICE_LIST."
    Else
        AppendLog "PD6_Backfill_PD6_From_IO_DEVICE_LIST", "OK", "No missing PD6 values required IO_DEVICE_LIST backfill."
    End If
End Sub

Private Function PD6_FindIOBlockBackfill(ByVal dictBlock As Object, ByVal dictDevice As Object, ByVal sisSeqVal As String, ByVal sisElemVal As String) As Variant

    Dim k As String
    Dim candidate As Variant
    Dim candidates As Collection

    Set candidates = New Collection
    PD6_AddCandidate candidates, sisSeqVal
    PD6_AddCandidate candidates, sisElemVal
    PD6_AddCandidate candidates, PD6_ExtractSequenceFromElement(sisElemVal)

    For Each candidate In candidates
        k = PD6_LookupKey(candidate)
        If Len(k) > 0 Then
            If dictBlock.Exists(k) Then
                PD6_FindIOBlockBackfill = dictBlock(k)
                Exit Function
            End If
        End If
    Next candidate

    For Each candidate In candidates
        k = PD6_LookupKey(candidate)
        If Len(k) > 0 Then
            If dictDevice.Exists(k) Then
                PD6_FindIOBlockBackfill = dictDevice(k)
                Exit Function
            End If
        End If
    Next candidate

    PD6_FindIOBlockBackfill = Empty

End Function

Private Function PD6_FindDeviceBackfill(ByVal dictDevice As Object, ByVal sisSeqVal As String, ByVal sisElemVal As String) As Variant

    Dim k As String
    Dim candidate As Variant
    Dim candidates As Collection

    Set candidates = New Collection
    PD6_AddCandidate candidates, sisSeqVal
    PD6_AddCandidate candidates, sisElemVal
    PD6_AddCandidate candidates, PD6_ExtractSequenceFromElement(sisElemVal)

    For Each candidate In candidates
        k = PD6_LookupKey(candidate)
        If Len(k) > 0 Then
            If dictDevice.Exists(k) Then
                PD6_FindDeviceBackfill = dictDevice(k)
                Exit Function
            End If
        End If
    Next candidate

    PD6_FindDeviceBackfill = Empty

End Function

Private Sub PD6_AddCandidate(ByVal candidates As Collection, ByVal valueIn As Variant)

    Dim s As String
    Dim normalizedIO As String

    s = Trim$(CStr(valueIn))
    If Len(s) = 0 Then Exit Sub

    PD6_AddCandidateOne candidates, s

    normalizedIO = PD6_NormalizeIOSequenceInstance(s)
    If Len(normalizedIO) > 0 Then
        If StrComp(normalizedIO, s, vbTextCompare) <> 0 Then
            PD6_AddCandidateOne candidates, normalizedIO
        End If
    End If

End Sub

Private Sub PD6_AddCandidateOne(ByVal candidates As Collection, ByVal valueIn As String)

    Dim s As String
    Dim item As Variant

    s = Trim$(CStr(valueIn))
    If Len(s) = 0 Then Exit Sub

    For Each item In candidates
        If StrComp(CStr(item), s, vbTextCompare) = 0 Then Exit Sub
    Next item

    candidates.Add s

End Sub

Private Function PD6_NormalizeIOSequenceInstance(ByVal valueIn As Variant) As String

    Dim s As String
    Dim u As String
    Dim p As Long
    Dim suffixText As String

    s = Trim$(CStr(valueIn))
    If Len(s) = 0 Then Exit Function

    u = UCase$(Replace(s, "_", "/"))

    If InStr(1, u, "-IO/D-", vbTextCompare) > 0 Then
        p = InStrRev(u, "-IO/D-")
        suffixText = mid$(s, p + Len("-IO/D-"))
        If PD6_IsPositiveIntegerText(suffixText) Then
            PD6_NormalizeIOSequenceInstance = Left$(s, p + Len("-IO/D") - 1)
            Exit Function
        End If
    End If

    If InStr(1, u, "-IO/S-", vbTextCompare) > 0 Then
        p = InStrRev(u, "-IO/S-")
        suffixText = mid$(s, p + Len("-IO/S-"))
        If PD6_IsPositiveIntegerText(suffixText) Then
            PD6_NormalizeIOSequenceInstance = Left$(s, p + Len("-IO/S") - 1)
            Exit Function
        End If
    End If

    If InStr(1, u, "-I/O/D-", vbTextCompare) > 0 Then
        p = InStrRev(u, "-I/O/D-")
        suffixText = mid$(s, p + Len("-I/O/D-"))
        If PD6_IsPositiveIntegerText(suffixText) Then
            PD6_NormalizeIOSequenceInstance = Left$(s, p + Len("-I/O/D") - 1)
            Exit Function
        End If
    End If

    If InStr(1, u, "-I/O/S-", vbTextCompare) > 0 Then
        p = InStrRev(u, "-I/O/S-")
        suffixText = mid$(s, p + Len("-I/O/S-"))
        If PD6_IsPositiveIntegerText(suffixText) Then
            PD6_NormalizeIOSequenceInstance = Left$(s, p + Len("-I/O/S") - 1)
            Exit Function
        End If
    End If

    PD6_NormalizeIOSequenceInstance = s

End Function

Private Function PD6_IsPositiveIntegerText(ByVal valueIn As String) As Boolean

    Dim i As Long
    Dim ch As String
    Dim s As String

    s = Trim$(valueIn)
    If Len(s) = 0 Then Exit Function

    For i = 1 To Len(s)
        ch = mid$(s, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i

    PD6_IsPositiveIntegerText = True

End Function

Private Function PD6_LookupKey(ByVal valueIn As Variant) As String

    Dim s As String

    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace(s, Chr$(160), " ")
    s = Replace(s, " ", "")
    s = Replace(s, "_", "/")

    PD6_LookupKey = s

End Function

Private Function PD6_ExtractSequenceFromElement(ByVal sisElemVal As String) As String

    Dim s As String
    Dim parts() As String
    Dim n As Long
    Dim i As Long
    Dim lastIdx As Long
    Dim outText As String

    s = Trim$(sisElemVal)
    If Len(s) = 0 Then Exit Function

    parts = Split(s, "-")
    n = UBound(parts)

    If n >= 2 Then
        lastIdx = n
        If UCase$(Left$(Trim$(parts(n)), 1)) = "K" And n >= 3 Then lastIdx = n - 1

        For i = 2 To lastIdx
            If Len(outText) > 0 Then outText = outText & "-"
            outText = outText & Trim$(parts(i))
        Next i

        PD6_ExtractSequenceFromElement = outText
    Else
        PD6_ExtractSequenceFromElement = s
    End If

End Function

Private Function PD6_IsIOType(ByVal typeVal As String) As Boolean

    Dim t As String
    t = UCase$(Trim$(typeVal))
    t = Replace(t, " ", "")
    t = Replace(t, "_", "/")
    t = Replace(t, "-", "/")

    PD6_IsIOType = (Left$(t, 2) = "IO" Or Left$(t, 3) = "I/O")

End Function

Private Function PD6_IsDeviceLookupType(ByVal typeVal As String) As Boolean

    Dim t As String
    t = UCase$(Trim$(typeVal))
    t = Replace(t, " ", "")
    t = Replace(t, "_", "-")

    PD6_IsDeviceLookupType = False

    If t = "PBL" Or Left$(t, 3) = "PBL" Then PD6_IsDeviceLookupType = True
    If t = "SCN" Or Left$(t, 3) = "SCN" Then PD6_IsDeviceLookupType = True
    If t = "B" Or Left$(t, 1) = "B" Then PD6_IsDeviceLookupType = True
    If t = "BA" Or Left$(t, 2) = "BA" Then PD6_IsDeviceLookupType = True
    If t = "LT" Or Left$(t, 2) = "LT" Then PD6_IsDeviceLookupType = True
    If t = "EST" Or Left$(t, 3) = "EST" Then PD6_IsDeviceLookupType = True
    If t = "EPC" Or Left$(t, 3) = "EPC" Then PD6_IsDeviceLookupType = True
    If t = "VFD" Or Left$(t, 3) = "VFD" Then PD6_IsDeviceLookupType = True

End Function

Private Function PD6_BuildIOElementFromType(ByVal areaVal As String, ByVal switchVal As String, ByVal sisSeqVal As String, ByVal typeVal As String) As String

    Dim baseID As String
    Dim kSuffix As String

    baseID = PD6_BuildBaseElement(areaVal, switchVal, sisSeqVal)
    If Len(baseID) = 0 Then Exit Function

    kSuffix = PD6_GetConfiguredOrDefaultKSuffix(baseID, typeVal, False)

    If Len(kSuffix) > 0 Then
        PD6_BuildIOElementFromType = PD6_AppendKSuffixIfNeeded(baseID, kSuffix)
    Else
        PD6_BuildIOElementFromType = baseID
    End If

End Function

Private Function PD6_BuildBaseElement(ByVal areaVal As String, ByVal switchVal As String, ByVal sisSeqVal As String) As String

    If Len(Trim$(sisSeqVal)) = 0 Then Exit Function

    PD6_BuildBaseElement = Trim$(areaVal) & "-" & Trim$(switchVal) & "-" & Trim$(sisSeqVal)

End Function

Private Function PD6_AppendKSuffixIfNeeded(ByVal baseID As String, ByVal kSuffix As String) As String

    Dim cleanBase As String
    Dim cleanSuffix As String

    cleanBase = Trim$(baseID)
    cleanSuffix = UCase$(Trim$(kSuffix))

    If Len(cleanBase) = 0 Then Exit Function
    If Len(cleanSuffix) = 0 Then
        PD6_AppendKSuffixIfNeeded = cleanBase
        Exit Function
    End If

    If Left$(cleanSuffix, 1) = "-" Then cleanSuffix = mid$(cleanSuffix, 2)

    If PD6_EndsWithKSuffix(cleanBase) Then
        PD6_AppendKSuffixIfNeeded = cleanBase
    Else
        PD6_AppendKSuffixIfNeeded = cleanBase & "-" & cleanSuffix
    End If

End Function

Private Function PD6_EndsWithKSuffix(ByVal valueText As String) As Boolean

    Dim s As String
    Dim lastDash As Long
    Dim lastPart As String

    s = Trim$(valueText)
    If Len(s) = 0 Then Exit Function

    lastDash = InStrRev(s, "-")
    If lastDash = 0 Or lastDash = Len(s) Then Exit Function

    lastPart = UCase$(Trim$(mid$(s, lastDash + 1)))

    PD6_EndsWithKSuffix = (Left$(lastPart, 1) = "K")

End Function

Private Sub PD6_Backfill_PNL_From_IO_BLOCK_GENERATOR(ByVal wsPD6 As Worksheet)

    Dim wsIOBlock As Worksheet
    Dim lastPD6 As Long
    Dim lastIO As Long
    Dim pd6Count As Long
    Dim ioCount As Long
    Dim idx As Long
    Dim rowNum As Long
    Dim switchKey As String
    Dim pnlVal As String
    Dim existingPnl As String
    Dim newNote As Variant
    Dim dictPanelByPWG As Object
    Dim dictConflictByPWG As Object

    Dim cPD6Switch As Long
    Dim cPD6PNL As Long
    Dim cNotes As Long
    Dim cIOPWG As Long
    Dim cIOPanel As Long

    Dim vPD6Switch As Variant
    Dim vPD6PNL As Variant
    Dim vNotes As Variant
    Dim vIOPWG As Variant
    Dim vIOPanel As Variant

    Set wsIOBlock = FirstExistingSheet(ThisWorkbook, Array("IO_BLOCK_GENERATOR", "IO Block Generator", "IO_BLOCK_GEN", "IO BLOCK GENERATOR"))
    If wsIOBlock Is Nothing Then
        AppendLog "PD6_Backfill_PNL_From_IO_BLOCK_GENERATOR", "WARNING", "IO_BLOCK_GENERATOR sheet not found. PNL backfill skipped."
        Exit Sub
    End If

    lastPD6 = LastUsedRow(wsPD6)
    lastIO = LastUsedRow(wsIOBlock)
    If lastPD6 < 2 Or lastIO < 2 Then Exit Sub

    cPD6Switch = PD6_HeaderCol(wsPD6, "SwitchGroup", "SWITCHGROUP", "PWG")
    cPD6PNL = PD6_HeaderCol(wsPD6, "PNL", "Panel", "PANEL")
    cNotes = PD6_HeaderCol(wsPD6, "NOTES", "Notes")
    cIOPWG = PD6_HeaderCol(wsIOBlock, "PWG", "SwitchGroup", "SWITCHGROUP")
    cIOPanel = PD6_HeaderCol(wsIOBlock, "Panel", "PNL", "PANEL")

    If cPD6Switch = 0 Or cPD6PNL = 0 Then
        AppendLog "PD6_Backfill_PNL_From_IO_BLOCK_GENERATOR", "WARNING", "PD6_IMPORT missing SwitchGroup or PNL header. PNL backfill skipped."
        Exit Sub
    End If

    If cIOPWG = 0 Or cIOPanel = 0 Then
        AppendLog "PD6_Backfill_PNL_From_IO_BLOCK_GENERATOR", "WARNING", "IO_BLOCK_GENERATOR missing PWG or Panel header. PNL backfill skipped."
        Exit Sub
    End If

    ioCount = lastIO - 1&
    vIOPWG = PD6_ReadColumnFast(wsIOBlock, lastIO, cIOPWG)
    vIOPanel = PD6_ReadColumnFast(wsIOBlock, lastIO, cIOPanel)

    Set dictPanelByPWG = CreateObject("Scripting.Dictionary")
    Set dictConflictByPWG = CreateObject("Scripting.Dictionary")
    dictPanelByPWG.CompareMode = vbTextCompare
    dictConflictByPWG.CompareMode = vbTextCompare

    For idx = 1 To ioCount
        switchKey = PD6_LookupKey(PD6_ArrayValueFast(vIOPWG, idx))
        pnlVal = PD6_ArrayTextFast(vIOPanel, idx)
        If Len(switchKey) > 0 And Len(pnlVal) > 0 Then
            If Not dictPanelByPWG.Exists(switchKey) Then
                dictPanelByPWG.Add switchKey, pnlVal
            ElseIf StrComp(CStr(dictPanelByPWG(switchKey)), pnlVal, vbTextCompare) <> 0 Then
                dictConflictByPWG(switchKey) = True
            End If
        End If
    Next idx

    pd6Count = lastPD6 - 1&
    vPD6Switch = PD6_ReadColumnFast(wsPD6, lastPD6, cPD6Switch)
    vPD6PNL = PD6_ReadColumnFast(wsPD6, lastPD6, cPD6PNL)
    vNotes = PD6_ReadColumnFast(wsPD6, lastPD6, cNotes)

    For idx = 1 To pd6Count
        rowNum = idx + 1&
        switchKey = PD6_LookupKey(PD6_ArrayValueFast(vPD6Switch, idx))
        If Len(switchKey) > 0 And dictPanelByPWG.Exists(switchKey) Then
            pnlVal = CStr(dictPanelByPWG(switchKey))
            existingPnl = PD6_ArrayTextFast(vPD6PNL, idx)

            If Len(existingPnl) = 0 Then
                wsPD6.Cells(rowNum, cPD6PNL).Value2 = pnlVal
                vPD6PNL(idx, 1) = pnlVal
                existingPnl = pnlVal
            ElseIf StrComp(existingPnl, pnlVal, vbTextCompare) <> 0 Then
                newNote = vNotes(idx, 1)
                PD6_AppendNoteValueFast newNote, "PNL differs from IO_BLOCK_GENERATOR for PWG " & _
                    PD6_ArrayTextFast(vPD6Switch, idx) & "; kept existing PNL " & existingPnl & "."
                If CStr(newNote) <> PD6_ArrayTextFast(vNotes, idx) Then
                    vNotes(idx, 1) = newNote
                    If cNotes > 0 Then wsPD6.Cells(rowNum, cNotes).Value2 = newNote
                End If
            End If

            If dictConflictByPWG.Exists(switchKey) Then
                newNote = vNotes(idx, 1)
                PD6_AppendNoteValueFast newNote, "Multiple Panel values found in IO_BLOCK_GENERATOR for PWG " & _
                    PD6_ArrayTextFast(vPD6Switch, idx) & "; used first Panel " & pnlVal & "."
                If CStr(newNote) <> PD6_ArrayTextFast(vNotes, idx) Then
                    vNotes(idx, 1) = newNote
                    If cNotes > 0 Then wsPD6.Cells(rowNum, cNotes).Value2 = newNote
                End If
            End If
        End If
    Next idx

    AppendLog "PD6_Backfill_PNL_From_IO_BLOCK_GENERATOR", "OK", "PNL values checked against IO_BLOCK_GENERATOR PWG/Panel mapping."
End Sub

Private Sub PD6_Collapse_Existing_SplitBusRows(ByVal ws As Worksheet)

    Dim lastRow As Long
    Dim rowCount As Long
    Dim r As Long
    Dim idx As Long
    Dim deleteCount As Long
    Dim batchCount As Long
    Dim keyText As String
    Dim typeVal As String
    Dim seen As Object
    Dim rowsToDelete() As Long
    Dim deleteRange As Range

    Dim cType As Long
    Dim cSisSeq As Long
    Dim cArea As Long
    Dim cSwitch As Long

    Dim vType As Variant
    Dim vSisSeq As Variant
    Dim vArea As Variant
    Dim vSwitch As Variant

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then Exit Sub

    cType = PD6_HeaderCol(ws, "TYPE", "Device Type", "TYPE/DESC")
    cSisSeq = PD6_HeaderCol(ws, "SIS_sequence", "SIS_SEQUENCE", "Sequence")
    cArea = PD6_HeaderCol(ws, "AREA_Number", "AREA_NUMBER")
    cSwitch = PD6_HeaderCol(ws, "SwitchGroup", "SWITCHGROUP", "PWG")

    If cType = 0 Or cSisSeq = 0 Then Exit Sub

    rowCount = lastRow - 1&
    vType = PD6_ReadColumnFast(ws, lastRow, cType)
    vSisSeq = PD6_ReadColumnFast(ws, lastRow, cSisSeq)
    vArea = PD6_ReadColumnFast(ws, lastRow, cArea)
    vSwitch = PD6_ReadColumnFast(ws, lastRow, cSwitch)

    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    ReDim rowsToDelete(1 To rowCount)

    For idx = 1 To rowCount
        typeVal = UCase$(Trim$(PD6_ArrayTextFast(vType, idx)))
        keyText = PD6_UniquePowerSequenceKeyValues( _
            typeVal, PD6_ArrayTextFast(vSisSeq, idx), _
            PD6_ArrayTextFast(vArea, idx), PD6_ArrayTextFast(vSwitch, idx))

        If Len(keyText) > 0 Then
            If seen.Exists(keyText) Then
                deleteCount = deleteCount + 1&
                rowsToDelete(deleteCount) = idx + 1&
            Else
                seen.Add keyText, idx + 1&
            End If
        End If
    Next idx

    For idx = deleteCount To 1 Step -1
        r = rowsToDelete(idx)
        If deleteRange Is Nothing Then
            Set deleteRange = ws.rows(r)
        Else
            Set deleteRange = Union(deleteRange, ws.rows(r))
        End If
        batchCount = batchCount + 1&

        If batchCount >= 200 Or idx = 1 Then
            deleteRange.EntireRow.Delete
            Set deleteRange = Nothing
            batchCount = 0&
        End If
    Next idx

    If deleteCount > 0 Then
        AppendLog "PD6_Collapse_Existing_SplitBusRows", "OK", _
                  CStr(deleteCount) & " duplicate power-device SIS_sequence row(s) removed."
    End If

End Sub

Private Sub PD6_Split_CombinedBusRows(ByVal ws As Worksheet)

    PD6_Collapse_Existing_SplitBusRows ws
    PD6_ValidateUniqueSISSequenceRows ws

End Sub

Private Function PD6_UniquePowerSequenceKeyValues(ByVal typeValue As String, _
                                                   ByVal sisSequence As String, _
                                                   ByVal areaValue As String, _
                                                   ByVal switchValue As String) As String

    Dim sequenceKey As String

    If Not PD6_TypeHasDataPower24VRule(typeValue) Then Exit Function

    sequenceKey = PD6_LookupKey(sisSequence)
    If Len(sequenceKey) = 0 Then Exit Function

    PD6_UniquePowerSequenceKeyValues = _
        "|A=" & PD6_LookupKey(areaValue) & _
        "|G=" & PD6_LookupKey(switchValue) & _
        "|S=" & sequenceKey

End Function

Private Sub PD6_ValidateUniqueSISSequenceRows(ByVal ws As Worksheet)

    Dim lastRow As Long
    Dim rowCount As Long
    Dim idx As Long
    Dim duplicateCount As Long
    Dim keyText As String
    Dim typeVal As String
    Dim exampleText As String
    Dim seen As Object

    Dim cType As Long
    Dim cSisSeq As Long
    Dim cArea As Long
    Dim cSwitch As Long

    Dim vType As Variant
    Dim vSisSeq As Variant
    Dim vArea As Variant
    Dim vSwitch As Variant

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then Exit Sub

    cType = PD6_HeaderCol(ws, "TYPE", "Device Type", "TYPE/DESC")
    cSisSeq = PD6_HeaderCol(ws, "SIS_sequence", "SIS_SEQUENCE", "Sequence")
    cArea = PD6_HeaderCol(ws, "AREA_Number", "AREA_NUMBER")
    cSwitch = PD6_HeaderCol(ws, "SwitchGroup", "SWITCHGROUP", "PWG")

    If cType = 0 Or cSisSeq = 0 Then Exit Sub

    rowCount = lastRow - 1&
    vType = PD6_ReadColumnFast(ws, lastRow, cType)
    vSisSeq = PD6_ReadColumnFast(ws, lastRow, cSisSeq)
    vArea = PD6_ReadColumnFast(ws, lastRow, cArea)
    vSwitch = PD6_ReadColumnFast(ws, lastRow, cSwitch)

    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    For idx = 1 To rowCount
        typeVal = UCase$(Trim$(PD6_ArrayTextFast(vType, idx)))
        keyText = PD6_UniquePowerSequenceKeyValues( _
            typeVal, PD6_ArrayTextFast(vSisSeq, idx), _
            PD6_ArrayTextFast(vArea, idx), PD6_ArrayTextFast(vSwitch, idx))

        If Len(keyText) > 0 Then
            If seen.Exists(keyText) Then
                duplicateCount = duplicateCount + 1&
                If duplicateCount <= 5 Then
                    If Len(exampleText) > 0 Then exampleText = exampleText & ", "
                    exampleText = exampleText & PD6_ArrayTextFast(vSisSeq, idx)
                End If
            Else
                seen.Add keyText, idx + 1&
            End If
        End If
    Next idx

    If duplicateCount > 0 Then
        Err.Raise vbObjectError + 596, "PD6_ValidateUniqueSISSequenceRows", _
                  CStr(duplicateCount) & _
                  " duplicate 24V power-device SIS_sequence row(s) remain in PD6_IMPORT." & _
                  IIf(Len(exampleText) > 0, " Examples: " & exampleText, vbNullString)
    End If

End Sub

Private Function PD6_RowIdentityKey(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal cType As Long, ByVal cSisSeq As Long, ByVal cSisElem As Long, ByVal cArea As Long, ByVal cSwitch As Long) As String

    Dim keyText As String

    keyText = ""
    If cType > 0 Then keyText = keyText & "|T=" & PD6_LookupKey(ws.Cells(rowNum, cType).value)
    If cSisSeq > 0 Then keyText = keyText & "|S=" & PD6_LookupKey(ws.Cells(rowNum, cSisSeq).value)
    If cSisElem > 0 Then keyText = keyText & "|E=" & PD6_LookupKey(ws.Cells(rowNum, cSisElem).value)
    If cArea > 0 Then keyText = keyText & "|A=" & PD6_LookupKey(ws.Cells(rowNum, cArea).value)
    If cSwitch > 0 Then keyText = keyText & "|G=" & PD6_LookupKey(ws.Cells(rowNum, cSwitch).value)

    PD6_RowIdentityKey = keyText

End Function

Private Function PD6_RowHasBothBuses(ByVal busText As String, ByVal psuText As String) As Boolean

    Dim combinedText As String
    combinedText = UCase$(busText & " " & psuText)

    PD6_RowHasBothBuses = (InStr(1, combinedText, "BUS-1", vbTextCompare) > 0 And _
                           InStr(1, combinedText, "BUS-2", vbTextCompare) > 0)

End Function

Private Function PD6_GetSingleBusPSU(ByVal psuText As String, ByVal busLabel As String) As String

    Dim v As String

    v = PD6_GetPSUForBus(psuText, busLabel)
    If Len(v) = 0 Then v = PD6_RemoveBusLabels(psuText)

    PD6_GetSingleBusPSU = v

End Function

Private Function PD6_GetPSUForBus(ByVal psuText As String, ByVal busLabel As String) As String

    Dim parts() As String
    Dim i As Long
    Dim itemText As String
    Dim prefixText As String
    Dim eqPos As Long

    psuText = Trim$(psuText)
    prefixText = UCase$(busLabel) & "="

    If Len(psuText) = 0 Then Exit Function

    parts = Split(psuText, "|")
    For i = LBound(parts) To UBound(parts)
        itemText = Trim$(parts(i))
        If InStr(1, UCase$(itemText), prefixText, vbTextCompare) = 1 Then
            eqPos = InStr(1, itemText, "=", vbTextCompare)
            If eqPos > 0 Then
                PD6_GetPSUForBus = Trim$(mid$(itemText, eqPos + 1))
                Exit Function
            End If
        End If
    Next i

End Function

Private Function PD6_RemoveBusLabels(ByVal psuText As String) As String

    Dim resultText As String
    Dim parts() As String
    Dim i As Long
    Dim itemText As String
    Dim eqPos As Long

    resultText = ""
    psuText = Trim$(psuText)
    If Len(psuText) = 0 Then
        PD6_RemoveBusLabels = ""
        Exit Function
    End If

    parts = Split(psuText, "|")
    For i = LBound(parts) To UBound(parts)
        itemText = Trim$(parts(i))
        eqPos = InStr(1, itemText, "=", vbTextCompare)
        If eqPos > 0 Then
            itemText = Trim$(mid$(itemText, eqPos + 1))
        End If
        If Len(itemText) > 0 Then
            If Len(resultText) = 0 Then
                resultText = itemText
            ElseIf InStr(1, "|" & UCase$(resultText) & "|", "|" & UCase$(itemText) & "|", vbTextCompare) = 0 Then
                resultText = resultText & " | " & itemText
            End If
        End If
    Next i

    PD6_RemoveBusLabels = resultText

End Function
Private Sub PD6_Recalculate_LoadBusColumns(ByVal ws As Worksheet, Optional ByVal preserveMainLoad As Boolean = False)

    Dim lastRow As Long
    Dim rowCount As Long
    Dim idx As Long
    Dim cType As Long
    Dim cConv As Long
    Dim cSys As Long
    Dim cVolt As Long
    Dim cMotorPower As Long
    Dim cDrives As Long
    Dim cLoad As Long
    Dim cLoadBus1 As Long
    Dim cLoadBus2 As Long
    Dim typeVal As String
    Dim convVal As String
    Dim sysVal As String
    Dim voltVal As String
    Dim sourceLoad As String
    Dim dataLoad As String
    Dim combinedVoltageText As String
    Dim motorPower As Double
    Dim motorVolt As Double
    Dim totalDrives As Double
    Dim loadValue As Variant
    Dim bus1Val As Variant
    Dim bus2Val As Variant

    Dim vType As Variant
    Dim vConv As Variant
    Dim vSys As Variant
    Dim vVolt As Variant
    Dim vMotorPower As Variant
    Dim vDrives As Variant
    Dim vLoad As Variant
    Dim outLoad() As Variant
    Dim outBus1() As Variant
    Dim outBus2() As Variant

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then Exit Sub

    cType = PD6_HeaderCol(ws, "TYPE", "Device Type", "TYPE/DESC")
    cConv = PD6_HeaderCol(ws, "Conveyor Type", "CONVEYOR TYPE")
    cSys = PD6_HeaderCol(ws, "System Type", "SYSTEM TYPE")
    cVolt = PD6_HeaderCol(ws, "Motor Voltage (Main Drive)", "MOTOR VOLTAGE (MAIN DRIVE)", "Motor Voltage")
    cMotorPower = PD6_HeaderCol(ws, "Motor Power (Main Drive)", "MOTOR POWER (MAIN DRIVE)", "Motor Power")
    cDrives = PD6_HeaderCol(ws, "Total Qty of Drives", "TOTAL QTY OF DRIVES", "Qty of Drives")
    cLoad = PD6_HeaderCol(ws, "Load", "CURRENT_LOAD")
    cLoadBus1 = PD6_HeaderCol(ws, "Load BUS-1", "LOAD BUS 1", "Load Bus1")
    cLoadBus2 = PD6_HeaderCol(ws, "Load BUS-2", "LOAD BUS 2", "Load Bus2")

    If cType = 0 Or cLoadBus1 = 0 Or cLoadBus2 = 0 Then Exit Sub

    rowCount = lastRow - 1&
    vType = PD6_ReadColumnFast(ws, lastRow, cType)
    vConv = PD6_ReadColumnFast(ws, lastRow, cConv)
    vSys = PD6_ReadColumnFast(ws, lastRow, cSys)
    vVolt = PD6_ReadColumnFast(ws, lastRow, cVolt)
    vMotorPower = PD6_ReadColumnFast(ws, lastRow, cMotorPower)
    vDrives = PD6_ReadColumnFast(ws, lastRow, cDrives)
    vLoad = PD6_ReadColumnFast(ws, lastRow, cLoad)

    ReDim outBus1(1 To rowCount, 1 To 1)
    ReDim outBus2(1 To rowCount, 1 To 1)
    If cLoad > 0 And Not preserveMainLoad Then ReDim outLoad(1 To rowCount, 1 To 1)

    For idx = 1 To rowCount
        typeVal = UCase$(PD6_ArrayTextFast(vType, idx))
        convVal = PD6_ArrayTextFast(vConv, idx)
        sysVal = UCase$(PD6_ArrayTextFast(vSys, idx))
        voltVal = UCase$(PD6_ArrayTextFast(vVolt, idx))
        sourceLoad = PD6_ArrayTextFast(vLoad, idx)

        dataLoad = PD6_GetConveyorTypeLoad(convVal)
        If Len(dataLoad) > 0 Then
            loadValue = dataLoad
        Else
            combinedVoltageText = UCase$(Trim$(sysVal & " " & voltVal))

            If InStr(1, combinedVoltageText, "400", vbTextCompare) > 0 Or _
               InStr(1, combinedVoltageText, "460", vbTextCompare) > 0 Or _
               InStr(1, combinedVoltageText, "480", vbTextCompare) > 0 Then
                loadValue = 1.6

            ElseIf InStr(1, combinedVoltageText, "24V", vbTextCompare) > 0 Or _
                   InStr(1, combinedVoltageText, "24 V", vbTextCompare) > 0 Then
                motorPower = PD6_ValueDoubleFast(PD6_ArrayValueFast(vMotorPower, idx))
                motorVolt = PD6_ValueDoubleFast(PD6_ArrayValueFast(vVolt, idx))
                totalDrives = PD6_ValueDoubleFast(PD6_ArrayValueFast(vDrives, idx))
                If totalDrives = 0# Then totalDrives = 1#

                If motorPower <> 0# And motorVolt <> 0# Then
                    loadValue = (motorPower * 1000# / motorVolt) * totalDrives
                ElseIf Len(sourceLoad) > 0 Then
                    loadValue = sourceLoad
                Else
                    loadValue = vbNullString
                End If
            ElseIf Len(sourceLoad) > 0 Then
                loadValue = sourceLoad
            Else
                loadValue = vbNullString
            End If
        End If

        PD6_ResolveLoadBusValues typeVal, loadValue, bus1Val, bus2Val
        outBus1(idx, 1) = bus1Val
        outBus2(idx, 1) = bus2Val
        If cLoad > 0 And Not preserveMainLoad Then outLoad(idx, 1) = loadValue
    Next idx

    ws.Range(ws.Cells(2, cLoadBus1), ws.Cells(lastRow, cLoadBus1)).Value2 = outBus1
    ws.Range(ws.Cells(2, cLoadBus2), ws.Cells(lastRow, cLoadBus2)).Value2 = outBus2
    If cLoad > 0 And Not preserveMainLoad Then
        ws.Range(ws.Cells(2, cLoad), ws.Cells(lastRow, cLoad)).Value2 = outLoad
    End If
End Sub

Private Sub PD6_AssignBusPowerSupplyAndTerminals(ByVal ws As Worksheet, ByVal useXYZDistance As Boolean)

    Dim lastRow As Long
    Dim rowCount As Long
    Dim r As Long
    Dim idx As Long
    Dim allocationPass As Long
    Dim allocationRows() As Long
    Dim allocationKeys() As String
    Dim allocationRowCount As Long
    Dim allocationOrderIndex As Long
    Dim psuBySwitch As Object
    Dim psuRowBySwitchPSU As Object
    Dim rowDistanceByRow As Object
    Dim rowDistanceCountByRow As Object
    Dim stateBySwitchBus As Object
    Dim psuTotalLoadBySwitchPSU As Object
    Dim psuOwnerBySwitchPSU As Object
    Dim pairMateBySwitchPSU As Object
    Dim psuList As Collection
    Dim buses As Collection
    Dim typeVal As String
    Dim panelVal As String
    Dim switchVal As String
    Dim switchKey As String
    Dim allocationLocationText As String
    Dim busVal As Variant
    Dim psuName As String
    Dim terminalName As String
    Dim psuBus1 As String
    Dim psuBus2 As String
    Dim termBus1 As String
    Dim termBus2 As String
    Dim allocLoad As Double
    Dim allocLoadBus1 As Double
    Dim allocLoadBus2 As Double
    Dim moduleFt As Double
    Dim lengthApplies As Boolean
    Dim busDisplay As String
    Dim psuDisplay As String
    Dim warningText As String
    Dim deviceSeqNum As Long
    Dim isDualBusRow As Boolean

    Dim cType As Long
    Dim cPNL As Long
    Dim cSwitch As Long
    Dim cSisElem As Long
    Dim cControl As Long
    Dim cSisSeq As Long
    Dim cLoad As Long
    Dim cLoadBus1 As Long
    Dim cLoadBus2 As Long
    Dim cML As Long
    Dim cBus As Long
    Dim cPSU As Long
    Dim cTerm1 As Long
    Dim cTerm2 As Long
    Dim cNotes As Long
    Dim cX As Long
    Dim cY As Long
    Dim cZ As Long

    Dim vType As Variant
    Dim vPNL As Variant
    Dim vSwitch As Variant
    Dim vSisElem As Variant
    Dim vControl As Variant
    Dim vSisSeq As Variant
    Dim vLoad As Variant
    Dim vLoadBus1 As Variant
    Dim vLoadBus2 As Variant
    Dim vML As Variant
    Dim vX As Variant
    Dim vY As Variant
    Dim vZ As Variant
    Dim outBus As Variant
    Dim outPSU As Variant
    Dim outTerm1 As Variant
    Dim outTerm2 As Variant
    Dim outNotes As Variant
    Dim isPSURow() As Boolean

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then Exit Sub

    cType = PD6_HeaderCol(ws, "TYPE", "Device Type", "TYPE/DESC")
    cPNL = PD6_HeaderCol(ws, "PNL", "Panel", "PANEL")
    cSwitch = PD6_HeaderCol(ws, "SwitchGroup", "SWITCHGROUP", "PWG")
    cSisElem = PD6_HeaderCol(ws, "SIS_Element_Number", "SIS_ELEMENT_NUMBER")
    cControl = PD6_HeaderCol(ws, "Control_ID", "CONTROL_ID")
    cSisSeq = PD6_HeaderCol(ws, "SIS_sequence", "SIS_SEQUENCE")
    cLoad = PD6_HeaderCol(ws, "Load", "CURRENT_LOAD")
    cLoadBus1 = PD6_HeaderCol(ws, "Load BUS-1", "LOAD BUS 1", "Load Bus1")
    cLoadBus2 = PD6_HeaderCol(ws, "Load BUS-2", "LOAD BUS 2", "Load Bus2")
    cML = PD6_HeaderCol(ws, "Module Length (ML)", "MODULE LENGTH ML", "Module Length")
    cBus = PD6_HeaderCol(ws, "Bus Power", "BUS POWER")
    cPSU = PD6_HeaderCol(ws, "Power Supply", "POWER SUPPLY", "PSU")
    cTerm1 = PD6_HeaderCol(ws, "Power BUS-1 Terminal", "BUS-1 Terminal")
    cTerm2 = PD6_HeaderCol(ws, "Power BUS-2 Terminal", "BUS-2 Terminal")
    cNotes = PD6_HeaderCol(ws, "NOTES", "Notes")
    cX = PD6_HeaderCol(ws, "X", "X_COORD", "X COORDINATE", "X_COORDINATE")
    cY = PD6_HeaderCol(ws, "Y", "Y_COORD", "Y COORDINATE", "Y_COORDINATE")
    cZ = PD6_HeaderCol(ws, "Z", "Z_COORD", "Z COORDINATE", "Z_COORDINATE")

    If cType = 0 Or cPNL = 0 Or cSwitch = 0 Or cBus = 0 Or cPSU = 0 Or cTerm1 = 0 Or cTerm2 = 0 Then
        Err.Raise vbObjectError + 520, , "PD6_IMPORT is missing one or more required allocation headers."
    End If

    PD6_ValidatePSUTerminalTemplate

    rowCount = lastRow - 1&
    vType = PD6_ReadColumnFast(ws, lastRow, cType)
    vPNL = PD6_ReadColumnFast(ws, lastRow, cPNL)
    vSwitch = PD6_ReadColumnFast(ws, lastRow, cSwitch)
    vSisElem = PD6_ReadColumnFast(ws, lastRow, cSisElem)
    vControl = PD6_ReadColumnFast(ws, lastRow, cControl)
    vSisSeq = PD6_ReadColumnFast(ws, lastRow, cSisSeq)
    vLoad = PD6_ReadColumnFast(ws, lastRow, cLoad)
    vLoadBus1 = PD6_ReadColumnFast(ws, lastRow, cLoadBus1)
    vLoadBus2 = PD6_ReadColumnFast(ws, lastRow, cLoadBus2)
    vML = PD6_ReadColumnFast(ws, lastRow, cML)
    vX = PD6_ReadColumnFast(ws, lastRow, cX)
    vY = PD6_ReadColumnFast(ws, lastRow, cY)
    vZ = PD6_ReadColumnFast(ws, lastRow, cZ)

    mPD6UseXYZDistance = useXYZDistance
    PD6_ResetCoordinateRuntime
    If mPD6UseXYZDistance Then
        PD6_BuildRowCoordinateLookupFast vX, vY, vZ, rowCount
    End If

    outBus = PD6_BlankColumnFast(rowCount)
    outPSU = PD6_BlankColumnFast(rowCount)
    outTerm1 = PD6_BlankColumnFast(rowCount)
    outTerm2 = PD6_BlankColumnFast(rowCount)
    outNotes = PD6_ReadColumnFast(ws, lastRow, cNotes)
    ReDim isPSURow(1 To rowCount)

    Set psuBySwitch = CreateObject("Scripting.Dictionary")
    Set psuRowBySwitchPSU = CreateObject("Scripting.Dictionary")
    Set rowDistanceByRow = CreateObject("Scripting.Dictionary")
    Set rowDistanceCountByRow = CreateObject("Scripting.Dictionary")
    PD6_BuildModuleLengthPositionLookupsFast vPNL, vSwitch, vML, rowCount, rowDistanceByRow, rowDistanceCountByRow

    Set stateBySwitchBus = CreateObject("Scripting.Dictionary")
    Set psuTotalLoadBySwitchPSU = CreateObject("Scripting.Dictionary")
    Set psuOwnerBySwitchPSU = CreateObject("Scripting.Dictionary")
    Set pairMateBySwitchPSU = CreateObject("Scripting.Dictionary")
    pairMateBySwitchPSU.CompareMode = vbTextCompare

    'Classify each row once and collect every available PSU type that has both
    'a Panel assignment and a SwitchGroup. Allocation is isolated by Panel +
    'SwitchGroup so a PSU can never be borrowed from another panel.
    mPD6EligiblePSUCount = 0&
    mPD6ExcludedPSUCount = 0&

    For idx = 1 To rowCount
        typeVal = UCase$(Trim$(PD6_ArrayTextFast(vType, idx)))
        isPSURow(idx) = PD6_RowIsPSUValues( _
            typeVal, PD6_ArrayTextFast(vSisElem, idx), _
            PD6_ArrayTextFast(vControl, idx), PD6_ArrayTextFast(vSisSeq, idx))

        If isPSURow(idx) Then
            panelVal = Trim$(PD6_ArrayTextFast(vPNL, idx))
            switchVal = Trim$(PD6_ArrayTextFast(vSwitch, idx))
            switchKey = PD6_PanelSwitchKey(panelVal, switchVal)

            psuName = PD6_PSUNameFromValues( _
                PD6_ArrayTextFast(vSisElem, idx), PD6_ArrayTextFast(vControl, idx), _
                PD6_ArrayTextFast(vSisSeq, idx), typeVal)
            If Len(psuName) = 0 Then psuName = "PSU_ROW_" & CStr(idx + 1&)

            outBus(idx, 1) = "PSU"
            outPSU(idx, 1) = psuName

            If Len(panelVal) > 0 And Len(switchVal) > 0 And Len(switchKey) > 0 Then
                If Not psuBySwitch.Exists(switchKey) Then
                    Set psuList = New Collection
                    psuBySwitch.Add switchKey, psuList
                End If
                psuBySwitch(switchKey).Add psuName
                If Not psuRowBySwitchPSU.Exists(PD6_PsuTotalKey(switchKey, psuName)) Then
                    psuRowBySwitchPSU.Add PD6_PsuTotalKey(switchKey, psuName), idx + 1&
                End If
                PD6_RegisterPSUCoordinate switchKey, psuName, idx + 1&
                mPD6EligiblePSUCount = mPD6EligiblePSUCount + 1&
            Else
                mPD6ExcludedPSUCount = mPD6ExcludedPSUCount + 1&
                PD6_AppendNoteValueFast outNotes(idx, 1), _
                    "PSU excluded from allocation: both PNL and SwitchGroup are required."
            End If
        End If
    Next idx

    ReDim allocationRows(1 To rowCount)
    ReDim allocationKeys(1 To rowCount)

    For idx = 1 To rowCount
        typeVal = UCase$(Trim$(PD6_ArrayTextFast(vType, idx)))
        If Len(typeVal) > 0 And Not isPSURow(idx) Then
            allocationRowCount = allocationRowCount + 1&
            allocationRows(allocationRowCount) = idx + 1&
            allocationKeys(allocationRowCount) = PD6_AllocationSortKeyValues( _
                PD6_ArrayTextFast(vPNL, idx), PD6_ArrayTextFast(vSwitch, idx), _
                PD6_ArrayTextFast(vSisSeq, idx), _
                PD6_ArrayTextFast(vSisElem, idx), PD6_ArrayTextFast(vControl, idx), idx + 1&)
        End If
    Next idx

    If allocationRowCount > 1 Then
        PD6_QuickSortAllocationRows allocationRows, allocationKeys, 1, allocationRowCount
    End If

    For allocationPass = 1 To 2
        For allocationOrderIndex = 1 To allocationRowCount

            r = allocationRows(allocationOrderIndex)
            idx = r - 1&
            warningText = vbNullString
            busDisplay = vbNullString
            psuDisplay = vbNullString

            typeVal = UCase$(Trim$(PD6_ArrayTextFast(vType, idx)))
            If Len(typeVal) = 0 Then GoTo NextAllocationRowFast

            Set buses = PD6_BusesForType(typeVal)
            If buses.count = 0 Then
                If allocationPass = 2 Then
                    If Not PD6_TypeHasDataPower24VRule(typeVal) Then
                        PD6_AppendNoteValueFast outNotes(idx, 1), _
                            "TYPE " & typeVal & " is not listed in DATA_POWER 24V BUS rules; no PSU assigned."
                    End If
                End If
                GoTo NextAllocationRowFast
            End If

            isDualBusRow = (PD6_CollectionHasBus(buses, "BUS-1") And PD6_CollectionHasBus(buses, "BUS-2"))
            If allocationPass = 1 And Not isDualBusRow Then GoTo NextAllocationRowFast
            If allocationPass = 2 And isDualBusRow Then GoTo NextAllocationRowFast

            panelVal = Trim$(PD6_ArrayTextFast(vPNL, idx))
            switchVal = Trim$(PD6_ArrayTextFast(vSwitch, idx))
            switchKey = PD6_PanelSwitchKey(panelVal, switchVal)
            allocationLocationText = PD6_PanelSwitchDisplay(panelVal, switchVal)

            If Len(panelVal) = 0 Or Len(switchVal) = 0 Or Len(switchKey) = 0 Or _
               Not psuBySwitch.Exists(switchKey) Then
                For Each busVal In buses
                    PD6_AddUniqueText busDisplay, CStr(busVal), "/"
                    If buses.count = 1 Then
                        PD6_AddUniqueText psuDisplay, PSU_MISSING_TEXT, " | "
                    Else
                        PD6_AddUniqueText psuDisplay, CStr(busVal) & "=" & PSU_MISSING_TEXT, " | "
                    End If
                Next busVal

                outBus(idx, 1) = busDisplay
                outPSU(idx, 1) = psuDisplay
                PD6_AppendNoteValueFast outNotes(idx, 1), _
                    "No eligible PSU found for " & allocationLocationText & _
                    ". PSU rows require both PNL and SwitchGroup; BUS PSU marked MISSING."
                GoTo NextAllocationRowFast
            End If

            Set psuList = psuBySwitch(switchKey)
            moduleFt = PD6_ModuleLengthFeet(PD6_ArrayValueFast(vML, idx))
            lengthApplies = (moduleFt > 0#)
            deviceSeqNum = PD6_DeviceSequenceNumberValues( _
                PD6_ArrayTextFast(vSisSeq, idx), PD6_ArrayTextFast(vSisElem, idx), _
                PD6_ArrayTextFast(vControl, idx))

            If isDualBusRow Then
                allocLoadBus1 = PD6_AllocationLoadForBus(typeVal, "BUS-1", _
                    PD6_LoadForBusValues("BUS-1", PD6_ArrayValueFast(vLoadBus1, idx), _
                    PD6_ArrayValueFast(vLoadBus2, idx), PD6_ArrayValueFast(vLoad, idx)))
                allocLoadBus2 = PD6_AllocationLoadForBus(typeVal, "BUS-2", _
                    PD6_LoadForBusValues("BUS-2", PD6_ArrayValueFast(vLoadBus1, idx), _
                    PD6_ArrayValueFast(vLoadBus2, idx), PD6_ArrayValueFast(vLoad, idx)))

                psuBus1 = vbNullString
                psuBus2 = vbNullString
                termBus1 = vbNullString
                termBus2 = vbNullString

                PD6_AllocateRowToPairedBuses _
                    stateBySwitchBus, psuTotalLoadBySwitchPSU, psuOwnerBySwitchPSU, _
                    pairMateBySwitchPSU, psuList, allocationLocationText, switchKey, _
                    allocLoadBus1, allocLoadBus2, moduleFt, lengthApplies, r, deviceSeqNum, _
                    psuRowBySwitchPSU, rowDistanceByRow, rowDistanceCountByRow, _
                    psuBus1, termBus1, psuBus2, termBus2, warningText

                outBus(idx, 1) = "BUS-1/BUS-2"
                outPSU(idx, 1) = "BUS-1=" & psuBus1 & " | BUS-2=" & psuBus2
                outTerm1(idx, 1) = termBus1
                outTerm2(idx, 1) = termBus2

            Else
                For Each busVal In buses
                    psuName = vbNullString
                    terminalName = vbNullString
                    allocLoad = PD6_AllocationLoadForBus(typeVal, CStr(busVal), _
                        PD6_LoadForBusValues(CStr(busVal), PD6_ArrayValueFast(vLoadBus1, idx), _
                        PD6_ArrayValueFast(vLoadBus2, idx), PD6_ArrayValueFast(vLoad, idx)))

                    PD6_AllocateRowToOneBus _
                        stateBySwitchBus, psuTotalLoadBySwitchPSU, psuOwnerBySwitchPSU, _
                        psuList, allocationLocationText, switchKey, CStr(busVal), allocLoad, _
                        moduleFt, lengthApplies, r, deviceSeqNum, psuRowBySwitchPSU, _
                        rowDistanceByRow, rowDistanceCountByRow, psuName, terminalName, warningText

                    If Len(psuName) > 0 Then
                        PD6_AddUniqueText busDisplay, CStr(busVal), "/"
                        PD6_AddUniqueText psuDisplay, psuName, " | "
                        If CStr(busVal) = "BUS-1" Then
                            outTerm1(idx, 1) = terminalName
                        ElseIf CStr(busVal) = "BUS-2" Then
                            outTerm2(idx, 1) = terminalName
                        End If
                    End If
                Next busVal

                outBus(idx, 1) = busDisplay
                outPSU(idx, 1) = psuDisplay
            End If

            If Len(warningText) > 0 Then PD6_AppendNoteValueFast outNotes(idx, 1), warningText

NextAllocationRowFast:
        Next allocationOrderIndex
    Next allocationPass

    ws.Range(ws.Cells(2, cBus), ws.Cells(lastRow, cBus)).Value2 = outBus
    ws.Range(ws.Cells(2, cPSU), ws.Cells(lastRow, cPSU)).Value2 = outPSU
    ws.Range(ws.Cells(2, cTerm1), ws.Cells(lastRow, cTerm1)).Value2 = outTerm1
    ws.Range(ws.Cells(2, cTerm2), ws.Cells(lastRow, cTerm2)).Value2 = outTerm2
    If cNotes > 0 Then ws.Range(ws.Cells(2, cNotes), ws.Cells(lastRow, cNotes)).Value2 = outNotes

    PD6_ValidateAndCleanAllocationLimits ws, lastRow, cType, cSisElem, cControl, cSisSeq, _
        cPNL, cSwitch, cLoad, cLoadBus1, cLoadBus2, cBus, cPSU, cTerm1, cTerm2, cNotes, isPSURow

    On Error Resume Next
    AppendLog "PD6_XYZ_PSU_DISTANCE", "OK", _
              "Distance mode=" & PD6_DistanceModeLabel(mPD6UseXYZDistance) & _
              "; XYZ assignments=" & CStr(mPD6CoordinateDistanceUsedCount) & _
              "; Module Length/SIS assignments=" & CStr(mPD6FallbackDistanceUsedCount) & _
              "; eligible PSU rows=" & CStr(mPD6EligiblePSUCount) & _
              "; excluded PSU rows missing PNL/SwitchGroup=" & CStr(mPD6ExcludedPSUCount) & _
              "; coordinate unit=" & PD6_XYZ_UNIT & _
              "; route factor=" & Format$(PD6_XYZ_ROUTE_FACTOR, "0.###") & "."
    On Error GoTo 0

End Sub

Private Sub PD6_ValidateAndCleanAllocationLimits( _
        ByVal ws As Worksheet, _
        ByVal lastRow As Long, _
        ByVal cType As Long, _
        ByVal cSisElem As Long, _
        ByVal cControl As Long, _
        ByVal cSisSeq As Long, _
        ByVal cPNL As Long, _
        ByVal cSwitch As Long, _
        ByVal cLoad As Long, _
        ByVal cLoadBus1 As Long, _
        ByVal cLoadBus2 As Long, _
        ByVal cBus As Long, _
        ByVal cPSU As Long, _
        ByVal cTerm1 As Long, _
        ByVal cTerm2 As Long, _
        ByVal cNotes As Long, _
        ByRef isPSURow() As Boolean)

    Dim totalByPSU As Object
    Dim totalByTerminal As Object
    Dim rowCount As Long
    Dim idx As Long
    Dim typeVal As String
    Dim panelVal As String
    Dim switchKey As String
    Dim buses As Collection
    Dim busVal As Variant
    Dim psuName As String
    Dim termName As String
    Dim loadVal As Double
    Dim psuKey As String
    Dim termKey As String
    Dim existingPsuLoad As Double
    Dim existingTermLoad As Double
    Dim psuText As String
    Dim invalidReason As String

    Dim vType As Variant
    Dim vPNL As Variant
    Dim vSwitch As Variant
    Dim vLoad As Variant
    Dim vLoadBus1 As Variant
    Dim vLoadBus2 As Variant
    Dim vPSU As Variant
    Dim vTerm1 As Variant
    Dim vTerm2 As Variant
    Dim vNotes As Variant

    rowCount = lastRow - 1&
    If rowCount < 1 Then Exit Sub

    vType = PD6_ReadColumnFast(ws, lastRow, cType)
    vPNL = PD6_ReadColumnFast(ws, lastRow, cPNL)
    vSwitch = PD6_ReadColumnFast(ws, lastRow, cSwitch)
    vLoad = PD6_ReadColumnFast(ws, lastRow, cLoad)
    vLoadBus1 = PD6_ReadColumnFast(ws, lastRow, cLoadBus1)
    vLoadBus2 = PD6_ReadColumnFast(ws, lastRow, cLoadBus2)
    vPSU = PD6_ReadColumnFast(ws, lastRow, cPSU)
    vTerm1 = PD6_ReadColumnFast(ws, lastRow, cTerm1)
    vTerm2 = PD6_ReadColumnFast(ws, lastRow, cTerm2)
    vNotes = PD6_ReadColumnFast(ws, lastRow, cNotes)

    Set totalByPSU = CreateObject("Scripting.Dictionary")
    Set totalByTerminal = CreateObject("Scripting.Dictionary")

    For idx = 1 To rowCount
        typeVal = UCase$(PD6_ArrayTextFast(vType, idx))
        If Len(typeVal) = 0 Then GoTo NextValidationRowFast
        If idx >= LBound(isPSURow) And idx <= UBound(isPSURow) Then
            If isPSURow(idx) Then GoTo NextValidationRowFast
        End If

        Set buses = PD6_BusesForType(typeVal)
        If buses.count = 0 Then GoTo NextValidationRowFast

        panelVal = PD6_ArrayTextFast(vPNL, idx)
        switchKey = PD6_PanelSwitchKey(panelVal, PD6_ArrayTextFast(vSwitch, idx))
        psuText = PD6_ArrayTextFast(vPSU, idx)

        For Each busVal In buses
            loadVal = PD6_AllocationLoadForBus(typeVal, CStr(busVal), _
                PD6_LoadForBusValues(CStr(busVal), PD6_ArrayValueFast(vLoadBus1, idx), _
                    PD6_ArrayValueFast(vLoadBus2, idx), PD6_ArrayValueFast(vLoad, idx)))
            If loadVal <= 0 Then GoTo NextValidationBusFast

            psuName = PD6_GetPSUFromDisplayForBus(psuText, CStr(busVal))
            If Len(psuName) = 0 Then GoTo NextValidationBusFast
            If UCase$(Trim$(psuName)) = UCase$(PSU_MISSING_TEXT) Then GoTo NextValidationBusFast

            If UCase$(CStr(busVal)) = "BUS-1" Then
                termName = PD6_ArrayTextFast(vTerm1, idx)
            Else
                termName = PD6_ArrayTextFast(vTerm2, idx)
            End If

            invalidReason = vbNullString
            If Len(termName) = 0 Then
                invalidReason = CStr(busVal) & " has load but no terminal assignment."
            Else
                psuKey = PD6_PsuTotalKey(switchKey, psuName)
                termKey = psuKey & "|" & UCase$(termName)
                existingPsuLoad = PD6_GetDictDouble(totalByPSU, psuKey)
                existingTermLoad = PD6_GetDictDouble(totalByTerminal, termKey)

                If existingTermLoad + loadVal > TERM_LIMIT_A Then
                    invalidReason = CStr(busVal) & " terminal " & termName & " would exceed " & PD6_FormatAmp(TERM_LIMIT_A) & "A."
                ElseIf existingPsuLoad + loadVal > PSU_ALLOC_LIMIT_A Then
                    invalidReason = CStr(busVal) & " power supply " & psuName & " would exceed " & PD6_FormatAmp(PSU_ALLOC_LIMIT_A) & "A."
                Else
                    totalByPSU(psuKey) = existingPsuLoad + loadVal
                    totalByTerminal(termKey) = existingTermLoad + loadVal
                End If
            End If

            If Len(invalidReason) > 0 Then
                If InStr(1, UCase$(psuText), "BUS-1=", vbTextCompare) > 0 Or _
                   InStr(1, UCase$(psuText), "BUS-2=", vbTextCompare) > 0 Then
                    psuText = PD6_SetPowerSupplyEntry(psuText, UCase$(CStr(busVal)), PSU_MISSING_TEXT)
                Else
                    psuText = PSU_MISSING_TEXT
                End If
                vPSU(idx, 1) = psuText

                If UCase$(CStr(busVal)) = "BUS-1" Then
                    vTerm1(idx, 1) = vbNullString
                ElseIf UCase$(CStr(busVal)) = "BUS-2" Then
                    vTerm2(idx, 1) = vbNullString
                End If

                PD6_AppendNoteValueFast vNotes(idx, 1), _
                    "MISSING " & CStr(busVal) & " PSU/terminal; " & invalidReason
            End If

NextValidationBusFast:
        Next busVal

NextValidationRowFast:
    Next idx

    ws.Range(ws.Cells(2, cPSU), ws.Cells(lastRow, cPSU)).Value2 = vPSU
    ws.Range(ws.Cells(2, cTerm1), ws.Cells(lastRow, cTerm1)).Value2 = vTerm1
    ws.Range(ws.Cells(2, cTerm2), ws.Cells(lastRow, cTerm2)).Value2 = vTerm2
    If cNotes > 0 Then ws.Range(ws.Cells(2, cNotes), ws.Cells(lastRow, cNotes)).Value2 = vNotes
End Sub

Private Function PD6_GetPSUFromDisplayForBus(ByVal powerSupplyText As String, ByVal busVal As String) As String

    Dim parts() As String
    Dim i As Long
    Dim itemText As String
    Dim prefix As String

    powerSupplyText = Trim$(powerSupplyText)
    busVal = UCase$(Trim$(busVal))
    prefix = busVal & "="

    If Len(powerSupplyText) = 0 Then Exit Function

    If InStr(1, UCase$(powerSupplyText), "BUS-1=", vbTextCompare) > 0 Or _
       InStr(1, UCase$(powerSupplyText), "BUS-2=", vbTextCompare) > 0 Then

        parts = Split(powerSupplyText, "|")
        For i = LBound(parts) To UBound(parts)
            itemText = Trim$(parts(i))
            If InStr(1, UCase$(itemText), prefix, vbTextCompare) = 1 Then
                PD6_GetPSUFromDisplayForBus = Trim$(mid$(itemText, Len(prefix) + 1))
                Exit Function
            End If
        Next i

        PD6_GetPSUFromDisplayForBus = ""
    Else
        PD6_GetPSUFromDisplayForBus = powerSupplyText
    End If

End Function

Private Sub PD6_MarkBusAssignmentMissing(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal busVal As String, _
                                         ByVal cPSU As Long, ByVal cTerm1 As Long, ByVal cTerm2 As Long)

    Dim psuText As String

    busVal = UCase$(Trim$(busVal))
    psuText = CStr(ws.Cells(rowNum, cPSU).value)

    If InStr(1, UCase$(psuText), "BUS-1=", vbTextCompare) > 0 Or _
       InStr(1, UCase$(psuText), "BUS-2=", vbTextCompare) > 0 Then
        ws.Cells(rowNum, cPSU).value = PD6_SetPowerSupplyEntry(psuText, busVal, PSU_MISSING_TEXT)
    Else
        ws.Cells(rowNum, cPSU).value = PSU_MISSING_TEXT
    End If

    If busVal = "BUS-1" Then
        ws.Cells(rowNum, cTerm1).value = ""
    ElseIf busVal = "BUS-2" Then
        ws.Cells(rowNum, cTerm2).value = ""
    End If

End Sub

Private Sub PD6_ForceFill_BUS1_For_MC_MS(ByVal ws As Worksheet)

End Sub

Private Function PD6_TypeNeedsBus1(ByVal typeVal As String) As Boolean

    Dim t As String
    t = UCase$(Trim$(typeVal))
    t = Replace(t, " ", "")
    t = Replace(t, "_", "/")

    PD6_TypeNeedsBus1 = (t = "MC" Or Left$(t, 2) = "MC" Or t = "MS" Or Left$(t, 2) = "MS")

End Function

Private Function PD6_AddBusLabel(ByVal existingText As String, ByVal busLabel As String) As String

    Dim resultText As String
    Dim u As String

    resultText = Trim$(existingText)
    u = UCase$(resultText)

    If InStr(1, u, UCase$(busLabel), vbTextCompare) = 0 Then
        If Len(resultText) = 0 Then
            resultText = busLabel
        Else
            If UCase$(busLabel) = "BUS-1" Then
                resultText = busLabel & "/" & resultText
            Else
                resultText = resultText & "/" & busLabel
            End If
        End If
    End If

    If InStr(1, UCase$(resultText), "BUS-1", vbTextCompare) > 0 And InStr(1, UCase$(resultText), "BUS-2", vbTextCompare) > 0 Then
        resultText = "BUS-1/BUS-2"
    End If

    PD6_AddBusLabel = resultText

End Function

Private Function PD6_SetPowerSupplyEntry(ByVal existingText As String, ByVal busLabel As String, ByVal psuName As String) As String

    Dim parts() As String
    Dim i As Long
    Dim itemText As String
    Dim resultText As String
    Dim busPrefix As String
    Dim found As Boolean

    busPrefix = busLabel & "="
    existingText = Trim$(existingText)
    psuName = Trim$(psuName)

    If Len(psuName) = 0 Then
        PD6_SetPowerSupplyEntry = existingText
        Exit Function
    End If

    resultText = ""
    found = False

    If Len(existingText) > 0 Then
        parts = Split(existingText, "|")
        For i = LBound(parts) To UBound(parts)
            itemText = Trim$(parts(i))
            If Len(itemText) > 0 Then
                If InStr(1, itemText, busPrefix, vbTextCompare) = 1 Then
                    itemText = busPrefix & psuName
                    found = True
                End If
                If Len(resultText) > 0 Then resultText = resultText & " | "
                resultText = resultText & itemText
            End If
        Next i
    End If

    If Not found Then
        If Len(resultText) = 0 Then
            resultText = busPrefix & psuName
        ElseIf UCase$(busLabel) = "BUS-1" Then
            resultText = busPrefix & psuName & " | " & resultText
        Else
            resultText = resultText & " | " & busPrefix & psuName
        End If
    End If

    PD6_SetPowerSupplyEntry = resultText

End Function

Private Function PD6_AllocationSortKey( _
        ByVal ws As Worksheet, _
        ByVal rowNum As Long, _
        ByVal cSwitch As Long, _
        ByVal cSisSeq As Long, _
        ByVal cSisElem As Long, _
        ByVal cControl As Long) As String

    Dim switchText As String
    Dim switchPart As String
    Dim sequenceNum As Long

    switchText = Trim$(CStr(ws.Cells(rowNum, cSwitch).value))
    If IsNumeric(switchText) Then
        switchPart = "0" & Right$(String$(12, "0") & CStr(CLng(val(switchText))), 12)
    Else
        switchPart = "1" & UCase$(switchText)
    End If

    sequenceNum = PD6_DeviceSequenceNumber(ws, rowNum, cSisSeq, cSisElem, cControl)
    If sequenceNum <= 0 Then sequenceNum = 2147483647

    PD6_AllocationSortKey = switchPart & "|" & _
        Right$(String$(12, "0") & CStr(sequenceNum), 12) & "|" & _
        Right$(String$(10, "0") & CStr(rowNum), 10)

End Function

Private Sub PD6_QuickSortAllocationRows( _
        ByRef allocationRows() As Long, _
        ByRef allocationKeys() As String, _
        ByVal lowIndex As Long, _
        ByVal highIndex As Long)

    Dim i As Long
    Dim j As Long
    Dim pivotKey As String
    Dim tempKey As String
    Dim tempRow As Long

    i = lowIndex
    j = highIndex
    pivotKey = allocationKeys((lowIndex + highIndex) \ 2)

    Do While i <= j
        Do While StrComp(allocationKeys(i), pivotKey, vbTextCompare) < 0
            i = i + 1&
        Loop

        Do While StrComp(allocationKeys(j), pivotKey, vbTextCompare) > 0
            j = j - 1&
        Loop

        If i <= j Then
            tempKey = allocationKeys(i)
            allocationKeys(i) = allocationKeys(j)
            allocationKeys(j) = tempKey

            tempRow = allocationRows(i)
            allocationRows(i) = allocationRows(j)
            allocationRows(j) = tempRow

            i = i + 1&
            j = j - 1&
        End If
    Loop

    If lowIndex < j Then
        PD6_QuickSortAllocationRows allocationRows, allocationKeys, lowIndex, j
    End If

    If i < highIndex Then
        PD6_QuickSortAllocationRows allocationRows, allocationKeys, i, highIndex
    End If

End Sub

Private Function PD6_CollectionHasBus(ByVal buses As Collection, ByVal busLabel As String) As Boolean

    Dim item As Variant

    PD6_CollectionHasBus = False
    If buses Is Nothing Then Exit Function

    For Each item In buses
        If StrComp(Trim$(CStr(item)), Trim$(busLabel), vbTextCompare) = 0 Then
            PD6_CollectionHasBus = True
            Exit Function
        End If
    Next item

End Function

Private Function PD6_TypeNeedsBoth24VBuses(ByVal typeVal As String) As Boolean

    Dim buses As Collection

    Set buses = PD6_BusesForType(typeVal)
    PD6_TypeNeedsBoth24VBuses = _
        (PD6_CollectionHasBus(buses, "BUS-1") And PD6_CollectionHasBus(buses, "BUS-2"))

End Function

Private Sub PD6_AllocateRowToPairedBuses( _
        ByVal stateBySwitchBus As Object, _
        ByVal psuTotalLoadBySwitchPSU As Object, _
        ByVal psuOwnerBySwitchPSU As Object, _
        ByVal pairMateBySwitchPSU As Object, _
        ByVal psuList As Collection, _
        ByVal switchVal As String, _
        ByVal switchKey As String, _
        ByVal bus1Load As Double, _
        ByVal bus2Load As Double, _
        ByVal moduleFt As Double, _
        ByVal lengthApplies As Boolean, _
        ByVal deviceRowNum As Long, _
        ByVal deviceSeqNum As Long, _
        ByVal psuRowBySwitchPSU As Object, _
        ByVal rowDistanceByRow As Object, _
        ByVal rowDistanceCountByRow As Object, _
        ByRef psuBus1 As String, _
        ByRef termBus1 As String, _
        ByRef psuBus2 As String, _
        ByRef termBus2 As String, _
        ByRef warningText As String)

    Dim selectedBus1 As String
    Dim selectedBus2 As String

    psuBus1 = PSU_MISSING_TEXT
    psuBus2 = PSU_MISSING_TEXT
    termBus1 = ""
    termBus2 = ""

    Call PD6_FindBestPairedPSUs( _
        stateBySwitchBus, psuTotalLoadBySwitchPSU, psuOwnerBySwitchPSU, _
        pairMateBySwitchPSU, psuList, switchKey, bus1Load, bus2Load, _
        moduleFt, lengthApplies, deviceRowNum, deviceSeqNum, selectedBus1, selectedBus2)

    If Len(selectedBus1) = 0 Or Len(selectedBus2) = 0 Then
        PD6_AddAllocationWarning warningText, _
            "MISSING paired BUS-1/BUS-2 PSU in " & switchVal & _
            "; no two available PSUs within " & CStr(PSU_PAIR_MAX_NUMBER_GAP) & _
            " sequence increments can accept both loads while preserving the " & _
            PD6_FormatAmp(PSU_ALLOC_LIMIT_A) & "A PSU cap, " & _
            PD6_FormatAmp(TERM_LIMIT_A) & "A terminal cap, and length limits."
        Exit Sub
    End If

    Call PD6_AllocateRowToOneBus( _
        stateBySwitchBus, psuTotalLoadBySwitchPSU, psuOwnerBySwitchPSU, _
        psuList, switchVal, switchKey, "BUS-1", bus1Load, moduleFt, _
        lengthApplies, deviceRowNum, deviceSeqNum, psuRowBySwitchPSU, _
        rowDistanceByRow, rowDistanceCountByRow, psuBus1, termBus1, warningText, selectedBus1)

    Call PD6_AllocateRowToOneBus( _
        stateBySwitchBus, psuTotalLoadBySwitchPSU, psuOwnerBySwitchPSU, _
        psuList, switchVal, switchKey, "BUS-2", bus2Load, moduleFt, _
        lengthApplies, deviceRowNum, deviceSeqNum, psuRowBySwitchPSU, _
        rowDistanceByRow, rowDistanceCountByRow, psuBus2, termBus2, warningText, selectedBus2)

    If UCase$(Trim$(psuBus1)) = UCase$(PSU_MISSING_TEXT) Or _
       UCase$(Trim$(psuBus2)) = UCase$(PSU_MISSING_TEXT) Then
        Err.Raise vbObjectError + 527, "PD6_AllocateRowToPairedBuses", _
            "A prevalidated BUS-1/BUS-2 PSU pair could not be committed."
    End If

    PD6_RegisterPSUPair pairMateBySwitchPSU, switchKey, psuBus1, psuBus2

End Sub

Private Sub PD6_FindBestExactNamedPSUPair( _
        ByVal stateBySwitchBus As Object, _
        ByVal psuTotalLoadBySwitchPSU As Object, _
        ByVal psuOwnerBySwitchPSU As Object, _
        ByVal pairMateBySwitchPSU As Object, _
        ByVal psuList As Collection, _
        ByVal switchKey As String, _
        ByVal bus1Load As Double, _
        ByVal bus2Load As Double, _
        ByVal moduleFt As Double, _
        ByVal lengthApplies As Boolean, _
        ByVal deviceSeqNum As Long, _
        ByRef selectedBus1 As String, _
        ByRef selectedBus2 As String)

    Dim i As Long
    Dim j As Long
    Dim candidateBus1 As String
    Dim candidateBus2 As String
    Dim stateBus1 As Object
    Dim stateBus2 As Object
    Dim totalBus1 As Double
    Dim totalBus2 As Double
    Dim seqBus1 As Long
    Dim seqBus2 As Long
    Dim ordinalBus1 As Long
    Dim ordinalBus2 As Long
    Dim deviceGap As Long
    Dim score As Double
    Dim bestScore As Double
    Dim exactExistingPair As Boolean
    Dim tieKey As String
    Dim bestTieKey As String

    selectedBus1 = vbNullString
    selectedBus2 = vbNullString
    bestScore = 1E+30
    bestTieKey = vbNullString

    If psuList Is Nothing Then Exit Sub
    If psuList.count < 2 Then Exit Sub

    For i = 1 To psuList.count

        candidateBus1 = Trim$(CStr(psuList(i)))
        If Len(candidateBus1) = 0 Then GoTo NextExactBus1
        If UCase$(candidateBus1) = UCase$(PSU_MISSING_TEXT) Then GoTo NextExactBus1

        ordinalBus1 = PD6_PSUSuffixOrdinal(candidateBus1)
        If ordinalBus1 <> 0 And ordinalBus1 <> 1 Then GoTo NextExactBus1

        seqBus1 = PD6_FirstNumberFromPSUName(candidateBus1)
        If seqBus1 <= 0 Then GoTo NextExactBus1

        If PD6_PSUOwnedByOtherBus( _
                psuOwnerBySwitchPSU, switchKey, candidateBus1, "BUS-1") Then
            GoTo NextExactBus1
        End If

        totalBus1 = PD6_GetDictDouble( _
            psuTotalLoadBySwitchPSU, PD6_PsuTotalKey(switchKey, candidateBus1))

        If bus1Load > 0# Then
            If totalBus1 + bus1Load > PSU_ALLOC_LIMIT_A Then GoTo NextExactBus1
        End If

        Set stateBus1 = PD6_GetState( _
            stateBySwitchBus, PD6_PsuBusStateKey(switchKey, "BUS-1", candidateBus1))

        If Not PD6_CandidatePSUCanAccept( _
                stateBus1, bus1Load, moduleFt, lengthApplies, BUS1_LIMIT_FT) Then
            GoTo NextExactBus1
        End If

        For j = 1 To psuList.count

            candidateBus2 = Trim$(CStr(psuList(j)))
            If Len(candidateBus2) = 0 Then GoTo NextExactBus2
            If UCase$(candidateBus2) = UCase$(PSU_MISSING_TEXT) Then GoTo NextExactBus2
            If StrComp(candidateBus1, candidateBus2, vbTextCompare) = 0 Then GoTo NextExactBus2

            ordinalBus2 = PD6_PSUSuffixOrdinal(candidateBus2)
            If ordinalBus2 <> 2 Then GoTo NextExactBus2

            seqBus2 = PD6_FirstNumberFromPSUName(candidateBus2)
            If seqBus2 <= 0 Or seqBus2 <> seqBus1 Then GoTo NextExactBus2

            If deviceSeqNum > 0 Then
                deviceGap = Abs(seqBus1 - deviceSeqNum)
                If deviceGap > PSU_EXACT_PAIR_DEVICE_GAP Then GoTo NextExactBus2
            Else
                deviceGap = 0&
            End If

            If PD6_PSUOwnedByOtherBus( _
                    psuOwnerBySwitchPSU, switchKey, candidateBus2, "BUS-2") Then
                GoTo NextExactBus2
            End If

            If Not PD6_PairCandidateAllowed( _
                    pairMateBySwitchPSU, switchKey, candidateBus1, candidateBus2) Then
                GoTo NextExactBus2
            End If

            totalBus2 = PD6_GetDictDouble( _
                psuTotalLoadBySwitchPSU, PD6_PsuTotalKey(switchKey, candidateBus2))

            If bus2Load > 0# Then
                If totalBus2 + bus2Load > PSU_ALLOC_LIMIT_A Then GoTo NextExactBus2
            End If

            Set stateBus2 = PD6_GetState( _
                stateBySwitchBus, PD6_PsuBusStateKey(switchKey, "BUS-2", candidateBus2))

            If Not PD6_CandidatePSUCanAccept( _
                    stateBus2, bus2Load, moduleFt, lengthApplies, BUS2_LIMIT_FT) Then
                GoTo NextExactBus2
            End If

            exactExistingPair = PD6_IsRegisteredPSUPair( _
                pairMateBySwitchPSU, switchKey, candidateBus1, candidateBus2)

            score = CDbl(deviceGap) * 100000# + _
                    PD6_PairLoadBalancePenalty(totalBus1 + bus1Load) + _
                    PD6_PairLoadBalancePenalty(totalBus2 + bus2Load) + _
                    CDbl(CLng(stateBus1("TERM_IDX")) + CLng(stateBus2("TERM_IDX"))) * 10# + _
                    CDbl(CLng(stateBus1("TERM_COUNT")) + CLng(stateBus2("TERM_COUNT")))

            If exactExistingPair Then score = score - 1000000000#

            tieKey = Right$(String$(12, "0") & CStr(seqBus1), 12) & "|" & _
                     UCase$(candidateBus1) & "|" & UCase$(candidateBus2)

            If score < bestScore Or _
               (Abs(score - bestScore) < 0.000001 And _
                (Len(bestTieKey) = 0 Or StrComp(tieKey, bestTieKey, vbBinaryCompare) < 0)) Then
                bestScore = score
                bestTieKey = tieKey
                selectedBus1 = candidateBus1
                selectedBus2 = candidateBus2
            End If

NextExactBus2:
        Next j

NextExactBus1:
    Next i

End Sub

Private Sub PD6_FindBestPairedPSUs( _
        ByVal stateBySwitchBus As Object, _
        ByVal psuTotalLoadBySwitchPSU As Object, _
        ByVal psuOwnerBySwitchPSU As Object, _
        ByVal pairMateBySwitchPSU As Object, _
        ByVal psuList As Collection, _
        ByVal switchKey As String, _
        ByVal bus1Load As Double, _
        ByVal bus2Load As Double, _
        ByVal moduleFt As Double, _
        ByVal lengthApplies As Boolean, _
        ByVal deviceRowNum As Long, _
        ByVal deviceSeqNum As Long, _
        ByRef selectedBus1 As String, _
        ByRef selectedBus2 As String)

    Dim i As Long
    Dim j As Long
    Dim candidateBus1 As String
    Dim candidateBus2 As String
    Dim stateBus1 As Object
    Dim stateBus2 As Object
    Dim totalBus1 As Double
    Dim totalBus2 As Double
    Dim score As Double
    Dim bestScore As Double
    Dim seq1 As Long
    Dim seq2 As Long
    Dim pairGap As Long
    Dim ordinalBus1 As Long
    Dim ordinalBus2 As Long
    Dim exactExistingPair As Boolean
    Dim distanceBus1 As Double
    Dim distanceBus2 As Double
    Dim lengthBus1Applies As Boolean
    Dim lengthBus2Applies As Boolean
    Dim usesXYZBus1 As Boolean
    Dim usesXYZBus2 As Boolean
    Dim deviceHasXYZ As Boolean

    selectedBus1 = ""
    selectedBus2 = ""
    bestScore = 1E+30

    If psuList Is Nothing Then Exit Sub
    If psuList.count < 2 Then Exit Sub

    deviceHasXYZ = (mPD6UseXYZDistance And PD6_RowHasCoordinate(deviceRowNum))

    'When the user selects XYZ and coordinates exist, physical placement is primary.
    'Otherwise the exact named-pair and Module Length setup remains the default.
    If Not deviceHasXYZ Then
        PD6_FindBestExactNamedPSUPair _
            stateBySwitchBus, psuTotalLoadBySwitchPSU, psuOwnerBySwitchPSU, _
            pairMateBySwitchPSU, psuList, switchKey, bus1Load, bus2Load, _
            moduleFt, lengthApplies, deviceSeqNum, selectedBus1, selectedBus2

        If Len(selectedBus1) > 0 And Len(selectedBus2) > 0 Then Exit Sub
    End If

    For i = 1 To psuList.count
        candidateBus1 = Trim$(CStr(psuList(i)))
        If Len(candidateBus1) = 0 Then GoTo NextBus1Candidate
        If UCase$(candidateBus1) = UCase$(PSU_MISSING_TEXT) Then GoTo NextBus1Candidate
        If PD6_PSUOwnedByOtherBus(psuOwnerBySwitchPSU, switchKey, candidateBus1, "BUS-1") Then GoTo NextBus1Candidate

        totalBus1 = PD6_GetDictDouble(psuTotalLoadBySwitchPSU, _
            PD6_PsuTotalKey(switchKey, candidateBus1))
        If bus1Load > 0 Then
            If totalBus1 + bus1Load > PSU_ALLOC_LIMIT_A Then GoTo NextBus1Candidate
        End If

        Set stateBus1 = PD6_GetState(stateBySwitchBus, _
            PD6_PsuBusStateKey(switchKey, "BUS-1", candidateBus1))
        PD6_ResolveCandidateDistance switchKey, candidateBus1, deviceRowNum, _
            moduleFt, lengthApplies, distanceBus1, lengthBus1Applies, usesXYZBus1
        If Not PD6_CandidatePSUCanAccept(stateBus1, bus1Load, distanceBus1, _
            lengthBus1Applies, BUS1_LIMIT_FT) Then GoTo NextBus1Candidate

        For j = 1 To psuList.count
            candidateBus2 = Trim$(CStr(psuList(j)))
            If Len(candidateBus2) = 0 Then GoTo NextBus2Candidate
            If UCase$(candidateBus2) = UCase$(PSU_MISSING_TEXT) Then GoTo NextBus2Candidate
            If StrComp(candidateBus1, candidateBus2, vbTextCompare) = 0 Then GoTo NextBus2Candidate
            If PD6_PSUOwnedByOtherBus(psuOwnerBySwitchPSU, switchKey, candidateBus2, "BUS-2") Then GoTo NextBus2Candidate
            If Not PD6_PairCandidateAllowed(pairMateBySwitchPSU, switchKey, candidateBus1, candidateBus2) Then GoTo NextBus2Candidate

            totalBus2 = PD6_GetDictDouble(psuTotalLoadBySwitchPSU, _
                PD6_PsuTotalKey(switchKey, candidateBus2))
            If bus2Load > 0 Then
                If totalBus2 + bus2Load > PSU_ALLOC_LIMIT_A Then GoTo NextBus2Candidate
            End If

            Set stateBus2 = PD6_GetState(stateBySwitchBus, _
                PD6_PsuBusStateKey(switchKey, "BUS-2", candidateBus2))
            PD6_ResolveCandidateDistance switchKey, candidateBus2, deviceRowNum, _
                moduleFt, lengthApplies, distanceBus2, lengthBus2Applies, usesXYZBus2
            If Not PD6_CandidatePSUCanAccept(stateBus2, bus2Load, distanceBus2, _
                lengthBus2Applies, BUS2_LIMIT_FT) Then GoTo NextBus2Candidate

            seq1 = PD6_FirstNumberFromPSUName(candidateBus1)
            seq2 = PD6_FirstNumberFromPSUName(candidateBus2)
            pairGap = 0

            If seq1 > 0 And seq2 > 0 Then
                pairGap = Abs(seq1 - seq2)
                If pairGap > PSU_PAIR_MAX_NUMBER_GAP Then GoTo NextBus2Candidate
            End If

            exactExistingPair = PD6_IsRegisteredPSUPair( _
                pairMateBySwitchPSU, switchKey, candidateBus1, candidateBus2)

            If deviceHasXYZ Then
                score = PD6_PairCoordinateSelectionScore( _
                            candidateBus1, candidateBus2, deviceSeqNum, _
                            distanceBus1, distanceBus2, usesXYZBus1, usesXYZBus2) + _
                        CDbl(pairGap) * 100# + _
                        PD6_PairLoadBalancePenalty(totalBus1 + bus1Load) + _
                        PD6_PairLoadBalancePenalty(totalBus2 + bus2Load)
            Else
                score = PD6_PSUAllocationScore(candidateBus1, deviceSeqNum, totalBus1, stateBus1) + _
                        PD6_PSUAllocationScore(candidateBus2, deviceSeqNum, totalBus2, stateBus2) + _
                        CDbl(pairGap) * 100# + _
                        PD6_PairLoadBalancePenalty(totalBus1 + bus1Load) + _
                        PD6_PairLoadBalancePenalty(totalBus2 + bus2Load)
            End If

            If exactExistingPair Then
                score = score - 8000#
            ElseIf Not deviceHasXYZ Then
                score = score + PD6_PairIsolationPenalty( _
                    psuList, psuOwnerBySwitchPSU, pairMateBySwitchPSU, _
                    switchKey, candidateBus1, candidateBus2)
            Else
                score = score + (PD6_PairIsolationPenalty( _
                    psuList, psuOwnerBySwitchPSU, pairMateBySwitchPSU, _
                    switchKey, candidateBus1, candidateBus2) / 1000000#)
            End If

            If seq1 > 0 And seq1 = seq2 Then
                score = score - 12000#
                ordinalBus1 = PD6_PSUSuffixOrdinal(candidateBus1)
                ordinalBus2 = PD6_PSUSuffixOrdinal(candidateBus2)

                If ordinalBus1 = 1 And ordinalBus2 = 2 Then
                    score = score - 3000#
                ElseIf ordinalBus1 = 0 And ordinalBus2 > 0 Then
                    score = score - 1500#
                ElseIf ordinalBus1 > 0 And ordinalBus2 > ordinalBus1 Then
                    score = score - 750#
                End If
            End If

            If score < bestScore Then
                bestScore = score
                selectedBus1 = candidateBus1
                selectedBus2 = candidateBus2
            End If

NextBus2Candidate:
        Next j

NextBus1Candidate:
    Next i

End Sub

Private Function PD6_PairIsolationPenalty( _
        ByVal psuList As Collection, _
        ByVal psuOwnerBySwitchPSU As Object, _
        ByVal pairMateBySwitchPSU As Object, _
        ByVal switchKey As String, _
        ByVal excludedPSU1 As String, _
        ByVal excludedPSU2 As String) As Double

    Dim i As Long
    Dim j As Long
    Dim psu1 As String
    Dim psu2 As String
    Dim seq1 As Long
    Dim seq2 As Long
    Dim availableCount As Long
    Dim isolatedCount As Long
    Dim hasMate As Boolean

    For i = 1 To psuList.count
        psu1 = Trim$(CStr(psuList(i)))
        If Len(psu1) = 0 Then GoTo NextIsolationPSU
        If StrComp(psu1, excludedPSU1, vbTextCompare) = 0 Then GoTo NextIsolationPSU
        If StrComp(psu1, excludedPSU2, vbTextCompare) = 0 Then GoTo NextIsolationPSU
        If pairMateBySwitchPSU.Exists(PD6_PairMateKey(switchKey, psu1)) Then GoTo NextIsolationPSU
        If psuOwnerBySwitchPSU.Exists(PD6_PsuTotalKey(switchKey, psu1)) Then GoTo NextIsolationPSU

        availableCount = availableCount + 1&
        hasMate = False
        seq1 = PD6_FirstNumberFromPSUName(psu1)

        For j = 1 To psuList.count
            If j <> i Then
                psu2 = Trim$(CStr(psuList(j)))
                If Len(psu2) > 0 Then
                    If StrComp(psu2, excludedPSU1, vbTextCompare) <> 0 And _
                       StrComp(psu2, excludedPSU2, vbTextCompare) <> 0 Then
                        If Not pairMateBySwitchPSU.Exists(PD6_PairMateKey(switchKey, psu2)) And _
                           Not psuOwnerBySwitchPSU.Exists(PD6_PsuTotalKey(switchKey, psu2)) Then
                            seq2 = PD6_FirstNumberFromPSUName(psu2)
                            If seq1 <= 0 Or seq2 <= 0 Or _
                               Abs(seq1 - seq2) <= PSU_PAIR_MAX_NUMBER_GAP Then
                                hasMate = True
                                Exit For
                            End If
                        End If
                    End If
                End If
            End If
        Next j

        If Not hasMate Then isolatedCount = isolatedCount + 1&

NextIsolationPSU:
    Next i

    isolatedCount = isolatedCount - (availableCount Mod 2&)
    If isolatedCount > 0 Then
        PD6_PairIsolationPenalty = _
            CDbl(isolatedCount) * PSU_PAIR_ISOLATION_PENALTY
    End If

End Function

Private Function PD6_PairLoadBalancePenalty(ByVal projectedLoad As Double) As Double

    If projectedLoad > PSU_PAIR_SOFT_TARGET_A Then
        PD6_PairLoadBalancePenalty = _
            (projectedLoad - PSU_PAIR_SOFT_TARGET_A) * PSU_PAIR_BALANCE_PENALTY
    Else
        PD6_PairLoadBalancePenalty = 0#
    End If

End Function

Private Function PD6_PairCandidateAllowed( _
        ByVal pairMateBySwitchPSU As Object, _
        ByVal switchKey As String, _
        ByVal psuBus1 As String, _
        ByVal psuBus2 As String) As Boolean

    Dim keyBus1 As String
    Dim keyBus2 As String

    PD6_PairCandidateAllowed = False
    If pairMateBySwitchPSU Is Nothing Then Exit Function

    keyBus1 = PD6_PairMateKey(switchKey, psuBus1)
    keyBus2 = PD6_PairMateKey(switchKey, psuBus2)

    If pairMateBySwitchPSU.Exists(keyBus1) Then
        If StrComp(CStr(pairMateBySwitchPSU(keyBus1)), psuBus2, vbTextCompare) <> 0 Then Exit Function
    End If

    If pairMateBySwitchPSU.Exists(keyBus2) Then
        If StrComp(CStr(pairMateBySwitchPSU(keyBus2)), psuBus1, vbTextCompare) <> 0 Then Exit Function
    End If

    PD6_PairCandidateAllowed = True

End Function

Private Function PD6_IsRegisteredPSUPair( _
        ByVal pairMateBySwitchPSU As Object, _
        ByVal switchKey As String, _
        ByVal psuBus1 As String, _
        ByVal psuBus2 As String) As Boolean

    Dim keyBus1 As String

    PD6_IsRegisteredPSUPair = False
    If pairMateBySwitchPSU Is Nothing Then Exit Function

    keyBus1 = PD6_PairMateKey(switchKey, psuBus1)
    If pairMateBySwitchPSU.Exists(keyBus1) Then
        PD6_IsRegisteredPSUPair = _
            (StrComp(CStr(pairMateBySwitchPSU(keyBus1)), psuBus2, vbTextCompare) = 0)
    End If

End Function

Private Sub PD6_RegisterPSUPair( _
        ByVal pairMateBySwitchPSU As Object, _
        ByVal switchKey As String, _
        ByVal psuBus1 As String, _
        ByVal psuBus2 As String)

    If pairMateBySwitchPSU Is Nothing Then Exit Sub
    If Len(Trim$(psuBus1)) = 0 Or Len(Trim$(psuBus2)) = 0 Then Exit Sub
    If UCase$(Trim$(psuBus1)) = UCase$(PSU_MISSING_TEXT) Then Exit Sub
    If UCase$(Trim$(psuBus2)) = UCase$(PSU_MISSING_TEXT) Then Exit Sub

    pairMateBySwitchPSU(PD6_PairMateKey(switchKey, psuBus1)) = psuBus2
    pairMateBySwitchPSU(PD6_PairMateKey(switchKey, psuBus2)) = psuBus1

End Sub

Private Function PD6_PSUSuffixOrdinal(ByVal psuName As String) As Long

    Dim u As String
    Dim psuPos As Long
    Dim suffixText As String
    Dim i As Long
    Dim digitsText As String

    PD6_PSUSuffixOrdinal = 0&
    u = UCase$(Trim$(psuName))
    psuPos = InStrRev(u, "-PSU", -1, vbTextCompare)
    If psuPos = 0 Then Exit Function

    suffixText = mid$(u, psuPos + 4)
    If Left$(suffixText, 1) = "-" Then suffixText = mid$(suffixText, 2)

    For i = 1 To Len(suffixText)
        If mid$(suffixText, i, 1) Like "#" Then
            digitsText = digitsText & mid$(suffixText, i, 1)
        ElseIf Len(digitsText) > 0 Then
            Exit For
        End If
    Next i

    If Len(digitsText) > 0 Then PD6_PSUSuffixOrdinal = CLng(digitsText)

End Function

Private Function PD6_PairMateKey(ByVal switchKey As String, ByVal psuName As String) As String

    PD6_PairMateKey = UCase$(Trim$(switchKey)) & "|" & UCase$(Trim$(psuName))

End Function

Private Sub PD6_AllocateRowToOneBus( _
        ByVal stateBySwitchBus As Object, _
        ByVal psuTotalLoadBySwitchPSU As Object, _
        ByVal psuOwnerBySwitchPSU As Object, _
        ByVal psuList As Collection, _
        ByVal switchVal As String, _
        ByVal switchKey As String, _
        ByVal busVal As String, _
        ByVal deviceLoad As Double, _
        ByVal moduleFt As Double, _
        ByVal lengthApplies As Boolean, _
        ByVal deviceRowNum As Long, _
        ByVal deviceSeqNum As Long, _
        ByVal psuRowBySwitchPSU As Object, _
        ByVal rowDistanceByRow As Object, _
        ByVal rowDistanceCountByRow As Object, _
        ByRef psuName As String, _
        ByRef terminalName As String, _
        ByRef warningText As String, _
        Optional ByVal requiredPSUName As String = "")

    Dim i As Long
    Dim candidateName As String
    Dim bestName As String
    Dim bestScore As Double
    Dim candidateScore As Double
    Dim psuTotalKey As String
    Dim currentTotalLoad As Double
    Dim psuLimitFt As Double
    Dim candidateState As Object
    Dim bestState As Object
    Dim stateKey As String
    Dim seqGap As Long
    Dim bestSeqGap As Long
    Dim usedOutsidePreferredGap As Boolean
    Dim candidateDistanceFt As Double
    Dim bestDistanceFt As Double
    Dim candidateLengthApplies As Boolean
    Dim bestLengthApplies As Boolean
    Dim candidateUsesXYZ As Boolean
    Dim bestUsesXYZ As Boolean
    Dim deviceHasXYZ As Boolean

    psuName = ""
    terminalName = ""

    If psuList Is Nothing Then Exit Sub
    If psuList.count = 0 Then Exit Sub

    If UCase$(Trim$(busVal)) = "BUS-1" Then
        psuLimitFt = BUS1_LIMIT_FT
    Else
        psuLimitFt = BUS2_LIMIT_FT
    End If

    bestName = ""
    bestScore = 1E+30
    bestSeqGap = 0&
    bestDistanceFt = moduleFt
    bestLengthApplies = lengthApplies
    bestUsesXYZ = False
    deviceHasXYZ = (mPD6UseXYZDistance And PD6_RowHasCoordinate(deviceRowNum))

    For i = 1 To psuList.count

        candidateName = CStr(psuList(i))
        If Len(Trim$(candidateName)) = 0 Then GoTo NextCandidate
        If UCase$(Trim$(candidateName)) = UCase$(PSU_MISSING_TEXT) Then GoTo NextCandidate
        If Len(Trim$(requiredPSUName)) > 0 Then
            If StrComp(Trim$(candidateName), Trim$(requiredPSUName), vbTextCompare) <> 0 Then GoTo NextCandidate
        End If

        'PSU, PSU-1, PSU-2, PSU-3, and other PSU-x names are all eligible
        'for either BUS. The suffix is an ordinal used only to distinguish
        'multiple PSUs that share the same SIS number.

        If PD6_PSUOwnedByOtherBus(psuOwnerBySwitchPSU, switchKey, candidateName, busVal) Then GoTo NextCandidate

        psuTotalKey = PD6_PsuTotalKey(switchKey, candidateName)
        currentTotalLoad = PD6_GetDictDouble(psuTotalLoadBySwitchPSU, psuTotalKey)
        If deviceLoad > 0 Then
            If currentTotalLoad + deviceLoad > PSU_ALLOC_LIMIT_A Then GoTo NextCandidate
        End If

        stateKey = PD6_PsuBusStateKey(switchKey, busVal, candidateName)
        Set candidateState = PD6_GetState(stateBySwitchBus, stateKey)

        PD6_ResolveCandidateDistance switchKey, candidateName, deviceRowNum, _
            moduleFt, lengthApplies, candidateDistanceFt, candidateLengthApplies, candidateUsesXYZ

        If Not PD6_CandidatePSUCanAccept(candidateState, deviceLoad, candidateDistanceFt, _
            candidateLengthApplies, psuLimitFt) Then
            GoTo NextCandidate
        End If

        If deviceHasXYZ Then
            candidateScore = PD6_CoordinateCandidateSelectionScore( _
                candidateName, deviceSeqNum, currentTotalLoad, candidateState, _
                candidateDistanceFt, candidateUsesXYZ)
        Else
            candidateScore = PD6_PSUAllocationScore(candidateName, deviceSeqNum, currentTotalLoad, candidateState)
        End If

        If candidateScore < bestScore Then
            bestScore = candidateScore
            bestName = candidateName
            Set bestState = candidateState
            seqGap = PD6_SequenceGapForPSU(candidateName, deviceSeqNum)
            bestSeqGap = seqGap
            bestDistanceFt = candidateDistanceFt
            bestLengthApplies = candidateLengthApplies
            bestUsesXYZ = candidateUsesXYZ
        End If

NextCandidate:
    Next i

    If Len(bestName) = 0 Then
        PD6_AddAllocationWarning warningText, _
            "MISSING PSU for " & busVal & " in " & switchVal & _
            "; no eligible PSU type in this Panel + SwitchGroup can accept the load without exceeding " & _
            PD6_FormatAmp(PSU_ALLOC_LIMIT_A) & "A per PSU or " & _
            PD6_FormatAmp(TERM_LIMIT_A) & "A per terminal."
        psuName = PSU_MISSING_TEXT
        terminalName = ""
        Exit Sub
    End If

    psuName = bestName

    If CLng(bestState("TERM_IDX")) > MAX_TERMINALS_PER_BUS Then
        PD6_AddAllocationWarning warningText, _
            "MISSING PSU for " & busVal & "; selected PSU has no available terminal."
        psuName = PSU_MISSING_TEXT
        terminalName = ""
        Exit Sub
    End If

    If bestState("TERM_COUNT") > 0 Then
        If PD6_ShouldAdvanceTerminal(bestState, deviceLoad, bestDistanceFt, bestLengthApplies) Then
            bestState("TERM_IDX") = CLng(bestState("TERM_IDX")) + 1&
            bestState("TERM_LOAD") = 0#
            bestState("TERM_LEN") = 0#
            bestState("TERM_COUNT") = 0&
        End If
    End If

    If CLng(bestState("TERM_IDX")) > MAX_TERMINALS_PER_BUS Then
        PD6_AddAllocationWarning warningText, _
            "MISSING PSU for " & busVal & "; " & psuName & _
            " has used all " & CStr(MAX_TERMINALS_PER_BUS) & " terminals."
        psuName = PSU_MISSING_TEXT
        terminalName = ""
        Exit Sub
    End If

    If PD6_WouldExceedTerminal(bestState, deviceLoad, bestDistanceFt, bestLengthApplies) Then
        PD6_AddAllocationWarning warningText, _
            "MISSING PSU for " & busVal & "; load " & PD6_FormatAmp(deviceLoad) & _
            "A would exceed the " & PD6_FormatAmp(TERM_LIMIT_A) & "A terminal cap."
        psuName = PSU_MISSING_TEXT
        terminalName = ""
        Exit Sub
    End If

    If bestLengthApplies Then
        If CDbl(bestState("PSU_LEN")) + bestDistanceFt > psuLimitFt Then
            PD6_AddAllocationWarning warningText, _
                "MISSING PSU for " & busVal & "; row would exceed the PSU length limit."
            psuName = PSU_MISSING_TEXT
            terminalName = ""
            Exit Sub
        End If
    End If

    currentTotalLoad = PD6_GetDictDouble(psuTotalLoadBySwitchPSU, PD6_PsuTotalKey(switchKey, psuName))
    If deviceLoad > 0 Then
        If currentTotalLoad + deviceLoad > PSU_ALLOC_LIMIT_A Then
            PD6_AddAllocationWarning warningText, _
                "MISSING PSU for " & busVal & "; load " & PD6_FormatAmp(deviceLoad) & _
                "A would exceed the " & PD6_FormatAmp(PSU_ALLOC_LIMIT_A) & "A PSU cap."
            psuName = PSU_MISSING_TEXT
            terminalName = ""
            Exit Sub
        End If
    End If

    terminalName = PD6_TerminalName(CLng(bestState("TERM_IDX")))

    bestState("PSU_LOAD") = CDbl(bestState("PSU_LOAD")) + deviceLoad
    If bestLengthApplies Then bestState("PSU_LEN") = CDbl(bestState("PSU_LEN")) + bestDistanceFt
    bestState("PSU_COUNT") = CLng(bestState("PSU_COUNT")) + 1&

    bestState("TERM_LOAD") = CDbl(bestState("TERM_LOAD")) + deviceLoad
    If bestLengthApplies Then bestState("TERM_LEN") = CDbl(bestState("TERM_LEN")) + bestDistanceFt
    bestState("TERM_COUNT") = CLng(bestState("TERM_COUNT")) + 1&

    psuTotalKey = PD6_PsuTotalKey(switchKey, psuName)
    psuTotalLoadBySwitchPSU(psuTotalKey) = currentTotalLoad + deviceLoad
    PD6_SetPSUOwner psuOwnerBySwitchPSU, switchKey, psuName, busVal

    If bestUsesXYZ Then
        mPD6CoordinateDistanceUsedCount = mPD6CoordinateDistanceUsedCount + 1&
    Else
        mPD6FallbackDistanceUsedCount = mPD6FallbackDistanceUsedCount + 1&
    End If

    If deviceSeqNum > 0 And bestSeqGap > PSU_DEVICE_MAX_NUMBER_GAP Then
        usedOutsidePreferredGap = True
    End If

    If usedOutsidePreferredGap Then
        PD6_AddAllocationWarning warningText, _
            busVal & " assigned to closest available PSU " & psuName & _
            " in same Panel + SwitchGroup; sequence gap " & CStr(bestSeqGap) & _
            " is over preferred gap " & CStr(PSU_DEVICE_MAX_NUMBER_GAP) & "."
    End If

End Sub

Private Function PD6_PsuBusStateKey(ByVal switchKey As String, ByVal busVal As String, ByVal psuName As String) As String

    PD6_PsuBusStateKey = UCase$(Trim$(switchKey)) & "|" & UCase$(Trim$(busVal)) & "|" & UCase$(Trim$(psuName))

End Function

Private Function PD6_CandidatePSUCanAccept( _
        ByVal state As Object, _
        ByVal deviceLoad As Double, _
        ByVal moduleFt As Double, _
        ByVal lengthApplies As Boolean, _
        ByVal psuLimitFt As Double) As Boolean

    Dim nextTermIdx As Long

    PD6_CandidatePSUCanAccept = False
    If state Is Nothing Then Exit Function

    If lengthApplies Then
        If CDbl(state("PSU_LEN")) + moduleFt > psuLimitFt Then Exit Function
    End If

    nextTermIdx = CLng(state("TERM_IDX"))
    If nextTermIdx < 1 Then nextTermIdx = 1

    If nextTermIdx > MAX_TERMINALS_PER_BUS Then Exit Function

    If state("TERM_COUNT") > 0 Then
        If PD6_ShouldAdvanceTerminal(state, deviceLoad, moduleFt, lengthApplies) Then
            nextTermIdx = nextTermIdx + 1&
            If nextTermIdx > MAX_TERMINALS_PER_BUS Then Exit Function
            If deviceLoad > TERM_LIMIT_A Then Exit Function
            If lengthApplies Then
                If moduleFt > TERM_LIMIT_FT Then Exit Function
            End If
        End If
    Else
        If deviceLoad > TERM_LIMIT_A Then Exit Function
        If lengthApplies Then
            If moduleFt > TERM_LIMIT_FT Then Exit Function
        End If
    End If

    PD6_CandidatePSUCanAccept = True

End Function

Private Function PD6_PSUAllocationScore( _
        ByVal psuName As String, _
        ByVal deviceSeqNum As Long, _
        ByVal currentTotalLoad As Double, _
        ByVal state As Object) As Double

    Dim seqGap As Long
    Dim penalty As Double
    Dim termPenalty As Double
    Dim reusePenalty As Double

    seqGap = PD6_SequenceGapForPSU(psuName, deviceSeqNum)

    If deviceSeqNum > 0 And seqGap > PSU_DEVICE_MAX_NUMBER_GAP Then
        penalty = 100000000#
    Else
        penalty = 0#
    End If

    If Not state Is Nothing Then
        termPenalty = CDbl(CLng(state("TERM_IDX"))) * 10# + CDbl(CLng(state("TERM_COUNT")))
        If CLng(state("PSU_COUNT")) > 0 Then reusePenalty = -100#
    Else
        termPenalty = 0#
        reusePenalty = 0#
    End If

    PD6_PSUAllocationScore = penalty + (CDbl(seqGap) * 1000#) + termPenalty + reusePenalty + (currentTotalLoad / 1000#)

End Function

Private Function PD6_SequenceGapForPSU(ByVal psuName As String, ByVal deviceSeqNum As Long) As Long

    Dim psuNum As Long

    If deviceSeqNum <= 0 Then
        PD6_SequenceGapForPSU = 0&
        Exit Function
    End If

    psuNum = PD6_FirstNumberFromPSUName(psuName)
    If psuNum <= 0 Then
        PD6_SequenceGapForPSU = 0&
    Else
        PD6_SequenceGapForPSU = Abs(psuNum - deviceSeqNum)
    End If

End Function

Private Function PD6_PSUOwnedByOtherBus(ByVal psuOwnerBySwitchPSU As Object, ByVal switchKey As String, ByVal psuName As String, ByVal busVal As String) As Boolean

    Dim ownerKey As String
    Dim existingOwner As String

    PD6_PSUOwnedByOtherBus = False
    If psuOwnerBySwitchPSU Is Nothing Then Exit Function

    ownerKey = PD6_PsuTotalKey(switchKey, psuName)
    If Not psuOwnerBySwitchPSU.Exists(ownerKey) Then Exit Function

    existingOwner = UCase$(Trim$(CStr(psuOwnerBySwitchPSU(ownerKey))))
    If Len(existingOwner) = 0 Then Exit Function

    PD6_PSUOwnedByOtherBus = (existingOwner <> UCase$(Trim$(busVal)))

End Function

Private Sub PD6_SetPSUOwner(ByVal psuOwnerBySwitchPSU As Object, ByVal switchKey As String, ByVal psuName As String, ByVal busVal As String)

    Dim ownerKey As String

    If psuOwnerBySwitchPSU Is Nothing Then Exit Sub
    If Len(Trim$(psuName)) = 0 Then Exit Sub
    If Len(Trim$(busVal)) = 0 Then Exit Sub

    ownerKey = PD6_PsuTotalKey(switchKey, psuName)
    If Not psuOwnerBySwitchPSU.Exists(ownerKey) Then
        psuOwnerBySwitchPSU.Add ownerKey, UCase$(Trim$(busVal))
    End If

End Sub

Private Function PD6_DeviceSequenceNumber(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal cSisSeq As Long, ByVal cSisElem As Long, ByVal cControl As Long) As Long

    Dim n As Long

    If cSisSeq > 0 Then
        n = PD6_LastMeaningfulNumber(CStr(ws.Cells(rowNum, cSisSeq).value))
        If n > 0 Then
            PD6_DeviceSequenceNumber = n
            Exit Function
        End If
    End If

    If cSisElem > 0 Then
        n = PD6_LastMeaningfulNumber(CStr(ws.Cells(rowNum, cSisElem).value))
        If n > 0 Then
            PD6_DeviceSequenceNumber = n
            Exit Function
        End If
    End If

    If cControl > 0 Then
        n = PD6_LastMeaningfulNumber(CStr(ws.Cells(rowNum, cControl).value))
        If n > 0 Then
            PD6_DeviceSequenceNumber = n
            Exit Function
        End If
    End If

    PD6_DeviceSequenceNumber = 0&

End Function

Private Function PD6_LastMeaningfulNumber(ByVal valueIn As String) As Long

    Dim i As Long
    Dim ch As String
    Dim digitsText As String
    Dim lastAnyNumber As String
    Dim lastMeaningfulNumber As String

    digitsText = ""
    lastAnyNumber = ""
    lastMeaningfulNumber = ""

    For i = 1 To Len(valueIn)
        ch = mid$(valueIn, i, 1)
        If ch >= "0" And ch <= "9" Then
            digitsText = digitsText & ch
        Else
            If Len(digitsText) > 0 Then
                lastAnyNumber = digitsText
                If Len(digitsText) >= 3 Then lastMeaningfulNumber = digitsText
                digitsText = ""
            End If
        End If
    Next i

    If Len(digitsText) > 0 Then
        lastAnyNumber = digitsText
        If Len(digitsText) >= 3 Then lastMeaningfulNumber = digitsText
    End If

    If Len(lastMeaningfulNumber) > 0 Then
        PD6_LastMeaningfulNumber = CLng(lastMeaningfulNumber)
    ElseIf Len(lastAnyNumber) > 0 Then
        PD6_LastMeaningfulNumber = CLng(lastAnyNumber)
    Else
        PD6_LastMeaningfulNumber = 0&
    End If

End Function

Private Function PD6_PSUIsNearDeviceSequence(ByVal psuName As String, ByVal deviceSeqNum As Long, ByVal maxNumberGap As Long) As Boolean

    Dim psuNum As Long

    If deviceSeqNum <= 0 Or maxNumberGap <= 0 Then
        PD6_PSUIsNearDeviceSequence = True
        Exit Function
    End If

    psuNum = PD6_FirstNumberFromPSUName(psuName)
    If psuNum <= 0 Then
        PD6_PSUIsNearDeviceSequence = True
    Else
        PD6_PSUIsNearDeviceSequence = (Abs(psuNum - deviceSeqNum) <= maxNumberGap)
    End If

End Function

Private Function PD6_PSUIsNearDevicePlacement( _
        ByVal psuRowBySwitchPSU As Object, _
        ByVal rowDistanceByRow As Object, _
        ByVal rowDistanceCountByRow As Object, _
        ByVal switchKey As String, _
        ByVal psuName As String, _
        ByVal deviceRowNum As Long, _
        ByVal maxDistanceFt As Double, _
        ByVal deviceSeqNum As Long, _
        ByVal fallbackMaxNumberGap As Long) As Boolean

    PD6_PSUIsNearDevicePlacement = PD6_PSUIsNearDeviceSequence(psuName, deviceSeqNum, fallbackMaxNumberGap)

End Function

Private Function PD6_FindNextFreeNearDevicePSUIndex( _
        ByVal psuOwnerBySwitchPSU As Object, _
        ByVal psuList As Collection, _
        ByVal switchKey As String, _
        ByVal busVal As String, _
        ByVal startIndex As Long, _
        ByVal deviceRowNum As Long, _
        ByVal maxDistanceFt As Double, _
        ByVal deviceSeqNum As Long, _
        ByVal maxNumberGap As Long, _
        ByVal psuRowBySwitchPSU As Object, _
        ByVal rowDistanceByRow As Object, _
        ByVal rowDistanceCountByRow As Object) As Long

    Dim i As Long
    Dim candidateName As String
    Dim candidateNum As Long
    Dim gap As Long
    Dim bestGap As Long
    Dim bestIndex As Long

    PD6_FindNextFreeNearDevicePSUIndex = 0
    If psuList Is Nothing Then Exit Function
    If startIndex < 1 Then startIndex = 1
    If startIndex > psuList.count Then Exit Function

    bestIndex = 0
    bestGap = 2147483647

    For i = startIndex To psuList.count
        candidateName = CStr(psuList(i))
        If Not PD6_PSUOwnedByOtherBus(psuOwnerBySwitchPSU, switchKey, candidateName, busVal) Then
            If deviceSeqNum <= 0 Or maxNumberGap <= 0 Then
                PD6_FindNextFreeNearDevicePSUIndex = i
                Exit Function
            Else
                candidateNum = PD6_FirstNumberFromPSUName(candidateName)
                If candidateNum <= 0 Then
                    gap = 0
                Else
                    gap = Abs(candidateNum - deviceSeqNum)
                End If

                If gap <= maxNumberGap Then
                    If gap < bestGap Then
                        bestGap = gap
                        bestIndex = i
                    End If
                End If
            End If
        End If
    Next i

    PD6_FindNextFreeNearDevicePSUIndex = bestIndex

End Function

Private Function PD6_FindNextFreeNearPSUIndex( _
        ByVal psuOwnerBySwitchPSU As Object, _
        ByVal psuList As Collection, _
        ByVal switchKey As String, _
        ByVal basePsuName As String, _
        ByVal busVal As String, _
        ByVal startIndex As Long, _
        ByVal maxNumberGap As Long, _
        ByVal deviceRowNum As Long, _
        ByVal maxDistanceFt As Double, _
        ByVal deviceSeqNum As Long, _
        ByVal deviceMaxNumberGap As Long, _
        ByVal psuRowBySwitchPSU As Object, _
        ByVal rowDistanceByRow As Object, _
        ByVal rowDistanceCountByRow As Object) As Long

    Dim i As Long
    Dim candidateName As String
    Dim baseNum As Long
    Dim candidateNum As Long
    Dim pairGap As Long
    Dim deviceGap As Long
    Dim score As Double
    Dim bestScore As Double
    Dim bestIndex As Long
    Dim candidateOk As Boolean

    PD6_FindNextFreeNearPSUIndex = 0
    If psuList Is Nothing Then Exit Function
    If startIndex < 1 Then startIndex = 1
    If startIndex > psuList.count Then Exit Function

    baseNum = PD6_FirstNumberFromPSUName(basePsuName)
    bestIndex = 0
    bestScore = 1E+30

    For i = startIndex To psuList.count
        candidateName = CStr(psuList(i))
        If Not PD6_PSUOwnedByOtherBus(psuOwnerBySwitchPSU, switchKey, candidateName, busVal) Then
            candidateNum = PD6_FirstNumberFromPSUName(candidateName)
            candidateOk = True

            If baseNum > 0 And candidateNum > 0 And maxNumberGap > 0 Then
                pairGap = Abs(candidateNum - baseNum)
                If pairGap > maxNumberGap Then candidateOk = False
            Else
                pairGap = 0
            End If

            If candidateOk And deviceSeqNum > 0 And candidateNum > 0 And deviceMaxNumberGap > 0 Then
                deviceGap = Abs(candidateNum - deviceSeqNum)
                If deviceGap > deviceMaxNumberGap Then candidateOk = False
            Else
                deviceGap = 0
            End If

            If candidateOk Then
                score = CDbl(deviceGap) * 1000# + CDbl(pairGap)
                If score < bestScore Then
                    bestScore = score
                    bestIndex = i
                End If
            End If
        End If
    Next i

    PD6_FindNextFreeNearPSUIndex = bestIndex

End Function

Private Sub PD6_BuildModuleLengthPositionLookups( _
        ByVal ws As Worksheet, _
        ByVal lastRow As Long, _
        ByVal cSwitch As Long, _
        ByVal cML As Long, _
        ByVal rowDistanceByRow As Object, _
        ByVal rowDistanceCountByRow As Object)

    Dim runningFtBySwitch As Object
    Dim runningCountBySwitch As Object
    Dim r As Long
    Dim switchKey As String
    Dim moduleFt As Double
    Dim runningFt As Double
    Dim runningCount As Long

    If ws Is Nothing Then Exit Sub
    If rowDistanceByRow Is Nothing Or rowDistanceCountByRow Is Nothing Then Exit Sub
    If cSwitch <= 0 Or cML <= 0 Then Exit Sub

    Set runningFtBySwitch = CreateObject("Scripting.Dictionary")
    Set runningCountBySwitch = CreateObject("Scripting.Dictionary")

    For r = 2 To lastRow
        switchKey = PD6_SwitchKey(CStr(ws.Cells(r, cSwitch).value))
        If Len(switchKey) > 0 Then
            If runningFtBySwitch.Exists(switchKey) Then
                runningFt = CDbl(runningFtBySwitch(switchKey))
                runningCount = CLng(runningCountBySwitch(switchKey))
            Else
                runningFt = 0#
                runningCount = 0&
            End If

            moduleFt = PD6_ModuleLengthFeet(ws.Cells(r, cML).value)
            If moduleFt > 0 Then
                runningFt = runningFt + moduleFt
                runningCount = runningCount + 1&
            End If

            rowDistanceByRow(CStr(r)) = runningFt
            rowDistanceCountByRow(CStr(r)) = runningCount
            runningFtBySwitch(switchKey) = runningFt
            runningCountBySwitch(switchKey) = runningCount
        End If
    Next r

End Sub

Private Function PD6_FormatFeet(ByVal n As Double) As String

    If n = Fix(n) Then
        PD6_FormatFeet = CStr(CLng(n))
    Else
        PD6_FormatFeet = Format$(n, "0.##")
    End If

End Function

Private Function PD6_FirstNumberFromPSUName(ByVal psuName As String) As Long

    Dim i As Long
    Dim ch As String
    Dim digitsText As String
    Dim scanText As String
    Dim psuPos As Long

    scanText = Trim$(psuName)
    psuPos = InStr(1, UCase$(scanText), "-PSU", vbTextCompare)
    If psuPos > 1 Then scanText = Left$(scanText, psuPos - 1)

    digitsText = ""
    For i = Len(scanText) To 1 Step -1
        ch = mid$(scanText, i, 1)
        If ch >= "0" And ch <= "9" Then
            digitsText = ch & digitsText
        ElseIf Len(digitsText) > 0 Then
            Exit For
        End If
    Next i

    If Len(digitsText) > 0 Then
        PD6_FirstNumberFromPSUName = CLng(digitsText)
    Else
        PD6_FirstNumberFromPSUName = 0&
    End If

End Function

Private Function PD6_PairedPSUNameForBus(ByVal psuName As String, ByVal busVal As String) As String

    Dim p As String
    Dim suffixText As String
    Dim u As String

    p = Trim$(psuName)
    u = UCase$(p)

    If UCase$(Trim$(busVal)) = "BUS-2" Then
        suffixText = "-2"
    Else
        suffixText = "-1"
    End If

    If Len(p) = 0 Then
        PD6_PairedPSUNameForBus = "PSU" & suffixText
        Exit Function
    End If

    If Right$(u, Len(suffixText)) = suffixText Then
        PD6_PairedPSUNameForBus = p
    Else
        PD6_PairedPSUNameForBus = p & suffixText
    End If

End Function

Private Function PD6_PsuTotalKey(ByVal switchKey As String, ByVal psuName As String) As String

    PD6_PsuTotalKey = UCase$(Trim$(switchKey)) & "|" & UCase$(Trim$(psuName))

End Function

Private Function PD6_GetDictDouble(ByVal dictObj As Object, ByVal keyText As String) As Double

    If dictObj Is Nothing Then
        PD6_GetDictDouble = 0#
    ElseIf dictObj.Exists(keyText) Then
        If IsNumeric(dictObj(keyText)) Then
            PD6_GetDictDouble = CDbl(dictObj(keyText))
        Else
            PD6_GetDictDouble = 0#
        End If
    Else
        PD6_GetDictDouble = 0#
    End If

End Function

Private Sub PD6_ResetStateForNextPSU(ByVal state As Object)

    state("PSU_IDX") = CLng(state("PSU_IDX")) + 1
    state("PSU_LOAD") = 0#
    state("PSU_LEN") = 0#
    state("PSU_COUNT") = 0&
    state("TERM_IDX") = 1&
    state("TERM_LOAD") = 0#
    state("TERM_LEN") = 0#
    state("TERM_COUNT") = 0&

End Sub

Private Sub PD6_AddAllocationWarning(ByRef warningText As String, ByVal addText As String)

    If Len(Trim$(addText)) = 0 Then Exit Sub
    If Len(warningText) > 0 Then warningText = warningText & " | "
    warningText = warningText & addText

End Sub

Private Function PD6_ShouldAdvancePSU(ByVal state As Object, ByVal busVal As String, ByVal deviceLoad As Double, ByVal moduleFt As Double, ByVal lengthApplies As Boolean, ByVal psuLimitFt As Double) As Boolean

    PD6_ShouldAdvancePSU = PD6_WouldExceedPSU(state, deviceLoad, moduleFt, lengthApplies, psuLimitFt)

End Function

Private Function PD6_WouldExceedPSU(ByVal state As Object, ByVal deviceLoad As Double, ByVal moduleFt As Double, ByVal lengthApplies As Boolean, ByVal psuLimitFt As Double) As Boolean

    PD6_WouldExceedPSU = False

    If deviceLoad > 0 Then
        If CDbl(state("PSU_LOAD")) + deviceLoad > PSU_ALLOC_LIMIT_A Then
            PD6_WouldExceedPSU = True
            Exit Function
        End If
    End If

    If lengthApplies Then
        If CDbl(state("PSU_LEN")) + moduleFt > psuLimitFt Then
            PD6_WouldExceedPSU = True
            Exit Function
        End If
    End If

End Function

Private Function PD6_ShouldAdvanceTerminal(ByVal state As Object, ByVal deviceLoad As Double, ByVal moduleFt As Double, ByVal lengthApplies As Boolean) As Boolean

    PD6_ShouldAdvanceTerminal = PD6_WouldExceedTerminal(state, deviceLoad, moduleFt, lengthApplies)

End Function

Private Function PD6_WouldExceedTerminal(ByVal state As Object, ByVal deviceLoad As Double, ByVal moduleFt As Double, ByVal lengthApplies As Boolean) As Boolean

    PD6_WouldExceedTerminal = False

    If deviceLoad > 0 Then
        If CDbl(state("TERM_LOAD")) + deviceLoad > TERM_LIMIT_A Then
            PD6_WouldExceedTerminal = True
            Exit Function
        End If
    End If

    If lengthApplies Then
        If CDbl(state("TERM_LEN")) + moduleFt > TERM_LIMIT_FT Then
            PD6_WouldExceedTerminal = True
            Exit Function
        End If
    End If

End Function

Private Function PD6_FormatAmp(ByVal n As Double) As String

    If n = Fix(n) Then
        PD6_FormatAmp = CStr(CLng(n))
    Else
        PD6_FormatAmp = CStr(n)
    End If

End Function

Private Function PD6_GetState(ByVal stateByKey As Object, ByVal keyText As String) As Object

    Dim st As Object

    If stateByKey.Exists(keyText) Then
        Set PD6_GetState = stateByKey(keyText)
        Exit Function
    End If

    Set st = CreateObject("Scripting.Dictionary")
    st("PSU_IDX") = 1&
    st("PSU_LOAD") = 0#
    st("PSU_LEN") = 0#
    st("PSU_COUNT") = 0&
    st("TERM_IDX") = 1&
    st("TERM_LOAD") = 0#
    st("TERM_LEN") = 0#
    st("TERM_COUNT") = 0&

    stateByKey.Add keyText, st
    Set PD6_GetState = st

End Function

Private Function PD6_LoadForBus(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal busVal As String, ByVal cLoadBus1 As Long, ByVal cLoadBus2 As Long, ByVal cLoadFallback As Long) As Double

    Dim targetCol As Long
    Dim rawValue As Variant

    If UCase$(Trim$(busVal)) = "BUS-1" Then
        targetCol = cLoadBus1
    ElseIf UCase$(Trim$(busVal)) = "BUS-2" Then
        targetCol = cLoadBus2
    End If

    If targetCol > 0 Then
        rawValue = ws.Cells(rowNum, targetCol).value
        If Not IsError(rawValue) Then
            If Len(Trim$(CStr(rawValue))) > 0 Then
                PD6_LoadForBus = PD6_CellDouble(ws, rowNum, targetCol)
                Exit Function
            End If
        End If
    End If

    PD6_LoadForBus = PD6_CellDouble(ws, rowNum, cLoadFallback)

End Function

Private Function PD6_AllocationLoadForBus(ByVal typeVal As String, ByVal busVal As String, ByVal sourceLoad As Double) As Double

    Dim dataBus1 As Variant
    Dim dataBus2 As Variant
    Dim selectedValue As Variant
    Dim needsBus1 As Boolean
    Dim needsBus2 As Boolean
    Dim selectedEnabled As Boolean

    PD6_AllocationLoadForBus = 0#

    If Not PD6_GetDataPowerBusRuleValues(typeVal, dataBus1, dataBus2, needsBus1, needsBus2) Then Exit Function

    If UCase$(Trim$(busVal)) = "BUS-1" Then
        selectedValue = dataBus1
        selectedEnabled = needsBus1
    ElseIf UCase$(Trim$(busVal)) = "BUS-2" Then
        selectedValue = dataBus2
        selectedEnabled = needsBus2
    Else
        Exit Function
    End If

    If Not selectedEnabled Then Exit Function

    If Len(Trim$(CStr(selectedValue))) > 0 And IsNumeric(selectedValue) Then
        PD6_AllocationLoadForBus = CDbl(selectedValue)
    Else
        PD6_AllocationLoadForBus = sourceLoad
    End If

End Function

Private Function PD6_BusesForType(ByVal typeVal As String) As Collection

    Dim buses As Collection
    Dim dataBus1 As Variant
    Dim dataBus2 As Variant
    Dim needsBus1 As Boolean
    Dim needsBus2 As Boolean

    Set buses = New Collection

    If PD6_GetDataPowerBusRuleValues(typeVal, dataBus1, dataBus2, needsBus1, needsBus2) Then
        If needsBus1 Then PD6_AddBusToCollection buses, "BUS-1"
        If needsBus2 Then PD6_AddBusToCollection buses, "BUS-2"
    End If

    Set PD6_BusesForType = buses

End Function

Private Function PD6_TypeHasDataPower24VRule(ByVal typeVal As String) As Boolean

    Dim bus1Value As Variant
    Dim bus2Value As Variant
    Dim needsBus1 As Boolean
    Dim needsBus2 As Boolean

    PD6_TypeHasDataPower24VRule = PD6_GetDataPowerBusRuleValues(typeVal, bus1Value, bus2Value, needsBus1, needsBus2)

End Function

Private Sub PD6_AddBusToCollection(ByVal buses As Collection, ByVal busLabel As String)

    If buses Is Nothing Then Exit Sub
    If Len(Trim$(busLabel)) = 0 Then Exit Sub

    On Error Resume Next
    buses.Add UCase$(Trim$(busLabel)), UCase$(Trim$(busLabel))
    On Error GoTo 0

End Sub

Private Sub PD6_AddUniqueText(ByRef targetText As String, ByVal addText As String, ByVal delimiterText As String)

    If Len(Trim$(addText)) = 0 Then Exit Sub

    If Len(targetText) = 0 Then
        targetText = addText
    ElseIf InStr(1, delimiterText & targetText & delimiterText, delimiterText & addText & delimiterText, vbTextCompare) = 0 Then
        targetText = targetText & delimiterText & addText
    End If

End Sub

Private Function PD6_ReadColumnFast(ByVal ws As Worksheet, ByVal lastRow As Long, ByVal colNum As Long) As Variant
    Dim blankData() As Variant
    Dim rowCount As Long

    rowCount = lastRow - 1&
    If rowCount < 1 Then rowCount = 1

    If colNum > 0 Then
        PD6_ReadColumnFast = ws.Range(ws.Cells(2, colNum), ws.Cells(lastRow, colNum)).Value2
    Else
        ReDim blankData(1 To rowCount, 1 To 1)
        PD6_ReadColumnFast = blankData
    End If
End Function

Private Function PD6_BlankColumnFast(ByVal rowCount As Long) As Variant
    Dim blankData() As Variant
    If rowCount < 1 Then rowCount = 1
    ReDim blankData(1 To rowCount, 1 To 1)
    PD6_BlankColumnFast = blankData
End Function

Private Function PD6_ArrayValueFast(ByRef dataIn As Variant, ByVal indexValue As Long) As Variant
    On Error GoTo BlankValue
    If IsError(dataIn(indexValue, 1)) Or IsNull(dataIn(indexValue, 1)) Then GoTo BlankValue
    PD6_ArrayValueFast = dataIn(indexValue, 1)
    Exit Function
BlankValue:
    PD6_ArrayValueFast = Empty
End Function

Private Function PD6_ArrayTextFast(ByRef dataIn As Variant, ByVal indexValue As Long) As String
    Dim v As Variant
    v = PD6_ArrayValueFast(dataIn, indexValue)
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        PD6_ArrayTextFast = vbNullString
    Else
        PD6_ArrayTextFast = Trim$(CStr(v))
    End If
End Function

Private Function PD6_ValueDoubleFast(ByVal valueIn As Variant) As Double
    Dim s As String
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function
    If IsNumeric(valueIn) Then
        PD6_ValueDoubleFast = CDbl(valueIn)
        Exit Function
    End If

    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace(s, "FEET", vbNullString)
    s = Replace(s, "FT", vbNullString)
    s = Replace(s, "MM", vbNullString)
    s = Replace(s, "IN", vbNullString)
    s = Replace(s, "AMPS", vbNullString)
    s = Replace(s, "AMP", vbNullString)
    s = Replace(s, "KW", vbNullString)
    s = Replace(s, "A", vbNullString)
    s = Replace(s, "W", vbNullString)
    s = Replace(s, "V", vbNullString)
    s = Replace(s, ",", vbNullString)
    s = Trim$(s)
    If IsNumeric(s) Then PD6_ValueDoubleFast = CDbl(s)
End Function

Private Function PD6_LoadForBusValues(ByVal busVal As String, ByVal bus1Value As Variant, _
                                       ByVal bus2Value As Variant, ByVal fallbackValue As Variant) As Double
    Dim selectedValue As Variant

    If UCase$(Trim$(busVal)) = "BUS-1" Then
        selectedValue = bus1Value
    ElseIf UCase$(Trim$(busVal)) = "BUS-2" Then
        selectedValue = bus2Value
    Else
        selectedValue = Empty
    End If

    If Not IsError(selectedValue) And Not IsNull(selectedValue) Then
        If Len(Trim$(CStr(selectedValue))) > 0 Then
            PD6_LoadForBusValues = PD6_ValueDoubleFast(selectedValue)
            Exit Function
        End If
    End If

    PD6_LoadForBusValues = PD6_ValueDoubleFast(fallbackValue)
End Function

Private Function PD6_RowIsPSUValues(ByVal typeText As String, ByVal sisElement As String, _
                                     ByVal controlID As String, ByVal sisSequence As String) As Boolean
    If PD6_IsPSUType(typeText) Then
        PD6_RowIsPSUValues = True
    ElseIf PD6_TextLooksLikePSUName(sisElement) Then
        PD6_RowIsPSUValues = True
    ElseIf PD6_TextLooksLikePSUName(controlID) Then
        PD6_RowIsPSUValues = True
    ElseIf PD6_TextLooksLikePSUName(sisSequence) Then
        PD6_RowIsPSUValues = True
    End If
End Function

Private Function PD6_PSUNameFromValues(ByVal sisElement As String, ByVal controlID As String, _
                                        ByVal sisSequence As String, ByVal typeText As String) As String
    If PD6_TextLooksLikePSUInstanceName(controlID) Then
        PD6_PSUNameFromValues = Trim$(controlID)
    ElseIf PD6_TextLooksLikePSUInstanceName(sisElement) Then
        PD6_PSUNameFromValues = Trim$(sisElement)
    ElseIf PD6_TextLooksLikePSUInstanceName(sisSequence) Then
        PD6_PSUNameFromValues = Trim$(sisSequence)
    ElseIf PD6_TextLooksLikePSUName(controlID) Then
        PD6_PSUNameFromValues = Trim$(controlID)
    ElseIf PD6_TextLooksLikePSUName(sisElement) Then
        PD6_PSUNameFromValues = Trim$(sisElement)
    ElseIf PD6_TextLooksLikePSUName(sisSequence) Then
        PD6_PSUNameFromValues = Trim$(sisSequence)
    ElseIf Len(Trim$(sisElement)) > 0 Then
        PD6_PSUNameFromValues = Trim$(sisElement)
    ElseIf Len(Trim$(controlID)) > 0 Then
        PD6_PSUNameFromValues = Trim$(controlID)
    ElseIf Len(Trim$(sisSequence)) > 0 Then
        PD6_PSUNameFromValues = Trim$(sisSequence)
    ElseIf PD6_IsPSUType(typeText) Then
        PD6_PSUNameFromValues = Trim$(typeText)
    End If
End Function

Private Function PD6_DeviceSequenceNumberValues(ByVal sisSequence As String, ByVal sisElement As String, _
                                                 ByVal controlID As String) As Long
    Dim n As Long
    n = PD6_LastMeaningfulNumber(sisSequence)
    If n <= 0 Then n = PD6_LastMeaningfulNumber(sisElement)
    If n <= 0 Then n = PD6_LastMeaningfulNumber(controlID)
    PD6_DeviceSequenceNumberValues = n
End Function

Private Function PD6_AllocationSortKeyValues(ByVal panelText As String, ByVal switchText As String, _
                                              ByVal sisSequence As String, ByVal sisElement As String, _
                                              ByVal controlID As String, ByVal rowNum As Long) As String
    Dim panelPart As String
    Dim switchPart As String
    Dim sequenceNum As Long

    panelPart = UCase$(Trim$(panelText))
    If Len(panelPart) = 0 Then panelPart = "~NO-PANEL"

    switchText = Trim$(switchText)
    If IsNumeric(switchText) Then
        switchPart = "0" & Right$(String$(12, "0") & CStr(CLng(val(switchText))), 12)
    Else
        switchPart = "1" & UCase$(switchText)
    End If

    sequenceNum = PD6_DeviceSequenceNumberValues(sisSequence, sisElement, controlID)
    If sequenceNum <= 0 Then sequenceNum = 2147483647

    PD6_AllocationSortKeyValues = panelPart & "|" & switchPart & "|" & _
        Right$(String$(12, "0") & CStr(sequenceNum), 12) & "|" & _
        Right$(String$(10, "0") & CStr(rowNum), 10)
End Function

Private Function PD6_RowIdentityKeyValues(ByVal typeValue As String, ByVal sisSequence As String, _
                                           ByVal sisElement As String, ByVal areaValue As String, _
                                           ByVal switchValue As String) As String
    PD6_RowIdentityKeyValues = "|T=" & PD6_LookupKey(typeValue) & _
        "|S=" & PD6_LookupKey(sisSequence) & _
        "|E=" & PD6_LookupKey(sisElement) & _
        "|A=" & PD6_LookupKey(areaValue) & _
        "|G=" & PD6_LookupKey(switchValue)
End Function

Private Sub PD6_AppendNoteValueFast(ByRef currentValue As Variant, ByVal noteText As String)
    Dim oldText As String
    noteText = Trim$(noteText)
    If Len(noteText) = 0 Then Exit Sub

    If IsError(currentValue) Or IsNull(currentValue) Or IsEmpty(currentValue) Then
        oldText = vbNullString
    Else
        oldText = Trim$(CStr(currentValue))
    End If

    If Len(oldText) = 0 Then
        currentValue = noteText
    ElseIf InStr(1, oldText, noteText, vbTextCompare) = 0 Then
        currentValue = oldText & " | " & noteText
    End If
End Sub

Private Sub PD6_BuildModuleLengthPositionLookupsFast(ByRef panelData As Variant, ByRef switchData As Variant, _
                                                      ByRef lengthData As Variant, ByVal rowCount As Long, _
                                                      ByVal rowDistanceByRow As Object, _
                                                      ByVal rowDistanceCountByRow As Object)
    Dim runningFtBySwitch As Object
    Dim runningCountBySwitch As Object
    Dim idx As Long
    Dim switchKey As String
    Dim moduleFt As Double
    Dim runningFt As Double
    Dim runningCount As Long

    Set runningFtBySwitch = CreateObject("Scripting.Dictionary")
    Set runningCountBySwitch = CreateObject("Scripting.Dictionary")

    For idx = 1 To rowCount
        switchKey = PD6_PanelSwitchKey( _
            PD6_ArrayTextFast(panelData, idx), PD6_ArrayTextFast(switchData, idx))
        If Len(switchKey) > 0 Then
            If runningFtBySwitch.Exists(switchKey) Then
                runningFt = CDbl(runningFtBySwitch(switchKey))
                runningCount = CLng(runningCountBySwitch(switchKey))
            Else
                runningFt = 0#
                runningCount = 0&
            End If

            moduleFt = PD6_ModuleLengthFeet(PD6_ArrayValueFast(lengthData, idx))
            If moduleFt > 0# Then
                runningFt = runningFt + moduleFt
                runningCount = runningCount + 1&
            End If

            rowDistanceByRow(CStr(idx + 1&)) = runningFt
            rowDistanceCountByRow(CStr(idx + 1&)) = runningCount
            runningFtBySwitch(switchKey) = runningFt
            runningCountBySwitch(switchKey) = runningCount
        End If
    Next idx
End Sub

Private Sub PD6_ResetCoordinateRuntime()

    Set mPD6CoordinateByRow = CreateObject("Scripting.Dictionary")
    Set mPD6PSUCoordinateBySwitchPSU = CreateObject("Scripting.Dictionary")
    mPD6CoordinateByRow.CompareMode = vbTextCompare
    mPD6PSUCoordinateBySwitchPSU.CompareMode = vbTextCompare
    mPD6CoordinateDistanceUsedCount = 0&
    mPD6FallbackDistanceUsedCount = 0&

End Sub

Private Sub PD6_BuildRowCoordinateLookupFast( _
        ByRef xData As Variant, _
        ByRef yData As Variant, _
        ByRef zData As Variant, _
        ByVal rowCount As Long)

    Dim idx As Long
    Dim xVal As Double
    Dim yVal As Double
    Dim zVal As Double

    If mPD6CoordinateByRow Is Nothing Then PD6_ResetCoordinateRuntime

    For idx = 1 To rowCount
        If PD6_TryCoordinateDouble(PD6_ArrayValueFast(xData, idx), xVal) And _
           PD6_TryCoordinateDouble(PD6_ArrayValueFast(yData, idx), yVal) And _
           PD6_TryCoordinateDouble(PD6_ArrayValueFast(zData, idx), zVal) Then
            mPD6CoordinateByRow(CStr(idx + 1&)) = Array(xVal, yVal, zVal)
        End If
    Next idx

End Sub

Private Sub PD6_RegisterPSUCoordinate( _
        ByVal switchKey As String, _
        ByVal psuName As String, _
        ByVal psuRowNum As Long)

    Dim rowKey As String
    Dim psuKey As String

    If mPD6CoordinateByRow Is Nothing Then Exit Sub
    If mPD6PSUCoordinateBySwitchPSU Is Nothing Then Exit Sub

    rowKey = CStr(psuRowNum)
    If Not mPD6CoordinateByRow.Exists(rowKey) Then Exit Sub

    psuKey = PD6_PsuTotalKey(switchKey, psuName)
    If Len(psuKey) = 0 Then Exit Sub

    mPD6PSUCoordinateBySwitchPSU(psuKey) = mPD6CoordinateByRow(rowKey)

End Sub

Private Function PD6_RowHasCoordinate(ByVal rowNum As Long) As Boolean

    PD6_RowHasCoordinate = False
    If mPD6CoordinateByRow Is Nothing Then Exit Function
    PD6_RowHasCoordinate = mPD6CoordinateByRow.Exists(CStr(rowNum))

End Function

Private Sub PD6_ResolveCandidateDistance( _
        ByVal switchKey As String, _
        ByVal psuName As String, _
        ByVal deviceRowNum As Long, _
        ByVal fallbackModuleFt As Double, _
        ByVal fallbackLengthApplies As Boolean, _
        ByRef effectiveDistanceFt As Double, _
        ByRef effectiveLengthApplies As Boolean, _
        ByRef usedXYZ As Boolean)

    effectiveDistanceFt = fallbackModuleFt
    effectiveLengthApplies = fallbackLengthApplies
    usedXYZ = False

    If Not mPD6UseXYZDistance Then Exit Sub

    If PD6_TryCoordinateDistanceFeet(switchKey, psuName, deviceRowNum, effectiveDistanceFt) Then
        effectiveDistanceFt = effectiveDistanceFt * PD6_XYZ_ROUTE_FACTOR
        If effectiveDistanceFt < 0# Then effectiveDistanceFt = 0#
        effectiveLengthApplies = (effectiveDistanceFt > 0#)
        usedXYZ = True
    End If

End Sub

Private Function PD6_TryCoordinateDistanceFeet( _
        ByVal switchKey As String, _
        ByVal psuName As String, _
        ByVal deviceRowNum As Long, _
        ByRef distanceFt As Double) As Boolean

    Dim deviceCoord As Variant
    Dim psuCoord As Variant
    Dim psuKey As String
    Dim dx As Double
    Dim dy As Double
    Dim dz As Double
    Dim rawDistance As Double

    PD6_TryCoordinateDistanceFeet = False
    distanceFt = 0#

    If mPD6CoordinateByRow Is Nothing Then Exit Function
    If mPD6PSUCoordinateBySwitchPSU Is Nothing Then Exit Function
    If Not mPD6CoordinateByRow.Exists(CStr(deviceRowNum)) Then Exit Function

    psuKey = PD6_PsuTotalKey(switchKey, psuName)
    If Not mPD6PSUCoordinateBySwitchPSU.Exists(psuKey) Then Exit Function

    deviceCoord = mPD6CoordinateByRow(CStr(deviceRowNum))
    psuCoord = mPD6PSUCoordinateBySwitchPSU(psuKey)

    dx = CDbl(deviceCoord(0)) - CDbl(psuCoord(0))
    dy = CDbl(deviceCoord(1)) - CDbl(psuCoord(1))
    dz = CDbl(deviceCoord(2)) - CDbl(psuCoord(2))
    rawDistance = Sqr((dx * dx) + (dy * dy) + (dz * dz))

    distanceFt = PD6_CoordinateDistanceToFeet(rawDistance)
    PD6_TryCoordinateDistanceFeet = True

End Function

Private Function PD6_CoordinateDistanceToFeet(ByVal rawDistance As Double) As Double

    Select Case UCase$(Trim$(PD6_XYZ_UNIT))
        Case "FT", "FEET", "FOOT"
            PD6_CoordinateDistanceToFeet = rawDistance
        Case "IN", "INCH", "INCHES"
            PD6_CoordinateDistanceToFeet = rawDistance / 12#
        Case "CM"
            PD6_CoordinateDistanceToFeet = rawDistance / 30.48
        Case "M", "METER", "METERS", "METRE", "METRES"
            PD6_CoordinateDistanceToFeet = rawDistance * 3.28083989501312
        Case Else
            'Industrial default for the supplied ONGEN coordinate export: millimeters.
            PD6_CoordinateDistanceToFeet = rawDistance / 304.8
    End Select

End Function

Private Function PD6_TryCoordinateDouble(ByVal valueIn As Variant, ByRef valueOut As Double) As Boolean

    Dim textValue As String

    PD6_TryCoordinateDouble = False
    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function

    If IsNumeric(valueIn) Then
        valueOut = CDbl(valueIn)
        PD6_TryCoordinateDouble = True
        Exit Function
    End If

    textValue = Replace(Trim$(CStr(valueIn)), ",", vbNullString)
    If IsNumeric(textValue) Then
        valueOut = CDbl(textValue)
        PD6_TryCoordinateDouble = True
    End If

End Function

Private Function PD6_CoordinateCandidateSelectionScore( _
        ByVal psuName As String, _
        ByVal deviceSeqNum As Long, _
        ByVal currentTotalLoad As Double, _
        ByVal state As Object, _
        ByVal distanceFt As Double, _
        ByVal usesXYZ As Boolean) As Double

    Dim score As Double

    If usesXYZ Then
        score = distanceFt * PD6_XYZ_SCORE_WEIGHT
        score = score + CDbl(PD6_SequenceGapForPSU(psuName, deviceSeqNum))
        score = score + (currentTotalLoad * 10#)
        If Not state Is Nothing Then
            score = score + CDbl(CLng(state("TERM_IDX"))) * 10#
            score = score + CDbl(CLng(state("TERM_COUNT")))
            If CLng(state("PSU_COUNT")) > 0 Then score = score - 100#
        End If
    Else
        score = PD6_XYZ_MISSING_CANDIDATE_PENALTY + _
                PD6_PSUAllocationScore(psuName, deviceSeqNum, currentTotalLoad, state)
    End If

    PD6_CoordinateCandidateSelectionScore = score

End Function

Private Function PD6_PairCoordinateSelectionScore( _
        ByVal psuBus1 As String, _
        ByVal psuBus2 As String, _
        ByVal deviceSeqNum As Long, _
        ByVal distanceBus1 As Double, _
        ByVal distanceBus2 As Double, _
        ByVal usesXYZBus1 As Boolean, _
        ByVal usesXYZBus2 As Boolean) As Double

    Dim score As Double

    If usesXYZBus1 Then
        score = score + (distanceBus1 * PD6_XYZ_SCORE_WEIGHT)
    Else
        score = score + PD6_XYZ_MISSING_CANDIDATE_PENALTY + _
                CDbl(PD6_SequenceGapForPSU(psuBus1, deviceSeqNum)) * 1000#
    End If

    If usesXYZBus2 Then
        score = score + (distanceBus2 * PD6_XYZ_SCORE_WEIGHT)
    Else
        score = score + PD6_XYZ_MISSING_CANDIDATE_PENALTY + _
                CDbl(PD6_SequenceGapForPSU(psuBus2, deviceSeqNum)) * 1000#
    End If

    If usesXYZBus1 And usesXYZBus2 Then
        score = score + Abs(distanceBus1 - distanceBus2) * 1000#
    End If

    PD6_PairCoordinateSelectionScore = score

End Function

Private Function PD6_RowIsPSU( _
        ByVal ws As Worksheet, _
        ByVal rowNum As Long, _
        ByVal cType As Long, _
        ByVal cSisElem As Long, _
        ByVal cControl As Long, _
        ByVal cSisSeq As Long) As Boolean

    Dim typeText As String
    Dim v As String

    PD6_RowIsPSU = False
    If ws Is Nothing Then Exit Function

    If cType > 0 Then
        typeText = Trim$(CStr(ws.Cells(rowNum, cType).value))
        If PD6_IsPSUType(typeText) Then
            PD6_RowIsPSU = True
            Exit Function
        End If
    End If

    If cSisElem > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cSisElem).value))
        If PD6_TextLooksLikePSUName(v) Then
            PD6_RowIsPSU = True
            Exit Function
        End If
    End If

    If cControl > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cControl).value))
        If PD6_TextLooksLikePSUName(v) Then
            PD6_RowIsPSU = True
            Exit Function
        End If
    End If

    If cSisSeq > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cSisSeq).value))
        If PD6_TextLooksLikePSUName(v) Then
            PD6_RowIsPSU = True
            Exit Function
        End If
    End If

End Function

Private Function PD6_PSUNameFromRow( _
        ByVal ws As Worksheet, _
        ByVal rowNum As Long, _
        ByVal cSisElem As Long, _
        ByVal cControl As Long, _
        ByVal cSisSeq As Long, _
        ByVal cType As Long) As String

    Dim v As String

    PD6_PSUNameFromRow = ""
    If ws Is Nothing Then Exit Function

    If cControl > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cControl).value))
        If PD6_TextLooksLikePSUInstanceName(v) Then
            PD6_PSUNameFromRow = v
            Exit Function
        End If
    End If

    If cSisElem > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cSisElem).value))
        If PD6_TextLooksLikePSUInstanceName(v) Then
            PD6_PSUNameFromRow = v
            Exit Function
        End If
    End If

    If cSisSeq > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cSisSeq).value))
        If PD6_TextLooksLikePSUInstanceName(v) Then
            PD6_PSUNameFromRow = v
            Exit Function
        End If
    End If

    If cControl > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cControl).value))
        If PD6_TextLooksLikePSUName(v) Then
            PD6_PSUNameFromRow = v
            Exit Function
        End If
    End If

    If cSisElem > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cSisElem).value))
        If PD6_TextLooksLikePSUName(v) Then
            PD6_PSUNameFromRow = v
            Exit Function
        End If
    End If

    If cSisSeq > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cSisSeq).value))
        If PD6_TextLooksLikePSUName(v) Then
            PD6_PSUNameFromRow = v
            Exit Function
        End If
    End If

    PD6_PSUNameFromRow = PD6_FirstNonBlankCell(ws, rowNum, cSisElem, cControl, cSisSeq)
    If Len(PD6_PSUNameFromRow) = 0 And cType > 0 Then
        v = Trim$(CStr(ws.Cells(rowNum, cType).value))
        If PD6_IsPSUType(v) Then PD6_PSUNameFromRow = v
    End If
End Function

Private Function PD6_TextLooksLikePSUInstanceName(ByVal txt As String) As Boolean

    Dim compactText As String
    Dim p As Long
    Dim suffixText As String

    compactText = UCase$(Trim$(txt))
    compactText = Replace(compactText, " ", "")
    compactText = Replace(compactText, "_", "-")

    PD6_TextLooksLikePSUInstanceName = False
    If Len(compactText) = 0 Then Exit Function

    p = InStr(1, compactText, "-PSU-", vbTextCompare)
    If p > 0 Then
        suffixText = mid$(compactText, p + Len("-PSU-"))
        PD6_TextLooksLikePSUInstanceName = (Len(suffixText) > 0)
        Exit Function
    End If

    If Left$(compactText, 4) = "PSU-" And Len(compactText) > 4 Then
        PD6_TextLooksLikePSUInstanceName = True
    End If

End Function

Private Function PD6_TextLooksLikePSUName(ByVal txt As String) As Boolean

    Dim u As String
    Dim compactText As String

    u = UCase$(Trim$(txt))
    compactText = u
    compactText = Replace(compactText, " ", "")
    compactText = Replace(compactText, "_", "-")

    PD6_TextLooksLikePSUName = False
    If Len(compactText) = 0 Then Exit Function

    If InStr(1, compactText, "-PSU", vbTextCompare) > 0 Then
        PD6_TextLooksLikePSUName = True
    ElseIf Left$(compactText, 4) = "PSU-" Then
        PD6_TextLooksLikePSUName = True
    ElseIf Right$(compactText, 3) = "PSU" Then
        PD6_TextLooksLikePSUName = True
    End If

End Function

Private Function PD6_IsPSUType(ByVal typeVal As String) As Boolean

    Dim t As String
    Dim compactText As String

    t = UCase$(Trim$(typeVal))
    compactText = t
    compactText = Replace(compactText, " ", "")
    compactText = Replace(compactText, "-", "")
    compactText = Replace(compactText, "_", "")
    compactText = Replace(compactText, "/", "")

    PD6_IsPSUType = (t = "PSU" Or _
        InStr(1, compactText, "PSU", vbTextCompare) > 0 Or _
        InStr(1, compactText, "POWERSUPPLY", vbTextCompare) > 0)

End Function

Private Sub PD6_ValidatePSUTerminalTemplate()

    Dim template As Object
    Set template = PD6_GetPSUTerminalTemplate()

    If template Is Nothing Then
        Err.Raise vbObjectError + 593, "PD6_ValidatePSUTerminalTemplate", _
                  "The PSU terminal template could not be loaded from worksheet '480v_DATA_POWER'."
    End If

End Sub

Private Function PD6_GetPSUTerminalTemplate() As Object

    Dim ws As Worksheet
    Dim template As Object
    Dim headerRow As Long
    Dim cDwg As Long
    Dim cTerm As Long
    Dim cDesc As Long
    Dim lastRow As Long
    Dim lastCol As Long
    Dim scanLastRow As Long
    Dim r As Long
    Dim c As Long
    Dim keyText As String
    Dim currentDwg As String
    Dim rowDwg As String
    Dim termText As String
    Dim descText As String
    Dim termCount As Long

    If Not mPD6PSUTerminalTemplate Is Nothing Then
        Set PD6_GetPSUTerminalTemplate = mPD6PSUTerminalTemplate
        Exit Function
    End If

    Set ws = PD6_Find480VDataPowerSheet()
    If ws Is Nothing Then
        Err.Raise vbObjectError + 594, "PD6_GetPSUTerminalTemplate", _
                  "Worksheet '480v_DATA_POWER' was not found in this workbook."
    End If

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then
        Err.Raise vbObjectError + 595, "PD6_GetPSUTerminalTemplate", _
                  "Worksheet '480v_DATA_POWER' does not contain PSU terminal data."
    End If

    lastCol = ws.UsedRange.Column + ws.UsedRange.Columns.count - 1
    scanLastRow = lastRow
    If scanLastRow > 100 Then scanLastRow = 100

    For r = 1 To scanLastRow
        cDwg = 0
        cTerm = 0
        cDesc = 0

        For c = 1 To lastCol
            keyText = PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c).value))
            Select Case keyText
                Case "PSUDWG", "PSUDRAWING", "PSUBLOCK"
                    cDwg = c
                Case "PSUTERM", "PSUTERMINAL", "POWERPSUTERMINAL"
                    cTerm = c
                Case "PSUDESC", "DESCPSU", "PSUDESCRIPTION"
                    cDesc = c
            End Select
        Next c

        If cDwg > 0 And cTerm > 0 And cDesc > 0 Then
            headerRow = r
            Exit For
        End If
    Next r

    If headerRow = 0 Then
        Err.Raise vbObjectError + 596, "PD6_GetPSUTerminalTemplate", _
                  "Headers 'PSU DWG', 'PSU TERM', and 'DESCPSU' were not found on the same row of worksheet '480v_DATA_POWER'."
    End If

    Set template = CreateObject("Scripting.Dictionary")
    template.CompareMode = vbTextCompare

    currentDwg = vbNullString
    termCount = 0

    For r = headerRow + 1 To lastRow
        rowDwg = Trim$(CStr(ws.Cells(r, cDwg).value))
        If Len(rowDwg) > 0 Then currentDwg = rowDwg

        termText = Trim$(CStr(ws.Cells(r, cTerm).value))
        descText = Trim$(CStr(ws.Cells(r, cDesc).value))

        If Len(termText) > 0 Or Len(descText) > 0 Then
            If Len(currentDwg) = 0 Then
                Err.Raise vbObjectError + 597, "PD6_GetPSUTerminalTemplate", _
                          "The first PSU TERM row must have a PSU DWG value in worksheet '480v_DATA_POWER'."
            End If

            If Len(termText) = 0 Or Len(descText) = 0 Then
                Err.Raise vbObjectError + 598, "PD6_GetPSUTerminalTemplate", _
                          "Every PSU terminal row must contain both PSU TERM and PSUDESC. Check row " & CStr(r) & _
                          " of worksheet '480v_DATA_POWER'."
            End If

            termCount = termCount + 1
            template("DWG" & CStr(termCount)) = currentDwg
            template("TERM" & CStr(termCount)) = termText
            template("PSUDESC" & CStr(termCount)) = descText
            If termCount = 1 Then template("DWG") = currentDwg

            If termCount = MAX_TERMINALS_PER_BUS Then Exit For
        End If
    Next r

    If termCount <> MAX_TERMINALS_PER_BUS Then
        Err.Raise vbObjectError + 599, "PD6_GetPSUTerminalTemplate", _
                  "Exactly " & CStr(MAX_TERMINALS_PER_BUS) & _
                  " usable PSU TERM/PSUDESC rows are required under the PSU headers in worksheet '480v_DATA_POWER'. Found " & _
                  CStr(termCount) & "."
    End If

    Set mPD6PSUTerminalTemplate = template
    Set PD6_GetPSUTerminalTemplate = mPD6PSUTerminalTemplate

End Function

Public Sub Step05_Validate_PD6_PSU_Terminal_Table()

    Dim template As Object
    Dim i As Long
    Dim reportText As String
    Dim errNumber As Long
    Dim errDescription As String

    On Error GoTo ErrHandler
    Set mPD6PSUTerminalTemplate = Nothing
    Set template = PD6_GetPSUTerminalTemplate()

    reportText = "PSU terminal table validation passed." & vbCrLf & vbCrLf
    For i = 1 To MAX_TERMINALS_PER_BUS
        reportText = reportText & CStr(i) & ". " & _
                     CStr(template("TERM" & CStr(i))) & "  -  " & _
                     CStr(template("PSUDESC" & CStr(i))) & vbCrLf
    Next i

    MsgBox reportText, vbInformation, "480v_DATA_POWER PSU Terminal Table"
    Exit Sub

ErrHandler:
    errNumber = Err.Number
    errDescription = Err.description
    If Len(Trim$(errDescription)) = 0 Then errDescription = "Unspecified VBA runtime error."
    MsgBox "PSU terminal table validation failed." & vbCrLf & _
           "Error " & CStr(errNumber) & ": " & errDescription, _
           vbCritical, "480v_DATA_POWER PSU Terminal Table"

End Sub

Private Function PD6_Find480VDataPowerSheet() As Worksheet

    Dim ws As Worksheet
    Dim keyText As String

    For Each ws In ThisWorkbook.Worksheets
        keyText = PD6_NormalizeHeaderKey(ws.Name)
        If keyText = "480VDATAPOWER" Then
            Set PD6_Find480VDataPowerSheet = ws
            Exit Function
        End If
    Next ws

End Function

Private Function PD6_TerminalName(ByVal terminalIndex As Long) As String

    Dim template As Object

    If terminalIndex < 1 Or terminalIndex > MAX_TERMINALS_PER_BUS Then
        Err.Raise vbObjectError + 600, "PD6_TerminalName", _
                  "PSU terminal index " & CStr(terminalIndex) & " is outside the supported range 1-" & _
                  CStr(MAX_TERMINALS_PER_BUS) & "."
    End If

    Set template = PD6_GetPSUTerminalTemplate()
    PD6_TerminalName = Trim$(CStr(template("TERM" & CStr(terminalIndex))))

End Function

Private Function PD6_TerminalDescription(ByVal terminalIndex As Long) As String

    Dim template As Object

    If terminalIndex < 1 Or terminalIndex > MAX_TERMINALS_PER_BUS Then Exit Function

    Set template = PD6_GetPSUTerminalTemplate()
    PD6_TerminalDescription = Trim$(CStr(template("PSUDESC" & CStr(terminalIndex))))

End Function

Private Function PD6_PromptUseXYZDistance(ByVal workflowName As String) As Boolean

    Dim response As VbMsgBoxResult

    response = MsgBox( _
        "Select the PSU BUS distance method for " & workflowName & "." & vbCrLf & vbCrLf & _
        "YES  = Use X/Y/Z 3D distance where both the device and PSU have coordinates." & vbCrLf & _
        "       Rows with incomplete coordinates automatically fall back to Module Length." & vbCrLf & vbCrLf & _
        "NO   = Use the current Module Length setup for every assignment (default).", _
        vbYesNo + vbQuestion + vbDefaultButton2, _
        "ONGEN PSU Distance Method")

    PD6_PromptUseXYZDistance = (response = vbYes)

End Function

Private Function PD6_DistanceModeLabel(ByVal useXYZDistance As Boolean) As String

    If useXYZDistance Then
        PD6_DistanceModeLabel = "X/Y/Z where available; Module Length fallback"
    Else
        PD6_DistanceModeLabel = "Module Length (default)"
    End If

End Function

Private Function PD6_PanelSwitchKey(ByVal panelVal As String, ByVal switchVal As String) As String
    panelVal = PD6_NormalizePanelMatchKey(panelVal)
    switchVal = PD6_SwitchKey(switchVal)
    If Len(panelVal) = 0 Or Len(switchVal) = 0 Then Exit Function
    PD6_PanelSwitchKey = "PNL=" & panelVal & "|SWG=" & switchVal
End Function

Private Function PD6_PanelSwitchDisplay(ByVal panelVal As String, ByVal switchVal As String) As String
    panelVal = Trim$(panelVal)
    switchVal = Trim$(switchVal)

    If Len(panelVal) = 0 Then panelVal = "(blank)"
    If Len(switchVal) = 0 Then switchVal = "(blank)"

    PD6_PanelSwitchDisplay = "Panel " & panelVal & ", SwitchGroup " & switchVal
End Function

Private Function PD6_SwitchKey(ByVal switchVal As String) As String
    Dim s As String
    s = PD6_NormalizeAlphaNumericKey(switchVal)
    If Left$(s, 11) = "SWITCHGROUP" Then
        s = mid$(s, 12)
    ElseIf Left$(s, 3) = "SWG" Or Left$(s, 3) = "PWG" Then
        s = mid$(s, 4)
    End If
    PD6_SwitchKey = s
End Function

Private Function PD6_NormalizePanelMatchKey(ByVal panelVal As String) As String
    Dim s As String
    s = PD6_NormalizeAlphaNumericKey(panelVal)
    If Left$(s, 5) = "PANEL" Then
        s = mid$(s, 6)
    ElseIf Left$(s, 3) = "PNL" Then
        s = mid$(s, 4)
    End If
    PD6_NormalizePanelMatchKey = s
End Function

Private Function PD6_NormalizeAlphaNumericKey(ByVal valueText As String) As String
    Dim s As String, i As Long, ch As String, resultText As String
    s = UCase$(Trim$(Replace$(valueText, Chr$(160), " ")))
    If Len(s) = 0 Then Exit Function

    If IsNumeric(s) Then
        PD6_NormalizeAlphaNumericKey = Format$(CDbl(s), "0.############")
        Exit Function
    End If

    For i = 1 To Len(s)
        ch = mid$(s, i, 1)
        If (ch >= "A" And ch <= "Z") Or (ch >= "0" And ch <= "9") Then
            resultText = resultText & ch
        End If
    Next i
    PD6_NormalizeAlphaNumericKey = resultText
End Function

Private Function PD6_FirstNonBlankCell(ByVal ws As Worksheet, ByVal rowNum As Long, ParamArray cols() As Variant) As String

    Dim i As Long
    Dim c As Long
    Dim v As String

    For i = LBound(cols) To UBound(cols)
        c = CLng(cols(i))
        If c > 0 Then
            v = Trim$(CStr(ws.Cells(rowNum, c).value))
            If Len(v) > 0 Then
                PD6_FirstNonBlankCell = v
                Exit Function
            End If
        End If
    Next i

    PD6_FirstNonBlankCell = ""

End Function

Private Sub PD6_AppendNote(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal notesCol As Long, ByVal noteText As String)

    Dim oldText As String

    If notesCol <= 0 Then Exit Sub
    If Len(noteText) = 0 Then Exit Sub

    oldText = Trim$(CStr(ws.Cells(rowNum, notesCol).value))
    If Len(oldText) = 0 Then
        ws.Cells(rowNum, notesCol).value = noteText
    ElseIf InStr(1, oldText, noteText, vbTextCompare) = 0 Then
        ws.Cells(rowNum, notesCol).value = oldText & " | " & noteText
    End If

End Sub

Private Function PD6_CellDouble(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal colNum As Long) As Double

    Dim v As Variant
    Dim s As String

    PD6_CellDouble = 0#
    If colNum <= 0 Then Exit Function

    v = ws.Cells(rowNum, colNum).value
    If IsNumeric(v) Then
        PD6_CellDouble = CDbl(v)
    Else
        s = UCase$(Trim$(CStr(v)))
        s = Replace(s, "FT", "")
        s = Replace(s, "FEET", "")
        s = Replace(s, "MM", "")
        s = Replace(s, "IN", "")
        s = Replace(s, "A", "")
        s = Replace(s, "KW", "")
        s = Replace(s, "W", "")
        s = Replace(s, "V", "")
        s = Replace(s, ",", "")
        If IsNumeric(s) Then PD6_CellDouble = CDbl(s)
    End If

End Function

Private Function PD6_ModuleLengthFeet(ByVal valueIn As Variant) As Double

    Dim rawVal As Double
    Dim txt As String

    rawVal = 0#
    If IsNumeric(valueIn) Then
        rawVal = CDbl(valueIn)
    Else
        txt = UCase$(Trim$(CStr(valueIn)))
        txt = Replace(txt, "FEET", "")
        txt = Replace(txt, "FOOT", "")
        txt = Replace(txt, "FT", "")
        txt = Replace(txt, "'", "")
        txt = Replace(txt, "MM", "")
        txt = Replace(txt, "INCHES", "")
        txt = Replace(txt, "IN", "")
        txt = Replace(txt, Chr$(34), "")
        txt = Replace(txt, ",", "")
        If IsNumeric(txt) Then rawVal = CDbl(txt)
    End If

    If rawVal <= 0 Then
        PD6_ModuleLengthFeet = 0#
    ElseIf rawVal > 500# Then
        PD6_ModuleLengthFeet = rawVal / 304.8
    ElseIf rawVal > 60# Then
        PD6_ModuleLengthFeet = rawVal / 12#
    Else
        PD6_ModuleLengthFeet = rawVal
    End If

End Function

Private Function PD6_HeaderCol(ByVal ws As Worksheet, ParamArray aliases() As Variant) As Long

    Dim headerMap As Object
    Dim i As Long
    Dim aliasKey As String

    PD6_HeaderCol = 0
    Set headerMap = PD6_GetHeaderMap(ws)
    If headerMap Is Nothing Then Exit Function

    For i = LBound(aliases) To UBound(aliases)
        aliasKey = PD6_NormalizeHeaderKey(CStr(aliases(i)))
        If Len(aliasKey) > 0 Then
            If headerMap.Exists(aliasKey) Then
                PD6_HeaderCol = CLng(headerMap(aliasKey))
                Exit Function
            End If
        End If
    Next i

End Function

Private Function PD6_GetHeaderMap(ByVal ws As Worksheet) As Object

    Dim sheetKey As String
    Dim lastCol As Long
    Dim c As Long
    Dim keyText As String
    Dim headerValues As Variant
    Dim headerMap As Object

    If ws Is Nothing Then Exit Function

    If mPD6HeaderCache Is Nothing Then Set mPD6HeaderCache = CreateObject("Scripting.Dictionary")

    sheetKey = CStr(ObjPtr(ws))
    If mPD6HeaderCache.Exists(sheetKey) Then
        Set PD6_GetHeaderMap = mPD6HeaderCache(sheetKey)
        Exit Function
    End If

    Set headerMap = CreateObject("Scripting.Dictionary")
    headerMap.CompareMode = vbTextCompare

    lastCol = LastUsedCol(ws, 1)
    If lastCol > 0 Then
        headerValues = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)).Value2
        For c = 1 To lastCol
            keyText = PD6_NormalizeHeaderKey(CStr(headerValues(1, c)))
            If Len(keyText) > 0 Then
                If Not headerMap.Exists(keyText) Then headerMap.Add keyText, c
            End If
        Next c
    End If

    mPD6HeaderCache.Add sheetKey, headerMap
    Set PD6_GetHeaderMap = headerMap

End Function

Private Sub PD6_ResetHeaderCache()

    Set mPD6HeaderCache = Nothing
    Set mPD6LastColCache = Nothing

End Sub

Private Sub PD6_ResetSpeedCaches(Optional ByVal clearDataPowerCache As Boolean = False)

    PD6_ResetHeaderCache
    If clearDataPowerCache Then
        Set mPD6DataPowerLoadCache = Nothing
        Set mPD6DataPowerBusCache = Nothing
    End If

    Set mPD6ControlKRuleCache = Nothing
    Set mPD6ControlKAllocationCache = Nothing
    Set mPD6ControlKWarningCache = Nothing
    Set mPD6PSUTerminalTemplate = Nothing

End Sub

Private Function PD6_NormalizeHeaderKey(ByVal headerText As String) As String

    Dim s As String
    Dim i As Long
    Dim ch As String
    Dim outText As String

    s = UCase$(Trim$(CStr(headerText)))
    outText = ""

    For i = 1 To Len(s)
        ch = mid$(s, i, 1)
        If (ch >= "A" And ch <= "Z") Or (ch >= "0" And ch <= "9") Then
            outText = outText & ch
        End If
    Next i

    PD6_NormalizeHeaderKey = outText

End Function

Private Function PD6_RowHasData(ByVal ws As Worksheet, ByVal rowNum As Long) As Boolean

    Dim lastCol As Long
    Dim sheetKey As String

    If ws Is Nothing Then Exit Function

    If mPD6LastColCache Is Nothing Then Set mPD6LastColCache = CreateObject("Scripting.Dictionary")

    sheetKey = CStr(ObjPtr(ws))
    If mPD6LastColCache.Exists(sheetKey) Then
        lastCol = CLng(mPD6LastColCache(sheetKey))
    Else
        lastCol = LastUsedCol(ws, 1)
        If lastCol < 1 Then lastCol = 1
        mPD6LastColCache.Add sheetKey, lastCol
    End If

    PD6_RowHasData = (Application.WorksheetFunction.CountA(ws.Range(ws.Cells(rowNum, 1), ws.Cells(rowNum, lastCol))) > 0)

End Function

Private Function PD6_Pick(ByVal ws As Worksheet, ByVal rowNum As Long, ParamArray aliases() As Variant) As String

    Dim i As Long
    Dim c As Long
    Dim v As String

    PD6_Pick = ""

    For i = LBound(aliases) To UBound(aliases)
        c = PD6_HeaderCol(ws, CStr(aliases(i)))
        If c > 0 Then
            v = Trim$(CStr(ws.Cells(rowNum, c).value))
            If Len(v) > 0 Then
                PD6_Pick = v
                Exit Function
            End If
        End If
    Next i

End Function

Private Function PD6_Number(ByVal ws As Worksheet, ByVal rowNum As Long, ParamArray aliases() As Variant) As Double

    Dim txt As String
    Dim i As Long
    Dim c As Long
    Dim v As Variant

    PD6_Number = 0

    For i = LBound(aliases) To UBound(aliases)
        c = PD6_HeaderCol(ws, CStr(aliases(i)))
        If c > 0 Then
            v = ws.Cells(rowNum, c).value
            If IsNumeric(v) Then
                PD6_Number = CDbl(v)
                Exit Function
            Else
                txt = Trim$(CStr(v))
                txt = Replace(txt, "KW", "", 1, -1, vbTextCompare)
                txt = Replace(txt, "A", "", 1, -1, vbTextCompare)
                txt = Replace(txt, "V", "", 1, -1, vbTextCompare)
                txt = Replace(txt, "W", "", 1, -1, vbTextCompare)
                txt = Replace(txt, ",", "")
                If IsNumeric(txt) Then
                    PD6_Number = CDbl(txt)
                    Exit Function
                End If
            End If
        End If
    Next i

End Function

Private Function PD6_CalculateLoadBUS1(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal conveyorTypeVal As String, ByVal sysType As String, ByVal motorVoltText As String) As Variant

    Dim dataLoad As String

    dataLoad = PD6_GetConveyorTypeLoad(conveyorTypeVal)
    If Len(dataLoad) > 0 Then
        PD6_CalculateLoadBUS1 = dataLoad
    Else
        PD6_CalculateLoadBUS1 = PD6_CalculateLoad(ws, rowNum, sysType, motorVoltText)
    End If

End Function

Private Function PD6_CalculateLoadBUS2(ByVal typeVal As String) As Variant

    Dim t As String
    t = UCase$(Trim$(typeVal))
    t = Replace(t, " ", "")
    t = Replace(t, "_", "/")

    If t = "SCN" Or Left$(t, 3) = "SCN" Or t = "SCANNER" Or Left$(t, 7) = "SCANNER" Then
        PD6_CalculateLoadBUS2 = ""
    ElseIf t = "PC2" Or Left$(t, 3) = "PC2" Then
        PD6_CalculateLoadBUS2 = 4#
    ElseIf t = "VFD" Or Left$(t, 3) = "VFD" Then
        PD6_CalculateLoadBUS2 = 3.5
    ElseIf PD6_TypeNeedsBus1(t) Or PD6_IsIOType(t) Then
        PD6_CalculateLoadBUS2 = 1.6
    Else
        PD6_CalculateLoadBUS2 = ""
    End If

End Function

Private Function PD6_GetConveyorTypeLoad(ByVal conveyorTypeVal As String) As String

    Dim keyText As String
    Dim loadMap As Object

    PD6_GetConveyorTypeLoad = ""
    keyText = PD6_LookupKey(conveyorTypeVal)
    If Len(keyText) = 0 Then Exit Function

    Set loadMap = PD6_GetConveyorTypeLoadMap()
    If loadMap Is Nothing Then Exit Function

    If loadMap.Exists(keyText) Then
        PD6_GetConveyorTypeLoad = CStr(loadMap(keyText))
    End If

End Function

Private Function PD6_GetConveyorTypeLoadMap() As Object

    Dim ws As Worksheet
    Dim cConv As Long
    Dim cLoad As Long
    Dim lastRow As Long
    Dim r As Long
    Dim keyText As String
    Dim loadVal As String

    If Not mPD6DataPowerLoadCache Is Nothing Then
        Set PD6_GetConveyorTypeLoadMap = mPD6DataPowerLoadCache
        Exit Function
    End If

    Set mPD6DataPowerLoadCache = CreateObject("Scripting.Dictionary")
    mPD6DataPowerLoadCache.CompareMode = vbTextCompare

    Set ws = GetSheetIfExists(SH_DATA_PWR)
    If ws Is Nothing Then
        Set PD6_GetConveyorTypeLoadMap = mPD6DataPowerLoadCache
        Exit Function
    End If

    cConv = PD6_HeaderCol(ws, "Conveyor Type", "CONVEYOR TYPE")
    cLoad = PD6_HeaderCol(ws, "Load", "LOAD", "CURRENT_LOAD")
    If cConv = 0 Or cLoad = 0 Then
        Set PD6_GetConveyorTypeLoadMap = mPD6DataPowerLoadCache
        Exit Function
    End If

    lastRow = LastUsedRow(ws)
    For r = 2 To lastRow
        keyText = PD6_LookupKey(ws.Cells(r, cConv).value)
        loadVal = Trim$(CStr(ws.Cells(r, cLoad).value))
        If Len(keyText) > 0 And Len(loadVal) > 0 Then
            If Not mPD6DataPowerLoadCache.Exists(keyText) Then
                mPD6DataPowerLoadCache.Add keyText, loadVal
            End If
        End If
    Next r

    Set PD6_GetConveyorTypeLoadMap = mPD6DataPowerLoadCache

End Function

Private Sub PD6_ResolveLoadBusValues(ByVal typeVal As String, ByVal loadValue As Variant, ByRef bus1Value As Variant, ByRef bus2Value As Variant)

    Dim dataBus1 As Variant
    Dim dataBus2 As Variant
    Dim needsBus1 As Boolean
    Dim needsBus2 As Boolean

    bus1Value = ""
    bus2Value = ""

    If Not PD6_GetDataPowerBusRuleValues(typeVal, dataBus1, dataBus2, needsBus1, needsBus2) Then Exit Sub

    If needsBus1 Then
        If Len(Trim$(CStr(dataBus1))) > 0 And IsNumeric(dataBus1) Then
            bus1Value = CDbl(dataBus1)
        Else
            bus1Value = loadValue
        End If
    End If

    If needsBus2 Then
        If Len(Trim$(CStr(dataBus2))) > 0 And IsNumeric(dataBus2) Then
            bus2Value = CDbl(dataBus2)
        Else
            bus2Value = loadValue
        End If
    End If

End Sub

Private Function PD6_GetDataPowerBusValues(ByVal typeVal As String, ByRef bus1Value As Variant, ByRef bus2Value As Variant) As Boolean

    Dim needsBus1 As Boolean
    Dim needsBus2 As Boolean

    PD6_GetDataPowerBusValues = PD6_GetDataPowerBusRuleValues(typeVal, bus1Value, bus2Value, needsBus1, needsBus2)

End Function

Private Function PD6_GetDataPowerBusRuleValues( _
        ByVal typeVal As String, _
        ByRef bus1Value As Variant, _
        ByRef bus2Value As Variant, _
        ByRef needsBus1 As Boolean, _
        ByRef needsBus2 As Boolean) As Boolean

    Dim busMap As Object
    Dim keyText As String
    Dim compactKey As String
    Dim entry As Variant

    bus1Value = ""
    bus2Value = ""
    needsBus1 = False
    needsBus2 = False
    PD6_GetDataPowerBusRuleValues = False

    keyText = PD6_LookupKey(typeVal)
    compactKey = PD6_NormalizeHeaderKey(typeVal)
    If Len(keyText) = 0 And Len(compactKey) = 0 Then Exit Function

    Set busMap = PD6_GetDataPowerBusMap()
    If busMap Is Nothing Then Exit Function

    If Len(keyText) > 0 And busMap.Exists(keyText) Then
        entry = busMap(keyText)
    ElseIf Len(compactKey) > 0 And busMap.Exists(compactKey) Then
        entry = busMap(compactKey)
    Else
        Exit Function
    End If

    If IsArray(entry) Then
        bus1Value = entry(0)
        bus2Value = entry(1)
        needsBus1 = CBool(entry(2))
        needsBus2 = CBool(entry(3))
        PD6_GetDataPowerBusRuleValues = True
    End If

End Function

Private Function PD6_GetDataPowerBusMap() As Object

    Dim ws As Worksheet
    Dim cType As Long
    Dim cDeviceType As Long
    Dim cBus1 As Long
    Dim cBus2 As Long
    Dim c24Bus1 As Long
    Dim c24Bus2 As Long
    Dim headerRow As Long
    Dim lastRow As Long
    Dim r As Long
    Dim typeText As String
    Dim aliasText As String
    Dim bus1Value As Variant
    Dim bus2Value As Variant
    Dim needsBus1 As Boolean
    Dim needsBus2 As Boolean

    If Not mPD6DataPowerBusCache Is Nothing Then
        Set PD6_GetDataPowerBusMap = mPD6DataPowerBusCache
        Exit Function
    End If

    Set mPD6DataPowerBusCache = CreateObject("Scripting.Dictionary")
    mPD6DataPowerBusCache.CompareMode = vbTextCompare

    Set ws = GetSheetIfExists(SH_DATA_PWR)
    If ws Is Nothing Then
        Set PD6_GetDataPowerBusMap = mPD6DataPowerBusCache
        Exit Function
    End If

    If Not PD6_FindDataPowerBusHeaderBlock(ws, headerRow, cType, cDeviceType, cBus1, cBus2, c24Bus1, c24Bus2) Then
        Err.Raise vbObjectError + 526, , _
                  "DATA_POWER is missing the required contiguous 24V rule headers: " & _
                  "Type | DESC | DEVICE TYPE | Bus-1 | Bus-2 | 24- BUS-1 | 24V- BUS-2."
    End If

    PD6_EnsureAE24VRule ws, headerRow, cType, cDeviceType, cBus1, cBus2, c24Bus1, c24Bus2

    lastRow = ws.Cells(ws.rows.count, cType).End(xlUp).Row
    For r = headerRow + 1 To lastRow
        typeText = Trim$(CStr(ws.Cells(r, cType).value))
        aliasText = Trim$(CStr(ws.Cells(r, cDeviceType).value))

        If Len(typeText) > 0 Then
            bus1Value = PD6_DataPowerBusCellValue(ws, r, cBus1)
            bus2Value = PD6_DataPowerBusCellValue(ws, r, cBus2)
            needsBus1 = PD6_DataPowerFlagIsEnabled(ws.Cells(r, c24Bus1).value)
            needsBus2 = PD6_DataPowerFlagIsEnabled(ws.Cells(r, c24Bus2).value)

            PD6_AddDataPowerBusRuleKeys mPD6DataPowerBusCache, typeText, bus1Value, bus2Value, needsBus1, needsBus2
            If Len(aliasText) > 0 Then
                PD6_AddDataPowerBusAliasList mPD6DataPowerBusCache, aliasText, bus1Value, bus2Value, needsBus1, needsBus2
            End If
        End If
    Next r

    Set PD6_GetDataPowerBusMap = mPD6DataPowerBusCache

End Function

Private Function PD6_FindDataPowerBusHeaderBlock( _
        ByVal ws As Worksheet, _
        ByRef headerRow As Long, _
        ByRef cType As Long, _
        ByRef cDeviceType As Long, _
        ByRef cBus1 As Long, _
        ByRef cBus2 As Long, _
        ByRef c24Bus1 As Long, _
        ByRef c24Bus2 As Long) As Boolean

    Dim lastCol As Long
    Dim lastHeaderRow As Long
    Dim r As Long
    Dim c As Long

    PD6_FindDataPowerBusHeaderBlock = False
    headerRow = 0
    cType = 0
    cDeviceType = 0
    cBus1 = 0
    cBus2 = 0
    c24Bus1 = 0
    c24Bus2 = 0
    If ws Is Nothing Then Exit Function

    lastCol = LastUsedCol(ws, 1)
    If lastCol < 7 Then Exit Function

    lastHeaderRow = LastUsedRow(ws)
    If lastHeaderRow > 10 Then lastHeaderRow = 10

    For r = 1 To lastHeaderRow
        For c = 1 To lastCol - 6
            If PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c).value)) = "TYPE" And _
               PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c + 1).value)) = "DESC" And _
               PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c + 2).value)) = "DEVICETYPE" And _
               PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c + 3).value)) = "BUS1" And _
               PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c + 4).value)) = "BUS2" And _
               PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c + 5).value)) = "24BUS1" And _
               PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c + 6).value)) = "24VBUS2" Then

                headerRow = r
                cType = c
                cDeviceType = c + 2
                cBus1 = c + 3
                cBus2 = c + 4
                c24Bus1 = c + 5
                c24Bus2 = c + 6
                PD6_FindDataPowerBusHeaderBlock = True
                Exit Function
            End If
        Next c
    Next r

End Function

Private Sub PD6_EnsureAE24VRule( _
        ByVal ws As Worksheet, _
        ByVal headerRow As Long, _
        ByVal cType As Long, _
        ByVal cDeviceType As Long, _
        ByVal cBus1 As Long, _
        ByVal cBus2 As Long, _
        ByVal c24Bus1 As Long, _
        ByVal c24Bus2 As Long)

    Dim lastRow As Long
    Dim r As Long
    Dim targetRow As Long

    If ws Is Nothing Then Exit Sub

    lastRow = ws.Cells(ws.rows.count, cType).End(xlUp).Row
    For r = headerRow + 1 To lastRow
        If PD6_NormalizeHeaderKey(CStr(ws.Cells(r, cType).value)) = "AE" Then Exit Sub
    Next r

    targetRow = lastRow + 1
    If targetRow <= headerRow Then targetRow = headerRow + 1

    ws.Cells(targetRow, cType).value = "AE"
    ws.Cells(targetRow, cType + 1).value = "Automation Electrical Panel"
    ws.Cells(targetRow, cDeviceType).value = "AE"
    ws.Cells(targetRow, cBus1).value = ""
    ws.Cells(targetRow, cBus2).value = ""
    ws.Cells(targetRow, c24Bus1).value = ""
    ws.Cells(targetRow, c24Bus2).value = "YES"

End Sub

Private Function PD6_DataPowerFlagIsEnabled(ByVal rawValue As Variant) As Boolean

    Dim t As String

    PD6_DataPowerFlagIsEnabled = False
    If IsError(rawValue) Or IsNull(rawValue) Or IsEmpty(rawValue) Then Exit Function

    If VarType(rawValue) = vbBoolean Then
        PD6_DataPowerFlagIsEnabled = CBool(rawValue)
        Exit Function
    End If

    t = UCase$(Trim$(CStr(rawValue)))
    Select Case t
        Case "YES", "Y", "TRUE", "1", "X", "BUS-1", "BUS1", "BUS-2", "BUS2"
            PD6_DataPowerFlagIsEnabled = True
    End Select

End Function

Private Sub PD6_AddDataPowerBusAliasList( _
        ByVal busMap As Object, _
        ByVal aliasText As String, _
        ByVal bus1Value As Variant, _
        ByVal bus2Value As Variant, _
        ByVal needsBus1 As Boolean, _
        ByVal needsBus2 As Boolean)

    Dim cleanText As String
    Dim parts() As String
    Dim i As Long

    cleanText = Replace(aliasText, vbCrLf, "|")
    cleanText = Replace(cleanText, vbCr, "|")
    cleanText = Replace(cleanText, vbLf, "|")
    cleanText = Replace(cleanText, ";", "|")
    cleanText = Replace(cleanText, ",", "|")
    parts = Split(cleanText, "|")

    For i = LBound(parts) To UBound(parts)
        PD6_AddDataPowerBusRuleKeys busMap, Trim$(parts(i)), bus1Value, bus2Value, needsBus1, needsBus2
    Next i

End Sub

Private Sub PD6_AddDataPowerBusRuleKeys( _
        ByVal busMap As Object, _
        ByVal typeText As String, _
        ByVal bus1Value As Variant, _
        ByVal bus2Value As Variant, _
        ByVal needsBus1 As Boolean, _
        ByVal needsBus2 As Boolean)

    If Len(Trim$(typeText)) = 0 Then Exit Sub

    PD6_AddDataPowerBusMapEntry busMap, PD6_LookupKey(typeText), bus1Value, bus2Value, needsBus1, needsBus2
    PD6_AddDataPowerBusMapEntry busMap, PD6_NormalizeHeaderKey(typeText), bus1Value, bus2Value, needsBus1, needsBus2

End Sub

Private Sub PD6_AddDataPowerBusMapEntry( _
        ByVal busMap As Object, _
        ByVal keyText As String, _
        ByVal bus1Value As Variant, _
        ByVal bus2Value As Variant, _
        ByVal needsBus1 As Boolean, _
        ByVal needsBus2 As Boolean)

    Dim entry As Variant

    If busMap Is Nothing Then Exit Sub
    keyText = Trim$(keyText)
    If Len(keyText) = 0 Then Exit Sub

    If busMap.Exists(keyText) Then
        entry = busMap(keyText)
    Else
        entry = Array("", "", False, False)
    End If

    If Len(Trim$(CStr(bus1Value))) > 0 Then entry(0) = bus1Value
    If Len(Trim$(CStr(bus2Value))) > 0 Then entry(1) = bus2Value
    If needsBus1 Then entry(2) = True
    If needsBus2 Then entry(3) = True
    busMap(keyText) = entry

End Sub

Private Function PD6_DataPowerBusCellValue(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal colNum As Long) As Variant

    Dim rawValue As Variant
    Dim textValue As String

    PD6_DataPowerBusCellValue = ""
    If ws Is Nothing Or colNum <= 0 Then Exit Function

    rawValue = ws.Cells(rowNum, colNum).Value2
    If IsError(rawValue) Then Exit Function

    textValue = Trim$(CStr(rawValue))
    If Len(textValue) = 0 Then Exit Function

    If IsNumeric(rawValue) Then
        PD6_DataPowerBusCellValue = CDbl(rawValue)
    ElseIf IsNumeric(textValue) Then
        PD6_DataPowerBusCellValue = CDbl(textValue)
    Else
        PD6_DataPowerBusCellValue = textValue
    End If

End Function

Private Function PD6_CalculateLoad(ByVal ws As Worksheet, ByVal rowNum As Long, ByVal sysType As String, ByVal motorVoltText As String) As Variant

    Dim sourceLoad As String
    Dim motorPower As Double
    Dim motorVolt As Double
    Dim totalDrives As Double
    Dim u As String

    sourceLoad = PD6_Pick(ws, rowNum, "Load", "LOAD", "CURRENT_LOAD")
    u = UCase$(Trim$(sysType & " " & motorVoltText))

    If InStr(1, u, "400", vbTextCompare) > 0 Or InStr(1, u, "460", vbTextCompare) > 0 Or InStr(1, u, "480", vbTextCompare) > 0 Then
        PD6_CalculateLoad = 1.6
        Exit Function
    End If

    If InStr(1, u, "24V", vbTextCompare) > 0 Or InStr(1, u, "24 V", vbTextCompare) > 0 Then

        motorPower = PD6_Number(ws, rowNum, "Motor Power (Main Drive)", "MOTOR POWER (MAIN DRIVE)", "Motor Power")
        motorVolt = PD6_Number(ws, rowNum, "Motor Voltage (Main Drive)", "MOTOR VOLTAGE (MAIN DRIVE)", "Motor Voltage")
        totalDrives = PD6_Number(ws, rowNum, "Total Qty of Drives", "TOTAL QTY OF DRIVES", "Qty of Drives")

        If totalDrives = 0 Then totalDrives = 1

        If motorPower <> 0 And motorVolt <> 0 Then
            PD6_CalculateLoad = (motorPower * 1000# / motorVolt) * totalDrives
        ElseIf Len(sourceLoad) > 0 Then
            PD6_CalculateLoad = sourceLoad
        Else
            PD6_CalculateLoad = ""
        End If

        Exit Function

    End If

    If Len(sourceLoad) > 0 Then
        PD6_CalculateLoad = sourceLoad
    Else
        PD6_CalculateLoad = ""
    End If

End Function

Private Function PD6_BuildControlID(ByVal areaVal As String, ByVal switchVal As String, ByVal sisSeqVal As String, ByVal typeVal As String) As String

    Dim baseID As String
    Dim kSuffix As String

    If Len(Trim$(sisSeqVal)) = 0 Then Exit Function

    baseID = PD6_BuildBaseElement(areaVal, switchVal, sisSeqVal)
    If Len(baseID) = 0 Then Exit Function

    If PD6_EndsWithKSuffix(baseID) Then
        PD6_BuildControlID = baseID
        Exit Function
    End If

    kSuffix = PD6_GetConfiguredOrDefaultKSuffix(baseID, typeVal, True)

    If Len(kSuffix) > 0 Then
        PD6_BuildControlID = PD6_AppendKSuffixIfNeeded(baseID, kSuffix)
    Else
        PD6_BuildControlID = baseID
    End If

End Function

Private Function PD6_GetConfiguredOrDefaultKSuffix(ByVal baseID As String, ByVal typeVal As String, ByVal allocateRange As Boolean) As String

    Dim canonicalType As String
    Dim ruleText As String
    Dim resolvedSuffix As String
    Dim ruleWasValid As Boolean

    canonicalType = PD6_ControlKCanonicalType(typeVal)
    ruleText = PD6_GetControlKRule(canonicalType)

    If Len(ruleText) > 0 Then
        resolvedSuffix = PD6_ResolveKRule(ruleText, baseID, canonicalType, allocateRange, ruleWasValid)
        If ruleWasValid Then
            PD6_GetConfiguredOrDefaultKSuffix = resolvedSuffix
            Exit Function
        End If
    End If

    PD6_GetConfiguredOrDefaultKSuffix = PD6_DefaultKSuffix(canonicalType)

End Function

Private Sub PD6_EnsureControlKRuleCache()

    Dim ws As Worksheet
    Dim headerRow As Long
    Dim cType As Long
    Dim cRange As Long
    Dim lastRow As Long
    Dim lastCol As Long
    Dim scanLastRow As Long
    Dim r As Long
    Dim c As Long
    Dim h As String
    Dim typeKey As String
    Dim rangeText As String

    If Not mPD6ControlKRuleCache Is Nothing Then Exit Sub

    Set mPD6ControlKRuleCache = CreateObject("Scripting.Dictionary")
    mPD6ControlKRuleCache.CompareMode = vbTextCompare

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("DATA")
    On Error GoTo 0
    If ws Is Nothing Then Exit Sub

    lastRow = LastUsedRow(ws)
    lastCol = ws.UsedRange.Column + ws.UsedRange.Columns.count - 1
    scanLastRow = lastRow
    If scanLastRow > 50 Then scanLastRow = 50

    For r = 1 To scanLastRow
        cRange = 0
        cType = 0

        For c = 1 To lastCol
            h = PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c).value))
            Select Case h
                Case "KVALUERANGE", "KRANGE", "CONTROLIDKRANGE", "CONTROLIDKVALUE", "CONTROLIDKVALUERANGE"
                    cRange = c
                    Exit For
            End Select
        Next c

        If cRange > 0 Then
            For c = cRange - 1 To 1 Step -1
                h = PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c).value))
                If h = "DEVICETYPE" Or h = "TYPE" Then
                    cType = c
                    Exit For
                End If
            Next c

            If cType = 0 Then
                For c = cRange + 1 To lastCol
                    h = PD6_NormalizeHeaderKey(CStr(ws.Cells(r, c).value))
                    If h = "DEVICETYPE" Or h = "TYPE" Then
                        cType = c
                        Exit For
                    End If
                Next c
            End If

            If cType > 0 Then
                headerRow = r
                Exit For
            End If
        End If
    Next r

    If headerRow = 0 Or cType = 0 Or cRange = 0 Then Exit Sub

    For r = headerRow + 1 To lastRow
        typeKey = PD6_ControlKCanonicalType(CStr(ws.Cells(r, cType).value))
        rangeText = Trim$(CStr(ws.Cells(r, cRange).value))

        If Len(typeKey) > 0 And Len(rangeText) > 0 Then
            mPD6ControlKRuleCache(typeKey) = rangeText
        End If
    Next r

End Sub

Private Function PD6_GetControlKRule(ByVal canonicalType As String) As String

    PD6_EnsureControlKRuleCache

    If mPD6ControlKRuleCache Is Nothing Then Exit Function
    If mPD6ControlKRuleCache.Exists(canonicalType) Then
        PD6_GetControlKRule = Trim$(CStr(mPD6ControlKRuleCache(canonicalType)))
    End If

End Function

Private Function PD6_ControlKCanonicalType(ByVal rawType As String) As String

    Dim t As String

    t = UCase$(Trim$(rawType))
    t = Replace$(t, " ", vbNullString)
    t = Replace$(t, "_", "/")
    t = Replace$(t, "\", "/")
    t = Replace$(t, "-", "/")

    If t = "IOD" Or t = "I/O/D" Or InStr(1, t, "IO/D", vbTextCompare) > 0 Then
        PD6_ControlKCanonicalType = "IO/D"
    ElseIf t = "IOS" Or t = "I/O/S" Or InStr(1, t, "IO/S", vbTextCompare) > 0 Then
        PD6_ControlKCanonicalType = "IO/S"
    ElseIf Left$(t, 7) = "SCANNER" Or Left$(t, 3) = "SCN" Then
        PD6_ControlKCanonicalType = "SCN"
    ElseIf Left$(t, 3) = "VFD" Then
        PD6_ControlKCanonicalType = "VFD"
    ElseIf t = "MC" Then
        PD6_ControlKCanonicalType = "MC"
    ElseIf t = "MS" Then
        PD6_ControlKCanonicalType = "MS"
    ElseIf t = "PSU" Then
        PD6_ControlKCanonicalType = "PSU"
    Else
        PD6_ControlKCanonicalType = t
    End If

End Function

Private Function PD6_DefaultKSuffix(ByVal canonicalType As String) As String

    Select Case canonicalType
        Case "MC"
            PD6_DefaultKSuffix = "K1"
        Case "SCN"
            PD6_DefaultKSuffix = "K70"
        Case "VFD"
            PD6_DefaultKSuffix = "K7"
        Case "IO/D"
            PD6_DefaultKSuffix = "K4"
        Case "IO/S"
            PD6_DefaultKSuffix = "K5"
        Case Else
            PD6_DefaultKSuffix = vbNullString
    End Select

End Function

Private Function PD6_ResolveKRule(ByVal ruleText As String, _
                                  ByVal baseID As String, _
                                  ByVal canonicalType As String, _
                                  ByVal allocateRange As Boolean, _
                                  ByRef ruleWasValid As Boolean) As String

    Dim s As String
    Dim parts As Variant
    Dim startK As Long
    Dim endK As Long
    Dim itemK As Long
    Dim selectedIndex As Long
    Dim itemCount As Long
    Dim allocationKey As String

    ruleWasValid = False
    s = UCase$(Trim$(ruleText))
    s = Replace$(s, ChrW(8211), "-")
    s = Replace$(s, ChrW(8212), "-")
    s = Replace$(s, " TO ", "-")
    s = Replace$(s, " ", vbNullString)

    If Len(s) = 0 Then Exit Function

    If InStr(1, s, ",", vbBinaryCompare) > 0 Then
        parts = Split(s, ",")
        itemCount = UBound(parts) - LBound(parts) + 1
        If itemCount <= 0 Then Exit Function

        If allocateRange Then
            allocationKey = UCase$(Trim$(baseID)) & "|" & canonicalType & "|" & s
            selectedIndex = PD6_NextKAllocationIndex(allocationKey, itemCount)
        Else
            selectedIndex = 0
        End If

        If PD6_ParseKNumber(CStr(parts(LBound(parts) + selectedIndex)), itemK) Then
            ruleWasValid = True
            PD6_ResolveKRule = "K" & CStr(itemK)
        End If
        Exit Function
    End If

    If InStr(2, s, "-", vbBinaryCompare) > 0 Then
        parts = Split(s, "-")
        If UBound(parts) - LBound(parts) = 1 Then
            If PD6_ParseKNumber(CStr(parts(LBound(parts))), startK) And _
               PD6_ParseKNumber(CStr(parts(UBound(parts))), endK) Then

                If startK > endK Then
                    itemK = startK
                    startK = endK
                    endK = itemK
                End If

                itemCount = endK - startK + 1
                If allocateRange Then
                    allocationKey = UCase$(Trim$(baseID)) & "|" & canonicalType & "|" & s
                    selectedIndex = PD6_NextKAllocationIndex(allocationKey, itemCount)
                Else
                    selectedIndex = 0
                End If

                ruleWasValid = True
                PD6_ResolveKRule = "K" & CStr(startK + selectedIndex)
                Exit Function
            End If
        End If
    End If

    If PD6_ParseKNumber(s, itemK) Then
        ruleWasValid = True
        PD6_ResolveKRule = "K" & CStr(itemK)
    End If

End Function

Private Function PD6_NextKAllocationIndex(ByVal allocationKey As String, ByVal itemCount As Long) As Long

    Dim currentCount As Long

    If itemCount <= 1 Then Exit Function

    If mPD6ControlKAllocationCache Is Nothing Then
        Set mPD6ControlKAllocationCache = CreateObject("Scripting.Dictionary")
        mPD6ControlKAllocationCache.CompareMode = vbTextCompare
    End If

    If mPD6ControlKAllocationCache.Exists(allocationKey) Then
        currentCount = CLng(mPD6ControlKAllocationCache(allocationKey))
    Else
        currentCount = 0
    End If

    If currentCount >= itemCount Then
        PD6_NextKAllocationIndex = itemCount - 1
        PD6_LogControlKOverflow allocationKey, itemCount
    Else
        PD6_NextKAllocationIndex = currentCount
    End If

    mPD6ControlKAllocationCache(allocationKey) = currentCount + 1

End Function

Private Function PD6_ParseKNumber(ByVal tokenText As String, ByRef kNumber As Long) As Boolean

    Dim s As String
    Dim i As Long
    Dim ch As String

    s = UCase$(Trim$(tokenText))
    If Left$(s, 1) = "K" Then s = mid$(s, 2)
    If Len(s) = 0 Then Exit Function

    For i = 1 To Len(s)
        ch = mid$(s, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i

    On Error GoTo InvalidNumber
    kNumber = CLng(s)
    If kNumber < 0 Then Exit Function
    PD6_ParseKNumber = True
    Exit Function

InvalidNumber:
    PD6_ParseKNumber = False

End Function

Private Sub PD6_LogControlKOverflow(ByVal allocationKey As String, ByVal itemCount As Long)

    If mPD6ControlKWarningCache Is Nothing Then
        Set mPD6ControlKWarningCache = CreateObject("Scripting.Dictionary")
        mPD6ControlKWarningCache.CompareMode = vbTextCompare
    End If

    If mPD6ControlKWarningCache.Exists(allocationKey) Then Exit Sub
    mPD6ControlKWarningCache.Add allocationKey, True

    On Error Resume Next
    AppendLog "PD6_Control_ID_K_Table", "WARNING", _
              "Configured K range/list contains " & CStr(itemCount) & _
              " value(s), but more matching duplicate rows were found. The last K value was reused. Key: " & allocationKey
    On Error GoTo 0

End Sub

Public Function PD6Net_CanonicalType(ByVal rawType As String) As String
    Dim t As String
    t = UCase$(Trim$(rawType))
    t = Replace(t, " ", "")
    t = Replace(t, "_", "/")
    t = Replace(t, "\", "/")

    If Left$(t, 4) = "IO/S" Or t = "IOS" Then
        PD6Net_CanonicalType = "IO/S"
    ElseIf Left$(t, 4) = "IO/D" Or t = "IOD" Then
        PD6Net_CanonicalType = "IO/D"
    ElseIf t = "MC" Then
        PD6Net_CanonicalType = "MC"
    ElseIf t = "MS" Then
        PD6Net_CanonicalType = "MS"
    ElseIf Left$(t, 3) = "VFD" Then
        PD6Net_CanonicalType = "VFD"
    ElseIf t = "PNL" Or t = "PANEL" Or t = "RIO" Then
        PD6Net_CanonicalType = "PNL"
    ElseIf Left$(t, 3) = "SCN" Or Left$(t, 7) = "SCANNER" Then
        PD6Net_CanonicalType = "SCN"
    End If
End Function

Public Function PD6Net_DeviceDescription(ByVal canonicalType As String, ByVal controlCard As String, ByVal systemType As String) As String
    Dim hint As String
    Select Case canonicalType
        Case "IO/S": PD6Net_DeviceDescription = "EP1957-0022"
        Case "IO/D": PD6Net_DeviceDescription = "EP2339-0042"
        Case "MC", "MS": PD6Net_DeviceDescription = "MultiControl EtherCAT"
        Case "PNL": PD6Net_DeviceDescription = "RIO"
        Case "SCN": PD6Net_DeviceDescription = "Scanner CDF600-x3xx"
        Case "VFD"
            hint = UCase$(controlCard & " " & systemType)
            If InStr(hint, "MOVIMOT") > 0 Or InStr(hint, "MFE") > 0 Then
                PD6Net_DeviceDescription = "MOVIMOT+MFE72A"
            Else
                PD6Net_DeviceDescription = "MOVI-C Decentralized Electronics"
            End If
    End Select
End Function

Public Function PD6Net_ControlTag(ByVal canonicalType As String) As String

    PD6Net_ControlTag = PD6_GetConfiguredOrDefaultKSuffix(vbNullString, canonicalType, False)

End Function

Public Function PD6Net_TopologyCellText(ByVal swg As String, ByVal sisSeq As String, _
    ByVal canonicalType As String, ByVal description As String) As String

    Dim tagText As String, seqText As String
    seqText = Replace(Trim$(sisSeq), "-", "_")
    tagText = PD6Net_ControlTag(canonicalType)

    PD6Net_TopologyCellText = "IO_" & Replace(Trim$(swg), "-", "_") & "_" & seqText
    If Len(tagText) > 0 And Not PD6Net_HasKToken(sisSeq) Then
        PD6Net_TopologyCellText = PD6Net_TopologyCellText & "_" & tagText
    End If
    If Len(description) > 0 Then
        PD6Net_TopologyCellText = PD6Net_TopologyCellText & " [" & description & "]"
    End If
End Function

Public Function PD6Net_HasKToken(ByVal txt As String) As Boolean
    Dim parts() As String, i As Long, token As String
    txt = Replace(txt, "_", "-")
    parts = Split(txt, "-")
    For i = LBound(parts) To UBound(parts)
        token = UCase$(Trim$(parts(i)))
        If Len(token) >= 2 And Left$(token, 1) = "K" Then
            If IsNumeric(mid$(token, 2)) Then
                PD6Net_HasKToken = True
                Exit Function
            End If
        End If
    Next i
End Function

Public Function PD6Net_NormalizeSequence(ByVal sisSeq As String, ByVal areaNumber As String, ByVal swg As String) As String
    Dim prefix As String
    sisSeq = Trim$(sisSeq)
    prefix = Trim$(areaNumber) & "-" & Trim$(swg) & "-"
    If Len(areaNumber) > 0 And Len(swg) > 0 Then
        If StrComp(Left$(sisSeq, Len(prefix)), prefix, vbTextCompare) = 0 Then
            sisSeq = mid$(sisSeq, Len(prefix) + 1)
        End If
    End If
    PD6Net_NormalizeSequence = Trim$(sisSeq)
End Function

Public Function PD6Net_ModuleLengthMeters(ByVal valueIn As Variant) As Double
    Dim rawValue As Double, txt As String, unitText As String
    If IsError(valueIn) Or IsEmpty(valueIn) Then Exit Function

    If IsNumeric(valueIn) Then
        rawValue = CDbl(valueIn)
    Else
        txt = UCase$(Trim$(CStr(valueIn)))
        If InStr(txt, "MM") > 0 Then unitText = "MM"
        If InStr(txt, "FT") > 0 Or InStr(txt, "FEET") > 0 Or InStr(txt, "'") > 0 Then unitText = "FT"
        If InStr(txt, "IN") > 0 Or InStr(txt, Chr$(34)) > 0 Then unitText = "IN"
        txt = Replace(txt, "MILLIMETERS", "")
        txt = Replace(txt, "MILLIMETER", "")
        txt = Replace(txt, "MM", "")
        txt = Replace(txt, "FEET", "")
        txt = Replace(txt, "FOOT", "")
        txt = Replace(txt, "FT", "")
        txt = Replace(txt, "INCHES", "")
        txt = Replace(txt, "INCH", "")
        txt = Replace(txt, "IN", "")
        txt = Replace(txt, Chr$(34), "")
        txt = Replace(txt, "'", "")
        txt = Replace(txt, ",", "")
        txt = Trim$(txt)
        If IsNumeric(txt) Then rawValue = CDbl(txt)
    End If

    If rawValue <= 0# Then Exit Function
    Select Case unitText
        Case "MM": PD6Net_ModuleLengthMeters = rawValue / 1000#
        Case "IN": PD6Net_ModuleLengthMeters = rawValue * 0.0254
        Case "FT": PD6Net_ModuleLengthMeters = rawValue * 0.3048
        Case Else
            If rawValue > 500# Then
                PD6Net_ModuleLengthMeters = rawValue / 1000#
            ElseIf rawValue > 60# Then
                PD6Net_ModuleLengthMeters = rawValue * 0.0254
            Else
                PD6Net_ModuleLengthMeters = rawValue * 0.3048
            End If
    End Select
End Function

Public Function PD6Net_FirstNumber(ByVal txt As String) As Double
    Dim i As Long, j As Long, ch As String, numberText As String
    txt = Trim$(txt)
    For i = 1 To Len(txt)
        ch = mid$(txt, i, 1)
        If ch >= "0" And ch <= "9" Then
            j = i
            Do While j <= Len(txt)
                ch = mid$(txt, j, 1)
                If ch < "0" Or ch > "9" Then Exit Do
                numberText = numberText & ch
                j = j + 1
            Loop
            If Len(numberText) > 0 Then
                PD6Net_FirstNumber = CDbl(numberText)
                Exit Function
            End If
        End If
    Next i
    PD6Net_FirstNumber = 1E+99
End Function

Public Function PD6Net_MissingReason(ByVal panel As String, ByVal swg As String, ByVal sisSeq As String) As String
    If Len(panel) = 0 Then PD6Net_MissingReason = "Missing Panel"
    If Len(swg) = 0 Then
        If Len(PD6Net_MissingReason) > 0 Then PD6Net_MissingReason = PD6Net_MissingReason & "; "
        PD6Net_MissingReason = PD6Net_MissingReason & "Missing SwitchGroup"
    End If
    If Len(sisSeq) = 0 Then
        If Len(PD6Net_MissingReason) > 0 Then PD6Net_MissingReason = PD6Net_MissingReason & "; "
        PD6Net_MissingReason = PD6Net_MissingReason & "Missing SIS sequence"
    End If
End Function

