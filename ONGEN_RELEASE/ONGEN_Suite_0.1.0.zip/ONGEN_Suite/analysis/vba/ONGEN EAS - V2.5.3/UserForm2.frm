Attribute VB_Name = "UserForm2"
Attribute VB_Base = "0{1FF85B82-3DD4-4164-ACB8-AA7D1D373CC4}{9CDEF4E5-BB9C-434C-87A2-D09ACE1AB4FA}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
