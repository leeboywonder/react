Attribute VB_Name = "mod00_ONGEN_V20_Core"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod00_ONGEN_V20_Core
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : mod00_ONGEN_V20_Core
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Static procedure, declaration, and public-name audit completed.
' Notes         : Central suite constants updated to ONGEN EAS V21.5; compatibility procedure names retained.
'-------------------------------------------------------------------------------

Option Explicit

'-------------------------------------------------------------------------------
' ONGEN Electrical Automation Suite - Version 21.5
' Author: Lee Pierre, Principal Electrical Engineer
' Purpose: Central version, installation, repair, and startup commands.
'-------------------------------------------------------------------------------

Public Const ONGEN_SUITE_VERSION As String = "21.5"
Public Const ONGEN_SUITE_NAME As String = "ONGEN Electrical Automation Suite"

Public Sub ONGEN_V20_INSTALL_OR_REPAIR()
    Dim oldCalc As XlCalculation
    On Error GoTo EH

    oldCalc = Application.Calculation
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_RELOAD_ALL_UI_BUTTONS"
    Application.Run "'" & ThisWorkbook.Name & "'!NAV_Install_Return_To_MAIN_Buttons_All_Sheets"
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_Create_Or_Open_Workflow_Guide"

    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox ONGEN_SUITE_NAME & " V" & ONGEN_SUITE_VERSION & _
           " installation/repair completed.", vbInformation, "ONGEN EAS V21.5"
    Exit Sub
EH:
    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    MsgBox "ONGEN EAS V21.5 installation/repair failed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, vbCritical, "ONGEN EAS V21.5"
End Sub

Public Sub ONGEN_V20_OPEN_GUIDE()
    On Error GoTo EH
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_Create_Or_Open_Workflow_Guide"
    Exit Sub
EH:
    MsgBox "Unable to open the ONGEN EAS V21.5 workflow guide." & vbCrLf & _
           Err.description, vbExclamation, "ONGEN EAS V21.5"
End Sub

Public Sub ONGEN_V20_RUN_STARTUP_AUDIT()
    Dim issues As String
    issues = vbNullString

    If Not ONGEN_V20_WorksheetExists("MAIN") Then issues = issues & vbCrLf & "- MAIN worksheet is missing."
    If Not ONGEN_V20_WorksheetExists("DATA") Then issues = issues & vbCrLf & "- DATA worksheet is missing."
    If Not ONGEN_V20_WorksheetExists("480v_DATA_POWER") Then issues = issues & vbCrLf & "- 480v_DATA_POWER worksheet is missing."
    If Not ONGEN_V20_WorksheetExists("PD6_IMPORT") Then issues = issues & vbCrLf & "- PD6_IMPORT is not currently present (run Step 05 if required)."

    If Len(issues) = 0 Then
        MsgBox "ONGEN EAS V21.5 startup audit passed.", vbInformation, "ONGEN EAS V21.5 Audit"
    Else
        MsgBox "ONGEN EAS V21.5 startup audit found the following:" & issues, _
               vbExclamation, "ONGEN EAS V21.5 Audit"
    End If
End Sub

Public Sub ONGEN_V20_VALIDATE_PSU_TERMINAL_TABLE()
    On Error GoTo EH
    Application.Run "'" & ThisWorkbook.Name & "'!Step05_Validate_PD6_PSU_Terminal_Table"
    Exit Sub
EH:
    MsgBox "The PSU terminal table validation could not run." & vbCrLf & _
           "Confirm mod02_PD6_Import is the V20 replacement." & vbCrLf & _
           Err.description, vbCritical, "ONGEN EAS V21.5"
End Sub

Public Sub ONGEN_V20_RECALCULATE_PD6()
    On Error GoTo EH
    Application.Run "'" & ThisWorkbook.Name & "'!Step05_Recalculate_PD6_IMPORT_Calculations"
    Exit Sub
EH:
    MsgBox "PD6 recalculation failed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, vbCritical, "ONGEN EAS V21.5"
End Sub

Public Sub ONGEN_V20_REASSIGN_PSU_TERMINALS()
    On Error GoTo EH
    Application.Run "'" & ThisWorkbook.Name & "'!Step05_Reassign_PD6_BUS_PSU_Terminals"
    Exit Sub
EH:
    MsgBox "PD6 PSU/terminal reassignment failed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, vbCritical, "ONGEN EAS V21.5"
End Sub

Public Sub ONGEN_EAS_V21_5_INSTALL_OR_REPAIR()
    ONGEN_V20_INSTALL_OR_REPAIR
End Sub

Public Sub ONGEN_EAS_V21_5_OPEN_GUIDE()
    ONGEN_V20_OPEN_GUIDE
End Sub

Public Sub ONGEN_EAS_V21_5_RUN_STARTUP_AUDIT()
    ONGEN_V20_RUN_STARTUP_AUDIT
End Sub

Private Function ONGEN_V20_WorksheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    ONGEN_V20_WorksheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

