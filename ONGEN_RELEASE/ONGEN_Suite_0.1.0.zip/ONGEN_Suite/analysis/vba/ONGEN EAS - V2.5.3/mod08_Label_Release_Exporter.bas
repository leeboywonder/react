Attribute VB_Name = "mod08_Label_Release_Exporter"
Option Explicit
'===============================================================================
' ONGEN EAS - STEP 17 LABEL RELEASE EXPORTER
' Author: Lee Pierre, Principal Electrical Engineer
' Purpose: Permanent production module for the ONGEN Engineering Automation Suite.
'          This module is part of the V26.3 clean workflow baseline.
'===============================================================================



'===============================================================================
' ONGEN EAS - STEP 17 DIRECT RELEASE EXPORTER
'
' Permanent export architecture:
'   CABLE_TAG_OUTPUT       -> WIO / WSF / WNET / WDC / WPWR / WMTR
'   VFD DWG MPWR GROUPS   -> MPWR parent + child rows DIRECTLY
'
' MPWR is NOT dependent on CABLE_TAG_OUTPUT.
'
' Export worksheets:
'   READ ME
'   ALL LABELS
'   IO LABELS
'   NETWORK LABELS
'   POWER LABELS
'   DEVICE TAGS
'
' DEVICE TAGS sources:
'   PD6_IMPORT
'   IO_DEVICE_LIST
'   VFD_DWG_QUEUE
'   VFD_DWG_DEVICE_PLACEMENT (enabled rows only)
'
' Export intentionally removes:
'   Source Sheet / Data Source
'   Notes
'===============================================================================

Private Const CABLE_SHEET As String = "CABLE_TAG_OUTPUT"
Private Const MPWR_SHEET As String = "VFD DWG MPWR GROUPS"
Private Const PD6_SHEET As String = "PD6_IMPORT"
Private Const IO_DEVICE_SHEET As String = "IO_DEVICE_LIST"
Private Const VFD_QUEUE_SHEET As String = "VFD_DWG_QUEUE"
Private Const DEVICE_PLACEMENT_SHEET As String = "VFD_DWG_DEVICE_PLACEMENT"

Private Const CABLE_HEADER_ROW As Long = 6
Private Const CABLE_FIRST_DATA_ROW As Long = 7

'17 exported columns:
'1 Label ID
'2 Category
'3 Type Code
'4 Package
'5 Area
'6 Panel
'7 SwitchGroup
'8 From
'9 From Terminal
'10 To
'11 To Terminal
'12 Device / Route Type
'13 Port / Bus
'14 Load / Length
'15 Description
'16 Status
'17 Quantity
Private Const EXPORT_COL_COUNT As Long = 17


Public Sub ONGEN_Export_Label_List_Report_CORE()
    On Error GoTo FailHandler

    Dim oldScreen As Boolean
    Dim oldEvents As Boolean
    Dim oldCalc As XlCalculation
    Dim oldStatus As Variant

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    oldCalc = Application.Calculation
    oldStatus = Application.StatusBar

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Application.StatusBar = "ONGEN Step 17: Refreshing baseline cable families..."

    'Refresh the normal families. MPWR is exported separately from its own
    'canonical worksheet and therefore cannot be lost by this refresh.
    LABEL17_TryRun "Build_ONGEN_Combined_Label_List"
    LABEL17_TryRun "ONGEN_Network_Append_WNET_To_Output"

    'Refresh canonical MPWR mapping when available.
    LABEL17_TryRun "VFD_DWG_Refresh_MPWR_Group_IDs_Silent"

    Dim wsCable As Worksheet
    Dim wsMPWR As Worksheet

    Set wsCable = LABEL17_GetSheet(CABLE_SHEET)
    Set wsMPWR = LABEL17_GetSheet(MPWR_SHEET)

    If wsCable Is Nothing Then
        Err.Raise vbObjectError + 18201, _
                  "ONGEN_Export_Label_List_Report_CORE", _
                  "Worksheet '" & CABLE_SHEET & "' was not found."
    End If

    If wsMPWR Is Nothing Then
        Err.Raise vbObjectError + 18202, _
                  "ONGEN_Export_Label_List_Report_CORE", _
                  "Worksheet '" & MPWR_SHEET & "' was not found."
    End If

    LABEL17_ValidateCableSheet wsCable

    Dim mpwrParentCount As Long
    Dim mpwrChildCount As Long

    LABEL17_CountMPWR wsMPWR, mpwrParentCount, mpwrChildCount

    If mpwrParentCount <= 0 Then
        Err.Raise vbObjectError + 18203, _
                  "ONGEN_Export_Label_List_Report_CORE", _
                  "No connected MPWR parent power groups were found in '" & _
                  MPWR_SHEET & "'."
    End If

    Application.StatusBar = "ONGEN Step 17: Preparing release workbook..."

    Dim savePath As Variant
    savePath = LABEL17_GetSavePath()

    If VarType(savePath) = vbBoolean Then
        If savePath = False Then GoTo CleanExit
    End If

    Dim reportWb As Workbook
    Set reportWb = Workbooks.Add(xlWBATWorksheet)

    Dim wsReadMe As Worksheet
    Dim wsAll As Worksheet
    Dim wsIO As Worksheet
    Dim wsNetwork As Worksheet
    Dim wsPower As Worksheet
    Dim wsDevices As Worksheet

    Set wsReadMe = reportWb.Worksheets(1)
    wsReadMe.Name = "READ ME"

    Set wsAll = reportWb.Worksheets.Add(After:=reportWb.Worksheets(reportWb.Worksheets.count))
    wsAll.Name = "ALL LABELS"

    Set wsIO = reportWb.Worksheets.Add(After:=reportWb.Worksheets(reportWb.Worksheets.count))
    wsIO.Name = "IO LABELS"

    Set wsNetwork = reportWb.Worksheets.Add(After:=reportWb.Worksheets(reportWb.Worksheets.count))
    wsNetwork.Name = "NETWORK LABELS"

    Set wsPower = reportWb.Worksheets.Add(After:=reportWb.Worksheets(reportWb.Worksheets.count))
    wsPower.Name = "POWER LABELS"

    Set wsDevices = reportWb.Worksheets.Add(After:=reportWb.Worksheets(reportWb.Worksheets.count))
    wsDevices.Name = "DEVICE TAGS"

    LABEL17_WriteReadMe wsReadMe

    LABEL17_WriteHeaders wsAll
    LABEL17_WriteHeaders wsIO
    LABEL17_WriteHeaders wsNetwork
    LABEL17_WriteHeaders wsPower

    Dim nextAll As Long
    Dim nextIO As Long
    Dim nextNetwork As Long
    Dim nextPower As Long

    nextAll = 2
    nextIO = 2
    nextNetwork = 2
    nextPower = 2

    'Normal families from CABLE_TAG_OUTPUT.
    LABEL17_ExportCableOutput _
        wsCable, _
        wsAll, nextAll, _
        wsIO, nextIO, _
        wsNetwork, nextNetwork, _
        wsPower, nextPower

    'MPWR is built DIRECTLY from canonical mapping.
    LABEL17_ExportMPWRDirect _
        wsMPWR, _
        wsAll, nextAll, _
        wsPower, nextPower

    'Build one consolidated equipment/device-tag schedule.
    Application.StatusBar = "ONGEN Step 17: Building device-tag schedule..."
    LABEL17_ExportDeviceTags wsDevices

    LABEL17_FormatSheet wsAll
    LABEL17_FormatSheet wsIO
    LABEL17_FormatSheet wsNetwork
    LABEL17_FormatSheet wsPower
    LABEL17_FormatDeviceSheet wsDevices

    'Validate required MPWR export before saving.
    Dim allMPWR As Long
    Dim powerMPWR As Long
    Dim expectedMPWR As Long

    expectedMPWR = mpwrParentCount + mpwrChildCount
    allMPWR = LABEL17_CountExportFamily(wsAll, "MPWR")
    powerMPWR = LABEL17_CountExportFamily(wsPower, "MPWR")

    If allMPWR <> expectedMPWR Or powerMPWR <> expectedMPWR Then
        Err.Raise vbObjectError + 18204, _
                  "ONGEN_Export_Label_List_Report_CORE", _
                  "MPWR export validation failed." & vbCrLf & _
                  "Expected MPWR rows: " & CStr(expectedMPWR) & vbCrLf & _
                  "ALL LABELS MPWR rows: " & CStr(allMPWR) & vbCrLf & _
                  "POWER LABELS MPWR rows: " & CStr(powerMPWR)
    End If

    Application.StatusBar = "ONGEN Step 17: Saving release workbook..."

    Application.DisplayAlerts = False
    reportWb.SaveAs fileName:=CStr(savePath), FileFormat:=xlOpenXMLWorkbook
    Application.DisplayAlerts = True

    wsReadMe.Activate

    Application.StatusBar = oldStatus
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    MsgBox _
        "Step 17 label report exported successfully." & vbCrLf & vbCrLf & _
        "MPWR parent rows: " & CStr(mpwrParentCount) & vbCrLf & _
        "MPWR child rows: " & CStr(mpwrChildCount) & vbCrLf & _
        "Total MPWR rows exported: " & CStr(expectedMPWR) & vbCrLf & _
        "Device tags exported: " & Format$(LABEL17_LastRow(wsDevices) - 1, "#,##0"), _
        vbInformation, _
        "ONGEN Label List Export"
    Exit Sub

CleanExit:
    Application.StatusBar = oldStatus
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    Exit Sub

FailHandler:
    Dim n As Long
    Dim d As String

    n = Err.Number
    d = Err.description

    On Error Resume Next
    Application.DisplayAlerts = True
    Application.StatusBar = oldStatus
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    MsgBox _
        "The ONGEN Step 17 label report could not be exported." & vbCrLf & vbCrLf & _
        "Error " & CStr(n) & ": " & d, _
        vbCritical, _
        "ONGEN Label List Export"
End Sub


'===============================================================================
' READ ME
'===============================================================================

Private Sub LABEL17_WriteReadMe(ByVal ws As Worksheet)
    ws.Cells.Clear

    ws.Range("A1:B1").Merge
    ws.Range("A1").Value2 = "ONGEN EAS - CABLE TAG RELEASE REPORT"

    ws.Range("A3").Value2 = "Generated"
    ws.Range("B3").value = Now
    ws.Range("B3").NumberFormat = "yyyy-mm-dd hh:mm:ss"

    '---------------------------------------------------------------------------
    ' Export Sheet Families
    '---------------------------------------------------------------------------
    ws.Range("A5").Value2 = "Export Sheet"
    ws.Range("B5").Value2 = "Families"

    ws.Range("A6").Value2 = "ALL LABELS"
    ws.Range("B6").Value2 = "WIO, WSF, WNET, WDC, WPWR, WMTR, MPWR"

    ws.Range("A7").Value2 = "IO LABELS"
    ws.Range("B7").Value2 = "WIO, WSF"

    ws.Range("A8").Value2 = "NETWORK LABELS"
    ws.Range("B8").Value2 = "WNET"

    ws.Range("A9").Value2 = "POWER LABELS"
    ws.Range("B9").Value2 = "WDC, WPWR, WMTR, MPWR"

    ws.Range("A10").Value2 = "DEVICE TAGS"
    ws.Range("B10").Value2 = "All equipment / device identifiers"

    '---------------------------------------------------------------------------
    ' Cable ID Families
    '---------------------------------------------------------------------------
    ws.Range("A13").Value2 = "Cable ID Families"
    ws.Range("B12").Value2 = "Description"

    ws.Range("A14").Value2 = "WIO"
    ws.Range("B14").Value2 = "Standard I/O"

    ws.Range("A15").Value2 = "WSF"
    ws.Range("B15").Value2 = "Safety I/O"

    ws.Range("A16").Value2 = "WNET"
    ws.Range("B16").Value2 = "Network"

    ws.Range("A17").Value2 = "WDC"
    ws.Range("B17").Value2 = "24Vdc"

    ws.Range("A18").Value2 = "WPWR"
    ws.Range("B18").Value2 = "480Vac / power"

    ws.Range("A19").Value2 = "WMTR"
    ws.Range("B19").Value2 = "Motor"

    ws.Range("A20").Value2 = "MPWR"
    ws.Range("B20").Value2 = "RCP power-group / outgoing power"

    With ws.Range("A1:B1")
        .Font.Bold = True
        .Font.Size = 16
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .HorizontalAlignment = xlCenter
    End With

    With ws.Range("A5:B5")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
    End With

    With ws.Range("A13:B13")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
    End With

    ws.Columns("A:B").AutoFit
    If ws.Columns("B").columnWidth > 46 Then ws.Columns("B").columnWidth = 46
    ws.Range("A1:B20").WrapText = True
End Sub


'===============================================================================
' NORMAL FAMILIES - CABLE_TAG_OUTPUT
'===============================================================================

Private Sub LABEL17_ExportCableOutput( _
    ByVal wsSource As Worksheet, _
    ByVal wsAll As Worksheet, _
    ByRef nextAll As Long, _
    ByVal wsIO As Worksheet, _
    ByRef nextIO As Long, _
    ByVal wsNetwork As Worksheet, _
    ByRef nextNetwork As Long, _
    ByVal wsPower As Worksheet, _
    ByRef nextPower As Long)

    Dim r As Long
    Dim lastRow As Long
    Dim labelID As String
    Dim family As String
    Dim rowData As Variant

    lastRow = LABEL17_LastRow(wsSource)

    For r = CABLE_FIRST_DATA_ROW To lastRow
        labelID = Trim$(CStr(wsSource.Cells(r, 1).Value2))
        family = LABEL17_TagFamily(labelID)

        'MPWR is intentionally skipped here. It is exported directly from
        'VFD DWG MPWR GROUPS to prevent stale/missing/duplicate MPWR behavior.
        If family <> "MPWR" Then
            If LABEL17_IsSupportedFamily(family) Then
                rowData = LABEL17_GetCableOutputRow(wsSource, r)

                LABEL17_WriteRow wsAll, nextAll, rowData
                nextAll = nextAll + 1

                If family = "WIO" Or family = "WSF" Then
                    LABEL17_WriteRow wsIO, nextIO, rowData
                    nextIO = nextIO + 1
                End If

                If family = "WNET" Then
                    LABEL17_WriteRow wsNetwork, nextNetwork, rowData
                    nextNetwork = nextNetwork + 1
                End If

                If family = "WDC" Or family = "WPWR" Or family = "WMTR" Then
                    LABEL17_WriteRow wsPower, nextPower, rowData
                    nextPower = nextPower + 1
                End If
            End If
        End If
    Next r
End Sub


Private Function LABEL17_GetCableOutputRow( _
    ByVal ws As Worksheet, _
    ByVal r As Long) As Variant

    Dim arr(1 To EXPORT_COL_COUNT) As Variant
    Dim c As Long

    'A:O -> 1:15
    For c = 1 To 15
        arr(c) = ws.Cells(r, c).Value2
    Next c

    'Status = source column Q / 17
    arr(16) = ws.Cells(r, 17).Value2

    'Quantity = source column S / 19
    arr(17) = ws.Cells(r, 19).Value2

    LABEL17_GetCableOutputRow = arr
End Function


'===============================================================================
' MPWR DIRECT EXPORT - CANONICAL MPWR SHEET
'===============================================================================

Private Sub LABEL17_ExportMPWRDirect( _
    ByVal wsMPWR As Worksheet, _
    ByVal wsAll As Worksheet, _
    ByRef nextAll As Long, _
    ByVal wsPower As Worksheet, _
    ByRef nextPower As Long)

    Dim hr As Long
    hr = LABEL17_FindHeaderRow(wsMPWR, "MPWR_LABEL_ID")

    If hr = 0 Then
        Err.Raise vbObjectError + 18301, _
                  "LABEL17_ExportMPWRDirect", _
                  "MPWR_LABEL_ID header was not found."
    End If

    Dim cBase As Long
    Dim cArea As Long
    Dim cPanel As Long
    Dim cSWG As Long
    Dim cSeq As Long
    Dim cStatus As Long
    Dim cDeviceTags As Long
    Dim cParent As Long

    cBase = LABEL17_FindHeader(wsMPWR, hr, Array("MPWR_LABEL_ID"))
    cArea = LABEL17_FindHeader(wsMPWR, hr, Array("AREA_NUMBER", "AREA NUMBER"))
    cPanel = LABEL17_FindHeader(wsMPWR, hr, Array("RCP_PANEL", "RCP PANEL"))
    cSWG = LABEL17_FindHeader(wsMPWR, hr, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cSeq = LABEL17_FindHeader(wsMPWR, hr, Array("SIS_SEQUENCE", "SIS SEQUENCE"))
    cStatus = LABEL17_FindHeader(wsMPWR, hr, Array("STATUS"))
    cDeviceTags = LABEL17_FindHeader(wsMPWR, hr, Array("DEVICE_CABLE_TAGS", "DEVICE CABLE TAGS"))
    cParent = LABEL17_FindHeader(wsMPWR, hr, Array("PARENT_CABLE_ID", "PARENT CABLE ID"))

    Dim r As Long
    Dim baseID As String
    Dim parentID As String
    Dim areaVal As String
    Dim panelVal As String
    Dim swgVal As String
    Dim statusVal As String
    Dim devices As Variant
    Dim childTags As Variant
    Dim deviceCount As Long
    Dim i As Long
    Dim rowData As Variant

    For r = hr + 1 To LABEL17_LastRow(wsMPWR)
        baseID = LABEL17_CellText(wsMPWR, r, cBase)
        areaVal = LABEL17_CellText(wsMPWR, r, cArea)
        panelVal = LABEL17_CellText(wsMPWR, r, cPanel)
        swgVal = LABEL17_NormalizeSWG(LABEL17_CellText(wsMPWR, r, cSWG))
        statusVal = UCase$(LABEL17_CellText(wsMPWR, r, cStatus))

        If Left$(UCase$(baseID), 5) = "MPWR-" And _
           Len(panelVal) > 0 And _
           Len(swgVal) > 0 And _
           InStr(1, statusVal, "SPARE", vbTextCompare) = 0 Then

            parentID = LABEL17_CellText(wsMPWR, r, cParent)
            If Len(parentID) = 0 Then parentID = baseID

            devices = LABEL17_SplitNonBlank( _
                LABEL17_CellText(wsMPWR, r, cSeq))

            childTags = LABEL17_SplitNonBlank( _
                LABEL17_CellText(wsMPWR, r, cDeviceTags))

            deviceCount = LABEL17_ArrayCount(devices)

            If LABEL17_ArrayCount(childTags) <> deviceCount Then
                childTags = LABEL17_BuildChildTags(parentID, deviceCount)
            End If

            'Parent row
            rowData = LABEL17_MPWRParentRow( _
                parentID, areaVal, panelVal, swgVal)

            LABEL17_WriteRow wsAll, nextAll, rowData
            nextAll = nextAll + 1

            LABEL17_WriteRow wsPower, nextPower, rowData
            nextPower = nextPower + 1

            'Child rows
            For i = 0 To deviceCount - 1
                rowData = LABEL17_MPWRChildRow( _
                    CStr(childTags(LBound(childTags) + i)), _
                    parentID, _
                    CStr(devices(LBound(devices) + i)), _
                    areaVal, _
                    panelVal, _
                    swgVal)

                LABEL17_WriteRow wsAll, nextAll, rowData
                nextAll = nextAll + 1

                LABEL17_WriteRow wsPower, nextPower, rowData
                nextPower = nextPower + 1
            Next i
        End If
    Next r
End Sub


Private Function LABEL17_MPWRParentRow( _
    ByVal parentID As String, _
    ByVal areaVal As String, _
    ByVal panelVal As String, _
    ByVal swgVal As String) As Variant

    Dim arr(1 To EXPORT_COL_COUNT) As Variant

    arr(1) = parentID
    arr(2) = "RCP POWER GROUP PARENT CABLE"
    arr(3) = "MPWR"
    arr(4) = panelVal
    arr(5) = areaVal
    arr(6) = panelVal
    arr(7) = swgVal
    arr(8) = panelVal & " PWG" & swgVal
    arr(9) = vbNullString
    arr(10) = "480V POWER GROUP TRUNK"
    arr(11) = vbNullString
    arr(12) = "MPWR PARENT"
    arr(13) = "PWG" & swgVal
    arr(14) = vbNullString
    arr(15) = "RCP power-group / outgoing power parent cable"
    arr(16) = "OK - MPWR PARENT CABLE"
    arr(17) = 1

    LABEL17_MPWRParentRow = arr
End Function


Private Function LABEL17_MPWRChildRow( _
    ByVal childID As String, _
    ByVal parentID As String, _
    ByVal deviceName As String, _
    ByVal areaVal As String, _
    ByVal panelVal As String, _
    ByVal swgVal As String) As Variant

    Dim arr(1 To EXPORT_COL_COUNT) As Variant

    arr(1) = childID
    arr(2) = "RCP POWER GROUP CHILD CABLE"
    arr(3) = "MPWR"
    arr(4) = panelVal
    arr(5) = areaVal
    arr(6) = panelVal
    arr(7) = swgVal
    arr(8) = parentID
    arr(9) = vbNullString
    arr(10) = deviceName
    arr(11) = vbNullString
    arr(12) = "MPWR CHILD"
    arr(13) = "PWG" & swgVal
    arr(14) = vbNullString
    arr(15) = "Outgoing 480V branch from parent " & parentID
    arr(16) = "OK - MPWR CHILD CABLE"
    arr(17) = 1

    LABEL17_MPWRChildRow = arr
End Function


Private Sub LABEL17_CountMPWR( _
    ByVal wsMPWR As Worksheet, _
    ByRef parentCount As Long, _
    ByRef childCount As Long)

    parentCount = 0
    childCount = 0

    Dim hr As Long
    hr = LABEL17_FindHeaderRow(wsMPWR, "MPWR_LABEL_ID")
    If hr = 0 Then Exit Sub

    Dim cBase As Long
    Dim cPanel As Long
    Dim cSWG As Long
    Dim cStatus As Long
    Dim cSeq As Long

    cBase = LABEL17_FindHeader(wsMPWR, hr, Array("MPWR_LABEL_ID"))
    cPanel = LABEL17_FindHeader(wsMPWR, hr, Array("RCP_PANEL", "RCP PANEL"))
    cSWG = LABEL17_FindHeader(wsMPWR, hr, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cStatus = LABEL17_FindHeader(wsMPWR, hr, Array("STATUS"))
    cSeq = LABEL17_FindHeader(wsMPWR, hr, Array("SIS_SEQUENCE", "SIS SEQUENCE"))

    Dim r As Long
    Dim baseID As String
    Dim panelVal As String
    Dim swgVal As String
    Dim statusVal As String
    Dim devices As Variant

    For r = hr + 1 To LABEL17_LastRow(wsMPWR)
        baseID = LABEL17_CellText(wsMPWR, r, cBase)
        panelVal = LABEL17_CellText(wsMPWR, r, cPanel)
        swgVal = LABEL17_NormalizeSWG(LABEL17_CellText(wsMPWR, r, cSWG))
        statusVal = UCase$(LABEL17_CellText(wsMPWR, r, cStatus))

        If Left$(UCase$(baseID), 5) = "MPWR-" And _
           Len(panelVal) > 0 And _
           Len(swgVal) > 0 And _
           InStr(1, statusVal, "SPARE", vbTextCompare) = 0 Then

            parentCount = parentCount + 1

            devices = LABEL17_SplitNonBlank( _
                LABEL17_CellText(wsMPWR, r, cSeq))

            childCount = childCount + LABEL17_ArrayCount(devices)
        End If
    Next r
End Sub



'===============================================================================
' DEVICE TAG EXPORT
'===============================================================================

Private Sub LABEL17_ExportDeviceTags(ByVal wsOut As Worksheet)
    '---------------------------------------------------------------------------
    ' Purpose:
    '   Build one consolidated device-label schedule for Step 17.
    '
    ' Governing label rule:
    '   Normal device types:
    '       Control ID 11-102-1005-K1 -> Device Label 1005-K1
    '
    '   MC / VFD / MOT device types:
    '       Control ID 11-102-1005-K1 -> Device Label 11-102-1005-K1
    '
    ' Exported columns:
    '   Device Label
    '   Device Type
    '   Control ID
    '   Panel
    '   Area
    '   SwitchGroup
    '   Related Device / Function
    '
    ' Duplicate policy:
    '   Full Control ID is the preferred unique key. This prevents two devices
    '   in different Areas/SwitchGroups from merging merely because their short
    '   Device Labels are identical.
    '---------------------------------------------------------------------------
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    LABEL17_CollectDevicesFromPD6 dict
    LABEL17_CollectDevicesFromIO dict
    LABEL17_CollectDevicesFromVFDQueue dict
    LABEL17_CollectDevicesFromPlacement dict

    LABEL17_WriteDeviceHeaders wsOut

    Dim keys As Variant
    Dim i As Long
    Dim rowData As Variant
    Dim outRow As Long

    If dict.count > 0 Then
        keys = dict.keys
        outRow = 2

        For i = LBound(keys) To UBound(keys)
            rowData = dict(keys(i))
            LABEL17_WriteDeviceRow wsOut, outRow, rowData
            outRow = outRow + 1
        Next i
    End If

    LABEL17_SortDeviceTags wsOut
End Sub


Private Sub LABEL17_CollectDevicesFromPD6(ByVal dict As Object)
    'PD6_IMPORT is the primary device schedule because it contains the complete
    'Control_ID together with TYPE, PNL, AREA_Number and SwitchGroup.
    Dim ws As Worksheet
    Set ws = LABEL17_GetSheet(PD6_SHEET)
    If ws Is Nothing Then Exit Sub

    Dim hr As Long
    hr = LABEL17_FindHeaderRow(ws, "SIS_SEQUENCE")
    If hr = 0 Then Exit Sub

    Dim cSeq As Long
    Dim cType As Long
    Dim cControl As Long
    Dim cPanel As Long
    Dim cArea As Long
    Dim cSWG As Long
    Dim cConveyor As Long
    Dim cSystem As Long

    cSeq = LABEL17_FindHeader(ws, hr, Array("SIS_SEQUENCE", "SIS SEQUENCE"))
    cType = LABEL17_FindHeader(ws, hr, Array("TYPE", "DEVICE TYPE"))
    cControl = LABEL17_FindHeader(ws, hr, Array("CONTROL_ID", "CONTROL ID"))
    cPanel = LABEL17_FindHeader(ws, hr, Array("PNL", "PANEL"))
    cArea = LABEL17_FindHeader(ws, hr, Array("AREA_NUMBER", "AREA NUMBER"))
    cSWG = LABEL17_FindHeader(ws, hr, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cConveyor = LABEL17_FindHeader(ws, hr, Array("CONVEYOR TYPE"))
    cSystem = LABEL17_FindHeader(ws, hr, Array("SYSTEM TYPE"))

    Dim r As Long
    Dim sourceTag As String
    Dim controlID As String
    Dim deviceType As String
    Dim areaVal As String
    Dim swgVal As String
    Dim detailVal As String
    Dim rec As Variant

    For r = hr + 1 To LABEL17_LastRow(ws)
        sourceTag = LABEL17_CellText(ws, r, cSeq)
        controlID = LABEL17_CellText(ws, r, cControl)
        deviceType = LABEL17_CellText(ws, r, cType)
        areaVal = LABEL17_CellText(ws, r, cArea)
        swgVal = LABEL17_NormalizeSWG(LABEL17_CellText(ws, r, cSWG))

        If Len(controlID) > 0 Or Len(sourceTag) > 0 Then
            detailVal = LABEL17_CellText(ws, r, cConveyor)
            If Len(detailVal) = 0 Then
                detailVal = LABEL17_CellText(ws, r, cSystem)
            End If

            rec = LABEL17_NewDeviceRecord( _
                sourceTag, _
                deviceType, _
                controlID, _
                LABEL17_CellText(ws, r, cPanel), _
                areaVal, _
                swgVal, _
                detailVal)

            LABEL17_AddOrMergeDevice dict, rec
        End If
    Next r
End Sub


Private Sub LABEL17_CollectDevicesFromIO(ByVal dict As Object)
    'IO_DEVICE_LIST supplements devices that may not have a PD6 Control ID.
    'When Control ID is unavailable, the existing Device value is retained as
    'the fallback identifier and is shortened only when it follows the same
    'Area-SwitchGroup-Control pattern.
    Dim ws As Worksheet
    Set ws = LABEL17_GetSheet(IO_DEVICE_SHEET)
    If ws Is Nothing Then Exit Sub

    Dim hr As Long
    hr = LABEL17_FindHeaderRow(ws, "DEVICE")
    If hr = 0 Then Exit Sub

    Dim cDevice As Long
    Dim cType As Long
    Dim cBlock As Long
    Dim cPanel As Long
    Dim cArea As Long
    Dim cSWG As Long
    Dim cControl As Long

    cDevice = LABEL17_FindHeader(ws, hr, Array("DEVICE", "DEVICE NAME"))
    cType = LABEL17_FindHeader(ws, hr, Array("DEVICE TYPE"))
    cBlock = LABEL17_FindHeader(ws, hr, Array("BLOCK ID", "IO BLOCK"))
    cPanel = LABEL17_FindHeader(ws, hr, Array("PANEL", "PNL"))
    cArea = LABEL17_FindHeader(ws, hr, Array("LOCATION", "AREA", "AREA NUMBER"))
    cSWG = LABEL17_FindHeader(ws, hr, Array("PWG", "SWITCHGROUP", "SWITCH GROUP"))
    cControl = LABEL17_FindHeader(ws, hr, Array("CONTROL_ID", "CONTROL ID"))

    Dim r As Long
    Dim sourceTag As String
    Dim rec As Variant

    For r = hr + 1 To LABEL17_LastRow(ws)
        sourceTag = LABEL17_CellText(ws, r, cDevice)

        If Len(sourceTag) > 0 Then
            rec = LABEL17_NewDeviceRecord( _
                sourceTag, _
                LABEL17_CellText(ws, r, cType), _
                LABEL17_CellText(ws, r, cControl), _
                LABEL17_CellText(ws, r, cPanel), _
                LABEL17_CellText(ws, r, cArea), _
                LABEL17_NormalizeSWG(LABEL17_CellText(ws, r, cSWG)), _
                LABEL17_CellText(ws, r, cBlock))

            LABEL17_AddOrMergeDevice dict, rec
        End If
    Next r
End Sub


Private Sub LABEL17_CollectDevicesFromVFDQueue(ByVal dict As Object)
    'VFD queue rows are used to enrich/retain generated 480V devices.
    Dim ws As Worksheet
    Set ws = LABEL17_GetSheet(VFD_QUEUE_SHEET)
    If ws Is Nothing Then Exit Sub

    Dim hr As Long
    hr = LABEL17_FindHeaderRow(ws, "SIS_SEQUENCE")
    If hr = 0 Then Exit Sub

    Dim cEnabled As Long
    Dim cSeq As Long
    Dim cType As Long
    Dim cControl As Long
    Dim cPanel As Long
    Dim cArea As Long
    Dim cSWG As Long
    Dim cBlock As Long

    cEnabled = LABEL17_FindHeader(ws, hr, Array("ENABLED"))
    cSeq = LABEL17_FindHeader(ws, hr, Array("SIS_SEQUENCE", "SIS SEQUENCE"))
    cType = LABEL17_FindHeader(ws, hr, Array("TYPE", "DEVICE TYPE"))
    cControl = LABEL17_FindHeader(ws, hr, Array("CONTROL_ID", "CONTROL ID"))
    cPanel = LABEL17_FindHeader(ws, hr, Array("PANEL", "PNL"))
    cArea = LABEL17_FindHeader(ws, hr, Array("AREA_NUMBER", "AREA NUMBER"))
    cSWG = LABEL17_FindHeader(ws, hr, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cBlock = LABEL17_FindHeader(ws, hr, Array("BLOCK"))

    Dim r As Long
    Dim sourceTag As String
    Dim controlID As String
    Dim rec As Variant
    Dim enabledVal As String

    For r = hr + 1 To LABEL17_LastRow(ws)
        enabledVal = UCase$(LABEL17_CellText(ws, r, cEnabled))

        If cEnabled = 0 Or enabledVal = "YES" Or enabledVal = "TRUE" Or enabledVal = "1" Then
            sourceTag = LABEL17_CellText(ws, r, cSeq)
            controlID = LABEL17_CellText(ws, r, cControl)

            'For generated MC/VFD/MOT rows, SIS_SEQUENCE is a valid fallback
            'full identifier when the queue does not expose Control_ID.
            If Len(controlID) = 0 Then controlID = sourceTag

            If Len(controlID) > 0 Or Len(sourceTag) > 0 Then
                rec = LABEL17_NewDeviceRecord( _
                    sourceTag, _
                    LABEL17_CellText(ws, r, cType), _
                    controlID, _
                    LABEL17_CellText(ws, r, cPanel), _
                    LABEL17_CellText(ws, r, cArea), _
                    LABEL17_NormalizeSWG(LABEL17_CellText(ws, r, cSWG)), _
                    LABEL17_CellText(ws, r, cBlock))

                LABEL17_AddOrMergeDevice dict, rec
            End If
        End If
    Next r
End Sub


Private Sub LABEL17_CollectDevicesFromPlacement(ByVal dict As Object)
    'Enabled device-placement records can add library devices that do not have
    'their own PD6 row.
    Dim ws As Worksheet
    Set ws = LABEL17_GetSheet(DEVICE_PLACEMENT_SHEET)
    If ws Is Nothing Then Exit Sub

    Dim hr As Long
    hr = LABEL17_FindHeaderRow(ws, "DEVICE_TAG")
    If hr = 0 Then Exit Sub

    Dim cEnabled As Long
    Dim cTag As Long
    Dim cInstance As Long
    Dim cType As Long
    Dim cControl As Long
    Dim cPanel As Long
    Dim cArea As Long
    Dim cSWG As Long
    Dim cFunction As Long

    cEnabled = LABEL17_FindHeader(ws, hr, Array("ENABLED"))
    cTag = LABEL17_FindHeader(ws, hr, Array("DEVICE_TAG", "DEVICE TAG"))
    cInstance = LABEL17_FindHeader(ws, hr, Array("DEVICE_INSTANCE", "DEVICE INSTANCE"))
    cType = LABEL17_FindHeader(ws, hr, Array("DEVICE_TYPE", "DEVICE TYPE"))
    cControl = LABEL17_FindHeader(ws, hr, Array("CONTROL_ID", "CONTROL ID"))
    cPanel = LABEL17_FindHeader(ws, hr, Array("PANEL", "PNL"))
    cArea = LABEL17_FindHeader(ws, hr, Array("AREA_NUMBER", "AREA NUMBER", "AREA"))
    cSWG = LABEL17_FindHeader(ws, hr, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    cFunction = LABEL17_FindHeader(ws, hr, Array("FUNCTION_TEXT", "FUNCTION TEXT"))

    Dim r As Long
    Dim sourceTag As String
    Dim enabledVal As String
    Dim rec As Variant

    For r = hr + 1 To LABEL17_LastRow(ws)
        enabledVal = UCase$(LABEL17_CellText(ws, r, cEnabled))

        If cEnabled = 0 Or enabledVal = "YES" Or enabledVal = "TRUE" Or enabledVal = "1" Then
            sourceTag = LABEL17_CellText(ws, r, cTag)

            If Len(sourceTag) = 0 Then
                sourceTag = LABEL17_CellText(ws, r, cInstance)
            End If

            If Len(sourceTag) > 0 Then
                rec = LABEL17_NewDeviceRecord( _
                    sourceTag, _
                    LABEL17_CellText(ws, r, cType), _
                    LABEL17_CellText(ws, r, cControl), _
                    LABEL17_CellText(ws, r, cPanel), _
                    LABEL17_CellText(ws, r, cArea), _
                    LABEL17_NormalizeSWG(LABEL17_CellText(ws, r, cSWG)), _
                    LABEL17_CellText(ws, r, cFunction))

                LABEL17_AddOrMergeDevice dict, rec
            End If
        End If
    Next r
End Sub


Private Function LABEL17_NewDeviceRecord( _
    ByVal sourceTag As String, _
    ByVal deviceType As String, _
    ByVal controlID As String, _
    ByVal panel As String, _
    ByVal areaVal As String, _
    ByVal switchGroup As String, _
    ByVal relatedInfo As String) As Variant

    Dim arr(1 To 7) As Variant
    Dim deviceLabel As String

    deviceLabel = LABEL17_DeviceLabelFromControlID( _
        controlID, _
        deviceType, _
        areaVal, _
        switchGroup, _
        sourceTag)

    arr(1) = deviceLabel
    arr(2) = Trim$(deviceType)
    arr(3) = Trim$(controlID)
    arr(4) = Trim$(panel)
    arr(5) = Trim$(areaVal)
    arr(6) = Trim$(switchGroup)
    arr(7) = Trim$(relatedInfo)

    LABEL17_NewDeviceRecord = arr
End Function


Private Function LABEL17_DeviceLabelFromControlID( _
    ByVal controlID As String, _
    ByVal deviceType As String, _
    ByVal areaVal As String, _
    ByVal switchGroup As String, _
    ByVal fallbackTag As String) As String

    '---------------------------------------------------------------------------
    ' Device label rule requested for the release schedule.
    '
    ' Example normal device:
    '   Control ID = 11-102-1005-K1
    '   Device Label = 1005-K1
    '
    ' Example MC/VFD/MOT:
    '   Control ID = 11-102-1005-K1
    '   Device Label = 11-102-1005-K1
    '---------------------------------------------------------------------------
    Dim rawID As String
    rawID = Trim$(controlID)

    If Len(rawID) = 0 Then rawID = Trim$(fallbackTag)
    If Len(rawID) = 0 Then Exit Function

    If LABEL17_KeepFullControlID(deviceType) Then
        LABEL17_DeviceLabelFromControlID = rawID
        Exit Function
    End If

    Dim prefix As String
    prefix = Trim$(areaVal) & "-" & Trim$(switchGroup) & "-"

    'Preferred method: remove the exact known Area + SwitchGroup prefix.
    If Len(Trim$(areaVal)) > 0 And Len(Trim$(switchGroup)) > 0 Then
        If Left$(rawID, Len(prefix)) = prefix Then
            LABEL17_DeviceLabelFromControlID = mid$(rawID, Len(prefix) + 1)
            Exit Function
        End If
    End If

    'Fallback for well-formed Control IDs where Area/SwitchGroup metadata may
    'be blank: remove the first two hyphen-separated components.
    Dim parts As Variant
    parts = Split(rawID, "-")

    If UBound(parts) >= 2 Then
        Dim i As Long
        Dim shortID As String

        For i = 2 To UBound(parts)
            If Len(shortID) > 0 Then shortID = shortID & "-"
            shortID = shortID & CStr(parts(i))
        Next i

        LABEL17_DeviceLabelFromControlID = shortID
    Else
        LABEL17_DeviceLabelFromControlID = rawID
    End If
End Function


Private Function LABEL17_KeepFullControlID(ByVal deviceType As String) As Boolean
    Select Case UCase$(Trim$(deviceType))
        Case "MC", "VFD", "MOT"
            LABEL17_KeepFullControlID = True
    End Select
End Function


Private Sub LABEL17_AddOrMergeDevice( _
    ByVal dict As Object, _
    ByVal incoming As Variant)

    'Prefer the complete Control ID as the unique key. When Control ID is not
    'available, use Device Label as the fallback key.
    Dim key As String

    key = UCase$(Trim$(CStr(incoming(3))))
    If Len(key) = 0 Then key = UCase$(Trim$(CStr(incoming(1))))

    If Len(key) = 0 Then Exit Sub

    If Not dict.Exists(key) Then
        dict.Add key, incoming
        Exit Sub
    End If

    Dim existing As Variant
    Dim i As Long

    existing = dict(key)

    For i = 1 To 7
        If Len(Trim$(CStr(existing(i)))) = 0 And _
           Len(Trim$(CStr(incoming(i)))) > 0 Then

            existing(i) = incoming(i)
        End If
    Next i

    'Recalculate Device Label after metadata enrichment because Area,
    'SwitchGroup or Device Type may have been supplied by a later source.
    existing(1) = LABEL17_DeviceLabelFromControlID( _
        CStr(existing(3)), _
        CStr(existing(2)), _
        CStr(existing(5)), _
        CStr(existing(6)), _
        CStr(existing(1)))

    dict(key) = existing
End Sub


Private Sub LABEL17_WriteDeviceHeaders(ByVal ws As Worksheet)
    ws.Cells(1, 1).Value2 = "Device Label"
    ws.Cells(1, 2).Value2 = "Device Type"
    ws.Cells(1, 3).Value2 = "Control ID"
    ws.Cells(1, 4).Value2 = "Panel"
    ws.Cells(1, 5).Value2 = "Area"
    ws.Cells(1, 6).Value2 = "SwitchGroup"
    ws.Cells(1, 7).Value2 = "Related Device / Function"
End Sub


Private Sub LABEL17_WriteDeviceRow( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal rowData As Variant)

    Dim c As Long

    For c = 1 To 7
        ws.Cells(r, c).Value2 = rowData(c)
    Next c
End Sub


Private Sub LABEL17_SortDeviceTags(ByVal ws As Worksheet)
    Dim lastRow As Long
    lastRow = LABEL17_LastRow(ws)

    If lastRow <= 2 Then Exit Sub

    With ws.Sort
        .SortFields.Clear
        .SortFields.Add _
            key:=ws.Range("A2:A" & lastRow), _
            SortOn:=xlSortOnValues, _
            Order:=xlAscending, _
            DataOption:=xlSortNormal

        .SetRange ws.Range("A1:G" & lastRow)
        .header = xlYes
        .MatchCase = False
        .Orientation = xlTopToBottom
        .Apply
    End With
End Sub


Private Sub LABEL17_FormatDeviceSheet(ByVal ws As Worksheet)
    With ws.Range("A1:G1")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .WrapText = True
    End With

    ws.Range("A1:G1").AutoFilter
    ws.Columns("A:G").AutoFit

    Dim c As Long

    For c = 1 To 7
        If ws.Columns(c).columnWidth > 38 Then
            ws.Columns(c).columnWidth = 38
        End If
    Next c

    ws.UsedRange.WrapText = True

    ws.Activate
    ActiveWindow.FreezePanes = False
    ActiveWindow.SplitRow = 1
    ActiveWindow.SplitColumn = 0
    ActiveWindow.FreezePanes = True
End Sub


'===============================================================================
' COMMON EXPORT HELPERS
'===============================================================================

Private Sub LABEL17_WriteHeaders(ByVal ws As Worksheet)
    Dim headers As Variant

    headers = Array( _
        "Label ID", _
        "Category", _
        "Type Code", _
        "Package", _
        "Area", _
        "Panel", _
        "SwitchGroup", _
        "From", _
        "From Terminal", _
        "To", _
        "To Terminal", _
        "Device / Route Type", _
        "Port / Bus", _
        "Load / Length", _
        "Description", _
        "Status", _
        "Quantity")

    Dim c As Long

    For c = LBound(headers) To UBound(headers)
        ws.Cells(1, c + 1).Value2 = headers(c)
    Next c
End Sub


Private Sub LABEL17_WriteRow( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal rowData As Variant)

    Dim c As Long

    For c = 1 To EXPORT_COL_COUNT
        ws.Cells(r, c).Value2 = rowData(c)
    Next c
End Sub


Private Function LABEL17_IsSupportedFamily(ByVal family As String) As Boolean
    Select Case UCase$(family)
        Case "WIO", "WSF", "WNET", "WDC", "WPWR", "WMTR"
            LABEL17_IsSupportedFamily = True
    End Select
End Function


Private Function LABEL17_TagFamily(ByVal labelID As String) As String
    Dim s As String
    s = UCase$(Trim$(labelID))

    If Left$(s, 5) = "WNET-" Then
        LABEL17_TagFamily = "WNET"
    ElseIf Left$(s, 5) = "WPWR-" Then
        LABEL17_TagFamily = "WPWR"
    ElseIf Left$(s, 5) = "WMTR-" Then
        LABEL17_TagFamily = "WMTR"
    ElseIf Left$(s, 5) = "MPWR-" Then
        LABEL17_TagFamily = "MPWR"
    ElseIf Left$(s, 4) = "WIO-" Then
        LABEL17_TagFamily = "WIO"
    ElseIf Left$(s, 4) = "WSF-" Then
        LABEL17_TagFamily = "WSF"
    ElseIf Left$(s, 4) = "WDC-" Then
        LABEL17_TagFamily = "WDC"
    End If
End Function


Private Function LABEL17_CountExportFamily( _
    ByVal ws As Worksheet, _
    ByVal familyName As String) As Long

    Dim r As Long
    Dim lastRow As Long

    lastRow = LABEL17_LastRow(ws)

    For r = 2 To lastRow
        If StrComp( _
            LABEL17_TagFamily(CStr(ws.Cells(r, 1).Value2)), _
            familyName, _
            vbTextCompare) = 0 Then

            LABEL17_CountExportFamily = _
                LABEL17_CountExportFamily + 1
        End If
    Next r
End Function


Private Sub LABEL17_FormatSheet(ByVal ws As Worksheet)
    With ws.Range("A1:Q1")
        .Font.Bold = True
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .WrapText = True
    End With

    ws.Range("A1:Q1").AutoFilter
    ws.Columns("A:Q").AutoFit

    Dim c As Long
    For c = 1 To EXPORT_COL_COUNT
        If ws.Columns(c).columnWidth > 36 Then
            ws.Columns(c).columnWidth = 36
        End If
    Next c

    ws.UsedRange.WrapText = True

    ws.Activate
    ActiveWindow.FreezePanes = False
    ActiveWindow.SplitRow = 1
    ActiveWindow.SplitColumn = 0
    ActiveWindow.FreezePanes = True
End Sub


'===============================================================================
' WORKBOOK UTILITIES
'===============================================================================

Private Sub LABEL17_ValidateCableSheet(ByVal ws As Worksheet)
    If StrComp(Trim$(CStr(ws.Cells(CABLE_HEADER_ROW, 1).Value2)), _
               "Label ID", vbTextCompare) <> 0 Then

        Err.Raise vbObjectError + 18401, _
                  "LABEL17_ValidateCableSheet", _
                  "CABLE_TAG_OUTPUT does not contain the expected row-6 headers."
    End If
End Sub


Private Function LABEL17_GetSavePath() As Variant
    Dim defaultName As String

    defaultName = _
        "ONGEN Cable Tag Release " & _
        Format$(Now, "yyyymmdd_hhnnss") & ".xlsx"

    LABEL17_GetSavePath = Application.GetSaveAsFilename( _
        InitialFileName:=defaultName, _
        FileFilter:="Excel Workbook (*.xlsx), *.xlsx", _
        title:="Save ONGEN Step 17 Label Report")
End Function


Private Function LABEL17_TryRun(ByVal macroName As String) As Boolean
    On Error GoTo Failed

    Application.Run "'" & ThisWorkbook.Name & "'!" & macroName
    LABEL17_TryRun = True
    Exit Function

Failed:
    Err.Clear
    LABEL17_TryRun = False
End Function


Private Function LABEL17_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set LABEL17_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function


Private Function LABEL17_LastRow(ByVal ws As Worksheet) As Long
    On Error GoTo SafeExit

    Dim f As Range

    Set f = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    If Not f Is Nothing Then LABEL17_LastRow = f.Row
    Exit Function

SafeExit:
    LABEL17_LastRow = 0
End Function


Private Function LABEL17_FindHeaderRow( _
    ByVal ws As Worksheet, _
    ByVal requiredHeader As String) As Long

    Dim maxRow As Long
    maxRow = Application.Min(20, Application.Max(1, ws.UsedRange.rows.count))

    Dim r As Long

    For r = 1 To maxRow
        If LABEL17_FindHeader(ws, r, Array(requiredHeader)) > 0 Then
            LABEL17_FindHeaderRow = r
            Exit Function
        End If
    Next r
End Function


Private Function LABEL17_FindHeader( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal aliases As Variant) As Long

    If headerRow <= 0 Then Exit Function

    Dim lastCol As Long
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column

    Dim c As Long
    Dim a As Variant
    Dim cellKey As String

    For c = 1 To lastCol
        cellKey = LABEL17_HeaderKey(ws.Cells(headerRow, c).Value2)

        For Each a In aliases
            If cellKey = LABEL17_HeaderKey(CStr(a)) Then
                LABEL17_FindHeader = c
                Exit Function
            End If
        Next a
    Next c
End Function


Private Function LABEL17_HeaderKey(ByVal value As Variant) As String
    Dim s As String

    s = UCase$(Trim$(CStr(value)))

    s = Replace$(s, "_", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "-", "")
    s = Replace$(s, "/", "")
    s = Replace$(s, ".", "")
    s = Replace$(s, "(", "")
    s = Replace$(s, ")", "")

    LABEL17_HeaderKey = s
End Function


Private Function LABEL17_CellText( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal c As Long) As String

    If c <= 0 Then Exit Function
    If IsError(ws.Cells(r, c).Value2) Then Exit Function

    LABEL17_CellText = Trim$(CStr(ws.Cells(r, c).Value2))
End Function


Private Function LABEL17_NormalizeSWG(ByVal value As String) As String
    Dim s As String
    s = UCase$(Trim$(value))

    If Left$(s, 3) = "PWG" Then s = mid$(s, 4)
    If Left$(s, 3) = "SWG" Then s = mid$(s, 4)

    LABEL17_NormalizeSWG = Trim$(s)
End Function


Private Function LABEL17_SplitNonBlank(ByVal value As String) As Variant
    Dim coll As Collection
    Set coll = New Collection

    Dim p As Variant

    For Each p In Split(value, "|")
        If Len(Trim$(CStr(p))) > 0 Then
            coll.Add Trim$(CStr(p))
        End If
    Next p

    If coll.count = 0 Then
        LABEL17_SplitNonBlank = Array()
        Exit Function
    End If

    Dim arr() As String
    Dim i As Long

    ReDim arr(0 To coll.count - 1)

    For i = 1 To coll.count
        arr(i - 1) = CStr(coll(i))
    Next i

    LABEL17_SplitNonBlank = arr
End Function


Private Function LABEL17_ArrayCount(ByVal arr As Variant) As Long
    On Error GoTo EmptyArray

    LABEL17_ArrayCount = UBound(arr) - LBound(arr) + 1
    Exit Function

EmptyArray:
    LABEL17_ArrayCount = 0
End Function


Private Function LABEL17_BuildChildTags( _
    ByVal parentID As String, _
    ByVal count As Long) As Variant

    If count <= 0 Then
        LABEL17_BuildChildTags = Array()
        Exit Function
    End If

    Dim arr() As String
    Dim i As Long

    ReDim arr(0 To count - 1)

    For i = 0 To count - 1
        arr(i) = parentID & "." & CStr(i + 1)
    Next i

    LABEL17_BuildChildTags = arr
End Function
