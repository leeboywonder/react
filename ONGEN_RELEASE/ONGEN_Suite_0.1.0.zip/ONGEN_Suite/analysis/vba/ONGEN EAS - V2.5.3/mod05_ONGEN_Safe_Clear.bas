Attribute VB_Name = "mod05_ONGEN_Safe_Clear"
Option Explicit

'===============================================================================
' ONGEN EAS - SAFE GENERATED DATA CLEAR
'
' MAIN COMMAND
'   ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE
'
' CURRENT REQUIREMENTS
'   - Clears generated/audit data but preserves workbook configuration.
'   - Clears:
'       24V_OVERLOAD_TERMINALS
'       24V_NOT_GENERATED
'       STEP10A_SYNC_AUDIT
'       VFD_FUNCTION_ASSIGNMENT
'   - Deletes:
'       24v_Power Generator
'       generated panel/Clean/24V sheets
'   - Does NOT delete source/configuration/library sheets.
'===============================================================================

Private Const STRUCTURE_KEY As String = "ONGEN-STRUCTURE-2026"

Public Sub ONGEN_STEP18_CLEAR_GENERATED_DATA_SAFE()
    Dim answer As VbMsgBoxResult

    answer = MsgBox( _
        "This will clear generated ONGEN project data and delete generated sheets." & vbCrLf & vbCrLf & _
        "It will also:" & vbCrLf & _
        "  - clear 24V_OVERLOAD_TERMINALS" & vbCrLf & _
        "  - clear 24V_NOT_GENERATED" & vbCrLf & _
        "  - clear STEP10A_SYNC_AUDIT" & vbCrLf & _
        "  - clear VFD_FUNCTION_ASSIGNMENT" & vbCrLf & _
        "  - delete 24v_Power Generator" & vbCrLf & _
        "  - delete generated RCP/Clean/24V sheets" & vbCrLf & vbCrLf & _
        "Source, configuration, and library sheets are preserved." & vbCrLf & vbCrLf & _
        "Continue?", _
        vbYesNo + vbQuestion + vbDefaultButton2, _
        "ONGEN Safe Clear")

    If answer <> vbYes Then Exit Sub

    On Error GoTo EH

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.EnableEvents = False

    On Error Resume Next
    ThisWorkbook.Unprotect Password:=STRUCTURE_KEY
    On Error GoTo EH

    '---------------------------------------------------------------------------
    ' Delete generated worksheets.
    '---------------------------------------------------------------------------
    ONGEN_DeleteSheetIfExists "24v_Power Generator"
    ONGEN_DeleteGeneratedDynamicSheets

    '---------------------------------------------------------------------------
    ' Clear current generated reports/audits requested by engineering.
    '---------------------------------------------------------------------------
    ONGEN_Clear_24V_Overload_Terminals
    ONGEN_Clear_24V_Not_Generated
    ONGEN_Clear_Step10A_Sync_Audit
    ONGEN_Clear_VFD_Function_Assignment

    '---------------------------------------------------------------------------
    ' Existing generated-output resets.
    '---------------------------------------------------------------------------
    ONGEN_ClearBelowHeader "CABLE_TAG_OUTPUT", 6
    ONGEN_ClearBelowHeader "CABLE_ID_REGISTRY", 1
    ONGEN_ClearBelowHeader "VFD DWG MPWR GROUPS", 1
    ONGEN_ClearBelowHeader "VFD DWG PANEL CABLE REPORT", 1
    ONGEN_ClearBelowHeader "VFD_DWG_PANEL_CABLE_REPORT", 1
    ONGEN_ClearBelowHeader "VFD_DWG_QUEUE", 1
    ONGEN_ClearBelowHeader "VFD_480V_Generator", 1
    ONGEN_ClearBelowHeader "VFD_NETWORK_BACKFILL_AUDIT", 1
    ONGEN_ClearBelowHeader "IO_BLOCK_GENERATOR", 1
    ONGEN_ClearBelowHeader "PROCESS_LOG", 1
    ONGEN_ClearBelowHeader "EXPORT_LOG", 1
    ONGEN_ClearBelowHeader "VALIDATION", 1

    'Return workbook to User Mode if security module is installed.
    On Error Resume Next
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_USER_MODE", False
    If Err.Number <> 0 Then
        Err.Clear
        ThisWorkbook.Protect Password:=STRUCTURE_KEY, Structure:=True, Windows:=False
    End If
    On Error GoTo EH

    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "ONGEN generated data was cleared successfully.", _
           vbInformation, "ONGEN Safe Clear"
    Exit Sub

EH:
    On Error Resume Next
    ThisWorkbook.Protect Password:=STRUCTURE_KEY, Structure:=True, Windows:=False
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    On Error GoTo 0

    MsgBox "ONGEN Safe Clear stopped." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbCritical, "ONGEN Safe Clear"
End Sub

'Use this smaller command when only the four requested generated audit/data sheets
'need to be reset without clearing the entire project.
Public Sub ONGEN_CLEAR_CURRENT_GENERATED_AUDITS_ONLY()
    Dim answer As VbMsgBoxResult

    answer = MsgBox( _
        "Clear current generated audit/assignment data and delete 24v_Power Generator?" & vbCrLf & vbCrLf & _
        "Affected:" & vbCrLf & _
        "  24V_OVERLOAD_TERMINALS" & vbCrLf & _
        "  24V_NOT_GENERATED" & vbCrLf & _
        "  STEP10A_SYNC_AUDIT" & vbCrLf & _
        "  VFD_FUNCTION_ASSIGNMENT" & vbCrLf & _
        "  24v_Power Generator (deleted)", _
        vbYesNo + vbQuestion + vbDefaultButton2, _
        "ONGEN Generated Audit Clear")

    If answer <> vbYes Then Exit Sub

    On Error GoTo EH
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.EnableEvents = False

    On Error Resume Next
    ThisWorkbook.Unprotect Password:=STRUCTURE_KEY
    On Error GoTo EH

    ONGEN_DeleteSheetIfExists "24v_Power Generator"
    ONGEN_Clear_24V_Overload_Terminals
    ONGEN_Clear_24V_Not_Generated
    ONGEN_Clear_Step10A_Sync_Audit
    ONGEN_Clear_VFD_Function_Assignment

    On Error Resume Next
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_USER_MODE", False
    If Err.Number <> 0 Then
        Err.Clear
        ThisWorkbook.Protect Password:=STRUCTURE_KEY, Structure:=True, Windows:=False
    End If
    On Error GoTo EH

    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "Requested generated data was cleared.", vbInformation, "ONGEN"
    Exit Sub

EH:
    On Error Resume Next
    ThisWorkbook.Protect Password:=STRUCTURE_KEY, Structure:=True, Windows:=False
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    On Error GoTo 0

    MsgBox "Generated-data clear stopped." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, vbCritical
End Sub

Private Sub ONGEN_Clear_24V_Overload_Terminals()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet("24V_OVERLOAD_TERMINALS")
    If ws Is Nothing Then Exit Sub

    'Generated summary values.
    ONGEN_ClearCells ws, Array("B2", "E2", "H2", "K2", "N2", "Q2")

    'Row 4 is the production header.
    ONGEN_ClearRowsBelow ws, 4
End Sub

Private Sub ONGEN_Clear_24V_Not_Generated()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet("24V_NOT_GENERATED")
    If ws Is Nothing Then Exit Sub

    ONGEN_ClearCells ws, Array("B2", "E2", "H2", "M2")
    ONGEN_ClearRowsBelow ws, 4
End Sub

Private Sub ONGEN_Clear_Step10A_Sync_Audit()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet("STEP10A_SYNC_AUDIT")
    If ws Is Nothing Then Exit Sub

    ONGEN_ClearCells ws, Array( _
        "B2", "E2", "G2", "I2", "K2", "M2", "O2", _
        "E3", "G3", "I3", "K3", "M3" _
    )

    ONGEN_ClearRowsBelow ws, 4
End Sub

Private Sub ONGEN_Clear_VFD_Function_Assignment()
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet("VFD_FUNCTION_ASSIGNMENT")
    If ws Is Nothing Then Exit Sub

    'Row 1 contains the assignment headers.
    ONGEN_ClearRowsBelow ws, 1
End Sub

Private Sub ONGEN_ClearBelowHeader(ByVal sheetName As String, ByVal headerRow As Long)
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(sheetName)
    If ws Is Nothing Then Exit Sub

    ONGEN_ClearRowsBelow ws, headerRow
End Sub

Private Sub ONGEN_ClearRowsBelow(ByVal ws As Worksheet, ByVal headerRow As Long)
    Dim lastRow As Long
    Dim lastCol As Long

    lastRow = ONGEN_LastUsedRow(ws)
    lastCol = ONGEN_LastUsedCol(ws)

    If lastRow <= headerRow Or lastCol = 0 Then Exit Sub

    ws.Range(ws.Cells(headerRow + 1, 1), ws.Cells(lastRow, lastCol)).ClearContents
End Sub

Private Sub ONGEN_ClearCells(ByVal ws As Worksheet, ByVal cellAddresses As Variant)
    Dim i As Long

    For i = LBound(cellAddresses) To UBound(cellAddresses)
        On Error Resume Next
        ws.Range(CStr(cellAddresses(i))).ClearContents
        On Error GoTo 0
    Next i
End Sub

Private Sub ONGEN_DeleteGeneratedDynamicSheets()
    Dim i As Long
    Dim ws As Worksheet
    Dim nm As String

    For i = ThisWorkbook.Worksheets.count To 1 Step -1
        Set ws = ThisWorkbook.Worksheets(i)
        nm = ws.Name

        If ONGEN_IsGeneratedDynamicSheet(nm) Then
            On Error Resume Next
            ws.Delete
            On Error GoTo 0
        End If
    Next i
End Sub

Private Function ONGEN_IsGeneratedDynamicSheet(ByVal sheetName As String) As Boolean
    Dim u As String
    u = UCase$(Trim$(sheetName))

    'Generated -Clean sheets.
    If InStr(1, u, " - CLEAN", vbTextCompare) > 0 Then
        ONGEN_IsGeneratedDynamicSheet = True
        Exit Function
    End If

    'Generated 24V panel worksheets such as RCP-402_24V.
    If Right$(u, 4) = "_24V" Then
        ONGEN_IsGeneratedDynamicSheet = True
        Exit Function
    End If

    'Raw generated panel sheet names such as RCP-101.
    If Left$(u, 4) = "RCP-" Then
        If ONGEN_IsNumericPanelSuffix(mid$(u, 5)) Then
            ONGEN_IsGeneratedDynamicSheet = True
        End If
    End If
End Function

Private Function ONGEN_IsNumericPanelSuffix(ByVal textValue As String) As Boolean
    Dim i As Long
    Dim ch As String

    If Len(textValue) = 0 Then Exit Function

    For i = 1 To Len(textValue)
        ch = mid$(textValue, i, 1)
        If ch < "0" Or ch > "9" Then Exit Function
    Next i

    ONGEN_IsNumericPanelSuffix = True
End Function

Private Sub ONGEN_DeleteSheetIfExists(ByVal sheetName As String)
    Dim ws As Worksheet
    Set ws = ONGEN_GetSheet(sheetName)

    If Not ws Is Nothing Then
        On Error Resume Next
        ws.Delete
        On Error GoTo 0
    End If
End Sub

Private Function ONGEN_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set ONGEN_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function ONGEN_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim c As Range

    On Error Resume Next
    Set c = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    If Not c Is Nothing Then ONGEN_LastUsedRow = c.Row
    On Error GoTo 0
End Function

Private Function ONGEN_LastUsedCol(ByVal ws As Worksheet) As Long
    Dim c As Range

    On Error Resume Next
    Set c = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByColumns, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    If Not c Is Nothing Then ONGEN_LastUsedCol = c.Column
    On Error GoTo 0
End Function
