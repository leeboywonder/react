Attribute VB_Name = "mod03_24V_Power_Generator"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : mod03_24V_Power_Generator
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.2.1-COMPILE-FIX
' Module        : mod03_24V_Power_Generator
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : V25.2.1 compile repair; missing-only counters explicitly declared.
' Notes         : NO preserves every existing <Panel>_24v sheet and creates only panel sheets that are absent; YES performs a controlled full rebuild.
'-------------------------------------------------------------------------------



' ONGEN V20.2 CLEAN PSU TERMINAL FIX 2026-07-17
' PSU DWG, PSU TERM, and DESC are read from 480v_DATA_POWER.
' PD6 allocation remains logical; generated drawing sheets use the physical table values.

Option Explicit

' ONGEN V19.2 repair: 24V generator reads PSU DWG/TERM/DESC from 480v_DATA_POWER.

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R1
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-12
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

'==========================================================
' Module: mod03_24V_Power_Generator
' Author     : Lee Pierre
' PATCH: Build one 24V generator worksheet per PNL + pair BUS-1/BUS-2 PSUs + BUS-2 terminal backfill
'
'
' Step07 now reads PD6_IMPORT after Step05 allocation and creates one
' 24V worksheet per PNL, for example:
'   RCP101_24v
'   PNL300_24v
'
' The original 24v_Power Generator sheet becomes an index sheet so the
' SNR_24V_BUS_PSU_GEN LISP can scan the workbook and process each panel
' worksheet separately. The LISP already scans all worksheets for the
' required 24V headers.
'
' Missing PSU/terminal behavior (V25.8.4):
'   If PD6_IMPORT[Power Supply] is MISSING or blank for a required BUS, Step07
'   performs a generation-only spatial/capacity plan using Module Length and XYZ.
'   The virtual section is labeled MISSING BUS-x PSU REQUIRED #n and uses the
'   normal 40A PSU / 20A terminal / 40ft / 20ft rules. PD6 is not changed.
'   Existing real PSU assignments are preserved. A real PSU with a blank PD6
'   terminal remains visibly MISSING rather than receiving a random terminal.
'   QUICK FIX 2026-07-02: If PD6_IMPORT has a power device with no PSU for the PWG,
'   Step07 still creates the 24V sheet/device row and marks the BUS PSU as MISSING.
'   QUICK FIX 2026-07-02: Control_ID overrides SIS_Element_Number in generated output when not blank.
'   QUICK FIX 2026-07-02: TYPE output is replaced with DATA_IO_BLOCK[DESC] when available.
'   QUICK FIX 2026-07-02 REV-B: Final write guard forces 24V TYPE to DESC, including MC -> MultiControl.
'   UPDATE 2026-07-21: Missing-PSU status and generated-PSU counts are consolidated on the 24V index sheet.
'   QUICK FIX 2026-07-08: Generated PSU names like 1025-PSU-2 are now prefixed with AREA_NUMBER-SWITCHGROUP.
'   QUICK FIX 2026-07-09: BUS-1/BUS-2 PSU section pairing now requires PSU sequence numbers to be within 20 increments.
'   V22.7: Shared dual-BUS devices use deterministic exact PSU pair ranges when available.
'   V22.7: Shared dual-BUS devices are written first in identical SIS order on BUS-1 and BUS-2.
'   V22.7: Bus-specific devices are written after the paired device set.
'   V22.8: Missing PSU loads are packed into capacity-safe virtual PSU sections.
'   V22.8: Missing BUS-1/BUS-2 records for the same device remain paired.
'   V22.8: Missing virtual PSU sections retain 40A PSU, 20A terminal, and length limits.
'
' Depends on:
'   mod00_ONGEN_Common
'==========================================================

' [LINE EXPLANATION] Defines SH_DATA_IO_BLOCK_LOCAL as a String constant with value "DATA_IO_BLOCK". Edit this line to change sheet data IO block local globally.
Private Const SH_DATA_IO_BLOCK_LOCAL As String = "DATA_IO_BLOCK"
' [LINE EXPLANATION] Defines MAX_24V_PSU_PAIR_INCREMENT as a Long constant with value 20. Edit this line to change maximum 24 v PSU pair increment globally.
Private Const MAX_24V_PSU_PAIR_INCREMENT As Long = 20
Private Const ASSIGNMENT_RULE_VERSION_24V As String = "V25.8.4-PD6-FIRST-MISSING-PSU-SPATIAL-DATAPOWER-FALLBACK"
Private Const MISSING_PSU_LIMIT_A_24V As Double = 40#
Private Const MISSING_TERM_LIMIT_A_24V As Double = 20#
Private Const MISSING_PSU_LIMIT_FT_24V As Double = 40#
Private Const MISSING_TERM_LIMIT_FT_24V As Double = 20#

' Data-driven PSU template source.
Private Const SH_480V_DATA_POWER_LOCAL As String = "480v_DATA_POWER"
Private Const PSU_TEMPLATE_TERMINAL_COUNT_24V As Long = 4
Private m24VPSUTemplate As Object

'V22.5 HIGH-SPEED session cache. Step07 safely reuses a completed Step06
'assignment only when a checksum of the relevant source sheets is unchanged.
Private m24VPreparedSignature As String
Private m24VPreparedValid As Boolean

'-------------------------------------------------------------------------------
' Procedure : Step06_Refresh_24V_Power_Formulas_From_DATA
' Scope/Type: Public Sub
' Purpose   : Refreshes 24 v power formulas from data.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Step06_Refresh_24V_Power_Formulas_From_DATA. Refreshes 24 v power formulas from data.
Public Sub Step06_Refresh_24V_Power_Formulas_From_DATA()

    'V25.9.2: Step06 is SOURCE VALIDATION / LOOKUP REFRESH ONLY.
    'It must never backfill, recalculate, collapse, or reassign PD6_IMPORT.
    Dim wsPD6 As Worksheet
    Dim ws As Worksheet
    Dim wsData As Worksheet
    Dim ws480 As Worksheet
    Dim startTime As Double
    Dim elapsedText As String
    Dim assignedRows As Long
    Dim missingPSU As Long
    Dim missingTerminal As Long

    On Error GoTo ErrHandler
    startTime = Timer
    ResetApplicationState False
    Application.StatusBar = "ONGEN Step 06: validating existing PD6 24V source..."

    Set wsPD6 = GetSheetIfExists(SH_PD6)
    If wsPD6 Is Nothing Then
        Err.Raise vbObjectError + 2601, "Step06_Refresh_24V_Power_Formulas_From_DATA", _
                  "PD6_IMPORT was not found. Run Step05 import first."
    End If

    ValidateExistingPD6ForStep07 wsPD6, assignedRows, missingPSU, missingTerminal

    'Refresh lookup worksheets only. PD6_IMPORT is intentionally not calculated
    'or written by Step06.
    Set wsData = GetSheetIfExists("DATA_POWER")
    If Not wsData Is Nothing Then wsData.Calculate
    Set ws480 = GetSheetIfExists(SH_480V_DATA_POWER_LOCAL)
    If Not ws480 Is Nothing Then ws480.Calculate

    Set ws = EnsureSheet(SH_24V)
    DeleteLegacyPSUMissingSummarySheet
    Clear24VSheetFast ws
    ws.Range("A1:I1").value = Array( _
        "24V Power Generator Panel Sheet Index", "PNL", "Worksheet", _
        "Device Rows", "PSUs Generated", "Missing BUS-1 PSU", _
        "Missing BUS-2 PSU", "Total Missing PSU", "Status")
    StyleHeader ws.Range("A1:I1")
    ws.Range("A2").value = "Step06 validated the existing PD6_IMPORT. Run Step07 to generate directly from the current PD6 assignments."
    ws.Range("A2:I2").Merge
    ws.Range("A2:I2").WrapText = True
    Apply24VIndexWidthsFast ws

    m24VPreparedSignature = Build24VAssignmentSignature()
    m24VPreparedValid = (Len(m24VPreparedSignature) > 0)

    elapsedText = Format$(Elapsed24VSeconds(startTime), "0.0")
    AppendLog "Step06_Refresh_24V_Power_Formulas_From_DATA", "OK", _
              "Read-only PD6 validation completed; assigned rows=" & CStr(assignedRows) & _
              "; missing PSU=" & CStr(missingPSU) & "; missing terminal=" & CStr(missingTerminal) & _
              "; elapsed=" & elapsedText & " sec."

    MsgBox "Step06 completed without changing PD6_IMPORT." & vbCrLf & vbCrLf & _
           "Existing allocated BUS rows: " & CStr(assignedRows) & vbCrLf & _
           "Rows with missing PSU: " & CStr(missingPSU) & vbCrLf & _
           "Rows with missing required terminal: " & CStr(missingTerminal) & vbCrLf & vbCrLf & _
           "Step07 will use the existing PD6 values exactly; it will not recalculate PSU or terminal assignments.", _
           IIf(missingPSU + missingTerminal > 0, vbExclamation, vbInformation), _
           "06 - Validate Existing PD6 Power Source"

SafeExit:
    Application.StatusBar = False
    ResetApplicationState True
    Exit Sub

ErrHandler:
    m24VPreparedValid = False
    Application.StatusBar = False
    ResetApplicationState True
    AppendLog "Step06_Refresh_24V_Power_Formulas_From_DATA", "ERROR", Err.description
    MsgBox "Step06 source validation failed: " & Err.description, vbCritical, _
           "06 - Validate Existing PD6 Power Source"
End Sub

Private Sub ValidateExistingPD6ForStep07(ByVal wsPD6 As Worksheet, _
                                         ByRef assignedRows As Long, _
                                         ByRef missingPSU As Long, _
                                         ByRef missingTerminal As Long)
    Dim lr As Long, lc As Long, r As Long
    Dim data As Variant, headerMap As Object
    Dim cType As Long, cBus As Long, cPSU As Long, cT1 As Long, cT2 As Long
    Dim typ As String, busText As String, psuText As String, termText As String
    Dim buses As Collection, busVal As Variant

    lr = LastUsedRow(wsPD6)
    If lr < 2 Then Err.Raise vbObjectError + 2602, , "PD6_IMPORT contains no data rows."
    lc = LastUsedColAnyRow24V(wsPD6)
    data = wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(lr, lc)).Value2
    Set headerMap = Build24VHeaderMapFast(data, lc)

    cType = HeaderCol24VFast(headerMap, "TYPE", "Device Type", "TYPE/DESC")
    cBus = HeaderCol24VFast(headerMap, "Bus Power", "BUS POWER", "Power Bus")
    cPSU = HeaderCol24VFast(headerMap, "Power Supply", "POWER SUPPLY", "PSU")
    cT1 = HeaderCol24VFast(headerMap, "Power BUS-1 Terminal", "BUS-1 Terminal", "BUS1 Terminal")
    cT2 = HeaderCol24VFast(headerMap, "Power BUS-2 Terminal", "BUS-2 Terminal", "BUS2 Terminal")

    If cType = 0 Or cBus = 0 Or cPSU = 0 Or cT1 = 0 Or cT2 = 0 Then
        Err.Raise vbObjectError + 2603, , _
                  "PD6_IMPORT is missing one or more required Step07 columns: TYPE, Bus Power, Power Supply, Power BUS-1 Terminal, Power BUS-2 Terminal."
    End If

    For r = 2 To lr
        typ = ArrayText24VFast(data, r, cType)
        If Len(typ) > 0 And Not IsPSUTypeFor24V(typ) Then
            busText = ArrayText24VFast(data, r, cBus)
            Set buses = BusListFromDisplay(busText)
            For Each busVal In buses
                assignedRows = assignedRows + 1
                psuText = PowerSupplyForBusDisplay(ArrayText24VFast(data, r, cPSU), CStr(busVal))
                If Len(Trim$(psuText)) = 0 Or Is24VMissingText(psuText) Then
                    missingPSU = missingPSU + 1
                Else
                    If CStr(busVal) = "BUS-1" Then
                        termText = ArrayText24VFast(data, r, cT1)
                    Else
                        termText = ArrayText24VFast(data, r, cT2)
                    End If
                    If Len(Trim$(termText)) = 0 Or Is24VMissingText(termText) Then missingTerminal = missingTerminal + 1
                End If
            Next busVal
        End If
    Next r
End Sub

'-------------------------------------------------------------------------------
' Procedure : Step07_Build_24V_Power_Generator_From_PD6
' Scope/Type: Public Sub
' Purpose   : Builds 24 v power generator from pd 6.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Step07_Build_24V_Power_Generator_From_PD6. Builds 24 v power generator from pd 6.
Public Sub Step07_Build_24V_Power_Generator_From_PD6()

    Dim wsPD6 As Worksheet
    Dim wsIndex As Worksheet
    Dim panelGroups As Object
    Dim panelKey As Variant
    Dim groups As Object
    Dim sheetName As String
    Dim wsOut As Worksheet
    Dim outRow As Long
    Dim sectionEndRow As Long
    Dim idxRow As Long
    Dim key As Variant
    Dim col As Collection
    Dim countBuilt As Long
    Dim totalRows As Long
    Dim missingCounts As Variant
    Dim missingBus1 As Long
    Dim missingBus2 As Long
    Dim totalMissingPSU As Long
    Dim generatedPSUCount As Long
    Dim statusText As String
    Dim errNumber As Long
    Dim errSource As String
    Dim errDescription As String
    Dim startTime As Double
    Dim elapsedText As String
    Dim currentSignature As String
    Dim reusedStep06 As Boolean
    Dim panelIndex As Long
    Dim indexData() As Variant
    Dim indexSheetNames() As String
    Dim missingIndexRow() As Boolean
    Dim generationMode As Long
    Dim missingOnlyBackup As Object
    Dim generationTransactionFinalized As Boolean
    Dim builtNewPanels As Long
    Dim skippedExistingPanels As Long
    Dim supplementalRows As Long

    Dim mapBlock As Object
    Dim mapTin As Object
    Dim mapTout As Object
    Dim mapInside As Object
    Dim mapTypeDesc As Object
    Dim mapRuntimePower As Object

    On Error GoTo ErrHandler
    startTime = Timer
    ResetApplicationState False
    Set m24VPSUTemplate = Nothing
    Application.StatusBar = "ONGEN Step 07: validating 24V source data..."

    generationMode = ONGEN_RequestGenerationModeForCategory( _
                         "Step 07 - Build 24V Power Generator", _
                         ONGEN_CATEGORY_24V_PANEL, "generated 24V panel worksheet")
    If generationMode = ONGEN_GEN_CANCEL Then GoTo SafeExit

    'V25.8.4 CONTROLLED GENERATION RULE:
    'Step07 never recalculates or writes PD6_IMPORT. Existing PD6 assignments
    'remain authoritative. For generation only, DATA_POWER may supply a missing
    'BUS/load profile, and missing PSUs are capacity/distance planned as virtual
    'MISSING requirements so the generated worksheet is deterministic/actionable.
    m24VPreparedValid = False

    Set wsPD6 = GetSheetIfExists(SH_PD6)
    If wsPD6 Is Nothing Then
        Err.Raise vbObjectError + 2701, "Step07_Build_24V_Power_Generator_From_PD6", _
                  "PD6_IMPORT was not found. Run Step05 import first."
    End If
    ValidateExistingPD6ForStep07 wsPD6, totalRows, missingBus1, missingBus2
    totalRows = 0: missingBus1 = 0: missingBus2 = 0
    Set wsIndex = EnsureSheet(SH_24V)
    NAV_Ensure_Return_To_MAIN_Button wsIndex, False
    DeleteLegacyPSUMissingSummarySheet

    Application.StatusBar = "ONGEN Step 07: loading lookup tables..."
    Set mapBlock = BuildPowerMap(1, 2)
    Set mapTin = BuildPowerMap(1, 3)
    Set mapTout = BuildPowerMap(1, 4)
    Set mapInside = Build24VPSUDescriptionMap()
    Set mapTypeDesc = Build24VTypeDescMap()
    Set mapRuntimePower = Build24VRuntimePowerProfile()

    Application.StatusBar = "ONGEN Step 07: grouping PD6 rows in memory..."
    If generationMode = ONGEN_GEN_OVERWRITE Then DeleteOld24VPanelSheets
    Set panelGroups = Build24VPanelGroups(wsPD6, mapBlock, mapTin, mapTout, mapInside, mapTypeDesc, mapRuntimePower)

    'Generation-only supplemental source: an I/O device that is not yet in PD6
    'can still be shown when its Device Type is configured for 24V in DATA_POWER.
    'The parent conveyor in PD6 supplies Panel/PWG/ML/XYZ whenever available.
    Add24VSupplementalDevicesFromIOList panelGroups, wsPD6, mapBlock, mapTin, mapTout, _
                                            mapInside, mapTypeDesc, mapRuntimePower, supplementalRows

    'Missing physical PSUs are not randomly placed. Rebuild only MISSING PSU
    'records into deterministic virtual sections using 40A PSU / 20A terminal
    'limits plus Module Length and XYZ spatial distance. Existing real PSU
    'assignments remain unchanged.
    Repack24VMissingPSUGroups panelGroups
    Sort24VPanelGroupsDeterministic panelGroups
    Write24VMissingPSURegister panelGroups

    If generationMode = ONGEN_GEN_OVERWRITE Then Clear24VSheetFast wsIndex
    wsIndex.Range("A1:I1").value = Array( _
        "24V Power Generator Panel Sheet Index", "PNL", "Worksheet", _
        "Device Rows", "PSUs Generated", "Missing BUS-1 PSU", _
        "Missing BUS-2 PSU", "Total Missing PSU", "Status")
    StyleHeader wsIndex.Range("A1:I1")
    idxRow = 2

    If panelGroups.count = 0 Then
        wsIndex.Cells(idxRow, 1).value = "No 24V-required device rows were found in PD6_IMPORT or the supplemental I/O source."
        wsIndex.Range("A" & idxRow & ":I" & idxRow).Merge
        Apply24VIndexWidthsFast wsIndex
        AppendLog "Step07_Build_24V_Power_Generator_From_PD6", "OK", "No 24V rows found in PD6_IMPORT."
        MsgBox "No 24V-required rows were found. Confirm PD6_IMPORT or IO_DEVICE_LIST contains a device type configured for 24V in DATA_POWER.", vbInformation
        generationTransactionFinalized = True
        Step10A_Rebuild_24V_Index_And_PSU_List_Only False
        GoTo SafeExit
    End If

    ReDim indexData(1 To panelGroups.count, 1 To 9)
    ReDim indexSheetNames(1 To panelGroups.count)
    ReDim missingIndexRow(1 To panelGroups.count)

    For Each panelKey In panelGroups.keys
        panelIndex = panelIndex + 1&
        Application.StatusBar = "ONGEN Step 07: building panel " & CStr(panelIndex) & _
                                " of " & CStr(panelGroups.count) & "..."

        Set groups = panelGroups(panelKey)
        sheetName = SafeSheetName(CStr(panelKey) & "_24v")
        If Len(sheetName) > 31 Then sheetName = Left$(sheetName, 31)

        If generationMode = ONGEN_GEN_MISSING_ONLY And WorksheetExists(sheetName) Then
            skippedExistingPanels = skippedExistingPanels + 1
            GoTo NextPanelKeyV252
        End If

        Set wsOut = EnsureSheet(sheetName)
        NAV_Ensure_Return_To_MAIN_Button wsOut, False
        Clear24VSheetFast wsOut
        builtNewPanels = builtNewPanels + 1
        On Error Resume Next
        wsOut.DisplayPageBreaks = False
        On Error GoTo ErrHandler
        outRow = 1
        countBuilt = 0

        For Each key In groups.keys
            Set col = groups(key)
            Write24VPowerSection wsOut, outRow, CStr(key), col, sectionEndRow
            outRow = sectionEndRow + 3&
            countBuilt = countBuilt + col.count
        Next key

        Apply24VPanelWidthsFast wsOut

        generatedPSUCount = Count24VGeneratedPSUs(groups)
        missingCounts = Count24VMissingPSUByBus(groups)
        missingBus1 = CLng(missingCounts(0))
        missingBus2 = CLng(missingCounts(1))
        totalMissingPSU = missingBus1 + missingBus2
        If totalMissingPSU > 0 Then statusText = "MISSING PSU" Else statusText = "OK"

        indexData(panelIndex, 1) = "Panel 24V sheet"
        indexData(panelIndex, 2) = CStr(panelKey)
        indexData(panelIndex, 3) = sheetName
        indexData(panelIndex, 4) = countBuilt
        indexData(panelIndex, 5) = generatedPSUCount
        indexData(panelIndex, 6) = missingBus1
        indexData(panelIndex, 7) = missingBus2
        indexData(panelIndex, 8) = totalMissingPSU
        indexData(panelIndex, 9) = statusText
        indexSheetNames(panelIndex) = sheetName
        missingIndexRow(panelIndex) = (totalMissingPSU > 0)
        totalRows = totalRows + countBuilt
NextPanelKeyV252:
    Next panelKey

    If generationMode = ONGEN_GEN_OVERWRITE Then
        wsIndex.Range("A2:I" & CStr(panelGroups.count + 1&)).Value2 = indexData
        For panelIndex = 1 To panelGroups.count
            idxRow = panelIndex + 1&
            If Len(indexSheetNames(panelIndex)) > 0 Then
                wsIndex.Hyperlinks.Add anchor:=wsIndex.Cells(idxRow, 3), Address:="", _
                                       SubAddress:="'" & indexSheetNames(panelIndex) & "'!A1", _
                                       TextToDisplay:=indexSheetNames(panelIndex)
            End If
            If missingIndexRow(panelIndex) Then wsIndex.Range("A" & idxRow & ":I" & idxRow).Font.Bold = True
        Next panelIndex
        Apply24VIndexWidthsFast wsIndex
    End If

    generationTransactionFinalized = True
    Step10A_Rebuild_24V_Index_And_PSU_List_Only False

    elapsedText = Format$(Elapsed24VSeconds(startTime), "0.0")
    AppendLog "Step07_Build_24V_Power_Generator_From_PD6", "OK", _
              CStr(totalRows) & " rows across " & CStr(panelGroups.count) & _
              " panels in " & elapsedText & " seconds; existing PD6 assignments consumed without recalculation."
    MsgBox "24V Power Generator built from the existing PD6_IMPORT." & vbCrLf & _
           CStr(totalRows) & " device rows across " & CStr(panelGroups.count) & " panel worksheet(s)." & vbCrLf & _
           "Elapsed time: " & elapsedText & " seconds." & vbCrLf & _
           "PD6 BUS, PSU, load, and terminal assignments were not recalculated by Step07." & vbCrLf & _
           "New panel sheets built: " & CStr(builtNewPanels) & vbCrLf & _
           "Existing panel sheets preserved: " & CStr(skippedExistingPanels) & vbCrLf & _
           "Supplemental DATA_POWER/I-O device rows included: " & CStr(supplementalRows) & vbCrLf & _
           "Missing PSUs were planned as MISSING requirements; PD6 was not modified.", vbInformation

SafeExit:
    On Error Resume Next
    If Not generationTransactionFinalized Then
        If Not missingOnlyBackup Is Nothing Then
            ONGEN_FinalizeMissingOnlyGeneration ONGEN_CATEGORY_24V_PANEL, missingOnlyBackup, False
        End If
    End If
    ONGEN_ClearGenerationMode
    On Error GoTo 0
    Application.StatusBar = False
    ResetApplicationState True
    Exit Sub

ErrHandler:
    errNumber = Err.Number
    errSource = Err.source
    errDescription = Err.description
    If Len(Trim$(errDescription)) = 0 Then errDescription = "Unspecified VBA runtime error."
    On Error Resume Next
    If Not missingOnlyBackup Is Nothing Then
        ONGEN_FinalizeMissingOnlyGeneration ONGEN_CATEGORY_24V_PANEL, missingOnlyBackup, False
    End If
    ONGEN_ClearGenerationMode
    Application.StatusBar = False
    ResetApplicationState True
    AppendLog "Step07_Build_24V_Power_Generator_From_PD6", "ERROR", _
              "Number=" & CStr(errNumber) & "; Source=" & errSource & "; Description=" & errDescription
    On Error GoTo 0
    MsgBox "24V build failed." & vbCrLf & _
           "Error " & CStr(errNumber) & ": " & errDescription, vbCritical, "24V Power Generator"
End Sub

'-------------------------------------------------------------------------------
' Procedure : Build24VPanelGroups
' Scope/Type: Private Function
' Purpose   : Builds 24 v panel groups.
' Parameters:
' wsPD6 (Worksheet) - Supplies worksheet pd 6.
' mapBlock (Object) - Supplies map block.
' mapTin (Object) - Supplies map tin.
' mapTout (Object) - Supplies map tout.
' mapInside (Object) - Supplies map inside.
' mapTypeDesc (Object) - Supplies map type desc.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------

'-------------------------------------------------------------------------------
' V22.5 HIGH-SPEED helpers
'-------------------------------------------------------------------------------
Private Function Build24VHeaderMapFast(ByRef data As Variant, ByVal lastCol As Long) As Object
    Dim d As Object
    Dim c As Long
    Dim keyText As String
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    For c = 1 To lastCol
        keyText = HeaderKey24V(data(1, c))
        If Len(keyText) > 0 Then
            If Not d.Exists(keyText) Then d.Add keyText, c
        End If
    Next c
    Set Build24VHeaderMapFast = d
End Function

Private Function HeaderCol24VFast(ByVal headerMap As Object, ParamArray aliases() As Variant) As Long
    Dim i As Long
    Dim keyText As String
    If headerMap Is Nothing Then Exit Function
    For i = LBound(aliases) To UBound(aliases)
        keyText = HeaderKey24V(CStr(aliases(i)))
        If headerMap.Exists(keyText) Then
            HeaderCol24VFast = CLng(headerMap(keyText))
            Exit Function
        End If
    Next i
End Function

Private Function ArrayValue24VFast(ByRef data As Variant, ByVal rowNum As Long, ByVal colNum As Long) As Variant
    On Error GoTo BlankValue
    If colNum <= 0 Then GoTo BlankValue
    If IsError(data(rowNum, colNum)) Or IsNull(data(rowNum, colNum)) Then GoTo BlankValue
    ArrayValue24VFast = data(rowNum, colNum)
    Exit Function
BlankValue:
    ArrayValue24VFast = Empty
End Function

Private Function ArrayText24VFast(ByRef data As Variant, ByVal rowNum As Long, ByVal colNum As Long) As String
    Dim v As Variant
    v = ArrayValue24VFast(data, rowNum, colNum)
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        ArrayText24VFast = vbNullString
    Else
        ArrayText24VFast = Trim$(CStr(v))
    End If
End Function

Private Function FirstArrayText24VFast(ByRef data As Variant, ByVal rowNum As Long, ParamArray colNums() As Variant) As String
    Dim i As Long
    Dim v As String
    For i = LBound(colNums) To UBound(colNums)
        If CLng(colNums(i)) > 0 Then
            v = ArrayText24VFast(data, rowNum, CLng(colNums(i)))
            If Len(v) > 0 Then
                FirstArrayText24VFast = v
                Exit Function
            End If
        End If
    Next i
End Function

Private Function FirstArrayValue24VFast(ByRef data As Variant, ByVal rowNum As Long, ParamArray colNums() As Variant) As Variant
    Dim i As Long
    Dim v As Variant
    For i = LBound(colNums) To UBound(colNums)
        If CLng(colNums(i)) > 0 Then
            v = ArrayValue24VFast(data, rowNum, CLng(colNums(i)))
            If Not IsError(v) And Not IsNull(v) Then
                If Len(Trim$(CStr(v))) > 0 Then
                    FirstArrayValue24VFast = v
                    Exit Function
                End If
            End If
        End If
    Next i
    FirstArrayValue24VFast = Empty
End Function

Private Sub Clear24VSheetFast(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Cells.UnMerge
    ws.UsedRange.Clear
    On Error GoTo 0
End Sub

Private Sub Apply24VPanelWidthsFast(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Columns("A").columnWidth = 22
    ws.Columns("B").columnWidth = 28
    ws.Columns("C").columnWidth = 10
    ws.Columns("D").columnWidth = 17
    ws.Columns("E:H").columnWidth = 14
    ws.Columns("I:J").columnWidth = 3
    ws.Columns("K").columnWidth = 22
    ws.Columns("L").columnWidth = 28
    ws.Columns("M").columnWidth = 10
    ws.Columns("N").columnWidth = 14
End Sub

Private Sub Apply24VIndexWidthsFast(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Columns("A").columnWidth = 30
    ws.Columns("B").columnWidth = 14
    ws.Columns("C").columnWidth = 26
    ws.Columns("D:I").columnWidth = 16
End Sub

Private Function Elapsed24VSeconds(ByVal startedAt As Double) As Double
    Dim finishedAt As Double
    finishedAt = Timer
    If finishedAt < startedAt Then finishedAt = finishedAt + 86400#
    Elapsed24VSeconds = finishedAt - startedAt
End Function

Private Function Build24VAssignmentSignature() As String
    Dim hashValue As Double
    Dim ws As Worksheet
    Dim sheetNames As Variant
    Dim i As Long

    hashValue = 17#
    'Include the allocation-rule revision so a module update cannot reuse
    'a Step06 signature created by an older pairing algorithm.
    hashValue = Hash24VTextFast(ASSIGNMENT_RULE_VERSION_24V, hashValue)
    sheetNames = Array(SH_PD6, SH_DATA_PWR, SH_480V_DATA_POWER_LOCAL, _
                       "IO_DEVICE_LIST", "IO_BLOCK_GENERATOR")

    For i = LBound(sheetNames) To UBound(sheetNames)
        Set ws = GetSheetIfExists(CStr(sheetNames(i)))
        If Not ws Is Nothing Then
            hashValue = Hash24VSheetFast(ws, hashValue)
        Else
            hashValue = Hash24VTextFast("MISSING:" & CStr(sheetNames(i)), hashValue)
        End If
    Next i

    Build24VAssignmentSignature = Format$(hashValue, "0")
End Function

Private Function Hash24VSheetFast(ByVal ws As Worksheet, ByVal seedValue As Double) As Double
    Const HASH_MOD As Double = 2147483629#
    Dim values As Variant
    Dim rng As Range
    Dim r As Long
    Dim c As Long
    Dim rowCount As Long
    Dim colCount As Long
    Dim hashValue As Double

    Set rng = ws.UsedRange
    hashValue = Hash24VTextFast(ws.Name & "|" & CStr(rng.Row) & "|" & CStr(rng.Column), seedValue)
    values = rng.Value2
    rowCount = rng.rows.count
    colCount = rng.Columns.count
    hashValue = Hash24VTextFast(CStr(rowCount) & "x" & CStr(colCount), hashValue)

    If rowCount = 1 And colCount = 1 Then
        hashValue = Hash24VTextFast(Safe24VSignatureText(values), hashValue)
    Else
        For r = 1 To rowCount
            For c = 1 To colCount
                hashValue = Hash24VTextFast(Safe24VSignatureText(values(r, c)), hashValue)
            Next c
        Next r
    End If

    Hash24VSheetFast = hashValue - Fix(hashValue / HASH_MOD) * HASH_MOD
End Function

Private Function Safe24VSignatureText(ByVal valueIn As Variant) As String
    If IsError(valueIn) Then
        Safe24VSignatureText = "#ERR"
    ElseIf IsNull(valueIn) Or IsEmpty(valueIn) Then
        Safe24VSignatureText = vbNullString
    Else
        Safe24VSignatureText = CStr(valueIn)
    End If
End Function

Private Function Hash24VTextFast(ByVal textValue As String, ByVal seedValue As Double) As Double
    Const HASH_MOD As Double = 2147483629#
    Dim i As Long
    Dim hashValue As Double
    hashValue = seedValue

    For i = 1 To Len(textValue)
        hashValue = hashValue * 33# + CDbl(AscW(mid$(textValue, i, 1)) And &HFFFF&)
        If hashValue > HASH_MOD Then hashValue = hashValue - Fix(hashValue / HASH_MOD) * HASH_MOD
    Next i
    hashValue = hashValue * 33# + 257#
    Hash24VTextFast = hashValue - Fix(hashValue / HASH_MOD) * HASH_MOD
End Function

Private Function Build24VPanelGroups(ByVal wsPD6 As Worksheet, ByVal mapBlock As Object, _
                                     ByVal mapTin As Object, ByVal mapTout As Object, _
                                     ByVal mapInside As Object, ByVal mapTypeDesc As Object, _
                                     ByVal mapRuntimePower As Object) As Object

    'V25.8.4: Existing PD6 values are consumed first. DATA_POWER is a generation-
    'only fallback for a missing Bus Power or missing BUS-specific load. Nothing
    'in this procedure writes back to PD6_IMPORT.
    Dim panelGroups As Object
    Dim groups As Object
    Dim col As Collection
    Dim headerMap As Object
    Dim data As Variant
    Dim lastRow As Long
    Dim lastCol As Long
    Dim r As Long

    Dim pnl As String
    Dim sis As String
    Dim sourceSeq As String
    Dim areaNum As String
    Dim typ As String
    Dim typDesc As String
    Dim loadVal As String
    Dim runtimeLoad As Double
    Dim runtimeFound As Boolean
    Dim pwg As String
    Dim busRaw As String
    Dim busVal As Variant
    Dim buses As Collection
    Dim psuText As String
    Dim psu As String
    Dim pterm As String
    Dim blockName As String
    Dim tin As String
    Dim tout As String
    Dim inside As String
    Dim groupKey As String
    Dim rec As Variant
    Dim pairIndex As Long
    Dim moduleFt As Double
    Dim xVal As Double, yVal As Double, zVal As Double
    Dim xyzKnown As Boolean

    Dim psuPairIndex As Object
    Dim psuPairCount As Object
    Dim psuPairBus1Seq As Object
    Dim psuPairBus2Seq As Object

    Dim cType As Long
    Dim cBus As Long
    Dim cPSU As Long
    Dim cControl As Long
    Dim cSisElem As Long
    Dim cSisSeq As Long
    Dim cArea As Long
    Dim cPWG As Long
    Dim cPNL As Long
    Dim cLoad1 As Long
    Dim cLoad2 As Long
    Dim cTerm1 As Long
    Dim cTerm2 As Long
    Dim cML As Long
    Dim cX As Long, cY As Long, cZ As Long

    Set panelGroups = CreateObject("Scripting.Dictionary")
    panelGroups.CompareMode = vbTextCompare
    Set psuPairIndex = CreateObject("Scripting.Dictionary")
    Set psuPairCount = CreateObject("Scripting.Dictionary")
    Set psuPairBus1Seq = CreateObject("Scripting.Dictionary")
    Set psuPairBus2Seq = CreateObject("Scripting.Dictionary")
    psuPairIndex.CompareMode = vbTextCompare
    psuPairCount.CompareMode = vbTextCompare
    psuPairBus1Seq.CompareMode = vbTextCompare
    psuPairBus2Seq.CompareMode = vbTextCompare

    lastRow = LastUsedRow(wsPD6)
    If lastRow < 2 Then
        Set Build24VPanelGroups = panelGroups
        Exit Function
    End If
    lastCol = LastUsedColAnyRow24V(wsPD6)
    data = wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(lastRow, lastCol)).Value2
    Set headerMap = Build24VHeaderMapFast(data, lastCol)

    cType = HeaderCol24VFast(headerMap, "TYPE", "Device Type", "TYPE/DESC")
    cBus = HeaderCol24VFast(headerMap, "Bus Power", "BUS POWER", "Power Bus")
    cPSU = HeaderCol24VFast(headerMap, "Power Supply", "POWER SUPPLY", "PSU")
    cControl = HeaderCol24VFast(headerMap, "Control_ID", "CONTROL_ID", "Control ID")
    cSisElem = HeaderCol24VFast(headerMap, "SIS_Element_Number", "SIS_ELEMENT_NUMBER")
    cSisSeq = HeaderCol24VFast(headerMap, "SIS_sequence", "SIS_SEQUENCE", "Sequence")
    cArea = HeaderCol24VFast(headerMap, "Area_Number", "AREA_NUMBER", "Area Number", "LOCATION")
    cPWG = HeaderCol24VFast(headerMap, "SwitchGroup", "PWG", "SWITCHGROUP")
    cPNL = HeaderCol24VFast(headerMap, "PNL", "PANEL", "Panel")
    cLoad1 = HeaderCol24VFast(headerMap, "Load BUS-1", "LOAD BUS 1", "Load Bus1")
    cLoad2 = HeaderCol24VFast(headerMap, "Load BUS-2", "LOAD BUS 2", "Load Bus2")
    cTerm1 = HeaderCol24VFast(headerMap, "Power BUS-1 Terminal", "BUS-1 Terminal", "BUS1 Terminal", "Power Terminal")
    cTerm2 = HeaderCol24VFast(headerMap, "Power BUS-2 Terminal", "BUS-2 Terminal", "BUS2 Terminal", "Power Terminal")
    cML = HeaderCol24VFast(headerMap, "Module Length (ML)", "MODULE LENGTH ML", "Module Length", "ML")
    cX = HeaderCol24VFast(headerMap, "X")
    cY = HeaderCol24VFast(headerMap, "Y")
    cZ = HeaderCol24VFast(headerMap, "Z")

    If cType = 0 Then
        Set Build24VPanelGroups = panelGroups
        Exit Function
    End If

    For r = 2 To lastRow
        typ = ArrayText24VFast(data, r, cType)
        If Len(typ) = 0 Then GoTo NextRowFast24V
        If IsPSUTypeFor24V(typ) Then GoTo NextRowFast24V

        busRaw = ArrayText24VFast(data, r, cBus)
        Set buses = BusListFromDisplay(busRaw)
        If buses.count = 0 Then Set buses = Runtime24VBusesForType(mapRuntimePower, typ)
        If buses.count = 0 Then GoTo NextRowFast24V

        psuText = ArrayText24VFast(data, r, cPSU)
        If Len(psuText) = 0 Then psuText = "MISSING"

        sourceSeq = ArrayText24VFast(data, r, cSisSeq)
        sis = FirstArrayText24VFast(data, r, cControl, cSisElem, cSisSeq)
        If Len(sis) = 0 Then GoTo NextRowFast24V
        If Len(sourceSeq) = 0 Then sourceSeq = sis
        typDesc = Get24VTypeDesc(mapTypeDesc, typ)

        areaNum = ArrayText24VFast(data, r, cArea)
        If Len(areaNum) = 0 Then areaNum = AreaNumberFrom24VElementNumber(sis)
        pwg = ArrayText24VFast(data, r, cPWG)
        If Len(pwg) = 0 Then pwg = SwitchGroupFrom24VElementNumber(sis)
        If Len(pwg) = 0 Then pwg = "PWG-UNKNOWN"
        pnl = ArrayText24VFast(data, r, cPNL)
        If Len(pnl) = 0 Then pnl = Build24VVirtualPanelKey(areaNum, pwg)

        moduleFt = ModuleLengthFeet24V(ArrayValue24VFast(data, r, cML))
        xyzKnown = Read24VXYZFromArray(data, r, cX, cY, cZ, xVal, yVal, zVal)

        blockName = GetPowerMapValueLocal(mapBlock, typ, "HDV1T6_GENERIC")
        tin = GetPowerMapValueLocal(mapTin, typ, "X4TERM01")
        tout = GetPowerMapValueLocal(mapTout, typ, "X1TERM02")

        For Each busVal In buses
            runtimeFound = False
            runtimeLoad = Runtime24VLoadForType(mapRuntimePower, typ, CStr(busVal), runtimeFound)

            If CStr(busVal) = "BUS-1" Then
                loadVal = Format24VLoadValue(ArrayValue24VFast(data, r, cLoad1), True)
                pterm = FirstArrayText24VFast(data, r, cTerm1)
            Else
                loadVal = Format24VLoadValue(ArrayValue24VFast(data, r, cLoad2), False)
                pterm = FirstArrayText24VFast(data, r, cTerm2)
            End If

            'Only use DATA_POWER when the PD6 BUS-specific load is blank/zero.
            If LoadNumberFrom24VText(loadVal) <= 0# And runtimeFound And runtimeLoad > 0# Then
                loadVal = Format24VLoadValue(runtimeLoad, CStr(busVal) = "BUS-1")
            End If

            psu = PowerSupplyForBusDisplay(psuText, CStr(busVal))
            If Len(Trim$(psu)) = 0 Then psu = "MISSING"
            psu = Normalize24VGeneratedPSUName(psu, areaNum, pwg)
            If Len(psu) = 0 Then psu = "MISSING"

            pterm = Normalize24VPowerTerminalName(pterm)
            inside = GetPowerMapValueLocal(mapInside, pterm, vbNullString)
            If Len(inside) = 0 Then inside = InsidePSUTermFromPowerTerminal(pterm)

            pairIndex = Get24VPairIndex(psuPairIndex, psuPairCount, psuPairBus1Seq, _
                                       psuPairBus2Seq, pnl, pwg, CStr(busVal), psu)
            groupKey = pwg & "|" & Format$(pairIndex, "0000")
            rec = Array(pnl, pwg, CStr(busVal), psu, sis, typDesc, loadVal, _
                        blockName, tin, tout, pterm, inside, moduleFt, _
                        xVal, yVal, zVal, sourceSeq, xyzKnown)

            If Not panelGroups.Exists(pnl) Then
                Set groups = CreateObject("Scripting.Dictionary")
                groups.CompareMode = vbTextCompare
                panelGroups.Add pnl, groups
            Else
                Set groups = panelGroups(pnl)
            End If

            If Not groups.Exists(groupKey) Then
                Set col = New Collection
                groups.Add groupKey, col
            End If
            groups(groupKey).Add rec

NextBusFast24V:
        Next busVal
NextRowFast24V:
    Next r

    Set Build24VPanelGroups = panelGroups
End Function

Private Function Build24VVirtualPanelKey(ByVal areaNum As String, ByVal pwg As String) As String
    Dim a As String, s As String
    a = Clean24VKeyToken(areaNum)
    s = Clean24VKeyToken(pwg)
    If Len(a) = 0 Then a = "NA"
    If Len(s) = 0 Then s = "NA"
    Build24VVirtualPanelKey = "MISSING_PNL_" & a & "_" & s
End Function

Private Function Clean24VKeyToken(ByVal valueIn As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace$(s, " ", "")
    s = Replace$(s, "-", "")
    s = Replace$(s, "_", "")
    s = Replace$(s, "/", "")
    Clean24VKeyToken = s
End Function

Private Function Read24VXYZFromArray(ByVal data As Variant, ByVal r As Long, _
                                     ByVal cX As Long, ByVal cY As Long, ByVal cZ As Long, _
                                     ByRef xVal As Double, ByRef yVal As Double, ByRef zVal As Double) As Boolean
    xVal = 0#: yVal = 0#: zVal = 0#
    If cX <= 0 Or cY <= 0 Then Exit Function
    If Not IsNumeric(ArrayValue24VFast(data, r, cX)) Then Exit Function
    If Not IsNumeric(ArrayValue24VFast(data, r, cY)) Then Exit Function
    xVal = CDbl(ArrayValue24VFast(data, r, cX))
    yVal = CDbl(ArrayValue24VFast(data, r, cY))
    If cZ > 0 Then
        If IsNumeric(ArrayValue24VFast(data, r, cZ)) Then zVal = CDbl(ArrayValue24VFast(data, r, cZ))
    End If
    Read24VXYZFromArray = True
End Function

Private Function Build24VRuntimePowerProfile() As Object
    Dim d As Object, ws As Worksheet
    Dim headerRow As Long, cType As Long, cBus1 As Long, cBus2 As Long
    Dim cFlag1 As Long, cFlag2 As Long, lr As Long, r As Long
    Dim typ As String, key As String, load1 As Double, load2 As Double
    Dim req1 As Boolean, req2 As Boolean

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    Set ws = GetSheetIfExists("DATA_POWER")
    If ws Is Nothing Then
        Set Build24VRuntimePowerProfile = d
        Exit Function
    End If

    headerRow = Find24VRuntimePowerHeaders(ws, cType, cBus1, cBus2, cFlag1, cFlag2)
    If headerRow = 0 Or cType = 0 Then
        Set Build24VRuntimePowerProfile = d
        Exit Function
    End If

    lr = LastUsedRow(ws)
    For r = headerRow + 1 To lr
        typ = Trim$(CStr(ws.Cells(r, cType).Value2))
        key = Runtime24VTypeKey(typ)
        If Len(key) > 0 Then
            load1 = Runtime24VNumeric(ws, r, cBus1)
            load2 = Runtime24VNumeric(ws, r, cBus2)
            req1 = (load1 > 0#) Or Runtime24VYes(ws, r, cFlag1)
            req2 = (load2 > 0#) Or Runtime24VYes(ws, r, cFlag2)
            d(key & "|BUS-1|LOAD") = load1
            d(key & "|BUS-2|LOAD") = load2
            d(key & "|BUS-1|REQ") = req1
            d(key & "|BUS-2|REQ") = req2
        End If
    Next r

    Set Build24VRuntimePowerProfile = d
End Function

Private Function Find24VRuntimePowerHeaders(ByVal ws As Worksheet, _
        ByRef cType As Long, ByRef cBus1 As Long, ByRef cBus2 As Long, _
        ByRef cFlag1 As Long, ByRef cFlag2 As Long) As Long
    Dim r As Long, c As Long, k As Long, lastCol As Long, maxRow As Long, searchEnd As Long
    Dim h As String, h2 As String
    cType = 0: cBus1 = 0: cBus2 = 0: cFlag1 = 0: cFlag2 = 0
    lastCol = LastUsedColAnyRow24V(ws)
    maxRow = LastUsedRow(ws)
    If maxRow > 30 Then maxRow = 30

    For r = 1 To maxRow
        For c = 1 To lastCol
            h = Runtime24VHeaderKey(ws.Cells(r, c).Value2)
            If h = "TYPE" Then
                searchEnd = c + 10
                If searchEnd > lastCol Then searchEnd = lastCol
                For k = c + 1 To searchEnd
                    h2 = Runtime24VHeaderKey(ws.Cells(r, k).Value2)
                    If h2 = "BUS1" Then cBus1 = k
                    If h2 = "BUS2" Then cBus2 = k
                    If h2 = "24BUS1" Then cFlag1 = k
                    If h2 = "24VBUS2" Or h2 = "24BUS2" Then cFlag2 = k
                Next k
                If cBus1 > 0 Or cBus2 > 0 Or cFlag1 > 0 Or cFlag2 > 0 Then
                    cType = c
                    Find24VRuntimePowerHeaders = r
                    Exit Function
                End If
                cBus1 = 0: cBus2 = 0: cFlag1 = 0: cFlag2 = 0
            End If
        Next c
    Next r
End Function

Private Function Runtime24VHeaderKey(ByVal valueIn As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace$(s, " ", "")
    s = Replace$(s, "-", "")
    s = Replace$(s, "_", "")
    s = Replace$(s, "/", "")
    Runtime24VHeaderKey = s
End Function

Private Function Runtime24VTypeKey(ByVal valueIn As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace$(s, " ", "")
    s = Replace$(s, "_", "/")
    s = Replace$(s, "-", "/")
    Runtime24VTypeKey = s
End Function

Private Function Runtime24VNumeric(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As Double
    If c <= 0 Then Exit Function
    If IsNumeric(ws.Cells(r, c).Value2) Then Runtime24VNumeric = CDbl(ws.Cells(r, c).Value2)
End Function

Private Function Runtime24VYes(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As Boolean
    Dim s As String
    If c <= 0 Then Exit Function
    s = UCase$(Trim$(CStr(ws.Cells(r, c).Value2)))
    Runtime24VYes = (s = "YES" Or s = "Y" Or s = "TRUE" Or s = "1" Or s = "X")
End Function

Private Function Runtime24VBusesForType(ByVal profile As Object, ByVal typ As String) As Collection
    Dim buses As New Collection
    Dim key As String
    key = Runtime24VTypeKey(typ)
    If Not profile Is Nothing Then
        If profile.Exists(key & "|BUS-1|REQ") Then
            If CBool(profile(key & "|BUS-1|REQ")) Then buses.Add "BUS-1"
        End If
        If profile.Exists(key & "|BUS-2|REQ") Then
            If CBool(profile(key & "|BUS-2|REQ")) Then buses.Add "BUS-2"
        End If
    End If
    Set Runtime24VBusesForType = buses
End Function

Private Function Runtime24VLoadForType(ByVal profile As Object, ByVal typ As String, _
                                       ByVal busText As String, ByRef found As Boolean) As Double
    Dim key As String
    found = False
    If profile Is Nothing Then Exit Function
    key = Runtime24VTypeKey(typ) & "|" & UCase$(Trim$(busText)) & "|LOAD"
    If profile.Exists(key) Then
        found = True
        If IsNumeric(profile(key)) Then Runtime24VLoadForType = CDbl(profile(key))
    End If
End Function


'-------------------------------------------------------------------------------
' V22.8 missing-PSU capacity planner
' Rebuilds only records whose PD6 Power Supply is blank/MISSING. Physical PSU
' assignments are preserved. Missing devices are packed into virtual required
' PSU sections so no section silently carries more than the existing limits.
'-------------------------------------------------------------------------------
Private Sub Repack24VMissingPSUGroups(ByVal panelGroups As Object)

    Dim pnlKey As Variant
    Dim groups As Object, newGroups As Object
    Dim missingByPWG As Object, assignedByDevice As Object
    Dim stateByGroup As Object, virtualKeysByPWG As Object, nextIndexByPWG As Object
    Dim groupKey As Variant, records As Collection, target As Collection
    Dim missingRecords As Collection, deviceRecords As Collection, virtualKeys As Collection
    Dim devices As Object, rec As Variant, recOut As Variant, deviceKeys As Variant
    Dim deviceKey As Variant, pwgKey As Variant
    Dim i As Long, selectedGroup As String, assignedGroup As String, newIndex As Long
    Dim state As Object, busText As String, terminalIndex As Long
    Dim sisText As String, pwgText As String

    For Each pnlKey In panelGroups.keys
        Set groups = panelGroups(pnlKey)
        Set newGroups = CreateObject("Scripting.Dictionary")
        Set missingByPWG = CreateObject("Scripting.Dictionary")
        Set assignedByDevice = CreateObject("Scripting.Dictionary")
        Set stateByGroup = CreateObject("Scripting.Dictionary")
        Set virtualKeysByPWG = CreateObject("Scripting.Dictionary")
        Set nextIndexByPWG = CreateObject("Scripting.Dictionary")
        newGroups.CompareMode = vbTextCompare
        missingByPWG.CompareMode = vbTextCompare
        assignedByDevice.CompareMode = vbTextCompare
        stateByGroup.CompareMode = vbTextCompare
        virtualKeysByPWG.CompareMode = vbTextCompare
        nextIndexByPWG.CompareMode = vbTextCompare

        'Preserve real PSU assignments exactly. Only MISSING PSU records are replanned.
        For Each groupKey In groups.keys
            Set records = groups(groupKey)
            For i = 1 To records.count
                rec = records(i)
                pwgText = Trim$(CStr(rec(1)))
                sisText = UCase$(Trim$(CStr(rec(4))))

                If Is24VMissingText(CStr(rec(3))) Then
                    If Not missingByPWG.Exists(pwgText) Then
                        Set missingRecords = New Collection
                        missingByPWG.Add pwgText, missingRecords
                    End If
                    missingByPWG(pwgText).Add rec
                Else
                    Add24VRecordToGroup newGroups, CStr(groupKey), rec
                    If Len(sisText) > 0 Then assignedByDevice(UCase$(pwgText) & "|" & sisText) = CStr(groupKey)
                End If
            Next i
        Next groupKey

        'Seed state from every existing physical group so a missing paired BUS
        'cannot ignore load/distance already consumed by the real BUS in that section.
        For Each groupKey In newGroups.keys
            Update24VNextSectionIndex nextIndexByPWG, CStr(groupKey)
            Set state = Get24VMissingGroupState(stateByGroup, CStr(groupKey))
            'Use deterministic SIS/XYZ order for distance-state seeding. Existing
            'PD6 row order is not treated as physical routing order.
            Set target = Sort24VRecordsCollection(newGroups(groupKey))
            Initialize24VMissingStateFromExistingGroup state, target
        Next groupKey

        For Each pwgKey In missingByPWG.keys
            Set missingRecords = missingByPWG(pwgKey)
            Set devices = Build24VMissingDeviceMap(missingRecords)
            deviceKeys = devices.keys
            Sort24VMissingDeviceKeys deviceKeys, devices

            If Not virtualKeysByPWG.Exists(CStr(pwgKey)) Then
                Set virtualKeys = New Collection
                virtualKeysByPWG.Add CStr(pwgKey), virtualKeys
            Else
                Set virtualKeys = virtualKeysByPWG(CStr(pwgKey))
            End If

            For Each deviceKey In deviceKeys
                Set deviceRecords = devices(deviceKey)
                selectedGroup = vbNullString
                assignedGroup = vbNullString

                'If one BUS of the same device already has a real PSU, keep the
                'missing companion BUS visually paired with that section when safe.
                If assignedByDevice.Exists(UCase$(CStr(pwgKey)) & "|" & UCase$(CStr(deviceKey))) Then
                    assignedGroup = CStr(assignedByDevice(UCase$(CStr(pwgKey)) & "|" & UCase$(CStr(deviceKey))))
                    Set state = Get24VMissingGroupState(stateByGroup, assignedGroup)
                    If Can24VMissingGroupAcceptDevice(state, deviceRecords) Then selectedGroup = assignedGroup
                End If

                If Len(selectedGroup) = 0 Then
                    For i = 1 To virtualKeys.count
                        Set state = Get24VMissingGroupState(stateByGroup, CStr(virtualKeys(i)))
                        If Can24VMissingGroupAcceptDevice(state, deviceRecords) Then
                            selectedGroup = CStr(virtualKeys(i))
                            Exit For
                        End If
                    Next i
                End If

                If Len(selectedGroup) = 0 Then
                    newIndex = Next24VMissingSectionIndex(nextIndexByPWG, CStr(pwgKey))
                    selectedGroup = CStr(pwgKey) & "|" & Format$(newIndex, "0000")
                    virtualKeys.Add selectedGroup
                    Set state = Get24VMissingGroupState(stateByGroup, selectedGroup)
                Else
                    Set state = Get24VMissingGroupState(stateByGroup, selectedGroup)
                End If

                Reserve24VMissingDevice state, deviceRecords

                For i = 1 To deviceRecords.count
                    recOut = deviceRecords(i)
                    busText = UCase$(Trim$(CStr(recOut(2))))
                    terminalIndex = Assigned24VMissingTerminal(state, busText, UCase$(Trim$(CStr(recOut(4)))))

                    recOut(3) = Missing24VPSULabel(busText, selectedGroup, Not DeviceFitsEmpty24VMissingGroup(deviceRecords))
                    If terminalIndex > 0 Then
                        recOut(10) = Missing24VTerminalName(terminalIndex)
                        recOut(11) = InsidePSUTermFromPowerTerminal(CStr(recOut(10)))
                    Else
                        recOut(10) = "MISSING"
                        recOut(11) = "MISSING"
                    End If
                    Add24VRecordToGroup newGroups, selectedGroup, recOut
                Next i
            Next deviceKey
        Next pwgKey

        groups.RemoveAll
        For Each groupKey In newGroups.keys
            Set target = newGroups(groupKey)
            groups.Add CStr(groupKey), target
        Next groupKey
    Next pnlKey
End Sub

Private Sub Add24VRecordToGroup(ByVal groups As Object, ByVal groupKey As String, ByVal rec As Variant)
    Dim records As Collection
    If Not groups.Exists(groupKey) Then
        Set records = New Collection
        groups.Add groupKey, records
    End If
    groups(groupKey).Add rec
End Sub

Private Sub Update24VNextSectionIndex(ByVal nextIndexByPWG As Object, ByVal groupKey As String)
    Dim parts As Variant, pwgText As String, idx As Long
    parts = Split(groupKey, "|")
    If UBound(parts) < 1 Then Exit Sub
    pwgText = CStr(parts(0))
    If IsNumeric(parts(1)) Then idx = CLng(parts(1))
    If Not nextIndexByPWG.Exists(pwgText) Then nextIndexByPWG(pwgText) = 0&
    If idx > CLng(nextIndexByPWG(pwgText)) Then nextIndexByPWG(pwgText) = idx
End Sub

Private Function Next24VMissingSectionIndex(ByVal nextIndexByPWG As Object, ByVal pwgText As String) As Long
    Dim idx As Long
    If nextIndexByPWG.Exists(pwgText) Then idx = CLng(nextIndexByPWG(pwgText))
    idx = idx + 1&
    nextIndexByPWG(pwgText) = idx
    Next24VMissingSectionIndex = idx
End Function

Private Function Build24VMissingDeviceMap(ByVal missingRecords As Collection) As Object
    Dim devices As Object, deviceRecords As Collection
    Dim rec As Variant, keyText As String, i As Long
    Set devices = CreateObject("Scripting.Dictionary")
    devices.CompareMode = vbTextCompare
    For i = 1 To missingRecords.count
        rec = missingRecords(i)
        keyText = UCase$(Trim$(CStr(rec(4))))
        If Len(keyText) = 0 Then keyText = "ROW-" & Format$(i, "000000")
        If Not devices.Exists(keyText) Then
            Set deviceRecords = New Collection
            devices.Add keyText, deviceRecords
        End If
        devices(keyText).Add rec
    Next i
    Set Build24VMissingDeviceMap = devices
End Function

Private Sub Sort24VMissingDeviceKeys(ByRef keys As Variant, ByVal devices As Object)
    Dim i As Long, j As Long, temp As Variant
    If Not IsArray(keys) Then Exit Sub
    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If Compare24VMissingDeviceKeys(CStr(keys(i)), CStr(keys(j)), devices) > 0 Then
                temp = keys(i): keys(i) = keys(j): keys(j) = temp
            End If
        Next j
    Next i
End Sub

Private Function Compare24VMissingDeviceKeys(ByVal leftKey As String, ByVal rightKey As String, ByVal devices As Object) As Long
    Dim leftSeq As Long, rightSeq As Long
    Dim leftRec As Variant, rightRec As Variant
    leftRec = devices(leftKey)(1)
    rightRec = devices(rightKey)(1)
    leftSeq = Record24VSequenceNumber(leftRec)
    rightSeq = Record24VSequenceNumber(rightRec)
    If leftSeq < rightSeq Then
        Compare24VMissingDeviceKeys = -1
    ElseIf leftSeq > rightSeq Then
        Compare24VMissingDeviceKeys = 1
    Else
        Compare24VMissingDeviceKeys = Compare24VRecordXYZ(leftRec, rightRec)
        If Compare24VMissingDeviceKeys = 0 Then Compare24VMissingDeviceKeys = StrComp(leftKey, rightKey, vbTextCompare)
    End If
End Function

Private Function Record24VSequenceNumber(ByVal rec As Variant) As Long
    Dim s As String
    On Error Resume Next
    If UBound(rec) >= 16 Then s = CStr(rec(16))
    If Len(Trim$(s)) = 0 Then s = CStr(rec(4))
    On Error GoTo 0
    Record24VSequenceNumber = DeviceSequence24V(s)
End Function

Private Function DeviceSequence24V(ByVal sisText As String) As Long
    Dim parts As Variant, i As Long, token As String
    parts = Split(UCase$(Trim$(sisText)), "-")
    'Prefer the third token for full Area-SWG-SIS identifiers.
    If UBound(parts) >= 2 Then
        token = NumericPrefix24V(CStr(parts(2)))
        If Len(token) > 0 Then DeviceSequence24V = CLng(token): Exit Function
    End If
    'Fallback for plain SIS_sequence such as 1060-01B.
    For i = LBound(parts) To UBound(parts)
        token = NumericPrefix24V(CStr(parts(i)))
        If Len(token) > 0 Then
            If CLng(token) >= 1000 Then DeviceSequence24V = CLng(token): Exit Function
        End If
    Next i
    DeviceSequence24V = 2147483647
End Function

Private Function NumericPrefix24V(ByVal valueIn As String) As String
    Dim i As Long, ch As String, s As String
    valueIn = Trim$(valueIn)
    For i = 1 To Len(valueIn)
        ch = mid$(valueIn, i, 1)
        If ch >= "0" And ch <= "9" Then s = s & ch Else Exit For
    Next i
    NumericPrefix24V = s
End Function

Private Function Get24VMissingGroupState(ByVal stateByGroup As Object, ByVal groupKey As String) As Object
    Dim state As Object
    If stateByGroup.Exists(groupKey) Then
        Set Get24VMissingGroupState = stateByGroup(groupKey)
        Exit Function
    End If
    Set state = CreateObject("Scripting.Dictionary")
    state.CompareMode = vbTextCompare
    stateByGroup.Add groupKey, state
    Set Get24VMissingGroupState = state
End Function

Private Sub Initialize24VMissingStateFromExistingGroup(ByVal state As Object, ByVal records As Collection)
    Dim i As Long, rec As Variant, busText As String, loadAmps As Double
    Dim spanFt As Double, slot As Long, prefix As String
    For i = 1 To records.count
        rec = records(i)
        busText = UCase$(Trim$(CStr(rec(2))))
        loadAmps = LoadNumberFrom24VText(CStr(rec(6)))
        spanFt = Missing24VSpanFeet(state, busText, rec, 0)
        state(busText & "|LOAD") = State24VDouble(state, busText & "|LOAD") + loadAmps
        state(busText & "|LEN") = State24VDouble(state, busText & "|LEN") + spanFt
        Update24VLastXYZ state, busText, rec
        slot = Missing24VTerminalSlotFromName(CStr(rec(10)))
        If slot > 0 Then
            prefix = busText & "|T" & CStr(slot)
            spanFt = Missing24VSpanFeet(state, busText, rec, slot)
            state(prefix & "|LOAD") = State24VDouble(state, prefix & "|LOAD") + loadAmps
            state(prefix & "|LEN") = State24VDouble(state, prefix & "|LEN") + spanFt
            Update24VLastXYZ state, prefix, rec
        End If
        state("DEVICECOUNT") = State24VDouble(state, "DEVICECOUNT") + 1#
    Next i
End Sub

Private Function Can24VMissingGroupAcceptDevice(ByVal state As Object, ByVal deviceRecords As Collection) As Boolean
    Dim rec As Variant, busText As String, loadAmps As Double, spanFt As Double
    Dim i As Long
    If Device24VHasNoLocation(deviceRecords) And State24VDouble(state, "DEVICECOUNT") > 0# Then Exit Function
    For i = 1 To deviceRecords.count
        rec = deviceRecords(i)
        busText = UCase$(Trim$(CStr(rec(2))))
        loadAmps = LoadNumberFrom24VText(CStr(rec(6)))
        spanFt = Missing24VSpanFeet(state, busText, rec, 0)
        If State24VDouble(state, busText & "|LOAD") + loadAmps > MISSING_PSU_LIMIT_A_24V Then Exit Function
        If State24VDouble(state, busText & "|LEN") + spanFt > MISSING_PSU_LIMIT_FT_24V Then Exit Function
        If Find24VMissingTerminal(state, busText, loadAmps, rec) = 0 Then Exit Function
    Next i
    Can24VMissingGroupAcceptDevice = True
End Function

Private Function DeviceFitsEmpty24VMissingGroup(ByVal deviceRecords As Collection) As Boolean
    Dim state As Object
    Set state = CreateObject("Scripting.Dictionary")
    state.CompareMode = vbTextCompare
    DeviceFitsEmpty24VMissingGroup = Can24VMissingGroupAcceptDevice(state, deviceRecords)
End Function

Private Function Find24VMissingTerminal(ByVal state As Object, ByVal busText As String, _
        ByVal loadAmps As Double, ByVal rec As Variant) As Long
    Dim idx As Long, prefix As String, spanFt As Double
    For idx = 1 To PSU_TEMPLATE_TERMINAL_COUNT_24V
        prefix = busText & "|T" & CStr(idx)
        spanFt = Missing24VSpanFeet(state, busText, rec, idx)
        If State24VDouble(state, prefix & "|LOAD") + loadAmps <= MISSING_TERM_LIMIT_A_24V Then
            If State24VDouble(state, prefix & "|LEN") + spanFt <= MISSING_TERM_LIMIT_FT_24V Then
                Find24VMissingTerminal = idx
                Exit Function
            End If
        End If
    Next idx
End Function

Private Sub Reserve24VMissingDevice(ByVal state As Object, ByVal deviceRecords As Collection)
    Dim rec As Variant, busText As String, deviceKey As String
    Dim loadAmps As Double, spanFt As Double, terminalIndex As Long
    Dim prefix As String, i As Long
    For i = 1 To deviceRecords.count
        rec = deviceRecords(i)
        busText = UCase$(Trim$(CStr(rec(2))))
        deviceKey = UCase$(Trim$(CStr(rec(4))))
        loadAmps = LoadNumberFrom24VText(CStr(rec(6)))
        terminalIndex = Find24VMissingTerminal(state, busText, loadAmps, rec)

        spanFt = Missing24VSpanFeet(state, busText, rec, 0)
        state(busText & "|LOAD") = State24VDouble(state, busText & "|LOAD") + loadAmps
        state(busText & "|LEN") = State24VDouble(state, busText & "|LEN") + spanFt
        Update24VLastXYZ state, busText, rec

        If terminalIndex > 0 Then
            prefix = busText & "|T" & CStr(terminalIndex)
            spanFt = Missing24VSpanFeet(state, busText, rec, terminalIndex)
            state(prefix & "|LOAD") = State24VDouble(state, prefix & "|LOAD") + loadAmps
            state(prefix & "|LEN") = State24VDouble(state, prefix & "|LEN") + spanFt
            Update24VLastXYZ state, prefix, rec
        End If
        state(busText & "|DEVICE|" & deviceKey) = terminalIndex
    Next i
    state("DEVICECOUNT") = State24VDouble(state, "DEVICECOUNT") + 1#
End Sub

Private Function Missing24VSpanFeet(ByVal state As Object, ByVal busText As String, _
                                    ByVal rec As Variant, ByVal terminalSlot As Long) As Double
    Dim moduleFt As Double, spatialFt As Double, prefix As String
    moduleFt = Record24VModuleFeet(rec)
    If terminalSlot > 0 Then
        prefix = busText & "|T" & CStr(terminalSlot)
    Else
        prefix = busText
    End If
    spatialFt = DistanceFrom24VStateFeet(state, prefix, rec)
    If spatialFt > moduleFt Then Missing24VSpanFeet = spatialFt Else Missing24VSpanFeet = moduleFt
End Function

Private Function DistanceFrom24VStateFeet(ByVal state As Object, ByVal prefix As String, ByVal rec As Variant) As Double
    Dim dx As Double, dy As Double, dz As Double
    If Not Record24VHasXYZ(rec) Then Exit Function
    If Not state.Exists(prefix & "|LASTX") Or Not state.Exists(prefix & "|LASTY") Then Exit Function
    dx = CDbl(rec(13)) - CDbl(state(prefix & "|LASTX"))
    dy = CDbl(rec(14)) - CDbl(state(prefix & "|LASTY"))
    dz = 0#
    If state.Exists(prefix & "|LASTZ") Then dz = CDbl(rec(15)) - CDbl(state(prefix & "|LASTZ"))
    'ONGEN_MECH/PD6 XYZ is millimetres in the current workflow.
    DistanceFrom24VStateFeet = Sqr(dx * dx + dy * dy + dz * dz) / 304.8
End Function

Private Sub Update24VLastXYZ(ByVal state As Object, ByVal prefix As String, ByVal rec As Variant)
    If Not Record24VHasXYZ(rec) Then Exit Sub
    state(prefix & "|LASTX") = CDbl(rec(13))
    state(prefix & "|LASTY") = CDbl(rec(14))
    state(prefix & "|LASTZ") = CDbl(rec(15))
End Sub

Private Function Record24VHasXYZ(ByVal rec As Variant) As Boolean
    On Error GoTo NoXYZ
    If UBound(rec) >= 17 Then Record24VHasXYZ = CBool(rec(17))
NoXYZ:
End Function

Private Function Device24VHasNoLocation(ByVal deviceRecords As Collection) As Boolean
    Dim rec As Variant, i As Long
    For i = 1 To deviceRecords.count
        rec = deviceRecords(i)
        If Record24VHasXYZ(rec) Or Record24VModuleFeet(rec) > 0# Then Exit Function
    Next i
    Device24VHasNoLocation = True
End Function

Private Function Compare24VRecordXYZ(ByVal leftRec As Variant, ByVal rightRec As Variant) As Long
    If Record24VHasXYZ(leftRec) And Record24VHasXYZ(rightRec) Then
        If CDbl(leftRec(13)) < CDbl(rightRec(13)) Then Compare24VRecordXYZ = -1: Exit Function
        If CDbl(leftRec(13)) > CDbl(rightRec(13)) Then Compare24VRecordXYZ = 1: Exit Function
        If CDbl(leftRec(14)) < CDbl(rightRec(14)) Then Compare24VRecordXYZ = -1: Exit Function
        If CDbl(leftRec(14)) > CDbl(rightRec(14)) Then Compare24VRecordXYZ = 1: Exit Function
        If CDbl(leftRec(15)) < CDbl(rightRec(15)) Then Compare24VRecordXYZ = -1: Exit Function
        If CDbl(leftRec(15)) > CDbl(rightRec(15)) Then Compare24VRecordXYZ = 1: Exit Function
    End If
End Function

Private Function Missing24VTerminalSlotFromName(ByVal terminalName As String) As Long
    Dim template As Object, i As Long, n As String
    n = Normalize24VPowerTerminalName(terminalName)
    If Len(n) = 0 Or Is24VMissingText(n) Then Exit Function
    Set template = Get24VPSUTemplate()
    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_24V
        If StrComp(n, Normalize24VPowerTerminalName(CStr(template("TERM" & CStr(i)))), vbTextCompare) = 0 Then
            Missing24VTerminalSlotFromName = i
            Exit Function
        End If
    Next i
End Function

Private Function Assigned24VMissingTerminal(ByVal state As Object, ByVal busText As String, ByVal deviceKey As String) As Long
    Dim keyText As String
    keyText = busText & "|DEVICE|" & deviceKey
    If state.Exists(keyText) Then Assigned24VMissingTerminal = CLng(state(keyText))
End Function

Private Function State24VDouble(ByVal state As Object, ByVal keyText As String) As Double
    If state.Exists(keyText) Then If IsNumeric(state(keyText)) Then State24VDouble = CDbl(state(keyText))
End Function

Private Function Record24VModuleFeet(ByVal rec As Variant) As Double
    On Error GoTo NoLength
    If UBound(rec) >= 12 Then If IsNumeric(rec(12)) Then Record24VModuleFeet = CDbl(rec(12))
NoLength:
End Function

Private Function Missing24VPSULabel(ByVal busText As String, ByVal groupKey As String, ByVal overLimit As Boolean) As String
    Dim parts As Variant, idxText As String
    parts = Split(groupKey, "|")
    If UBound(parts) >= 1 Then idxText = CStr(CLng(val(parts(1))))
    Missing24VPSULabel = "MISSING " & busText & " PSU REQUIRED #" & idxText
    If overLimit Then Missing24VPSULabel = Missing24VPSULabel & " - DEVICE OVER LIMIT"
End Function

Private Function Missing24VTerminalName(ByVal terminalIndex As Long) As String
    Dim template As Object
    Set template = Get24VPSUTemplate()
    If terminalIndex >= 1 And terminalIndex <= PSU_TEMPLATE_TERMINAL_COUNT_24V Then
        Missing24VTerminalName = CStr(template("TERM" & CStr(terminalIndex)))
    End If
End Function

Private Function ModuleLengthFeet24V(ByVal valueIn As Variant) As Double
    Dim rawVal As Double, txt As String, u As String
    Dim explicitlyFeet As Boolean, explicitlyInches As Boolean, explicitlyMM As Boolean

    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function

    If IsNumeric(valueIn) Then
        rawVal = CDbl(valueIn)
        'PD6 Module Length (ML) is an ONGEN_MECH geometry value in millimetres.
        'Do not guess units from magnitude; a 450 mm bed must not become 37.5 ft.
        If rawVal > 0# Then ModuleLengthFeet24V = rawVal / 304.8
        Exit Function
    End If

    txt = Trim$(CStr(valueIn))
    u = UCase$(txt)
    explicitlyFeet = (InStr(1, u, "FT", vbTextCompare) > 0 Or InStr(1, u, "FEET", vbTextCompare) > 0 Or InStr(1, u, "FOOT", vbTextCompare) > 0 Or InStr(1, u, "'", vbBinaryCompare) > 0)
    explicitlyInches = (InStr(1, u, "IN", vbTextCompare) > 0 Or InStr(1, u, Chr$(34), vbBinaryCompare) > 0)
    explicitlyMM = (InStr(1, u, "MM", vbTextCompare) > 0)

    u = Replace(u, "FEET", vbNullString)
    u = Replace(u, "FOOT", vbNullString)
    u = Replace(u, "FT", vbNullString)
    u = Replace(u, "MM", vbNullString)
    u = Replace(u, "INCHES", vbNullString)
    u = Replace(u, "INCH", vbNullString)
    u = Replace(u, "IN", vbNullString)
    u = Replace(u, "'", vbNullString)
    u = Replace(u, Chr$(34), vbNullString)
    u = Replace(u, ",", vbNullString)
    u = Trim$(u)
    If Not IsNumeric(u) Then Exit Function
    rawVal = CDbl(u)
    If rawVal <= 0# Then Exit Function

    If explicitlyFeet Then
        ModuleLengthFeet24V = rawVal
    ElseIf explicitlyInches Then
        ModuleLengthFeet24V = rawVal / 12#
    Else
        'Explicit MM or no unit follows the PD6/ONGEN_MECH millimetre contract.
        ModuleLengthFeet24V = rawVal / 304.8
    End If
End Function

Private Sub Sort24VPanelGroupsDeterministic(ByVal panelGroups As Object)
    Dim pnlKey As Variant, groupKey As Variant, groups As Object
    Dim records As Collection, sortedRecords As Collection
    For Each pnlKey In panelGroups.keys
        Set groups = panelGroups(pnlKey)
        For Each groupKey In groups.keys
            Set records = groups(groupKey)
            Set sortedRecords = Sort24VRecordsCollection(records)
            groups.Remove groupKey
            groups.Add CStr(groupKey), sortedRecords
        Next groupKey
    Next pnlKey
End Sub

Private Function Sort24VRecordsCollection(ByVal records As Collection) As Collection
    Dim arr() As Variant, i As Long, j As Long, tmp As Variant
    Dim out As New Collection
    If records.count = 0 Then Set Sort24VRecordsCollection = out: Exit Function
    ReDim arr(1 To records.count)
    For i = 1 To records.count: arr(i) = records(i): Next i
    For i = 1 To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If Compare24VRecords(arr(i), arr(j)) > 0 Then tmp = arr(i): arr(i) = arr(j): arr(j) = tmp
        Next j
    Next i
    For i = 1 To UBound(arr): out.Add arr(i): Next i
    Set Sort24VRecordsCollection = out
End Function

Private Function Compare24VRecords(ByVal a As Variant, ByVal b As Variant) As Long
    Dim sa As Long, sb As Long
    sa = Record24VSequenceNumber(a): sb = Record24VSequenceNumber(b)
    If sa < sb Then Compare24VRecords = -1: Exit Function
    If sa > sb Then Compare24VRecords = 1: Exit Function
    Compare24VRecords = Compare24VRecordXYZ(a, b)
    If Compare24VRecords = 0 Then Compare24VRecords = StrComp(CStr(a(4)), CStr(b(4)), vbTextCompare)
End Function

Private Sub Write24VMissingPSURegister(ByVal panelGroups As Object)
    Const SH_MISSING As String = "PSU_MISSING_REQUIREMENTS"
    Dim ws As Worksheet, rows As Collection, seen As Object
    Dim pnlKey As Variant, groupKey As Variant, groups As Object, records As Collection
    Dim rec As Variant, i As Long, k As String, busText As String, psuText As String
    Dim item As Variant, data() As Variant, r As Long, groupParts As Variant
    Dim totalLoad As Double, deviceList As String, termList As String

    Set rows = New Collection
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare

    For Each pnlKey In panelGroups.keys
        Set groups = panelGroups(pnlKey)
        For Each groupKey In groups.keys
            Set records = groups(groupKey)
            For i = 1 To records.count
                rec = records(i)
                psuText = CStr(rec(3))
                If Is24VMissingText(psuText) Then
                    busText = UCase$(Trim$(CStr(rec(2))))
                    k = CStr(pnlKey) & "|" & CStr(groupKey) & "|" & busText & "|" & UCase$(psuText)
                    If Not seen.Exists(k) Then
                        seen.Add k, True
                        totalLoad = Sum24VMissingSectionLoad(records, busText, psuText)
                        deviceList = List24VMissingSectionDevices(records, busText, psuText)
                        termList = List24VMissingSectionTerminals(records, busText, psuText)
                        groupParts = Split(CStr(groupKey), "|")
                        rows.Add Array(CStr(pnlKey), CStr(groupParts(0)), busText, psuText, totalLoad, termList, deviceList)
                    End If
                End If
            Next i
        Next groupKey
    Next pnlKey

    Set ws = EnsureSheet(SH_MISSING)
    NAV_Ensure_Return_To_MAIN_Button ws, False
    ws.Cells.Clear
    ws.Range("A1:G1").Value2 = Array("Panel / Virtual Panel", "SwitchGroup", "Bus", "Missing PSU Requirement", "Estimated Load (A)", "Planned Terminals", "Powered Devices")
    StyleHeader ws.Range("A1:G1")
    If rows.count = 0 Then
        ws.Range("A2:G2").Merge
        ws.Range("A2").Value2 = "No missing PSU requirements were generated."
    Else
        ReDim data(1 To rows.count, 1 To 7)
        For r = 1 To rows.count
            item = rows(r)
            For i = 0 To 6: data(r, i + 1) = item(i): Next i
        Next r
        ws.Range("A2:G" & CStr(rows.count + 1)).Value2 = data
    End If
    ws.Columns("A:G").AutoFit
    ws.Columns("F:G").columnWidth = 45
    ws.Columns("F:G").WrapText = True
End Sub

Private Function Sum24VMissingSectionLoad(ByVal records As Collection, ByVal busText As String, ByVal psuText As String) As Double
    Dim i As Long, rec As Variant
    For i = 1 To records.count
        rec = records(i)
        If StrComp(CStr(rec(2)), busText, vbTextCompare) = 0 And StrComp(CStr(rec(3)), psuText, vbTextCompare) = 0 Then
            Sum24VMissingSectionLoad = Sum24VMissingSectionLoad + LoadNumberFrom24VText(CStr(rec(6)))
        End If
    Next i
End Function

Private Function List24VMissingSectionDevices(ByVal records As Collection, ByVal busText As String, ByVal psuText As String) As String
    Dim i As Long, rec As Variant, s As String, labelText As String
    For i = 1 To records.count
        rec = records(i)
        If StrComp(CStr(rec(2)), busText, vbTextCompare) = 0 And StrComp(CStr(rec(3)), psuText, vbTextCompare) = 0 Then
            labelText = CStr(rec(4))
            If InStr(1, "," & s & ",", "," & labelText & ",", vbTextCompare) = 0 Then
                If Len(s) > 0 Then s = s & ", "
                s = s & labelText
            End If
        End If
    Next i
    List24VMissingSectionDevices = s
End Function

Private Function List24VMissingSectionTerminals(ByVal records As Collection, ByVal busText As String, ByVal psuText As String) As String
    Dim i As Long, rec As Variant, s As String, t As String
    For i = 1 To records.count
        rec = records(i)
        If StrComp(CStr(rec(2)), busText, vbTextCompare) = 0 And StrComp(CStr(rec(3)), psuText, vbTextCompare) = 0 Then
            t = CStr(rec(10))
            If Len(t) > 0 And InStr(1, "," & s & ",", "," & t & ",", vbTextCompare) = 0 Then
                If Len(s) > 0 Then s = s & ", "
                s = s & t
            End If
        End If
    Next i
    List24VMissingSectionTerminals = s
End Function

Private Sub Add24VSupplementalDevicesFromIOList(ByVal panelGroups As Object, ByVal wsPD6 As Worksheet, _
        ByVal mapBlock As Object, ByVal mapTin As Object, ByVal mapTout As Object, _
        ByVal mapInside As Object, ByVal mapTypeDesc As Object, ByVal mapRuntimePower As Object, _
        ByRef addedRows As Long)

    Dim wsIO As Worksheet, lr As Long, lc As Long, data As Variant, headers As Object
    Dim cDevice As Long, cType As Long, cPWG As Long, cPanel As Long, cArea As Long
    Dim r As Long, device As String, typ As String, key As String, parentSeq As String
    Dim existing As Object, seen As Object, parentMap As Object, parentInfo As Variant
    Dim buses As Collection, busVal As Variant, loadA As Double, found As Boolean
    Dim pnl As String, pwg As String, areaNum As String, blockName As String, tin As String, tout As String
    Dim typDesc As String, groupKey As String, groups As Object, rec As Variant
    Dim xVal As Double, yVal As Double, zVal As Double, moduleFt As Double, xyzKnown As Boolean

    Set wsIO = GetSheetIfExists("IO_DEVICE_LIST")
    If wsIO Is Nothing Then Exit Sub
    Set existing = Build24VExistingDeviceKeyMap(wsPD6)
    Set parentMap = Build24VParentLocationMap(wsPD6)
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare

    lr = LastUsedRow(wsIO): lc = LastUsedColAnyRow24V(wsIO)
    If lr < 2 Or lc < 1 Then Exit Sub
    data = wsIO.Range(wsIO.Cells(1, 1), wsIO.Cells(lr, lc)).Value2
    Set headers = Build24VHeaderMapFast(data, lc)
    cDevice = HeaderCol24VFast(headers, "Device", "DEVICE NAME", "Device Name")
    cType = HeaderCol24VFast(headers, "Device Type", "TYPE", "Item Type")
    cPWG = HeaderCol24VFast(headers, "PWG", "SwitchGroup")
    cPanel = HeaderCol24VFast(headers, "Panel", "PNL")
    cArea = HeaderCol24VFast(headers, "Location", "AREA_Number", "AREA_NUMBER")
    If cDevice = 0 Or cType = 0 Then Exit Sub

    For r = 2 To lr
        device = ArrayText24VFast(data, r, cDevice)
        typ = ArrayText24VFast(data, r, cType)
        If Len(device) = 0 Or Len(typ) = 0 Then GoTo NextSupplemental
        key = UCase$(Trim$(device)) & "|" & Runtime24VTypeKey(typ)
        If seen.Exists(key) Then GoTo NextSupplemental
        seen.Add key, True
        If existing.Exists(UCase$(Trim$(device))) Then GoTo NextSupplemental

        Set buses = Runtime24VBusesForType(mapRuntimePower, typ)
        If buses.count = 0 Then GoTo NextSupplemental

        parentSeq = ParentSISForSupplement24V(device, typ)
        parentInfo = Empty
        If parentMap.Exists(UCase$(parentSeq)) Then
            parentInfo = parentMap(UCase$(parentSeq))
        ElseIf Len(ParentRootKey24V(parentSeq)) > 0 Then
            If parentMap.Exists(ParentRootKey24V(parentSeq)) Then parentInfo = parentMap(ParentRootKey24V(parentSeq))
        End If

        areaNum = ArrayText24VFast(data, r, cArea)
        pwg = ArrayText24VFast(data, r, cPWG)
        pnl = ArrayText24VFast(data, r, cPanel)
        moduleFt = 0#: xVal = 0#: yVal = 0#: zVal = 0#: xyzKnown = False
        If IsArray(parentInfo) Then
            If Len(CStr(parentInfo(0))) > 0 Then areaNum = CStr(parentInfo(0))
            If Len(CStr(parentInfo(1))) > 0 Then pwg = CStr(parentInfo(1))
            If Len(CStr(parentInfo(2))) > 0 Then pnl = CStr(parentInfo(2))
            moduleFt = CDbl(parentInfo(3))
            xVal = CDbl(parentInfo(4)): yVal = CDbl(parentInfo(5)): zVal = CDbl(parentInfo(6))
            xyzKnown = CBool(parentInfo(7))
        End If
        If Len(pwg) = 0 Then pwg = "PWG-UNKNOWN"
        If Len(pnl) = 0 Then pnl = Build24VVirtualPanelKey(areaNum, pwg)

        blockName = GetPowerMapValueLocal(mapBlock, typ, "HDV1T6_GENERIC")
        tin = GetPowerMapValueLocal(mapTin, typ, "X4TERM01")
        tout = GetPowerMapValueLocal(mapTout, typ, "X1TERM02")
        typDesc = Get24VTypeDesc(mapTypeDesc, typ)

        For Each busVal In buses
            found = False
            loadA = Runtime24VLoadForType(mapRuntimePower, typ, CStr(busVal), found)
            If Not found Or loadA <= 0# Then GoTo NextSupplementalBus
            groupKey = pwg & "|0000"
            rec = Array(pnl, pwg, CStr(busVal), "MISSING", device, typDesc, _
                        Format24VLoadValue(loadA, CStr(busVal) = "BUS-1"), blockName, tin, tout, _
                        "", "", moduleFt, xVal, yVal, zVal, parentSeq, xyzKnown)
            If Not panelGroups.Exists(pnl) Then
                Set groups = CreateObject("Scripting.Dictionary"): groups.CompareMode = vbTextCompare
                panelGroups.Add pnl, groups
            Else
                Set groups = panelGroups(pnl)
            End If
            Add24VRecordToGroup groups, groupKey, rec
            addedRows = addedRows + 1
NextSupplementalBus:
        Next busVal
NextSupplemental:
    Next r
End Sub

Private Function Build24VExistingDeviceKeyMap(ByVal wsPD6 As Worksheet) As Object
    Dim d As Object, lr As Long, lc As Long, data As Variant, h As Object, r As Long
    Dim cControl As Long, cElem As Long, cSeq As Long, s As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    lr = LastUsedRow(wsPD6): lc = LastUsedColAnyRow24V(wsPD6)
    If lr < 2 Then Set Build24VExistingDeviceKeyMap = d: Exit Function
    data = wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(lr, lc)).Value2
    Set h = Build24VHeaderMapFast(data, lc)
    cControl = HeaderCol24VFast(h, "Control_ID", "CONTROL_ID")
    cElem = HeaderCol24VFast(h, "SIS_Element_Number", "SIS_ELEMENT_NUMBER")
    cSeq = HeaderCol24VFast(h, "SIS_sequence", "SIS_SEQUENCE")
    For r = 2 To lr
        'Keep every PD6 identity alias so a supplemental I/O record is not
        'duplicated merely because Control_ID is populated ahead of SIS element.
        s = ArrayText24VFast(data, r, cControl)
        If Len(s) > 0 Then d(UCase$(Trim$(s))) = True
        s = ArrayText24VFast(data, r, cElem)
        If Len(s) > 0 Then d(UCase$(Trim$(s))) = True
        s = ArrayText24VFast(data, r, cSeq)
        If Len(s) > 0 Then d(UCase$(Trim$(s))) = True
    Next r
    Set Build24VExistingDeviceKeyMap = d
End Function

Private Function Build24VParentLocationMap(ByVal wsPD6 As Worksheet) As Object
    Dim d As Object, lr As Long, lc As Long, data As Variant, h As Object, r As Long
    Dim cSeq As Long, cArea As Long, cPWG As Long, cPNL As Long, cML As Long, cX As Long, cY As Long, cZ As Long
    Dim seq As String, xVal As Double, yVal As Double, zVal As Double, xyzKnown As Boolean
    Dim info As Variant, existingInfo As Variant, rootKey As String, exactKey As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    lr = LastUsedRow(wsPD6): lc = LastUsedColAnyRow24V(wsPD6)
    If lr < 2 Then Set Build24VParentLocationMap = d: Exit Function
    data = wsPD6.Range(wsPD6.Cells(1, 1), wsPD6.Cells(lr, lc)).Value2
    Set h = Build24VHeaderMapFast(data, lc)
    cSeq = HeaderCol24VFast(h, "SIS_sequence", "SIS_SEQUENCE")
    cArea = HeaderCol24VFast(h, "Area_Number", "AREA_NUMBER")
    cPWG = HeaderCol24VFast(h, "SwitchGroup", "PWG")
    cPNL = HeaderCol24VFast(h, "PNL", "Panel")
    cML = HeaderCol24VFast(h, "Module Length (ML)", "ML")
    cX = HeaderCol24VFast(h, "X"): cY = HeaderCol24VFast(h, "Y"): cZ = HeaderCol24VFast(h, "Z")
    For r = 2 To lr
        seq = ArrayText24VFast(data, r, cSeq)
        If Len(seq) > 0 Then
            xyzKnown = Read24VXYZFromArray(data, r, cX, cY, cZ, xVal, yVal, zVal)
            info = Array(ArrayText24VFast(data, r, cArea), ArrayText24VFast(data, r, cPWG), _
                         ArrayText24VFast(data, r, cPNL), ModuleLengthFeet24V(ArrayValue24VFast(data, r, cML)), _
                         xVal, yVal, zVal, xyzKnown)
            exactKey = UCase$(Trim$(seq))
            If Not d.Exists(exactKey) Then d(exactKey) = info

            'IO modules commonly use 1060 while the conveyor is 1060-01B.
            'Store the numeric conveyor root as a fallback location alias.
            rootKey = ParentRootKey24V(seq)
            If Len(rootKey) > 0 Then
                If Not d.Exists(rootKey) Then
                    d(rootKey) = info
                Else
                    existingInfo = d(rootKey)
                    If xyzKnown And Not CBool(existingInfo(7)) Then d(rootKey) = info
                End If
            End If
        End If
    Next r
    Set Build24VParentLocationMap = d
End Function

Private Function ParentSISForSupplement24V(ByVal device As String, ByVal typ As String) As String
    Dim s As String, suffix As String, p As Long
    s = Trim$(device)
    suffix = "-" & Trim$(typ)
    If Len(suffix) > 1 Then
        If Len(s) > Len(suffix) Then
            If StrComp(Right$(s, Len(suffix)), suffix, vbTextCompare) = 0 Then s = Left$(s, Len(s) - Len(suffix))
        End If
    End If
    'Strip common IO block suffixes and module counters.
    p = InStr(1, UCase$(s), "-IO/S", vbTextCompare)
    If p = 0 Then p = InStr(1, UCase$(s), "-IO/D", vbTextCompare)
    If p > 0 Then s = Left$(s, p - 1)
    ParentSISForSupplement24V = s
End Function

Private Function ParentRootKey24V(ByVal sisText As String) As String
    Dim s As String, parts As Variant, i As Long, token As String
    s = UCase$(Trim$(sisText))
    If Len(s) = 0 Then Exit Function
    parts = Split(s, "-")

    'For a plain conveyor SIS sequence use the first numeric token >= 1000.
    'For a full Area-SWG-SIS identifier the same scan naturally reaches the
    'SIS token after the smaller Area/SWG tokens.
    For i = LBound(parts) To UBound(parts)
        token = NumericPrefix24V(CStr(parts(i)))
        If Len(token) > 0 Then
            If CLng(token) >= 1000 Then
                ParentRootKey24V = token
                Exit Function
            End If
        End If
    Next i
End Function

Private Function Count24VGeneratedPSUs(ByVal groups As Object) As Long

    'Counts each assigned physical PSU once per panel, even when the same PSU
    'feeds several device rows. Blank and MISSING values are excluded.
    Dim seen As Object
    Dim groupKey As Variant
    Dim records As Collection
    Dim rec As Variant
    Dim i As Long
    Dim psuText As String
    Dim psuKey As String

    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    For Each groupKey In groups.keys
        Set records = groups(groupKey)
        For i = 1 To records.count
            rec = records(i)
            psuText = Trim$(CStr(rec(3)))
            If Len(psuText) > 0 Then
                If Not Is24VMissingText(psuText) Then
                    psuKey = UCase$(psuText)
                    If Not seen.Exists(psuKey) Then seen.Add psuKey, True
                End If
            End If
        Next i
    Next groupKey

    Count24VGeneratedPSUs = seen.count
End Function

'-------------------------------------------------------------------------------
' Procedure : Count24VMissingPSUByBus
' Scope/Type: Private Function
' Purpose   : Calculates or returns count 24 v missing PSU by bus.
' Parameters:
' groups (Object) - Supplies groups.
' Returns   : Variant.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Count24VMissingPSUByBus. Calculates or returns count 24 v missing PSU by bus.
Private Function Count24VMissingPSUByBus(ByVal groups As Object) As Variant

    'Counts missing PSU instances once per generated PWG section and bus.
    'This avoids counting every device row when several devices share the same missing PSU.

    ' [LINE EXPLANATION] Declares procedure-level storage for bus1Count (Long).
    Dim bus1Count As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for bus2Count (Long).
    Dim bus2Count As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for seen (Object).
    Dim seen As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for groupKey (Variant).
    Dim groupKey As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for records (Collection).
    Dim records As Collection
    ' [LINE EXPLANATION] Declares procedure-level storage for rec (Variant).
    Dim rec As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for busText (String).
    Dim busText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for psuText (String).
    Dim psuText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for missingKey (String).
    Dim missingKey As String

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in seen.
    Set seen = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets seen.CompareMode to vbTextCompare.
    seen.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Loops through each groupKey contained in groups.keys.
    For Each groupKey In groups.keys
        ' [LINE EXPLANATION] Stores the object returned by groups(groupKey) in records.
        Set records = groups(groupKey)
        ' [LINE EXPLANATION] Loops i from 1 through records.count.
        For i = 1 To records.count
            ' [LINE EXPLANATION] Sets rec to records(i).
            rec = records(i)
            ' [LINE EXPLANATION] Sets busText to UCase$(Trim$(CStr(rec(2)))).
            busText = UCase$(Trim$(CStr(rec(2))))
            ' [LINE EXPLANATION] Sets psuText to UCase$(Trim$(CStr(rec(3)))).
            psuText = UCase$(Trim$(CStr(rec(3))))

            ' [LINE EXPLANATION] Starts a conditional block that runs when Len(psuText) = 0 Or psuText = "MISSING" is true.
            If Is24VMissingText(psuText) Then
                ' [LINE EXPLANATION] Sets missingKey to CStr(groupKey) & "|" & busText.
                missingKey = CStr(groupKey) & "|" & busText
                ' [LINE EXPLANATION] Starts a conditional block that runs when Not seen.Exists(missingKey) is true.
                If Not seen.Exists(missingKey) Then
                    ' [LINE EXPLANATION] Adds an item to seen using missingKey, True.
                    seen.Add missingKey, True
                    ' [LINE EXPLANATION] Starts a conditional block that runs when busText = "BUS-1" is true.
                    If busText = "BUS-1" Then
                        ' [LINE EXPLANATION] Sets bus1Count to bus1Count + 1.
                        bus1Count = bus1Count + 1
                    ' [LINE EXPLANATION] Tests the next alternative condition: busText = "BUS-2".
                    ElseIf busText = "BUS-2" Then
                        ' [LINE EXPLANATION] Sets bus2Count to bus2Count + 1.
                        bus2Count = bus2Count + 1
                    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                    End If
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Advances the i loop to its next iteration.
        Next i
    ' [LINE EXPLANATION] Advances the groupKey loop to its next iteration.
    Next groupKey

    ' [LINE EXPLANATION] Sets the return value of Count24VMissingPSUByBus to Array(bus1Count, bus2Count).
    Count24VMissingPSUByBus = Array(bus1Count, bus2Count)

' [LINE EXPLANATION] Ends function Count24VMissingPSUByBus.
End Function

'-------------------------------------------------------------------------------
' Procedure : Build24VTypeDescMap
' Scope/Type: Private Function
' Purpose   : Builds 24 v type desc map.
' Parameters: None.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Build24VTypeDescMap. Builds 24 v type desc map.
Private Function Build24VTypeDescMap() As Object

    'Reads DATA_IO_BLOCK[TYPE] -> DATA_IO_BLOCK[DESC].
    'The generated 24V sheets still use PD6_IMPORT[TYPE] for logic/block lookup,
    'but display the friendly DESC text in the TYPE columns when available.
    '
    'QUICK FIX 2026-07-02 REV-B:
    '   The previous 24V DESC lookup could still miss DATA_IO_BLOCK in some workbooks
    '   when the table started away from A1 or when the header row was not row 1.
    '   This version:
    '       1) Finds DATA_IO_BLOCK by normalized sheet name.
    '       2) Scans the first 100 rows and up to the last used column for TYPE/DESC.
    '       3) Adds an emergency adjacent-pair scan, so column H=TYPE and I=DESC
    '          is still loaded even if the header band is offset.
    '       4) Adds safe defaults only when DATA_IO_BLOCK does not provide a value.

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet

    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in d.
    Set d = CreateObject("Scripting.Dictionary")
    ' [LINE EXPLANATION] Sets d.CompareMode to vbTextCompare.
    d.CompareMode = vbTextCompare

    ' [LINE EXPLANATION] Stores the object returned by Find24VDataIOBlockSheet() in ws.
    Set ws = Find24VDataIOBlockSheet()
    ' [LINE EXPLANATION] When Not ws Is Nothing is true, executes the inline action Load24VTypeDescFromSheet d, ws.
    If Not ws Is Nothing Then Load24VTypeDescFromSheet d, ws

    ' [LINE EXPLANATION] Calls Add24VDefaultTypeDescValues, which adds 24 v default type desc values, using the supplied argument values.
    Add24VDefaultTypeDescValues d

    ' [LINE EXPLANATION] Stores the object returned by d in Build24VTypeDescMap.
    Set Build24VTypeDescMap = d

' [LINE EXPLANATION] Ends function Build24VTypeDescMap.
End Function

'-------------------------------------------------------------------------------
' Procedure : Load24VTypeDescFromSheet
' Scope/Type: Private Sub
' Purpose   : Loads 24 v type desc from sheet.
' Parameters:
' d (Object) - Supplies d.
' ws (Worksheet) - Supplies worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Load24VTypeDescFromSheet. Loads 24 v type desc from sheet.
Private Sub Load24VTypeDescFromSheet(ByVal d As Object, ByVal ws As Worksheet)

    'Primary load uses the discovered TYPE and DESC headers.
    'Secondary load scans adjacent cells as a safety net for shifted tables.

    ' [LINE EXPLANATION] Declares procedure-level storage for cType (Long).
    Dim cType As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for cDesc (Long).
    Dim cDesc As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for headerRow (Long).
    Dim headerRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for LastRow (Long).
    Dim lastRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for c (Long).
    Dim c As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for typeRaw (String).
    Dim typeRaw As String
    ' [LINE EXPLANATION] Declares procedure-level storage for descRaw (String).
    Dim descRaw As String

    ' [LINE EXPLANATION] When d Is Nothing is true, executes the inline action Exit Sub.
    If d Is Nothing Then Exit Sub
    ' [LINE EXPLANATION] When ws Is Nothing is true, executes the inline action Exit Sub.
    If ws Is Nothing Then Exit Sub

    ' [LINE EXPLANATION] Sets headerRow to Find24VTypeDescHeader(ws, cType, cDesc).
    headerRow = Find24VTypeDescHeader(ws, cType, cDesc)
    ' [LINE EXPLANATION] Sets LastRow to LastUsedRow(ws).
    lastRow = LastUsedRow(ws)

    ' [LINE EXPLANATION] Starts a conditional block that runs when headerRow > 0 And cType > 0 And cDesc > 0 is true.
    If headerRow > 0 And cType > 0 And cDesc > 0 Then
        ' [LINE EXPLANATION] Loops r from headerRow + 1 through LastRow.
        For r = headerRow + 1 To lastRow
            ' [LINE EXPLANATION] Sets typeRaw to Trim$(CStr(ws.Cells(r, cType).value)).
            typeRaw = Trim$(CStr(ws.Cells(r, cType).value))
            ' [LINE EXPLANATION] Sets descRaw to Trim$(CStr(ws.Cells(r, cDesc).value)).
            descRaw = Trim$(CStr(ws.Cells(r, cDesc).value))
            ' [LINE EXPLANATION] Calls Add24VTypeDescKey, which adds 24 v type desc key, using the supplied argument values.
            Add24VTypeDescKey d, typeRaw, descRaw
        ' [LINE EXPLANATION] Advances the r loop to its next iteration.
        Next r
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    'Emergency safety net:
    'Some DATA_IO_BLOCK sheets have the Type/DESC table offset to columns H:I.
    'This pass loads any simple adjacent Type -> Desc pair across the used range.
    ' [LINE EXPLANATION] Sets lastCol to LastUsedColAnyRow24V(ws).
    lastCol = LastUsedColAnyRow24V(ws)
    ' [LINE EXPLANATION] When lastCol < 2 is true, executes the inline action Exit Sub.
    If lastCol < 2 Then Exit Sub

    ' [LINE EXPLANATION] Loops r from 1 through LastRow.
    For r = 1 To lastRow
        ' [LINE EXPLANATION] Loops c from 1 through lastCol - 1.
        For c = 1 To lastCol - 1
            ' [LINE EXPLANATION] Sets typeRaw to Trim$(CStr(ws.Cells(r, c).value)).
            typeRaw = Trim$(CStr(ws.Cells(r, c).value))
            ' [LINE EXPLANATION] Sets descRaw to Trim$(CStr(ws.Cells(r, c + 1).value)).
            descRaw = Trim$(CStr(ws.Cells(r, c + 1).value))

            ' [LINE EXPLANATION] Starts a conditional block that runs when IsLikely24VTypeValue(typeRaw) is true.
            If IsLikely24VTypeValue(typeRaw) Then
                ' [LINE EXPLANATION] Starts a conditional block that runs when Not Is24VTypeDescHeaderText(typeRaw) is true.
                If Not Is24VTypeDescHeaderText(typeRaw) Then
                    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(descRaw) > 0 And Not Is24VTypeDescHeaderText(descRaw) is true.
                    If Len(descRaw) > 0 And Not Is24VTypeDescHeaderText(descRaw) Then
                        ' [LINE EXPLANATION] Calls Add24VTypeDescKey, which adds 24 v type desc key, using the supplied argument values.
                        Add24VTypeDescKey d, typeRaw, descRaw
                    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                    End If
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Advances the c loop to its next iteration.
        Next c
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

' [LINE EXPLANATION] Ends procedure Load24VTypeDescFromSheet.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Find24VDataIOBlockSheet
' Scope/Type: Private Function
' Purpose   : Finds 24 v data IO block sheet.
' Parameters: None.
' Returns   : Worksheet.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Find24VDataIOBlockSheet. Finds 24 v data IO block sheet.
Private Function Find24VDataIOBlockSheet() As Worksheet

    'Find DATA_IO_BLOCK even if workbook tab spacing/case is slightly different.

    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for targetKey (String).
    Dim targetKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for sheetKey (String).
    Dim sheetKey As String

    ' [LINE EXPLANATION] Sets targetKey to HeaderKey24V(SH_DATA_IO_BLOCK_LOCAL).
    targetKey = HeaderKey24V(SH_DATA_IO_BLOCK_LOCAL)

    ' [LINE EXPLANATION] Loops through each ws contained in ThisWorkbook.Worksheets.
    For Each ws In ThisWorkbook.Worksheets
        ' [LINE EXPLANATION] Sets sheetKey to HeaderKey24V(ws.name).
        sheetKey = HeaderKey24V(ws.Name)
        ' [LINE EXPLANATION] Starts a conditional block that runs when sheetKey = targetKey is true.
        If sheetKey = targetKey Then
            ' [LINE EXPLANATION] Stores the object returned by ws in Find24VDataIOBlockSheet.
            Set Find24VDataIOBlockSheet = ws
            ' [LINE EXPLANATION] Returns immediately from Find24VDataIOBlockSheet using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the ws loop to its next iteration.
    Next ws

    'Fallback to the shared exact-name helper.
    ' [LINE EXPLANATION] Stores the object returned by GetSheetIfExists(SH_DATA_IO_BLOCK_LOCAL) in Find24VDataIOBlockSheet.
    Set Find24VDataIOBlockSheet = GetSheetIfExists(SH_DATA_IO_BLOCK_LOCAL)

' [LINE EXPLANATION] Ends function Find24VDataIOBlockSheet.
End Function

'-------------------------------------------------------------------------------
' Procedure : Get24VTypeDescCached
' Scope/Type: Private Function
' Purpose   : Returns 24 v type desc cached.
' Parameters:
' typeText (String) - Supplies type text.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get24VTypeDescCached. Returns 24 v type desc cached.
Private Function Get24VTypeDescCached(ByVal typeText As String) As String

    'Final safety lookup used while writing rows.
    'This prevents a raw "MC" from being written if the record was built before
    'the map was populated or if an older record path passed raw TYPE text.

    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Static d As Object

    ' [LINE EXPLANATION] When d Is Nothing is true, executes the inline action Set d = Build24VTypeDescMap().
    If d Is Nothing Then Set d = Build24VTypeDescMap()
    ' [LINE EXPLANATION] Sets the return value of Get24VTypeDescCached to Get24VTypeDesc(d, typeText).
    Get24VTypeDescCached = Get24VTypeDesc(d, typeText)

' [LINE EXPLANATION] Ends function Get24VTypeDescCached.
End Function

'-------------------------------------------------------------------------------
' Procedure : Get24VTypeDesc
' Scope/Type: Private Function
' Purpose   : Returns 24 v type desc.
' Parameters:
' mapTypeDesc (Object) - Supplies map type desc.
' typeText (String) - Supplies type text.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get24VTypeDesc. Returns 24 v type desc.
Private Function Get24VTypeDesc(ByVal mapTypeDesc As Object, ByVal typeText As String) As String

    'Return the friendly description for a PD6_IMPORT type.
    'Fallback is always the original type so generation does not fail if
    'DATA_IO_BLOCK is missing or the type is not listed.
    '
    'Lookup order is exact key first, then generic power key.
    'Example: VFD_MC should resolve before the generic VFD rule.

    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String
    ' [LINE EXPLANATION] Declares procedure-level storage for firstToken (String).
    Dim firstToken As String

    ' [LINE EXPLANATION] Sets the return value of Get24VTypeDesc to typeText.
    Get24VTypeDesc = typeText
    ' [LINE EXPLANATION] When mapTypeDesc Is Nothing is true, executes the inline action Exit Function.
    If mapTypeDesc Is Nothing Then Exit Function

    ' [LINE EXPLANATION] Sets k to TypeDescKey24V(typeText).
    k = TypeDescKey24V(typeText)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
    If Len(k) > 0 Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when mapTypeDesc.Exists(k) is true.
        If mapTypeDesc.Exists(k) Then
            ' [LINE EXPLANATION] Sets the return value of Get24VTypeDesc to CStr(mapTypeDesc(k)).
            Get24VTypeDesc = CStr(mapTypeDesc(k))
            ' [LINE EXPLANATION] Returns immediately from Get24VTypeDesc using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets k to PowerMapKey(typeText).
    k = PowerMapKey(typeText)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
    If Len(k) > 0 Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when mapTypeDesc.Exists(k) is true.
        If mapTypeDesc.Exists(k) Then
            ' [LINE EXPLANATION] Sets the return value of Get24VTypeDesc to CStr(mapTypeDesc(k)).
            Get24VTypeDesc = CStr(mapTypeDesc(k))
            ' [LINE EXPLANATION] Returns immediately from Get24VTypeDesc using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets firstToken to FirstTypeToken24V(typeText).
    firstToken = FirstTypeToken24V(typeText)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(firstToken) > 0 is true.
    If Len(firstToken) > 0 Then
        ' [LINE EXPLANATION] Sets k to TypeDescKey24V(firstToken).
        k = TypeDescKey24V(firstToken)
        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
        If Len(k) > 0 Then
            ' [LINE EXPLANATION] Starts a conditional block that runs when mapTypeDesc.Exists(k) is true.
            If mapTypeDesc.Exists(k) Then
                ' [LINE EXPLANATION] Sets the return value of Get24VTypeDesc to CStr(mapTypeDesc(k)).
                Get24VTypeDesc = CStr(mapTypeDesc(k))
                ' [LINE EXPLANATION] Returns immediately from Get24VTypeDesc using its current return value.
                Exit Function
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If

        ' [LINE EXPLANATION] Sets k to PowerMapKey(firstToken).
        k = PowerMapKey(firstToken)
        ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
        If Len(k) > 0 Then
            ' [LINE EXPLANATION] Starts a conditional block that runs when mapTypeDesc.Exists(k) is true.
            If mapTypeDesc.Exists(k) Then
                ' [LINE EXPLANATION] Sets the return value of Get24VTypeDesc to CStr(mapTypeDesc(k)).
                Get24VTypeDesc = CStr(mapTypeDesc(k))
                ' [LINE EXPLANATION] Returns immediately from Get24VTypeDesc using its current return value.
                Exit Function
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Get24VTypeDesc.
End Function

'-------------------------------------------------------------------------------
' Procedure : Find24VTypeDescHeader
' Scope/Type: Private Function
' Purpose   : Finds 24 v type desc header.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' cType (Long) - Supplies c type.
' cDesc (Long) - Supplies c desc.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Find24VTypeDescHeader. Finds 24 v type desc header.
Private Function Find24VTypeDescHeader(ByVal ws As Worksheet, ByRef cType As Long, ByRef cDesc As Long) As Long

    'Find TYPE and DESC headers in the first 100 rows of DATA_IO_BLOCK.
    'Returns the header row and passes the matching column numbers back.

    ' [LINE EXPLANATION] Declares procedure-level storage for maxRow (Long).
    Dim maxRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for c (Long).
    Dim c As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for lastCol (Long).
    Dim lastCol As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for h (String).
    Dim h As String

    ' [LINE EXPLANATION] Sets cType to 0.
    cType = 0
    ' [LINE EXPLANATION] Sets cDesc to 0.
    cDesc = 0
    ' [LINE EXPLANATION] Sets the return value of Find24VTypeDescHeader to 0.
    Find24VTypeDescHeader = 0

    ' [LINE EXPLANATION] Sets maxRow to LastUsedRow(ws).
    maxRow = LastUsedRow(ws)
    ' [LINE EXPLANATION] When maxRow > 100 is true, executes the inline action maxRow = 100.
    If maxRow > 100 Then maxRow = 100

    ' [LINE EXPLANATION] Loops r from 1 through maxRow.
    For r = 1 To maxRow
        ' [LINE EXPLANATION] Sets lastCol to LastUsedCol(ws, r).
        lastCol = LastUsedCol(ws, r)
        ' [LINE EXPLANATION] When lastCol < 10 is true, executes the inline action lastCol = 10.
        If lastCol < 10 Then lastCol = 10
        ' [LINE EXPLANATION] When lastCol > 100 is true, executes the inline action lastCol = 100.
        If lastCol > 100 Then lastCol = 100

        ' [LINE EXPLANATION] Sets cType to 0.
        cType = 0
        ' [LINE EXPLANATION] Sets cDesc to 0.
        cDesc = 0

        ' [LINE EXPLANATION] Loops c from 1 through lastCol.
        For c = 1 To lastCol
            ' [LINE EXPLANATION] Sets h to HeaderKey24V(ws.Cells(r, c).value).
            h = HeaderKey24V(ws.Cells(r, c).value)

            ' [LINE EXPLANATION] Starts a conditional block that runs when h = "TYPE" Or h = "DEVICETYPE" is true.
            If h = "TYPE" Or h = "DEVICETYPE" Then
                ' [LINE EXPLANATION] When cType = 0 is true, executes the inline action cType = c.
                If cType = 0 Then cType = c
            ' [LINE EXPLANATION] Tests the next alternative condition: h = "DESC" Or h = "DESCRIPTION" Or h = "TYPEDESCRIPTION".
            ElseIf h = "DESC" Or h = "DESCRIPTION" Or h = "TYPEDESCRIPTION" Then
                ' [LINE EXPLANATION] When cDesc = 0 is true, executes the inline action cDesc = c.
                If cDesc = 0 Then cDesc = c
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Advances the c loop to its next iteration.
        Next c

        ' [LINE EXPLANATION] Starts a conditional block that runs when cType > 0 And cDesc > 0 is true.
        If cType > 0 And cDesc > 0 Then
            ' [LINE EXPLANATION] Sets the return value of Find24VTypeDescHeader to r.
            Find24VTypeDescHeader = r
            ' [LINE EXPLANATION] Returns immediately from Find24VTypeDescHeader using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

' [LINE EXPLANATION] Ends function Find24VTypeDescHeader.
End Function

'-------------------------------------------------------------------------------
' Procedure : LastUsedColAnyRow24V
' Scope/Type: Private Function
' Purpose   : Returns the last used column any row 24 v.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function LastUsedColAnyRow24V. Returns the last used column any row 24 v.
Private Function LastUsedColAnyRow24V(ByVal ws As Worksheet) As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for f (Range).
    Dim f As Range

    ' [LINE EXPLANATION] Temporarily suppresses runtime errors so the next optional or cleanup operation can be attempted safely; Err should be checked or normal handling restored afterward.
    On Error Resume Next
    ' [LINE EXPLANATION] Stores the object returned by ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious) in f.
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    ' [LINE EXPLANATION] Turns off the temporary error handler and restores normal VBA error behavior.
    On Error GoTo 0

    ' [LINE EXPLANATION] Starts a conditional block that runs when f Is Nothing is true.
    If f Is Nothing Then
        ' [LINE EXPLANATION] Sets the return value of LastUsedColAnyRow24V to 1.
        LastUsedColAnyRow24V = 1
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of LastUsedColAnyRow24V to f.Column.
        LastUsedColAnyRow24V = f.Column
        ' [LINE EXPLANATION] When LastUsedColAnyRow24V > 100 is true, executes the inline action LastUsedColAnyRow24V = 100.
        If LastUsedColAnyRow24V > 100 Then LastUsedColAnyRow24V = 100
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function LastUsedColAnyRow24V.
End Function

'-------------------------------------------------------------------------------
' Procedure : Is24VTypeDescHeaderText
' Scope/Type: Private Function
' Purpose   : Checks whether 24 v type desc header text.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Is24VTypeDescHeaderText. Checks whether 24 v type desc header text.
Private Function Is24VTypeDescHeaderText(ByVal valueIn As String) As Boolean

    ' [LINE EXPLANATION] Declares procedure-level storage for h (String).
    Dim h As String

    ' [LINE EXPLANATION] Sets h to HeaderKey24V(valueIn).
    h = HeaderKey24V(valueIn)
    ' [LINE EXPLANATION] Sets the return value of Is24VTypeDescHeaderText to (h = "TYPE" Or h = "DESC" Or h = "DESCRIPTION" Or h = "TYPEDESC" Or h = "TYPEDESCRIPTION").
    Is24VTypeDescHeaderText = (h = "TYPE" Or h = "DESC" Or h = "DESCRIPTION" Or h = "TYPEDESC" Or h = "TYPEDESCRIPTION")

' [LINE EXPLANATION] Ends function Is24VTypeDescHeaderText.
End Function

'-------------------------------------------------------------------------------
' Procedure : IsLikely24VTypeValue
' Scope/Type: Private Function
' Purpose   : Checks whether likely 24 v type value.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function IsLikely24VTypeValue. Checks whether likely 24 v type value.
Private Function IsLikely24VTypeValue(ByVal valueIn As String) As Boolean

    'Keep the emergency adjacent-pair scan from loading titles or long notes.

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String
    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String

    ' [LINE EXPLANATION] Sets s to Trim$(valueIn).
    s = Trim$(valueIn)
    ' [LINE EXPLANATION] When Len(s) = 0 is true, executes the inline action Exit Function.
    If Len(s) = 0 Then Exit Function
    ' [LINE EXPLANATION] When Len(s) > 25 is true, executes the inline action Exit Function.
    If Len(s) > 25 Then Exit Function

    ' [LINE EXPLANATION] Sets k to PowerMapKey(s).
    k = PowerMapKey(s)
    ' [LINE EXPLANATION] Starts a multi-branch decision based on k.
    Select Case k
        ' [LINE EXPLANATION] Handles the case where the Select Case expression matches "MC", "MS", "SCN", "SC", "VFD", "VFD_MF", "VFD_MC", "IO_S", "IO_D", "IO", "RIO", "DC20", "PC2", "PBB", "B", "PE", "EN....
        Case "MC", "MS", "SCN", "SC", "VFD", "VFD_MF", "VFD_MC", "IO_S", "IO_D", "IO", "RIO", "DC20", "PC2", "PBB", "B", "PE", "ENC", "EST", "EPC", "PSU"
            ' [LINE EXPLANATION] Sets the return value of IsLikely24VTypeValue to True.
            IsLikely24VTypeValue = True
            ' [LINE EXPLANATION] Returns immediately from IsLikely24VTypeValue using its current return value.
            Exit Function
    ' [LINE EXPLANATION] Ends the current Select Case decision block.
    End Select

    ' [LINE EXPLANATION] Sets k to TypeDescKey24V(s).
    k = TypeDescKey24V(s)
    ' [LINE EXPLANATION] Starts a multi-branch decision based on k.
    Select Case k
        ' [LINE EXPLANATION] Handles the case where the Select Case expression matches "MC", "MS", "SCN", "SCANNER", "VFD", "VFDMF", "VFDMC", "IOS", "IOD", "IO/S", "IO/D", "RIO", "DC20", "PC2", "PBB", "B"....
        Case "MC", "MS", "SCN", "SCANNER", "VFD", "VFDMF", "VFDMC", "IOS", "IOD", "IO/S", "IO/D", "RIO", "DC20", "PC2", "PBB", "B", "PE", "ENC", "EST", "EPC", "PSU"
            ' [LINE EXPLANATION] Sets the return value of IsLikely24VTypeValue to True.
            IsLikely24VTypeValue = True
    ' [LINE EXPLANATION] Ends the current Select Case decision block.
    End Select

' [LINE EXPLANATION] Ends function IsLikely24VTypeValue.
End Function

'-------------------------------------------------------------------------------
' Procedure : Add24VTypeDescKey
' Scope/Type: Private Sub
' Purpose   : Adds 24 v type desc key.
' Parameters:
' d (Object) - Supplies d.
' typeRaw (String) - Supplies type raw.
' descRaw (String) - Supplies desc raw.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Add24VTypeDescKey. Adds 24 v type desc key.
Private Sub Add24VTypeDescKey(ByVal d As Object, ByVal typeRaw As String, ByVal descRaw As String)

    'Store several safe key versions so MC, MC - Text, IO/D, and IO_D all resolve.

    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String
    ' [LINE EXPLANATION] Declares procedure-level storage for firstToken (String).
    Dim firstToken As String

    ' [LINE EXPLANATION] When d Is Nothing is true, executes the inline action Exit Sub.
    If d Is Nothing Then Exit Sub
    ' [LINE EXPLANATION] When Len(Trim$(typeRaw)) = 0 Or Len(Trim$(descRaw)) = 0 is true, executes the inline action Exit Sub.
    If Len(Trim$(typeRaw)) = 0 Or Len(Trim$(descRaw)) = 0 Then Exit Sub

    ' [LINE EXPLANATION] Sets k to PowerMapKey(typeRaw).
    k = PowerMapKey(typeRaw)
    ' [LINE EXPLANATION] When Len(k) > 0 is true, executes the inline action d(k) = descRaw.
    If Len(k) > 0 Then d(k) = descRaw

    ' [LINE EXPLANATION] Sets k to TypeDescKey24V(typeRaw).
    k = TypeDescKey24V(typeRaw)
    ' [LINE EXPLANATION] When Len(k) > 0 is true, executes the inline action d(k) = descRaw.
    If Len(k) > 0 Then d(k) = descRaw

    ' [LINE EXPLANATION] Sets firstToken to FirstTypeToken24V(typeRaw).
    firstToken = FirstTypeToken24V(typeRaw)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(firstToken) > 0 is true.
    If Len(firstToken) > 0 Then
        ' [LINE EXPLANATION] Sets k to PowerMapKey(firstToken).
        k = PowerMapKey(firstToken)
        ' [LINE EXPLANATION] When Len(k) > 0 is true, executes the inline action d(k) = descRaw.
        If Len(k) > 0 Then d(k) = descRaw

        ' [LINE EXPLANATION] Sets k to TypeDescKey24V(firstToken).
        k = TypeDescKey24V(firstToken)
        ' [LINE EXPLANATION] When Len(k) > 0 is true, executes the inline action d(k) = descRaw.
        If Len(k) > 0 Then d(k) = descRaw
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends procedure Add24VTypeDescKey.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Add24VDefaultTypeDescValues
' Scope/Type: Private Sub
' Purpose   : Adds 24 v default type desc values.
' Parameters:
' d (Object) - Supplies d.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Add24VDefaultTypeDescValues. Adds 24 v default type desc values.
Private Sub Add24VDefaultTypeDescValues(ByVal d As Object)

    'Safe defaults are only used when DATA_IO_BLOCK does not provide a matching type.

    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "MC", "MultiControl"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "MS", "MultiControl"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "VFD", "MOVI-FLEXIBLE"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "VFD_MF", "MOVI-FLEXIBLE"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "VFD_MC", "MOVIMOT+MFE72A"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "SCN", "Scanner CDF600-x3xx"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "IO_S", "EP1957-0022"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "IO_D", "EP2339-0042"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "IO/S", "EP1957-0022"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "IO/D", "EP2339-0042"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "PC2", "Class2 Power Block"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "RIO", "RIO-PANEL"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "DC20", "DriveControl 20"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "PE", "Photoelectric Cell"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "ENC", "encoder"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "B", "STACK LIGHT"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "EST", "E-STOP"
    ' [LINE EXPLANATION] Calls Add24VTypeDescDefault, which adds 24 v type desc default, using the supplied argument values.
    Add24VTypeDescDefault d, "EPC", "PULLCORD"

' [LINE EXPLANATION] Ends procedure Add24VDefaultTypeDescValues.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Add24VTypeDescDefault
' Scope/Type: Private Sub
' Purpose   : Adds 24 v type desc default.
' Parameters:
' d (Object) - Supplies d.
' typeRaw (String) - Supplies type raw.
' descRaw (String) - Supplies desc raw.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Add24VTypeDescDefault. Adds 24 v type desc default.
Private Sub Add24VTypeDescDefault(ByVal d As Object, ByVal typeRaw As String, ByVal descRaw As String)

    'Default values must not overwrite DATA_IO_BLOCK values.

    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String

    ' [LINE EXPLANATION] When d Is Nothing is true, executes the inline action Exit Sub.
    If d Is Nothing Then Exit Sub

    ' [LINE EXPLANATION] Sets k to PowerMapKey(typeRaw).
    k = PowerMapKey(typeRaw)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
    If Len(k) > 0 Then
        ' [LINE EXPLANATION] When Not d.Exists(k) is true, executes the inline action d(k) = descRaw.
        If Not d.Exists(k) Then d(k) = descRaw
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets k to TypeDescKey24V(typeRaw).
    k = TypeDescKey24V(typeRaw)
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) > 0 is true.
    If Len(k) > 0 Then
        ' [LINE EXPLANATION] When Not d.Exists(k) is true, executes the inline action d(k) = descRaw.
        If Not d.Exists(k) Then d(k) = descRaw
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends procedure Add24VTypeDescDefault.
End Sub

'-------------------------------------------------------------------------------
' Procedure : FirstTypeToken24V
' Scope/Type: Private Function
' Purpose   : Returns the first type token 24 v.
' Parameters:
' typeText (String) - Supplies type text.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function FirstTypeToken24V. Returns the first type token 24 v.
Private Function FirstTypeToken24V(ByVal typeText As String) As String

    'Extract the leading device type from values like "MC - MultiControl".

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String
    ' [LINE EXPLANATION] Declares procedure-level storage for p (Long).
    Dim p As Long

    ' [LINE EXPLANATION] Sets s to Trim$(typeText).
    s = Trim$(typeText)
    ' [LINE EXPLANATION] When Len(s) = 0 is true, executes the inline action Exit Function.
    If Len(s) = 0 Then Exit Function

    ' [LINE EXPLANATION] Sets p to InStr(1, s, " - ", vbTextCompare).
    p = InStr(1, s, " - ", vbTextCompare)
    ' [LINE EXPLANATION] Starts a conditional block that runs when p > 0 is true.
    If p > 0 Then
        ' [LINE EXPLANATION] Sets the return value of FirstTypeToken24V to Trim$(Left$(s, p - 1)).
        FirstTypeToken24V = Trim$(Left$(s, p - 1))
        ' [LINE EXPLANATION] Returns immediately from FirstTypeToken24V using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets p to InStr(1, s, "-", vbTextCompare).
    p = InStr(1, s, "-", vbTextCompare)
    ' [LINE EXPLANATION] Starts a conditional block that runs when p > 0 is true.
    If p > 0 Then
        ' [LINE EXPLANATION] Sets the return value of FirstTypeToken24V to Trim$(Left$(s, p - 1)).
        FirstTypeToken24V = Trim$(Left$(s, p - 1))
        ' [LINE EXPLANATION] Returns immediately from FirstTypeToken24V using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets p to InStr(1, s, " ", vbTextCompare).
    p = InStr(1, s, " ", vbTextCompare)
    ' [LINE EXPLANATION] Starts a conditional block that runs when p > 0 is true.
    If p > 0 Then
        ' [LINE EXPLANATION] Sets the return value of FirstTypeToken24V to Trim$(Left$(s, p - 1)).
        FirstTypeToken24V = Trim$(Left$(s, p - 1))
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of FirstTypeToken24V to s.
        FirstTypeToken24V = s
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function FirstTypeToken24V.
End Function

'-------------------------------------------------------------------------------
' Procedure : TypeDescKey24V
' Scope/Type: Private Function
' Purpose   : Calculates or returns type desc key 24 v.
' Parameters:
' valueIn (Variant) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function TypeDescKey24V. Calculates or returns type desc key 24 v.
Private Function TypeDescKey24V(ByVal valueIn As Variant) As String

    'Generic key used only for the TYPE/DESC display lookup.

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "_", "/").
    s = Replace(s, "_", "/")
    ' [LINE EXPLANATION] Sets s to Replace(s, "-", "/").
    s = Replace(s, "-", "/")
    ' [LINE EXPLANATION] Sets s to Replace(s, ".", "").
    s = Replace(s, ".", "")

    ' [LINE EXPLANATION] Sets the return value of TypeDescKey24V to s.
    TypeDescKey24V = s

' [LINE EXPLANATION] Ends function TypeDescKey24V.
End Function

'-------------------------------------------------------------------------------
' Procedure : HeaderKey24V
' Scope/Type: Private Function
' Purpose   : Calculates or returns header key 24 v.
' Parameters:
' valueIn (Variant) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function HeaderKey24V. Calculates or returns header key 24 v.
Private Function HeaderKey24V(ByVal valueIn As Variant) As String

    'Local header normalizer so this patch works even in workbooks where the
    'shared HeaderCol helper only checks row 1.

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "_", "").
    s = Replace(s, "_", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "-", "").
    s = Replace(s, "-", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ".", "").
    s = Replace(s, ".", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "#", "").
    s = Replace(s, "#", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "(", "").
    s = Replace(s, "(", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ")", "").
    s = Replace(s, ")", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "/", "").
    s = Replace(s, "/", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "\", "").
    s = Replace(s, "\", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "[", "").
    s = Replace(s, "[", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "]", "").
    s = Replace(s, "]", "")

    ' [LINE EXPLANATION] Sets the return value of HeaderKey24V to s.
    HeaderKey24V = s

' [LINE EXPLANATION] Ends function HeaderKey24V.
End Function

'-------------------------------------------------------------------------------
' Procedure : BusListFromDisplay
' Scope/Type: Private Function
' Purpose   : Calculates or returns bus list from display.
' Parameters:
' busRaw (String) - Supplies bus raw.
' Returns   : Collection.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function BusListFromDisplay. Calculates or returns bus list from display.
Private Function BusListFromDisplay(ByVal busRaw As String) As Collection

    ' [LINE EXPLANATION] Declares procedure-level storage for col (Collection).
    Dim col As Collection
    ' [LINE EXPLANATION] Declares procedure-level storage for u (String).
    Dim u As String

    ' [LINE EXPLANATION] Stores the object returned by New Collection in col.
    Set col = New Collection
    ' [LINE EXPLANATION] Sets u to UCase$(Trim$(busRaw)).
    u = UCase$(Trim$(busRaw))
    ' [LINE EXPLANATION] Sets u to Replace(u, " ", "").
    u = Replace(u, " ", "")

    ' [LINE EXPLANATION] When InStr(1, u, "BUS-1", vbTextCompare) > 0 Or InStr(1, u, "BUS1", vbTextCompare) > 0 is true, executes the inline action col.Add "BUS-1".
    If InStr(1, u, "BUS-1", vbTextCompare) > 0 Or InStr(1, u, "BUS1", vbTextCompare) > 0 Then col.Add "BUS-1"
    ' [LINE EXPLANATION] When InStr(1, u, "BUS-2", vbTextCompare) > 0 Or InStr(1, u, "BUS2", vbTextCompare) > 0 is true, executes the inline action col.Add "BUS-2".
    If InStr(1, u, "BUS-2", vbTextCompare) > 0 Or InStr(1, u, "BUS2", vbTextCompare) > 0 Then col.Add "BUS-2"

    ' [LINE EXPLANATION] Starts a conditional block that runs when col.count = 0 is true.
    If col.count = 0 Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, u, "2", vbTextCompare) > 0 is true.
        If InStr(1, u, "2", vbTextCompare) > 0 Then
            ' [LINE EXPLANATION] Adds an item to col using "BUS-2".
            col.Add "BUS-2"
        ' [LINE EXPLANATION] Tests the next alternative condition: InStr(1, u, "1", vbTextCompare) > 0.
        ElseIf InStr(1, u, "1", vbTextCompare) > 0 Then
            ' [LINE EXPLANATION] Adds an item to col using "BUS-1".
            col.Add "BUS-1"
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Stores the object returned by col in BusListFromDisplay.
    Set BusListFromDisplay = col

' [LINE EXPLANATION] Ends function BusListFromDisplay.
End Function

'-------------------------------------------------------------------------------
' Procedure : BusListFrom24VType
' Scope/Type: Private Function
' Purpose   : Calculates or returns bus list from 24 v type.
' Parameters:
' typeVal (String) - Supplies type value.
' Returns   : Collection.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function BusListFrom24VType. Calculates or returns bus list from 24 v type.
Private Function BusListFrom24VType(ByVal typeVal As String) As Collection

    ' [LINE EXPLANATION] Declares procedure-level storage for buses (Collection).
    Dim buses As Collection
    ' [LINE EXPLANATION] Declares procedure-level storage for t (String).
    Dim t As String

    ' [LINE EXPLANATION] Stores the object returned by New Collection in buses.
    Set buses = New Collection
    ' [LINE EXPLANATION] Sets t to UCase$(Trim$(typeVal)).
    t = UCase$(Trim$(typeVal))
    ' [LINE EXPLANATION] Sets t to Replace(t, " ", "").
    t = Replace(t, " ", "")
    ' [LINE EXPLANATION] Sets t to Replace(t, "_", "/").
    t = Replace(t, "_", "/")

    'Fallback only used when PD6_IMPORT[Bus Power] is blank.
    'This keeps missing-PSU power devices visible in the 24V generator.
    ' [LINE EXPLANATION] Starts a conditional block that runs when t = "MC" Or Left$(t, 2) = "MC" is true.
    If t = "MC" Or Left$(t, 2) = "MC" Then
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-1".
        buses.Add "BUS-1"
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-2".
        buses.Add "BUS-2"
    ' [LINE EXPLANATION] Tests the next alternative condition: t = "MS" Or Left$(t, 2) = "MS".
    ElseIf t = "MS" Or Left$(t, 2) = "MS" Then
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-1".
        buses.Add "BUS-1"
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-2".
        buses.Add "BUS-2"
    ' [LINE EXPLANATION] Tests the next alternative condition: t = "VFD" Or Left$(t, 3) = "VFD".
    ElseIf t = "VFD" Or Left$(t, 3) = "VFD" Then
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-2".
        buses.Add "BUS-2"
    ' [LINE EXPLANATION] Tests the next alternative condition: Left$(t, 2) = "IO".
    ElseIf Left$(t, 2) = "IO" Then
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-2".
        buses.Add "BUS-2"
    ' [LINE EXPLANATION] Tests the next alternative condition: t = "PC2" Or Left$(t, 3) = "PC2".
    ElseIf t = "PC2" Or Left$(t, 3) = "PC2" Then
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-2".
        buses.Add "BUS-2"
    ' [LINE EXPLANATION] Tests the next alternative condition: t = "SCN" Or Left$(t, 3) = "SCN" Or t = "SCANNER" Or Left$(t, 7) = "SCANNER".
    ElseIf t = "SCN" Or Left$(t, 3) = "SCN" Or t = "SCANNER" Or Left$(t, 7) = "SCANNER" Then
        'SCN / SCANNER rows intentionally do not generate 24V power rows.
    ' [LINE EXPLANATION] Tests the next alternative condition: Left$(t, 2) = "SC".
    ElseIf Left$(t, 2) = "SC" Then
        ' [LINE EXPLANATION] Adds an item to buses using "BUS-2".
        buses.Add "BUS-2"
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Stores the object returned by buses in BusListFrom24VType.
    Set BusListFrom24VType = buses

' [LINE EXPLANATION] Ends function BusListFrom24VType.
End Function

'-------------------------------------------------------------------------------
' Procedure : PowerSupplyForBusDisplay
' Scope/Type: Private Function
' Purpose   : Calculates or returns power supply for bus display.
' Parameters:
' psuText (String) - Supplies PSU text.
' busVal (String) - Supplies bus value.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function PowerSupplyForBusDisplay. Calculates or returns power supply for bus display.
Private Function PowerSupplyForBusDisplay(ByVal psuText As String, ByVal busVal As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for parts() (String).
    Dim parts() As String
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for itemText (String).
    Dim itemText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for prefix (String).
    Dim prefix As String

    ' [LINE EXPLANATION] Sets psuText to Trim$(psuText).
    psuText = Trim$(psuText)
    ' [LINE EXPLANATION] Sets busVal to UCase$(Trim$(busVal)).
    busVal = UCase$(Trim$(busVal))
    ' [LINE EXPLANATION] Sets prefix to busVal & "=".
    prefix = busVal & "="

    ' [LINE EXPLANATION] When Len(psuText) = 0 is true, executes the inline action Exit Function.
    If Len(psuText) = 0 Then Exit Function

    ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, UCase$(psuText), "BUS-1=", vbTextCompare) > 0 Or InStr(1, UCase$(psuText), "BUS-2=", vbTextCompare) > 0 is true. This logical statement spans 2 physica...
    If InStr(1, UCase$(psuText), "BUS-1=", vbTextCompare) > 0 Or _
       InStr(1, UCase$(psuText), "BUS-2=", vbTextCompare) > 0 Then

        ' [LINE EXPLANATION] Sets parts to Split(psuText, "|").
        parts = Split(psuText, "|")
        ' [LINE EXPLANATION] Loops i from LBound(parts) through UBound(parts).
        For i = LBound(parts) To UBound(parts)
            ' [LINE EXPLANATION] Sets itemText to Trim$(parts(i)).
            itemText = Trim$(parts(i))
            ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, UCase$(itemText), prefix, vbTextCompare) = 1 is true.
            If InStr(1, UCase$(itemText), prefix, vbTextCompare) = 1 Then
                ' [LINE EXPLANATION] Sets the return value of PowerSupplyForBusDisplay to Trim$(mid$(itemText, Len(prefix) + 1)).
                PowerSupplyForBusDisplay = Trim$(mid$(itemText, Len(prefix) + 1))
                ' [LINE EXPLANATION] Returns immediately from PowerSupplyForBusDisplay using its current return value.
                Exit Function
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Advances the i loop to its next iteration.
        Next i

        ' [LINE EXPLANATION] Sets the return value of PowerSupplyForBusDisplay to "".
        PowerSupplyForBusDisplay = ""
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of PowerSupplyForBusDisplay to psuText.
        PowerSupplyForBusDisplay = psuText
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function PowerSupplyForBusDisplay.
End Function


'-------------------------------------------------------------------------------
' Procedure : Normalize24VGeneratedPSUName
' Scope/Type: Private Function
' Purpose   : Normalizes 24 v generated PSU name.
' Parameters:
' psuName (String) - Supplies PSU name.
' areaNum (String) - Supplies area number.
' switchGroup (String) - Supplies switch group.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Normalize24VGeneratedPSUName. Normalizes 24 v generated PSU name.
Private Function Normalize24VGeneratedPSUName(ByVal psuName As String, ByVal areaNum As String, ByVal switchGroup As String) As String

    'Power Supply values sometimes arrive from PD6_IMPORT as the bare SIS_SEQUENCE,
    'especially when the PSU sequence includes the extension suffix -1 or -2:
    '   1025-PSU-2
    'The generated 24V section must display the full element number:
    '   AREA_NUMBER-SWITCHGROUP-1025-PSU-2
    '
    'Already-qualified values such as 11-102-1025-PSU-2 are left unchanged.

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String
    ' [LINE EXPLANATION] Declares procedure-level storage for areaText (String).
    Dim areaText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for pwgText (String).
    Dim pwgText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for fullPrefix (String).
    Dim fullPrefix As String

    ' [LINE EXPLANATION] Sets s to Trim$(psuName).
    s = Trim$(psuName)
    ' [LINE EXPLANATION] Sets areaText to Trim$(areaNum).
    areaText = Trim$(areaNum)
    ' [LINE EXPLANATION] Sets pwgText to Trim$(switchGroup).
    pwgText = Trim$(switchGroup)

    ' [LINE EXPLANATION] When Len(s) = 0 is true, executes the inline action Exit Function.
    If Len(s) = 0 Then Exit Function
    ' [LINE EXPLANATION] Starts a conditional block that runs when Is24VMissingText(s) is true.
    If Is24VMissingText(s) Then
        ' [LINE EXPLANATION] Sets the return value of Normalize24VGeneratedPSUName to s.
        Normalize24VGeneratedPSUName = s
        ' [LINE EXPLANATION] Returns immediately from Normalize24VGeneratedPSUName using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when Is24VFullyQualifiedPSUName(s) is true.
    If Is24VFullyQualifiedPSUName(s) Then
        ' [LINE EXPLANATION] Sets the return value of Normalize24VGeneratedPSUName to s.
        Normalize24VGeneratedPSUName = s
        ' [LINE EXPLANATION] Returns immediately from Normalize24VGeneratedPSUName using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] When Len(areaText) = 0 is true, executes the inline action areaText = AreaNumberFrom24VElementNumber(s).
    If Len(areaText) = 0 Then areaText = AreaNumberFrom24VElementNumber(s)
    ' [LINE EXPLANATION] When Len(pwgText) = 0 is true, executes the inline action pwgText = SwitchGroupFrom24VElementNumber(s).
    If Len(pwgText) = 0 Then pwgText = SwitchGroupFrom24VElementNumber(s)

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(areaText) = 0 Or Len(pwgText) = 0 is true.
    If Len(areaText) = 0 Or Len(pwgText) = 0 Then
        ' [LINE EXPLANATION] Sets the return value of Normalize24VGeneratedPSUName to s.
        Normalize24VGeneratedPSUName = s
        ' [LINE EXPLANATION] Returns immediately from Normalize24VGeneratedPSUName using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when Is24VMissingText(areaText) Or Is24VMissingText(pwgText) is true.
    If Is24VMissingText(areaText) Or Is24VMissingText(pwgText) Then
        ' [LINE EXPLANATION] Sets the return value of Normalize24VGeneratedPSUName to s.
        Normalize24VGeneratedPSUName = s
        ' [LINE EXPLANATION] Returns immediately from Normalize24VGeneratedPSUName using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when UCase$(pwgText) = "PWG-UNKNOWN" is true.
    If UCase$(pwgText) = "PWG-UNKNOWN" Then
        ' [LINE EXPLANATION] Sets the return value of Normalize24VGeneratedPSUName to s.
        Normalize24VGeneratedPSUName = s
        ' [LINE EXPLANATION] Returns immediately from Normalize24VGeneratedPSUName using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets fullPrefix to areaText & "-" & pwgText & "-".
    fullPrefix = areaText & "-" & pwgText & "-"
    ' [LINE EXPLANATION] Starts a conditional block that runs when UCase$(Left$(s, Len(fullPrefix))) = UCase$(fullPrefix) is true.
    If UCase$(Left$(s, Len(fullPrefix))) = UCase$(fullPrefix) Then
        ' [LINE EXPLANATION] Sets the return value of Normalize24VGeneratedPSUName to s.
        Normalize24VGeneratedPSUName = s
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of Normalize24VGeneratedPSUName to fullPrefix & s.
        Normalize24VGeneratedPSUName = fullPrefix & s
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Normalize24VGeneratedPSUName.
End Function

'-------------------------------------------------------------------------------
' Procedure : Is24VFullyQualifiedPSUName
' Scope/Type: Private Function
' Purpose   : Checks whether 24 v fully qualified PSU name.
' Parameters:
' psuName (String) - Supplies PSU name.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Is24VFullyQualifiedPSUName. Checks whether 24 v fully qualified PSU name.
Private Function Is24VFullyQualifiedPSUName(ByVal psuName As String) As Boolean

    'A fully-qualified generated PSU is AREA-SWITCHGROUP-SEQUENCE-PSU...
    'For the current workflow AREA and SWITCHGROUP are numeric, so this safely
    'distinguishes 11-102-1025-PSU-2 from 1025-PSU-2.

    ' [LINE EXPLANATION] Declares procedure-level storage for parts (Variant).
    Dim parts As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for u (String).
    Dim u As String

    ' [LINE EXPLANATION] Sets u to UCase$(Trim$(psuName)).
    u = UCase$(Trim$(psuName))
    ' [LINE EXPLANATION] When InStr(1, u, "PSU", vbTextCompare) = 0 is true, executes the inline action Exit Function.
    If InStr(1, u, "PSU", vbTextCompare) = 0 Then Exit Function

    ' [LINE EXPLANATION] Sets parts to Split(u, "-").
    parts = Split(u, "-")
    ' [LINE EXPLANATION] When UBound(parts) < 3 is true, executes the inline action Exit Function.
    If UBound(parts) < 3 Then Exit Function

    ' [LINE EXPLANATION] Sets the return value of Is24VFullyQualifiedPSUName to (IsNumeric(CStr(parts(0))) And IsNumeric(CStr(parts(1)))).
    Is24VFullyQualifiedPSUName = (IsNumeric(CStr(parts(0))) And IsNumeric(CStr(parts(1))))

' [LINE EXPLANATION] Ends function Is24VFullyQualifiedPSUName.
End Function

'-------------------------------------------------------------------------------
' Procedure : AreaNumberFrom24VElementNumber
' Scope/Type: Private Function
' Purpose   : Calculates or returns area number from 24 v element number.
' Parameters:
' elementNumber (String) - Supplies element number.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function AreaNumberFrom24VElementNumber. Calculates or returns area number from 24 v element number.
Private Function AreaNumberFrom24VElementNumber(ByVal elementNumber As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for parts (Variant).
    Dim parts As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to Trim$(elementNumber).
    s = Trim$(elementNumber)
    ' [LINE EXPLANATION] When Len(s) = 0 is true, executes the inline action Exit Function.
    If Len(s) = 0 Then Exit Function

    ' [LINE EXPLANATION] Sets parts to Split(s, "-").
    parts = Split(s, "-")
    ' [LINE EXPLANATION] Starts a conditional block that runs when UBound(parts) >= 2 is true.
    If UBound(parts) >= 2 Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when IsNumeric(CStr(parts(0))) And IsNumeric(CStr(parts(1))) is true.
        If IsNumeric(CStr(parts(0))) And IsNumeric(CStr(parts(1))) Then
            ' [LINE EXPLANATION] Sets the return value of AreaNumberFrom24VElementNumber to CStr(parts(0)).
            AreaNumberFrom24VElementNumber = CStr(parts(0))
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function AreaNumberFrom24VElementNumber.
End Function

'-------------------------------------------------------------------------------
' Procedure : SwitchGroupFrom24VElementNumber
' Scope/Type: Private Function
' Purpose   : Calculates or returns switch group from 24 v element number.
' Parameters:
' elementNumber (String) - Supplies element number.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function SwitchGroupFrom24VElementNumber. Calculates or returns switch group from 24 v element number.
Private Function SwitchGroupFrom24VElementNumber(ByVal elementNumber As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for parts (Variant).
    Dim parts As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to Trim$(elementNumber).
    s = Trim$(elementNumber)
    ' [LINE EXPLANATION] When Len(s) = 0 is true, executes the inline action Exit Function.
    If Len(s) = 0 Then Exit Function

    ' [LINE EXPLANATION] Sets parts to Split(s, "-").
    parts = Split(s, "-")
    ' [LINE EXPLANATION] Starts a conditional block that runs when UBound(parts) >= 2 is true.
    If UBound(parts) >= 2 Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when IsNumeric(CStr(parts(0))) And IsNumeric(CStr(parts(1))) is true.
        If IsNumeric(CStr(parts(0))) And IsNumeric(CStr(parts(1))) Then
            ' [LINE EXPLANATION] Sets the return value of SwitchGroupFrom24VElementNumber to CStr(parts(1)).
            SwitchGroupFrom24VElementNumber = CStr(parts(1))
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function SwitchGroupFrom24VElementNumber.
End Function

'-------------------------------------------------------------------------------
' Procedure : Is24VMissingText
' Scope/Type: Private Function
' Purpose   : Checks whether 24 v missing text.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Is24VMissingText. Checks whether 24 v missing text.
Private Function Is24VMissingText(ByVal valueIn As String) As Boolean

    ' [LINE EXPLANATION] Declares procedure-level storage for u (String).
    Dim u As String

    ' [LINE EXPLANATION] Sets u to UCase$(Trim$(valueIn)).
    u = UCase$(Trim$(valueIn))
    ' [LINE EXPLANATION] Sets the return value of Is24VMissingText to (Len(u) = 0 Or u = "MISSING" Or u = "NOT FOUND" Or u = "N/A" Or u = "NA" Or u = "NONE" Or u = "NULL").
    Is24VMissingText = (Len(u) = 0 Or Left$(u, 7) = "MISSING" Or _
        u = "NOT FOUND" Or u = "N/A" Or u = "NA" Or u = "NONE" Or u = "NULL")

' [LINE EXPLANATION] Ends function Is24VMissingText.
End Function

'-------------------------------------------------------------------------------
' Procedure : Get24VPairIndex
' Scope/Type: Private Function
' Purpose   : Returns 24 v pair index.
' Parameters:
' psuPairIndex (Object) - Supplies PSU pair index.
' psuPairCount (Object) - Supplies PSU pair count.
' psuPairBus1Seq (Object) - Supplies PSU pair bus 1 seq.
' psuPairBus2Seq (Object) - Supplies PSU pair bus 2 seq.
' pnl (String) - Supplies pnl.
' pwg (String) - Supplies power group.
' bus (String) - Supplies bus.
' psu (String) - Supplies PSU.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get24VPairIndex. Returns 24 v pair index. This logical statement spans 3 physical lines.
Private Function Get24VPairIndex(ByVal psuPairIndex As Object, ByVal psuPairCount As Object, _
                                 ByVal psuPairBus1Seq As Object, ByVal psuPairBus2Seq As Object, _
                                 ByVal pnl As String, ByVal pwg As String, ByVal bus As String, ByVal psu As String) As Long

    'Returns the generated section pair index for the PSU.
    '
    'Fix:
    'The old logic counted BUS-1 and BUS-2 supplies independently, so the first
    'BUS-1 PSU could be printed beside the first BUS-2 PSU even when the PSU
    'base sequence numbers were far apart, for example 1050-PSU with 1025-PSU-2.
    '
    'This version pairs opposite BUS supplies only when their PSU sequence numbers
    'are within MAX_24V_PSU_PAIR_INCREMENT. Existing exact BUS/PSU records keep
    'their original section so all matching devices stay grouped together.

    ' [LINE EXPLANATION] Declares procedure-level storage for scopeKey (String).
    Dim scopeKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for psuKey (String).
    Dim psuKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for pairKey (String).
    Dim pairKey As String
    ' [LINE EXPLANATION] Declares procedure-level storage for nextIndex (Long).
    Dim nextIndex As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for psuSeq (Long).
    Dim psuSeq As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for bestIndex (Long).
    Dim bestIndex As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for pairVariant (Variant).
    Dim pairVariant As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for otherSeq (Long).
    Dim otherSeq As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for diffVal (Long).
    Dim diffVal As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for bestDiff (Long).
    Dim bestDiff As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for otherSeqMap (Object).
    Dim otherSeqMap As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for ownSeqMap (Object).
    Dim ownSeqMap As Object
    Dim psuSuffixOrdinal As Long
    Dim exactNamedPairOnly As Boolean

    ' [LINE EXPLANATION] Sets scopeKey to UCase$(Trim$(pnl)) & "|" & UCase$(Trim$(pwg)).
    scopeKey = UCase$(Trim$(pnl)) & "|" & UCase$(Trim$(pwg))
    ' [LINE EXPLANATION] Sets bus to UCase$(Trim$(bus)).
    bus = UCase$(Trim$(bus))
    ' [LINE EXPLANATION] Sets psuKey to scopeKey & "|" & bus & "|" & UCase$(Trim$(psu)).
    psuKey = scopeKey & "|" & bus & "|" & UCase$(Trim$(psu))

    ' [LINE EXPLANATION] Starts a conditional block that runs when psuPairIndex.Exists(psuKey) is true.
    If psuPairIndex.Exists(psuKey) Then
        ' [LINE EXPLANATION] Sets the return value of Get24VPairIndex to CLng(psuPairIndex(psuKey)).
        Get24VPairIndex = CLng(psuPairIndex(psuKey))
        ' [LINE EXPLANATION] Returns immediately from Get24VPairIndex using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets psuSeq to Extract24VPSUSequenceNumber(psu).
    psuSeq = Extract24VPSUSequenceNumber(psu)
    psuSuffixOrdinal = Extract24VPSUSuffixOrdinal(psu)
    exactNamedPairOnly = (psuSuffixOrdinal = 1 Or psuSuffixOrdinal = 2)

    ' [LINE EXPLANATION] Starts a conditional block that runs when bus = "BUS-1" is true.
    If bus = "BUS-1" Then
        ' [LINE EXPLANATION] Stores the object returned by psuPairBus2Seq in otherSeqMap.
        Set otherSeqMap = psuPairBus2Seq
        ' [LINE EXPLANATION] Stores the object returned by psuPairBus1Seq in ownSeqMap.
        Set ownSeqMap = psuPairBus1Seq
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Stores the object returned by psuPairBus1Seq in otherSeqMap.
        Set otherSeqMap = psuPairBus1Seq
        ' [LINE EXPLANATION] Stores the object returned by psuPairBus2Seq in ownSeqMap.
        Set ownSeqMap = psuPairBus2Seq
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets bestIndex to 0.
    bestIndex = 0
    ' [LINE EXPLANATION] Sets bestDiff to MAX_24V_PSU_PAIR_INCREMENT + 1.
    bestDiff = MAX_24V_PSU_PAIR_INCREMENT + 1

    ' [LINE EXPLANATION] Starts a conditional block that runs when psuSeq > 0 is true.
    If psuSeq > 0 Then
        ' [LINE EXPLANATION] Loops through each pairVariant contained in psuPairCount.keys.
        For Each pairVariant In psuPairCount.keys
            ' [LINE EXPLANATION] Starts a conditional block that runs when Left$(CStr(pairVariant), Len(scopeKey) + 1) = scopeKey & "|" is true.
            If Left$(CStr(pairVariant), Len(scopeKey) + 1) = scopeKey & "|" Then
                ' [LINE EXPLANATION] Sets pairKey to CStr(pairVariant).
                pairKey = CStr(pairVariant)

                'Only pair into a section that does not already have a different
                'supply for the same BUS.
                ' [LINE EXPLANATION] Starts a conditional block that runs when Not ownSeqMap.Exists(pairKey) is true.
                If Not ownSeqMap.Exists(pairKey) Then
                    ' [LINE EXPLANATION] Starts a conditional block that runs when otherSeqMap.Exists(pairKey) is true.
                    If otherSeqMap.Exists(pairKey) Then
                        ' [LINE EXPLANATION] Sets otherSeq to CLng(otherSeqMap(pairKey)).
                        otherSeq = CLng(otherSeqMap(pairKey))
                        ' [LINE EXPLANATION] Sets diffVal to Abs(psuSeq - otherSeq).
                        diffVal = Abs(psuSeq - otherSeq)
                        'V22.6: An explicitly numbered PSU-1 or PSU-2 may only
                        'share a generated section with the same PSU sequence.
                        'This prevents 1025-PSU-2 from being paired with
                        '1010-PSU merely because it was encountered first.
                        If (exactNamedPairOnly And diffVal = 0) Or _
                           (Not exactNamedPairOnly And diffVal <= MAX_24V_PSU_PAIR_INCREMENT) Then
                            ' [LINE EXPLANATION] Starts a conditional block that runs when diffVal < bestDiff is true.
                            If diffVal < bestDiff Then
                                ' [LINE EXPLANATION] Sets bestDiff to diffVal.
                                bestDiff = diffVal
                                ' [LINE EXPLANATION] Sets bestIndex to CLng(mid$(pairKey, Len(scopeKey) + 2)).
                                bestIndex = CLng(mid$(pairKey, Len(scopeKey) + 2))
                            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                            End If
                        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                        End If
                    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                    End If
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Advances the pairVariant loop to its next iteration.
        Next pairVariant
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Starts a conditional block that runs when bestIndex > 0 is true.
    If bestIndex > 0 Then
        ' [LINE EXPLANATION] Sets nextIndex to bestIndex.
        nextIndex = bestIndex
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Starts a conditional block that runs when psuPairCount.Exists(scopeKey) is true.
        If psuPairCount.Exists(scopeKey) Then
            ' [LINE EXPLANATION] Sets nextIndex to CLng(psuPairCount(scopeKey)) + 1.
            nextIndex = CLng(psuPairCount(scopeKey)) + 1
        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
        Else
            ' [LINE EXPLANATION] Sets nextIndex to 1.
            nextIndex = 1
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
        ' [LINE EXPLANATION] Sets psuPairCount(scopeKey) to nextIndex.
        psuPairCount(scopeKey) = nextIndex
        ' [LINE EXPLANATION] Sets psuPairCount(scopeKey & "|" & CStr(nextIndex)) to nextIndex.
        psuPairCount(scopeKey & "|" & CStr(nextIndex)) = nextIndex
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets pairKey to scopeKey & "|" & CStr(nextIndex).
    pairKey = scopeKey & "|" & CStr(nextIndex)
    ' [LINE EXPLANATION] Sets psuPairIndex(psuKey) to nextIndex.
    psuPairIndex(psuKey) = nextIndex

    ' [LINE EXPLANATION] Starts a conditional block that runs when psuSeq > 0 is true.
    If psuSeq > 0 Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when bus = "BUS-1" is true.
        If bus = "BUS-1" Then
            ' [LINE EXPLANATION] When Not psuPairBus1Seq.Exists(pairKey) is true, executes the inline action psuPairBus1Seq(pairKey) = psuSeq.
            If Not psuPairBus1Seq.Exists(pairKey) Then psuPairBus1Seq(pairKey) = psuSeq
        ' [LINE EXPLANATION] Tests the next alternative condition: bus = "BUS-2".
        ElseIf bus = "BUS-2" Then
            ' [LINE EXPLANATION] When Not psuPairBus2Seq.Exists(pairKey) is true, executes the inline action psuPairBus2Seq(pairKey) = psuSeq.
            If Not psuPairBus2Seq.Exists(pairKey) Then psuPairBus2Seq(pairKey) = psuSeq
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets the return value of Get24VPairIndex to nextIndex.
    Get24VPairIndex = nextIndex

' [LINE EXPLANATION] Ends function Get24VPairIndex.
End Function

Private Function Extract24VPSUSuffixOrdinal(ByVal psuName As String) As Long

    Dim u As String
    Dim psuPos As Long
    Dim suffixText As String
    Dim i As Long
    Dim digitsText As String

    Extract24VPSUSuffixOrdinal = 0&
    u = UCase$(Trim$(psuName))
    psuPos = InStrRev(u, "-PSU", -1, vbTextCompare)
    If psuPos = 0 Then Exit Function

    suffixText = mid$(u, psuPos + 4)
    If Left$(suffixText, 1) = "-" Then suffixText = mid$(suffixText, 2)

    For i = 1 To Len(suffixText)
        If mid$(suffixText, i, 1) Like "#" Then
            digitsText = digitsText & mid$(suffixText, i, 1)
        ElseIf Len(digitsText) > 0 Then
            Exit For
        End If
    Next i

    If Len(digitsText) > 0 Then Extract24VPSUSuffixOrdinal = CLng(digitsText)

End Function

'-------------------------------------------------------------------------------
' Procedure : Extract24VPSUSequenceNumber
' Scope/Type: Private Function
' Purpose   : Calculates or returns extract 24 vpsu sequence number.
' Parameters:
' psuName (String) - Supplies PSU name.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Extract24VPSUSequenceNumber. Calculates or returns extract 24 vpsu sequence number.
Private Function Extract24VPSUSequenceNumber(ByVal psuName As String) As Long

    'Returns the base numeric sequence immediately before the PSU token.
    'Examples:
    '   11-102-1050-PSU   -> 1050
    '   11-102-1025-PSU-2 -> 1025
    '   1025-PSU-2        -> 1025

    ' [LINE EXPLANATION] Declares procedure-level storage for parts (Variant).
    Dim parts As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for token (String).
    Dim token As String
    ' [LINE EXPLANATION] Declares procedure-level storage for j (Long).
    Dim j As Long

    ' [LINE EXPLANATION] Sets parts to Split(Trim$(psuName), "-").
    parts = Split(Trim$(psuName), "-")
    ' [LINE EXPLANATION] When UBound(parts) < 1 is true, executes the inline action Exit Function.
    If UBound(parts) < 1 Then Exit Function

    ' [LINE EXPLANATION] Loops i from LBound(parts) through UBound(parts).
    For i = LBound(parts) To UBound(parts)
        ' [LINE EXPLANATION] Sets token to UCase$(Trim$(CStr(parts(i)))).
        token = UCase$(Trim$(CStr(parts(i))))
        ' [LINE EXPLANATION] Starts a conditional block that runs when token = "PSU" Or Left$(token, 3) = "PSU" is true.
        If token = "PSU" Or Left$(token, 3) = "PSU" Then
            ' [LINE EXPLANATION] Loops j from i - 1 through LBound(parts) using step -1.
            For j = i - 1 To LBound(parts) Step -1
                ' [LINE EXPLANATION] Sets token to Trim$(CStr(parts(j))).
                token = Trim$(CStr(parts(j)))
                ' [LINE EXPLANATION] Starts a conditional block that runs when IsNumeric(token) is true.
                If IsNumeric(token) Then
                    ' [LINE EXPLANATION] Sets the return value of Extract24VPSUSequenceNumber to CLng(val(token)).
                    Extract24VPSUSequenceNumber = CLng(val(token))
                    ' [LINE EXPLANATION] Returns immediately from Extract24VPSUSequenceNumber using its current return value.
                    Exit Function
                ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
                End If
            ' [LINE EXPLANATION] Advances the j loop to its next iteration.
            Next j
            ' [LINE EXPLANATION] Returns immediately from Extract24VPSUSequenceNumber using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i

' [LINE EXPLANATION] Ends function Extract24VPSUSequenceNumber.
End Function

'-------------------------------------------------------------------------------
' Procedure : Write24VPowerSection
' Scope/Type: Private Sub
' Purpose   : Writes 24 v power section.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' startRow (Long) - Supplies start row.
' groupKey (String) - Supplies group key.
' records (Collection) - Supplies records.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Write24VPowerSection. Writes 24 v power section.
Private Sub Write24VPowerSection(ByVal ws As Worksheet, ByVal startRow As Long, _
                                 ByVal groupKey As String, ByVal col As Collection, _
                                 ByRef sectionEndRow As Long)

    Dim parts As Variant
    Dim pwg As String
    Dim bus1PSU As String
    Dim bus2PSU As String
    Dim bus1Start As Long
    Dim bus2Start As Long
    Dim bus1Count As Long
    Dim bus2Count As Long
    Dim psuTemplate As Object
    Dim psuRows(1 To 2, 1 To 8) As Variant

    parts = Split(groupKey, "|")
    pwg = CStr(parts(0))
    bus1PSU = Get24VSectionPSU(col, "BUS-1")
    bus2PSU = Get24VSectionPSU(col, "BUS-2")

    If Len(bus1PSU) > 0 And Len(bus2PSU) > 0 Then
        If StrComp(Trim$(bus1PSU), Trim$(bus2PSU), vbTextCompare) = 0 And _
           Not Is24VMissingText(bus1PSU) Then bus2PSU = "MISSING"
    End If

    ws.Range("A" & startRow & ":H" & startRow).value = _
        Array("PWG", "Bus Power", "Power Supply", "Block", _
              "Terminal 1", "Terminal 2", "Terminal 3", "Terminal 4")
    StyleHeader ws.Range("A" & startRow & ":H" & startRow)

    Set psuTemplate = Get24VPSUTemplate()
    psuRows(1, 1) = pwg
    psuRows(1, 2) = "BUS-1"
    psuRows(1, 3) = bus1PSU
    psuRows(1, 4) = CStr(psuTemplate("DWG"))
    psuRows(1, 5) = CStr(psuTemplate("TERM1"))
    psuRows(1, 6) = CStr(psuTemplate("TERM2"))
    psuRows(1, 7) = CStr(psuTemplate("TERM3"))
    psuRows(1, 8) = CStr(psuTemplate("TERM4"))

    psuRows(2, 1) = pwg
    psuRows(2, 2) = "BUS-2"
    psuRows(2, 3) = bus2PSU
    psuRows(2, 4) = CStr(psuTemplate("DWG"))
    psuRows(2, 5) = CStr(psuTemplate("TERM1"))
    psuRows(2, 6) = CStr(psuTemplate("TERM2"))
    psuRows(2, 7) = CStr(psuTemplate("TERM3"))
    psuRows(2, 8) = CStr(psuTemplate("TERM4"))

    ws.Range("A" & startRow + 1& & ":H" & startRow + 2&).Value2 = psuRows
    StyleSubHeader ws.Range("A" & startRow + 1& & ":H" & startRow + 2&)
    FormatMissingPSUCell ws.Cells(startRow + 1&, 3)
    FormatMissingPSUCell ws.Cells(startRow + 2&, 3)

    bus1Start = startRow + 4&
    ws.Range("A" & bus1Start & ":H" & bus1Start).value = _
        Array("SIS_ELEMENT_NUMBER", "TYPE", "LOAD", "BLOCK", "Terminal (IN)", _
              "Terminal (OUT)", "Power BUS-1 Terminal", "INSIDE PNL TERM")
    ws.Range("K" & bus1Start & ":N" & bus1Start).value = _
        Array("SIS_ELEMENT_NUMBER", "TYPE/DESC", "LOAD", "PWR TERM")
    StyleHeader ws.Range("A" & bus1Start & ":H" & bus1Start)
    StyleHeader ws.Range("K" & bus1Start & ":N" & bus1Start)
    bus1Count = Write24VDeviceRowsForBus(ws, bus1Start + 1&, col, "BUS-1")

    bus2Start = bus1Start + 2& + bus1Count
    If bus1Count = 0 Then bus2Start = bus2Start + 1&
    ws.Range("A" & bus2Start & ":H" & bus2Start).value = _
        Array("SIS_ELEMENT_NUMBER", "TYPE", "LOAD", "BLOCK", "Terminal (IN)", _
              "Terminal (OUT)", "Power BUS-2 Terminal", "INSIDE PNL TERM")
    ws.Range("K" & bus2Start & ":N" & bus2Start).value = _
        Array("SIS_ELEMENT_NUMBER", "TYPE/DESC", "LOAD", "PWR TERM")
    StyleHeader ws.Range("A" & bus2Start & ":H" & bus2Start)
    StyleHeader ws.Range("K" & bus2Start & ":N" & bus2Start)
    bus2Count = Write24VDeviceRowsForBus(ws, bus2Start + 1&, col, "BUS-2")

    If bus2Count > 0 Then
        sectionEndRow = bus2Start + bus2Count
    Else
        sectionEndRow = bus2Start
    End If
End Sub

'-------------------------------------------------------------------------------
' Procedure : Write24VDeviceRowsForBus
' Scope/Type: Private Function
' Purpose   : Writes 24 v device rows for bus.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' startDataRow (Long) - Supplies start data row.
' records (Collection) - Supplies records.
' busLabel (String) - Supplies bus label.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Write24VDeviceRowsForBus. Writes 24 v device rows for bus. This logical statement spans 2 physical lines.
Private Function Write24VDeviceRowsForBus(ByVal ws As Worksheet, ByVal startDataRow As Long, _
                                          ByVal records As Collection, ByVal busLabel As String) As Long

    'V22.5 HIGH-SPEED: construct A:H and K:N arrays in memory and write each
    'BUS section with two range assignments instead of twelve cell writes per row.
    Dim termLoads As Object
    Dim busMaskBySIS As Object
    Dim i As Long
    Dim outIndex As Long
    Dim matchCount As Long
    Dim priorityPass As Long
    Dim rec As Variant
    Dim recOut As Variant
    Dim bus As String
    Dim psu As String
    Dim termName As String
    Dim insideName As String
    Dim sisKey As String
    Dim displayType As String
    Dim loadAmps As Double
    Dim wasMissingTerminal As Boolean
    Dim isDualDevice As Boolean
    Dim busMask As Long
    Dim leftData() As Variant
    Dim rightData() As Variant
    Dim missingTerm1() As Boolean
    Dim missingTerm2() As Boolean
    Dim targetBus As String

    Set termLoads = CreateObject("Scripting.Dictionary")
    termLoads.CompareMode = vbTextCompare
    Set busMaskBySIS = CreateObject("Scripting.Dictionary")
    busMaskBySIS.CompareMode = vbTextCompare
    targetBus = UCase$(Trim$(busLabel))

    For i = 1 To records.count
        rec = records(i)
        bus = UCase$(Trim$(CStr(rec(2))))
        sisKey = UCase$(Trim$(CStr(rec(4))))
        If Len(sisKey) > 0 Then
            If busMaskBySIS.Exists(sisKey) Then busMask = CLng(busMaskBySIS(sisKey)) Else busMask = 0&
            If bus = "BUS-1" Then busMask = busMask Or 1&
            If bus = "BUS-2" Then busMask = busMask Or 2&
            busMaskBySIS(sisKey) = busMask
        End If

        If bus = targetBus Then
            termName = Normalize24VPowerTerminalName(CStr(rec(10)))
            If Len(termName) > 0 And UCase$(termName) <> "MISSING" Then
                Add24VTerminalLoad termLoads, termName, LoadNumberFrom24VText(CStr(rec(6)))
            End If
            matchCount = matchCount + 1&
        End If
    Next i

    If matchCount = 0 Then Exit Function
    ReDim leftData(1 To matchCount, 1 To 8)
    ReDim rightData(1 To matchCount, 1 To 4)
    ReDim missingTerm1(1 To matchCount)
    ReDim missingTerm2(1 To matchCount)

    For priorityPass = 1 To 2
        For i = 1 To records.count
            rec = records(i)
            bus = UCase$(Trim$(CStr(rec(2))))
            If bus = targetBus Then
                sisKey = UCase$(Trim$(CStr(rec(4))))
                isDualDevice = False
                If Len(sisKey) > 0 Then
                    If busMaskBySIS.Exists(sisKey) Then isDualDevice = (CLng(busMaskBySIS(sisKey)) = 3&)
                End If

                If (priorityPass = 1 And isDualDevice) Or (priorityPass = 2 And Not isDualDevice) Then
                    recOut = rec
                    psu = UCase$(Trim$(CStr(recOut(3))))
                    termName = Normalize24VPowerTerminalName(CStr(recOut(10)))
                    loadAmps = LoadNumberFrom24VText(CStr(recOut(6)))
                    wasMissingTerminal = (Len(termName) = 0)

                    If Len(termName) = 0 And Len(psu) > 0 And Not Is24VMissingText(psu) Then
                        'Do not invent a terminal during generation. Missing in PD6
                        'must remain visibly MISSING until corrected at the source.
                        termName = "MISSING"
                        recOut(10) = termName
                    End If

                    If Len(termName) > 0 And UCase$(termName) <> "MISSING" Then
                        insideName = CStr(recOut(11))
                        If Len(Trim$(insideName)) = 0 Then insideName = InsidePSUTermFromPowerTerminal(termName)
                        recOut(11) = insideName
                    End If
                    If wasMissingTerminal And UCase$(termName) <> "MISSING" Then
                        Add24VTerminalLoad termLoads, termName, loadAmps
                    End If

                    If Len(termName) > 0 And UCase$(termName) <> "MISSING" Then
                        recOut(10) = Get24VPhysicalPSUTerminal(termName)
                        recOut(11) = Get24VPSUDescription(termName)
                    End If

                    outIndex = outIndex + 1&
                    displayType = Get24VTypeDescCached(CStr(recOut(5)))
                    leftData(outIndex, 1) = recOut(4)
                    leftData(outIndex, 2) = displayType
                    leftData(outIndex, 3) = recOut(6)
                    leftData(outIndex, 4) = recOut(7)
                    leftData(outIndex, 5) = recOut(8)
                    leftData(outIndex, 6) = recOut(9)
                    leftData(outIndex, 7) = recOut(10)
                    leftData(outIndex, 8) = recOut(11)
                    rightData(outIndex, 1) = recOut(4)
                    rightData(outIndex, 2) = displayType
                    rightData(outIndex, 3) = recOut(6)
                    rightData(outIndex, 4) = recOut(10)
                    missingTerm1(outIndex) = Is24VMissingText(CStr(recOut(10)))
                    missingTerm2(outIndex) = Is24VMissingText(CStr(recOut(11)))
                End If
            End If
        Next i
    Next priorityPass

    ws.Range(ws.Cells(startDataRow, 1), ws.Cells(startDataRow + matchCount - 1&, 8)).Value2 = leftData
    ws.Range(ws.Cells(startDataRow, 11), ws.Cells(startDataRow + matchCount - 1&, 14)).Value2 = rightData

    For i = 1 To matchCount
        If missingTerm1(i) Then
            FormatMissingPSUCell ws.Cells(startDataRow + i - 1&, 7)
            FormatMissingPSUCell ws.Cells(startDataRow + i - 1&, 14)
        End If
        If missingTerm2(i) Then FormatMissingPSUCell ws.Cells(startDataRow + i - 1&, 8)
    Next i

    Write24VDeviceRowsForBus = matchCount
End Function

'-------------------------------------------------------------------------------
' Procedure : NextSafe24VPowerTerminal
' Scope/Type: Private Function
' Purpose   : Calculates or returns next safe 24 v power terminal.
' Parameters:
' termLoads (Object) - Supplies term loads.
' loadAmps (Double) - Supplies load amperes.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function NextSafe24VPowerTerminal. Calculates or returns next safe 24 v power terminal.
Private Function NextSafe24VPowerTerminal(ByVal termLoads As Object, ByVal loadAmps As Double) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for idx (Long).
    Dim idx As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for termName (String).
    Dim termName As String
    ' [LINE EXPLANATION] Declares procedure-level storage for existingLoad (Double).
    Dim existingLoad As Double

    ' [LINE EXPLANATION] When loadAmps < 0# is true, executes the inline action loadAmps = 0#.
    If loadAmps < 0# Then loadAmps = 0#

    ' [LINE EXPLANATION] Loops idx from 1 through 4.
    For idx = 1 To 4
        ' [LINE EXPLANATION] Sets termName to "X" & Format$(idx, "00") & "TERM01".
        termName = "X" & Format$(idx, "00") & "TERM01"
        ' [LINE EXPLANATION] Sets existingLoad to Get24VDictDouble(termLoads, termName).
        existingLoad = Get24VDictDouble(termLoads, termName)
        ' [LINE EXPLANATION] Starts a conditional block that runs when existingLoad + loadAmps <= 16# is true.
        If existingLoad + loadAmps <= MISSING_TERM_LIMIT_A_24V Then
            ' [LINE EXPLANATION] Sets the return value of NextSafe24VPowerTerminal to termName.
            NextSafe24VPowerTerminal = termName
            ' [LINE EXPLANATION] Returns immediately from NextSafe24VPowerTerminal using its current return value.
            Exit Function
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the idx loop to its next iteration.
    Next idx

    ' [LINE EXPLANATION] Sets the return value of NextSafe24VPowerTerminal to "".
    NextSafe24VPowerTerminal = ""

' [LINE EXPLANATION] Ends function NextSafe24VPowerTerminal.
End Function

'-------------------------------------------------------------------------------
' Procedure : Add24VTerminalLoad
' Scope/Type: Private Sub
' Purpose   : Adds 24 v terminal load.
' Parameters:
' termLoads (Object) - Supplies term loads.
' termName (String) - Supplies term name.
' loadAmps (Double) - Supplies load amperes.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Add24VTerminalLoad. Adds 24 v terminal load.
Private Sub Add24VTerminalLoad(ByVal termLoads As Object, ByVal termName As String, ByVal loadAmps As Double)

    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String

    ' [LINE EXPLANATION] When termLoads Is Nothing is true, executes the inline action Exit Sub.
    If termLoads Is Nothing Then Exit Sub
    ' [LINE EXPLANATION] Sets k to Normalize24VPowerTerminalName(termName).
    k = Normalize24VPowerTerminalName(termName)
    ' [LINE EXPLANATION] When Len(k) = 0 Or UCase$(k) = "MISSING" is true, executes the inline action Exit Sub.
    If Is24VMissingText(k) Then Exit Sub
    ' [LINE EXPLANATION] When loadAmps < 0# is true, executes the inline action loadAmps = 0#.
    If loadAmps < 0# Then loadAmps = 0#

    ' [LINE EXPLANATION] Sets termLoads(k) to Get24VDictDouble(termLoads, k) + loadAmps.
    termLoads(k) = Get24VDictDouble(termLoads, k) + loadAmps

' [LINE EXPLANATION] Ends procedure Add24VTerminalLoad.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Get24VDictDouble
' Scope/Type: Private Function
' Purpose   : Returns 24 v dictionary double.
' Parameters:
' dictObj (Object) - Supplies dictionary obj.
' keyText (String) - Supplies key text.
' Returns   : Double.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get24VDictDouble. Returns 24 v dictionary double.
Private Function Get24VDictDouble(ByVal dictObj As Object, ByVal keyText As String) As Double

    ' [LINE EXPLANATION] Starts a conditional block that runs when dictObj Is Nothing is true.
    If dictObj Is Nothing Then
        ' [LINE EXPLANATION] Sets the return value of Get24VDictDouble to 0#.
        Get24VDictDouble = 0#
    ' [LINE EXPLANATION] Tests the next alternative condition: dictObj.Exists(keyText).
    ElseIf dictObj.Exists(keyText) Then
        ' [LINE EXPLANATION] Starts a conditional block that runs when IsNumeric(dictObj(keyText)) is true.
        If IsNumeric(dictObj(keyText)) Then
            ' [LINE EXPLANATION] Sets the return value of Get24VDictDouble to CDbl(dictObj(keyText)).
            Get24VDictDouble = CDbl(dictObj(keyText))
        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
        Else
            ' [LINE EXPLANATION] Sets the return value of Get24VDictDouble to 0#.
            Get24VDictDouble = 0#
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of Get24VDictDouble to 0#.
        Get24VDictDouble = 0#
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Get24VDictDouble.
End Function

'-------------------------------------------------------------------------------
' Procedure : LoadNumberFrom24VText
' Scope/Type: Private Function
' Purpose   : Loads number from 24 v text.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : Double.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function LoadNumberFrom24VText. Loads number from 24 v text.
Private Function LoadNumberFrom24VText(ByVal valueIn As String) As Double

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(valueIn)).
    s = UCase$(Trim$(valueIn))
    ' [LINE EXPLANATION] Sets s to Replace(s, "AMPS", "").
    s = Replace(s, "AMPS", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "AMP", "").
    s = Replace(s, "AMP", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "A", "").
    s = Replace(s, "A", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ",", "").
    s = Replace(s, ",", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")

    ' [LINE EXPLANATION] Starts a conditional block that runs when IsNumeric(s) is true.
    If IsNumeric(s) Then
        ' [LINE EXPLANATION] Sets the return value of LoadNumberFrom24VText to CDbl(s).
        LoadNumberFrom24VText = CDbl(s)
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of LoadNumberFrom24VText to 0#.
        LoadNumberFrom24VText = 0#
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function LoadNumberFrom24VText.
End Function

'-------------------------------------------------------------------------------
' Procedure : Normalize24VPowerTerminalName
' Scope/Type: Private Function
' Purpose   : Normalizes 24 v power terminal name.
' Parameters:
' valueIn (String) - Supplies value in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Normalize24VPowerTerminalName. Normalizes 24 v power terminal name.
Private Function Normalize24VPowerTerminalName(ByVal valueIn As String) As String
    Dim s As String
    Dim template As Object
    Dim i As Long
    Dim p As Long
    Dim terminalNo As Long

    s = UCase$(Trim$(Replace(CStr(valueIn), Chr$(160), " ")))
    s = Replace(s, " ", "")
    s = Replace(s, "-", "")

    If Len(s) = 0 Then Exit Function
    If s = "MISSING" Then
        Normalize24VPowerTerminalName = "MISSING"
        Exit Function
    End If

    ' Preserve and canonicalize every physical terminal configured in
    ' 480v_DATA_POWER[PSU TERM]. This prevents X1TERM07, X1TERM09, and
    ' X1TERM11 from being incorrectly collapsed to logical terminal 1.
    Set template = Get24VPSUTemplate()
    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_24V
        If PowerMapKey(s) = PowerMapKey(CStr(template("TERM" & CStr(i)))) Then
            Normalize24VPowerTerminalName = CStr(template("TERM" & CStr(i)))
            Exit Function
        End If
    Next i

    ' Preserve the legacy logical allocation format X01TERM01..X04TERM01.
    If Left$(s, 1) = "X" Then
        p = InStr(2, s, "TERM", vbTextCompare)
        If p > 2 Then
            If IsNumeric(mid$(s, 2, p - 2)) Then
                terminalNo = CLng(mid$(s, 2, p - 2))
                If terminalNo >= 1 And terminalNo <= PSU_TEMPLATE_TERMINAL_COUNT_24V Then
                    If mid$(s, p + 4) = "01" Then
                        Normalize24VPowerTerminalName = "X" & Format$(terminalNo, "00") & "TERM01"
                        Exit Function
                    End If
                End If
            End If
        End If
    End If

    Normalize24VPowerTerminalName = s
End Function

'-------------------------------------------------------------------------------
' Procedure : InsidePSUTermFromPowerTerminal
' Scope/Type: Private Function
' Purpose   : Calculates or returns inside PSU term from power terminal.
' Parameters:
' powerTerminal (String) - Supplies power terminal.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function InsidePSUTermFromPowerTerminal. Calculates or returns inside PSU term from power terminal.
Private Function InsidePSUTermFromPowerTerminal(ByVal powerTerminal As String) As String

    ' Description is read only from the PSU-specific PSUDESC column.
    InsidePSUTermFromPowerTerminal = Get24VPSUDescription(powerTerminal)

' [LINE EXPLANATION] Ends function InsidePSUTermFromPowerTerminal.
End Function

'-------------------------------------------------------------------------------
' Procedure : TerminalIndexFrom24VPowerTerminal
' Scope/Type: Private Function
' Purpose   : Calculates or returns terminal index from 24 v power terminal.
' Parameters:
' powerTerminal (String) - Supplies power terminal.
' Returns   : Long.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function TerminalIndexFrom24VPowerTerminal. Calculates or returns terminal index from 24 v power terminal.
Private Function TerminalIndexFrom24VPowerTerminal(ByVal powerTerminal As String) As Long

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for ch (String).
    Dim ch As String
    ' [LINE EXPLANATION] Declares procedure-level storage for digitsText (String).
    Dim digitsText As String

    ' [LINE EXPLANATION] Sets s to Normalize24VPowerTerminalName(powerTerminal).
    s = Normalize24VPowerTerminalName(powerTerminal)
    ' [LINE EXPLANATION] When Len(s) = 0 Or UCase$(s) = "MISSING" is true, executes the inline action Exit Function.
    If Len(s) = 0 Or UCase$(s) = "MISSING" Then Exit Function
    ' [LINE EXPLANATION] When Left$(s, 1) <> "X" is true, executes the inline action Exit Function.
    If Left$(s, 1) <> "X" Then Exit Function

    ' [LINE EXPLANATION] Loops i from 2 through Len(s).
    For i = 2 To Len(s)
        ' [LINE EXPLANATION] Sets ch to mid$(s, i, 1).
        ch = mid$(s, i, 1)
        ' [LINE EXPLANATION] Starts a conditional block that runs when ch >= "0" And ch <= "9" is true.
        If ch >= "0" And ch <= "9" Then
            ' [LINE EXPLANATION] Sets digitsText to digitsText & ch.
            digitsText = digitsText & ch
        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
        Else
            ' [LINE EXPLANATION] Immediately leaves the current for loop.
            Exit For
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i

    ' [LINE EXPLANATION] When Len(digitsText) > 0 is true, executes the inline action TerminalIndexFrom24VPowerTerminal = CLng(digitsText).
    If Len(digitsText) > 0 Then TerminalIndexFrom24VPowerTerminal = CLng(digitsText)

' [LINE EXPLANATION] Ends function TerminalIndexFrom24VPowerTerminal.
End Function

'-------------------------------------------------------------------------------
' Procedure : Get24VSectionPSU
' Scope/Type: Private Function
' Purpose   : Returns 24 v section PSU.
' Parameters:
' records (Collection) - Supplies records.
' busLabel (String) - Supplies bus label.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Get24VSectionPSU. Returns 24 v section PSU.
Private Function Get24VSectionPSU(ByVal records As Collection, ByVal busLabel As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for rec (Variant).
    Dim rec As Variant
    ' [LINE EXPLANATION] Declares procedure-level storage for bus (String).
    Dim bus As String
    ' [LINE EXPLANATION] Declares procedure-level storage for psu (String).
    Dim psu As String

    ' [LINE EXPLANATION] Sets the return value of Get24VSectionPSU to "".
    Get24VSectionPSU = ""

    ' [LINE EXPLANATION] Loops i from 1 through records.count.
    For i = 1 To records.count
        ' [LINE EXPLANATION] Sets rec to records(i).
        rec = records(i)
        ' [LINE EXPLANATION] Sets bus to UCase$(Trim$(CStr(rec(2)))).
        bus = UCase$(Trim$(CStr(rec(2))))
        ' [LINE EXPLANATION] Starts a conditional block that runs when bus = UCase$(Trim$(busLabel)) is true.
        If bus = UCase$(Trim$(busLabel)) Then
            ' [LINE EXPLANATION] Sets psu to Trim$(CStr(rec(3))).
            psu = Trim$(CStr(rec(3)))
            ' [LINE EXPLANATION] Starts a conditional block that runs when Len(psu) > 0 is true.
            If Len(psu) > 0 Then
                ' [LINE EXPLANATION] Sets the return value of Get24VSectionPSU to psu.
                Get24VSectionPSU = psu
                ' [LINE EXPLANATION] Returns immediately from Get24VSectionPSU using its current return value.
                Exit Function
            ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
            End If
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Advances the i loop to its next iteration.
    Next i

' [LINE EXPLANATION] Ends function Get24VSectionPSU.
End Function

'-------------------------------------------------------------------------------
' Procedure : FormatMissingPSUCell
' Scope/Type: Private Sub
' Purpose   : Formats missing PSU cell.
' Parameters:
' targetCell (Range) - Supplies target cell.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub FormatMissingPSUCell. Formats missing PSU cell.
Private Sub FormatMissingPSUCell(ByVal targetCell As Range)

    ' [LINE EXPLANATION] When UCase$(Trim$(CStr(targetCell.value))) <> "MISSING" is true, executes the inline action Exit Sub.
    If Not Is24VMissingText(CStr(targetCell.value)) Then Exit Sub

    ' [LINE EXPLANATION] Starts a With block for targetCell, allowing nested lines to omit the repeated object reference.
    With targetCell
        ' [LINE EXPLANATION] Sets the Font property on the object named by the active With block.
        .Font.Color = vbRed
        ' [LINE EXPLANATION] Sets the Font property on the object named by the active With block.
        .Font.Bold = True
    ' [LINE EXPLANATION] Ends the current With block.
    End With

' [LINE EXPLANATION] Ends procedure FormatMissingPSUCell.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Write24VDeviceRow
' Scope/Type: Private Sub
' Purpose   : Writes 24 v device row.
' Parameters:
' ws (Worksheet) - Supplies worksheet.
' r (Long) - Supplies r.
' rec (Variant) - Supplies rec.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub Write24VDeviceRow. Writes 24 v device row.
Private Sub Write24VDeviceRow(ByVal ws As Worksheet, ByVal r As Long, ByVal rec As Variant)

    ' [LINE EXPLANATION] Declares procedure-level storage for displayType (String).
    Dim displayType As String

    'Final guard: translate raw PD6 TYPE text to DATA_IO_BLOCK DESC at the point
    'of writing the generated 24V sheet. This fixes cases where TYPE was still
    'showing as MC instead of MultiControl.
    ' [LINE EXPLANATION] Sets displayType to Get24VTypeDescCached(CStr(rec(5))).
    displayType = Get24VTypeDescCached(CStr(rec(5)))

    ' [LINE EXPLANATION] Writes rec(4) into ws.Cells(r, 1).value.
    ws.Cells(r, 1).value = rec(4)
    ' [LINE EXPLANATION] Writes displayType into ws.Cells(r, 2).value.
    ws.Cells(r, 2).value = displayType
    ' [LINE EXPLANATION] Writes rec(6) into ws.Cells(r, 3).value.
    ws.Cells(r, 3).value = rec(6)
    ' [LINE EXPLANATION] Writes rec(7) into ws.Cells(r, 4).value.
    ws.Cells(r, 4).value = rec(7)
    ' [LINE EXPLANATION] Writes rec(8) into ws.Cells(r, 5).value.
    ws.Cells(r, 5).value = rec(8)
    ' [LINE EXPLANATION] Writes rec(9) into ws.Cells(r, 6).value.
    ws.Cells(r, 6).value = rec(9)
    ' [LINE EXPLANATION] Writes rec(10) into ws.Cells(r, 7).value.
    ws.Cells(r, 7).value = rec(10)
    ' [LINE EXPLANATION] Writes rec(11) into ws.Cells(r, 8).value.
    ws.Cells(r, 8).value = rec(11)

    ' [LINE EXPLANATION] Writes rec(4) into ws.Cells(r, 11).value.
    ws.Cells(r, 11).value = rec(4)
    ' [LINE EXPLANATION] Writes displayType into ws.Cells(r, 12).value.
    ws.Cells(r, 12).value = displayType
    ' [LINE EXPLANATION] Writes rec(6) into ws.Cells(r, 13).value.
    ws.Cells(r, 13).value = rec(6)
    ' [LINE EXPLANATION] Writes rec(10) into ws.Cells(r, 14).value.
    ws.Cells(r, 14).value = rec(10)

    ' [LINE EXPLANATION] Calls FormatMissingPSUCell, which formats missing PSU cell, using the supplied argument values.
    FormatMissingPSUCell ws.Cells(r, 7)
    ' [LINE EXPLANATION] Calls FormatMissingPSUCell, which formats missing PSU cell, using the supplied argument values.
    FormatMissingPSUCell ws.Cells(r, 8)
    ' [LINE EXPLANATION] Calls FormatMissingPSUCell, which formats missing PSU cell, using the supplied argument values.
    FormatMissingPSUCell ws.Cells(r, 14)

' [LINE EXPLANATION] Ends procedure Write24VDeviceRow.
End Sub

Public Sub Remove_Legacy_PSU_Missing_Summary()
    DeleteLegacyPSUMissingSummarySheet
    MsgBox "The legacy PSU_MISSING_SUMMARY worksheet was removed. Missing-PSU status is now shown on the 24v_Power Generator index.", _
           vbInformation, "24V Power Generator"
End Sub

Private Sub DeleteLegacyPSUMissingSummarySheet()
    Const LEGACY_SHEET_NAME As String = "PSU_MISSING_SUMMARY"
    Dim oldAlerts As Boolean

    oldAlerts = Application.DisplayAlerts
    On Error GoTo CleanExit

    If WorksheetExists(LEGACY_SHEET_NAME) Then
        Application.DisplayAlerts = False
        ThisWorkbook.Worksheets(LEGACY_SHEET_NAME).Delete
    End If

CleanExit:
    Application.DisplayAlerts = oldAlerts
End Sub

'-------------------------------------------------------------------------------
' Procedure : DeleteOld24VPanelSheets
' Scope/Type: Private Sub
' Purpose   : Deletes old 24 v panel sheets.
' Parameters: None.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Sub DeleteOld24VPanelSheets. Deletes old 24 v panel sheets.
Private Sub DeleteOld24VPanelSheets()

    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for namesToDelete (Collection).
    Dim namesToDelete As Collection
    ' [LINE EXPLANATION] Declares procedure-level storage for nm (Variant).
    Dim nm As Variant

    ' [LINE EXPLANATION] Stores the object returned by New Collection in namesToDelete.
    Set namesToDelete = New Collection

    ' [LINE EXPLANATION] Loops through each ws contained in ThisWorkbook.Worksheets.
    For Each ws In ThisWorkbook.Worksheets
        ' [LINE EXPLANATION] Starts a conditional block that runs when Left$(UCase$(ws.name), 4) = "24V_" is true.
        If Left$(UCase$(ws.Name), 4) = "24V_" Or _
           Right$(UCase$(ws.Name), 4) = "_24V" Then
            'Only generated panel sheets are rebuild candidates. Preserve the
            'index, lookup, audit, overload, and missing-PSU requirement sheets.
            If UCase$(ws.Name) <> UCase$(SH_24V) And _
               UCase$(ws.Name) <> "24V_POWER_GENERATOR" And _
               UCase$(ws.Name) <> "24V_DATA_POWER" And _
               UCase$(ws.Name) <> "24V DATA POWER" And _
               UCase$(ws.Name) <> "24V_OVERLOAD_TERMINALS" And _
               UCase$(ws.Name) <> "24V_NOT_GENERATED" And _
               UCase$(ws.Name) <> "PSU_MISSING_REQUIREMENTS" Then
                namesToDelete.Add ws.Name
            End If
        End If
    ' [LINE EXPLANATION] Advances the ws loop to its next iteration.
    Next ws

    ' [LINE EXPLANATION] When namesToDelete.count = 0 is true, executes the inline action Exit Sub.
    If namesToDelete.count = 0 Then Exit Sub

    ' [LINE EXPLANATION] Controls whether Excel displays confirmation and warning dialogs to False.
    Application.DisplayAlerts = False
    ' [LINE EXPLANATION] Loops through each nm contained in namesToDelete.
    For Each nm In namesToDelete
        ' [LINE EXPLANATION] Calls the Worksheets member of this macro workbook with (CStr(nm)).Delete.
        ThisWorkbook.Worksheets(CStr(nm)).Delete
    ' [LINE EXPLANATION] Advances the nm loop to its next iteration.
    Next nm
    ' [LINE EXPLANATION] Controls whether Excel displays confirmation and warning dialogs to True.
    Application.DisplayAlerts = True

' [LINE EXPLANATION] Ends procedure DeleteOld24VPanelSheets.
End Sub

'-------------------------------------------------------------------------------
' Procedure : Unique24VPanelSheetName
' Scope/Type: Private Function
' Purpose   : Calculates or returns unique 24 v panel sheet name.
' Parameters:
' pnl (String) - Supplies pnl.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Unique24VPanelSheetName. Calculates or returns unique 24 v panel sheet name.
Private Function Unique24VPanelSheetName(ByVal pnl As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for baseName (String).
    Dim baseName As String
    ' [LINE EXPLANATION] Declares procedure-level storage for nm (String).
    Dim nm As String
    ' [LINE EXPLANATION] Declares procedure-level storage for i (Long).
    Dim i As Long

    ' [LINE EXPLANATION] Sets baseName to SafeSheetName(pnl & "_24v").
    baseName = SafeSheetName(pnl & "_24v")
    ' [LINE EXPLANATION] When Len(baseName) > 31 is true, executes the inline action baseName = Left$(baseName, 31).
    If Len(baseName) > 31 Then baseName = Left$(baseName, 31)
    ' [LINE EXPLANATION] Sets nm to baseName.
    nm = baseName
    ' [LINE EXPLANATION] Sets i to 1.
    i = 1

    ' [LINE EXPLANATION] Starts a loop that repeats while WorksheetExists(nm).
    Do While WorksheetExists(nm)
        ' [LINE EXPLANATION] Starts a conditional block that runs when UCase$(nm) = UCase$(SH_24V) is true.
        If UCase$(nm) = UCase$(SH_24V) Then
            ' [LINE EXPLANATION] Sets i to i + 1.
            i = i + 1
            ' [LINE EXPLANATION] Sets nm to Left$(baseName, 28) & "_" & Format$(i, "00").
            nm = Left$(baseName, 28) & "_" & Format$(i, "00")
        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
        Else
            ' [LINE EXPLANATION] Immediately leaves the current do loop.
            Exit Do
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Returns to the beginning of the current Do loop.
    Loop

    ' [LINE EXPLANATION] Sets the return value of Unique24VPanelSheetName to nm.
    Unique24VPanelSheetName = nm

' [LINE EXPLANATION] Ends function Unique24VPanelSheetName.
End Function

'-------------------------------------------------------------------------------
' Data-driven PSU template helpers
'-------------------------------------------------------------------------------
Private Function Get24VPSUTemplate() As Object
    Dim ws As Worksheet
    Dim d As Object
    Dim headerRow As Long
    Dim cDwg As Long, cTerm As Long, cDesc As Long
    Dim r As Long, c As Long, lastRow As Long, lastCol As Long
    Dim h As String, currentDwg As String, termText As String, descText As String
    Dim termCount As Long

    If Not m24VPSUTemplate Is Nothing Then
        Set Get24VPSUTemplate = m24VPSUTemplate
        Exit Function
    End If

    Set ws = GetSheetIfExists(SH_480V_DATA_POWER_LOCAL)
    If ws Is Nothing Then
        Err.Raise vbObjectError + 2401, "Get24VPSUTemplate", _
                  "Worksheet '" & SH_480V_DATA_POWER_LOCAL & "' was not found."
    End If

    lastRow = LastUsedRow(ws)
    lastCol = LastUsedColAnyRow24V(ws)
    If lastCol < 1 Then lastCol = 80

    For r = 1 To WorksheetFunction.Min(lastRow, 30)
        cDwg = 0: cTerm = 0: cDesc = 0
        For c = 1 To lastCol
            h = HeaderKey24V(ws.Cells(r, c).value)
            Select Case h
                Case "PSUDWG": cDwg = c
                Case "PSUTERM": cTerm = c
                Case "PSUDESC", "DESCPSU", "PSUDESCRIPTION": cDesc = c
            End Select
        Next c
        If cDwg > 0 And cTerm > 0 And cDesc > 0 Then
            headerRow = r
            Exit For
        End If
    Next r

    If headerRow = 0 Then
        Err.Raise vbObjectError + 2402, "Get24VPSUTemplate", _
                  "Headers PSU DWG, PSU TERM, and DESC were not found on the same row of '" & _
                  SH_480V_DATA_POWER_LOCAL & "'."
    End If

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    For r = headerRow + 1 To lastRow
        If Len(Trim$(CStr(ws.Cells(r, cDwg).value))) > 0 Then
            currentDwg = Trim$(CStr(ws.Cells(r, cDwg).value))
        End If
        termText = Trim$(CStr(ws.Cells(r, cTerm).value))
        descText = Trim$(CStr(ws.Cells(r, cDesc).value))

        If Len(termText) > 0 Or Len(descText) > 0 Then
            If Len(currentDwg) = 0 Then
                Err.Raise vbObjectError + 2403, "Get24VPSUTemplate", _
                          "The first PSU TERM row must have a PSU DWG value in '" & _
                          SH_480V_DATA_POWER_LOCAL & "'."
            End If
            If Len(termText) = 0 Or Len(descText) = 0 Then
                Err.Raise vbObjectError + 2404, "Get24VPSUTemplate", _
                          "Every PSU template row must contain both PSU TERM and DESC. Check row " & CStr(r) & "."
            End If

            termCount = termCount + 1
            If termCount = 1 Then d("DWG") = currentDwg
            d("DWG" & CStr(termCount)) = currentDwg
            d("TERM" & CStr(termCount)) = termText
            d("PSUDESC" & CStr(termCount)) = descText
            If termCount = PSU_TEMPLATE_TERMINAL_COUNT_24V Then Exit For
        End If
    Next r

    If termCount <> PSU_TEMPLATE_TERMINAL_COUNT_24V Then
        Err.Raise vbObjectError + 2405, "Get24VPSUTemplate", _
                  "Exactly four usable PSU TERM/DESC rows are required under the PSU headers in '" & _
                  SH_480V_DATA_POWER_LOCAL & "'. Found " & CStr(termCount) & "."
    End If

    Set m24VPSUTemplate = d
    Set Get24VPSUTemplate = m24VPSUTemplate
End Function

Private Function Get24VPSUTerminalIndex(ByVal terminalText As String) As Long
    Dim template As Object
    Dim i As Long
    Dim keyText As String
    Dim s As String
    Dim p As Long
    Dim logicalIndex As Long

    s = UCase$(Trim$(Replace(CStr(terminalText), Chr$(160), " ")))
    If Len(Replace(s, " ", "")) = 0 Or s = "MISSING" Then Exit Function

    Set template = Get24VPSUTemplate()
    keyText = PowerMapKey(s)

    ' Exact physical terminal match from the editable data table.
    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_24V
        If keyText = PowerMapKey(CStr(template("TERM" & CStr(i)))) Then
            Get24VPSUTerminalIndex = i
            Exit Function
        End If
    Next i

    ' Legacy logical allocation terminal match: X01TERM01..X04TERM01.
    s = Replace(Replace(s, " ", ""), "-", "")
    If Left$(s, 1) = "X" Then
        p = InStr(2, s, "TERM", vbTextCompare)
        If p > 2 And IsNumeric(mid$(s, 2, p - 2)) Then
            logicalIndex = CLng(mid$(s, 2, p - 2))
            If logicalIndex >= 1 And logicalIndex <= PSU_TEMPLATE_TERMINAL_COUNT_24V Then
                If mid$(s, p + 4) = "01" Then
                    Get24VPSUTerminalIndex = logicalIndex
                End If
            End If
        End If
    End If
End Function

Private Function Get24VPhysicalPSUTerminal(ByVal terminalText As String) As String
    Dim idx As Long
    Dim template As Object
    Dim cleanText As String

    cleanText = Trim$(Replace(CStr(terminalText), Chr$(160), " "))
    If Len(cleanText) = 0 Then Exit Function
    If UCase$(cleanText) = "MISSING" Then
        Get24VPhysicalPSUTerminal = "MISSING"
        Exit Function
    End If

    idx = Get24VPSUTerminalIndex(cleanText)
    If idx = 0 Then
        Err.Raise vbObjectError + 2406, "Get24VPhysicalPSUTerminal", _
                  "Terminal '" & cleanText & "' cannot be matched to 480v_DATA_POWER[PSU TERM]. " & _
                  "Valid values are: " & Get24VConfiguredTerminalList()
    End If

    Set template = Get24VPSUTemplate()
    Get24VPhysicalPSUTerminal = CStr(template("TERM" & CStr(idx)))
End Function

Private Function Get24VPSUDescription(ByVal terminalText As String) As String
    Dim idx As Long
    Dim template As Object
    Dim cleanText As String

    cleanText = Trim$(Replace(CStr(terminalText), Chr$(160), " "))
    If Len(cleanText) = 0 Or UCase$(cleanText) = "MISSING" Then Exit Function

    idx = Get24VPSUTerminalIndex(cleanText)
    If idx = 0 Then
        Err.Raise vbObjectError + 2407, "Get24VPSUDescription", _
                  "Terminal '" & cleanText & "' cannot be matched to 480v_DATA_POWER[PSU TERM]. " & _
                  "Valid values are: " & Get24VConfiguredTerminalList()
    End If

    Set template = Get24VPSUTemplate()
    Get24VPSUDescription = CStr(template("PSUDESC" & CStr(idx)))
End Function


Private Function Get24VConfiguredTerminalList() As String
    Dim template As Object
    Dim i As Long
    Dim result As String

    Set template = Get24VPSUTemplate()
    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_24V
        If Len(result) > 0 Then result = result & ", "
        result = result & CStr(template("TERM" & CStr(i)))
    Next i
    Get24VConfiguredTerminalList = result
End Function

Private Function Build24VPSUDescriptionMap() As Object
    Dim d As Object
    Dim template As Object
    Dim i As Long
    Dim logicalTerm As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    Set template = Get24VPSUTemplate()

    For i = 1 To PSU_TEMPLATE_TERMINAL_COUNT_24V
        logicalTerm = "X" & Format$(i, "00") & "TERM01"
        d(PowerMapKey(logicalTerm)) = CStr(template("PSUDESC" & CStr(i)))
        d(PowerMapKey(CStr(template("TERM" & CStr(i))))) = CStr(template("PSUDESC" & CStr(i)))
    Next i

    Set Build24VPSUDescriptionMap = d
End Function

'-------------------------------------------------------------------------------
' Procedure : BuildPowerMap
' Scope/Type: Private Function
' Purpose   : Builds power map.
' Parameters:
' keyColumn (Long) - Supplies key column.
' valueColumn (Long) - Supplies value column.
' Returns   : Object.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function BuildPowerMap. Builds power map.
Private Function BuildPowerMap(ByVal keyColumn As Long, ByVal valueColumn As Long) As Object

    ' [LINE EXPLANATION] Declares procedure-level storage for ws (Worksheet).
    Dim ws As Worksheet
    ' [LINE EXPLANATION] Declares procedure-level storage for LastRow (Long).
    Dim lastRow As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for r (Long).
    Dim r As Long
    ' [LINE EXPLANATION] Declares procedure-level storage for d (Object).
    Dim d As Object
    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String
    ' [LINE EXPLANATION] Declares procedure-level storage for v (String).
    Dim v As String

    ' [LINE EXPLANATION] Stores the object returned by EnsureSheet(SH_DATA_PWR) in ws.
    Set ws = EnsureSheet(SH_DATA_PWR)
    ' [LINE EXPLANATION] Stores the object returned by CreateObject("Scripting.Dictionary") in d.
    Set d = CreateObject("Scripting.Dictionary")

    ' [LINE EXPLANATION] Sets LastRow to LastUsedRow(ws).
    lastRow = LastUsedRow(ws)

    ' [LINE EXPLANATION] Loops r from 2 through LastRow.
    For r = 2 To lastRow
        ' [LINE EXPLANATION] Sets k to PowerMapKey(CStr(ws.Cells(r, keyColumn).value)).
        k = PowerMapKey(CStr(ws.Cells(r, keyColumn).value))
        ' [LINE EXPLANATION] Sets v to CStr(ws.Cells(r, valueColumn).value).
        v = CStr(ws.Cells(r, valueColumn).value)
        ' [LINE EXPLANATION] When Len(k) > 0 is true, executes the inline action d(k) = v.
        If Len(k) > 0 Then d(k) = v
    ' [LINE EXPLANATION] Advances the r loop to its next iteration.
    Next r

    ' [LINE EXPLANATION] Stores the object returned by d in BuildPowerMap.
    Set BuildPowerMap = d

' [LINE EXPLANATION] Ends function BuildPowerMap.
End Function

'-------------------------------------------------------------------------------
' Procedure : GetPowerMapValueLocal
' Scope/Type: Private Function
' Purpose   : Returns power map value local.
' Parameters:
' mapObj (Object) - Supplies map obj.
' keyText (String) - Supplies key text.
' fallback (String) - Supplies fallback; default = "".
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function GetPowerMapValueLocal. Returns power map value local.
Private Function GetPowerMapValueLocal(ByVal mapObj As Object, ByVal keyText As String, Optional ByVal fallback As String = "") As String

    ' [LINE EXPLANATION] Declares procedure-level storage for k (String).
    Dim k As String

    ' [LINE EXPLANATION] Sets k to PowerMapKey(keyText).
    k = PowerMapKey(keyText)

    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(k) = 0 is true.
    If Len(k) = 0 Then
        ' [LINE EXPLANATION] Sets the return value of GetPowerMapValueLocal to fallback.
        GetPowerMapValueLocal = fallback
    ' [LINE EXPLANATION] Tests the next alternative condition: mapObj.Exists(k).
    ElseIf mapObj.Exists(k) Then
        ' [LINE EXPLANATION] Sets the return value of GetPowerMapValueLocal to CStr(mapObj(k)).
        GetPowerMapValueLocal = CStr(mapObj(k))
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of GetPowerMapValueLocal to fallback.
        GetPowerMapValueLocal = fallback
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function GetPowerMapValueLocal.
End Function

'-------------------------------------------------------------------------------
' Procedure : PowerMapKey
' Scope/Type: Private Function
' Purpose   : Calculates or returns power map key.
' Parameters:
' s (String) - Supplies s.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function PowerMapKey. Calculates or returns power map key.
Private Function PowerMapKey(ByVal s As String) As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(s)).
    s = UCase$(Trim$(s))
    ' [LINE EXPLANATION] Sets s to Replace(s, "/", "_").
    s = Replace(s, "/", "_")
    ' [LINE EXPLANATION] Sets s to Replace(s, "-", "_").
    s = Replace(s, "-", "_")
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ".", "").
    s = Replace(s, ".", "")

    ' [LINE EXPLANATION] When Left$(s, 4) = "IO_S" is true, executes the inline action s = "IO_S".
    If Left$(s, 4) = "IO_S" Then s = "IO_S"
    ' [LINE EXPLANATION] When Left$(s, 4) = "IO_D" is true, executes the inline action s = "IO_D".
    If Left$(s, 4) = "IO_D" Then s = "IO_D"
    ' [LINE EXPLANATION] When Left$(s, 3) = "SCN" is true, executes the inline action s = "SCN".
    If Left$(s, 3) = "SCN" Then s = "SCN"
    ' [LINE EXPLANATION] When Left$(s, 7) = "SCANNER" is true, executes the inline action s = "SCN".
    If Left$(s, 7) = "SCANNER" Then s = "SCN"
    ' [LINE EXPLANATION] When Left$(s, 2) = "SC" is true, executes the inline action s = "SC".
    If Left$(s, 2) = "SC" Then s = "SC"
    ' [LINE EXPLANATION] When Left$(s, 2) = "MC" is true, executes the inline action s = "MC".
    If Left$(s, 2) = "MC" Then s = "MC"
    ' [LINE EXPLANATION] When Left$(s, 2) = "MS" is true, executes the inline action s = "MS".
    If Left$(s, 2) = "MS" Then s = "MS"
    ' [LINE EXPLANATION] When Left$(s, 3) = "VFD" is true, executes the inline action s = "VFD".
    If Left$(s, 3) = "VFD" Then s = "VFD"
    ' [LINE EXPLANATION] When Left$(s, 3) = "PC2" is true, executes the inline action s = "PC2".
    If Left$(s, 3) = "PC2" Then s = "PC2"

    ' [LINE EXPLANATION] Sets the return value of PowerMapKey to s.
    PowerMapKey = s

' [LINE EXPLANATION] Ends function PowerMapKey.
End Function

'-------------------------------------------------------------------------------
' Procedure : NormalizeBusName
' Scope/Type: Private Function
' Purpose   : Normalizes bus name.
' Parameters:
' busIn (String) - Supplies bus in.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function NormalizeBusName. Normalizes bus name.
Private Function NormalizeBusName(ByVal busIn As String) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for u (String).
    Dim u As String

    ' [LINE EXPLANATION] Sets u to UCase$(Trim$(busIn)).
    u = UCase$(Trim$(busIn))
    ' [LINE EXPLANATION] Sets u to Replace(u, " ", "").
    u = Replace(u, " ", "")

    ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, u, "2", vbTextCompare) > 0 is true.
    If InStr(1, u, "2", vbTextCompare) > 0 Then
        ' [LINE EXPLANATION] Sets the return value of NormalizeBusName to "BUS-2".
        NormalizeBusName = "BUS-2"
    ' [LINE EXPLANATION] Tests the next alternative condition: InStr(1, u, "1", vbTextCompare) > 0.
    ElseIf InStr(1, u, "1", vbTextCompare) > 0 Then
        ' [LINE EXPLANATION] Sets the return value of NormalizeBusName to "BUS-1".
        NormalizeBusName = "BUS-1"
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of NormalizeBusName to u.
        NormalizeBusName = u
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function NormalizeBusName.
End Function


'-------------------------------------------------------------------------------
' Procedure : Format24VLoadValue
' Scope/Type: Private Function
' Purpose   : Formats 24 v load value.
' Parameters:
' valueIn (Variant) - Supplies value in.
' roundUpBus1 (Boolean) - Supplies round up bus 1.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function Format24VLoadValue. Formats 24 v load value.
Private Function Format24VLoadValue(ByVal valueIn As Variant, ByVal roundUpBus1 As Boolean) As String

    ' [LINE EXPLANATION] Declares procedure-level storage for rawText (String).
    Dim rawText As String
    ' [LINE EXPLANATION] Declares procedure-level storage for n (Double).
    Dim n As Double
    ' [LINE EXPLANATION] Declares procedure-level storage for hasNumber (Boolean).
    Dim hasNumber As Boolean

    ' [LINE EXPLANATION] Sets rawText to Trim$(CStr(valueIn)).
    rawText = Trim$(CStr(valueIn))
    ' [LINE EXPLANATION] Starts a conditional block that runs when Len(rawText) = 0 is true.
    If Len(rawText) = 0 Then
        ' [LINE EXPLANATION] Sets the return value of Format24VLoadValue to "".
        Format24VLoadValue = ""
        ' [LINE EXPLANATION] Returns immediately from Format24VLoadValue using its current return value.
        Exit Function
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

    ' [LINE EXPLANATION] Sets hasNumber to TryParseLoadNumber(rawText, n).
    hasNumber = TryParseLoadNumber(rawText, n)
    ' [LINE EXPLANATION] Starts a conditional block that runs when hasNumber is true.
    If hasNumber Then
        ' [LINE EXPLANATION] When roundUpBus1 is true, executes the inline action n = RoundLoadUp(n).
        If roundUpBus1 Then n = RoundLoadUp(n)
        ' [LINE EXPLANATION] Sets the return value of Format24VLoadValue to CleanLoadNumberText(n) & "A".
        Format24VLoadValue = CleanLoadNumberText(n) & "A"
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Starts a conditional block that runs when InStr(1, UCase$(rawText), "A", vbTextCompare) > 0 is true.
        If InStr(1, UCase$(rawText), "A", vbTextCompare) > 0 Then
            ' [LINE EXPLANATION] Sets the return value of Format24VLoadValue to rawText.
            Format24VLoadValue = rawText
        ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
        Else
            ' [LINE EXPLANATION] Sets the return value of Format24VLoadValue to rawText & "A".
            Format24VLoadValue = rawText & "A"
        ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
        End If
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function Format24VLoadValue.
End Function

'-------------------------------------------------------------------------------
' Procedure : TryParseLoadNumber
' Scope/Type: Private Function
' Purpose   : Calculates or returns try parse load number.
' Parameters:
' valueIn (Variant) - Supplies value in.
' outNumber (Double) - Supplies out number.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function TryParseLoadNumber. Calculates or returns try parse load number.
Private Function TryParseLoadNumber(ByVal valueIn As Variant, ByRef outNumber As Double) As Boolean

    ' [LINE EXPLANATION] Declares procedure-level storage for s (String).
    Dim s As String

    ' [LINE EXPLANATION] Sets s to UCase$(Trim$(CStr(valueIn))).
    s = UCase$(Trim$(CStr(valueIn)))
    ' [LINE EXPLANATION] Sets s to Replace(s, "AMPS", "").
    s = Replace(s, "AMPS", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "AMP", "").
    s = Replace(s, "AMP", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, "A", "").
    s = Replace(s, "A", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, ",", "").
    s = Replace(s, ",", "")
    ' [LINE EXPLANATION] Sets s to Replace(s, " ", "").
    s = Replace(s, " ", "")

    ' [LINE EXPLANATION] Starts a conditional block that runs when IsNumeric(s) is true.
    If IsNumeric(s) Then
        ' [LINE EXPLANATION] Sets outNumber to CDbl(s).
        outNumber = CDbl(s)
        ' [LINE EXPLANATION] Sets the return value of TryParseLoadNumber to True.
        TryParseLoadNumber = True
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of TryParseLoadNumber to False.
        TryParseLoadNumber = False
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function TryParseLoadNumber.
End Function

'-------------------------------------------------------------------------------
' Procedure : RoundLoadUp
' Scope/Type: Private Function
' Purpose   : Calculates or returns round load up.
' Parameters:
' n (Double) - Supplies n.
' Returns   : Double.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function RoundLoadUp. Calculates or returns round load up.
Private Function RoundLoadUp(ByVal n As Double) As Double

    ' [LINE EXPLANATION] Starts a conditional block that runs when n <= 0# is true.
    If n <= 0# Then
        ' [LINE EXPLANATION] Sets the return value of RoundLoadUp to 0#.
        RoundLoadUp = 0#
    ' [LINE EXPLANATION] Tests the next alternative condition: n = Fix(n).
    ElseIf n = Fix(n) Then
        ' [LINE EXPLANATION] Sets the return value of RoundLoadUp to n.
        RoundLoadUp = n
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of RoundLoadUp to Fix(n) + 1#.
        RoundLoadUp = Fix(n) + 1#
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function RoundLoadUp.
End Function

'-------------------------------------------------------------------------------
' Procedure : CleanLoadNumberText
' Scope/Type: Private Function
' Purpose   : Calculates or returns clean load number text.
' Parameters:
' n (Double) - Supplies n.
' Returns   : String.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function CleanLoadNumberText. Calculates or returns clean load number text.
Private Function CleanLoadNumberText(ByVal n As Double) As String

    ' [LINE EXPLANATION] Starts a conditional block that runs when n = Fix(n) is true.
    If n = Fix(n) Then
        ' [LINE EXPLANATION] Sets the return value of CleanLoadNumberText to CStr(CLng(n)).
        CleanLoadNumberText = CStr(CLng(n))
    ' [LINE EXPLANATION] Starts the fallback branch used when the preceding If/ElseIf conditions were false.
    Else
        ' [LINE EXPLANATION] Sets the return value of CleanLoadNumberText to CStr(n).
        CleanLoadNumberText = CStr(n)
    ' [LINE EXPLANATION] Ends the current If/ElseIf/Else conditional block.
    End If

' [LINE EXPLANATION] Ends function CleanLoadNumberText.
End Function

'-------------------------------------------------------------------------------
' Procedure : IsPSUTypeFor24V
' Scope/Type: Private Function
' Purpose   : Checks whether PSU type for 24 v.
' Parameters:
' typ (String) - Supplies typ.
' Returns   : Boolean.
' Maintenance: Read the generated line explanations before changing dependencies,
'              worksheet names, headers, limits, or error-handling paths.
'-------------------------------------------------------------------------------
' [LINE EXPLANATION] Begins Function IsPSUTypeFor24V. Checks whether PSU type for 24 v.
Private Function IsPSUTypeFor24V(ByVal typ As String) As Boolean

    ' [LINE EXPLANATION] Declares procedure-level storage for t (String).
    Dim t As String
    ' [LINE EXPLANATION] Sets t to UCase$(Trim$(typ)).
    t = UCase$(Trim$(typ))
    ' [LINE EXPLANATION] Sets the return value of IsPSUTypeFor24V to (t = "PSU" Or Left$(t, 3) = "PSU").
    IsPSUTypeFor24V = (t = "PSU" Or Left$(t, 3) = "PSU")

' [LINE EXPLANATION] Ends function IsPSUTypeFor24V.
End Function

