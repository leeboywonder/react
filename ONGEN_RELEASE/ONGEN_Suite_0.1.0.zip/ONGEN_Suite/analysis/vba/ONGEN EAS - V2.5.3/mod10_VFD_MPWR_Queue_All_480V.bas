Attribute VB_Name = "mod10_VFD_MPWR_Queue_All_480V"
Option Explicit
'===============================================================================
' ONGEN EAS - ALL-480V RCP MPWR QUEUE SYNCHRONIZER
' Author: Lee Pierre, Principal Electrical Engineer
' Purpose: Permanent production module for the ONGEN Engineering Automation Suite.
'          This module is part of the V26.3 clean workflow baseline.
'===============================================================================



'===============================================================================
' ONGEN EAS - MPWR QUEUE FOR EVERY CONNECTED 480V RCP
'
' The module clones the workbook's EXISTING valid MPWR queue rows as templates.
' It does not fabricate a partial 140-column queue row.
'
' Every RCP represented in "VFD DWG MPWR GROUPS" receives exactly two MPWR rows:
'   PANEL_MPWR_1 = Incoming Power
'   PANEL_MPWR_2 = Power Groups Schematic
'
' A VFD is not required. PSU-only RCP panels are included.
'===============================================================================

Private Const SH_MPWR As String = "VFD DWG MPWR GROUPS"
Private Const SH_MPWR_LEGACY As String = "VFD_DWG_MPWR_GROUPS"
Private Const SH_QUEUE As String = "VFD_DWG_QUEUE"

Private Const PLAN_INCOMING As String = "PANEL_MPWR_1"
Private Const PLAN_GROUPS As String = "PANEL_MPWR_2"

Public Sub VFD_DWG_ENSURE_MPWR_QUEUE_ALL_480V()
    MPWRQ_Ensure True
End Sub

Public Sub VFD_DWG_ENSURE_MPWR_QUEUE_ALL_480V_SILENT()
    MPWRQ_Ensure False
End Sub

Public Sub VFD_DWG_DIAG_MPWR_QUEUE_ALL_480V()
    On Error GoTo FailHandler

    Dim wsMPWR As Worksheet
    Dim wsQ As Worksheet

    Set wsMPWR = MPWRQ_GetMPWRSheet()
    Set wsQ = MPWRQ_GetSheet(SH_QUEUE)

    If wsMPWR Is Nothing Then Err.Raise vbObjectError + 4301, , "MPWR group sheet not found."
    If wsQ Is Nothing Then Err.Raise vbObjectError + 4302, , "VFD_DWG_QUEUE not found."

    Dim panels As Object
    Set panels = MPWRQ_CollectPanels(wsMPWR)

    Dim queuePanels As Object
    Set queuePanels = MPWRQ_CurrentQueuePanels(wsQ)

    Dim missing As String
    Dim k As Variant
    Dim rec As Variant

    For Each k In panels.keys
        rec = panels(k)

        If Not queuePanels.Exists(UCase$(CStr(rec(0)) & "|" & CStr(rec(1)))) Then
            missing = missing & vbCrLf & _
                      " - Area " & CStr(rec(0)) & " / " & CStr(rec(1))
        End If
    Next k

    MsgBox _
        "Connected 480V RCP panels: " & panels.count & vbCrLf & _
        "RCP panels currently represented by MPWR queue rows: " & queuePanels.count & _
        IIf(Len(missing) > 0, vbCrLf & vbCrLf & "Missing:" & missing, vbCrLf & vbCrLf & "No panels are missing."), _
        vbInformation, _
        "ONGEN MPWR Queue Diagnostic"
    Exit Sub

FailHandler:
    MsgBox _
        "MPWR queue diagnostic failed." & vbCrLf & Err.description, _
        vbCritical, _
        "ONGEN MPWR Queue Diagnostic"
End Sub

Private Sub MPWRQ_Ensure(ByVal ShowMessage As Boolean)
    On Error GoTo FailHandler

    Dim oldCalc As XlCalculation
    Dim oldEvents As Boolean
    Dim oldScreen As Boolean

    oldCalc = Application.Calculation
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Dim wsMPWR As Worksheet
    Dim wsQ As Worksheet

    Set wsMPWR = MPWRQ_GetMPWRSheet()
    Set wsQ = MPWRQ_GetSheet(SH_QUEUE)

    If wsMPWR Is Nothing Then
        Err.Raise vbObjectError + 4310, "MPWRQ_Ensure", _
                  "The MPWR group worksheet was not found."
    End If

    If wsQ Is Nothing Then
        Err.Raise vbObjectError + 4311, "MPWRQ_Ensure", _
                  "VFD_DWG_QUEUE was not found."
    End If

    Dim panels As Object
    Set panels = MPWRQ_CollectPanels(wsMPWR)

    If panels.count = 0 Then
        Err.Raise vbObjectError + 4312, "MPWRQ_Ensure", _
                  "No connected RCP 480V panels were found."
    End If

    Dim headerRow As Long
    headerRow = MPWRQ_FindQueueHeaderRow(wsQ)

    If headerRow = 0 Then
        Err.Raise vbObjectError + 4313, "MPWRQ_Ensure", _
                  "The VFD drawing queue header row was not found."
    End If

    Dim lastCol As Long
    lastCol = wsQ.Cells(headerRow, wsQ.Columns.count).End(xlToLeft).Column

    Dim templateIncoming As Variant
    Dim templateGroups As Variant

    templateIncoming = MPWRQ_GetTemplateRow(wsQ, headerRow, lastCol, PLAN_INCOMING)
    templateGroups = MPWRQ_GetTemplateRow(wsQ, headerRow, lastCol, PLAN_GROUPS)

    If IsEmpty(templateIncoming) Then
        Err.Raise vbObjectError + 4314, "MPWRQ_Ensure", _
                  "No existing " & PLAN_INCOMING & " MPWR queue template row was found."
    End If

    If IsEmpty(templateGroups) Then
        Err.Raise vbObjectError + 4315, "MPWRQ_Ensure", _
                  "No existing " & PLAN_GROUPS & " MPWR queue template row was found."
    End If

    Dim oldState As Object
    Set oldState = MPWRQ_CaptureExistingState(wsQ, headerRow)

    MPWRQ_DeleteExistingMPWRRows wsQ, headerRow

    MPWRQ_AppendAllPanels _
        wsQ, headerRow, lastCol, panels, _
        templateIncoming, templateGroups, oldState

    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    If ShowMessage Then
        MsgBox _
            "MPWR drawing queue synchronized." & vbCrLf & _
            "Connected RCP panels: " & panels.count & vbCrLf & _
            "MPWR rows created: " & panels.count * 2, _
            vbInformation, _
            "ONGEN MPWR Queue"
    End If
    Exit Sub

FailHandler:
    Dim errNumber As Long
    Dim errDescription As String

    errNumber = Err.Number
    errDescription = Err.description

    On Error Resume Next
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    If ShowMessage Then
        MsgBox _
            "MPWR queue synchronization failed." & vbCrLf & vbCrLf & _
            "Error " & errNumber & ": " & errDescription, _
            vbCritical, _
            "ONGEN MPWR Queue"
    Else
        If errNumber = 0 Then errNumber = vbObjectError + 4399
        Err.Raise errNumber, "VFD_DWG_ENSURE_MPWR_QUEUE_ALL_480V_SILENT", errDescription
    End If
End Sub

Private Function MPWRQ_CollectPanels(ByVal ws As Worksheet) As Object
    Dim panels As Object
    Set panels = CreateObject("Scripting.Dictionary")
    panels.CompareMode = vbTextCompare

    Dim headerRow As Long
    headerRow = MPWRQ_FindMPWRHeaderRow(ws)

    If headerRow = 0 Then
        Set MPWRQ_CollectPanels = panels
        Exit Function
    End If

    Dim cArea As Long
    Dim cPanel As Long
    Dim cStatus As Long

    cArea = MPWRQ_FindHeader(ws, headerRow, Array( _
        "AREA_NUMBER", "AREA NUMBER", "AREA"))

    cPanel = MPWRQ_FindHeader(ws, headerRow, Array( _
        "RCP_PANEL", "RCP PANEL", "PANEL"))

    cStatus = MPWRQ_FindHeader(ws, headerRow, Array("STATUS"))

    Dim lastRow As Long
    lastRow = MPWRQ_LastRow(ws)

    Dim r As Long
    Dim areaVal As String
    Dim panelVal As String
    Dim statusVal As String
    Dim key As String

    For r = headerRow + 1 To lastRow
        areaVal = MPWRQ_Value(ws, r, cArea)
        panelVal = MPWRQ_Value(ws, r, cPanel)
        statusVal = UCase$(MPWRQ_Value(ws, r, cStatus))

        If Left$(UCase$(panelVal), 3) = "RCP" Then
            If InStr(1, statusVal, "SPARE", vbTextCompare) = 0 Then
                key = UCase$(Trim$(areaVal) & "|" & Trim$(panelVal))

                If Not panels.Exists(key) Then
                    panels.Add key, Array(areaVal, panelVal)
                End If
            End If
        End If
    Next r

    Set MPWRQ_CollectPanels = panels
End Function

Private Function MPWRQ_GetTemplateRow( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal lastCol As Long, _
    ByVal planID As String) As Variant

    Dim cPage As Long
    Dim cPlan As Long

    cPage = MPWRQ_FindHeader(ws, headerRow, Array("PAGE_CODE", "PAGE CODE"))
    cPlan = MPWRQ_FindHeader(ws, headerRow, Array("PLAN_ID", "PLAN ID"))

    Dim r As Long
    Dim lastRow As Long
    lastRow = MPWRQ_LastRow(ws)

    For r = headerRow + 1 To lastRow
        If UCase$(MPWRQ_Value(ws, r, cPage)) = "MPWR" And _
           StrComp(MPWRQ_Value(ws, r, cPlan), planID, vbTextCompare) = 0 Then

            MPWRQ_GetTemplateRow = _
                ws.Range(ws.Cells(r, 1), ws.Cells(r, lastCol)).Value2
            Exit Function
        End If
    Next r
End Function

Private Function MPWRQ_CaptureExistingState( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long) As Object

    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    Dim cPage As Long
    Dim cArea As Long
    Dim cPanel As Long
    Dim cPlan As Long
    Dim cStatus As Long
    Dim cPath As Long
    Dim cLast As Long
    Dim cNotes As Long

    cPage = MPWRQ_FindHeader(ws, headerRow, Array("PAGE_CODE", "PAGE CODE"))
    cArea = MPWRQ_FindHeader(ws, headerRow, Array("AREA_NUMBER", "AREA NUMBER"))
    cPanel = MPWRQ_FindHeader(ws, headerRow, Array("PANEL"))
    cPlan = MPWRQ_FindHeader(ws, headerRow, Array("PLAN_ID", "PLAN ID"))
    cStatus = MPWRQ_FindHeader(ws, headerRow, Array("STATUS"))
    cPath = MPWRQ_FindHeader(ws, headerRow, Array("OUTPUT_PATH", "OUTPUT PATH"))
    cLast = MPWRQ_FindHeader(ws, headerRow, Array("LAST_RUN", "LAST RUN"))
    cNotes = MPWRQ_FindHeader(ws, headerRow, Array("NOTES"))

    Dim r As Long
    Dim key As String

    For r = headerRow + 1 To MPWRQ_LastRow(ws)
        If UCase$(MPWRQ_Value(ws, r, cPage)) = "MPWR" Then
            key = UCase$( _
                MPWRQ_Value(ws, r, cArea) & "|" & _
                MPWRQ_Value(ws, r, cPanel) & "|" & _
                MPWRQ_Value(ws, r, cPlan))

            d(key) = Array( _
                MPWRQ_Value(ws, r, cStatus), _
                MPWRQ_Value(ws, r, cPath), _
                MPWRQ_Value(ws, r, cLast), _
                MPWRQ_Value(ws, r, cNotes))
        End If
    Next r

    Set MPWRQ_CaptureExistingState = d
End Function

Private Sub MPWRQ_DeleteExistingMPWRRows( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long)

    Dim cPage As Long
    cPage = MPWRQ_FindHeader(ws, headerRow, Array("PAGE_CODE", "PAGE CODE"))

    Dim r As Long

    For r = MPWRQ_LastRow(ws) To headerRow + 1 Step -1
        If UCase$(MPWRQ_Value(ws, r, cPage)) = "MPWR" Then
            ws.rows(r).Delete
        End If
    Next r
End Sub

Private Sub MPWRQ_AppendAllPanels( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal lastCol As Long, _
    ByVal panels As Object, _
    ByVal templateIncoming As Variant, _
    ByVal templateGroups As Variant, _
    ByVal oldState As Object)

    Dim keys As Variant
    keys = panels.keys
    MPWRQ_SortPanelKeys keys, panels

    Dim outRow As Long
    outRow = MPWRQ_LastRow(ws) + 1

    Dim currentArea As String
    Dim sheetNo As Long
    Dim i As Long
    Dim rec As Variant
    Dim areaVal As String
    Dim panelVal As String

    For i = LBound(keys) To UBound(keys)
        rec = panels(CStr(keys(i)))
        areaVal = CStr(rec(0))
        panelVal = CStr(rec(1))

        If StrComp(areaVal, currentArea, vbTextCompare) <> 0 Then
            currentArea = areaVal
            sheetNo = 1
        End If

        ws.Range(ws.Cells(outRow, 1), ws.Cells(outRow, lastCol)).Value2 = templateIncoming
        MPWRQ_ConfigureRow ws, headerRow, outRow, areaVal, panelVal, sheetNo, True, oldState
        outRow = outRow + 1
        sheetNo = sheetNo + 1

        ws.Range(ws.Cells(outRow, 1), ws.Cells(outRow, lastCol)).Value2 = templateGroups
        MPWRQ_ConfigureRow ws, headerRow, outRow, areaVal, panelVal, sheetNo, False, oldState
        outRow = outRow + 1
        sheetNo = sheetNo + 1
    Next i
End Sub

Private Sub MPWRQ_ConfigureRow( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal r As Long, _
    ByVal areaVal As String, _
    ByVal panelVal As String, _
    ByVal sheetNo As Long, _
    ByVal incoming As Boolean, _
    ByVal oldState As Object)

    Dim planID As String
    Dim sheetID As String
    Dim stateKey As String
    Dim drawingID As String
    Dim parentDrawingID As String
    Dim outputDwgName As String

    If incoming Then
        planID = PLAN_INCOMING
    Else
        planID = PLAN_GROUPS
    End If

    sheetID = "MPWR-" & Format$(sheetNo, "000")
    stateKey = UCase$(areaVal & "|" & panelVal & "|" & planID)

    parentDrawingID = "MPWR-" & areaVal & "-" & panelVal

    If incoming Then
        drawingID = parentDrawingID & "-01"
        outputDwgName = sheetID & " Incoming Power " & panelVal & ".dwg"
    Else
        drawingID = parentDrawingID & "-02"
        outputDwgName = sheetID & " Power Groups Schematic " & panelVal & ".dwg"
    End If

    MPWRQ_Set ws, headerRow, r, "ENABLED", "YES"
    MPWRQ_Set ws, headerRow, r, "DRAWING_ID", drawingID
    MPWRQ_Set ws, headerRow, r, "PARENT_DRAWING_ID", parentDrawingID

    MPWRQ_Set ws, headerRow, r, "PLAN_ID", planID
    MPWRQ_Set ws, headerRow, r, "PAGE_CODE", "MPWR"
    MPWRQ_Set ws, headerRow, r, "OUTPUT_DWG_NAME", outputDwgName

    MPWRQ_Set ws, headerRow, r, "SIS_ELEMENT_NUMBER", panelVal & " PANEL"
    MPWRQ_Set ws, headerRow, r, "SIS_SEQUENCE", panelVal
    MPWRQ_Set ws, headerRow, r, "AREA_NUMBER", areaVal
    MPWRQ_Set ws, headerRow, r, "SWITCHGROUP", vbNullString
    MPWRQ_Set ws, headerRow, r, "TYPE", "PNL"
    MPWRQ_Set ws, headerRow, r, "PANEL", panelVal
    MPWRQ_Set ws, headerRow, r, "SHEET_NUMBER", sheetID

    If incoming Then
        MPWRQ_Set ws, headerRow, r, "DRAWING_TITLE", "PANEL INCOMING POWER"
        MPWRQ_Set ws, headerRow, r, "DRAWING_DESCRIPTION", _
                  "Incoming Power " & panelVal
    Else
        MPWRQ_Set ws, headerRow, r, "DRAWING_TITLE", "PANEL POWER DISTRIBUTION"
        MPWRQ_Set ws, headerRow, r, "DRAWING_DESCRIPTION", _
                  "Power Groups Schematic " & panelVal
    End If

    MPWRQ_Set ws, headerRow, r, "DEVICE_COUNT", 1

    If oldState.Exists(stateKey) Then
        Dim oldRec As Variant
        oldRec = oldState(stateKey)

        MPWRQ_Set ws, headerRow, r, "STATUS", oldRec(0)
        MPWRQ_Set ws, headerRow, r, "OUTPUT_PATH", oldRec(1)
        MPWRQ_Set ws, headerRow, r, "LAST_RUN", oldRec(2)
        MPWRQ_Set ws, headerRow, r, "NOTES", oldRec(3)
    Else
        MPWRQ_Set ws, headerRow, r, "STATUS", "READY"
        MPWRQ_Set ws, headerRow, r, "OUTPUT_PATH", vbNullString
        MPWRQ_Set ws, headerRow, r, "LAST_RUN", vbNullString
    End If
End Sub

Private Function MPWRQ_CurrentQueuePanels(ByVal ws As Worksheet) As Object
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    Dim headerRow As Long
    headerRow = MPWRQ_FindQueueHeaderRow(ws)

    If headerRow = 0 Then
        Set MPWRQ_CurrentQueuePanels = d
        Exit Function
    End If

    Dim cPage As Long
    Dim cArea As Long
    Dim cPanel As Long

    cPage = MPWRQ_FindHeader(ws, headerRow, Array("PAGE_CODE"))
    cArea = MPWRQ_FindHeader(ws, headerRow, Array("AREA_NUMBER"))
    cPanel = MPWRQ_FindHeader(ws, headerRow, Array("PANEL"))

    Dim r As Long
    Dim key As String

    For r = headerRow + 1 To MPWRQ_LastRow(ws)
        If UCase$(MPWRQ_Value(ws, r, cPage)) = "MPWR" Then
            key = UCase$( _
                MPWRQ_Value(ws, r, cArea) & "|" & _
                MPWRQ_Value(ws, r, cPanel))

            d(key) = True
        End If
    Next r

    Set MPWRQ_CurrentQueuePanels = d
End Function

Private Sub MPWRQ_Set( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal r As Long, _
    ByVal headerName As String, _
    ByVal value As Variant)

    Dim c As Long
    c = MPWRQ_FindHeader(ws, headerRow, Array(headerName))

    If c > 0 Then ws.Cells(r, c).Value2 = value
End Sub

Private Function MPWRQ_GetMPWRSheet() As Worksheet
    Set MPWRQ_GetMPWRSheet = MPWRQ_GetSheet(SH_MPWR)

    If MPWRQ_GetMPWRSheet Is Nothing Then
        Set MPWRQ_GetMPWRSheet = MPWRQ_GetSheet(SH_MPWR_LEGACY)
    End If
End Function

Private Function MPWRQ_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set MPWRQ_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function MPWRQ_FindMPWRHeaderRow(ByVal ws As Worksheet) As Long
    Dim maxRow As Long
    maxRow = Application.Min(20, Application.Max(1, ws.UsedRange.rows.count))

    Dim r As Long

    For r = 1 To maxRow
        If MPWRQ_FindHeader(ws, r, Array( _
            "RCP_PANEL", "RCP PANEL", "PANEL")) > 0 And _
           MPWRQ_FindHeader(ws, r, Array( _
            "SWITCHGROUP", "SWITCH GROUP", "PWG")) > 0 Then

            MPWRQ_FindMPWRHeaderRow = r
            Exit Function
        End If
    Next r
End Function

Private Function MPWRQ_FindQueueHeaderRow(ByVal ws As Worksheet) As Long
    Dim maxRow As Long
    maxRow = Application.Min(20, Application.Max(1, ws.UsedRange.rows.count))

    Dim r As Long

    For r = 1 To maxRow
        If MPWRQ_FindHeader(ws, r, Array("DRAWING_ID")) > 0 And _
           MPWRQ_FindHeader(ws, r, Array("PAGE_CODE")) > 0 Then

            MPWRQ_FindQueueHeaderRow = r
            Exit Function
        End If
    Next r
End Function

Private Function MPWRQ_FindHeader( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal aliases As Variant) As Long

    If headerRow <= 0 Then Exit Function

    Dim lastCol As Long
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column

    Dim c As Long
    Dim a As Variant
    Dim key As String

    For c = 1 To lastCol
        key = MPWRQ_HeaderKey(ws.Cells(headerRow, c).Value2)

        For Each a In aliases
            If key = MPWRQ_HeaderKey(CStr(a)) Then
                MPWRQ_FindHeader = c
                Exit Function
            End If
        Next a
    Next c
End Function

Private Function MPWRQ_HeaderKey(ByVal value As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(value)))

    s = Replace$(s, "_", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "-", "")
    s = Replace$(s, "/", "")
    s = Replace$(s, ".", "")

    MPWRQ_HeaderKey = s
End Function

Private Function MPWRQ_Value( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal c As Long) As String

    If c <= 0 Then Exit Function
    If IsError(ws.Cells(r, c).Value2) Then Exit Function

    MPWRQ_Value = Trim$(CStr(ws.Cells(r, c).Value2))
End Function

Private Function MPWRQ_LastRow(ByVal ws As Worksheet) As Long
    On Error GoTo SafeExit

    Dim f As Range

    Set f = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    If Not f Is Nothing Then MPWRQ_LastRow = f.Row
    Exit Function

SafeExit:
    MPWRQ_LastRow = 0
End Function

Private Sub MPWRQ_SortPanelKeys(ByRef keys As Variant, ByVal panels As Object)
    If panels.count <= 1 Then Exit Sub

    Dim i As Long
    Dim j As Long
    Dim temp As Variant

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If MPWRQ_SortValue(panels(CStr(keys(j)))) < _
               MPWRQ_SortValue(panels(CStr(keys(i)))) Then

                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next j
    Next i
End Sub

Private Function MPWRQ_SortValue(ByVal rec As Variant) As String
    MPWRQ_SortValue = _
        Format$(val(CStr(rec(0))), "000000") & "|" & _
        UCase$(CStr(rec(1)))
End Function
