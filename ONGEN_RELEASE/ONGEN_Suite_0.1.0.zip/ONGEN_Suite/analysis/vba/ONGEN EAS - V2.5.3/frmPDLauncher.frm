Attribute VB_Name = "frmPDLauncher"
Attribute VB_Base = "0{B73B0030-11C8-469D-93AF-8945A7943FF4}{76F95CD2-9266-42BD-BAF9-1A876065618A}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit

'===============================================================================
' ONGEN WORKSHEET LAUNCHER
' Form name: frmPDLauncher
' Release: V16.2-R8.2
' Author: Lee Pierre
'
' REQUIRED EXISTING CONTROLS
'   lblTitle    Label
'   txtSearch   TextBox
'   lstSheets   ListBox
'   cmdOpen     CommandButton
'   cmdRefresh  CommandButton
'   cmdHome     CommandButton
'   cmdClose    CommandButton
'
' PURPOSE
'   Lists every worksheet in the workbook, supports searching, opens hidden
'   worksheets when permitted, refreshes workbook data, and returns to MAIN.
'
' IMPORTANT
'   This code intentionally does not use:
'       Me.Visible = True
'       Me.Visible = False
'   Those assignments can cause a restricted-interface compile error.
'===============================================================================

Private Const MAIN_SHEET_NAME As String = "MAIN"
Private Const FORM_TITLE As String = "ONGEN Workbook Worksheet Launcher"


'===============================================================================
' FORM STARTUP
'===============================================================================

Private Sub UserForm_Initialize()
    On Error GoTo EH

    ' Set the title displayed in the UserForm window.
    Me.caption = FORM_TITLE

    ' Apply a consistent layout to the existing form controls.
    SetupFormLayout

    ' Load every worksheet into the launcher list.
    LoadWorksheetList vbNullString

    Exit Sub

EH:
    MsgBox "The worksheet launcher could not be initialized." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbExclamation, _
           FORM_TITLE
End Sub


Private Sub UserForm_Activate()
    On Error Resume Next

    ' Place the cursor in the search box whenever the launcher is displayed.
    txtSearch.SetFocus
End Sub


'===============================================================================
' FORM LAYOUT
'===============================================================================

Private Sub SetupFormLayout()
    ' Set the overall UserForm size.
    Me.Width = 560
    Me.Height = 420

    ' Configure the heading label.
    With lblTitle
        .caption = "Search worksheets by name, group, or visibility"
        .Left = 12
        .Top = 12
        .Width = 520
        .Height = 24
    End With

    ' Configure the search TextBox.
    With txtSearch
        .Left = 12
        .Top = 45
        .Width = 520
        .Height = 22
    End With

    ' Configure the worksheet ListBox.
    With lstSheets
        .Left = 12
        .Top = 80
        .Width = 520
        .Height = 250
        .columnCount = 3
        .ColumnWidths = "125 pt;285 pt;90 pt"
    End With

    ' Configure the Open Selected button.
    With cmdOpen
        .Left = 12
        .Top = 345
        .Width = 110
        .Height = 28
        .caption = "Open Selected"
        .Default = True
    End With

    ' Configure the Refresh List button.
    With cmdRefresh
        .Left = 132
        .Top = 345
        .Width = 110
        .Height = 28
        .caption = "Refresh List"
    End With

    ' Configure the Return to MAIN button.
    With cmdHome
        .Left = 252
        .Top = 345
        .Width = 110
        .Height = 28
        .caption = "Return to MAIN"
    End With

    ' Configure the Close button.
    With cmdClose
        .Left = 422
        .Top = 345
        .Width = 110
        .Height = 28
        .caption = "Close"
        .Cancel = True
    End With
End Sub


'===============================================================================
' CONTROL EVENTS
'===============================================================================

Private Sub txtSearch_Change()
    ' Rebuild the worksheet list using the current search text.
    LoadWorksheetList txtSearch.text
End Sub


Private Sub cmdOpen_Click()
    ' Open the worksheet selected in the ListBox.
    OpenSelectedWorksheet
End Sub


Private Sub lstSheets_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    ' Open the selected worksheet when its row is double-clicked.
    OpenSelectedWorksheet
End Sub


Private Sub cmdRefresh_Click()
    Dim previousStatusBar As Variant

    On Error GoTo EH

    ' Preserve the current Excel status-bar value.
    previousStatusBar = Application.StatusBar

    ' Tell the user that workbook refresh is running.
    Application.StatusBar = "ONGEN: Refreshing workbook data..."

    ' Refresh workbook connections, queries, PivotTables, and other refreshable
    ' objects that are controlled by Excel's RefreshAll command.
    ThisWorkbook.RefreshAll

    ' Recalculate formulas throughout Excel.
    Application.CalculateFull

    ' Rebuild the worksheet list after the refresh.
    LoadWorksheetList txtSearch.text

CleanExit:
    ' Restore Excel's original status-bar setting.
    Application.StatusBar = previousStatusBar
    Exit Sub

EH:
    MsgBox "The workbook refresh could not be completed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbExclamation, _
           FORM_TITLE
    Resume CleanExit
End Sub


Private Sub cmdHome_Click()
    ' Open the MAIN worksheet and close the launcher.
    OpenWorksheetByName MAIN_SHEET_NAME
End Sub


Private Sub cmdClose_Click()
    ' Close and remove the launcher from memory.
    Unload Me
End Sub


'===============================================================================
' WORKSHEET LIST
'===============================================================================

Private Sub LoadWorksheetList(ByVal filterText As String)
    Dim ws As Worksheet
    Dim rows() As String
    Dim rowCount As Long
    Dim i As Long
    Dim groupName As String
    Dim visibilityText As String
    Dim normalizedFilter As String

    On Error GoTo EH

    ' Normalize the search value for case-insensitive matching.
    normalizedFilter = UCase$(Trim$(filterText))

    ' Clear all existing launcher rows.
    lstSheets.Clear

    ' Reapply the ListBox column settings in case Excel reset them.
    lstSheets.columnCount = 3
    lstSheets.ColumnWidths = "125 pt;285 pt;90 pt"

    ' Examine every worksheet in the workbook.
    For Each ws In ThisWorkbook.Worksheets
        ' Determine the worksheet's workflow category.
        groupName = GetWorkflowGroup(ws.Name)

        ' Convert Excel's visibility constant into user-friendly text.
        visibilityText = GetWorksheetVisibilityText(ws)

        ' Add the worksheet when the search is blank or matches any displayed
        ' worksheet property.
        If WorksheetMatchesFilter( _
                ws.Name, _
                groupName, _
                visibilityText, _
                normalizedFilter) Then

            rowCount = rowCount + 1

            ' Resize the temporary two-dimensional array while preserving rows.
            ReDim Preserve rows(1 To 3, 1 To rowCount)

            ' Store Group, Worksheet Name, and Visibility.
            rows(1, rowCount) = groupName
            rows(2, rowCount) = ws.Name
            rows(3, rowCount) = visibilityText
        End If
    Next ws

    ' Sort the temporary array by workflow group and then worksheet name.
    If rowCount > 1 Then
        SortWorksheetRows rows, rowCount
    End If

    ' Transfer the sorted rows into the ListBox.
    For i = 1 To rowCount
        lstSheets.AddItem rows(1, i)
        lstSheets.List(lstSheets.ListCount - 1, 1) = rows(2, i)
        lstSheets.List(lstSheets.ListCount - 1, 2) = rows(3, i)
    Next i

    ' Select the first result automatically.
    If lstSheets.ListCount > 0 Then
        lstSheets.ListIndex = 0
    End If

    ' Update the heading with the number of matching worksheets.
    lblTitle.caption = "Worksheets found: " & CStr(lstSheets.ListCount) & _
                       "  |  Search by name, group, or visibility"

    Exit Sub

EH:
    MsgBox "The worksheet list could not be loaded." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbExclamation, _
           FORM_TITLE
End Sub


Private Function WorksheetMatchesFilter( _
    ByVal sheetName As String, _
    ByVal groupName As String, _
    ByVal visibilityText As String, _
    ByVal normalizedFilter As String) As Boolean

    ' A blank search displays every worksheet.
    If Len(normalizedFilter) = 0 Then
        WorksheetMatchesFilter = True
        Exit Function
    End If

    ' Match the worksheet name.
    If InStr(1, UCase$(sheetName), normalizedFilter, vbBinaryCompare) > 0 Then
        WorksheetMatchesFilter = True
        Exit Function
    End If

    ' Match the workflow group.
    If InStr(1, UCase$(groupName), normalizedFilter, vbBinaryCompare) > 0 Then
        WorksheetMatchesFilter = True
        Exit Function
    End If

    ' Match Visible, Hidden, or Very Hidden.
    If InStr(1, UCase$(visibilityText), normalizedFilter, vbBinaryCompare) > 0 Then
        WorksheetMatchesFilter = True
    End If
End Function


Private Sub SortWorksheetRows(ByRef rows() As String, ByVal rowCount As Long)
    Dim i As Long
    Dim j As Long
    Dim leftKey As String
    Dim rightKey As String
    Dim temporaryValue As String
    Dim columnIndex As Long

    ' Use a simple sort because workbook worksheet counts are normally small.
    For i = 1 To rowCount - 1
        For j = i + 1 To rowCount
            leftKey = UCase$(rows(1, i) & "|" & rows(2, i))
            rightKey = UCase$(rows(1, j) & "|" & rows(2, j))

            If rightKey < leftKey Then
                ' Swap all three displayed columns.
                For columnIndex = 1 To 3
                    temporaryValue = rows(columnIndex, i)
                    rows(columnIndex, i) = rows(columnIndex, j)
                    rows(columnIndex, j) = temporaryValue
                Next columnIndex
            End If
        Next j
    Next i
End Sub


Private Function GetWorksheetVisibilityText(ByVal ws As Worksheet) As String
    ' Return a readable description for each Excel visibility state.
    Select Case ws.Visible
        Case xlSheetVisible
            GetWorksheetVisibilityText = "Visible"

        Case xlSheetHidden
            GetWorksheetVisibilityText = "Hidden"

        Case xlSheetVeryHidden
            GetWorksheetVisibilityText = "Very Hidden"

        Case Else
            GetWorksheetVisibilityText = "Unknown"
    End Select
End Function


Private Function GetWorkflowGroup(ByVal sheetName As String) As String
    Dim normalizedName As String

    ' Normalize the worksheet name for case-insensitive classification.
    normalizedName = UCase$(Trim$(sheetName))

    Select Case True
        Case normalizedName = "MAIN"
            GetWorkflowGroup = "00 - Dashboard"

        Case InStr(1, normalizedName, "VALIDATION", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "AUDIT", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "ERROR", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "LOG", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "MISSING", vbBinaryCompare) > 0
            GetWorkflowGroup = "90 - Validation / Logs"

        Case InStr(1, normalizedName, "ROUTE", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "NETWORK", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "RCP", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "TOPOLOGY", vbBinaryCompare) > 0
            GetWorkflowGroup = "50 - Network / Route"

        Case InStr(1, normalizedName, "VFD", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "480V", vbBinaryCompare) > 0
            GetWorkflowGroup = "40 - 480V / VFD"

        Case InStr(1, normalizedName, "24V", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "PSU", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "POWER", vbBinaryCompare) > 0
            GetWorkflowGroup = "30 - 24V / Power"

        Case InStr(1, normalizedName, "PD6", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "SIS", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "DEFINITION", vbBinaryCompare) > 0
            GetWorkflowGroup = "20 - PD6 / Definition"

        Case InStr(1, normalizedName, "IO_", vbBinaryCompare) > 0 _
          Or Left$(normalizedName, 3) = "IO " _
          Or InStr(1, normalizedName, "BECKHOFF", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "ETHERCAT", vbBinaryCompare) > 0
            GetWorkflowGroup = "10 - Beckhoff / IO"

        Case InStr(1, normalizedName, "DATA", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "CONFIG", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "LIBRARY", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "LOOKUP", vbBinaryCompare) > 0 _
          Or InStr(1, normalizedName, "MAP", vbBinaryCompare) > 0
            GetWorkflowGroup = "80 - Data / Configuration"

        Case Else
            GetWorkflowGroup = "70 - Other Worksheets"
    End Select
End Function


'===============================================================================
' OPEN WORKSHEET
'===============================================================================

Private Sub OpenSelectedWorksheet()
    Dim sheetName As String

    On Error GoTo EH

    ' Require one selected row.
    If lstSheets.ListIndex < 0 Then
        MsgBox "Select a worksheet first.", _
               vbInformation, _
               FORM_TITLE
        Exit Sub
    End If

    ' Column 1 contains the worksheet name.
    sheetName = CStr(lstSheets.List(lstSheets.ListIndex, 1))

    ' Open the selected worksheet.
    OpenWorksheetByName sheetName

    Exit Sub

EH:
    MsgBox "The selected worksheet could not be opened." & vbCrLf & _
           "Worksheet: " & sheetName & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbExclamation, _
           FORM_TITLE
End Sub


Private Sub OpenWorksheetByName(ByVal sheetName As String)
    Dim ws As Worksheet

    On Error GoTo EH

    ' Confirm that the requested worksheet still exists.
    If Not WorksheetExists(sheetName) Then
        MsgBox "Worksheet '" & sheetName & "' no longer exists." & vbCrLf & _
               "Click Refresh List to reload the launcher.", _
               vbExclamation, _
               FORM_TITLE

        LoadWorksheetList txtSearch.text
        Exit Sub
    End If

    ' Store a direct reference to the requested worksheet.
    Set ws = ThisWorkbook.Worksheets(sheetName)

    ' A hidden worksheet must be made visible before it can be activated.
    If ws.Visible <> xlSheetVisible Then
        If ThisWorkbook.ProtectStructure Then
            MsgBox "Worksheet '" & sheetName & "' is hidden, but the workbook " & _
                   "structure is protected." & vbCrLf & _
                   "Unprotect the workbook structure before opening this sheet.", _
                   vbExclamation, _
                   FORM_TITLE
            Exit Sub
        End If

        ws.Visible = xlSheetVisible
    End If

    ' Activate the workbook containing the launcher.
    ThisWorkbook.Activate

    ' Activate the requested worksheet while the form is still loaded.
    ws.Activate

    ' Close the launcher after the worksheet opens successfully.
    Unload Me

    Exit Sub

EH:
    MsgBox "Worksheet '" & sheetName & "' could not be opened." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.description, _
           vbExclamation, _
           FORM_TITLE
End Sub


Private Function WorksheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet

    On Error Resume Next

    ' Attempt to obtain the worksheet by name.
    Set ws = ThisWorkbook.Worksheets(sheetName)

    ' A non-Nothing reference means the worksheet exists.
    WorksheetExists = Not ws Is Nothing

    On Error GoTo 0
End Function

