Attribute VB_Name = "IMPORT_IO_TOPOLOGY"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.5 - Split 24V / 480V Exports
' Module          : IMPORT_IO_TOPOLOGY
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Logic preserved from uploaded workbook; included in synchronized full BAS package.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.2-INDUSTRIAL-FULL-RELEASE
' Module        : IMPORT_IO_TOPOLOGY
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : V25.8.4-C05 audit repair; imports every RCP panel block from CSV/XLSX sources.
' Notes         : Scans all source worksheets, all RCP blocks per sheet, and the true used row/column extent.
'-------------------------------------------------------------------------------

' Require every variable to be declared before use, which prevents spelling mistakes from creating unintended variables.
' [R7 LINE] Requires explicit variable declarations to prevent misspelled variables.
Option Explicit

'-------------------------------------------------------------------------------
' ONGEN RELEASE CONTROL
' Release Package : ONGEN Beckhoff 24V Combined Template V16.2
' Release ID      : V16.2-R7
' Source Baseline : ONGEN_Beckhoff_24V_Combined_Template_V16.1.xlsm
' Release Date    : 2026-07-13
' Author/Owner    : Lee Pierre, Principal Electrical Engineer
'-------------------------------------------------------------------------------

' [R7 LINE] Starts Sub Import_IO_Topology_Uplinks_From_CSV; the following statements perform or calculate this named workflow.
Public Sub Import_IO_Topology_Uplinks_From_CSV()
    Dim destWB As Workbook
    Dim srcWB As Workbook
    Dim filePath As Variant
    Dim wsSrc As Worksheet
    Dim generationMode As Long
    Dim importedCount As Long
    Dim skippedCount As Long
    Dim usableSourceCount As Long
    Dim oldScreenUpdating As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim sheetIndex As Long
    Dim sourceType As String
    Dim detectedPanelCount As Long
    Dim processedPanelCount As Long

    On Error GoTo EH
    Set destWB = ThisWorkbook
    oldScreenUpdating = Application.ScreenUpdating
    oldDisplayAlerts = Application.DisplayAlerts

    generationMode = ONGEN_GetGenerationMode()
    If generationMode = ONGEN_GEN_CANCEL Then
        generationMode = ONGEN_RequestGenerationModeForCategory( _
                             "Step 11 - Import IO Topology CSV/XLSX", _
                             ONGEN_CATEGORY_RAW_RCP, "raw RCP topology worksheet")
    End If
    If generationMode = ONGEN_GEN_CANCEL Then Exit Sub

    filePath = Application.GetOpenFilename( _
        FileFilter:="Supported Topology Files (*.csv;*.xlsx),*.csv;*.xlsx,CSV Files (*.csv),*.csv,Excel Workbooks (*.xlsx),*.xlsx", _
        title:="Select Source CSV or XLSX File")
    If VarType(filePath) = vbBoolean Then
        If filePath = False Then GoTo SafeExit
    End If

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    sourceType = UCase$(mid$(CStr(filePath), InStrRev(CStr(filePath), ".") + 1))
    If sourceType <> "CSV" And sourceType <> "XLSX" Then
        Err.Raise vbObjectError + 31101, "Import_IO_Topology_Uplinks_From_CSV", _
                  "Step 11 supports .csv and .xlsx source files only."
    End If

    Set srcWB = Workbooks.Open(CStr(filePath), ReadOnly:=True)

    'First pass: count every panel before changing the destination workbook.
    'This protects overwrite mode from deleting valid panels before the source is proven usable.
    For Each wsSrc In srcWB.Worksheets
        If IT_SheetLooksLikeRawRCPTopology(wsSrc) Then
            usableSourceCount = usableSourceCount + 1
            detectedPanelCount = detectedPanelCount + 1
        ElseIf IT_SheetContainsIPCUplinkBlocks(wsSrc) Then
            usableSourceCount = usableSourceCount + 1
            detectedPanelCount = detectedPanelCount + IT_CountPanelBlocks(wsSrc)
        End If
    Next wsSrc

    If usableSourceCount = 0 Or detectedPanelCount = 0 Then
        Err.Raise vbObjectError + 31102, "Import_IO_Topology_Uplinks_From_CSV", _
                  "No usable IO topology was found. Expected an RCP-* worksheet with X1-X9/X01-X09 headers, " & _
                  "or one or more RCP_### / RCP-### panel headings in column A."
    End If

    If generationMode = ONGEN_GEN_OVERWRITE Then
        For sheetIndex = destWB.Worksheets.count To 1 Step -1
            If ONGEN_IsGeneratedCategorySheet( _
                    destWB.Worksheets(sheetIndex).Name, ONGEN_CATEGORY_RAW_RCP) Then
                destWB.Worksheets(sheetIndex).Delete
            End If
        Next sheetIndex
    End If

    'Second pass: import every detected panel block. XLSX files can contain many panels per worksheet.
    For Each wsSrc In srcWB.Worksheets
        If IT_SheetLooksLikeRawRCPTopology(wsSrc) Then
            IT_ImportDirectRawRCPSheet wsSrc, destWB, generationMode, importedCount, skippedCount
            processedPanelCount = processedPanelCount + 1
        ElseIf IT_SheetContainsIPCUplinkBlocks(wsSrc) Then
            IT_ImportFlattenedUplinkBlocks wsSrc, destWB, generationMode, importedCount, skippedCount, processedPanelCount
        End If
    Next wsSrc

    If processedPanelCount <> detectedPanelCount Then
        Err.Raise vbObjectError + 31103, "Import_IO_Topology_Uplinks_From_CSV", _
                  "Topology panel-count verification failed. Detected " & CStr(detectedPanelCount) & _
                  " panel(s) but processed " & CStr(processedPanelCount) & ". No partial-success result will be reported."
    End If

    Application.CutCopyMode = False
    srcWB.Close SaveChanges:=False
    Set srcWB = Nothing
    SetImportedNetworkMode destWB, sourceType

    AppendLog "11 - Import IO Topology CSV/XLSX", "OK", _
              CStr(importedCount) & " worksheet(s) imported; " & _
              CStr(skippedCount) & " existing worksheet(s) preserved; " & _
              CStr(detectedPanelCount) & " panel(s) detected; source=" & sourceType & "."

    MsgBox "CSV/XLSX IO topology import complete." & vbCrLf & _
           "Imported or overwritten: " & CStr(importedCount) & vbCrLf & _
           "Preserved as existing: " & CStr(skippedCount) & vbCrLf & _
           "Panels detected in source: " & CStr(detectedPanelCount) & vbCrLf & vbCrLf & _
           "Step 12 will isolate RIO and IO/S whenever ports are available.", _
           vbInformation, "ONGEN Step 11"

SafeExit:
    On Error Resume Next
    If Not srcWB Is Nothing Then srcWB.Close SaveChanges:=False
    Application.CutCopyMode = False
    Application.DisplayAlerts = oldDisplayAlerts
    Application.ScreenUpdating = oldScreenUpdating
    ONGEN_ClearGenerationMode
    On Error GoTo 0
    Exit Sub

EH:
    AppendLog "11 - Import IO Topology CSV/XLSX", "ERROR", Err.description
    MsgBox "CSV/XLSX IO topology import failed." & vbCrLf & vbCrLf & Err.description, _
           vbCritical, "ONGEN Step 11"
    Resume SafeExit
End Sub
' [R7 LINE] Starts Sub SetImportedNetworkMode; the following statements perform or calculate this named workflow.
Private Function IT_SheetContainsIPCUplinkBlocks(ByVal ws As Worksheet) As Boolean
    IT_SheetContainsIPCUplinkBlocks = (IT_CountPanelBlocks(ws) > 0)
End Function

Private Function IT_CountPanelBlocks(ByVal ws As Worksheet) As Long
    Dim lastRow As Long, r As Long
    lastRow = IT_LastUsedRow(ws)
    For r = 1 To lastRow
        If IT_IsPanelHeaderText(CStr(ws.Cells(r, "A").Value2)) Then
            IT_CountPanelBlocks = IT_CountPanelBlocks + 1
        End If
    Next r
End Function

Private Function IT_SheetLooksLikeRawRCPTopology(ByVal ws As Worksheet) As Boolean
    Dim normalizedName As String, lastCol As Long, c As Long, portText As String, portCount As Long
    normalizedName = UCase$(Replace(Trim$(ws.Name), "_", "-"))
    If Left$(normalizedName, 4) <> "RCP-" Then Exit Function

    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lastCol
        portText = Trim$(CStr(ws.Cells(1, c).Value2))
        If IT_IsNetworkPortHeader(portText) Then portCount = portCount + 1
    Next c
    IT_SheetLooksLikeRawRCPTopology = (portCount > 0)
End Function

Private Function IT_IsNetworkPortHeader(ByVal valueText As String) As Boolean
    Dim t As String, n As String
    t = UCase$(Trim$(valueText))
    If Left$(t, 1) <> "X" Then Exit Function
    n = mid$(t, 2)
    If Len(n) < 1 Or Len(n) > 2 Or Not IsNumeric(n) Then Exit Function
    IT_IsNetworkPortHeader = (CLng(n) >= 1 And CLng(n) <= 9)
End Function

Private Sub IT_ImportDirectRawRCPSheet(ByVal wsSrc As Worksheet, ByVal destWB As Workbook, _
                                       ByVal generationMode As Long, ByRef importedCount As Long, _
                                       ByRef skippedCount As Long)
    Dim wsDst As Worksheet, dstName As String
    Dim lastRow As Long, lastCol As Long
    Dim lastCell As Range

    dstName = CleanSheetName(Replace(wsSrc.Name, "_", "-"))
    If generationMode = ONGEN_GEN_MISSING_ONLY And SheetExists(destWB, dstName) Then
        skippedCount = skippedCount + 1
        Exit Sub
    End If

    Set lastCell = wsSrc.Cells.Find(What:="*", After:=wsSrc.Cells(1, 1), LookIn:=xlFormulas, _
                                    LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                    MatchCase:=False)
    If lastCell Is Nothing Then Exit Sub
    lastRow = lastCell.Row
    Set lastCell = wsSrc.Cells.Find(What:="*", After:=wsSrc.Cells(1, 1), LookIn:=xlFormulas, _
                                    LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, _
                                    MatchCase:=False)
    lastCol = lastCell.Column

    Set wsDst = GetOrCreateSheet(destWB, dstName)
    wsDst.Cells.Clear
    wsDst.Range("A1").Resize(lastRow, lastCol).Value2 = _
        wsSrc.Range("A1").Resize(lastRow, lastCol).Value2
    wsDst.Columns.AutoFit
    importedCount = importedCount + 1
End Sub

Private Sub IT_ImportFlattenedUplinkBlocks(ByVal wsSrc As Worksheet, ByVal destWB As Workbook, _
                                           ByVal generationMode As Long, ByRef importedCount As Long, _
                                           ByRef skippedCount As Long, ByRef processedPanelCount As Long)
    Dim wsDst As Worksheet
    Dim lastRow As Long, lastCol As Long, r As Long, startRow As Long, endRow As Long
    Dim cellText As String, dstName As String

    'Use the true used row. Column A usually ends at the final RCP heading while topology data continues in B:I.
    lastRow = IT_LastUsedRow(wsSrc)
    r = 1
    Do While r <= lastRow
        cellText = Trim$(CStr(wsSrc.Cells(r, "A").Value2))
        If IT_IsPanelHeaderText(cellText) Then
            dstName = IT_ExtractPanelName(cellText)
            processedPanelCount = processedPanelCount + 1
            startRow = r + 1
            endRow = FindNextUplinkRow(wsSrc, startRow, lastRow) - 1
            If endRow < startRow Then endRow = lastRow

            If generationMode = ONGEN_GEN_MISSING_ONLY And SheetExists(destWB, dstName) Then
                skippedCount = skippedCount + 1
            Else
                lastCol = LastUsedColumnInRows(wsSrc, startRow, endRow)
                If lastCol < 2 Then
                    Err.Raise vbObjectError + 31104, "IT_ImportFlattenedUplinkBlocks", _
                              "Panel '" & dstName & "' was detected on source sheet '" & wsSrc.Name & _
                              "' but no topology columns were found below its heading."
                End If

                Set wsDst = GetOrCreateSheet(destWB, dstName)
                wsDst.Cells.Clear
                wsDst.Range("A1").Resize(endRow - startRow + 1, lastCol - 1).Value2 = _
                    wsSrc.Range(wsSrc.Cells(startRow, 2), wsSrc.Cells(endRow, lastCol)).Value2
                wsDst.Columns.AutoFit
                importedCount = importedCount + 1
            End If
            r = endRow + 1
        Else
            r = r + 1
        End If
    Loop
End Sub

Private Function IT_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim lastCell As Range
    On Error Resume Next
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                                 LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                 MatchCase:=False)
    On Error GoTo 0
    If lastCell Is Nothing Then
        IT_LastUsedRow = 0
    Else
        IT_LastUsedRow = lastCell.Row
    End If
End Function

Private Function IT_IsPanelHeaderText(ByVal valueText As String) As Boolean
    IT_IsPanelHeaderText = (Len(IT_ExtractPanelName(valueText)) > 0)
End Function

Private Function IT_ExtractPanelName(ByVal valueText As String) As String
    Dim t As String, u As String, p As Long, i As Long, digits As String, ch As String
    t = Trim$(valueText)
    u = UCase$(t)

    p = InStr(1, u, "RCP_", vbBinaryCompare)
    If p = 0 Then p = InStr(1, u, "RCP-", vbBinaryCompare)
    If p = 0 Then Exit Function

    'Panel headings must begin with RCP after trimming; this avoids matching device descriptions.
    If p <> 1 Then Exit Function
    For i = p + 4 To Len(t)
        ch = mid$(t, i, 1)
        If ch Like "#" Then
            digits = digits & ch
        ElseIf Len(digits) > 0 Then
            Exit For
        Else
            Exit Function
        End If
    Next i
    If Len(digits) = 0 Then Exit Function
    IT_ExtractPanelName = CleanSheetName("RCP-" & digits)
End Function

Private Sub SetImportedNetworkMode(ByVal wb As Workbook, ByVal modeName As String)
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim ws As Worksheet

    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
    Set ws = wb.Worksheets("IO_Topology")
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0

    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If ws Is Nothing Then
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ' [R7 LINE] Calculates or updates ws.Name using the expression in this statement.
        ws.Name = "IO_Topology"
    ' [R7 LINE] Ends the current conditional block.
    End If

    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Range("A1").value = "IO_Topology"
    ' [R7 LINE] Executes this VBA statement to continue the current routing, worksheet, or launcher workflow.
    ws.Range("B1").value = "MODE=" & UCase$(Trim$(modeName))
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Sub

' [R7 LINE] Starts Function FindNextUplinkRow; the following statements perform or calculate this named workflow.
Private Function FindNextUplinkRow(ByVal ws As Worksheet, ByVal startRow As Long, ByVal lastRow As Long) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim r As Long
    
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For r = startRow To lastRow
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If IT_IsPanelHeaderText(CStr(ws.Cells(r, "A").Value2)) Then
            ' [R7 LINE] Calculates or updates FindNextUplinkRow using the expression in this statement.
            FindNextUplinkRow = r
            ' [R7 LINE] Leaves the current Function immediately and returns its assigned result.
            Exit Function
        ' [R7 LINE] Ends the current conditional block.
        End If
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next r
    
    ' [R7 LINE] Calculates or updates FindNextUplinkRow using the expression in this statement.
    FindNextUplinkRow = lastRow + 1
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function LastUsedColumnInRows; the following statements perform or calculate this named workflow.
Private Function LastUsedColumnInRows(ByVal ws As Worksheet, ByVal startRow As Long, ByVal endRow As Long) As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim r As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim c As Long
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim maxCol As Long
    
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For r = startRow To endRow
        ' [R7 LINE] Calculates or updates c using the expression in this statement.
        c = ws.Cells(r, ws.Columns.count).End(xlToLeft).Column
        ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
        If c > maxCol Then maxCol = c
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next r
    
    ' [R7 LINE] Calculates or updates LastUsedColumnInRows using the expression in this statement.
    LastUsedColumnInRows = maxCol
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function GetOrCreateSheet; the following statements perform or calculate this named workflow.
Private Function GetOrCreateSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    
    ' [R7 LINE] Calculates or updates sheetName using the expression in this statement.
    sheetName = CleanSheetName(sheetName)
    
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If SheetExists(wb, sheetName) Then
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to GetOrCreateSheet.
        Set GetOrCreateSheet = wb.Worksheets(sheetName)
    ' [R7 LINE] Runs the fallback branch when the preceding conditions were false.
    Else
        ' [R7 LINE] Assigns the required workbook object or dictionary reference to GetOrCreateSheet.
        Set GetOrCreateSheet = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ' [R7 LINE] Calculates or updates GetOrCreateSheet.name using the expression in this statement.
        GetOrCreateSheet.Name = sheetName
    ' [R7 LINE] Ends the current conditional block.
    End If

' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function SheetExists; the following statements perform or calculate this named workflow.
Private Function SheetExists(ByVal wb As Workbook, ByVal sheetName As String) As Boolean
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim ws As Worksheet
    
    ' Temporarily continue past the next runtime error so an optional object or value can be checked safely.
    ' [R7 LINE] Temporarily suppresses the next optional runtime error so the code can test an object or value.
    On Error Resume Next
    ' [R7 LINE] Assigns the required workbook object or dictionary reference to ws.
    Set ws = wb.Worksheets(sheetName)
    ' [R7 LINE] Routes later runtime errors to the named error-handling section.
    On Error GoTo 0
    
    ' [R7 LINE] Calculates or updates SheetExists using the expression in this statement.
    SheetExists = Not ws Is Nothing
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

' [R7 LINE] Starts Function CleanSheetName; the following statements perform or calculate this named workflow.
Private Function CleanSheetName(ByVal sheetName As String) As String
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim badChars As Variant
    ' [R7 LINE] Declares the local variables used by the current procedure.
    Dim i As Long
    
    ' [R7 LINE] Calculates or updates badChars using the expression in this statement.
    badChars = Array("/", "\", "[", "]", "*", "?", ":", "'")
    
    ' [R7 LINE] Starts a loop over the specified worksheets, rows, ports, or collection items.
    For i = LBound(badChars) To UBound(badChars)
        ' [R7 LINE] Calculates or updates sheetName using the expression in this statement.
        sheetName = Replace(sheetName, badChars(i), "")
    ' [R7 LINE] Advances to the next item in the current For loop.
    Next i
    
    ' [R7 LINE] Calculates or updates sheetName using the expression in this statement.
    sheetName = Trim(sheetName)
    ' [R7 LINE] Evaluates this condition and runs the associated branch when it is true.
    If Len(sheetName) = 0 Then sheetName = "Imported_Uplink"
    
    ' [R7 LINE] Calculates or updates CleanSheetName using the expression in this statement.
    CleanSheetName = Left(sheetName, 31)
' [R7 LINE] Ends the current procedure and returns control to its caller.
End Function

