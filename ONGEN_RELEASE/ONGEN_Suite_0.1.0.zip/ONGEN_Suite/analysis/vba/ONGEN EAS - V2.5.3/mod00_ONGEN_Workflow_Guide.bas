Attribute VB_Name = "mod00_ONGEN_Workflow_Guide"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.6 - VFD Device Ownership Targeting
' Module          : mod00_ONGEN_Workflow_Guide
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Guide documents Step09 24V-only and dedicated Step15I 480V queue export.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.2-INDUSTRIAL-FULL-RELEASE
' Module        : mod00_ONGEN_Workflow_Guide
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : V25.2 operating guidance updated.
' Notes         : Documents true missing-only behavior and the live audit recheck workflow.
'-------------------------------------------------------------------------------

' C04.6 USER NOTE: Step 15J Assign Device to VFD selects a row in VFD_DWG_QUEUE, chooses LEFT/RIGHT when paired,
' then creates VFD_DWG_DEVICE_PLACEMENT with TARGET_VFD and TARGET_SIDE. Run VFD_DWG_Validate_Device_Targets to audit ownership.
Option Explicit

'-------------------------------------------------------------------------------
' Module Name : mod00_ONGEN_Workflow_Guide
' Version     : V20.0
' Author      : Lee Pierre, Principal Electrical Engineer
' Purpose     : Creates a self-documenting level and step guide inside the workbook.
'-------------------------------------------------------------------------------

Private Const GUIDE_SHEET As String = "ONGEN_WORKFLOW_GUIDE"

Public Sub ONGEN_Create_Or_Open_Workflow_Guide()
    Dim ws As Worksheet
    Dim data As Variant
    Dim i As Long, lastRow As Long

    On Error GoTo EH
    Application.ScreenUpdating = False

    Set ws = WG_GetOrCreateSheet(GUIDE_SHEET)
    ws.Cells.Clear

    data = WG_WorkflowRows()

    With ws
        .Range("A1:F1").Merge
        .Range("A1").value = "ONGEN ENGINEERING AUTOMATION SUITE V2.5 - WORKFLOW GUIDE"
        .Range("A2:F2").Merge
        .Range("A2").value = "Author: Lee Pierre, Principal Electrical Engineer | Run Level 0 first, then continue in numerical order."

        .Range("A4:F4").value = Array("Level", "Step", "Button / Action", "Run After", "Purpose", "Macro")

        For i = LBound(data) To UBound(data)
            .Cells(i + 5, 1).Resize(1, 6).value = data(i)
        Next i

        lastRow = UBound(data) + 5
        .Range("A1:F1").Interior.Color = RGB(31, 78, 121)
        .Range("A1:F1").Font.Color = vbWhite
        .Range("A1:F1").Font.Bold = True
        .Range("A1:F1").Font.Size = 16
        .Range("A1:F1").HorizontalAlignment = xlCenter

        .Range("A2:F2").Interior.Color = RGB(221, 235, 247)
        .Range("A2:F2").Font.Bold = True
        .Range("A2:F2").HorizontalAlignment = xlCenter

        .Range("A4:F4").Interior.Color = RGB(68, 114, 196)
        .Range("A4:F4").Font.Color = vbWhite
        .Range("A4:F4").Font.Bold = True
        .Range("A4:F4").AutoFilter

        .Range("A5:F" & lastRow).Borders.LineStyle = xlContinuous
        .Range("A5:F" & lastRow).Borders.Color = RGB(210, 210, 210)
        .Range("A5:F" & lastRow).VerticalAlignment = xlTop
        .Range("A5:F" & lastRow).WrapText = True

        .Columns("A").columnWidth = 10
        .Columns("B").columnWidth = 10
        .Columns("C").columnWidth = 34
        .Columns("D").columnWidth = 24
        .Columns("E").columnWidth = 60
        .Columns("F").columnWidth = 46
        .rows("1:2").RowHeight = 25
        .rows("4:" & lastRow).AutoFit
        .Range("A5:B" & lastRow).HorizontalAlignment = xlCenter

        .Activate
        .Range("A4").Select
        ActiveWindow.FreezePanes = True
    End With

    On Error Resume Next
    NAV_Ensure_Return_To_MAIN_Button ws, False
    On Error GoTo 0

    Application.ScreenUpdating = True
    Exit Sub
EH:
    Application.ScreenUpdating = True
    MsgBox "Unable to create the ONGEN workflow guide." & vbCrLf & _
           Err.description, vbCritical, "ONGEN Workflow Guide"
End Sub

Private Function WG_GetOrCreateSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set WG_GetOrCreateSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0

    If WG_GetOrCreateSheet Is Nothing Then
        Set WG_GetOrCreateSheet = ThisWorkbook.Worksheets.Add( _
                                    After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        WG_GetOrCreateSheet.Name = sheetName
    End If
End Function

Private Function WG_WorkflowRows() As Variant
    Dim rows() As Variant
    ReDim rows(0 To 33)

    rows(0) = Array("0", "00A", "Install / Repair ONGEN UI", "First action", "Rebuilds the MAIN dashboard and refreshes workbook-qualified button assignments.", "ONGEN_RELOAD_ALL_UI_BUTTONS")
    rows(1) = Array("0", "00B", "Install Return To Home", "After 00A", "Creates or repairs Return To Home buttons on every non-MAIN worksheet.", "NAV_Install_Return_To_MAIN_Buttons_All_Sheets")
    rows(2) = Array("0", "00C", "Open Workflow Guide", "After 00A", "Opens this guide and documents the required processing order.", "ONGEN_Create_Or_Open_Workflow_Guide")
    rows(3) = Array("0", "00D", "Audit UI Buttons", "After 00A", "Checks MAIN button inventory and macro assignments.", "BTN_Audit_UI_Buttons")
    rows(4) = Array("0", "00E", "Audit Return To Home", "After 00B", "Checks worksheet navigation assignments using normalized macro-name comparison.", "NAV_Audit_Return_To_MAIN_Buttons")
    rows(5) = Array("1", "01", "Import ONGEN Generated IO", "Level 0 complete", "Imports the ONGEN-generated IO source data.", "Step01_Import_ONGEN_Generated_IO")
    rows(6) = Array("1", "02", "Build IO Block Generator", "After 01", "Builds IO_BLOCK_GENERATOR from IO_DEVICE_LIST.", "Step02_Build_IO_BLOCK_GENERATOR_From_IO_DEVICE_LIST")
    rows(7) = Array("1", "03", "Refresh IO Data Formulas", "After 02", "Refreshes IO block DATA lookup formulas.", "Step03_Refresh_IO_BLOCK_DATA_Formulas")
    rows(8) = Array("1", "04", "Export Beckhoff ONGEN Input", "After 03", "Exports the Beckhoff ONGEN drawing input.", "Step04_Export_Beckhoff_ONGEN_Input")
    rows(9) = Array("2", "05", "Import SIS TAG PD6", "Level 1 complete or independently", "Merges the PD workbook into the fixed EAS PD6 layout, preserves existing nonblank EAS values, fills only missing EAS-owned values, and does not automatically run 05B/05C/05D.", "Step05_Import_SIS_TAG_PD6_From_PD_Workbook")
    rows(10) = Array("2", "05A", "Validate PD6 Headers", "After 05 or before manual edits", "Validates the fixed V25.8 PD6_IMPORT header contract. It does not add, remove, repair, or reorder headers.", "Step05_Ensure_PD6_IMPORT_Headers")
    rows(11) = Array("2", "05B", "OPTIONAL Recalculate Current PD6", "Manual recovery/edit only", "Optional. Recalculates EAS Control_ID/load fields after deliberate manual PD6 edits. It is not part of the normal PD-master power workflow.", "Step05_Recalculate_PD6_IMPORT_Calculations")
    rows(12) = Array("2", "05C", "OPTIONAL Backfill PD6 From IO List", "Only when PD import left required fields blank", "Optional missing-value backfill from IO_DEVICE_LIST/IO_BLOCK_GENERATOR. Step05 no longer runs this automatically.", "Step05_Backfill_PD6_From_IO_DEVICE_LIST_Only")
    rows(13) = Array("2", "05D", "OPTIONAL EAS PSU / Terminal Override", "Recovery only", "Optional override. Recalculates BUS/PSU/terminal assignments in EAS and can replace the PD workbook result; a warning confirmation is required.", "Step05_Reassign_PD6_BUS_PSU_Terminals")
    rows(14) = Array("3", "06", "Validate Existing PD6 24V Source", "After 05", "Refreshes DATA_POWER/lookup worksheets and validates existing PD6 power fields. It never recalculates or reassigns PD6. Missing PSU/terminal values are allowed so Step07 can generate a deterministic MISSING requirement for engineering review.", "Step06_Refresh_24V_Power_Formulas_From_DATA")
    rows(15) = Array("3", "07", "Build 24V Power Generator", "After 06", "Consumes existing PD6 assignments first. When a required PSU is blank/MISSING, Step07 creates a generation-only MISSING PSU requirement using 40A/20A and Module Length + XYZ distance rules. If PD6 BUS/load is blank, DATA_POWER may supply a generation-only configured BUS/load. IO_DEVICE_LIST may add powered device instances not yet in PD6 when their Device Type exists in DATA_POWER. PD6 is not modified.", "Step07_Build_24V_Power_Generator_From_PD6")
    rows(16) = Array("3", "08", "Build 480V VFD Generator", "After 07", "Prompts to overwrite or append only VFD devices missing from the existing generator.", "Step08_Build_480V_VFD_Generator_From_PD6")
    rows(17) = Array("3", "09", "Export 24V Input", "After 07", "Exports only the generated panel 24V drawing input sheets A:I with TAG in column I. VFD/480V data is intentionally excluded and is exported by Step 15I.", "Step09_Export_SNR_24V_Input")
    rows(18) = Array("3", "10A", "Audit / Optional PD6 Backfill", "After generated-sheet edits", "Always audits generated 24V sheets. YES optionally backfills safe manual BUS/PSU/terminal edits into existing PD6 rows; NO performs audit/index only. It never runs the automatic PD6 PSU allocator, does not add new PD6 rows, and skips overloaded generated sections. A later Step05 re-import can supersede the manual backfill.", "Step10A_Refresh_Missing_Status_From_Generated_Sheets")
    rows(19) = Array("4", "11", "Import IO Topology CSV/XLSX", "After power and IO data are ready", "Imports the manually prepared IO topology CSV or XLSX workbook.", "IMPORT_IO_TOPOLOGY")
    rows(20) = Array("4", "11B", "Prepare Auto Network", "Alternative to 11", "Builds the automatic network and RCP preparation data.", "CREATE_AUTO_NETWORK_SWITCH_MAP")
    rows(21) = Array("4", "12", "Create RCP Clean Sheets", "After 11 or 11B", "Creates clean RCP worksheets from network topology.", "CREATE_CLEAN_PNL")
    rows(22) = Array("4", "12A", "Refresh Clean Formulas", "After 12", "Refreshes formulas in the clean RCP sheets.", "REFRESH_ALL_CLEAN_PNL_FORMULAS")
    rows(23) = Array("4", "13", "Export RCP Values Only", "After 12A", "Exports finalized RCP sheets as values.", "EXPORT_CLEAN_PNL_SHEETS_VALUES_ONLY")
    rows(24) = Array("5", "15A", "Install / Refresh VFD Data", "After Level 3", "Installs or refreshes VFD drawing support tables.", "VFD_Install_Or_Refresh_Workflow")
    rows(25) = Array("5", "15B", "Build 480V + Refresh Queue", "After 15A", "Builds current 480V data and refreshes the VFD drawing queue.", "VFD_Build_480V_And_Refresh_Queue")
    rows(26) = Array("5", "15C", "Refresh VFD Queue", "After sheet plan changes", "Refreshes the drawing queue without rebuilding all source data.", "VFD_Refresh_Drawing_Queue")
    rows(27) = Array("5", "15D", "Rebuild Queue From Plan", "After sheet plan changes", "Rebuilds the queue from VFD_DWG_SHEET_PLAN.", "VFD_Rebuild_Drawing_Queue_From_Plan")
    rows(28) = Array("5", "15H", "Build Combined Label List", "After label source data is ready", "Refreshes CABLE_TAG_OUTPUT inside the EAS workbook using the same IO, network, DC, PWR, and MTR collectors and cable-ID rules as Step 17. It does not create an external file.", "Build_ONGEN_Combined_Label_List")
    rows(29) = Array("5", "15I", "Export 480V VFD Queue", "After 15B/15C", "Exports the complete VFD_DWG_QUEUE worksheet to a standalone XLSX. TAG contains the primary PWR feeder wire label and RIGHT_TAG preserves the second VFD feeder label when a paired queue row is used. Non-PWR rows remain in the queue export but do not receive feeder tags.", "Step15I_Export_VFD_DWG_Queue_480V_Input")
    rows(30) = Array("6", "16", "Validate Workbook", "After Levels 1-5", "Runs workbook validation before drawings or final exports.", "Step10_Validate_ONGEN_Workbook")
    rows(31) = Array("6", "17", "Export Label List Report", "After validation", "The only external label-list export. Keeps the current README, ALL LABELS, IO DEVICE LABELS, NETWORK LABELS, and POWER LABELS format.", "Export_ONGEN_Label_List_Report")
    rows(32) = Array("6", "18", "Final Clear Generated Data", "Only after backups and exports", "Clears generated data. This is destructive and should be the last action only.", "Step99_Clear_All_Generated_Data")
    rows(33) = Array("3", "10B", "Recheck / Clear Solved Audit", "After directly correcting generated-sheet issues", "Rechecks STEP10A_SYNC_AUDIT, removes solved issues, and does not rebuild Step07 or overwrite generated sheets.", "Step10B_Recheck_And_Clear_Solved_Audit_Issues")

    WG_WorkflowRows = rows
End Function

