Attribute VB_Name = "mod00_ONGEN_Navigation_UI"
Option Explicit

'===============================================================================
' ONGEN EAS - WORKBOOK NAVIGATION UI
'
' Author : Lee Pierre
' Title  : Principal Electrical Engineer
'
' PURPOSE
' -------
' Provides the production Sheet Launcher button on MAIN without using the old
' worksheet-based navigator.
'
' ROOT FIX
' --------
' Earlier code used several Shape/TextFrame2 properties during installation.
' Some Excel/Office builds return Error 438 for one or more of those properties.
'
' This release keeps only the properties required for reliable operation.
' Cosmetic properties are applied through safe helper routines and are allowed
' to fail without aborting the installation.
'===============================================================================

Private Const NAV_HOME_SHEET As String = "MAIN"
Private Const LEGACY_NAV_SHEET As String = "WORKSHEET NAVIGATOR"
Private Const LEGACY_NAV_BUTTON As String = "ONGEN_BTN_WORKSHEET_NAVIGATOR"
Private Const MAIN_LAUNCH_BUTTON As String = "ONGEN_UI_BTN_0B_Sheet_Launcher"
Private Const GUIDE_BUTTON As String = "ONGEN_UI_BTN_0C_Workflow_Guide"

Public Sub ONGEN_INSTALL_NAVIGATION_UI()
    On Error GoTo Failed

    Dim oldScreen As Boolean
    Dim oldEvents As Boolean

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents

    Application.ScreenUpdating = False
    Application.EnableEvents = False

    NAV_RemoveLegacyWorksheetNavigator
    NAV_EnsureMainLauncherButton

    'Keep existing return-home / launcher controls synchronized when available.
    NAV_RunOptionalMacro "NAV_Install_Worksheet_Navigation_Buttons_All_Sheets"

    'Keyboard shortcut. This is optional and must never break installation.
    On Error Resume Next
    Application.OnKey "^+L", NAV_QualifiedMacro("NAV_Open_Worksheet_Launcher")
    On Error GoTo Failed

CleanExit:
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    MsgBox _
        "ONGEN navigation updated." & vbCrLf & vbCrLf & _
        "0B Sheet Launcher is installed beside 0C Workflow Guide.", _
        vbInformation, _
        "ONGEN Navigation"
    Exit Sub

Failed:
    Dim n As Long
    Dim d As String

    n = Err.Number
    d = Err.description

    On Error Resume Next
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    MsgBox _
        "ONGEN navigation could not be updated." & vbCrLf & _
        "Error " & CStr(n) & ": " & d, _
        vbCritical, _
        "ONGEN Navigation"
End Sub


Public Sub ONGEN_OPEN_WORKSHEET_NAVIGATOR()
    'Compatibility entry point retained for older workbooks/buttons.
    NAV_OpenSheetLauncherForm
End Sub


Public Sub ONGEN_OPEN_SHEET_LAUNCHER()
    NAV_OpenSheetLauncherForm
End Sub


Public Sub ONGEN_USER_VIEW()
    On Error Resume Next
    ActiveWindow.DisplayWorkbookTabs = False
    On Error GoTo 0

    NAV_OpenSheetLauncherForm
End Sub


Public Sub ONGEN_ADMIN_SHOW_TECHNICAL_TABS()
    On Error Resume Next
    ActiveWindow.DisplayWorkbookTabs = True
    On Error GoTo 0

    MsgBox _
        "Technical worksheet tabs are visible.", _
        vbInformation, _
        "ONGEN Admin View"
End Sub


Public Sub ONGEN_RESET_MAIN_SHEET_LAUNCHER()
    NAV_EnsureMainLauncherButton
End Sub


Private Sub NAV_OpenSheetLauncherForm()
    On Error GoTo TryFallback

    Application.Run NAV_QualifiedMacro("NAV_Open_Worksheet_Launcher")
    Exit Sub

TryFallback:
    Err.Clear
    On Error GoTo Failed

    Application.Run NAV_QualifiedMacro("UI_ShowLauncher")
    Exit Sub

Failed:
    MsgBox _
        "The Sheet Launcher could not be opened." & vbCrLf & _
        "Confirm frmPDLauncher and its navigation modules are present." & _
        vbCrLf & "Error " & CStr(Err.Number) & ": " & Err.description, _
        vbExclamation, _
        "ONGEN Sheet Launcher"
End Sub


Private Sub NAV_EnsureMainLauncherButton()
    On Error GoTo Failed

    Dim ws As Worksheet
    Dim guide As Shape
    Dim btn As Shape

    Dim leftPos As Double
    Dim topPos As Double
    Dim widthVal As Double
    Dim heightVal As Double

    Set ws = NAV_GetSheet(NAV_HOME_SHEET)

    If ws Is Nothing Then
        Err.Raise vbObjectError + 19001, _
                  "NAV_EnsureMainLauncherButton", _
                  "MAIN worksheet was not found."
    End If

    NAV_DeleteShapeIfExists ws, LEGACY_NAV_BUTTON
    NAV_DeleteShapeIfExists ws, MAIN_LAUNCH_BUTTON
    NAV_DeleteShapeIfExists ws, "btnWorksheetLauncher"

    Set guide = NAV_GetShape(ws, GUIDE_BUTTON)

    If Not guide Is Nothing Then
        leftPos = guide.Left - guide.Width - 12
        topPos = guide.Top
        widthVal = guide.Width
        heightVal = guide.Height

        If leftPos < 8 Then
            leftPos = guide.Left
            topPos = guide.Top - guide.Height - 8

            If topPos < 8 Then
                topPos = 8
            End If
        End If
    Else
        leftPos = ws.Range("E8").Left
        topPos = ws.Range("E8").Top
        widthVal = 138
        heightVal = 42
    End If

    Set btn = ws.Shapes.AddShape( _
        msoShapeRoundedRectangle, _
        leftPos, _
        topPos, _
        widthVal, _
        heightVal)

    'Only required properties are set directly.
    btn.Name = MAIN_LAUNCH_BUTTON
    btn.OnAction = NAV_QualifiedMacro("NAV_Open_Worksheet_Launcher")

    'Cosmetic properties are intentionally non-fatal.
    NAV_ApplyButtonAppearance btn

    Exit Sub

Failed:
    Err.Raise Err.Number, "NAV_EnsureMainLauncherButton", Err.description
End Sub


Private Sub NAV_ApplyButtonAppearance(ByVal btn As Shape)
    'Every property in this routine is cosmetic. Unsupported Office shape
    'properties must never abort navigation installation.
    On Error Resume Next

    btn.Fill.ForeColor.RGB = RGB(22, 42, 58)
    btn.Line.ForeColor.RGB = RGB(92, 200, 190)
    btn.Line.Weight = 1.25

    'Use the legacy TextFrame API for broad Excel compatibility.
    btn.TextFrame.Characters.text = "0B Sheet Launcher"
    btn.TextFrame.HorizontalAlignment = xlHAlignCenter
    btn.TextFrame.VerticalAlignment = xlVAlignCenter

    btn.TextFrame.Characters.Font.Name = "Arial"
    btn.TextFrame.Characters.Font.Size = 9
    btn.TextFrame.Characters.Font.Bold = True
    btn.TextFrame.Characters.Font.Color = RGB(255, 255, 255)

    btn.Placement = xlFreeFloating
    btn.PrintObject = False

    On Error GoTo 0
End Sub


Private Sub NAV_RemoveLegacyWorksheetNavigator()
    Dim ws As Worksheet

    For Each ws In ThisWorkbook.Worksheets
        NAV_DeleteShapeIfExists ws, LEGACY_NAV_BUTTON
    Next ws

    Set ws = NAV_GetSheet(LEGACY_NAV_SHEET)

    If Not ws Is Nothing Then
        Application.DisplayAlerts = False
        ws.Delete
        Application.DisplayAlerts = True
    End If
End Sub


Private Sub NAV_RunOptionalMacro(ByVal macroName As String)
    On Error Resume Next
    Application.Run NAV_QualifiedMacro(macroName)
    On Error GoTo 0
End Sub


Private Function NAV_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set NAV_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function


Private Function NAV_GetShape( _
    ByVal ws As Worksheet, _
    ByVal shapeName As String) As Shape

    On Error Resume Next
    Set NAV_GetShape = ws.Shapes(shapeName)
    On Error GoTo 0
End Function


Private Sub NAV_DeleteShapeIfExists( _
    ByVal ws As Worksheet, _
    ByVal shapeName As String)

    On Error Resume Next
    ws.Shapes(shapeName).Delete
    On Error GoTo 0
End Sub


Private Function NAV_QualifiedMacro(ByVal macroName As String) As String
    NAV_QualifiedMacro = _
        "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function
