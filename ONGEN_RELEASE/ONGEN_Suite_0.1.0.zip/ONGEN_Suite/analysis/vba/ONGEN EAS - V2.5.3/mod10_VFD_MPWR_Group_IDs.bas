Attribute VB_Name = "mod10_VFD_MPWR_Group_IDs"
Option Explicit
'===============================================================================
' ONGEN EAS - VFD MPWR PARENT / CHILD CABLE ID BUILDER
' Author: Lee Pierre, Principal Electrical Engineer
' Purpose: Permanent production module for the ONGEN Engineering Automation Suite.
'          This module is part of the V26.3 clean workflow baseline.
'===============================================================================



'===============================================================================
' ONGEN EAS - CANONICAL RCP 480V MPWR GROUP MAP
'
' Canonical worksheet:
'   VFD DWG MPWR GROUPS
'
' One MPWR cable/feed per:
'   AREA_NUMBER + RCP_PANEL + SWITCHGROUP
'
' Connected 480V load detection:
'   - VFD
'   - PSU
'   - any row explicitly listed in VFD_480V_Generator
'   - any PD6 row with Main Drive voltage from 400 through 480 V
'
' PSU-only groups are CONNECTED and are never SPARE.
'===============================================================================

Private Const MPWR_SHEET As String = "VFD DWG MPWR GROUPS"
Private Const MPWR_SHEET_LEGACY As String = "VFD_DWG_MPWR_GROUPS"
Private Const SRC_QUEUE As String = "VFD_DWG_QUEUE"
Private Const SRC_PD6 As String = "PD6_IMPORT"
Private Const SRC_VFD_GEN As String = "VFD_480V_Generator"
Private Const MPWR_PREFIX As String = "MPWR-"
Private Const MAX_AUTO_POSITION As Long = 32

Private Const COL_ID As Long = 1
Private Const COL_AREA As Long = 2
Private Const COL_PANEL As Long = 3
Private Const COL_SWG As Long = 4
Private Const COL_SEQ As Long = 5
Private Const COL_ELEM As Long = 6
Private Const COL_TYPE As Long = 7
Private Const COL_GROUP_NO As Long = 8
Private Const COL_SEED_GROUP As Long = 9
Private Const COL_LOCATOR_LP As Long = 10
Private Const COL_SOURCE_SHEET As Long = 11
Private Const COL_SOURCE_ROW As Long = 12
Private Const COL_SOURCE_KEY As Long = 13
Private Const COL_STATUS As Long = 14
Private Const COL_NOTES As Long = 15
Private Const COL_REFRESHED As Long = 16
Private Const COL_DEVICE_COUNT As Long = 17
Private Const COL_DEVICE_CABLE_TAGS As Long = 18
Private Const COL_DEVICE_TAG_MAP As Long = 19
Private Const COL_PARENT_CABLE_ID As Long = 20

Public Sub VFD_DWG_Create_MPWR_Group_Sheet()
    VFD_DWG_Refresh_MPWR_Group_IDs
End Sub

Public Sub BTN_VFD_Refresh_MPWR_Groups()
    VFD_DWG_Refresh_MPWR_Group_IDs
End Sub

Public Sub VFD_DWG_Refresh_MPWR_Group_IDs()
    MPWR_RefreshCore True
End Sub

Public Sub VFD_DWG_Refresh_MPWR_Group_IDs_Silent()
    MPWR_RefreshCore False
End Sub

Public Sub VFD_MPWR_UPGRADE_EXISTING_WORKBOOK_ONLY()
    MPWR_RefreshCore True
End Sub

Public Sub VFD_DWG_Open_MPWR_Groups()
    Dim ws As Worksheet
    Set ws = MPWR_GetSheet(MPWR_SHEET)

    If ws Is Nothing Then
        VFD_DWG_Refresh_MPWR_Group_IDs
        Set ws = MPWR_GetSheet(MPWR_SHEET)
    End If

    If Not ws Is Nothing Then
        ws.Visible = xlSheetVisible
        ws.Activate
        ws.Range("A1").Select
    End If
End Sub

Public Sub VFD_DWG_DIAG_MPWR_PSU_GROUPS()
    Dim ws As Worksheet
    Set ws = MPWR_GetSheet(MPWR_SHEET)

    If ws Is Nothing Then
        MsgBox MPWR_SHEET & " does not exist.", vbExclamation, "ONGEN MPWR Diagnostic"
        Exit Sub
    End If

    Dim r As Long
    Dim lastRow As Long
    Dim psuOnly As Long
    Dim mixed As Long
    Dim vfdOnly As Long
    Dim other480 As Long
    Dim t As String

    lastRow = MPWR_LastRow(ws)

    For r = 2 To lastRow
        t = UCase$(Trim$(CStr(ws.Cells(r, COL_TYPE).Value2)))

        If InStr(1, t, "VFD", vbTextCompare) > 0 And _
           InStr(1, t, "PSU", vbTextCompare) > 0 Then
            mixed = mixed + 1
        ElseIf InStr(1, t, "PSU", vbTextCompare) > 0 Then
            psuOnly = psuOnly + 1
        ElseIf InStr(1, t, "VFD", vbTextCompare) > 0 Then
            vfdOnly = vfdOnly + 1
        ElseIf Len(t) > 0 Then
            other480 = other480 + 1
        End If
    Next r

    MsgBox _
        "MPWR connected power groups" & vbCrLf & vbCrLf & _
        "PSU only: " & psuOnly & vbCrLf & _
        "VFD only: " & vfdOnly & vbCrLf & _
        "VFD + PSU: " & mixed & vbCrLf & _
        "Other 400/480V: " & other480 & vbCrLf & _
        "Total: " & Application.Max(0, lastRow - 1), _
        vbInformation, _
        "ONGEN MPWR Diagnostic"
End Sub

Private Sub MPWR_RefreshCore(ByVal ShowMessage As Boolean)
    On Error GoTo FailHandler

    Dim oldCalc As XlCalculation
    Dim oldEvents As Boolean
    Dim oldScreen As Boolean

    oldCalc = Application.Calculation
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Dim wsOut As Worksheet
    Set wsOut = MPWR_EnsureCanonicalSheet()

    Dim oldID As Object
    Dim oldGroup As Object
    Dim oldSeed As Object
    Dim oldLP As Object
    Dim oldNotes As Object

    Set oldID = MPWR_NewDict()
    Set oldGroup = MPWR_NewDict()
    Set oldSeed = MPWR_NewDict()
    Set oldLP = MPWR_NewDict()
    Set oldNotes = MPWR_NewDict()

    MPWR_ReadExisting wsOut, oldID, oldGroup, oldSeed, oldLP, oldNotes

    Dim legacy As Worksheet
    Set legacy = MPWR_GetSheet(MPWR_SHEET_LEGACY)
    If Not legacy Is Nothing Then
        If Not legacy Is wsOut Then
            MPWR_ReadExisting legacy, oldID, oldGroup, oldSeed, oldLP, oldNotes
        End If
    End If

    Dim groups As Object
    Set groups = MPWR_NewDict()

    Dim ws As Worksheet

    Set ws = MPWR_GetSheet(SRC_QUEUE)
    If Not ws Is Nothing Then
        MPWR_CollectSheet ws, groups, True, False
    End If

    Set ws = MPWR_GetSheet(SRC_PD6)
    If Not ws Is Nothing Then
        MPWR_CollectSheet ws, groups, False, False
    End If

    Set ws = MPWR_GetSheet(SRC_VFD_GEN)
    If Not ws Is Nothing Then
        MPWR_CollectSheet ws, groups, False, True
    End If

    If groups.count = 0 Then
        Err.Raise vbObjectError + 4101, "MPWR_RefreshCore", _
                  "No connected RCP 480V power groups were found."
    End If

    MPWR_WriteOutput wsOut, groups, oldID, oldGroup, oldSeed, oldLP, oldNotes
    MPWR_FormatSheet wsOut
    MPWR_DeleteLegacyDuplicate wsOut

    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    If ShowMessage Then
        MsgBox _
            MPWR_SHEET & " refreshed." & vbCrLf & _
            "Connected RCP power groups: " & groups.count & vbCrLf & _
            "PSU-only groups are included.", _
            vbInformation, _
            "ONGEN MPWR Groups"
    End If
    Exit Sub

FailHandler:
    Dim errNumber As Long
    Dim errDescription As String

    errNumber = Err.Number
    errDescription = Err.description

    On Error Resume Next
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    If ShowMessage Then
        MsgBox _
            "MPWR group refresh failed." & vbCrLf & vbCrLf & _
            "Error " & errNumber & ": " & errDescription, _
            vbCritical, _
            "ONGEN MPWR Groups"
    Else
        If errNumber = 0 Then errNumber = vbObjectError + 4199
        Err.Raise errNumber, "VFD_DWG_Refresh_MPWR_Group_IDs_Silent", errDescription
    End If
End Sub

Private Sub MPWR_CollectSheet( _
    ByVal ws As Worksheet, _
    ByVal groups As Object, _
    ByVal queueMode As Boolean, _
    ByVal forceListed480 As Boolean)

    Dim headerRow As Long
    headerRow = MPWR_FindHeaderRow(ws)
    If headerRow = 0 Then Exit Sub

    Dim cArea As Long
    Dim cPanel As Long
    Dim cSWG As Long
    Dim cSeq As Long
    Dim cElem As Long
    Dim cType As Long
    Dim cPage As Long
    Dim cVoltage As Long

    cArea = MPWR_FindHeader(ws, headerRow, Array( _
        "AREA_NUMBER", "AREA NUMBER", "AREA_NUMBER", "AREA", "AREA_NO"))

    cPanel = MPWR_FindHeader(ws, headerRow, Array( _
        "PANEL", "PNL", "480V PANEL", "RCP_PANEL", "RCP PANEL"))

    cSWG = MPWR_FindHeader(ws, headerRow, Array( _
        "SWITCHGROUP", "SWITCH GROUP", "SWG", "PWG", "POWER GROUP"))

    cSeq = MPWR_FindHeader(ws, headerRow, Array( _
        "SIS_SEQUENCE", "SIS SEQUENCE", "SIS_SEQUENCE_NUMBER"))

    cElem = MPWR_FindHeader(ws, headerRow, Array( _
        "SIS_ELEMENT_NUMBER", "SIS ELEMENT NUMBER", "SIS_ELEMENT", _
        "DEVICE", "DEVICE NAME"))

    cType = MPWR_FindHeader(ws, headerRow, Array( _
        "TYPE", "DEVICE TYPE", "DEVICE_TYPE", "ITEM TYPE"))

    cPage = MPWR_FindHeader(ws, headerRow, Array( _
        "PAGE_CODE", "PAGE CODE", "SHEET_PREFIX", "DRAWING_TYPE"))

    cVoltage = MPWR_FindHeader(ws, headerRow, Array( _
        "MOTOR VOLTAGE (MAIN DRIVE)", "MOTOR VOLTAGE MAIN DRIVE", _
        "MOTOR VOLTAGE (MAIN)", "MOTOR VOLTAGE", "VOLTAGE"))

    If cPanel = 0 Or cSWG = 0 Then Exit Sub

    Dim r As Long
    Dim lastRow As Long
    lastRow = MPWR_LastRow(ws)

    For r = headerRow + 1 To lastRow
        MPWR_AddCandidate ws, r, cArea, cPanel, cSWG, cSeq, cElem, _
                          cType, cPage, cVoltage, groups, queueMode, forceListed480

        If queueMode Then
            MPWR_AddRightQueueCandidate ws, r, headerRow, groups
        End If
    Next r
End Sub

Private Sub MPWR_AddCandidate( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal cArea As Long, _
    ByVal cPanel As Long, _
    ByVal cSWG As Long, _
    ByVal cSeq As Long, _
    ByVal cElem As Long, _
    ByVal cType As Long, _
    ByVal cPage As Long, _
    ByVal cVoltage As Long, _
    ByVal groups As Object, _
    ByVal queueMode As Boolean, _
    ByVal forceListed480 As Boolean)

    Dim areaVal As String
    Dim panelVal As String
    Dim swgVal As String
    Dim seqVal As String
    Dim elemVal As String
    Dim typeVal As String
    Dim pageVal As String
    Dim voltageVal As String

    areaVal = MPWR_Value(ws, r, cArea)
    panelVal = MPWR_Value(ws, r, cPanel)
    swgVal = MPWR_NormalizeSWG(MPWR_Value(ws, r, cSWG))
    seqVal = MPWR_Value(ws, r, cSeq)
    elemVal = MPWR_Value(ws, r, cElem)
    typeVal = MPWR_Value(ws, r, cType)
    pageVal = UCase$(MPWR_Value(ws, r, cPage))
    voltageVal = MPWR_Value(ws, r, cVoltage)

    If Not MPWR_IsRCP(panelVal) Then Exit Sub
    If Len(swgVal) = 0 Or swgVal = "0" Then Exit Sub

    If queueMode Then
        If Len(pageVal) > 0 Then
            If Not MPWR_IsPowerPage(pageVal) Then Exit Sub
        End If
    End If

    If Not MPWR_IsConnected480V( _
        typeVal, elemVal, seqVal, voltageVal, forceListed480) Then Exit Sub

    Dim key As String
    key = MPWR_GroupKey(areaVal, panelVal, swgVal)

    MPWR_AddOrMerge groups, key, areaVal, panelVal, swgVal, _
                    seqVal, elemVal, MPWR_CanonicalType(typeVal, elemVal, seqVal), _
                    ws.Name, CStr(r)
End Sub

Private Sub MPWR_AddRightQueueCandidate( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal headerRow As Long, _
    ByVal groups As Object)

    Dim cPage As Long
    Dim cArea As Long
    Dim cPanel As Long
    Dim cSWG As Long
    Dim cSeq As Long
    Dim cElem As Long
    Dim cType As Long

    cPage = MPWR_FindHeader(ws, headerRow, Array("PAGE_CODE", "PAGE CODE"))
    cArea = MPWR_FindHeader(ws, headerRow, Array( _
        "RIGHT_AREA_NUMBER", "RIGHT AREA NUMBER", "AREA_NUMBER", "AREA NUMBER"))
    cPanel = MPWR_FindHeader(ws, headerRow, Array( _
        "RIGHT_PANEL", "RIGHT PNL", "RIGHT_480V_PANEL", "RIGHT 480V PANEL"))
    cSWG = MPWR_FindHeader(ws, headerRow, Array( _
        "RIGHT_SWITCHGROUP", "RIGHT SWITCHGROUP", "RIGHT_SWITCH_GROUP", _
        "RIGHT POWER GROUP", "RIGHT_PWG"))
    cSeq = MPWR_FindHeader(ws, headerRow, Array( _
        "RIGHT_SIS_SEQUENCE", "RIGHT SIS SEQUENCE"))
    cElem = MPWR_FindHeader(ws, headerRow, Array( _
        "RIGHT_SIS_ELEMENT_NUMBER", "RIGHT SIS ELEMENT NUMBER"))
    cType = MPWR_FindHeader(ws, headerRow, Array( _
        "RIGHT_TYPE", "RIGHT TYPE", "TYPE"))

    If cPanel = 0 Or cSWG = 0 Then Exit Sub

    Dim pageVal As String
    pageVal = UCase$(MPWR_Value(ws, r, cPage))

    If Len(pageVal) > 0 Then
        If Not MPWR_IsPowerPage(pageVal) Then Exit Sub
    End If

    Dim areaVal As String
    Dim panelVal As String
    Dim swgVal As String
    Dim seqVal As String
    Dim elemVal As String
    Dim typeVal As String

    areaVal = MPWR_Value(ws, r, cArea)
    panelVal = MPWR_Value(ws, r, cPanel)
    swgVal = MPWR_NormalizeSWG(MPWR_Value(ws, r, cSWG))
    seqVal = MPWR_Value(ws, r, cSeq)
    elemVal = MPWR_Value(ws, r, cElem)
    typeVal = MPWR_Value(ws, r, cType)

    If Not MPWR_IsRCP(panelVal) Then Exit Sub
    If Len(swgVal) = 0 Or swgVal = "0" Then Exit Sub

    If Not MPWR_IsConnected480V( _
        typeVal, elemVal, seqVal, vbNullString, False) Then Exit Sub

    Dim key As String
    key = MPWR_GroupKey(areaVal, panelVal, swgVal)

    MPWR_AddOrMerge groups, key, areaVal, panelVal, swgVal, _
                    seqVal, elemVal, MPWR_CanonicalType(typeVal, elemVal, seqVal), _
                    ws.Name, CStr(r) & "R"
End Sub

Private Function MPWR_IsConnected480V( _
    ByVal typeVal As String, _
    ByVal elemVal As String, _
    ByVal seqVal As String, _
    ByVal voltageVal As String, _
    ByVal forceListed480 As Boolean) As Boolean

    If forceListed480 Then
        MPWR_IsConnected480V = True
        Exit Function
    End If

    Dim combined As String
    combined = UCase$(Trim$(typeVal & " " & elemVal & " " & seqVal))

    If InStr(1, combined, "VFD", vbTextCompare) > 0 Or _
       InStr(1, combined, "PSU", vbTextCompare) > 0 Then
        MPWR_IsConnected480V = True
        Exit Function
    End If

    If IsNumeric(Trim$(voltageVal)) Then
        Dim voltage As Double
        voltage = CDbl(Trim$(voltageVal))

        If voltage >= 400# And voltage <= 480# Then
            MPWR_IsConnected480V = True
        End If
    End If
End Function

Private Function MPWR_IsPowerPage(ByVal pageVal As String) As Boolean
    Select Case UCase$(Trim$(pageVal))
        Case "PWR", "POWER", "VFD-PWR", "MAIN-PWR", "MAIN-POWER"
            MPWR_IsPowerPage = True
    End Select
End Function

Private Function MPWR_CanonicalType( _
    ByVal typeVal As String, _
    ByVal elemVal As String, _
    ByVal seqVal As String) As String

    Dim combined As String
    combined = UCase$(Trim$(typeVal & " " & elemVal & " " & seqVal))

    If InStr(1, combined, "VFD", vbTextCompare) > 0 And _
       InStr(1, combined, "PSU", vbTextCompare) > 0 Then
        MPWR_CanonicalType = "VFD+PSU"
    ElseIf InStr(1, combined, "PSU", vbTextCompare) > 0 Then
        MPWR_CanonicalType = "PSU"
    ElseIf InStr(1, combined, "VFD", vbTextCompare) > 0 Then
        MPWR_CanonicalType = "VFD"
    ElseIf Len(Trim$(typeVal)) > 0 Then
        MPWR_CanonicalType = UCase$(Trim$(typeVal))
    Else
        MPWR_CanonicalType = "480V DEVICE"
    End If
End Function

Private Sub MPWR_AddOrMerge( _
    ByVal groups As Object, _
    ByVal key As String, _
    ByVal areaVal As String, _
    ByVal panelVal As String, _
    ByVal swgVal As String, _
    ByVal seqVal As String, _
    ByVal elemVal As String, _
    ByVal typeVal As String, _
    ByVal sourceSheet As String, _
    ByVal sourceRow As String)

    Dim rec As Variant

    If Not groups.Exists(key) Then
        rec = Array( _
            areaVal, panelVal, swgVal, seqVal, elemVal, typeVal, _
            sourceSheet, sourceRow, key)
        groups.Add key, rec
        Exit Sub
    End If

    rec = groups(key)
    rec(3) = MPWR_AppendUnique(CStr(rec(3)), seqVal)
    rec(4) = MPWR_AppendUnique(CStr(rec(4)), elemVal)
    rec(5) = MPWR_MergeTypes(CStr(rec(5)), typeVal)
    rec(6) = MPWR_AppendUnique(CStr(rec(6)), sourceSheet)
    rec(7) = MPWR_AppendUnique(CStr(rec(7)), sourceRow)
    groups(key) = rec
End Sub

Private Function MPWR_MergeTypes(ByVal a As String, ByVal b As String) As String
    a = UCase$(Trim$(a))
    b = UCase$(Trim$(b))

    If Len(a) = 0 Then
        MPWR_MergeTypes = b
        Exit Function
    End If

    If Len(b) = 0 Or StrComp(a, b, vbTextCompare) = 0 Then
        MPWR_MergeTypes = a
        Exit Function
    End If

    If (InStr(1, a, "VFD", vbTextCompare) > 0 Or _
        InStr(1, b, "VFD", vbTextCompare) > 0) And _
       (InStr(1, a, "PSU", vbTextCompare) > 0 Or _
        InStr(1, b, "PSU", vbTextCompare) > 0) Then

        MPWR_MergeTypes = "VFD+PSU"
    Else
        MPWR_MergeTypes = MPWR_AppendUnique(a, b)
    End If
End Function

Private Function MPWR_AppendUnique(ByVal existingVal As String, ByVal newVal As String) As String
    existingVal = Trim$(existingVal)
    newVal = Trim$(newVal)

    If Len(newVal) = 0 Then
        MPWR_AppendUnique = existingVal
        Exit Function
    End If

    If Len(existingVal) = 0 Then
        MPWR_AppendUnique = newVal
        Exit Function
    End If

    Dim part As Variant
    For Each part In Split(existingVal, "|")
        If StrComp(Trim$(CStr(part)), newVal, vbTextCompare) = 0 Then
            MPWR_AppendUnique = existingVal
            Exit Function
        End If
    Next part

    MPWR_AppendUnique = existingVal & "|" & newVal
End Function

Private Sub MPWR_ReadExisting( _
    ByVal ws As Worksheet, _
    ByVal idMap As Object, _
    ByVal groupMap As Object, _
    ByVal seedMap As Object, _
    ByVal lpMap As Object, _
    ByVal notesMap As Object)

    If ws Is Nothing Then Exit Sub

    Dim lastRow As Long
    lastRow = MPWR_LastRow(ws)
    If lastRow < 2 Then Exit Sub

    Dim r As Long
    Dim areaVal As String
    Dim panelVal As String
    Dim swgVal As String
    Dim key As String
    Dim idVal As String

    For r = 2 To lastRow
        areaVal = Trim$(CStr(ws.Cells(r, COL_AREA).Value2))
        panelVal = Trim$(CStr(ws.Cells(r, COL_PANEL).Value2))
        swgVal = MPWR_NormalizeSWG(Trim$(CStr(ws.Cells(r, COL_SWG).Value2)))

        If Len(panelVal) > 0 And Len(swgVal) > 0 Then
            key = MPWR_GroupKey(areaVal, panelVal, swgVal)
            idVal = Trim$(CStr(ws.Cells(r, COL_ID).Value2))

            If Len(idVal) > 0 Then
                If Not idMap.Exists(key) Then idMap.Add key, idVal
            End If

            If Len(Trim$(CStr(ws.Cells(r, COL_GROUP_NO).Value2))) > 0 Then
                groupMap(key) = ws.Cells(r, COL_GROUP_NO).Value2
            End If

            If Len(Trim$(CStr(ws.Cells(r, COL_SEED_GROUP).Value2))) > 0 Then
                seedMap(key) = ws.Cells(r, COL_SEED_GROUP).Value2
            End If

            If Len(Trim$(CStr(ws.Cells(r, COL_LOCATOR_LP).Value2))) > 0 Then
                lpMap(key) = ws.Cells(r, COL_LOCATOR_LP).Value2
            End If

            If Len(Trim$(CStr(ws.Cells(r, COL_NOTES).Value2))) > 0 Then
                notesMap(key) = ws.Cells(r, COL_NOTES).Value2
            End If
        End If
    Next r
End Sub

Private Sub MPWR_WriteOutput( _
    ByVal ws As Worksheet, _
    ByVal groups As Object, _
    ByVal oldID As Object, _
    ByVal oldGroup As Object, _
    ByVal oldSeed As Object, _
    ByVal oldLP As Object, _
    ByVal oldNotes As Object)

    MPWR_EnsureHeaders ws

    Dim lastOld As Long
    lastOld = MPWR_LastRow(ws)

    If lastOld >= 2 Then
        ws.Range(ws.Cells(2, 1), ws.Cells(lastOld, COL_REFRESHED)).ClearContents
    End If

    Dim keys As Variant
    keys = groups.keys
    MPWR_SortKeys keys, groups

    Dim maxID As Long
    Dim k As Variant
    Dim n As Long

    For Each k In oldID.keys
        n = MPWR_IDNumber(CStr(oldID(k)))
        If n > maxID Then maxID = n
    Next k

    Dim usedIDs As Object
    Set usedIDs = MPWR_NewDict()

    Dim usedPositions As Object
    Set usedPositions = MPWR_NewDict()

    Dim i As Long
    Dim key As String
    Dim rec As Variant
    Dim panelKey As String
    Dim groupNo As String
    Dim lpVal As String

    'Reserve existing group positions first.
    For i = LBound(keys) To UBound(keys)
        key = CStr(keys(i))
        rec = groups(key)
        panelKey = UCase$(CStr(rec(0)) & "|" & CStr(rec(1)))

        If oldGroup.Exists(key) Then
            groupNo = Trim$(CStr(oldGroup(key)))
            If Len(groupNo) > 0 Then
                usedPositions(panelKey & "|" & groupNo) = True
            End If
        End If

        If oldLP.Exists(key) Then
            lpVal = UCase$(Trim$(CStr(oldLP(key))))
            If Left$(lpVal, 4) = "LP_P" Then
                If IsNumeric(mid$(lpVal, 5)) Then
                    usedPositions(panelKey & "|" & CStr(CLng(mid$(lpVal, 5)))) = True
                End If
            End If
        End If
    Next i

    Dim arr() As Variant
    ReDim arr(1 To groups.count, 1 To COL_PARENT_CABLE_ID)

    Dim outRow As Long
    Dim idVal As String
    Dim seedVal As String
    Dim notesVal As String
    Dim statusVal As String

    For i = LBound(keys) To UBound(keys)
        key = CStr(keys(i))
        rec = groups(key)
        panelKey = UCase$(CStr(rec(0)) & "|" & CStr(rec(1)))

        idVal = vbNullString

        If oldID.Exists(key) Then
            idVal = UCase$(Trim$(CStr(oldID(key))))
            If MPWR_IDNumber(idVal) <= 0 Then idVal = vbNullString
            If Len(idVal) > 0 Then
                If usedIDs.Exists(idVal) Then idVal = vbNullString
            End If
        End If

        If Len(idVal) = 0 Then
            Do
                maxID = maxID + 1
                idVal = MPWR_PREFIX & Format$(maxID, "0000")
            Loop While usedIDs.Exists(idVal)
        End If

        usedIDs.Add idVal, key

        groupNo = vbNullString
        seedVal = vbNullString
        lpVal = vbNullString
        notesVal = vbNullString

        If oldGroup.Exists(key) Then groupNo = Trim$(CStr(oldGroup(key)))
        If oldSeed.Exists(key) Then seedVal = Trim$(CStr(oldSeed(key)))
        If oldLP.Exists(key) Then lpVal = Trim$(CStr(oldLP(key)))
        If oldNotes.Exists(key) Then notesVal = Trim$(CStr(oldNotes(key)))

        If Len(groupNo) = 0 Or Not IsNumeric(groupNo) Then
            groupNo = CStr(MPWR_FirstFreePosition(panelKey, usedPositions))
        Else
            usedPositions(panelKey & "|" & CStr(CLng(groupNo))) = True
        End If

        If Len(seedVal) = 0 And Len(lpVal) = 0 Then
            lpVal = "LP_P" & CStr(CLng(groupNo))
        End If

        If Len(seedVal) > 0 Then
            statusVal = "CONNECTED - SEED GROUP"
        Else
            statusVal = "CONNECTED - LP LOCATOR"
        End If

        outRow = outRow + 1

        arr(outRow, COL_ID) = idVal
        arr(outRow, COL_AREA) = rec(0)
        arr(outRow, COL_PANEL) = rec(1)
        arr(outRow, COL_SWG) = rec(2)
        arr(outRow, COL_SEQ) = rec(3)
        arr(outRow, COL_ELEM) = rec(4)
        arr(outRow, COL_TYPE) = rec(5)
        arr(outRow, COL_GROUP_NO) = CLng(groupNo)
        arr(outRow, COL_SEED_GROUP) = seedVal
        arr(outRow, COL_LOCATOR_LP) = lpVal
        arr(outRow, COL_SOURCE_SHEET) = rec(6)
        arr(outRow, COL_SOURCE_ROW) = rec(7)
        arr(outRow, COL_SOURCE_KEY) = key
        arr(outRow, COL_STATUS) = statusVal
        arr(outRow, COL_NOTES) = notesVal
        arr(outRow, COL_REFRESHED) = Now

        Dim deviceList As Variant
        Dim deviceCount As Long
        Dim cableTags As String
        Dim tagMap As String

        deviceList = MPWR_DeviceList(CStr(rec(3)))
        deviceCount = MPWR_DeviceListCount(deviceList)

        MPWR_BuildDeviceCableTags idVal, deviceList, cableTags, tagMap

        arr(outRow, COL_DEVICE_COUNT) = deviceCount
        arr(outRow, COL_DEVICE_CABLE_TAGS) = cableTags
        arr(outRow, COL_DEVICE_TAG_MAP) = tagMap
        arr(outRow, COL_PARENT_CABLE_ID) = idVal
    Next i

    ws.Range(ws.Cells(2, 1), ws.Cells(groups.count + 1, COL_PARENT_CABLE_ID)).value = arr
End Sub

Private Function MPWR_FirstFreePosition( _
    ByVal panelKey As String, _
    ByVal usedPositions As Object) As Long

    Dim n As Long

    For n = 1 To MAX_AUTO_POSITION
        If Not usedPositions.Exists(panelKey & "|" & CStr(n)) Then
            usedPositions.Add panelKey & "|" & CStr(n), True
            MPWR_FirstFreePosition = n
            Exit Function
        End If
    Next n

    Err.Raise vbObjectError + 4110, "MPWR_FirstFreePosition", _
              "No free MPWR LP position remains for " & panelKey
End Function


Private Function MPWR_DeviceList(ByVal sequenceList As String) As Variant
    Dim clean As Collection
    Set clean = New Collection

    Dim part As Variant
    Dim value As String
    Dim seen As Object
    Set seen = MPWR_NewDict()

    For Each part In Split(sequenceList, "|")
        value = Trim$(CStr(part))
        If Len(value) > 0 Then
            If Not seen.Exists(UCase$(value)) Then
                seen.Add UCase$(value), True
                clean.Add value
            End If
        End If
    Next part

    If clean.count = 0 Then
        MPWR_DeviceList = Array()
        Exit Function
    End If

    Dim arr() As String
    Dim i As Long
    ReDim arr(0 To clean.count - 1)

    For i = 1 To clean.count
        arr(i - 1) = CStr(clean(i))
    Next i

    MPWR_DeviceList = arr
End Function

Private Function MPWR_DeviceListCount(ByVal listValue As Variant) As Long
    On Error GoTo EmptyList
    MPWR_DeviceListCount = UBound(listValue) - LBound(listValue) + 1
    Exit Function

EmptyList:
    MPWR_DeviceListCount = 0
End Function

Private Sub MPWR_BuildDeviceCableTags( _
    ByVal baseID As String, _
    ByVal deviceList As Variant, _
    ByRef cableTags As String, _
    ByRef tagMap As String)

    'The unsuffixed base ID is RESERVED for the RCP/PWG parent trunk.
    'Every physical device drop is a child cable .1/.2/.3..., including
    'a group with only one connected 480V device.
    cableTags = vbNullString
    tagMap = vbNullString

    Dim count As Long
    count = MPWR_DeviceListCount(deviceList)

    If count <= 0 Then Exit Sub

    Dim i As Long
    Dim childIndex As Long
    Dim deviceTag As String

    For i = LBound(deviceList) To UBound(deviceList)
        childIndex = i - LBound(deviceList) + 1
        deviceTag = baseID & "." & CStr(childIndex)

        If Len(cableTags) > 0 Then cableTags = cableTags & "|"
        cableTags = cableTags & deviceTag

        If Len(tagMap) > 0 Then tagMap = tagMap & "|"
        tagMap = tagMap & CStr(deviceList(i)) & "=" & deviceTag
    Next i
End Sub

Private Function MPWR_GroupKey( _
    ByVal areaVal As String, _
    ByVal panelVal As String, _
    ByVal swgVal As String) As String

    MPWR_GroupKey = _
        UCase$(Trim$(areaVal)) & "|" & _
        UCase$(Trim$(panelVal)) & "|" & _
        UCase$(Trim$(swgVal))
End Function

Private Function MPWR_NormalizeSWG(ByVal value As String) As String
    Dim s As String
    s = UCase$(Trim$(value))

    If Left$(s, 3) = "PWG" Then s = mid$(s, 4)
    If Left$(s, 3) = "SWG" Then s = mid$(s, 4)

    MPWR_NormalizeSWG = Trim$(s)
End Function

Private Function MPWR_IsRCP(ByVal panelVal As String) As Boolean
    MPWR_IsRCP = (Left$(UCase$(Trim$(panelVal)), 3) = "RCP")
End Function

Private Function MPWR_IDNumber(ByVal idVal As String) As Long
    Dim s As String
    s = UCase$(Trim$(idVal))

    If Left$(s, Len(MPWR_PREFIX)) <> MPWR_PREFIX Then Exit Function

    s = mid$(s, Len(MPWR_PREFIX) + 1)

    If IsNumeric(s) Then MPWR_IDNumber = CLng(s)
End Function

Private Function MPWR_NewDict() As Object
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    Set MPWR_NewDict = d
End Function

Private Function MPWR_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set MPWR_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function MPWR_EnsureCanonicalSheet() As Worksheet
    Dim ws As Worksheet
    Dim legacy As Worksheet

    Set ws = MPWR_GetSheet(MPWR_SHEET)

    If ws Is Nothing Then
        Set legacy = MPWR_GetSheet(MPWR_SHEET_LEGACY)

        If Not legacy Is Nothing Then
            On Error Resume Next
            legacy.Name = MPWR_SHEET
            If Err.Number = 0 Then Set ws = legacy
            Err.Clear
            On Error GoTo 0
        End If
    End If

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.Name = MPWR_SHEET
    End If

    MPWR_EnsureHeaders ws
    Set MPWR_EnsureCanonicalSheet = ws
End Function

Private Sub MPWR_DeleteLegacyDuplicate(ByVal canonical As Worksheet)
    Dim legacy As Worksheet
    Set legacy = MPWR_GetSheet(MPWR_SHEET_LEGACY)

    If legacy Is Nothing Then Exit Sub
    If legacy Is canonical Then Exit Sub

    On Error Resume Next
    Application.DisplayAlerts = False
    legacy.Delete
    Application.DisplayAlerts = True
    On Error GoTo 0
End Sub

Private Sub MPWR_EnsureHeaders(ByVal ws As Worksheet)
    Dim headers As Variant
    headers = Array( _
        "MPWR_LABEL_ID", _
        "AREA_NUMBER", _
        "RCP_PANEL", _
        "SWITCHGROUP", _
        "SIS_SEQUENCE", _
        "SIS_ELEMENT_NUMBER", _
        "TYPE", _
        "GROUP_NO", _
        "SEED_GROUP_ID", _
        "LOCATOR_POSITION_LP", _
        "SOURCE_SHEET", _
        "SOURCE_ROW", _
        "SOURCE_KEY", _
        "STATUS", _
        "NOTES", _
        "LAST_REFRESHED", _
        "DEVICE_COUNT", _
        "DEVICE_CABLE_TAGS", _
        "DEVICE_TAG_MAP", _
        "PARENT_CABLE_ID")

    Dim i As Long

    For i = LBound(headers) To UBound(headers)
        ws.Cells(1, i + 1).Value2 = headers(i)
    Next i
End Sub

Private Function MPWR_FindHeaderRow(ByVal ws As Worksheet) As Long
    Dim maxRow As Long
    maxRow = Application.Min(20, Application.Max(1, ws.UsedRange.rows.count))

    Dim r As Long

    For r = 1 To maxRow
        If MPWR_FindHeader(ws, r, Array( _
            "PANEL", "PNL", "RCP_PANEL", "RCP PANEL", "480V PANEL")) > 0 And _
           MPWR_FindHeader(ws, r, Array( _
            "SWITCHGROUP", "SWITCH GROUP", "PWG", "SWG", "POWER GROUP")) > 0 Then

            MPWR_FindHeaderRow = r
            Exit Function
        End If
    Next r
End Function

Private Function MPWR_FindHeader( _
    ByVal ws As Worksheet, _
    ByVal headerRow As Long, _
    ByVal aliases As Variant) As Long

    If headerRow <= 0 Then Exit Function

    Dim lastCol As Long
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column

    Dim c As Long
    Dim a As Variant
    Dim cellKey As String

    For c = 1 To lastCol
        cellKey = MPWR_HeaderKey(ws.Cells(headerRow, c).Value2)

        For Each a In aliases
            If cellKey = MPWR_HeaderKey(CStr(a)) Then
                MPWR_FindHeader = c
                Exit Function
            End If
        Next a
    Next c
End Function

Private Function MPWR_HeaderKey(ByVal value As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(value)))

    s = Replace$(s, "_", "")
    s = Replace$(s, " ", "")
    s = Replace$(s, "-", "")
    s = Replace$(s, "/", "")
    s = Replace$(s, ".", "")
    s = Replace$(s, "(", "")
    s = Replace$(s, ")", "")
    s = Replace$(s, vbCr, "")
    s = Replace$(s, vbLf, "")

    MPWR_HeaderKey = s
End Function

Private Function MPWR_Value( _
    ByVal ws As Worksheet, _
    ByVal r As Long, _
    ByVal c As Long) As String

    If c <= 0 Then Exit Function
    If IsError(ws.Cells(r, c).Value2) Then Exit Function

    MPWR_Value = Trim$(CStr(ws.Cells(r, c).Value2))
End Function

Private Function MPWR_LastRow(ByVal ws As Worksheet) As Long
    On Error GoTo SafeExit

    Dim f As Range

    Set f = ws.Cells.Find( _
        What:="*", _
        After:=ws.Cells(1, 1), _
        LookIn:=xlFormulas, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False)

    If Not f Is Nothing Then MPWR_LastRow = f.Row
    Exit Function

SafeExit:
    MPWR_LastRow = 0
End Function

Private Sub MPWR_SortKeys(ByRef keys As Variant, ByVal groups As Object)
    If groups.count <= 1 Then Exit Sub

    Dim i As Long
    Dim j As Long
    Dim temp As Variant

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If MPWR_SortValue(groups(CStr(keys(j)))) < _
               MPWR_SortValue(groups(CStr(keys(i)))) Then

                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next j
    Next i
End Sub

Private Function MPWR_SortValue(ByVal rec As Variant) As String
    MPWR_SortValue = _
        Format$(val(CStr(rec(0))), "000000") & "|" & _
        UCase$(CStr(rec(1))) & "|" & _
        Format$(val(CStr(rec(2))), "000000")
End Function

Private Sub MPWR_FormatSheet(ByVal ws As Worksheet)
    On Error Resume Next

    With ws
        .rows(1).Font.Bold = True
        .rows(1).Interior.Color = RGB(31, 78, 121)
        .rows(1).Font.Color = RGB(255, 255, 255)

        .Columns("A:T").AutoFit
        .Columns("H:J").Interior.Color = RGB(255, 242, 204)
        .Columns("O").Interior.Color = RGB(255, 242, 204)
        .Columns("P").NumberFormat = "yyyy-mm-dd hh:mm:ss"

        If .AutoFilterMode Then .AutoFilterMode = False
        .Range(.Cells(1, 1), .Cells(1, COL_PARENT_CABLE_ID)).AutoFilter
    End With

    On Error GoTo 0
End Sub
