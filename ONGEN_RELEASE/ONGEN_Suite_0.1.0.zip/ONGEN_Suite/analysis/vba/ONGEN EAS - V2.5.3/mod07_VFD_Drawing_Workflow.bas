Attribute VB_Name = "mod07_VFD_Drawing_Workflow"
'===============================================================================
' ONGEN EAS - SYNCHRONIZED VBA RELEASE PACKAGE
' Package Release : V25.8.5-C04.6 - VFD Device Ownership Targeting
' Module          : mod07_VFD_Drawing_Workflow
' Author          : Lee Pierre
' Role            : Principal Electrical Engineer
' Package Note    : Adds explicit TARGET_VFD / TARGET_SIDE device ownership for paired VFD drawings.
'===============================================================================
'-------------------------------------------------------------------------------
' ONGEN EAS SUITE RELEASE
' Suite Version : V25.1-INDUSTRIAL-FULL-RELEASE
' Module        : mod07_VFD_Drawing_Workflow
' Audit Date    : 2026-07-26
' Owner         : Lee Pierre, Principal Electrical Engineer
' Status        : Static procedure, declaration, and public-name audit completed.
' LP BUS Repair : 2026-09-02 - C04.3 end-to-end IO page/circuit/link bridge repair.
' Notes         : Functional update: VFD STO backfill, queue fields, and BLOCK_EDIT STO_FROM_TEXT.
' Compile Fix   : 2026-08-03 - corrected the VFD source worksheet constant reference.
'-------------------------------------------------------------------------------

Option Explicit

'====================================================================================
' Module Name : mod07_VFD_Drawing_Workflow
' Version     : V25.8.5-C04.3 - Permanent IO LP BUS Workbook-to-LISP Link Bridge
' Author      : Lee Pierre, Principal Electrical Engineer
' Date        : 2026-07-21
'
' FINAL MODEL
'   VFD_480V_Generator              One source row per VFD device
'   VFD_DWG_SHEET_PLAN              One-to-many drawing plan per VFD type
'   VFD_DWG_SEED_LIBRARY            Reusable drawing borders/templates
'   VFD_DWG_QUEUE                   One final row per output DWG
'   VFD_DWG_CIRCUIT_LIBRARY         Reusable full-circuit DWGs
'   VFD_DWG_CIRCUIT_PLACEMENT       Optional extra circuits in one output DWG
'   VFD_DWG_DEVICE_LIBRARY          Optional individual device DWGs/blocks
'   VFD_DWG_DEVICE_PLACEMENT        Optional devices in one or many drawings
'   BLOCK_EDIT                     Exact circuit/device block and attribute rules
'   VFD_DWG_ATTRIBUTE_MAP           Title-block attributes only
'   VFD_DWG_CONFIG                  Global defaults and output settings
'
' IMPORTANT UI RULE
'   This module NEVER creates MAIN worksheet buttons. The only macro that rebuilds
'   workbook UI is ONGEN_RELOAD_ALL_UI_BUTTONS in mod00_UI_Buttons_ProgressBar.
'====================================================================================

Private Const SH_SOURCE As String = "VFD_480V_Generator"
Private Const SH_CONFIG As String = "VFD_DWG_CONFIG"
Private Const SH_SHEET_PLAN As String = "VFD_DWG_SHEET_PLAN"
Private Const SH_SEEDS As String = "VFD_DWG_SEED_LIBRARY"
Private Const SH_QUEUE As String = "VFD_DWG_QUEUE"
Private Const SH_CIRCUITS As String = "VFD_DWG_CIRCUIT_LIBRARY"
Private Const SH_CIRCUIT_PLACEMENT As String = "VFD_DWG_CIRCUIT_PLACEMENT"
Private Const SH_DEVICES As String = "VFD_DWG_DEVICE_LIBRARY"
Private Const SH_DEVICE_PLACEMENT As String = "VFD_DWG_DEVICE_PLACEMENT"
Private Const SH_ATTRMAP As String = "VFD_DWG_ATTRIBUTE_MAP"
Private Const SH_BLOCK_EDIT As String = "BLOCK_EDIT"
Private Const SH_README As String = "VFD_DWG_README"
Private Const SH_PROCESS_LOG As String = "PROCESS_LOG"
Private Const SH_PD6 As String = "PD6_IMPORT"
Private Const SH_IO_DEVICE_LIST As String = "IO_DEVICE_LIST"
Private Const SH_CABLE_OUTPUT As String = "CABLE_TAG_OUTPUT"

Private Const DEFAULT_LIBRARY_ROOT As String = "C:\Swisslog_electrical_library"
Private Const DEFAULT_LOCATOR_LAYER As String = "LP_DEVICE_LOCATORS"
Private Const VFD_VERSION As String = "4.0"

Private mPrevScreenUpdating As Boolean
Private mPrevEnableEvents As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mFastModeDepth As Long
Private mBuild480VRunning As Boolean

'====================================================================================
' PUBLIC WORKFLOW COMMANDS
'====================================================================================

Public Function VFD_DWG_INITIALIZE_BASELINE_SILENT() As Boolean
    'Canonical new-workbook initializer. No historical repair/patch module needed.
    On Error GoTo Failed

    Dim oldScreen As Boolean
    Dim oldEvents As Boolean
    Dim oldAlerts As Boolean

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False

    VFD_DWG_SetupAllSheets

    'A new workbook may not have upstream import sheets populated yet.
    On Error Resume Next
    Call VFD_DWG_BackfillPD6Core
    Call VFD_DWG_Backfill24VCore
    Call VFD_DWG_BackfillNetworkCore
    Call VFD_DWG_BackfillSTOCore
    On Error GoTo Failed

    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    VFD_DWG_INITIALIZE_BASELINE_SILENT = True
    Exit Function

Failed:
    On Error Resume Next
    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    On Error GoTo 0

    VFD_DWG_INITIALIZE_BASELINE_SILENT = False
End Function



'Installs/repairs data sheets and refreshes the queue. It does NOT create buttons.
Public Sub VFD_DWG_Install_Workflow()
    On Error GoTo EH

    VFD_DWG_BeginFastMode "Installing VFD drawing data model..."
    VFD_DWG_SetupAllSheets
    Call VFD_DWG_BackfillPD6Core
    Call VFD_DWG_Backfill24VCore
    Call VFD_DWG_BackfillNetworkCore
    Call VFD_DWG_BackfillSTOCore
    VFD_DWG_RefreshQueueCore True, False
    VFD_DWG_EndFastMode

    VFD_DWG_AppendLog "VFD_DWG_Install_Workflow", "OK", _
        "VFD V4.0 sheets installed/repaired and queue refreshed. No UI shapes were created."

    ThisWorkbook.Worksheets(SH_README).Activate
    MsgBox "The VFD V4.0 data model was installed or repaired." & vbCrLf & vbCrLf & _
           "The drawing queue was refreshed." & vbCrLf & _
           "No MAIN buttons were created. Use Reload All UI Buttons only when the complete UI must be rebuilt.", _
           vbInformation, "ONGEN VFD Drawing Workflow"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    VFD_DWG_AppendLog "VFD_DWG_Install_Workflow", "ERROR", Err.description
    MsgBox "VFD workflow setup failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD"
End Sub

'Preserves user overrides/status when refreshing the one-to-many queue.
Public Sub VFD_DWG_Refresh_Queue()
    On Error GoTo EH
    VFD_DWG_BeginFastMode "Refreshing VFD drawing queue..."
    VFD_DWG_SetupAllSheets
    Call VFD_DWG_BackfillPD6Core
    Call VFD_DWG_Backfill24VCore
    Call VFD_DWG_BackfillNetworkCore
    Call VFD_DWG_BackfillSTOCore
    VFD_DWG_RefreshQueueCore True, True
    VFD_DWG_EndFastMode
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    VFD_DWG_AppendLog "VFD_DWG_Refresh_Queue", "ERROR", Err.description
    MsgBox "VFD drawing queue refresh failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD Queue"
End Sub


'Validates the permanent LP BUS fields after a queue refresh.
Public Sub VFD_DWG_Validate_LP_BUS_Queue()
    Dim ws As Worksheet
    Dim map As Object
    Dim lastRow As Long, r As Long
    Dim leftIn As String, leftOut As String
    Dim rightSis As String, rightIn As String, rightOut As String
    Dim problems As Long, checkedRows As Long, repairedRows As Long, normalizedPageRows As Long
    Dim report As String
    Dim drawingID As String, sisElement As String

    On Error GoTo EH

    Set ws = VFD_DWG_GetOrCreateSheet(SH_QUEUE)

    'C04.3: normalize legacy PAGE_CODE aliases first. Older queues can contain
    'VFD-IO even though the Sheet Plan uses IO. The AutoCAD generator now also
    'bridges that value, but the workbook remains authoritative and canonical.
    normalizedPageRows = VFD_DWG_NormalizeQueuePageCodes(ws)

    'Synchronize the canonical LP BUS aliases from the queue's already-authoritative
    'PSU/terminal columns without requiring a destructive rebuild.
    repairedRows = VFD_DWG_SyncLPBusFieldsFromQueue(ws)

    Set map = VFD_DWG_HeaderMap(ws)
    VFD_DWG_RequireHeaders map, Array("ENABLED", "PAGE_CODE", "CIRCUIT_ID", _
                                      "LP_BUS_IN", "LP_BUS_OUT", _
                                      "RIGHT_LP_BUS_IN", "RIGHT_LP_BUS_OUT")

    lastRow = VFD_DWG_LastDataRow(ws)
    report = "VFD_DWG_QUEUE IO LP BUS validation" & vbCrLf & String$(45, "-") & vbCrLf

    For r = 2 To lastRow
        If VFD_DWG_IsYes(VFD_DWG_CellText(ws, r, map, "ENABLED")) Then
            'Only IO/MOVIFLEX_IO drawings use the LP BUS SRC/DEST pair.
            'MPWR and PWR rows must not be reported as LP BUS failures.
            If VFD_DWG_IsIOBusQueueRow(ws, r, map) Then
                checkedRows = checkedRows + 1
                drawingID = VFD_DWG_CellText(ws, r, map, "DRAWING_ID")
                sisElement = VFD_DWG_CellText(ws, r, map, "SIS_ELEMENT_NUMBER")
                leftIn = VFD_DWG_CellText(ws, r, map, "LP_BUS_IN")
                leftOut = VFD_DWG_CellText(ws, r, map, "LP_BUS_OUT")

                If Len(Trim$(leftIn)) = 0 Or Len(Trim$(leftOut)) = 0 Then
                    problems = problems + 1
                    report = report & "Row " & r & " LEFT " & drawingID & " / " & sisElement & _
                             ": LP_BUS_IN='" & leftIn & "' LP_BUS_OUT='" & leftOut & "'" & vbCrLf
                End If

                rightSis = VFD_DWG_CellText(ws, r, map, "RIGHT_SIS_ELEMENT_NUMBER")
                If Len(Trim$(rightSis)) > 0 Or _
                   Len(Trim$(VFD_DWG_CellText(ws, r, map, "RIGHT_SOURCE_ROW"))) > 0 Then

                    rightIn = VFD_DWG_CellText(ws, r, map, "RIGHT_LP_BUS_IN")
                    rightOut = VFD_DWG_CellText(ws, r, map, "RIGHT_LP_BUS_OUT")

                    If Len(Trim$(rightIn)) = 0 Or Len(Trim$(rightOut)) = 0 Then
                        problems = problems + 1
                        report = report & "Row " & r & " RIGHT " & drawingID & " / " & rightSis & _
                                 ": LP_BUS_IN='" & rightIn & "' LP_BUS_OUT='" & rightOut & "'" & vbCrLf
                    End If
                End If
            End If
        End If
    Next r

    If problems = 0 Then
        MsgBox "IO LP BUS queue validation passed." & vbCrLf & vbCrLf & _
               "IO drawing rows checked: " & CStr(checkedRows) & vbCrLf & _
               "Legacy PAGE_CODE rows normalized: " & CStr(normalizedPageRows) & vbCrLf & _
               "Queue rows synchronized: " & CStr(repairedRows) & vbCrLf & vbCrLf & _
               "LP_BUS_IN = INSIDE_PSU_TERM (incoming BUS-2 PSU terminal)" & vbCrLf & _
               "LP_BUS_OUT = POWER_BUS_2 (BUS-2 PSU feeding the VFD)", _
               vbInformation, "ONGEN VFD IO LP BUS Validation"
    Else
        MsgBox CStr(problems) & " IO LP BUS queue issue(s) found after synchronization." & vbCrLf & vbCrLf & _
               Left$(report, 1800), vbExclamation, "ONGEN VFD IO LP BUS Validation"
    End If
    Exit Sub
EH:
    MsgBox "IO LP BUS queue validation failed:" & vbCrLf & Err.description, _
           vbCritical, "ONGEN VFD IO LP BUS Validation"
End Sub

'End-to-end workbook link diagnostic for the AutoCAD LP BUS callout path.
'Checks Queue -> Sheet Plan -> Circuit Library -> LP data contract.
Public Sub VFD_DWG_Validate_IO_LP_Link()
    Dim wsQueue As Worksheet, wsPlan As Worksheet, wsCircuits As Worksheet, wsSeeds As Worksheet
    Dim qMap As Object, pMap As Object, cMap As Object, sMap As Object
    Dim lastRow As Long, r As Long, ioRows As Long, issues As Long
    Dim normalizedRows As Long, syncedRows As Long
    Dim pageCode As String, planID As String, circuitID As String, seedID As String
    Dim lpIn As String, lpOut As String, drawingID As String
    Dim circuitRow As Long, seedRow As Long
    Dim circuitPath As String, seedPath As String, report As String

    On Error GoTo EH
    VFD_DWG_BeginFastMode "Validating IO LP BUS workbook-to-LISP link..."
    VFD_DWG_SetupAllSheets

    Set wsQueue = VFD_DWG_GetOrCreateSheet(SH_QUEUE)
    Set wsPlan = VFD_DWG_GetOrCreateSheet(SH_SHEET_PLAN)
    Set wsCircuits = VFD_DWG_GetOrCreateSheet(SH_CIRCUITS)
    Set wsSeeds = VFD_DWG_GetOrCreateSheet(SH_SEEDS)

    normalizedRows = VFD_DWG_NormalizeQueuePageCodes(wsQueue)
    syncedRows = VFD_DWG_SyncLPBusFieldsFromQueue(wsQueue)

    Set qMap = VFD_DWG_HeaderMap(wsQueue)
    Set pMap = VFD_DWG_HeaderMap(wsPlan)
    Set cMap = VFD_DWG_HeaderMap(wsCircuits)
    Set sMap = VFD_DWG_HeaderMap(wsSeeds)

    VFD_DWG_RequireHeaders qMap, Array("ENABLED", "DRAWING_ID", "PLAN_ID", "PAGE_CODE", "SEED_ID", "CIRCUIT_ID", "LP_BUS_IN", "LP_BUS_OUT")
    VFD_DWG_RequireHeaders cMap, Array("ENABLED", "CIRCUIT_ID", "DWG_PATH")
    VFD_DWG_RequireHeaders sMap, Array("ENABLED", "SEED_ID", "DWG_PATH")

    report = "IO LP BUS workbook-to-LISP link diagnostic" & vbCrLf & String$(52, "-") & vbCrLf
    lastRow = VFD_DWG_LastDataRow(wsQueue)

    For r = 2 To lastRow
        If VFD_DWG_IsYes(VFD_DWG_CellText(wsQueue, r, qMap, "ENABLED")) And _
           VFD_DWG_IsIOBusQueueRow(wsQueue, r, qMap) Then

            ioRows = ioRows + 1
            drawingID = VFD_DWG_CellText(wsQueue, r, qMap, "DRAWING_ID")
            pageCode = VFD_DWG_NormalizePageCodeValue( _
                         VFD_DWG_CellText(wsQueue, r, qMap, "PAGE_CODE"), _
                         VFD_DWG_CellText(wsQueue, r, qMap, "PLAN_ID"), _
                         VFD_DWG_CellText(wsQueue, r, qMap, "CIRCUIT_ID"), _
                         VFD_DWG_CellText(wsQueue, r, qMap, "SEED_ID"))
            planID = VFD_DWG_CellText(wsQueue, r, qMap, "PLAN_ID")
            circuitID = VFD_DWG_CellText(wsQueue, r, qMap, "CIRCUIT_ID")
            seedID = VFD_DWG_CellText(wsQueue, r, qMap, "SEED_ID")
            lpIn = VFD_DWG_CellText(wsQueue, r, qMap, "LP_BUS_IN")
            lpOut = VFD_DWG_CellText(wsQueue, r, qMap, "LP_BUS_OUT")

            If pageCode <> "IO" Then
                issues = issues + 1
                report = report & drawingID & ": PAGE_CODE is not canonical IO." & vbCrLf
            End If
            If StrComp(planID, "MOVIFLEX_IO", vbTextCompare) <> 0 Then
                issues = issues + 1
                report = report & drawingID & ": PLAN_ID='" & planID & "' expected MOVIFLEX_IO." & vbCrLf
            End If
            If Len(Trim$(circuitID)) = 0 Then
                issues = issues + 1
                report = report & drawingID & ": CIRCUIT_ID is blank." & vbCrLf
            Else
                circuitRow = VFD_DWG_FindKeyedRow(wsCircuits, cMap, "CIRCUIT_ID", circuitID)
                If circuitRow = 0 Then
                    issues = issues + 1
                    report = report & drawingID & ": CIRCUIT_ID '" & circuitID & "' is missing from VFD_DWG_CIRCUIT_LIBRARY." & vbCrLf
                ElseIf Not VFD_DWG_IsYes(VFD_DWG_CellText(wsCircuits, circuitRow, cMap, "ENABLED")) Then
                    issues = issues + 1
                    report = report & drawingID & ": CIRCUIT_ID '" & circuitID & "' is disabled." & vbCrLf
                End If
            End If
            If Len(Trim$(seedID)) = 0 Then
                issues = issues + 1
                report = report & drawingID & ": SEED_ID is blank." & vbCrLf
            Else
                seedRow = VFD_DWG_FindKeyedRow(wsSeeds, sMap, "SEED_ID", seedID)
                If seedRow = 0 Then
                    issues = issues + 1
                    report = report & drawingID & ": SEED_ID '" & seedID & "' is missing from VFD_DWG_SEED_LIBRARY." & vbCrLf
                End If
            End If
            If Len(Trim$(lpIn)) = 0 Then
                issues = issues + 1
                report = report & drawingID & ": LP_BUS_IN is blank." & vbCrLf
            End If
            If Len(Trim$(lpOut)) = 0 Then
                issues = issues + 1
                report = report & drawingID & ": LP_BUS_OUT is blank." & vbCrLf
            End If
        End If
    Next r

    circuitRow = VFD_DWG_FindKeyedRow(wsCircuits, cMap, "CIRCUIT_ID", "MOVIFLEX_IO")
    If circuitRow > 0 Then circuitPath = VFD_DWG_CellText(wsCircuits, circuitRow, cMap, "DWG_PATH")
    seedRow = VFD_DWG_FindKeyedRow(wsSeeds, sMap, "SEED_ID", "VFD_MOVI_IO")
    If seedRow > 0 Then seedPath = VFD_DWG_CellText(wsSeeds, seedRow, sMap, "DWG_PATH")

    VFD_DWG_EndFastMode

    MsgBox "IO rows checked: " & CStr(ioRows) & vbCrLf & _
           "Legacy PAGE_CODE rows normalized: " & CStr(normalizedRows) & vbCrLf & _
           "LP BUS rows synchronized: " & CStr(syncedRows) & vbCrLf & _
           "Link issues: " & CStr(issues) & vbCrLf & vbCrLf & _
           "Expected IO circuit: MOVIFLEX_IO" & vbCrLf & _
           "Circuit DWG: " & circuitPath & vbCrLf & _
           "Expected IO seed: VFD_MOVI_IO" & vbCrLf & _
           "Seed DWG: " & seedPath & _
           IIf(issues > 0, vbCrLf & vbCrLf & Left$(report, 1800), vbNullString), _
           IIf(issues = 0, vbInformation, vbExclamation), "ONGEN VFD IO LP BUS Link"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    MsgBox "IO LP BUS link validation failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD IO LP BUS Link"
End Sub

'Permanent queue-level LP BUS synchronization.
'Why this exists:
'  POWER_BUS_2 / INSIDE_PSU_TERM can be populated by later backfill stages or can
'  already exist in an older VFD_DWG_QUEUE. LP_BUS_* are drawing aliases, so they
'  are synchronized from the final queue after the queue is assembled.
'
'Canonical contract:
'  LP_BUS_IN  = INSIDE_PSU_TERM
'               fallback POWER_24V_BUS_2_TERMINAL
'               fallback PD6_POWER_BUS_2_TERMINAL
'  LP_BUS_OUT = POWER_BUS_2
'               fallback POWER_24V_BUS_2_PSU
'               fallback PD6_POWER_SUPPLY
'
'RIGHT_* follows the same rule for a paired right-side VFD.
Private Function VFD_DWG_SyncLPBusFieldsFromQueue(ByVal wsQueue As Worksheet) As Long
    Dim map As Object
    Dim lastRow As Long, r As Long
    Dim lpBusIn As String, lpBusOut As String
    Dim rightBusIn As String, rightBusOut As String
    Dim rowChanged As Boolean, changedRows As Long
    Dim leftHasDevice As Boolean, rightHasDevice As Boolean

    Set map = VFD_DWG_HeaderMap(wsQueue)
    VFD_DWG_RequireHeaders map, Array("LP_BUS_IN", "LP_BUS_OUT", "LP_BUS2_OUT", _
                                      "RIGHT_LP_BUS_IN", "RIGHT_LP_BUS_OUT", "RIGHT_LP_BUS2_OUT")

    lastRow = VFD_DWG_LastDataRow(wsQueue)

    For r = 2 To lastRow
        If VFD_DWG_IsYes(VFD_DWG_CellText(wsQueue, r, map, "ENABLED")) Then
            rowChanged = False

            leftHasDevice = (Len(Trim$(VFD_DWG_CellText(wsQueue, r, map, "SOURCE_ROW"))) > 0) And _
                            (UCase$(Trim$(VFD_DWG_CellText(wsQueue, r, map, "TYPE"))) <> "PNL")

            If leftHasDevice Then
                lpBusIn = VFD_DWG_FirstQueueText(wsQueue, r, map, Array( _
                                "INSIDE_PSU_TERM", _
                                "POWER_24V_BUS_2_TERMINAL", _
                                "PD6_POWER_BUS_2_TERMINAL"))

                lpBusOut = VFD_DWG_FirstQueueText(wsQueue, r, map, Array( _
                                 "POWER_BUS_2", _
                                 "POWER_24V_BUS_2_PSU", _
                                 "PD6_POWER_SUPPLY"))

                If VFD_DWG_SetQueueTextIfDifferent(wsQueue, r, map, "LP_BUS_IN", lpBusIn) Then rowChanged = True
                If VFD_DWG_SetQueueTextIfDifferent(wsQueue, r, map, "LP_BUS_OUT", lpBusOut) Then rowChanged = True
                If VFD_DWG_SetQueueTextIfDifferent(wsQueue, r, map, "LP_BUS2_OUT", lpBusOut) Then rowChanged = True
            End If

            rightHasDevice = (Len(Trim$(VFD_DWG_CellText(wsQueue, r, map, "RIGHT_SOURCE_ROW"))) > 0) Or _
                             (Len(Trim$(VFD_DWG_CellText(wsQueue, r, map, "RIGHT_SIS_ELEMENT_NUMBER"))) > 0)

            If rightHasDevice Then
                rightBusIn = VFD_DWG_FirstQueueText(wsQueue, r, map, Array( _
                                   "RIGHT_INSIDE_PSU_TERM", _
                                   "RIGHT_POWER_24V_BUS_2_TERMINAL", _
                                   "RIGHT_PD6_POWER_BUS_2_TERMINAL"))

                rightBusOut = VFD_DWG_FirstQueueText(wsQueue, r, map, Array( _
                                    "RIGHT_POWER_BUS_2", _
                                    "RIGHT_POWER_24V_BUS_2_PSU", _
                                    "RIGHT_PD6_POWER_SUPPLY"))

                If VFD_DWG_SetQueueTextIfDifferent(wsQueue, r, map, "RIGHT_LP_BUS_IN", rightBusIn) Then rowChanged = True
                If VFD_DWG_SetQueueTextIfDifferent(wsQueue, r, map, "RIGHT_LP_BUS_OUT", rightBusOut) Then rowChanged = True
                If VFD_DWG_SetQueueTextIfDifferent(wsQueue, r, map, "RIGHT_LP_BUS2_OUT", rightBusOut) Then rowChanged = True
            End If

            If rowChanged Then changedRows = changedRows + 1
        End If
    Next r

    VFD_DWG_SyncLPBusFieldsFromQueue = changedRows
End Function

Private Function VFD_DWG_FirstQueueText(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                        ByVal map As Object, ByVal headerChoices As Variant) As String
    Dim h As Variant
    Dim valueText As String

    For Each h In headerChoices
        valueText = VFD_DWG_CellText(ws, rowNumber, map, CStr(h))
        If Len(Trim$(valueText)) > 0 Then
            VFD_DWG_FirstQueueText = valueText
            Exit Function
        End If
    Next h

    VFD_DWG_FirstQueueText = vbNullString
End Function

Private Function VFD_DWG_SetQueueTextIfDifferent(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                                   ByVal map As Object, ByVal headerName As String, _
                                                   ByVal newValue As String) As Boolean
    Dim oldValue As String

    oldValue = VFD_DWG_CellText(ws, rowNumber, map, headerName)
    If StrComp(Trim$(oldValue), Trim$(newValue), vbTextCompare) <> 0 Then
        VFD_DWG_PutCell ws, rowNumber, map, headerName, newValue
        VFD_DWG_SetQueueTextIfDifferent = True
    End If
End Function

Private Function VFD_DWG_NormalizePageCodeValue(ByVal rawPageCode As String, _
                                                     Optional ByVal planID As String = vbNullString, _
                                                     Optional ByVal circuitID As String = vbNullString, _
                                                     Optional ByVal seedID As String = vbNullString) As String
    Dim s As String
    Dim p As String
    Dim c As String
    Dim seed As String

    s = UCase$(Trim$(rawPageCode))
    s = Replace(s, "_", "-")
    p = UCase$(Trim$(planID))
    c = UCase$(Trim$(circuitID))
    seed = UCase$(Trim$(seedID))

    Select Case s
        Case "IO", "I/O", "VFD-IO", "VFDIO", "MOVIFLEX-IO"
            VFD_DWG_NormalizePageCodeValue = "IO"
            Exit Function
        Case "PWR", "VFD-PWR", "POWER"
            VFD_DWG_NormalizePageCodeValue = "PWR"
            Exit Function
        Case "MPWR", "MAIN-PWR", "MAIN-POWER"
            VFD_DWG_NormalizePageCodeValue = "MPWR"
            Exit Function
    End Select

    'Only infer a page kind when PAGE_CODE itself is blank. Do not overwrite
    'valid custom page codes merely because they happen to use MOVIFLEX_IO.
    If Len(s) = 0 Then
        If p = "MOVIFLEX_IO" Or c = "MOVIFLEX_IO" Or seed = "VFD_MOVI_IO" Then
            VFD_DWG_NormalizePageCodeValue = "IO"
        ElseIf p = "MOVIFLEX_PWR" Or c = "MOVIFLEX" Then
            VFD_DWG_NormalizePageCodeValue = "PWR"
        Else
            VFD_DWG_NormalizePageCodeValue = s
        End If
    Else
        VFD_DWG_NormalizePageCodeValue = s
    End If
End Function

Private Function VFD_DWG_NormalizeQueuePageCodes(ByVal wsQueue As Worksheet) As Long
    Dim map As Object
    Dim lastRow As Long, r As Long
    Dim rawPageCode As String, canonicalPageCode As String
    Dim planID As String, circuitID As String, seedID As String
    Dim changedRows As Long

    Set map = VFD_DWG_HeaderMap(wsQueue)
    VFD_DWG_RequireHeaders map, Array("PAGE_CODE", "PLAN_ID", "CIRCUIT_ID", "SEED_ID")
    lastRow = VFD_DWG_LastDataRow(wsQueue)

    For r = 2 To lastRow
        rawPageCode = VFD_DWG_CellText(wsQueue, r, map, "PAGE_CODE")
        planID = VFD_DWG_CellText(wsQueue, r, map, "PLAN_ID")
        circuitID = VFD_DWG_CellText(wsQueue, r, map, "CIRCUIT_ID")
        seedID = VFD_DWG_CellText(wsQueue, r, map, "SEED_ID")

        canonicalPageCode = VFD_DWG_NormalizePageCodeValue(rawPageCode, planID, circuitID, seedID)
        If Len(canonicalPageCode) > 0 Then
            If StrComp(Trim$(rawPageCode), canonicalPageCode, vbTextCompare) <> 0 Then
                VFD_DWG_PutCell wsQueue, r, map, "PAGE_CODE", canonicalPageCode
                changedRows = changedRows + 1
            End If
        End If
    Next r

    VFD_DWG_NormalizeQueuePageCodes = changedRows
End Function

Private Function VFD_DWG_IsIOBusQueueRow(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                         ByVal map As Object) As Boolean
    Dim pageCode As String
    Dim planID As String
    Dim circuitID As String
    Dim seedID As String

    pageCode = VFD_DWG_CellText(ws, rowNumber, map, "PAGE_CODE")
    planID = VFD_DWG_CellText(ws, rowNumber, map, "PLAN_ID")
    circuitID = VFD_DWG_CellText(ws, rowNumber, map, "CIRCUIT_ID")
    seedID = VFD_DWG_CellText(ws, rowNumber, map, "SEED_ID")

    VFD_DWG_IsIOBusQueueRow = _
        (VFD_DWG_NormalizePageCodeValue(pageCode, planID, circuitID, seedID) = "IO") Or _
        (InStr(1, circuitID, "MOVIFLEX_IO", vbTextCompare) > 0)
End Function

Public Sub VFD_DWG_Repair_Coordinates_And_Refresh()
    Dim wsConfig As Worksheet

    On Error GoTo EH
    VFD_DWG_BeginFastMode "Repairing VFD queue coordinates..."
    VFD_DWG_SetupAllSheets
    Set wsConfig = VFD_DWG_GetOrCreateSheet(SH_CONFIG)
    VFD_DWG_SetConfigValue wsConfig, "VFD_USE_SHEET_PLAN_COORDINATES", "NO"
    VFD_DWG_SetConfigValue wsConfig, "VFD_PRESERVE_QUEUE_COORDINATE_OVERRIDES", "NO"
    Call VFD_DWG_BackfillPD6Core
    Call VFD_DWG_Backfill24VCore
    Call VFD_DWG_BackfillNetworkCore
    Call VFD_DWG_BackfillSTOCore
    VFD_DWG_RefreshQueueCore False, True
    VFD_DWG_EndFastMode

    ThisWorkbook.Worksheets(SH_QUEUE).Activate
    MsgBox "VFD queue coordinates were rebuilt from the Circuit Library. Blank right-side library coordinates fall back to VFD_DWG_CONFIG." & vbCrLf & _
           "Sheet Plan coordinates are disabled unless VFD_USE_SHEET_PLAN_COORDINATES is changed to YES.", _
           vbInformation, "ONGEN VFD Coordinate Repair"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    MsgBox "VFD coordinate repair failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD Coordinate Repair"
End Sub

'Rebuilds the queue strictly from the sheet plan and clears previous row overrides/status.
Public Sub VFD_DWG_Rebuild_Queue_From_Plan()
    Dim answer As VbMsgBoxResult

    answer = MsgBox("This rebuild will replace queue overrides, output names, sheet numbers, and prior status." & vbCrLf & _
                    "Device and circuit placement sheets will not be deleted." & vbCrLf & vbCrLf & _
                    "Continue?", vbQuestion + vbYesNo, "Rebuild VFD Queue")
    If answer <> vbYes Then Exit Sub

    On Error GoTo EH
    VFD_DWG_BeginFastMode "Rebuilding VFD queue from sheet plan..."
    VFD_DWG_SetupAllSheets
    Call VFD_DWG_BackfillPD6Core
    Call VFD_DWG_Backfill24VCore
    Call VFD_DWG_BackfillNetworkCore
    Call VFD_DWG_BackfillSTOCore
    VFD_DWG_RefreshQueueCore True, False
    VFD_DWG_EndFastMode
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    MsgBox "VFD queue rebuild failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD Queue"
End Sub

'Runs the existing 480V build, then installs/repairs sheets and refreshes the queue.
Public Sub VFD_DWG_Build_480V_And_Refresh()
    Dim stageName As String
    Dim macroPath As String
    Dim pd6Count As Long, powerCount As Long, networkCount As Long, stoCount As Long

    If mBuild480VRunning Then
        MsgBox "The 480V/VFD build is already running. The duplicate request was ignored.", _
               vbInformation, "ONGEN VFD"
        Exit Sub
    End If

    On Error GoTo EH
    mBuild480VRunning = True

    stageName = "Running Step 08 exactly once"
    macroPath = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!Step08_Build_480V_VFD_Generator_From_PD6"
    Application.Run macroPath

    stageName = "Installing/repairing VFD V4.0 data model"
    VFD_DWG_BeginFastMode stageName
    VFD_DWG_SetupAllSheets

    stageName = "Backfilling PD6, Step 07 24V, Step 11B network, and IO_DEVICE_LIST STO data"
    pd6Count = VFD_DWG_BackfillPD6Core()
    powerCount = VFD_DWG_Backfill24VCore()
    networkCount = VFD_DWG_BackfillNetworkCore()
    stoCount = VFD_DWG_BackfillSTOCore()

    stageName = "Refreshing unique grouped VFD drawing queue"
    VFD_DWG_RefreshQueueCore False, True
    VFD_DWG_EndFastMode

    mBuild480VRunning = False
    ThisWorkbook.Worksheets(SH_QUEUE).Activate
    VFD_DWG_AppendLog "VFD_DWG_Build_480V_And_Refresh", "OK", _
        "Step 08 ran once. Backfill PD6=" & CStr(pd6Count) & _
        "; 24V=" & CStr(powerCount) & "; Network=" & CStr(networkCount) & _
        "; STO=" & CStr(stoCount) & ". The unique VFD V4.0 queue was refreshed."
    MsgBox "The 480V generator and VFD drawing queue were refreshed once." & vbCrLf & vbCrLf & _
           "PD6 backfill: " & CStr(pd6Count) & vbCrLf & _
           "Step 07 24V backfill: " & CStr(powerCount) & vbCrLf & _
           "Step 11B network backfill: " & CStr(networkCount) & vbCrLf & _
           "IO_DEVICE_LIST STO backfill: " & CStr(stoCount), _
           vbInformation, "ONGEN VFD"
    Exit Sub
EH:
    mBuild480VRunning = False
    VFD_DWG_EndFastMode
    VFD_DWG_AppendLog "VFD_DWG_Build_480V_And_Refresh", "ERROR", stageName & " | " & Err.description
    MsgBox "VFD build/refresh failed during:" & vbCrLf & stageName & vbCrLf & vbCrLf & Err.description, _
           vbCritical, "ONGEN VFD"
End Sub


'Backfills PD6 motor data, Step 07 24V data, Step 11B network data, and IO_DEVICE_LIST STO data.
'All values are propagated into VFD_480V_Generator before the queue is refreshed.
Public Sub VFD_DWG_Backfill_All_Ready_Data()
    Dim pd6Count As Long, powerCount As Long, networkCount As Long, stoCount As Long

    On Error GoTo EH
    VFD_DWG_BeginFastMode "Backfilling VFD network, 24V, and PD6 data..."
    VFD_DWG_SetupAllSheets
    pd6Count = VFD_DWG_BackfillPD6Core()
    powerCount = VFD_DWG_Backfill24VCore()
    networkCount = VFD_DWG_BackfillNetworkCore()
    stoCount = VFD_DWG_BackfillSTOCore()
    VFD_DWG_RefreshQueueCore False, True
    VFD_DWG_EndFastMode

    VFD_DWG_AppendLog "VFD_DWG_Backfill_All_Ready_Data", "OK", _
        "PD6=" & CStr(pd6Count) & "; 24V=" & CStr(powerCount) & _
        "; Network=" & CStr(networkCount) & "; STO=" & CStr(stoCount)
    MsgBox "VFD backfill completed." & vbCrLf & vbCrLf & _
           "PD6 rows updated: " & CStr(pd6Count) & vbCrLf & _
           "Step 07 24V rows updated: " & CStr(powerCount) & vbCrLf & _
           "Step 11B network rows updated: " & CStr(networkCount) & vbCrLf & _
           "IO_DEVICE_LIST STO rows updated: " & CStr(stoCount) & vbCrLf & vbCrLf & _
           "The VFD drawing queue was refreshed.", vbInformation, "ONGEN VFD Backfill"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    VFD_DWG_AppendLog "VFD_DWG_Backfill_All_Ready_Data", "ERROR", Err.description
    MsgBox "VFD backfill failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD Backfill"
End Sub

Public Sub VFD_DWG_Backfill_PD6_Motor_Power()
    Dim updatedCount As Long
    On Error GoTo EH
    VFD_DWG_BeginFastMode "Backfilling VFD motor power from PD6_IMPORT..."
    VFD_DWG_SetupAllSheets
    updatedCount = VFD_DWG_BackfillPD6Core()
    VFD_DWG_RefreshQueueCore False, True
    VFD_DWG_EndFastMode
    MsgBox CStr(updatedCount) & " VFD source row(s) were updated from PD6_IMPORT." & vbCrLf & _
           "Motor Power (Main Drive) is now available to BLOCK_EDIT.", _
           vbInformation, "ONGEN VFD PD6 Backfill"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    MsgBox "PD6 VFD backfill failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD"
End Sub

Public Sub VFD_DWG_Backfill_24V_From_Step07()
    Dim updatedCount As Long
    On Error GoTo EH
    VFD_DWG_BeginFastMode "Backfilling VFD 24V power from Step 07 worksheets..."
    VFD_DWG_SetupAllSheets
    updatedCount = VFD_DWG_Backfill24VCore()
    VFD_DWG_RefreshQueueCore False, True
    VFD_DWG_EndFastMode
    MsgBox CStr(updatedCount) & " VFD source row(s) were updated from Step 07 24V worksheets.", _
           vbInformation, "ONGEN VFD 24V Backfill"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    MsgBox "Step 07 24V VFD backfill failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD"
End Sub

Public Sub VFD_DWG_Backfill_Network_From_Step11B()
    Dim sourceUpdated As Long
    Dim queueUpdated As Long
    Dim matchedVFDs As Long
    Dim cleanSheetsRead As Long
    Dim skippedRows As Long
    Dim missingPanels As String
    Dim stageText As String

    On Error GoTo EH

    VFD_DWG_BeginFastMode "Backfilling VFD network data from Network Clean..."
    stageText = "Reading Network Clean worksheets"

    sourceUpdated = VFD_DWG_BackfillNetworkCleanRobust( _
                    queueUpdated, matchedVFDs, cleanSheetsRead, _
                    skippedRows, missingPanels, stageText)

    VFD_DWG_EndFastMode

    MsgBox "VFD Network Clean backfill completed." & vbCrLf & vbCrLf & _
           "Network Clean sheets read: " & CStr(cleanSheetsRead) & vbCrLf & _
           "Matched VFD source records: " & CStr(matchedVFDs) & vbCrLf & _
           "VFD_480V_Generator rows updated: " & CStr(sourceUpdated) & vbCrLf & _
           "VFD_DWG_QUEUE rows updated: " & CStr(queueUpdated) & vbCrLf & _
           "Skipped / unmatched VFD records: " & CStr(skippedRows) & _
           IIf(Len(missingPanels) > 0, vbCrLf & vbCrLf & _
               "Panels without a usable Network Clean source:" & vbCrLf & missingPanels, vbNullString) & _
           vbCrLf & vbCrLf & _
           "See VFD_NETWORK_BACKFILL_AUDIT for details.", _
           vbInformation, "ONGEN VFD Network Backfill"
    Exit Sub

EH:
    VFD_DWG_EndFastMode
    MsgBox "VFD Network Clean backfill failed." & vbCrLf & vbCrLf & _
           "Stage: " & stageText & vbCrLf & _
           "Error " & CStr(Err.Number) & ": " & Err.description & vbCrLf & vbCrLf & _
           "No queue rebuild is required by this backfill. " & _
           "Use the diagnostic text above to identify the exact failing stage.", _
           vbCritical, "ONGEN VFD Network Backfill"
End Sub


'Backward-compatible canonical alias.
'Existing MAIN buttons from earlier releases may still call this name.
Public Sub VFD_DWG_BackfillNetworkDetails()
    VFD_DWG_Backfill_Network_From_Step11B
End Sub

'Backward-compatible entry point retained for old buttons. Cable tags are now built
'only by the separate VFD_DWG_Build_Cable_Tag_Output procedure.
Public Sub VFD_DWG_Backfill_Network_And_Cable_Tags()
    VFD_DWG_Backfill_Network_From_Step11B
End Sub

Public Sub VFD_DWG_Build_Cable_Tag_Output()
    'V25.7.6: Compatibility entry point only.
    'The governing Step 15H implementation is Build_ONGEN_Combined_Label_List in mod08.
    On Error GoTo EH
    Application.Run "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!Build_ONGEN_Combined_Label_List"
    Exit Sub
EH:
    MsgBox "Cable tag output failed." & vbCrLf & _
           "Required macro: Build_ONGEN_Combined_Label_List (mod08_Label_List_Exporter)" & vbCrLf & vbCrLf & _
           Err.description, vbCritical, "ONGEN Cable Tag Output"
End Sub

Public Sub VFD_DWG_BuildAllCableTags()
    VFD_DWG_Build_Cable_Tag_Output
End Sub

'Pulls every VFD STO source from IO_DEVICE_LIST and refreshes the queue.
'No AutoCAD source/destination arrow is generated for STO; the result is exposed
'as STO_FROM_TEXT for exact BLOCK_EDIT attribute filling.
Public Sub VFD_DWG_Backfill_STO_From_IO_Device_List()
    Dim updatedCount As Long

    On Error GoTo EH
    VFD_DWG_BeginFastMode "Backfilling VFD STO sources from IO_DEVICE_LIST..."
    VFD_DWG_SetupAllSheets
    updatedCount = VFD_DWG_BackfillSTOCore()
    VFD_DWG_RefreshQueueCore False, True
    VFD_DWG_EndFastMode

    MsgBox CStr(updatedCount) & " VFD source row(s) received STO source data from IO_DEVICE_LIST." & vbCrLf & _
           "Use STO_FROM_TEXT in BLOCK_EDIT. No STO arrow line is generated.", _
           vbInformation, "ONGEN VFD STO Backfill"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    MsgBox "VFD STO backfill failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD"
End Sub

'Sets one VFD on every PWR and IO sheet, then refreshes the queue.
Public Sub VFD_DWG_Use_One_VFD_Per_Sheet()
    VFD_DWG_SetDevicesPerSheet 1
End Sub

'Sets two VFDs on every PWR and IO sheet when a matching partner is available.
Public Sub VFD_DWG_Use_Two_VFD_Per_Sheet()
    VFD_DWG_SetDevicesPerSheet 2
End Sub

'Compatibility entry point for old buttons. There is no VFD-only UI builder anymore.
Public Sub VFD_DWG_Repair_Main_Buttons()
    On Error GoTo EH
    Application.Run "'" & ThisWorkbook.Name & "'!ONGEN_RELOAD_ALL_UI_BUTTONS"
    Exit Sub
EH:
    MsgBox "Use ONGEN_RELOAD_ALL_UI_BUTTONS from mod00_UI_Buttons_ProgressBar.", _
           vbExclamation, "ONGEN UI"
End Sub

'====================================================================================
' OPEN / MAINTENANCE COMMANDS
'====================================================================================

Public Sub VFD_DWG_Open_Readme(): VFD_DWG_OpenSheet SH_README: End Sub
Public Sub VFD_DWG_Open_Config(): VFD_DWG_OpenSheet SH_CONFIG: End Sub
Public Sub VFD_DWG_Open_Sheet_Plan(): VFD_DWG_OpenSheet SH_SHEET_PLAN: End Sub
Public Sub VFD_DWG_Open_Seed_Library(): VFD_DWG_OpenSheet SH_SEEDS: End Sub
Public Sub VFD_DWG_Open_Queue(): VFD_DWG_OpenSheet SH_QUEUE: End Sub
Public Sub VFD_DWG_Open_Circuit_Library(): VFD_DWG_OpenSheet SH_CIRCUITS: End Sub
Public Sub VFD_DWG_Open_Circuit_Placement(): VFD_DWG_OpenSheet SH_CIRCUIT_PLACEMENT: End Sub
Public Sub VFD_DWG_Open_Device_Library(): VFD_DWG_OpenSheet SH_DEVICES: End Sub
Public Sub VFD_DWG_Open_Device_Placement(): VFD_DWG_OpenSheet SH_DEVICE_PLACEMENT: End Sub
Public Sub VFD_DWG_Open_Attribute_Map(): VFD_DWG_OpenSheet SH_ATTRMAP: End Sub

Public Sub VFD_DWG_Add_Device_To_Selected_VFD()
    'C04.6: assigns an optional device to one exact VFD, including LEFT/RIGHT ownership
    'on paired drawings. DRAWING_ID still controls which drawing receives the device;
    'TARGET_VFD and TARGET_SIDE identify which physical VFD on that drawing owns it.
    Dim wsQueue As Worksheet, wsPlace As Worksheet
    Dim queueRow As Long, outRow As Long
    Dim drawingID As String, planID As String, pageCode As String
    Dim leftSis As String, rightSis As String, targetSis As String, targetSide As String
    Dim sideChoice As String, deviceType As String, instanceID As String, locatorText As String
    Dim qMap As Object, pMap As Object

    On Error GoTo EH
    Set wsQueue = VFD_DWG_GetOrCreateSheet(SH_QUEUE)
    Set wsPlace = VFD_DWG_GetOrCreateSheet(SH_DEVICE_PLACEMENT)
    VFD_DWG_SetupDevicePlacement

    If ActiveSheet.Name <> SH_QUEUE Or ActiveCell.Row < 2 Then
        wsQueue.Activate
        MsgBox "Select the VFD_DWG_QUEUE row containing the VFD that should own the device, then run this command again.", _
               vbInformation, "Assign Device to VFD"
        Exit Sub
    End If

    queueRow = ActiveCell.Row
    Set qMap = VFD_DWG_HeaderMap(wsQueue)
    drawingID = VFD_DWG_CellText(wsQueue, queueRow, qMap, "DRAWING_ID")
    planID = VFD_DWG_CellText(wsQueue, queueRow, qMap, "PLAN_ID")
    pageCode = VFD_DWG_CellText(wsQueue, queueRow, qMap, "PAGE_CODE")
    leftSis = VFD_DWG_CellText(wsQueue, queueRow, qMap, "SIS_ELEMENT_NUMBER")
    rightSis = VFD_DWG_CellText(wsQueue, queueRow, qMap, "RIGHT_SIS_ELEMENT_NUMBER")

    If Len(drawingID) = 0 Then Err.Raise vbObjectError + 700, , "The selected queue row has no DRAWING_ID."
    If Len(leftSis) = 0 And Len(rightSis) = 0 Then Err.Raise vbObjectError + 701, , "The selected queue row has no VFD SIS element."

    If Len(rightSis) > 0 Then
        sideChoice = Trim$(InputBox( _
            "This drawing contains two VFDs." & vbCrLf & vbCrLf & _
            "Enter 1 for LEFT:  " & leftSis & vbCrLf & _
            "Enter 2 for RIGHT: " & rightSis, _
            "Choose VFD Owner", "1"))
        If Len(sideChoice) = 0 Then Exit Sub
        If UCase$(sideChoice) = "2" Or UCase$(sideChoice) = "RIGHT" Or StrComp(sideChoice, rightSis, vbTextCompare) = 0 Then
            targetSis = rightSis
            targetSide = "RIGHT"
        ElseIf UCase$(sideChoice) = "1" Or UCase$(sideChoice) = "LEFT" Or StrComp(sideChoice, leftSis, vbTextCompare) = 0 Then
            targetSis = leftSis
            targetSide = "LEFT"
        Else
            MsgBox "Enter 1/LEFT or 2/RIGHT. No placement row was created.", vbExclamation, "Choose VFD Owner"
            Exit Sub
        End If
    Else
        targetSis = leftSis
        targetSide = "LEFT"
    End If

    deviceType = Trim$(InputBox("Enter DEVICE_TYPE exactly as listed in VFD_DWG_DEVICE_LIBRARY:", _
                                "Assign Device to " & targetSis, "ENCODER"))
    If Len(deviceType) = 0 Then Exit Sub
    If Not VFD_DWG_DeviceTypeExists(deviceType) Then
        MsgBox "DEVICE_TYPE '" & deviceType & "' was not found in VFD_DWG_DEVICE_LIBRARY." & vbCrLf & _
               "Add/enable the library definition first, then assign it to the VFD.", vbExclamation, "Unknown VFD Device"
        Exit Sub
    End If

    instanceID = Trim$(InputBox("Enter a unique device instance:", "Assign Device", UCase$(deviceType) & "-01"))
    If Len(instanceID) = 0 Then Exit Sub
    locatorText = Trim$(InputBox("Enter locator TEXT/MTEXT. Leave blank to use X/Y/Z fallback:", _
                                 "Assign Device", "LP_SLOT_" & UCase$(deviceType)))

    Set pMap = VFD_DWG_HeaderMap(wsPlace)
    If VFD_DWG_DevicePlacementExists(wsPlace, pMap, drawingID, targetSis, instanceID) Then
        MsgBox "That DEVICE_INSTANCE is already assigned to " & targetSis & " on " & drawingID & ".", _
               vbExclamation, "Duplicate VFD Device"
        Exit Sub
    End If

    outRow = VFD_DWG_LastDataRow(wsPlace) + 1
    If outRow < 2 Then outRow = 2

    VFD_DWG_PutCell wsPlace, outRow, pMap, "ENABLED", "YES"
    VFD_DWG_PutCell wsPlace, outRow, pMap, "DRAWING_ID", drawingID
    VFD_DWG_PutCell wsPlace, outRow, pMap, "PLAN_ID", planID
    VFD_DWG_PutCell wsPlace, outRow, pMap, "PAGE_CODE", pageCode
    VFD_DWG_PutCell wsPlace, outRow, pMap, "TARGET_VFD", targetSis
    VFD_DWG_PutCell wsPlace, outRow, pMap, "TARGET_SIDE", targetSide
    VFD_DWG_PutCell wsPlace, outRow, pMap, "DEVICE_INSTANCE", instanceID
    VFD_DWG_PutCell wsPlace, outRow, pMap, "DEVICE_TYPE", UCase$(deviceType)
    VFD_DWG_PutCell wsPlace, outRow, pMap, "LOCATOR_TEXT", locatorText
    VFD_DWG_PutCell wsPlace, outRow, pMap, "LOCATOR_LAYER", VFD_DWG_GetConfigValue("LOCATOR_LAYER", DEFAULT_LOCATOR_LAYER)
    VFD_DWG_PutCell wsPlace, outRow, pMap, "REMOVE_LOCATOR_AFTER_INSERT", "YES"
    VFD_DWG_PutCell wsPlace, outRow, pMap, "SCALE", 1
    VFD_DWG_PutCell wsPlace, outRow, pMap, "SIS_ELEMENT_NUMBER", targetSis
    VFD_DWG_PutCell wsPlace, outRow, pMap, "DEVICE_TAG", instanceID
    VFD_DWG_PutCell wsPlace, outRow, pMap, "NOTES", "Owned by " & targetSide & " VFD " & targetSis

    VFD_DWG_FormatDataSheet wsPlace
    wsPlace.Activate
    wsPlace.Cells(outRow, 1).Select
    MsgBox "Device '" & instanceID & "' assigned to " & targetSide & " VFD " & targetSis & _
           " on drawing " & drawingID & ".", vbInformation, "ONGEN VFD Device Assignment"
    Exit Sub
EH:
    MsgBox "Could not assign the VFD device:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD"
End Sub

'Checks that a device type is defined and enabled in VFD_DWG_DEVICE_LIBRARY.
Private Function VFD_DWG_DeviceTypeExists(ByVal deviceType As String) As Boolean
    Dim ws As Worksheet, m As Object, r As Long, lastRow As Long
    Set ws = VFD_DWG_GetOrCreateSheet(SH_DEVICES)
    Set m = VFD_DWG_HeaderMap(ws)
    lastRow = VFD_DWG_LastDataRow(ws)
    For r = 2 To lastRow
        If StrComp(VFD_DWG_CellText(ws, r, m, "DEVICE_TYPE"), Trim$(deviceType), vbTextCompare) = 0 Then
            VFD_DWG_DeviceTypeExists = VFD_DWG_IsYes(VFD_DWG_CellText(ws, r, m, "ENABLED"))
            Exit Function
        End If
    Next r
End Function

'Prevents duplicate placement rows for the same device instance on the same physical VFD.
Private Function VFD_DWG_DevicePlacementExists(ByVal ws As Worksheet, ByVal m As Object, _
                                                ByVal drawingID As String, ByVal targetVfd As String, _
                                                ByVal instanceID As String) As Boolean
    Dim r As Long, lastRow As Long
    lastRow = VFD_DWG_LastDataRow(ws)
    For r = 2 To lastRow
        If StrComp(VFD_DWG_CellText(ws, r, m, "DRAWING_ID"), drawingID, vbTextCompare) = 0 And _
           StrComp(VFD_DWG_CellText(ws, r, m, "TARGET_VFD"), targetVfd, vbTextCompare) = 0 And _
           StrComp(VFD_DWG_CellText(ws, r, m, "DEVICE_INSTANCE"), instanceID, vbTextCompare) = 0 Then
            VFD_DWG_DevicePlacementExists = True
            Exit Function
        End If
    Next r
End Function

'Validates/repairs VFD ownership against the current queue. Blank ownership is allowed
'only when the selected drawing contains one VFD; paired drawings must be explicit.
Public Sub VFD_DWG_Validate_Device_Targets()
    Dim wsQ As Worksheet, wsP As Worksheet, qMap As Object, pMap As Object
    Dim qRows As Object, r As Long, qr As Long, lastP As Long, lastQ As Long
    Dim drawingID As String, targetVfd As String, leftSis As String, rightSis As String
    Dim problems As Long, repaired As Long, msg As String

    On Error GoTo EH
    VFD_DWG_SetupDevicePlacement
    Set wsQ = VFD_DWG_GetOrCreateSheet(SH_QUEUE)
    Set wsP = VFD_DWG_GetOrCreateSheet(SH_DEVICE_PLACEMENT)
    Set qMap = VFD_DWG_HeaderMap(wsQ)
    Set pMap = VFD_DWG_HeaderMap(wsP)
    Set qRows = CreateObject("Scripting.Dictionary")
    qRows.CompareMode = vbTextCompare

    lastQ = VFD_DWG_LastDataRow(wsQ)
    For qr = 2 To lastQ
        drawingID = VFD_DWG_CellText(wsQ, qr, qMap, "DRAWING_ID")
        If Len(drawingID) > 0 Then qRows(drawingID) = qr
    Next qr

    lastP = VFD_DWG_LastDataRow(wsP)
    For r = 2 To lastP
        If VFD_DWG_IsYes(VFD_DWG_CellText(wsP, r, pMap, "ENABLED")) Then
            drawingID = VFD_DWG_CellText(wsP, r, pMap, "DRAWING_ID")
            targetVfd = VFD_DWG_CellText(wsP, r, pMap, "TARGET_VFD")
            If Len(drawingID) = 0 Or Not qRows.Exists(drawingID) Then
                problems = problems + 1
                msg = msg & "Row " & r & ": DRAWING_ID not found in queue." & vbCrLf
            Else
                qr = CLng(qRows(drawingID))
                leftSis = VFD_DWG_CellText(wsQ, qr, qMap, "SIS_ELEMENT_NUMBER")
                rightSis = VFD_DWG_CellText(wsQ, qr, qMap, "RIGHT_SIS_ELEMENT_NUMBER")
                If Len(targetVfd) = 0 Then
                    If Len(rightSis) = 0 And Len(leftSis) > 0 Then
                        VFD_DWG_PutCell wsP, r, pMap, "TARGET_VFD", leftSis
                        VFD_DWG_PutCell wsP, r, pMap, "TARGET_SIDE", "LEFT"
                        repaired = repaired + 1
                    Else
                        problems = problems + 1
                        msg = msg & "Row " & r & ": paired drawing requires TARGET_VFD LEFT or RIGHT." & vbCrLf
                    End If
                ElseIf StrComp(targetVfd, leftSis, vbTextCompare) = 0 Then
                    VFD_DWG_PutCell wsP, r, pMap, "TARGET_SIDE", "LEFT"
                ElseIf Len(rightSis) > 0 And StrComp(targetVfd, rightSis, vbTextCompare) = 0 Then
                    VFD_DWG_PutCell wsP, r, pMap, "TARGET_SIDE", "RIGHT"
                Else
                    problems = problems + 1
                    msg = msg & "Row " & r & ": TARGET_VFD '" & targetVfd & "' is not on " & drawingID & "." & vbCrLf
                End If
            End If
        End If
    Next r

    VFD_DWG_FormatDataSheet wsP
    If problems = 0 Then
        MsgBox "VFD device targeting is valid." & vbCrLf & "Auto-repaired rows: " & repaired, vbInformation, "VFD Device Target Validation"
    Else
        MsgBox "VFD device targeting found " & problems & " problem(s)." & vbCrLf & _
               "Auto-repaired rows: " & repaired & vbCrLf & vbCrLf & Left$(msg, 3500), vbExclamation, "VFD Device Target Validation"
    End If
    Exit Sub
EH:
    MsgBox "VFD device target validation failed:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD"
End Sub

Public Sub VFD_DWG_Add_Circuit_To_Selected_VFD()
    Dim wsQueue As Worksheet, wsPlace As Worksheet
    Dim queueRow As Long, outRow As Long
    Dim drawingID As String, circuitID As String, instanceID As String
    Dim qMap As Object, pMap As Object

    On Error GoTo EH
    Set wsQueue = VFD_DWG_GetOrCreateSheet(SH_QUEUE)
    Set wsPlace = VFD_DWG_GetOrCreateSheet(SH_CIRCUIT_PLACEMENT)

    If ActiveSheet.Name <> SH_QUEUE Or ActiveCell.Row < 2 Then
        wsQueue.Activate
        MsgBox "Select a data row in VFD_DWG_QUEUE and run the command again.", vbInformation, "Add VFD Circuit"
        Exit Sub
    End If

    queueRow = ActiveCell.Row
    Set qMap = VFD_DWG_HeaderMap(wsQueue)
    drawingID = VFD_DWG_CellText(wsQueue, queueRow, qMap, "DRAWING_ID")
    If Len(drawingID) = 0 Then Err.Raise vbObjectError + 701, , "The selected queue row has no DRAWING_ID."

    circuitID = Trim$(InputBox("Enter CIRCUIT_ID exactly as listed in VFD_DWG_CIRCUIT_LIBRARY:", _
                               "Add Circuit", "MOVIFLEX_IO"))
    If Len(circuitID) = 0 Then Exit Sub
    instanceID = Trim$(InputBox("Enter a unique circuit instance:", "Add Circuit", circuitID & "-02"))
    If Len(instanceID) = 0 Then Exit Sub

    Set pMap = VFD_DWG_HeaderMap(wsPlace)
    outRow = VFD_DWG_LastDataRow(wsPlace) + 1
    If outRow < 2 Then outRow = 2

    VFD_DWG_PutCell wsPlace, outRow, pMap, "ENABLED", "YES"
    VFD_DWG_PutCell wsPlace, outRow, pMap, "DRAWING_ID", drawingID
    VFD_DWG_PutCell wsPlace, outRow, pMap, "CIRCUIT_INSTANCE", instanceID
    VFD_DWG_PutCell wsPlace, outRow, pMap, "CIRCUIT_ID", UCase$(circuitID)
    VFD_DWG_PutCell wsPlace, outRow, pMap, "INSERT_X", 0
    VFD_DWG_PutCell wsPlace, outRow, pMap, "INSERT_Y", 0
    VFD_DWG_PutCell wsPlace, outRow, pMap, "INSERT_Z", 0
    VFD_DWG_PutCell wsPlace, outRow, pMap, "ROTATION_DEG", 0
    VFD_DWG_PutCell wsPlace, outRow, pMap, "SCALE", 1

    VFD_DWG_FormatDataSheet wsPlace
    wsPlace.Activate
    wsPlace.Cells(outRow, 1).Select
    MsgBox "Additional circuit placement added for " & drawingID & ".", vbInformation, "ONGEN VFD"
    Exit Sub
EH:
    MsgBox "Could not add the VFD circuit:" & vbCrLf & Err.description, vbCritical, "ONGEN VFD"
End Sub


'====================================================================================
' VFD DATA BACKFILL - PD6 / STEP 07 24V / STEP 11B NETWORK / IO_DEVICE_LIST STO
'====================================================================================

Private Function VFD_DWG_BackfillOverwrite() As Boolean
    VFD_DWG_BackfillOverwrite = VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("VFD_BACKFILL_OVERWRITE", "NO")))
End Function

Private Function VFD_DWG_SetSourceIfAllowed(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                             ByVal headerMap As Object, ByVal headerName As String, _
                                             ByVal newValue As Variant, ByVal overwriteExisting As Boolean) As Boolean
    Dim key As String, oldValue As String, newText As String
    key = VFD_DWG_NormalizeHeader(headerName)
    If Not headerMap.Exists(key) Then Exit Function
    If IsError(newValue) Or IsEmpty(newValue) Or IsNull(newValue) Then Exit Function

    newText = Trim$(CStr(newValue))
    If Len(newText) = 0 Then Exit Function
    oldValue = VFD_DWG_CellText(ws, rowNumber, headerMap, headerName)

    If overwriteExisting Or Len(oldValue) = 0 Then
        If StrComp(oldValue, newText, vbBinaryCompare) <> 0 Then
            ws.Cells(rowNumber, CLng(headerMap(key))).Value2 = newValue
            VFD_DWG_SetSourceIfAllowed = True
        End If
    End If
End Function

Private Function VFD_DWG_IsVFDRecord(ByVal sisElement As String, ByVal sisSequence As String, _
                                     ByVal typeText As String) As Boolean
    Dim s As String
    s = UCase$(sisElement & "|" & sisSequence & "|" & typeText)
    VFD_DWG_IsVFDRecord = (InStr(1, s, "VFD", vbTextCompare) > 0 Or _
                           InStr(1, s, "MOVIFLEX", vbTextCompare) > 0 Or _
                           InStr(1, s, "MOVI-FLEX", vbTextCompare) > 0)
End Function

Private Function VFD_DWG_BackfillPD6Core() As Long
    Dim wsSource As Worksheet, wsPD6 As Worksheet
    Dim sourceMap As Object, pd6Map As Object
    Dim pd6Index As Object, pd6PanelSeqIndex As Object, pd6SeqIndex As Object
    Dim r As Long, sourceRow As Long, lastRow As Long, sourceLastRow As Long
    Dim sisElement As String, sisSequence As String, typeText As String
    Dim key As String, panelSeqKey As String
    Dim pd6Row As Long, updated As Boolean, overwriteExisting As Boolean
    Dim areaNumber As String, switchGroup As String, panel As String
    Dim pd6Panel As String, pd6Sequence As String
    Dim motorPower As Variant, sourceValue As Variant

    Set wsSource = VFD_DWG_GetSheet(SH_SOURCE)
    Set wsPD6 = VFD_DWG_GetSheet(SH_PD6)
    If wsSource Is Nothing Or wsPD6 Is Nothing Then Exit Function

    VFD_DWG_SetupSourceColumns
    Set sourceMap = VFD_DWG_HeaderMap(wsSource)
    Set pd6Map = VFD_DWG_HeaderMap(wsPD6)
    Set pd6Index = CreateObject("Scripting.Dictionary")
    Set pd6PanelSeqIndex = CreateObject("Scripting.Dictionary")
    Set pd6SeqIndex = CreateObject("Scripting.Dictionary")
    pd6Index.CompareMode = vbTextCompare
    pd6PanelSeqIndex.CompareMode = vbTextCompare
    pd6SeqIndex.CompareMode = vbTextCompare
    overwriteExisting = VFD_DWG_BackfillOverwrite()

    lastRow = VFD_DWG_LastDataRow(wsPD6)
    For r = 2 To lastRow
        sisElement = VFD_DWG_FirstSourceValue(wsPD6, r, pd6Map, _
                     Array("SIS_Element_Number", "SIS_ELEMENT_NUMBER"))
        pd6Sequence = VFD_DWG_FirstSourceValue(wsPD6, r, pd6Map, _
                      Array("SIS_sequence", "SIS_SEQUENCE"))
        typeText = VFD_DWG_FirstSourceValue(wsPD6, r, pd6Map, _
                   Array("TYPE", "DEVICE TYPE"))
        If VFD_DWG_IsVFDRecord(sisElement, pd6Sequence, typeText) Then
            key = VFD_DWG_SourceIdentityKey(sisElement)
            If Len(key) > 0 And Not pd6Index.Exists(key) Then pd6Index.Add key, r

            pd6Panel = VFD_DWG_FirstSourceValue(wsPD6, r, pd6Map, _
                       Array("PNL", "PANEL", "480V PANEL"))
            panelSeqKey = VFD_DWG_PanelIdentityKey(pd6Panel) & "|" & _
                          VFD_DWG_SourceIdentityKey(pd6Sequence)
            If Len(panelSeqKey) > 1 And Not pd6PanelSeqIndex.Exists(panelSeqKey) Then _
                pd6PanelSeqIndex.Add panelSeqKey, r

            key = VFD_DWG_SourceIdentityKey(pd6Sequence)
            If Len(key) > 0 Then
                If pd6SeqIndex.Exists(key) Then
                    pd6SeqIndex(key) = 0
                Else
                    pd6SeqIndex.Add key, r
                End If
            End If
        End If
    Next r

    sourceLastRow = VFD_DWG_LastDataRow(wsSource)
    For sourceRow = 2 To sourceLastRow
        sisElement = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, _
                     "SIS_ELEMENT_NUMBER")
        typeText = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "TYPE")
        sisSequence = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, _
                      "SIS_SEQUENCE")
        panel = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, _
                Array("480V Panel", "PANEL", "PNL"))

        If VFD_DWG_IsVFDRecord(sisElement, sisSequence, typeText) Then
            pd6Row = 0
            key = VFD_DWG_SourceIdentityKey(sisElement)
            If Len(key) > 0 And pd6Index.Exists(key) Then _
                pd6Row = CLng(pd6Index(key))

            If Len(sisSequence) = 0 Then
                VFD_DWG_ParseSISElement sisElement, areaNumber, switchGroup, sisSequence
            End If

            If pd6Row = 0 Then
                panelSeqKey = VFD_DWG_PanelIdentityKey(panel) & "|" & _
                              VFD_DWG_SourceIdentityKey(sisSequence)
                If Len(panelSeqKey) > 1 And pd6PanelSeqIndex.Exists(panelSeqKey) Then _
                    pd6Row = CLng(pd6PanelSeqIndex(panelSeqKey))
            End If

            If pd6Row = 0 Then
                key = VFD_DWG_SourceIdentityKey(sisSequence)
                If Len(key) > 0 And pd6SeqIndex.Exists(key) Then
                    If CLng(pd6SeqIndex(key)) > 0 Then pd6Row = CLng(pd6SeqIndex(key))
                End If
            End If

            If pd6Row > 0 Then
                updated = False

                'These are authoritative PD6 identity/grouping values. Always refresh
                'them before queue grouping so stale source values cannot pair VFDs
                'under the wrong Area, Panel, or SwitchGroup.
                motorPower = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                             Array("Motor Power (Main Drive)", _
                                   "MOTOR_POWER_MAIN_DRIVE", _
                                   "Motor Power Main Drive"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "Motor Power (Main Drive)", motorPower, True) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("SIS_sequence", "SIS_SEQUENCE"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "SIS_SEQUENCE", sourceValue, True) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("AREA_Number", "AREA_NUMBER", "LOCATION"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "AREA_NUMBER", sourceValue, True) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("SwitchGroup", "SWITCHGROUP", "PWG"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "SWITCHGROUP", sourceValue, True) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("PNL", "PANEL", "480V PANEL"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "480V Panel", sourceValue, True) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("NETWORK_IP", "NETWORK IP"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "NETWORK_IP", sourceValue, overwriteExisting) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("LPN"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "LPN", sourceValue, overwriteExisting) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("Load BUS-1", "LOAD_BUS_1", "Load Bus1"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "Load BUS-1", sourceValue, overwriteExisting) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("Load BUS-2", "LOAD_BUS_2", "Load Bus2"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "Load BUS-2", sourceValue, overwriteExisting) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("Bus Power", "BUS POWER", "POWER BUS"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "PD6_BUS_POWER", sourceValue, overwriteExisting) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("Power Supply", "POWER SUPPLY", "PSU"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "PD6_POWER_SUPPLY", sourceValue, overwriteExisting) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("Power BUS-1 Terminal", _
                                    "Power Bus-1 Terminal", _
                                    "BUS-1 TERMINAL"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "PD6_POWER_BUS_1_TERMINAL", sourceValue, _
                   overwriteExisting) Then updated = True

                sourceValue = VFD_DWG_FirstSourceValue(wsPD6, pd6Row, pd6Map, _
                              Array("Power BUS-2 Terminal", _
                                    "Power Bus-2 Terminal", _
                                    "BUS-2 TERMINAL"))
                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "PD6_POWER_BUS_2_TERMINAL", sourceValue, _
                   overwriteExisting) Then updated = True

                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, _
                   "PD6_SOURCE_ROW", pd6Row, True) Then updated = True

                If updated Then _
                    VFD_DWG_BackfillPD6Core = VFD_DWG_BackfillPD6Core + 1
            End If
        End If
    Next sourceRow
End Function

Private Function VFD_DWG_IsStep07PowerSheet(ByVal ws As Worksheet) As Boolean
    Dim nameText As String
    nameText = UCase$(Trim$(ws.Name))
    VFD_DWG_IsStep07PowerSheet = (InStr(1, nameText, "_24V", vbTextCompare) > 0 And _
                                  InStr(1, nameText, "480V", vbTextCompare) = 0)
End Function

Private Function VFD_DWG_Backfill24VCore() As Long
    Dim wsSource As Worksheet, ws As Worksheet, sourceMap As Object
    Dim sourceIndex As Object, panelSequenceIndex As Object
    Dim sourceRow As Long, r As Long, lastRow As Long, sourceLastRow As Long
    Dim sisElement As String, sisSequence As String, sourceArea As String
    Dim sourceSwitch As String, key As String, panelKey As String
    Dim sheetPanel As String, currentBus As String
    Dim bus1PSU As String, bus2PSU As String, currentPSU As String
    Dim headerA As String, headerB As String, headerG As String
    Dim updated As Boolean, overwriteExisting As Boolean, touched As Object
    Dim valueText As Variant, terminalIn As Variant, terminalOut As Variant
    Dim powerTerminal As Variant, insideTerminal As Variant, loadValue As Variant

    If Not VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("VFD_24V_BACKFILL_ENABLED", "YES"))) Then Exit Function
    Set wsSource = VFD_DWG_GetSheet(SH_SOURCE)
    If wsSource Is Nothing Then Exit Function

    VFD_DWG_SetupSourceColumns
    Set sourceMap = VFD_DWG_HeaderMap(wsSource)
    Set sourceIndex = CreateObject("Scripting.Dictionary")
    Set panelSequenceIndex = CreateObject("Scripting.Dictionary")
    Set touched = CreateObject("Scripting.Dictionary")
    sourceIndex.CompareMode = vbTextCompare
    panelSequenceIndex.CompareMode = vbTextCompare
    touched.CompareMode = vbTextCompare
    overwriteExisting = VFD_DWG_BackfillOverwrite()

    sourceLastRow = VFD_DWG_LastDataRow(wsSource)
    For sourceRow = 2 To sourceLastRow
        sisElement = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, _
                     "SIS_ELEMENT_NUMBER")
        key = VFD_DWG_SourceIdentityKey(sisElement)
        If Len(key) > 0 And Not sourceIndex.Exists(key) Then _
            sourceIndex.Add key, sourceRow

        VFD_DWG_ParseSISElement sisElement, sourceArea, sourceSwitch, sisSequence
        panelKey = VFD_DWG_PanelIdentityKey( _
                   VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, _
                   Array("480V Panel", "PANEL", "PNL"))) & "|" & _
                   VFD_DWG_SourceIdentityKey(sisSequence)
        If Len(panelKey) > 1 And Not panelSequenceIndex.Exists(panelKey) Then _
            panelSequenceIndex.Add panelKey, sourceRow
    Next sourceRow

    For Each ws In ThisWorkbook.Worksheets
        If VFD_DWG_IsStep07PowerSheet(ws) Then
            sheetPanel = ws.Name
            If InStr(1, UCase$(sheetPanel), "_24V", vbTextCompare) > 0 Then
                sheetPanel = Left$(sheetPanel, _
                             InStr(1, UCase$(sheetPanel), "_24V", vbTextCompare) - 1)
            End If
            currentBus = vbNullString
            bus1PSU = vbNullString
            bus2PSU = vbNullString
            lastRow = VFD_DWG_LastDataRow(ws)

            For r = 1 To lastRow
                headerA = VFD_DWG_NormalizeHeader(CStr(ws.Cells(r, 1).Value2))
                headerB = VFD_DWG_NormalizeHeader(CStr(ws.Cells(r, 2).Value2))
                headerG = VFD_DWG_NormalizeHeader(CStr(ws.Cells(r, 7).Value2))

                If headerA = "PWG" And headerB = "BUS_POWER" Then
                    If r + 1 <= lastRow Then
                        If UCase$(Trim$(CStr(ws.Cells(r + 1, 2).Value2))) = "BUS-1" Then _
                            bus1PSU = Trim$(CStr(ws.Cells(r + 1, 3).Value2))
                        If UCase$(Trim$(CStr(ws.Cells(r + 1, 2).Value2))) = "BUS-2" Then _
                            bus2PSU = Trim$(CStr(ws.Cells(r + 1, 3).Value2))
                    End If
                    If r + 2 <= lastRow Then
                        If UCase$(Trim$(CStr(ws.Cells(r + 2, 2).Value2))) = "BUS-1" Then _
                            bus1PSU = Trim$(CStr(ws.Cells(r + 2, 3).Value2))
                        If UCase$(Trim$(CStr(ws.Cells(r + 2, 2).Value2))) = "BUS-2" Then _
                            bus2PSU = Trim$(CStr(ws.Cells(r + 2, 3).Value2))
                    End If
                    currentBus = vbNullString
                ElseIf headerA = "SIS_ELEMENT_NUMBER" Then
                    If InStr(1, headerG, "BUS_1", vbTextCompare) > 0 Then
                        currentBus = "BUS-1"
                    ElseIf InStr(1, headerG, "BUS_2", vbTextCompare) > 0 Then
                        currentBus = "BUS-2"
                    Else
                        currentBus = vbNullString
                    End If
                ElseIf Len(currentBus) > 0 Then
                    sisElement = Trim$(CStr(ws.Cells(r, 1).Value2))
                    If VFD_DWG_IsVFDRecord(sisElement, vbNullString, Trim$(CStr(ws.Cells(r, 2).Value2))) Then
                        key = VFD_DWG_SourceIdentityKey(sisElement)
                        sourceRow = 0
                        If sourceIndex.Exists(key) Then sourceRow = CLng(sourceIndex(key))
                        If sourceRow = 0 Then
                            VFD_DWG_ParseSISElement sisElement, sourceArea, _
                                                     sourceSwitch, sisSequence
                            panelKey = VFD_DWG_PanelIdentityKey(sheetPanel) & "|" & _
                                       VFD_DWG_SourceIdentityKey(sisSequence)
                            If panelSequenceIndex.Exists(panelKey) Then _
                                sourceRow = CLng(panelSequenceIndex(panelKey))
                        End If
                        If sourceRow > 0 Then
                            updated = False
                            terminalIn = ws.Cells(r, 5).Value2
                            terminalOut = ws.Cells(r, 6).Value2
                            powerTerminal = ws.Cells(r, 7).Value2
                            insideTerminal = ws.Cells(r, 8).Value2
                            loadValue = ws.Cells(r, 3).Value2
                            If currentBus = "BUS-1" Then currentPSU = bus1PSU Else currentPSU = bus2PSU

                            If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "POWER_24V_SOURCE_SHEET", ws.Name, overwriteExisting) Then updated = True
                            If currentBus = "BUS-1" Then
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "BUS-1-IN", terminalIn, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "BUS-1-OUT", terminalOut, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "POWER_24V_BUS_1_PSU", currentPSU, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "POWER_24V_BUS_1_TERMINAL", powerTerminal, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "Load BUS-1", loadValue, overwriteExisting) Then updated = True
                            ElseIf currentBus = "BUS-2" Then
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "BUS-2-IN", terminalIn, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "BUS-2-OUT", terminalOut, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "POWER_24V_BUS_2_PSU", currentPSU, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "POWER_24V_BUS_2_TERMINAL", powerTerminal, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "Load BUS-2", loadValue, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "Power BUS-2", currentPSU, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "Terminal", powerTerminal, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "Inside PSU TERM", insideTerminal, overwriteExisting) Then updated = True
                            End If

                            If updated And Not touched.Exists(CStr(sourceRow)) Then touched.Add CStr(sourceRow), True
                        End If
                    End If
                End If
            Next r
        End If
    Next ws

    VFD_DWG_Backfill24VCore = touched.count
End Function

Private Function VFD_DWG_ParsePipeMetadata(ByVal metadataText As String) As Object
    Dim d As Object, parts As Variant, part As Variant, p As Long
    Dim key As String, valueText As String
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    parts = Split(metadataText, "|")
    For Each part In parts
        p = InStr(1, CStr(part), "=", vbBinaryCompare)
        If p > 1 Then
            key = VFD_DWG_NormalizeHeader(Left$(CStr(part), p - 1))
            valueText = Trim$(mid$(CStr(part), p + 1))
            If Len(key) > 0 Then d(key) = valueText
        End If
    Next part
    Set VFD_DWG_ParsePipeMetadata = d
End Function

Private Function VFD_DWG_MetadataValue(ByVal metadata As Object, ByVal keyName As String) As String
    Dim key As String
    key = VFD_DWG_NormalizeHeader(keyName)
    If metadata.Exists(key) Then VFD_DWG_MetadataValue = Trim$(CStr(metadata(key)))
End Function

Private Function VFD_DWG_NetworkDeviceReference(ByVal cellText As String) As String
    Dim p As Long, s As String
    s = Trim$(cellText)
    p = InStr(1, s, "[", vbBinaryCompare)
    If p > 1 Then s = Trim$(Left$(s, p - 1))
    VFD_DWG_NetworkDeviceReference = s
End Function

Private Sub VFD_DWG_ParseNetworkDeviceReference(ByVal deviceReference As String, _
                                                 ByRef switchGroup As String, _
                                                 ByRef sisSequence As String)
    Dim s As String, parts As Variant, i As Long
    s = Replace(Trim$(deviceReference), "_", "-")
    If UCase$(Left$(s, 3)) = "IO-" Then s = mid$(s, 4)
    parts = Split(s, "-")
    switchGroup = vbNullString
    sisSequence = vbNullString
    If UBound(parts) >= 0 Then switchGroup = CStr(parts(0))
    For i = 1 To UBound(parts)
        If Len(sisSequence) > 0 Then sisSequence = sisSequence & "-"
        sisSequence = sisSequence & CStr(parts(i))
    Next i
End Sub

Private Function VFD_DWG_IsNetworkRouteSheet(ByVal ws As Worksheet) As Boolean
    Dim c As Long, lastCol As Long, headerText As String
    If UCase$(Left$(Trim$(ws.Name), 4)) <> "RCP-" Then Exit Function
    lastCol = VFD_DWG_LastDataCol(ws)
    For c = 1 To lastCol
        headerText = UCase$(Trim$(CStr(ws.Cells(1, c).Value2)))
        If headerText Like "X##" Then
            VFD_DWG_IsNetworkRouteSheet = True
            Exit Function
        End If
    Next c
End Function


'====================================================================================
' V25.7.6 - ISOLATED NETWORK CLEAN BACKFILL
'
' This routine deliberately does NOT call VFD_DWG_SetupAllSheets or rebuild the
' VFD queue.  It reads the generated Network Clean worksheets directly and writes
' the network fields into both VFD_480V_Generator and VFD_DWG_QUEUE.
'
' Matching priority:
'   1) PANEL + AREA + SWITCHGROUP + sequence base
'   2) PANEL + sequence base when unique
'   3) PANEL + AREA + SWITCHGROUP when unique
'
' A missing Network Clean sheet is reported, not treated as a fatal error.
'====================================================================================
Private Function VFD_DWG_BackfillNetworkCleanRobust( _
                 ByRef queueUpdated As Long, _
                 ByRef matchedVFDs As Long, _
                 ByRef cleanSheetsRead As Long, _
                 ByRef skippedRows As Long, _
                 ByRef missingPanels As String, _
                 ByRef stageText As String) As Long

    Dim wsSource As Worksheet
    Dim wsQueue As Worksheet
    Dim wsAudit As Worksheet
    Dim ws As Worksheet
    Dim sourceMap As Object
    Dim queueMap As Object
    Dim cleanMap As Object
    Dim usedPanels As Object
    Dim cleanPanels As Object
    Dim touchedSource As Object
    Dim touchedQueue As Object
    Dim records As Collection
    Dim rec As Object
    Dim prevRec As Object
    Dim nextRec As Object
    Dim r As Long
    Dim i As Long
    Dim lastRow As Long
    Dim currentGroup As Long
    Dim currentPort As String
    Dim panel As String
    Dim currentRef As String
    Dim previousRef As String
    Dim nextRef As String
    Dim sourceRow As Long
    Dim sourceSis As String
    Dim sourceSeq As String
    Dim sourcePanel As String
    Dim auditRow As Long
    Dim queueCount As Long
    Dim noteText As String
    Dim panelKey As Variant

    Set wsSource = VFD_DWG_GetSheet(SH_SOURCE)
    Set wsQueue = VFD_DWG_GetSheet(SH_QUEUE)

    If wsSource Is Nothing Then
        Err.Raise vbObjectError + 760, "VFD_DWG_BackfillNetworkCleanRobust", _
                  "Required worksheet '" & SH_SOURCE & "' was not found."
    End If

    If wsQueue Is Nothing Then
        Err.Raise vbObjectError + 761, "VFD_DWG_BackfillNetworkCleanRobust", _
                  "Required worksheet '" & SH_QUEUE & "' was not found."
    End If

    stageText = "Ensuring VFD source network columns"
    VFD_DWG_SetupSourceColumns

    Set sourceMap = VFD_DWG_HeaderMap(wsSource)
    Set queueMap = VFD_DWG_HeaderMap(wsQueue)

    Set usedPanels = CreateObject("Scripting.Dictionary")
    Set cleanPanels = CreateObject("Scripting.Dictionary")
    Set touchedSource = CreateObject("Scripting.Dictionary")
    Set touchedQueue = CreateObject("Scripting.Dictionary")
    usedPanels.CompareMode = vbTextCompare
    cleanPanels.CompareMode = vbTextCompare
    touchedSource.CompareMode = vbTextCompare
    touchedQueue.CompareMode = vbTextCompare

    stageText = "Preparing VFD network audit worksheet"
    Set wsAudit = VFD_DWG_GetOrCreateSheet("VFD_NETWORK_BACKFILL_AUDIT")
    wsAudit.Cells.Clear
    wsAudit.Range("A1:J1").value = Array( _
        "STATUS", "NETWORK_CLEAN_SHEET", "PANEL", "SWITCH_PORT", _
        "CLEAN_SIS_NUMBER", "VFD_SOURCE_ROW", "VFD_SIS_ELEMENT_NUMBER", _
        "NETWORK_FROM", "NETWORK_TO", "DETAIL")
    auditRow = 2

    'Collect panels that actually contain VFD source rows.
    lastRow = VFD_DWG_LastDataRow(wsSource)
    For r = 2 To lastRow
        sourceSis = VFD_DWG_CellText(wsSource, r, sourceMap, "SIS_ELEMENT_NUMBER")
        sourceSeq = VFD_DWG_CellText(wsSource, r, sourceMap, "SIS_SEQUENCE")
        sourcePanel = CStr(VFD_DWG_FirstSourceValue( _
                      wsSource, r, sourceMap, Array("480V Panel", "PANEL", "PNL")))

        If VFD_DWG_IsVFDRecord(sourceSis, sourceSeq, _
           VFD_DWG_CellText(wsSource, r, sourceMap, "TYPE")) Then
            If Len(Trim$(sourcePanel)) > 0 Then
                If Not usedPanels.Exists(VFD_DWG_PanelIdentityKey(sourcePanel)) Then
                    usedPanels.Add VFD_DWG_PanelIdentityKey(sourcePanel), sourcePanel
                End If
            End If
        End If
    Next r

    For Each ws In ThisWorkbook.Worksheets
        If VFD_DWG_IsNetworkCleanSheet(ws) Then
            stageText = "Reading " & ws.Name
            cleanSheetsRead = cleanSheetsRead + 1

            panel = VFD_DWG_CleanPanelName(ws.Name)
            If Len(panel) > 0 Then
                cleanPanels(VFD_DWG_PanelIdentityKey(panel)) = panel
            End If

            Set cleanMap = VFD_DWG_HeaderMap(ws)

            If Not cleanMap.Exists(VFD_DWG_NormalizeHeader("Switch Port")) Or _
               Not cleanMap.Exists(VFD_DWG_NormalizeHeader("SIS Number")) Or _
               Not cleanMap.Exists(VFD_DWG_NormalizeHeader("Device")) Then

                VFD_DWG_NetworkAuditWrite wsAudit, auditRow, _
                    "SKIPPED SHEET", ws.Name, panel, vbNullString, vbNullString, _
                    0, vbNullString, vbNullString, vbNullString, _
                    "Required headers are Switch Port, SIS Number, and Device."
                GoTo NextCleanSheet
            End If

            Set records = New Collection
            currentGroup = 0
            currentPort = vbNullString
            lastRow = VFD_DWG_LastDataRow(ws)

            For r = 2 To lastRow
                If Len(VFD_DWG_CleanValue(ws, r, cleanMap, "Switch Port")) > 0 Then
                    currentPort = VFD_DWG_NormalizeNetworkPort( _
                                  VFD_DWG_CleanValue(ws, r, cleanMap, "Switch Port"))
                    currentGroup = currentGroup + 1
                End If

                If VFD_DWG_CleanRowHasData(ws, r, cleanMap) Then
                    Set rec = CreateObject("Scripting.Dictionary")
                    rec.CompareMode = vbTextCompare
                    rec("ROW") = r
                    rec("GROUP") = currentGroup
                    rec("PORT") = currentPort
                    rec("SIS") = VFD_DWG_CleanValue(ws, r, cleanMap, "SIS Number")
                    rec("DEVICE") = VFD_DWG_CleanValue(ws, r, cleanMap, "Device")
                    rec("TYPE") = VFD_DWG_CleanValue(ws, r, cleanMap, "TYPE")
                    rec("TERM_IN") = VFD_DWG_CleanValue(ws, r, cleanMap, "Terminal (IN)")
                    rec("TERM_OUT") = VFD_DWG_CleanValue(ws, r, cleanMap, "Terminal (OUT)")
                    records.Add rec
                End If
            Next r

            For i = 1 To records.count
                Set rec = records(i)
                currentRef = VFD_DWG_CleanRecordReference( _
                             CStr(rec("SIS")), CStr(rec("DEVICE")), CStr(rec("TYPE")))

                If VFD_DWG_IsVFDRecord(CStr(rec("SIS")), currentRef, _
                   CStr(rec("TYPE")) & "|" & CStr(rec("DEVICE"))) Then

                    stageText = "Matching " & ws.Name & " row " & CStr(rec("ROW"))

                    sourceRow = VFD_DWG_FindCleanVFDSourceRow( _
                                wsSource, sourceMap, panel, CStr(rec("SIS")))

                    If sourceRow > 0 Then
                        previousRef = Trim$(panel & " SW-01 " & CStr(rec("PORT")))
                        nextRef = "END OF ROUTE"

                        If i > 1 Then
                            Set prevRec = records(i - 1)
                            If CLng(prevRec("GROUP")) = CLng(rec("GROUP")) Then
                                previousRef = VFD_DWG_CleanRecordReference( _
                                              CStr(prevRec("SIS")), _
                                              CStr(prevRec("DEVICE")), _
                                              CStr(prevRec("TYPE")))
                            End If
                        End If

                        If i < records.count Then
                            Set nextRec = records(i + 1)
                            If CLng(nextRec("GROUP")) = CLng(rec("GROUP")) Then
                                nextRef = VFD_DWG_CleanRecordReference( _
                                          CStr(nextRec("SIS")), _
                                          CStr(nextRec("DEVICE")), _
                                          CStr(nextRec("TYPE")))
                            End If
                        End If

                        sourceSis = VFD_DWG_CellText( _
                                    wsSource, sourceRow, sourceMap, "SIS_ELEMENT_NUMBER")

                        stageText = "Updating VFD_480V_Generator row " & CStr(sourceRow)
                        VFD_DWG_WriteNetworkFieldsDirect wsSource, sourceMap, sourceRow, _
                            panel, "SW-01", CStr(rec("PORT")), _
                            previousRef & " -> " & currentRef & " -> " & nextRef, _
                            previousRef, nextRef, ws.Name, currentRef, _
                            CStr(rec("TERM_IN")), CStr(rec("TERM_OUT"))

                        If Not touchedSource.Exists(CStr(sourceRow)) Then
                            touchedSource.Add CStr(sourceRow), True
                            matchedVFDs = matchedVFDs + 1
                        End If

                        stageText = "Updating VFD_DWG_QUEUE for " & sourceSis
                        queueCount = VFD_DWG_UpdateQueueNetworkBySIS( _
                                     wsQueue, queueMap, sourceSis, panel, _
                                     "SW-01", CStr(rec("PORT")), _
                                     previousRef & " -> " & currentRef & " -> " & nextRef, _
                                     previousRef, nextRef, ws.Name, currentRef, _
                                     CStr(rec("TERM_IN")), CStr(rec("TERM_OUT")), _
                                     touchedQueue)

                        VFD_DWG_NetworkAuditWrite wsAudit, auditRow, _
                            "UPDATED", ws.Name, panel, CStr(rec("PORT")), _
                            CStr(rec("SIS")), sourceRow, sourceSis, _
                            previousRef, nextRef, _
                            "Updated source row and " & CStr(queueCount) & " queue row(s)."
                    Else
                        skippedRows = skippedRows + 1
                        VFD_DWG_NetworkAuditWrite wsAudit, auditRow, _
                            "NO VFD MATCH", ws.Name, panel, CStr(rec("PORT")), _
                            CStr(rec("SIS")), 0, vbNullString, _
                            vbNullString, vbNullString, _
                            "No unique VFD_480V_Generator match was found."
                    End If
                End If
            Next i
        End If
NextCleanSheet:
    Next ws

    stageText = "Checking VFD panels without Network Clean"
    For Each panelKey In usedPanels.keys
        If Not cleanPanels.Exists(CStr(panelKey)) Then
            If Len(missingPanels) > 0 Then missingPanels = missingPanels & vbCrLf
            missingPanels = missingPanels & CStr(usedPanels(panelKey))
            VFD_DWG_NetworkAuditWrite wsAudit, auditRow, _
                "NO CLEAN SHEET", vbNullString, CStr(usedPanels(panelKey)), _
                vbNullString, vbNullString, 0, vbNullString, _
                vbNullString, vbNullString, _
                "Generate / refresh the Phase 4 Network Clean worksheet for this panel."
        End If
    Next panelKey

    queueUpdated = touchedQueue.count
    VFD_DWG_BackfillNetworkCleanRobust = touchedSource.count

    stageText = "Formatting audit worksheet"
    wsAudit.Columns("A:J").EntireColumn.AutoFit
    wsAudit.rows(1).Font.Bold = True
    wsAudit.Range("A1:J1").AutoFilter
End Function

Private Function VFD_DWG_CleanValue(ByVal ws As Worksheet, _
                                    ByVal rowNumber As Long, _
                                    ByVal cleanMap As Object, _
                                    ByVal headerName As String) As String
    Dim key As String
    key = VFD_DWG_NormalizeHeader(headerName)
    If cleanMap.Exists(key) Then
        VFD_DWG_CleanValue = Trim$(CStr(ws.Cells(rowNumber, CLng(cleanMap(key))).Value2))
    Else
        VFD_DWG_CleanValue = vbNullString
    End If
End Function

Private Function VFD_DWG_CleanRowHasData(ByVal ws As Worksheet, _
                                         ByVal rowNumber As Long, _
                                         ByVal cleanMap As Object) As Boolean
    VFD_DWG_CleanRowHasData = _
        (Len(VFD_DWG_CleanValue(ws, rowNumber, cleanMap, "SIS Number")) > 0 Or _
         Len(VFD_DWG_CleanValue(ws, rowNumber, cleanMap, "Device")) > 0 Or _
         Len(VFD_DWG_CleanValue(ws, rowNumber, cleanMap, "TYPE")) > 0)
End Function

Private Sub VFD_DWG_WriteNetworkFieldsDirect(ByVal ws As Worksheet, _
                                             ByVal map As Object, _
                                             ByVal rowNumber As Long, _
                                             ByVal panel As String, _
                                             ByVal switchName As String, _
                                             ByVal portName As String, _
                                             ByVal routeText As String, _
                                             ByVal fromText As String, _
                                             ByVal toText As String, _
                                             ByVal sourceSheet As String, _
                                             ByVal deviceRef As String, _
                                             ByVal termIn As String, _
                                             ByVal termOut As String)
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_PANEL", panel
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_SWITCH", switchName
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_PORT", portName
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_ROUTE", routeText
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_FROM", fromText
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_TO", toText
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_SOURCE_SHEET", sourceSheet
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NETWORK_DEVICE_REFERENCE", deviceRef
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NET TERMINAL (IN)", termIn
    VFD_DWG_WriteMappedValue ws, map, rowNumber, "NET TERMINAL (OUT)", termOut
End Sub

Private Sub VFD_DWG_WriteMappedValue(ByVal ws As Worksheet, _
                                     ByVal map As Object, _
                                     ByVal rowNumber As Long, _
                                     ByVal headerName As String, _
                                     ByVal valueText As Variant)
    Dim key As String
    key = VFD_DWG_NormalizeHeader(headerName)
    If map.Exists(key) Then
        ws.Cells(rowNumber, CLng(map(key))).Value2 = valueText
    End If
End Sub

Private Function VFD_DWG_UpdateQueueNetworkBySIS( _
                 ByVal wsQueue As Worksheet, _
                 ByVal queueMap As Object, _
                 ByVal sourceSis As String, _
                 ByVal panel As String, _
                 ByVal switchName As String, _
                 ByVal portName As String, _
                 ByVal routeText As String, _
                 ByVal fromText As String, _
                 ByVal toText As String, _
                 ByVal sourceSheet As String, _
                 ByVal deviceRef As String, _
                 ByVal termIn As String, _
                 ByVal termOut As String, _
                 ByVal touchedQueue As Object) As Long

    Dim r As Long
    Dim lastRow As Long
    Dim leftSis As String
    Dim rightSis As String
    Dim updatedThisRow As Boolean

    lastRow = VFD_DWG_LastDataRow(wsQueue)

    For r = 2 To lastRow
        leftSis = VFD_DWG_QueueValue(wsQueue, queueMap, r, "SIS_ELEMENT_NUMBER")
        rightSis = VFD_DWG_QueueValue(wsQueue, queueMap, r, "RIGHT_SIS_ELEMENT_NUMBER")
        updatedThisRow = False

        If VFD_DWG_SourceIdentityKey(leftSis) = VFD_DWG_SourceIdentityKey(sourceSis) Then
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_PANEL", panel
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_SWITCH", switchName
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_PORT", portName
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_ROUTE", routeText
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_FROM", fromText
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_TO", toText
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_SOURCE_SHEET", sourceSheet
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NETWORK_DEVICE_REFERENCE", deviceRef
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NET_TERMINAL_IN", termIn
            VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "NET_TERMINAL_OUT", termOut
            updatedThisRow = True
        End If

        If Len(Trim$(rightSis)) > 0 Then
            If VFD_DWG_SourceIdentityKey(rightSis) = VFD_DWG_SourceIdentityKey(sourceSis) Then
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_PANEL", panel
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_SWITCH", switchName
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_PORT", portName
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_ROUTE", routeText
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_FROM", fromText
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_TO", toText
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_SOURCE_SHEET", sourceSheet
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NETWORK_DEVICE_REFERENCE", deviceRef
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NET_TERMINAL_IN", termIn
                VFD_DWG_WriteMappedValue wsQueue, queueMap, r, "RIGHT_NET_TERMINAL_OUT", termOut
                updatedThisRow = True
            End If
        End If

        If updatedThisRow Then
            If Not touchedQueue.Exists(CStr(r)) Then touchedQueue.Add CStr(r), True
            VFD_DWG_UpdateQueueNetworkBySIS = VFD_DWG_UpdateQueueNetworkBySIS + 1
        End If
    Next r
End Function

Private Function VFD_DWG_QueueValue(ByVal ws As Worksheet, _
                                    ByVal map As Object, _
                                    ByVal rowNumber As Long, _
                                    ByVal headerName As String) As String
    Dim key As String
    key = VFD_DWG_NormalizeHeader(headerName)
    If map.Exists(key) Then
        VFD_DWG_QueueValue = Trim$(CStr(ws.Cells(rowNumber, CLng(map(key))).Value2))
    Else
        VFD_DWG_QueueValue = vbNullString
    End If
End Function

Private Sub VFD_DWG_NetworkAuditWrite(ByVal wsAudit As Worksheet, _
                                      ByRef auditRow As Long, _
                                      ByVal statusText As String, _
                                      ByVal cleanSheet As String, _
                                      ByVal panel As String, _
                                      ByVal portText As String, _
                                      ByVal cleanSis As String, _
                                      ByVal sourceRow As Long, _
                                      ByVal sourceSis As String, _
                                      ByVal fromText As String, _
                                      ByVal toText As String, _
                                      ByVal detailText As String)
    wsAudit.Cells(auditRow, 1).Value2 = statusText
    wsAudit.Cells(auditRow, 2).Value2 = cleanSheet
    wsAudit.Cells(auditRow, 3).Value2 = panel
    wsAudit.Cells(auditRow, 4).Value2 = portText
    wsAudit.Cells(auditRow, 5).Value2 = cleanSis
    If sourceRow > 0 Then wsAudit.Cells(auditRow, 6).Value2 = sourceRow
    wsAudit.Cells(auditRow, 7).Value2 = sourceSis
    wsAudit.Cells(auditRow, 8).Value2 = fromText
    wsAudit.Cells(auditRow, 9).Value2 = toText
    wsAudit.Cells(auditRow, 10).Value2 = detailText
    auditRow = auditRow + 1
End Sub

Private Function VFD_DWG_BackfillNetworkCore() As Long
    Dim wsSource As Worksheet, ws As Worksheet, sourceMap As Object
    Dim sourceIndex As Object, panelSequenceIndex As Object, touched As Object
    Dim sourceRow As Long, sourceLastRow As Long, lastRow As Long, lastCol As Long
    Dim c As Long, r As Long, i As Long, networkSourceRow As Long
    Dim sisElement As String, sisSequence As String, sourceArea As String, sourceSwitch As String
    Dim panel As String, key As String, panelKey As String, typeText As String
    Dim metadata As Object, areaNumber As String, routeSwitchGroup As String
    Dim networkSwitch As String, networkPort As String, networkRoute As String
    Dim deviceRows As Collection, deviceText As String, deviceRef As String
    Dim refSwitch As String, refSequence As String, previousRef As String, nextRef As String
    Dim overwriteExisting As Boolean, updated As Boolean, copyToNetTerminals As Boolean
    Dim cleanCount As Long

    If Not VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("VFD_NETWORK_BACKFILL_ENABLED", "YES"))) Then Exit Function
    Set wsSource = VFD_DWG_GetSheet(SH_SOURCE)
    If wsSource Is Nothing Then Exit Function

    VFD_DWG_SetupSourceColumns
    Set sourceMap = VFD_DWG_HeaderMap(wsSource)

    'Generated Network Clean sheets are authoritative; raw route sheets remain a fallback.
    cleanCount = VFD_DWG_BackfillNetworkFromCleanSheets(wsSource, sourceMap)
    Set sourceIndex = CreateObject("Scripting.Dictionary")
    Set panelSequenceIndex = CreateObject("Scripting.Dictionary")
    Set touched = CreateObject("Scripting.Dictionary")
    sourceIndex.CompareMode = vbTextCompare
    panelSequenceIndex.CompareMode = vbTextCompare
    touched.CompareMode = vbTextCompare
    If cleanCount > 0 Then
        overwriteExisting = False
    Else
        overwriteExisting = VFD_DWG_BackfillOverwrite()
    End If
    copyToNetTerminals = VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("VFD_NETWORK_BACKFILL_TO_NET_TERMINALS", "YES")))

    sourceLastRow = VFD_DWG_LastDataRow(wsSource)
    For sourceRow = 2 To sourceLastRow
        sisElement = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "SIS_ELEMENT_NUMBER")
        typeText = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "TYPE")
        If VFD_DWG_IsVFDRecord(sisElement, vbNullString, typeText) Then
            key = VFD_DWG_SourceIdentityKey(sisElement)
            If Len(key) > 0 And Not sourceIndex.Exists(key) Then sourceIndex.Add key, sourceRow
            panel = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("480V Panel", "PANEL", "PNL"))
            VFD_DWG_ParseSISElement sisElement, sourceArea, sourceSwitch, sisSequence
            panelKey = UCase$(Trim$(panel) & "|" & VFD_DWG_SourceIdentityKey(sisSequence))
            If Len(panelKey) > 1 And Not panelSequenceIndex.Exists(panelKey) Then panelSequenceIndex.Add panelKey, sourceRow
        End If
    Next sourceRow

    For Each ws In ThisWorkbook.Worksheets
        If VFD_DWG_IsNetworkRouteSheet(ws) Then
            lastRow = VFD_DWG_LastDataRow(ws)
            lastCol = VFD_DWG_LastDataCol(ws)

            For c = 1 To lastCol
                networkPort = UCase$(Trim$(CStr(ws.Cells(1, c).Value2)))
                If networkPort Like "X##" Then
                    Set metadata = VFD_DWG_ParsePipeMetadata(CStr(ws.Cells(2, c).Value2))
                    areaNumber = VFD_DWG_MetadataValue(metadata, "AREA")
                    routeSwitchGroup = VFD_DWG_MetadataValue(metadata, "SWG")
                    networkSwitch = VFD_DWG_MetadataValue(metadata, "PANEL_SWITCH_NAME")
                    If Len(networkSwitch) = 0 Then networkSwitch = VFD_DWG_MetadataValue(metadata, "PANEL_SWITCH")
                    networkRoute = VFD_DWG_MetadataValue(metadata, "ROUTE_FAMILY")
                    If Len(networkRoute) = 0 Then networkRoute = VFD_DWG_MetadataValue(metadata, "ROUTE")
                    If Len(VFD_DWG_MetadataValue(metadata, "PORT")) > 0 Then _
                        networkPort = VFD_DWG_MetadataValue(metadata, "PORT")

                    Set deviceRows = New Collection
                    For r = 3 To lastRow
                        If Len(Trim$(CStr(ws.Cells(r, c).Value2))) > 0 Then deviceRows.Add r
                    Next r

                    For i = 1 To deviceRows.count
                        r = CLng(deviceRows(i))
                        deviceText = Trim$(CStr(ws.Cells(r, c).Value2))
                        deviceRef = VFD_DWG_NetworkDeviceReference(deviceText)
                        If VFD_DWG_IsVFDRecord(deviceRef, deviceRef, deviceText) Then
                            refSwitch = vbNullString
                            refSequence = vbNullString
                            VFD_DWG_ParseNetworkDeviceReference deviceRef, refSwitch, refSequence
                            If Len(routeSwitchGroup) = 0 Then routeSwitchGroup = refSwitch

                            networkSourceRow = 0
                            key = VFD_DWG_SourceIdentityKey(areaNumber & "-" & routeSwitchGroup & "-" & refSequence)
                            If Len(key) > 0 And sourceIndex.Exists(key) Then networkSourceRow = CLng(sourceIndex(key))
                            If networkSourceRow = 0 Then
                                panelKey = UCase$(Trim$(ws.Name) & "|" & VFD_DWG_SourceIdentityKey(refSequence))
                                If panelSequenceIndex.Exists(panelKey) Then networkSourceRow = CLng(panelSequenceIndex(panelKey))
                            End If

                            If networkSourceRow > 0 Then
                                If i > 1 Then
                                    previousRef = VFD_DWG_NetworkDeviceReference(CStr(ws.Cells(CLng(deviceRows(i - 1)), c).Value2))
                                Else
                                    previousRef = Trim$(networkSwitch & " " & networkPort)
                                End If
                                If i < deviceRows.count Then
                                    nextRef = VFD_DWG_NetworkDeviceReference(CStr(ws.Cells(CLng(deviceRows(i + 1)), c).Value2))
                                Else
                                    nextRef = "END"
                                End If

                                updated = False
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_PANEL", ws.Name, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_SWITCH", networkSwitch, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_PORT", networkPort, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_ROUTE", networkRoute, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_FROM", previousRef, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_TO", nextRef, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_SOURCE_SHEET", ws.Name, overwriteExisting) Then updated = True
                                If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NETWORK_DEVICE_REFERENCE", deviceRef, overwriteExisting) Then updated = True
                                If copyToNetTerminals Then
                                    If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NET TERMINAL (IN)", previousRef, overwriteExisting) Then updated = True
                                    If VFD_DWG_SetSourceIfAllowed(wsSource, networkSourceRow, sourceMap, "NET TERMINAL (OUT)", nextRef, overwriteExisting) Then updated = True
                                End If
                                If updated And Not touched.Exists(CStr(networkSourceRow)) Then touched.Add CStr(networkSourceRow), True
                            End If
                        End If
                    Next i
                End If
            Next c
        End If
    Next ws

    VFD_DWG_BackfillNetworkCore = cleanCount + touched.count
End Function

Private Function VFD_DWG_IsNetworkCleanSheet(ByVal ws As Worksheet) As Boolean
    Dim map As Object, upperName As String
    upperName = UCase$(Trim$(ws.Name))
    If Right$(upperName, 8) <> " - CLEAN" And Right$(upperName, 6) <> "_CLEAN" Then Exit Function
    Set map = VFD_DWG_HeaderMap(ws)
    VFD_DWG_IsNetworkCleanSheet = (map.Exists(VFD_DWG_NormalizeHeader("Switch Port")) And _
                                   map.Exists(VFD_DWG_NormalizeHeader("SIS Number")) And _
                                   map.Exists(VFD_DWG_NormalizeHeader("Device")))
End Function

Private Function VFD_DWG_CleanPanelName(ByVal sheetName As String) As String
    Dim s As String
    s = Trim$(sheetName)
    If UCase$(Right$(s, 8)) = " - CLEAN" Then s = Left$(s, Len(s) - 8)
    If UCase$(Right$(s, 6)) = "_CLEAN" Then s = Left$(s, Len(s) - 6)
    VFD_DWG_CleanPanelName = Trim$(s)
End Function

Private Function VFD_DWG_NormalizeNetworkPort(ByVal portText As String) As String
    VFD_DWG_NormalizeNetworkPort = ONGEN_CableID_NormalizeNetworkPort(portText)
End Function

Private Function VFD_DWG_CleanRecordReference(ByVal sisText As String, ByVal deviceText As String, _
                                              ByVal typeText As String) As String
    If Len(Trim$(sisText)) > 0 Then
        VFD_DWG_CleanRecordReference = Trim$(sisText)
    ElseIf Len(Trim$(deviceText)) > 0 Then
        VFD_DWG_CleanRecordReference = Trim$(deviceText)
    Else
        VFD_DWG_CleanRecordReference = Trim$(typeText)
    End If
End Function

Private Function VFD_DWG_FirstSequenceToken(ByVal sequenceText As String) As String
    Dim parts As Variant
    parts = Split(Trim$(sequenceText), "-")
    If UBound(parts) >= 0 Then VFD_DWG_FirstSequenceToken = Trim$(CStr(parts(0)))
End Function

Private Function VFD_DWG_SameNumberText(ByVal leftText As String, ByVal rightText As String) As Boolean
    If Len(Trim$(leftText)) = 0 Or Len(Trim$(rightText)) = 0 Then Exit Function
    If IsNumeric(leftText) And IsNumeric(rightText) Then
        VFD_DWG_SameNumberText = (CLng(leftText) = CLng(rightText))
    Else
        VFD_DWG_SameNumberText = (StrComp(Trim$(leftText), Trim$(rightText), vbTextCompare) = 0)
    End If
End Function

Private Function VFD_DWG_FindCleanVFDSourceRow(ByVal wsSource As Worksheet, ByVal sourceMap As Object, _
                                               ByVal panel As String, ByVal cleanSis As String) As Long
    Dim r As Long, lastRow As Long, bestRow As Long, bestScore As Long, score As Long, tieCount As Long
    Dim sourceSis As String, sourceType As String, sourcePanel As String
    Dim cleanArea As String, cleanSwitch As String, cleanSequence As String, cleanBase As String
    Dim sourceArea As String, sourceSwitch As String, sourceSequence As String, sourceBase As String

    VFD_DWG_ParseSISElement cleanSis, cleanArea, cleanSwitch, cleanSequence
    cleanBase = VFD_DWG_FirstSequenceToken(cleanSequence)
    lastRow = VFD_DWG_LastDataRow(wsSource)

    For r = 2 To lastRow
        sourceSis = VFD_DWG_CellText(wsSource, r, sourceMap, "SIS_ELEMENT_NUMBER")
        sourceType = VFD_DWG_CellText(wsSource, r, sourceMap, "TYPE")
        If VFD_DWG_IsVFDRecord(sourceSis, vbNullString, sourceType) Then
            sourcePanel = CStr(VFD_DWG_FirstSourceValue(wsSource, r, sourceMap, Array("480V Panel", "PANEL", "PNL")))
            If VFD_DWG_PanelIdentityKey(sourcePanel) = VFD_DWG_PanelIdentityKey(panel) Then
                VFD_DWG_ParseSISElement sourceSis, sourceArea, sourceSwitch, sourceSequence
                sourceBase = VFD_DWG_FirstSequenceToken(sourceSequence)
                score = 0
                If VFD_DWG_SameNumberText(cleanArea, sourceArea) And _
                   VFD_DWG_SameNumberText(cleanSwitch, sourceSwitch) And _
                   VFD_DWG_SameNumberText(cleanBase, sourceBase) Then
                    score = 100
                ElseIf VFD_DWG_SameNumberText(cleanBase, sourceBase) Then
                    score = 80
                ElseIf VFD_DWG_SameNumberText(cleanArea, sourceArea) And _
                       VFD_DWG_SameNumberText(cleanSwitch, sourceSwitch) Then
                    score = 60
                End If

                If score > bestScore Then
                    bestScore = score
                    bestRow = r
                    tieCount = 1
                ElseIf score > 0 And score = bestScore Then
                    tieCount = tieCount + 1
                End If
            End If
        End If
    Next r

    If bestScore > 0 And tieCount = 1 Then VFD_DWG_FindCleanVFDSourceRow = bestRow
End Function

Private Function VFD_DWG_BackfillNetworkFromCleanSheets(ByVal wsSource As Worksheet, _
                                                         ByVal sourceMap As Object) As Long
    Dim ws As Worksheet, cleanMap As Object, touched As Object
    Dim lastRow As Long, r As Long, n As Long, i As Long, groupNumber As Long
    Dim colPort As Long, colSis As Long, colDevice As Long, colType As Long, colIn As Long, colOut As Long
    Dim currentPort As String, panel As String, previousRef As String, nextRef As String, currentRef As String
    Dim sourceRow As Long, updated As Boolean, overwriteExisting As Boolean, copyToNetTerminals As Boolean
    Dim recRow() As Long, recGroup() As Long, recPort() As String, recSis() As String
    Dim recDevice() As String, recType() As String, recIn() As String, recOut() As String

    Set touched = CreateObject("Scripting.Dictionary")
    touched.CompareMode = vbTextCompare
    overwriteExisting = VFD_DWG_BackfillOverwrite()
    copyToNetTerminals = VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("VFD_NETWORK_BACKFILL_TO_NET_TERMINALS", "YES")))

    For Each ws In ThisWorkbook.Worksheets
        If VFD_DWG_IsNetworkCleanSheet(ws) Then
            Set cleanMap = VFD_DWG_HeaderMap(ws)
            colPort = CLng(cleanMap(VFD_DWG_NormalizeHeader("Switch Port")))
            colSis = CLng(cleanMap(VFD_DWG_NormalizeHeader("SIS Number")))
            colDevice = CLng(cleanMap(VFD_DWG_NormalizeHeader("Device")))
            If cleanMap.Exists(VFD_DWG_NormalizeHeader("TYPE")) Then colType = CLng(cleanMap(VFD_DWG_NormalizeHeader("TYPE"))) Else colType = 0
            If cleanMap.Exists(VFD_DWG_NormalizeHeader("Terminal (IN)")) Then colIn = CLng(cleanMap(VFD_DWG_NormalizeHeader("Terminal (IN)"))) Else colIn = 0
            If cleanMap.Exists(VFD_DWG_NormalizeHeader("Terminal (OUT)")) Then colOut = CLng(cleanMap(VFD_DWG_NormalizeHeader("Terminal (OUT)"))) Else colOut = 0

            n = 0: groupNumber = 0: currentPort = vbNullString
            lastRow = VFD_DWG_LastDataRow(ws)
            For r = 2 To lastRow
                If Len(Trim$(CStr(ws.Cells(r, colPort).Value2))) > 0 Then
                    currentPort = VFD_DWG_NormalizeNetworkPort(CStr(ws.Cells(r, colPort).Value2))
                    groupNumber = groupNumber + 1
                End If
                If Len(Trim$(CStr(ws.Cells(r, colSis).Value2))) > 0 Or _
                   Len(Trim$(CStr(ws.Cells(r, colDevice).Value2))) > 0 Or _
                   (colType > 0 And Len(Trim$(CStr(ws.Cells(r, colType).Value2))) > 0) Then
                    n = n + 1
                    ReDim Preserve recRow(1 To n): ReDim Preserve recGroup(1 To n)
                    ReDim Preserve recPort(1 To n): ReDim Preserve recSis(1 To n)
                    ReDim Preserve recDevice(1 To n): ReDim Preserve recType(1 To n)
                    ReDim Preserve recIn(1 To n): ReDim Preserve recOut(1 To n)
                    recRow(n) = r: recGroup(n) = groupNumber: recPort(n) = currentPort
                    recSis(n) = Trim$(CStr(ws.Cells(r, colSis).Value2))
                    recDevice(n) = Trim$(CStr(ws.Cells(r, colDevice).Value2))
                    If colType > 0 Then recType(n) = Trim$(CStr(ws.Cells(r, colType).Value2))
                    If colIn > 0 Then recIn(n) = Trim$(CStr(ws.Cells(r, colIn).Value2))
                    If colOut > 0 Then recOut(n) = Trim$(CStr(ws.Cells(r, colOut).Value2))
                End If
            Next r

            panel = VFD_DWG_CleanPanelName(ws.Name)
            For i = 1 To n
                currentRef = VFD_DWG_CleanRecordReference(recSis(i), recDevice(i), recType(i))
                If VFD_DWG_IsVFDRecord(recSis(i), currentRef, recType(i) & "|" & recDevice(i)) Then
                    sourceRow = VFD_DWG_FindCleanVFDSourceRow(wsSource, sourceMap, panel, recSis(i))
                    If sourceRow > 0 Then
                        If i > 1 And recGroup(i - 1) = recGroup(i) Then
                            previousRef = VFD_DWG_CleanRecordReference(recSis(i - 1), recDevice(i - 1), recType(i - 1))
                        Else
                            previousRef = Trim$(panel & " SW-01 " & recPort(i))
                        End If
                        If i < n And recGroup(i + 1) = recGroup(i) Then
                            nextRef = VFD_DWG_CleanRecordReference(recSis(i + 1), recDevice(i + 1), recType(i + 1))
                        Else
                            nextRef = "END OF ROUTE"
                        End If

                        updated = False
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_PANEL", panel, overwriteExisting) Then updated = True
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_SWITCH", "SW-01", overwriteExisting) Then updated = True
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_PORT", recPort(i), overwriteExisting) Then updated = True
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_ROUTE", _
                            previousRef & " -> " & currentRef & " -> " & nextRef, overwriteExisting) Then updated = True
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_FROM", previousRef, overwriteExisting) Then updated = True
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_TO", nextRef, overwriteExisting) Then updated = True
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_SOURCE_SHEET", ws.Name, overwriteExisting) Then updated = True
                        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NETWORK_DEVICE_REFERENCE", currentRef, overwriteExisting) Then updated = True
                        If copyToNetTerminals Then
                            If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NET TERMINAL (IN)", recIn(i), overwriteExisting) Then updated = True
                            If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "NET TERMINAL (OUT)", recOut(i), overwriteExisting) Then updated = True
                        End If
                        If updated And Not touched.Exists(CStr(sourceRow)) Then touched.Add CStr(sourceRow), True
                    End If
                End If
            Next i
        End If
    Next ws

    VFD_DWG_BackfillNetworkFromCleanSheets = touched.count
End Function

Private Function VFD_DWG_BuildCableTagOutputCore() As Long
    Dim wsOut As Worksheet, counters As Object, seen As Object
    Dim headers As Variant, typeCodes As Variant, typeDescriptions As Variant, typePrefixes As Variant
    Dim outRow As Long, i As Long

    ONGEN_CableID_BeginRun
    Set wsOut = VFD_DWG_GetOrCreateSheet(SH_CABLE_OUTPUT)
    If wsOut.AutoFilterMode Then wsOut.AutoFilterMode = False
    wsOut.Cells.UnMerge
    wsOut.Cells.Clear

    Set counters = CreateObject("Scripting.Dictionary")
    counters.CompareMode = vbTextCompare
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    headers = Array("CABLE_ID", "CABLE_TYPE", "CABLE_CATEGORY", "PACKAGE", "AREA_NUMBER", "PANEL", _
                    "SWITCHGROUP", "CONDUCTOR_CORE_COUNT", "SIZE", "SHIELD", "FROM_DEVICE", _
                    "FROM_TERMINAL", "TO_DEVICE", "TO_TERMINAL", "SOURCE_DRAWING_SHEET", _
                    "DESTINATION_DRAWING_SHEET", "NETWORK_SWITCH", "NETWORK_PORT", _
                    "RELATED_SIS_ELEMENT_NUMBER", "DESCRIPTION", "INSTALLATION_NOTES", _
                    "SOURCE_DATA_SHEET", "SOURCE_ROW", "MATCH_STATUS", "LAST_REFRESH")

    wsOut.Range("A1:Y1").Merge
    wsOut.Range("A1").Value2 = "ONGEN OPTION A FUNCTIONAL CABLE TAG OUTPUT"
    wsOut.Range("A2").Value2 = "Standard"
    wsOut.Range("B2").Value2 = "ONGEN-STD-001 Chapter 6 - Option A Functional Short Cable ID Standard"
    wsOut.Range("A3").Value2 = "Scope"
    wsOut.Range("B3").Value2 = "Physical cable tags from Network Clean routes, IO_DEVICE_LIST, VFD_480V_Generator, and every generated panel _24v worksheet."
    For i = LBound(headers) To UBound(headers)
        wsOut.Cells(4, i + 1).Value2 = headers(i)
    Next i
    outRow = 5

    VFD_DWG_AddNetworkCableTags wsOut, outRow, counters, seen
    VFD_DWG_AddIOCableTags wsOut, outRow, counters, seen
    VFD_DWG_AddVFDCableTags wsOut, outRow, counters, seen
    VFD_DWG_Add24VCableTags wsOut, outRow, counters, seen

    typeCodes = Array("PWR", "DC", "IO", "SAF", "NET", "FBR", "MTR", "ENC", "BRK", "CTRL", "BUS", "GEN")
    typeDescriptions = Array("AC / 480VAC power", "24VDC power", "Standard / non-safety I/O", "Safety I/O / safety cable", _
                             "Industrial Ethernet copper", "Fiber optic", "Motor power", "Encoder / feedback", _
                             "Motor brake", "General control cable", "Fieldbus / specialty bus", "General / uncategorized cable")
    typePrefixes = Array("WPWR", "WDC", "WIO", "WSF", "WNET", "WFB", "WMTR", "WEN", "WBK", "WCT", "WBS", "WGN")
    wsOut.Range("AA1:AE1").Merge
    wsOut.Range("AA1").Value2 = "CHAPTER 6 OPTION A CABLE TAG LEGEND"
    wsOut.Range("AA4").Value2 = "TYPE CODE"
    wsOut.Range("AB4").Value2 = "CABLE CATEGORY"
    wsOut.Range("AC4").Value2 = "TAG PREFIX"
    wsOut.Range("AD4").Value2 = "ID FORMAT"
    wsOut.Range("AE4").Value2 = "GENERATED COUNT"
    For i = LBound(typeCodes) To UBound(typeCodes)
        wsOut.Cells(i + 5, 27).Value2 = typeCodes(i)
        wsOut.Cells(i + 5, 28).Value2 = typeDescriptions(i)
        wsOut.Cells(i + 5, 29).Value2 = typePrefixes(i)
        wsOut.Cells(i + 5, 30).Value2 = typePrefixes(i) & "-####"
        wsOut.Cells(i + 5, 31).Formula = "=COUNTIF($B:$B,AA" & CStr(i + 5) & ")"
    Next i

    With wsOut.Range("A1:Y1")
        .Font.Bold = True
        .Font.Size = 14
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(31, 78, 121)
        .HorizontalAlignment = xlCenter
    End With
    With wsOut.Range("A4:Y4")
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(47, 84, 150)
        .WrapText = True
    End With
    With wsOut.Range("AA1:AE1")
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(0, 112, 60)
        .HorizontalAlignment = xlCenter
    End With
    With wsOut.Range("AA4:AE4")
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(112, 173, 71)
    End With
    If outRow > 5 Then
        With wsOut.Range("A5:Y" & CStr(outRow - 1))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(217, 217, 217)
            .VerticalAlignment = xlTop
        End With
        wsOut.Range("A4:Y" & CStr(outRow - 1)).AutoFilter
    End If
    wsOut.Columns("A:AE").AutoFit
    VFD_DWG_CapColumnWidths wsOut, 9, 42
    wsOut.Columns("T").columnWidth = 44
    wsOut.Columns("U").columnWidth = 58
    wsOut.Columns("AA:AE").columnWidth = 24
    wsOut.Activate
    ActiveWindow.FreezePanes = False
    wsOut.Range("A5").Select
    ActiveWindow.FreezePanes = True

    VFD_DWG_BuildCableTagOutputCore = outRow - 5
End Function

Private Sub VFD_DWG_AddNetworkCableTags(ByVal wsOut As Worksheet, ByRef outRow As Long, _
                                        ByVal counters As Object, ByVal seen As Object)
    Dim ws As Worksheet, map As Object
    Dim lastRow As Long, r As Long
    Dim colPort As Long, colSis As Long, colDevice As Long, colType As Long, colIn As Long, colOut As Long
    Dim panel As String, currentPort As String, currentSIS As String, currentDevice As String, currentType As String
    Dim currentRef As String, previousRef As String, previousTerminal As String, currentIn As String, currentOut As String
    Dim areaNumber As String, switchGroup As String, sisSequence As String, cableID As String, cableKey As String

    For Each ws In ThisWorkbook.Worksheets
        If VFD_DWG_IsNetworkCleanSheet(ws) Then
            Set map = VFD_DWG_HeaderMap(ws)
            colPort = VFD_DWG_CableHeaderColumn(map, Array("Switch Port"))
            colSis = VFD_DWG_CableHeaderColumn(map, Array("SIS Number", "SIS_ELEMENT_NUMBER"))
            colDevice = VFD_DWG_CableHeaderColumn(map, Array("Device"))
            colType = VFD_DWG_CableHeaderColumn(map, Array("TYPE", "Device Type"))
            colIn = VFD_DWG_CableHeaderColumn(map, Array("Terminal (IN)", "TERMINAL_IN"))
            colOut = VFD_DWG_CableHeaderColumn(map, Array("Terminal (OUT)", "TERMINAL_OUT"))

            If colPort = 0 Or colSis = 0 Or colDevice = 0 Then GoTo NextNetworkSheet
            panel = VFD_DWG_CleanPanelName(ws.Name)
            currentPort = vbNullString
            previousRef = vbNullString
            previousTerminal = vbNullString
            lastRow = VFD_DWG_LastDataRow(ws)

            For r = 2 To lastRow
                If Len(Trim$(CStr(ws.Cells(r, colPort).Value2))) > 0 Then
                    currentPort = VFD_DWG_NormalizeNetworkPort(CStr(ws.Cells(r, colPort).Value2))
                    previousRef = panel & "-NSW01 " & currentPort
                    previousTerminal = currentPort
                End If

                currentSIS = Trim$(CStr(ws.Cells(r, colSis).Value2))
                currentDevice = Trim$(CStr(ws.Cells(r, colDevice).Value2))
                If colType > 0 Then currentType = Trim$(CStr(ws.Cells(r, colType).Value2)) Else currentType = vbNullString
                If colIn > 0 Then currentIn = Trim$(CStr(ws.Cells(r, colIn).Value2)) Else currentIn = vbNullString
                If colOut > 0 Then currentOut = Trim$(CStr(ws.Cells(r, colOut).Value2)) Else currentOut = vbNullString
                currentRef = VFD_DWG_CleanRecordReference(currentSIS, currentDevice, currentType)

                If Len(currentRef) > 0 And Len(currentPort) > 0 Then
                    cableKey = "NET|" & panel & "|" & currentPort & "|" & previousRef & "|" & currentRef
                    If VFD_DWG_RegisterCableKey(seen, cableKey) Then
                        VFD_DWG_ParseSISElement currentSIS, areaNumber, switchGroup, sisSequence
                        cableID = ONGEN_ExportTag_NET(panel, currentPort, previousRef, currentRef)
                        VFD_DWG_WriteCableTagRow wsOut, outRow, Array( _
                            cableID, "NET", "Industrial Ethernet copper", panel, areaNumber, panel, switchGroup, _
                            "TBD", "TBD", "TBD", previousRef, previousTerminal, currentRef, currentIn, _
                            "TBD", "TBD", "SW-01", currentPort, currentSIS, _
                            "Industrial Ethernet cable from " & previousRef & " to " & currentRef, _
                            "Verify cable specification, shield, length, routing, and drawing references before release.", _
                            ws.Name, CStr(r), "REVIEW - CABLE SPEC/SHEETS TBD", Now)
                    End If
                    previousRef = currentRef
                    previousTerminal = currentOut
                End If
            Next r
        End If
NextNetworkSheet:
    Next ws
End Sub

Private Sub VFD_DWG_AddIOCableTags(ByVal wsOut As Worksheet, ByRef outRow As Long, _
                                   ByVal counters As Object, ByVal seen As Object)
    Dim ws As Worksheet, map As Object, groups As Object, rec As Object
    Dim lastRow As Long, r As Long
    Dim colDevice As Long, colDeviceType As Long, colChannel As Long, colSignalType As Long
    Dim colSignalName As Long, colPort As Long, colIOBlock As Long, colBlockID As Long
    Dim colPWG As Long, colPanel As Long, colLocation As Long, colCableGroup As Long
    Dim deviceText As String, blockID As String, panel As String, packageText As String
    Dim deviceType As String, ioBlock As String, areaNumber As String, switchGroup As String
    Dim portText As String, signalText As String, channelText As String, cableGroup As String
    Dim rowClass As String, cableType As String, categoryText As String, descriptionText As String
    Dim groupKey As String, identityToken As String, cableKey As String, cableID As String
    Dim dictionaryKey As Variant, statusText As String

    Set ws = VFD_DWG_GetSheet(SH_IO_DEVICE_LIST)
    If ws Is Nothing Then Exit Sub
    Set map = VFD_DWG_HeaderMap(ws)

    colDevice = VFD_DWG_CableHeaderColumn(map, Array("Device"))
    colDeviceType = VFD_DWG_CableHeaderColumn(map, Array("Device Type", "TYPE/DESC"))
    colChannel = VFD_DWG_CableHeaderColumn(map, Array("Channel IO", "CHANNEL_IO"))
    colSignalType = VFD_DWG_CableHeaderColumn(map, Array("Type", "SIGNAL TYPE"))
    colSignalName = VFD_DWG_CableHeaderColumn(map, Array("Signal Name", "SIGNAL_NAME"))
    colPort = VFD_DWG_CableHeaderColumn(map, Array("Port Location", "PORT_LOCATION"))
    colIOBlock = VFD_DWG_CableHeaderColumn(map, Array("IO Block", "IO_BLOCK"))
    colBlockID = VFD_DWG_CableHeaderColumn(map, Array("Block ID", "BLOCK_ID"))
    colPWG = VFD_DWG_CableHeaderColumn(map, Array("PWG", "SWITCHGROUP"))
    colPanel = VFD_DWG_CableHeaderColumn(map, Array("Panel", "PNL"))
    colLocation = VFD_DWG_CableHeaderColumn(map, Array("Location", "AREA_NUMBER"))
    colCableGroup = VFD_DWG_CableHeaderColumn(map, Array("PHYSICAL_CABLE_GROUP", "CABLE_GROUP", "CABLE GROUP", "CABLE_ID_GROUP"))
    If colDevice = 0 Or colBlockID = 0 Then Exit Sub

    Set groups = CreateObject("Scripting.Dictionary")
    groups.CompareMode = vbTextCompare
    lastRow = VFD_DWG_LastDataRow(ws)

    'Build physical-cable groups first.  When no explicit cable-group field exists,
    'Device + Block ID is treated as one physical cable.  This means a device that
    'lands on both IO/D and IO/S receives two tags by default.
    For r = 2 To lastRow
        deviceText = Trim$(CStr(ws.Cells(r, colDevice).Value2))
        blockID = Trim$(CStr(ws.Cells(r, colBlockID).Value2))
        If colPanel > 0 Then panel = Trim$(CStr(ws.Cells(r, colPanel).Value2)) Else panel = vbNullString
        If Len(deviceText) = 0 Or Len(blockID) = 0 Then GoTo NextSourceRow

        If colCableGroup > 0 Then cableGroup = Trim$(CStr(ws.Cells(r, colCableGroup).Value2)) Else cableGroup = vbNullString
        If Len(cableGroup) > 0 Then
            identityToken = "GROUP:" & cableGroup
        Else
            identityToken = "BLOCK:" & blockID
        End If
        groupKey = UCase$(panel & "|" & deviceText & "|" & identityToken)

        If Not groups.Exists(groupKey) Then
            Set rec = CreateObject("Scripting.Dictionary")
            rec.CompareMode = vbTextCompare
            rec("DEVICE") = deviceText
            rec("PANEL") = panel
            rec("IDENTITY") = identityToken
            rec("BLOCKS") = vbNullString
            rec("DEVICE_TYPES") = vbNullString
            rec("IO_BLOCKS") = vbNullString
            rec("PORTS") = vbNullString
            rec("SIGNALS") = vbNullString
            rec("CHANNELS") = vbNullString
            rec("SIGNAL_TYPES") = vbNullString
            rec("SOURCE_ROWS") = vbNullString
            rec("AREA") = vbNullString
            rec("SWITCHGROUP") = vbNullString
            rec("CLASS") = vbNullString
            groups.Add groupKey, rec
        Else
            Set rec = groups(groupKey)
        End If

        If colDeviceType > 0 Then deviceType = Trim$(CStr(ws.Cells(r, colDeviceType).Value2)) Else deviceType = vbNullString
        If colIOBlock > 0 Then ioBlock = Trim$(CStr(ws.Cells(r, colIOBlock).Value2)) Else ioBlock = vbNullString
        If colPort > 0 Then portText = Trim$(CStr(ws.Cells(r, colPort).Value2)) Else portText = vbNullString
        If colSignalName > 0 Then signalText = Trim$(CStr(ws.Cells(r, colSignalName).Value2)) Else signalText = vbNullString
        If colChannel > 0 Then channelText = Trim$(CStr(ws.Cells(r, colChannel).Value2)) Else channelText = vbNullString
        If colSignalType > 0 Then VFD_DWG_AppendUniqueCableDictText rec, "SIGNAL_TYPES", CStr(ws.Cells(r, colSignalType).Value2), " / "

        VFD_DWG_AppendUniqueCableDictText rec, "BLOCKS", blockID, " / "
        VFD_DWG_AppendUniqueCableDictText rec, "DEVICE_TYPES", deviceType, " / "
        VFD_DWG_AppendUniqueCableDictText rec, "IO_BLOCKS", ioBlock, " / "
        VFD_DWG_AppendUniqueCableDictText rec, "PORTS", portText, " / "
        VFD_DWG_AppendUniqueCableDictText rec, "SIGNALS", signalText, " / "
        VFD_DWG_AppendUniqueCableDictText rec, "CHANNELS", channelText, ", "
        VFD_DWG_AppendUniqueCableDictText rec, "SOURCE_ROWS", CStr(r), ","
        If colLocation > 0 And Len(rec("AREA")) = 0 Then rec("AREA") = Trim$(CStr(ws.Cells(r, colLocation).Value2))
        If colPWG > 0 And Len(rec("SWITCHGROUP")) = 0 Then rec("SWITCHGROUP") = Trim$(CStr(ws.Cells(r, colPWG).Value2))

        'Cable-family classifier priority:
        '  1) Explicit ONGEN IO/S or IO/D abbreviation.
        '  2) Semantic I/O evidence such as S_IN, S_OUT, EST, EPC, signal type,
        '     device text, signal name, and descriptions.
        'Part numbers / hardware model numbers are NEVER classification evidence.
        rowClass = VFD_DWG_IOCableRoleFromEvidence( _
                    blockID & "|" & deviceType & "|" & _
                    CStr(rec("SIGNAL_TYPES")) & "|" & deviceText & "|" & _
                    signalText & "|" & channelText)
        If rowClass = "SAF" Then
            rec("CLASS") = "SAF"                 'Safety wins for a deliberately shared physical cable.
        ElseIf rowClass = "IO" And Len(rec("CLASS")) = 0 Then
            rec("CLASS") = "IO"
        End If
NextSourceRow:
    Next r

    For Each dictionaryKey In groups.keys
        Set rec = groups(dictionaryKey)
        cableType = CStr(rec("CLASS"))
        If cableType = "SAF" Then
            categoryText = "Safety I/O cable"
            statusText = "REVIEW - VERIFY PHYSICAL CABLE/CORES"
        ElseIf cableType = "IO" Then
            categoryText = "Standard / non-safety I/O cable"
            statusText = "REVIEW - VERIFY PHYSICAL CABLE/CORES"
        Else
            cableType = "GEN"
            categoryText = "General / unclassified cable"
            statusText = "CHECK - I/O CLASSIFICATION EVIDENCE NOT FOUND"
        End If

        panel = CStr(rec("PANEL"))
        areaNumber = CStr(rec("AREA"))
        switchGroup = CStr(rec("SWITCHGROUP"))
        deviceText = CStr(rec("DEVICE"))
        packageText = panel
        If Len(packageText) = 0 And Len(areaNumber) > 0 Then packageText = "AREA-" & areaNumber
        If Len(packageText) = 0 Then packageText = "UNASSIGNED"

        cableKey = cableType & "|" & packageText & "|" & deviceText & "|" & CStr(rec("IDENTITY"))
        If VFD_DWG_RegisterCableKey(seen, cableKey) Then
            cableID = ONGEN_CableID_Get(cableKey, vbNullString, cableType)
            descriptionText = categoryText & " between " & deviceText & " and " & CStr(rec("BLOCKS"))
            VFD_DWG_WriteCableTagRow wsOut, outRow, Array( _
                cableID, cableType, categoryText, packageText, areaNumber, panel, switchGroup, _
                "TBD", "TBD", "TBD", deviceText, "FIELD TERMINALS - TBD", _
                CStr(rec("BLOCKS")) & IIf(Len(CStr(rec("IO_BLOCKS"))) > 0, " / " & CStr(rec("IO_BLOCKS")), vbNullString), _
                CStr(rec("PORTS")), "TBD", "TBD", vbNullString, vbNullString, deviceText, descriptionText, _
                "Signals: " & CStr(rec("SIGNALS")) & "; channels: " & CStr(rec("CHANNELS")) & _
                ". Cable family uses IO/S or IO/D first, then approved semantic I/O evidence. Part numbers are excluded. Verify physical cable grouping, core count, shield, and field terminals.", _
                ws.Name, CStr(rec("SOURCE_ROWS")), statusText, Now)
        End If
    Next dictionaryKey
End Sub

Private Sub VFD_DWG_AddVFDCableTags(ByVal wsOut As Worksheet, ByRef outRow As Long, _
                                    ByVal counters As Object, ByVal seen As Object)
    Dim ws As Worksheet, map As Object
    Dim lastRow As Long, r As Long
    Dim colSis As Long, colType As Long, colPanel As Long, colArea As Long, colSwitch As Long
    Dim colSequence As Long, colMotorPower As Long
    Dim sisText As String, typeText As String, panel As String, packageText As String
    Dim areaNumber As String, switchGroup As String, sisSequence As String, parsedSequence As String
    Dim motorPower As String, motorID As String, cableID As String, cableKey As String

    Set ws = VFD_DWG_GetSheet(SH_SOURCE)
    If ws Is Nothing Then Exit Sub
    Set map = VFD_DWG_HeaderMap(ws)
    colSis = VFD_DWG_CableHeaderColumn(map, Array("SIS_ELEMENT_NUMBER"))
    colType = VFD_DWG_CableHeaderColumn(map, Array("TYPE"))
    colPanel = VFD_DWG_CableHeaderColumn(map, Array("480V Panel", "PANEL", "PNL"))
    colArea = VFD_DWG_CableHeaderColumn(map, Array("AREA_NUMBER"))
    colSwitch = VFD_DWG_CableHeaderColumn(map, Array("SWITCHGROUP", "PWG"))
    colSequence = VFD_DWG_CableHeaderColumn(map, Array("SIS_SEQUENCE"))
    colMotorPower = VFD_DWG_CableHeaderColumn(map, Array("Motor Power (Main Drive)", "MOTOR POWER"))
    If colSis = 0 Then Exit Sub

    lastRow = VFD_DWG_LastDataRow(ws)
    For r = 2 To lastRow
        sisText = Trim$(CStr(ws.Cells(r, colSis).Value2))
        If colType > 0 Then typeText = Trim$(CStr(ws.Cells(r, colType).Value2)) Else typeText = vbNullString
        If Not VFD_DWG_IsVFDRecord(sisText, vbNullString, typeText) Then GoTo NextVFDRow
        If colPanel > 0 Then panel = Trim$(CStr(ws.Cells(r, colPanel).Value2)) Else panel = vbNullString
        If colArea > 0 Then areaNumber = Trim$(CStr(ws.Cells(r, colArea).Value2)) Else areaNumber = vbNullString
        If colSwitch > 0 Then switchGroup = Trim$(CStr(ws.Cells(r, colSwitch).Value2)) Else switchGroup = vbNullString
        If colSequence > 0 Then sisSequence = Trim$(CStr(ws.Cells(r, colSequence).Value2)) Else sisSequence = vbNullString
        If colMotorPower > 0 Then motorPower = Trim$(CStr(ws.Cells(r, colMotorPower).Value2)) Else motorPower = vbNullString
        If Len(areaNumber) = 0 Or Len(switchGroup) = 0 Or Len(sisSequence) = 0 Then
            VFD_DWG_ParseSISElement sisText, areaNumber, switchGroup, parsedSequence
            If Len(sisSequence) = 0 Then sisSequence = parsedSequence
        End If
        packageText = panel
        If Len(packageText) = 0 And Len(areaNumber) > 0 Then packageText = "AREA-" & areaNumber
        If Len(packageText) = 0 Then packageText = "UNASSIGNED"

        cableKey = "PWR|" & packageText & "|" & sisText
        If VFD_DWG_RegisterCableKey(seen, cableKey) Then
            cableID = ONGEN_CableID_Get(cableKey)
            VFD_DWG_WriteCableTagRow wsOut, outRow, Array( _
                cableID, "PWR", "AC power cable", packageText, areaNumber, panel, switchGroup, _
                "4C", "TBD", "TBD", panel & " 480VAC DISTRIBUTION", "FEEDER - TBD", _
                sisText, "L1/L2/L3/PE", "PWR GENERATED", "VFD GENERATED", vbNullString, vbNullString, _
                sisText, "480VAC feeder cable to " & sisText, _
                "Motor power: " & motorPower & ". Verify protective device, cable size, source terminal, length, and drawing sheet.", _
                ws.Name, CStr(r), "REVIEW - VERIFY FEEDER/SIZE/SHEET", Now)
        End If

        motorID = VFD_DWG_DeriveMotorID(sisText, sisSequence, areaNumber, switchGroup)
        cableKey = "MTR|" & packageText & "|" & sisText & "|" & motorID
        If VFD_DWG_RegisterCableKey(seen, cableKey) Then
            cableID = ONGEN_CableID_Get(cableKey)
            VFD_DWG_WriteCableTagRow wsOut, outRow, Array( _
                cableID, "MTR", "Motor power", packageText, areaNumber, panel, switchGroup, _
                "4C", "TBD", "TBD", sisText, "U/V/W/PE", motorID, "U/V/W/PE", _
                "VFD GENERATED", "FIELD MOTOR", vbNullString, vbNullString, sisText, _
                "Motor power cable from " & sisText & " to " & motorID, _
                "Motor power: " & motorPower & ". Motor ID is derived from the VFD SIS sequence; verify motor identity, cable size, shield, length, and destination drawing.", _
                ws.Name, CStr(r), "REVIEW - VERIFY MOTOR ID/SIZE/SHEET", Now)
        End If
NextVFDRow:
    Next r
End Sub

Private Sub VFD_DWG_Add24VCableTags(ByVal wsOut As Worksheet, ByRef outRow As Long, _
                                    ByVal counters As Object, ByVal seen As Object)
    Dim ws As Worksheet, psuByBus As Object, psuTermByBus As Object
    Dim lastRow As Long, r As Long, rr As Long
    Dim aText As String, bText As String, cText As String, header7 As String, currentBus As String
    Dim panel As String, packageText As String, deviceText As String, typeText As String, loadText As String
    Dim terminalIn As String, panelTerminal As String, insidePsuTerminal As String
    Dim psuText As String, areaNumber As String, switchGroup As String, sisSequence As String
    Dim cableID As String, cableKey As String, matchStatus As String, termList As String

    For Each ws In ThisWorkbook.Worksheets
        If VFD_DWG_IsGenerated24VSheet(ws) Then
            Set psuByBus = CreateObject("Scripting.Dictionary")
            psuByBus.CompareMode = vbTextCompare
            Set psuTermByBus = CreateObject("Scripting.Dictionary")
            psuTermByBus.CompareMode = vbTextCompare
            panel = VFD_DWG_PanelFrom24VSheet(ws.Name)
            packageText = panel
            If Len(packageText) = 0 Then packageText = "UNASSIGNED"
            currentBus = vbNullString
            lastRow = VFD_DWG_LastDataRow(ws)

            For r = 1 To lastRow
                aText = Trim$(CStr(ws.Cells(r, 1).Value2))
                bText = Trim$(CStr(ws.Cells(r, 2).Value2))
                cText = Trim$(CStr(ws.Cells(r, 3).Value2))

                If VFD_DWG_NormalizeHeader(aText) = VFD_DWG_NormalizeHeader("PWG") And _
                   VFD_DWG_NormalizeHeader(bText) = VFD_DWG_NormalizeHeader("Bus Power") And _
                   VFD_DWG_NormalizeHeader(cText) = VFD_DWG_NormalizeHeader("Power Supply") Then
                    psuByBus.RemoveAll
                    psuTermByBus.RemoveAll
                    currentBus = vbNullString
                    rr = r + 1
                    Do While rr <= lastRow
                        bText = UCase$(Trim$(CStr(ws.Cells(rr, 2).Value2)))
                        cText = Trim$(CStr(ws.Cells(rr, 3).Value2))
                        If Left$(bText, 4) <> "BUS-" Or Len(cText) = 0 Then Exit Do
                        psuByBus(bText) = cText
                        termList = vbNullString
                        VFD_DWG_AppendUniqueCableText termList, CStr(ws.Cells(rr, 5).Value2), " / "
                        VFD_DWG_AppendUniqueCableText termList, CStr(ws.Cells(rr, 6).Value2), " / "
                        VFD_DWG_AppendUniqueCableText termList, CStr(ws.Cells(rr, 7).Value2), " / "
                        VFD_DWG_AppendUniqueCableText termList, CStr(ws.Cells(rr, 8).Value2), " / "
                        psuTermByBus(bText) = termList
                        rr = rr + 1
                    Loop
                    GoTo Next24VRow
                End If

                If VFD_DWG_NormalizeHeader(aText) = VFD_DWG_NormalizeHeader("SIS_ELEMENT_NUMBER") Then
                    header7 = UCase$(Trim$(CStr(ws.Cells(r, 7).Value2)))
                    If InStr(1, header7, "BUS-1", vbTextCompare) > 0 Then
                        currentBus = "BUS-1"
                    ElseIf InStr(1, header7, "BUS-2", vbTextCompare) > 0 Then
                        currentBus = "BUS-2"
                    Else
                        currentBus = vbNullString
                    End If
                    GoTo Next24VRow
                End If

                If Len(currentBus) > 0 And Len(aText) > 0 And InStr(1, aText, "-", vbTextCompare) > 0 Then
                    deviceText = aText
                    typeText = Trim$(CStr(ws.Cells(r, 2).Value2))
                    If Len(typeText) = 0 Then GoTo Next24VRow
                    loadText = Trim$(CStr(ws.Cells(r, 3).Value2))
                    terminalIn = Trim$(CStr(ws.Cells(r, 5).Value2))
                    panelTerminal = Trim$(CStr(ws.Cells(r, 7).Value2))
                    insidePsuTerminal = Trim$(CStr(ws.Cells(r, 8).Value2))
                    If psuByBus.Exists(currentBus) Then psuText = CStr(psuByBus(currentBus)) Else psuText = "MISSING PSU"
                    If Len(insidePsuTerminal) = 0 And psuTermByBus.Exists(currentBus) Then insidePsuTerminal = CStr(psuTermByBus(currentBus))
                    VFD_DWG_ParseSISElement deviceText, areaNumber, switchGroup, sisSequence
                    cableKey = "DC|" & packageText & "|" & currentBus & "|" & psuText & "|" & deviceText & "|" & panelTerminal
                    If VFD_DWG_RegisterCableKey(seen, cableKey) Then
                        'Route 24VDC through the branch-aware helper. Calling the generic
                        'allocator here would incorrectly consume one WDC base per device.
                        cableID = ONGEN_ExportTag_DC( _
                            panel, currentBus, psuText, deviceText, panelTerminal, insidePsuTerminal)
                        If UCase$(psuText) = "MISSING PSU" Then
                            matchStatus = "ERROR - MISSING PSU"
                        Else
                            matchStatus = "REVIEW - VERIFY CABLE SIZE/ROUTING"
                        End If
                        VFD_DWG_WriteCableTagRow wsOut, outRow, Array( _
                            cableID, "DC", "24VDC multi-core", packageText, areaNumber, panel, switchGroup, _
                            "2C", "TBD", "TBD", psuText, insidePsuTerminal, deviceText, terminalIn, _
                            ws.Name, "FIELD DEVICE / DC", vbNullString, vbNullString, deviceText, _
                            "24VDC " & currentBus & " cable from " & psuText & " to " & deviceText, _
                            "Panel terminal: " & panelTerminal & "; load: " & loadText & ". Verify cable size, length, routing, and device terminal.", _
                            ws.Name, CStr(r), matchStatus, Now)
                    End If
                End If
Next24VRow:
            Next r
        End If
    Next ws
End Sub

Private Function VFD_DWG_CableHeaderColumn(ByVal map As Object, ByVal aliases As Variant) As Long
    Dim item As Variant, key As String
    If map Is Nothing Then Exit Function
    For Each item In aliases
        key = VFD_DWG_NormalizeHeader(CStr(item))
        If map.Exists(key) Then
            VFD_DWG_CableHeaderColumn = CLng(map(key))
            Exit Function
        End If
    Next item
End Function

Private Function VFD_DWG_NextCableID(ByVal counters As Object, ByVal packageText As String, _
                                     ByVal cableType As String) As String
    'Legacy compatibility only. New cable output calls ONGEN_CableID_Get with a
    'physical-cable key so the functional Option A ID remains stable across rebuilds.
    VFD_DWG_NextCableID = ONGEN_CableID_Get("LEGACY|" & packageText & "|" & cableType & "|" & CStr(Timer))
End Function

Private Function VFD_DWG_RegisterCableKey(ByVal seen As Object, ByVal cableKey As String) As Boolean
    If seen.Exists(cableKey) Then Exit Function
    seen.Add cableKey, True
    VFD_DWG_RegisterCableKey = True
End Function

Private Sub VFD_DWG_WriteCableTagRow(ByVal wsOut As Worksheet, ByRef outRow As Long, ByVal values As Variant)
    Dim i As Long
    For i = LBound(values) To UBound(values)
        wsOut.Cells(outRow, i + 1).Value2 = values(i)
    Next i
    outRow = outRow + 1
End Sub

Private Sub VFD_DWG_AppendUniqueCableText(ByRef listText As String, ByVal valueText As String, _
                                          Optional ByVal separatorText As String = " / ")
    Dim cleanValue As String, paddedList As String
    cleanValue = Trim$(valueText)
    If Len(cleanValue) = 0 Then Exit Sub
    paddedList = separatorText & listText & separatorText
    If InStr(1, paddedList, separatorText & cleanValue & separatorText, vbTextCompare) = 0 Then
        If Len(listText) > 0 Then listText = listText & separatorText
        listText = listText & cleanValue
    End If
End Sub

Private Sub VFD_DWG_AppendUniqueCableDictText(ByVal rec As Object, ByVal fieldName As String, _
                                              ByVal valueText As String, Optional ByVal separatorText As String = " / ")
    Dim cleanValue As String, currentText As String, paddedList As String
    cleanValue = Trim$(valueText)
    If Len(cleanValue) = 0 Then Exit Sub
    currentText = CStr(rec(fieldName))
    paddedList = separatorText & currentText & separatorText
    If InStr(1, paddedList, separatorText & cleanValue & separatorText, vbTextCompare) = 0 Then
        If Len(currentText) > 0 Then currentText = currentText & separatorText
        rec(fieldName) = currentText & cleanValue
    End If
End Sub

Private Function VFD_DWG_IOCableRoleFromEvidence(ByVal sourceText As String) As String
    Dim s As String
    s = UCase$(Trim$(sourceText))

    'Priority 1 - explicit ONGEN block abbreviation.
    If InStr(1, s, "IO/S", vbTextCompare) > 0 Then
        VFD_DWG_IOCableRoleFromEvidence = "SAF"
        Exit Function
    ElseIf InStr(1, s, "IO/D", vbTextCompare) > 0 Then
        VFD_DWG_IOCableRoleFromEvidence = "IO"
        Exit Function
    End If

    'Priority 2 - semantic safety evidence.
    'Do not add hardware catalog / part-number fields to sourceText.
    If InStr(1, s, "S_IN", vbTextCompare) > 0 Or _
       InStr(1, s, "S- IN", vbTextCompare) > 0 Or _
       InStr(1, s, "S OUT", vbTextCompare) > 0 Or _
       InStr(1, s, "S_OUT", vbTextCompare) > 0 Or _
       InStr(1, s, "SAFETY", vbTextCompare) > 0 Or _
       VFD_DWG_HasCableEvidenceToken(s, "EST") Or _
       VFD_DWG_HasCableEvidenceToken(s, "EPC") Then
        VFD_DWG_IOCableRoleFromEvidence = "SAF"
        Exit Function
    End If

    'Priority 3 - semantic standard-I/O evidence.
    If VFD_DWG_HasCableEvidenceToken(s, "DI") Or _
       VFD_DWG_HasCableEvidenceToken(s, "DO") Or _
       VFD_DWG_HasCableEvidenceToken(s, "AI") Or _
       VFD_DWG_HasCableEvidenceToken(s, "AO") Or _
       InStr(1, s, "DIGITAL INPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "DIGITAL OUTPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "ANALOG INPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "ANALOG OUTPUT", vbTextCompare) > 0 Or _
       InStr(1, s, "STANDARD I/O", vbTextCompare) > 0 Or _
       InStr(1, s, "STANDARD IO", vbTextCompare) > 0 Then
        VFD_DWG_IOCableRoleFromEvidence = "IO"
        Exit Function
    End If

    VFD_DWG_IOCableRoleFromEvidence = vbNullString
End Function

Private Function VFD_DWG_HasCableEvidenceToken(ByVal sourceText As String, _
                                                ByVal tokenText As String) As Boolean
    Dim s As String
    s = UCase$(sourceText)
    s = Replace(s, "-", " ")
    s = Replace(s, "_", " ")
    s = Replace(s, "/", " ")
    s = Replace(s, "\", " ")
    s = Replace(s, ".", " ")
    s = Replace(s, ",", " ")
    s = Replace(s, ":", " ")
    s = Replace(s, ";", " ")
    s = Replace(s, "(", " ")
    s = Replace(s, ")", " ")
    s = Replace(s, "[", " ")
    s = Replace(s, "]", " ")
    s = Replace(s, "|", " ")
    Do While InStr(1, s, "  ", vbBinaryCompare) > 0
        s = Replace(s, "  ", " ")
    Loop
    s = " " & Trim$(s) & " "
    VFD_DWG_HasCableEvidenceToken = (InStr(1, s, " " & UCase$(Trim$(tokenText)) & " ", vbBinaryCompare) > 0)
End Function


Private Function VFD_DWG_DeriveMotorID(ByVal sisText As String, ByVal sisSequence As String, _
                                       ByVal areaNumber As String, ByVal switchGroup As String) As String
    Dim baseText As String, p As Long
    baseText = Trim$(sisSequence)
    If Len(baseText) = 0 Then baseText = Trim$(sisText)
    p = InStr(1, UCase$(baseText), "-VFD", vbTextCompare)
    If p > 0 Then baseText = Left$(baseText, p - 1)
    p = InStrRev(UCase$(baseText), "-K")
    If p > 0 Then baseText = Left$(baseText, p - 1)
    If Len(areaNumber) > 0 And Len(switchGroup) > 0 And InStr(1, baseText, "-", vbTextCompare) = 0 Then
        VFD_DWG_DeriveMotorID = areaNumber & "-" & switchGroup & "-" & baseText & "-MTR"
    Else
        VFD_DWG_DeriveMotorID = baseText & "-MTR"
    End If
End Function

Private Function VFD_DWG_IsGenerated24VSheet(ByVal ws As Worksheet) As Boolean
    Dim upperName As String
    upperName = UCase$(Trim$(ws.Name))
    If Right$(upperName, 4) <> "_24V" Then Exit Function
    If upperName = UCase$("24v_Power Generator") Then Exit Function
    If InStr(1, upperName, "OVERLOAD", vbTextCompare) > 0 Then Exit Function
    If InStr(1, upperName, "NOT_GENERATED", vbTextCompare) > 0 Then Exit Function
    VFD_DWG_IsGenerated24VSheet = True
End Function

Private Function VFD_DWG_PanelFrom24VSheet(ByVal sheetName As String) As String
    Dim s As String
    s = Trim$(sheetName)
    If UCase$(Right$(s, 4)) = "_24V" Then s = Left$(s, Len(s) - 4)
    VFD_DWG_PanelFrom24VSheet = Trim$(s)
End Function

Private Function VFD_DWG_STODeviceKey(ByVal deviceText As String) As String
    'Normalizes SIS_SEQUENCE and IO_DEVICE_LIST[Device] for an exact physical-VFD match.
    Dim s As String, suffixText As String, p As Long

    s = UCase$(Trim$(deviceText))
    s = Replace(s, "_", "-")
    s = Replace(s, " ", vbNullString)

    p = InStrRev(s, "-K", -1, vbTextCompare)
    If p > 0 Then
        suffixText = mid$(s, p + 2)
        If Len(suffixText) > 0 And IsNumeric(suffixText) Then s = Left$(s, p - 1)
    End If

    VFD_DWG_STODeviceKey = s
End Function

Private Function VFD_DWG_STOChannelParts(ByVal channelText As String, _
                                         ByRef labelPrefix As String, _
                                         ByRef channelNumber As String) As Boolean
    'Converts Out1 or OUT 2 into prefix=Out and number=1/2.
    Dim s As String, i As Long, ch As String

    s = Trim$(channelText)
    labelPrefix = vbNullString
    channelNumber = vbNullString

    For i = 1 To Len(s)
        ch = mid$(s, i, 1)
        If ch Like "#" Then
            channelNumber = channelNumber & ch
        ElseIf ch <> " " And ch <> "-" And ch <> "_" Then
            labelPrefix = labelPrefix & ch
        End If
    Next i

    If Len(labelPrefix) = 0 Then labelPrefix = "Out"
    labelPrefix = UCase$(Left$(labelPrefix, 1)) & LCase$(mid$(labelPrefix, 2))
    VFD_DWG_STOChannelParts = (Len(channelNumber) > 0)
End Function

Private Function VFD_DWG_JoinDictionaryKeys(ByVal values As Object, _
                                             Optional ByVal separatorText As String = " / ") As String
    Dim key As Variant, result As String

    For Each key In values.keys
        If Len(result) > 0 Then result = result & separatorText
        result = result & CStr(values(key))
    Next key
    VFD_DWG_JoinDictionaryKeys = result
End Function

Private Function VFD_DWG_FormatSTOChannels(ByVal channels As Object) As String
    'Produces the requested readable form: Out 1 and 2.
    Dim key As Variant, prefixText As String, numberText As String
    Dim commonPrefix As String, numberList As String, formatted As String
    Dim samePrefix As Boolean, firstItem As Boolean

    firstItem = True
    samePrefix = True

    For Each key In channels.keys
        If VFD_DWG_STOChannelParts(CStr(channels(key)), prefixText, numberText) Then
            If firstItem Then
                commonPrefix = prefixText
                firstItem = False
            ElseIf StrComp(commonPrefix, prefixText, vbTextCompare) <> 0 Then
                samePrefix = False
            End If

            If Len(numberList) > 0 Then numberList = numberList & " and "
            numberList = numberList & numberText
        Else
            samePrefix = False
        End If
    Next key

    If Not firstItem And samePrefix Then
        VFD_DWG_FormatSTOChannels = commonPrefix & " " & numberList
        Exit Function
    End If

    For Each key In channels.keys
        If Len(formatted) > 0 Then formatted = formatted & " and "
        formatted = formatted & CStr(channels(key))
    Next key
    VFD_DWG_FormatSTOChannels = formatted
End Function

Private Function VFD_DWG_BackfillSTOCore() As Long
    'Authoritative STO source: IO_DEVICE_LIST.
    'Matching rule: VFD_480V_Generator[SIS_SEQUENCE] equals IO_DEVICE_LIST[Device]
    'after case, underscore, spaces, and trailing -K<number> normalization.
    Dim wsSource As Worksheet, wsIO As Worksheet
    Dim sourceMap As Object, ioMap As Object, ioIndex As Object, touched As Object
    Dim rowsForDevice As Collection, blockIDs As Object, ioBlocks As Object
    Dim channels As Object, ports As Object, sourceRows As Object
    Dim sourceLastRow As Long, ioLastRow As Long, sourceRow As Long, ioRow As Long
    Dim sisElement As String, sisSequence As String, areaNumber As String
    Dim switchGroup As String, parsedSequence As String, sourceKey As String
    Dim ioDevice As String, ioKey As String, channelText As String, typeText As String
    Dim deviceType As String, blockID As String, ioBlock As String, portText As String
    Dim candidate As Variant, panelText As String, locationText As String
    Dim sourcePanel As String, sourceArea As String, matchPanel As Boolean, matchArea As Boolean
    Dim blockText As String, ioBlockText As String, channelList As String
    Dim portList As String, sourceRowList As String, fromText As String
    Dim missingText As String, overwriteExisting As Boolean, updated As Boolean

    Set wsSource = VFD_DWG_GetSheet(SH_SOURCE)
    Set wsIO = VFD_DWG_GetSheet(SH_IO_DEVICE_LIST)
    If wsSource Is Nothing Or wsIO Is Nothing Then Exit Function
    If Not VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("VFD_STO_BACKFILL_ENABLED", "YES"))) Then Exit Function

    VFD_DWG_SetupSourceColumns
    Set sourceMap = VFD_DWG_HeaderMap(wsSource)
    Set ioMap = VFD_DWG_HeaderMap(wsIO)

    VFD_DWG_RequireHeaders sourceMap, Array("SIS_ELEMENT_NUMBER", "SIS_SEQUENCE")
    VFD_DWG_RequireHeaders ioMap, Array("DEVICE", "CHANNEL IO", "BLOCK ID")

    overwriteExisting = VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("VFD_STO_BACKFILL_OVERWRITE", "YES")))
    missingText = CStr(VFD_DWG_GetConfigValue("VFD_STO_MISSING_TEXT", "FROM- xxx"))

    Set ioIndex = CreateObject("Scripting.Dictionary")
    ioIndex.CompareMode = vbTextCompare
    ioLastRow = VFD_DWG_LastDataRow(wsIO)

    For ioRow = 2 To ioLastRow
        ioDevice = VFD_DWG_CellText(wsIO, ioRow, ioMap, "DEVICE")
        channelText = VFD_DWG_CellText(wsIO, ioRow, ioMap, "CHANNEL IO")
        typeText = UCase$(VFD_DWG_CellText(wsIO, ioRow, ioMap, "TYPE"))
        deviceType = UCase$(VFD_DWG_CellText(wsIO, ioRow, ioMap, "DEVICE TYPE"))
        ioKey = VFD_DWG_STODeviceKey(ioDevice)

        If Len(ioKey) > 0 And _
           (InStr(1, ioKey, "VFD", vbTextCompare) > 0 Or deviceType = "VFD") And _
           (UCase$(Left$(Replace(channelText, " ", vbNullString), 3)) = "OUT" Or _
            typeText = "S_DO" Or typeText = "DO") Then
            If Not ioIndex.Exists(ioKey) Then
                Set rowsForDevice = New Collection
                ioIndex.Add ioKey, rowsForDevice
            End If
            Set rowsForDevice = ioIndex(ioKey)
            rowsForDevice.Add ioRow
        End If
    Next ioRow

    Set touched = CreateObject("Scripting.Dictionary")
    touched.CompareMode = vbTextCompare
    sourceLastRow = VFD_DWG_LastDataRow(wsSource)

    For sourceRow = 2 To sourceLastRow
        sisElement = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "SIS_ELEMENT_NUMBER")
        sisSequence = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "SIS_SEQUENCE")
        If Len(sisSequence) = 0 Then
            VFD_DWG_ParseSISElement sisElement, areaNumber, switchGroup, parsedSequence
            sisSequence = parsedSequence
        End If
        sourceKey = VFD_DWG_STODeviceKey(sisSequence)
        sourcePanel = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("480V PANEL", "PANEL", "PNL"))
        sourceArea = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("AREA_NUMBER", "AREA NUMBER", "LOCATION"))

        Set blockIDs = CreateObject("Scripting.Dictionary")
        Set ioBlocks = CreateObject("Scripting.Dictionary")
        Set channels = CreateObject("Scripting.Dictionary")
        Set ports = CreateObject("Scripting.Dictionary")
        Set sourceRows = CreateObject("Scripting.Dictionary")
        blockIDs.CompareMode = vbTextCompare
        ioBlocks.CompareMode = vbTextCompare
        channels.CompareMode = vbTextCompare
        ports.CompareMode = vbTextCompare
        sourceRows.CompareMode = vbTextCompare

        If Len(sourceKey) > 0 And ioIndex.Exists(sourceKey) Then
            Set rowsForDevice = ioIndex(sourceKey)
            For Each candidate In rowsForDevice
                ioRow = CLng(candidate)
                panelText = VFD_DWG_CellText(wsIO, ioRow, ioMap, "PANEL")
                locationText = VFD_DWG_CellText(wsIO, ioRow, ioMap, "LOCATION")
                matchPanel = (Len(sourcePanel) = 0 Or Len(panelText) = 0 Or _
                              VFD_DWG_PanelIdentityKey(sourcePanel) = VFD_DWG_PanelIdentityKey(panelText))
                matchArea = (Len(sourceArea) = 0 Or Len(locationText) = 0 Or _
                             StrComp(Trim$(sourceArea), Trim$(locationText), vbTextCompare) = 0)

                If matchPanel And matchArea Then
                    blockID = VFD_DWG_CellText(wsIO, ioRow, ioMap, "BLOCK ID")
                    ioBlock = VFD_DWG_CellText(wsIO, ioRow, ioMap, "IO BLOCK")
                    channelText = VFD_DWG_CellText(wsIO, ioRow, ioMap, "CHANNEL IO")
                    portText = VFD_DWG_CellText(wsIO, ioRow, ioMap, "PORT LOCATION")

                    If Len(blockID) > 0 And Not blockIDs.Exists(UCase$(blockID)) Then blockIDs.Add UCase$(blockID), blockID
                    If Len(ioBlock) > 0 And Not ioBlocks.Exists(UCase$(ioBlock)) Then ioBlocks.Add UCase$(ioBlock), ioBlock
                    If Len(channelText) > 0 And Not channels.Exists(UCase$(channelText)) Then channels.Add UCase$(channelText), channelText
                    If Len(portText) > 0 And Not ports.Exists(UCase$(portText)) Then ports.Add UCase$(portText), portText
                    If Not sourceRows.Exists(CStr(ioRow)) Then sourceRows.Add CStr(ioRow), CStr(ioRow)
                End If
            Next candidate
        End If

        blockText = VFD_DWG_JoinDictionaryKeys(blockIDs)
        ioBlockText = VFD_DWG_JoinDictionaryKeys(ioBlocks)
        channelList = VFD_DWG_FormatSTOChannels(channels)
        portList = VFD_DWG_JoinDictionaryKeys(ports)
        sourceRowList = VFD_DWG_JoinDictionaryKeys(sourceRows, ",")

        If Len(blockText) > 0 Then
            fromText = "FROM- " & blockText
            If Len(channelList) > 0 Then fromText = fromText & " " & channelList
        Else
            fromText = missingText
        End If

        updated = False
        If overwriteExisting Then
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_SOURCE_SHEET", vbNullString
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_SOURCE_ROWS", vbNullString
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_BLOCK_ID", vbNullString
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_IO_BLOCK", vbNullString
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_CHANNEL_IO", vbNullString
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_PORT_LOCATION", vbNullString
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_FROM_TEXT", vbNullString
            VFD_DWG_PutCell wsSource, sourceRow, sourceMap, "STO_MATCH_STATUS", vbNullString
        End If
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_SOURCE_SHEET", SH_IO_DEVICE_LIST, overwriteExisting) Then updated = True
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_SOURCE_ROWS", sourceRowList, overwriteExisting) Then updated = True
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_BLOCK_ID", blockText, overwriteExisting) Then updated = True
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_IO_BLOCK", ioBlockText, overwriteExisting) Then updated = True
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_CHANNEL_IO", channelList, overwriteExisting) Then updated = True
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_PORT_LOCATION", portList, overwriteExisting) Then updated = True
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_FROM_TEXT", fromText, True) Then updated = True
        If VFD_DWG_SetSourceIfAllowed(wsSource, sourceRow, sourceMap, "STO_MATCH_STATUS", IIf(Len(blockText) > 0, "MATCHED", "MISSING"), True) Then updated = True

        If updated And Not touched.Exists(CStr(sourceRow)) Then touched.Add CStr(sourceRow), True
    Next sourceRow

    VFD_DWG_BackfillSTOCore = touched.count
End Function

'====================================================================================
' ONE-TO-MANY QUEUE BUILDER
'====================================================================================

Private Sub VFD_DWG_RefreshQueueCore(ByVal ShowMessage As Boolean, ByVal preserveExisting As Boolean)
    Dim wsSource As Worksheet, wsPlan As Worksheet, wsQueue As Worksheet, wsCircuits As Worksheet
    Dim sourceMap As Object, planMap As Object, queueMap As Object, circuitMap As Object
    Dim existingExact As Object, existingLegacy As Object, legacyUsed As Object
    Dim sectionCounters As Object, sourceGroups As Object, panelGroups As Object
    Dim uniqueSource As Object
    Dim groupOrder As Collection, panelOrder As Collection, bucket As Collection, rowsOut As Collection
    Dim sourceLastRow As Long, sourceRow As Long, sourceIndex As Long
    Dim queueLastCol As Long, queueLastRow As Long
    Dim planRows As Variant, planRow As Variant, groupKey As Variant, panelKey As String
    Dim rowData As Variant, oldData As Variant
    Dim isLegacy As Boolean
    Dim firstRow As Long, leftRow As Long, rightRow As Long
    Dim groupPosition As Long, groupPageIndex As Long, maxPerSheet As Long
    Dim leftSis As String, leftSeq As String, leftArea As String, leftSwitch As String
    Dim leftType As String, leftPanel As String
    Dim rightSis As String, rightSeq As String, rightArea As String, rightSwitch As String
    Dim rightType As String, rightPanel As String
    Dim planID As String, pageCode As String, pageOrder As Long
    Dim parentID As String, drawingID As String, outputName As String
    Dim seedID As String, circuitID As String, sheetPrefix As String, sheetNumber As String
    Dim titleTemplate As String, titleText As String, descTemplate As String, descriptionText As String
    Dim exactKey As String, legacyKey As String, counterKey As String
    Dim leftX As Variant, leftY As Variant, leftZ As Variant
    Dim rightX As Variant, rightY As Variant, rightZ As Variant
    Dim rotationValue As Variant, scaleValue As Variant
    Dim outputArray() As Variant, i As Long, c As Long
    Dim sourceKey As String, duplicateSourceRows As Long
    Dim pwrJobs As Long, ioJobs As Long, mpwrJobs As Long, otherJobs As Long

    Set wsSource = VFD_DWG_GetSheet(SH_SOURCE)
    If wsSource Is Nothing Then
        Err.Raise vbObjectError + 710, "VFD_DWG_RefreshQueueCore", _
                  "Required source worksheet not found: " & SH_SOURCE & ". Run Step 08 first."
    End If

    Set wsPlan = VFD_DWG_GetOrCreateSheet(SH_SHEET_PLAN)
    Set wsQueue = VFD_DWG_GetOrCreateSheet(SH_QUEUE)
    Set wsCircuits = VFD_DWG_GetOrCreateSheet(SH_CIRCUITS)
    Set sourceMap = VFD_DWG_HeaderMap(wsSource)
    Set planMap = VFD_DWG_HeaderMap(wsPlan)
    Set queueMap = VFD_DWG_HeaderMap(wsQueue)
    Set circuitMap = VFD_DWG_HeaderMap(wsCircuits)

    VFD_DWG_RequireHeaders sourceMap, Array("SIS_ELEMENT_NUMBER", "TYPE")
    VFD_DWG_RequireHeaders planMap, Array("ENABLED", "PLAN_ID", "TYPE_MATCH", "PAGE_CODE", "PAGE_ORDER")
    VFD_DWG_RequireHeaders circuitMap, Array("CIRCUIT_ID", "INSERT_X", "INSERT_Y", "INSERT_Z", "ROTATION_DEG", "SCALE")

    queueLastCol = VFD_DWG_LastDataCol(wsQueue)
    If queueLastCol < 1 Then Err.Raise vbObjectError + 711, , "VFD_DWG_QUEUE has no headers."

    Set existingExact = CreateObject("Scripting.Dictionary")
    Set existingLegacy = CreateObject("Scripting.Dictionary")
    Set legacyUsed = CreateObject("Scripting.Dictionary")
    existingExact.CompareMode = vbTextCompare
    existingLegacy.CompareMode = vbTextCompare
    legacyUsed.CompareMode = vbTextCompare

    If preserveExisting Then
        VFD_DWG_CacheExistingQueue wsQueue, queueMap, queueLastCol, existingExact, existingLegacy
    End If

    Set rowsOut = New Collection
    Set uniqueSource = CreateObject("Scripting.Dictionary")
    uniqueSource.CompareMode = vbTextCompare
    Set sectionCounters = CreateObject("Scripting.Dictionary")
    sectionCounters.CompareMode = vbTextCompare
    Set sourceGroups = CreateObject("Scripting.Dictionary")
    sourceGroups.CompareMode = vbTextCompare
    Set panelGroups = CreateObject("Scripting.Dictionary")
    panelGroups.CompareMode = vbTextCompare
    Set groupOrder = New Collection
    Set panelOrder = New Collection

    sourceLastRow = VFD_DWG_LastDataRow(wsSource)
    sourceIndex = 0

    For sourceRow = 2 To sourceLastRow
        leftSis = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "SIS_ELEMENT_NUMBER")
        sourceKey = VFD_DWG_SourceIdentityKey(leftSis)

        If Len(sourceKey) > 0 Then
            If uniqueSource.Exists(sourceKey) Then
                duplicateSourceRows = duplicateSourceRows + 1
            Else
                uniqueSource.Add sourceKey, sourceRow
                sourceIndex = sourceIndex + 1
                leftType = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "TYPE")
                leftPanel = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("480V PANEL", "PANEL", "PNL"))
                VFD_DWG_ParseSISElement leftSis, leftArea, leftSwitch, leftSeq
                If Len(VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("AREA_NUMBER", "AREA NUMBER", "LOCATION"))) > 0 Then _
                    leftArea = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("AREA_NUMBER", "AREA NUMBER", "LOCATION"))
                If Len(VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))) > 0 Then _
                    leftSwitch = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))

                groupKey = UCase$(Trim$(leftArea) & "|" & Trim$(leftPanel) & "|" & Trim$(leftSwitch) & "|" & Trim$(leftType))
                If Not sourceGroups.Exists(CStr(groupKey)) Then
                    Set bucket = New Collection
                    sourceGroups.Add CStr(groupKey), bucket
                    groupOrder.Add CStr(groupKey)
                End If
                Set bucket = sourceGroups(CStr(groupKey))
                bucket.Add sourceRow

                panelKey = UCase$(Trim$(leftArea) & "|" & Trim$(leftPanel))
                If Len(Trim$(leftPanel)) > 0 And Not panelGroups.Exists(panelKey) Then
                    panelGroups.Add panelKey, sourceRow
                    panelOrder.Add panelKey
                End If
            End If
        End If
    Next sourceRow

    Set panelOrder = VFD_DWG_SortedKeyCollection(panelOrder)
    Set groupOrder = VFD_DWG_SortedKeyCollection(groupOrder)

    VFD_DWG_AppendPanelMPWRRows wsSource, sourceMap, queueMap, queueLastCol, rowsOut, _
                                sectionCounters, panelOrder, panelGroups, preserveExisting, _
                                existingExact, existingLegacy, legacyUsed

    For Each groupKey In groupOrder
        Set bucket = sourceGroups(CStr(groupKey))
        Set bucket = VFD_DWG_UniqueBucketRows(bucket, wsSource, sourceMap)
        firstRow = CLng(bucket(1))
        leftType = VFD_DWG_CellText(wsSource, firstRow, sourceMap, "TYPE")
        planRows = VFD_DWG_MatchingPlanRows(wsPlan, planMap, leftType)
        If IsEmpty(planRows) Then
            Err.Raise vbObjectError + 712, "VFD_DWG_RefreshQueueCore", _
                      "No enabled VFD_DWG_SHEET_PLAN row matches TYPE '" & leftType & "'."
        End If

        For Each planRow In planRows
            planID = VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "PLAN_ID")
            pageCode = VFD_DWG_NormalizePageCodeValue( _
                           VFD_DWG_SafeID(VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "PAGE_CODE")))
            If Len(pageCode) = 0 Then pageCode = "MAIN"
            pageOrder = CLng(val(VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "PAGE_ORDER")))
            maxPerSheet = CLng(val(VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "MAX_DEVICES_PER_SHEET")))
            If maxPerSheet < 1 Then maxPerSheet = 1
            If maxPerSheet > 2 Then maxPerSheet = 2

            For groupPosition = 1 To bucket.count Step maxPerSheet
                leftRow = CLng(bucket(groupPosition))
                rightRow = 0
                If maxPerSheet >= 2 And groupPosition + 1 <= bucket.count Then rightRow = CLng(bucket(groupPosition + 1))

                leftSis = vbNullString: leftSeq = vbNullString: leftArea = vbNullString
                leftSwitch = vbNullString: leftType = vbNullString: leftPanel = vbNullString
                rightSis = vbNullString: rightSeq = vbNullString: rightArea = vbNullString
                rightSwitch = vbNullString: rightType = vbNullString: rightPanel = vbNullString

                seedID = VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "SEED_ID")
                If Len(seedID) = 0 Then seedID = CStr(VFD_DWG_GetConfigValue("DEFAULT_SEED_ID", "VFD_STANDARD"))
                circuitID = VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "PRIMARY_CIRCUIT_ID")
                If Len(circuitID) = 0 Then circuitID = CStr(VFD_DWG_GetConfigValue("DEFAULT_CIRCUIT_ID", "MOVIFLEX_IO"))

                ReDim rowData(1 To queueLastCol)
                VFD_DWG_PopulateQueueSlot wsSource, leftRow, sourceMap, rowData, queueMap, vbNullString, circuitID, _
                                          leftSis, leftSeq, leftArea, leftSwitch, leftType, leftPanel
                If rightRow > 0 Then
                    VFD_DWG_PopulateQueueSlot wsSource, rightRow, sourceMap, rowData, queueMap, "RIGHT_", circuitID, _
                                              rightSis, rightSeq, rightArea, rightSwitch, rightType, rightPanel

                    'Hard stop for the V20.7 queue defect that copied the LEFT
                    'device into RIGHT_* while leaving RIGHT_SOURCE_ROW different.
                    If VFD_DWG_SourceIdentityKey(leftSis) = VFD_DWG_SourceIdentityKey(rightSis) Then
                        Err.Raise vbObjectError + 713, "VFD_DWG_RefreshQueueCore", _
                                  "Invalid two-device pair. LEFT and RIGHT resolve to the same VFD: " & leftSis & _
                                  " (source rows " & CStr(leftRow) & " and " & CStr(rightRow) & ")."
                    End If

                    If StrComp(Trim$(leftSwitch), Trim$(rightSwitch), vbTextCompare) <> 0 Then
                        Err.Raise vbObjectError + 714, "VFD_DWG_RefreshQueueCore", _
                                  "Invalid two-device pair. VFDs on one sheet must have the same SwitchGroup." & vbCrLf & _
                                  "LEFT: " & leftSis & " / SwitchGroup " & leftSwitch & vbCrLf & _
                                  "RIGHT: " & rightSis & " / SwitchGroup " & rightSwitch
                    End If
                End If

                groupPageIndex = ((groupPosition - 1) \ maxPerSheet) + 1
                parentID = "VFD-" & VFD_DWG_SafeID(leftArea & "-" & leftPanel & "-" & leftSwitch) & "-" & Format$(groupPageIndex, "000")
                drawingID = parentID & "-" & pageCode

                sheetPrefix = VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "SHEET_PREFIX")
                If Len(sheetPrefix) = 0 Then sheetPrefix = pageCode
                counterKey = UCase$(Trim$(leftArea) & "|" & Trim$(sheetPrefix))
                If Not sectionCounters.Exists(counterKey) Then sectionCounters.Add counterKey, 0
                sectionCounters(counterKey) = CLng(sectionCounters(counterKey)) + 1
                sheetNumber = sheetPrefix & "-" & Format$(CLng(sectionCounters(counterKey)), "000")
                outputName = VFD_DWG_SafeFileName(sheetNumber & ".dwg")

                VFD_DWG_ResolvePrimaryCircuitCoordinates wsPlan, CLng(planRow), planMap, _
                                                        wsCircuits, circuitMap, circuitID, _
                                                        leftX, leftY, leftZ, rightX, rightY, rightZ, _
                                                        rotationValue, scaleValue

                titleTemplate = VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "DRAWING_TITLE_TEMPLATE")
                If Len(titleTemplate) = 0 Then
                    If UCase$(pageCode) = "PWR" Then
                        titleTemplate = "PWR - Drawing ONLY"
                    Else
                        titleTemplate = "{SIS_ELEMENT_NUMBER} - " & VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "TITLE_SUFFIX")
                    End If
                End If
                titleText = VFD_DWG_ExpandTokens(titleTemplate, leftSis, leftSeq, leftArea, leftSwitch, _
                                                  leftType, leftPanel, planID, pageCode, rightSis)

                descTemplate = VFD_DWG_CellText(wsPlan, CLng(planRow), planMap, "DESCRIPTION_TEMPLATE")
                If Len(descTemplate) = 0 Then descTemplate = "{TYPE} {PAGE_CODE} circuit for {PANEL}"
                descriptionText = VFD_DWG_ExpandTokens(descTemplate, leftSis, leftSeq, leftArea, leftSwitch, _
                                                       leftType, leftPanel, planID, pageCode, rightSis)

                VFD_DWG_SetRowValue rowData, queueMap, "ENABLED", "YES"
                VFD_DWG_SetRowValue rowData, queueMap, "DRAWING_ID", drawingID
                VFD_DWG_SetRowValue rowData, queueMap, "PARENT_DRAWING_ID", parentID
                VFD_DWG_SetRowValue rowData, queueMap, "PLAN_ID", planID
                VFD_DWG_SetRowValue rowData, queueMap, "PAGE_CODE", pageCode
                VFD_DWG_SetRowValue rowData, queueMap, "PAGE_ORDER", pageOrder
                VFD_DWG_SetRowValue rowData, queueMap, "SOURCE_SHEET", SH_SOURCE
                VFD_DWG_SetRowValue rowData, queueMap, "OUTPUT_DWG_NAME", outputName
                VFD_DWG_SetRowValue rowData, queueMap, "SEED_ID", seedID
                VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_INSERT_X", leftX
                VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_INSERT_Y", leftY
                VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_INSERT_Z", leftZ
                VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_ROTATION_DEG", rotationValue
                VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_SCALE", scaleValue
                If rightRow > 0 Then
                    VFD_DWG_SetRowValue rowData, queueMap, "RIGHT_CIRCUIT_INSERT_X", rightX
                    VFD_DWG_SetRowValue rowData, queueMap, "RIGHT_CIRCUIT_INSERT_Y", rightY
                    VFD_DWG_SetRowValue rowData, queueMap, "RIGHT_CIRCUIT_INSERT_Z", rightZ
                    VFD_DWG_SetRowValue rowData, queueMap, "RIGHT_CIRCUIT_ROTATION_DEG", rotationValue
                    VFD_DWG_SetRowValue rowData, queueMap, "RIGHT_CIRCUIT_SCALE", scaleValue
                End If
                VFD_DWG_SetRowValue rowData, queueMap, "DEVICE_COUNT", IIf(rightRow > 0, 2, 1)
                VFD_DWG_SetRowValue rowData, queueMap, "DEVICE_FOLDER_NAME", vbNullString
                VFD_DWG_SetRowValue rowData, queueMap, "SHEET_NUMBER", sheetNumber
                VFD_DWG_SetRowValue rowData, queueMap, "DRAWING_TITLE", titleText
                VFD_DWG_SetRowValue rowData, queueMap, "DRAWING_DESCRIPTION", descriptionText

                exactKey = VFD_DWG_QueueKey(leftSis, rightSis, planID)
                legacyKey = UCase$(leftSis & "|" & circuitID)
                isLegacy = False
                oldData = Empty

                If preserveExisting And existingExact.Exists(exactKey) Then
                    oldData = existingExact(exactKey)
                ElseIf preserveExisting And existingLegacy.Exists(legacyKey) And Not legacyUsed.Exists(legacyKey) Then
                    oldData = existingLegacy(legacyKey)
                    legacyUsed.Add legacyKey, True
                    isLegacy = True
                End If

                If Not IsEmpty(oldData) Then
                    VFD_DWG_ApplyExistingOverrides rowData, oldData, queueMap, isLegacy
                End If

                rowsOut.Add rowData
            Next groupPosition
        Next planRow
    Next groupKey

    queueLastRow = VFD_DWG_LastDataRow(wsQueue)
    If queueLastRow >= 2 Then wsQueue.Range(wsQueue.Cells(2, 1), wsQueue.Cells(queueLastRow, queueLastCol)).ClearContents

    If rowsOut.count > 0 Then
        ReDim outputArray(1 To rowsOut.count, 1 To queueLastCol)
        For i = 1 To rowsOut.count
            rowData = rowsOut(i)
            Select Case UCase$(VFD_DWG_RowArrayText(rowData, queueMap, "PAGE_CODE"))
                Case "PWR": pwrJobs = pwrJobs + 1
                Case "IO": ioJobs = ioJobs + 1
                Case "MPWR": mpwrJobs = mpwrJobs + 1
                Case Else: otherJobs = otherJobs + 1
            End Select
            For c = 1 To queueLastCol
                outputArray(i, c) = rowData(c)
            Next c
        Next i
        wsQueue.Cells(2, 1).Resize(rowsOut.count, queueLastCol).Value2 = outputArray
    End If

    'C04.3 permanent workbook-to-LISP bridge:
    '  1) canonicalize legacy VFD-IO/I/O page values to IO;
    '  2) synchronize LP_BUS_IN / LP_BUS_OUT from final queue data.
    Call VFD_DWG_NormalizeQueuePageCodes(wsQueue)
    Call VFD_DWG_SyncLPBusFieldsFromQueue(wsQueue)

    VFD_DWG_FormatQueue wsQueue
    VFD_DWG_AppendLog "VFD_DWG_Refresh_Queue", "OK", _
        CStr(sourceIndex) & " unique VFD device(s); " & CStr(duplicateSourceRows) & _
        " duplicate source row(s) ignored. Drawing jobs: " & _
        CStr(pwrJobs) & " PWR, " & CStr(ioJobs) & " IO, " & CStr(mpwrJobs) & " MPWR, " & _
        CStr(otherJobs) & " other."

    If ShowMessage Then
        wsQueue.Activate
        MsgBox "Unique VFD devices: " & CStr(sourceIndex) & vbCrLf & _
               "Duplicate source rows ignored: " & CStr(duplicateSourceRows) & vbCrLf & vbCrLf & _
               "Drawing jobs created:" & vbCrLf & _
               "  PWR: " & CStr(pwrJobs) & vbCrLf & _
               "  IO: " & CStr(ioJobs) & vbCrLf & _
               "  MPWR: " & CStr(mpwrJobs) & vbCrLf & _
               "  Other: " & CStr(otherJobs) & vbCrLf & vbCrLf & _
               "PWR/IO jobs are drawing sheets, not additional VFD devices. " & _
               "All numbering restarts for each Area_Number.", _
               vbInformation, "ONGEN VFD Queue"
    End If
End Sub

Private Function VFD_DWG_SortedKeyCollection(ByVal sourceKeys As Collection) As Collection
    Dim arr() As String, i As Long, j As Long, temp As String
    Dim result As New Collection
    If sourceKeys Is Nothing Then
        Set VFD_DWG_SortedKeyCollection = result
        Exit Function
    End If
    If sourceKeys.count = 0 Then
        Set VFD_DWG_SortedKeyCollection = result
        Exit Function
    End If
    ReDim arr(1 To sourceKeys.count)
    For i = 1 To sourceKeys.count
        arr(i) = CStr(sourceKeys(i))
    Next i
    For i = LBound(arr) To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If StrComp(arr(j), arr(i), vbTextCompare) < 0 Then
                temp = arr(i): arr(i) = arr(j): arr(j) = temp
            End If
        Next j
    Next i
    For i = LBound(arr) To UBound(arr)
        result.Add arr(i)
    Next i
    Set VFD_DWG_SortedKeyCollection = result
End Function

Private Sub VFD_DWG_AppendPanelMPWRRows(ByVal wsSource As Worksheet, ByVal sourceMap As Object, _
                                        ByVal queueMap As Object, ByVal queueLastCol As Long, _
                                        ByVal rowsOut As Collection, ByVal sectionCounters As Object, _
                                        ByVal panelOrder As Collection, ByVal panelGroups As Object, _
                                        ByVal preserveExisting As Boolean, ByVal existingExact As Object, _
                                        ByVal existingLegacy As Object, ByVal legacyUsed As Object)
    Dim panelKey As Variant, sourceRow As Long, pageIndex As Long, pageCount As Long
    Dim sourceSis As String, areaNumber As String, switchGroup As String, sourceSequence As String
    Dim panel As String, panelElement As String, planID As String, seedID As String, circuitID As String
    Dim rowData As Variant, sheetNumber As String, outputName As String, counterKey As String
    Dim parentID As String, drawingID As String, titleText As String, descriptionText As String
    Dim titleTemplate As String, descTemplate As String, folderSuffix As String
    Dim insertX As Variant, insertY As Variant, insertZ As Variant, rotationValue As Variant, scaleValue As Variant
    Dim exactKey As String, legacyKey As String, oldData As Variant, isLegacy As Boolean

    If Not VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue("PANEL_MPWR_ENABLED", "YES"))) Then Exit Sub
    pageCount = CLng(val(CStr(VFD_DWG_GetConfigValue("PANEL_MPWR_SHEETS_PER_PANEL", 2))))
    If pageCount < 1 Then pageCount = 2
    If pageCount > 10 Then pageCount = 10

    For Each panelKey In panelOrder
        sourceRow = CLng(panelGroups(CStr(panelKey)))
        sourceSis = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "SIS_ELEMENT_NUMBER")
        panel = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("480V PANEL", "PANEL", "PNL"))
        VFD_DWG_ParseSISElement sourceSis, areaNumber, switchGroup, sourceSequence
        If Len(VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("AREA_NUMBER", "AREA NUMBER", "LOCATION"))) > 0 Then _
            areaNumber = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("AREA_NUMBER", "AREA NUMBER", "LOCATION"))
        panelElement = Trim$(panel) & " PANEL"
        parentID = "MPWR-" & VFD_DWG_SafeID(areaNumber & "-" & panel)
        folderSuffix = CStr(VFD_DWG_GetConfigValue("PANEL_MPWR_DEVICE_FOLDER_SUFFIX", "PANEL POWER"))

        For pageIndex = 1 To pageCount
            ReDim rowData(1 To queueLastCol)
            planID = "PANEL_MPWR_" & CStr(pageIndex)
            seedID = CStr(VFD_DWG_GetConfigValue("PANEL_MPWR_SEED_ID", "MAIN_PWR"))
            circuitID = CStr(VFD_DWG_GetConfigValue("PANEL_MPWR_CIRCUIT_ID_" & CStr(pageIndex), _
                                                    VFD_DWG_GetConfigValue("PANEL_MPWR_CIRCUIT_ID_1", "MAIN_PWR_6")))
            insertX = VFD_DWG_GetConfigValue("PANEL_MPWR_INSERT_X_" & CStr(pageIndex), 3)
            insertY = VFD_DWG_GetConfigValue("PANEL_MPWR_INSERT_Y_" & CStr(pageIndex), 20)
            insertZ = VFD_DWG_GetConfigValue("PANEL_MPWR_INSERT_Z_" & CStr(pageIndex), 0)
            rotationValue = VFD_DWG_GetConfigValue("PANEL_MPWR_ROTATION_DEG_" & CStr(pageIndex), 0)
            scaleValue = VFD_DWG_GetConfigValue("PANEL_MPWR_SCALE_" & CStr(pageIndex), 1)

            counterKey = UCase$(Trim$(areaNumber) & "|MPWR")
            If Not sectionCounters.Exists(counterKey) Then sectionCounters.Add counterKey, 0
            sectionCounters(counterKey) = CLng(sectionCounters(counterKey)) + 1
            sheetNumber = "MPWR-" & Format$(CLng(sectionCounters(counterKey)), "000")
            outputName = VFD_DWG_SafeFileName(sheetNumber & ".dwg")
            drawingID = parentID & "-" & Format$(pageIndex, "00")

            titleTemplate = CStr(VFD_DWG_GetConfigValue("PANEL_MPWR_TITLE_" & CStr(pageIndex), _
                                                       IIf(pageIndex = 1, "PANEL INCOMING POWER", "PANEL POWER DISTRIBUTION")))
            descTemplate = CStr(VFD_DWG_GetConfigValue("PANEL_MPWR_DESCRIPTION_" & CStr(pageIndex), _
                                                      IIf(pageIndex = 1, "Main incoming power for {PANEL}", "Panel power distribution for {PANEL}")))
            titleText = VFD_DWG_ExpandTokens(titleTemplate, panelElement, panel, areaNumber, vbNullString, _
                                              "PNL", panel, planID, "MPWR", vbNullString)
            descriptionText = VFD_DWG_ExpandTokens(descTemplate, panelElement, panel, areaNumber, vbNullString, _
                                                    "PNL", panel, planID, "MPWR", vbNullString)

            VFD_DWG_SetRowValue rowData, queueMap, "ENABLED", "YES"
            VFD_DWG_SetRowValue rowData, queueMap, "DRAWING_ID", drawingID
            VFD_DWG_SetRowValue rowData, queueMap, "PARENT_DRAWING_ID", parentID
            VFD_DWG_SetRowValue rowData, queueMap, "PLAN_ID", planID
            VFD_DWG_SetRowValue rowData, queueMap, "PAGE_CODE", "MPWR"
            VFD_DWG_SetRowValue rowData, queueMap, "PAGE_ORDER", pageIndex - 2
            VFD_DWG_SetRowValue rowData, queueMap, "SOURCE_SHEET", "PANEL POWERGROUP"
            VFD_DWG_SetRowValue rowData, queueMap, "SOURCE_ROW", sourceRow
            VFD_DWG_SetRowValue rowData, queueMap, "OUTPUT_DWG_NAME", outputName
            VFD_DWG_SetRowValue rowData, queueMap, "SEED_ID", seedID
            VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_ID", circuitID
            VFD_DWG_SetRowValue rowData, queueMap, "SIS_ELEMENT_NUMBER", panelElement
            VFD_DWG_SetRowValue rowData, queueMap, "SIS_SEQUENCE", panel
            VFD_DWG_SetRowValue rowData, queueMap, "AREA_NUMBER", areaNumber
            VFD_DWG_SetRowValue rowData, queueMap, "SWITCHGROUP", vbNullString
            VFD_DWG_SetRowValue rowData, queueMap, "TYPE", "PNL"
            VFD_DWG_SetRowValue rowData, queueMap, "PANEL", panel
            VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_INSERT_X", insertX
            VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_INSERT_Y", insertY
            VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_INSERT_Z", insertZ
            VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_ROTATION_DEG", rotationValue
            VFD_DWG_SetRowValue rowData, queueMap, "CIRCUIT_SCALE", scaleValue
            VFD_DWG_SetRowValue rowData, queueMap, "DEVICE_COUNT", 1
            VFD_DWG_SetRowValue rowData, queueMap, "DEVICE_FOLDER_NAME", vbNullString
            VFD_DWG_SetRowValue rowData, queueMap, "SHEET_NUMBER", sheetNumber
            VFD_DWG_SetRowValue rowData, queueMap, "DRAWING_TITLE", titleText
            VFD_DWG_SetRowValue rowData, queueMap, "DRAWING_DESCRIPTION", descriptionText
            VFD_DWG_SetRowValue rowData, queueMap, "STATUS", "READY"

            exactKey = VFD_DWG_QueueKey(panelElement, vbNullString, planID)
            legacyKey = UCase$(panelElement & "|" & circuitID)
            oldData = Empty: isLegacy = False
            If preserveExisting And existingExact.Exists(exactKey) Then
                oldData = existingExact(exactKey)
            ElseIf preserveExisting And existingLegacy.Exists(legacyKey) And Not legacyUsed.Exists(legacyKey) Then
                oldData = existingLegacy(legacyKey)
                legacyUsed.Add legacyKey, True
                isLegacy = True
            End If
            If Not IsEmpty(oldData) Then VFD_DWG_ApplyExistingOverrides rowData, oldData, queueMap, isLegacy
            rowsOut.Add rowData
        Next pageIndex
    Next panelKey
End Sub

Private Sub VFD_DWG_CacheExistingQueue(ByVal ws As Worksheet, ByVal qMap As Object, ByVal lastCol As Long, _
                                       ByVal exactIndex As Object, ByVal legacyIndex As Object)
    Dim r As Long, lastRow As Long
    Dim sisElement As String, rightSis As String, planID As String, circuitID As String
    Dim key As String, data As Variant

    lastRow = VFD_DWG_LastDataRow(ws)
    For r = 2 To lastRow
        sisElement = VFD_DWG_CellText(ws, r, qMap, "SIS_ELEMENT_NUMBER")
        rightSis = VFD_DWG_CellText(ws, r, qMap, "RIGHT_SIS_ELEMENT_NUMBER")
        planID = VFD_DWG_CellText(ws, r, qMap, "PLAN_ID")
        circuitID = VFD_DWG_CellText(ws, r, qMap, "CIRCUIT_ID")
        If Len(sisElement) > 0 Then
            data = ws.Cells(r, 1).Resize(1, lastCol).Value2
            If Len(planID) > 0 Then
                key = VFD_DWG_QueueKey(sisElement, rightSis, planID)
                If Not exactIndex.Exists(key) Then exactIndex.Add key, data
            End If
            key = UCase$(sisElement & "|" & circuitID)
            If Not legacyIndex.Exists(key) Then legacyIndex.Add key, data
        End If
    Next r
End Sub

Private Sub VFD_DWG_ApplyExistingOverrides(ByRef newRow As Variant, ByVal oldData As Variant, _
                                           ByVal qMap As Object, ByVal legacyRow As Boolean)
    Dim preserveHeaders As Variant, h As Variant, col As Long, v As Variant
    Dim preserveCoordinates As Boolean

    preserveCoordinates = VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue( _
                              "VFD_PRESERVE_QUEUE_COORDINATE_OVERRIDES", "NO")))

    If legacyRow Then
        If preserveCoordinates Then
            preserveHeaders = Array("ENABLED", "CIRCUIT_INSERT_X", "CIRCUIT_INSERT_Y", "CIRCUIT_INSERT_Z", _
                                    "CIRCUIT_ROTATION_DEG", "CIRCUIT_SCALE", "NOTES")
        Else
            preserveHeaders = Array("ENABLED", "NOTES")
        End If
    Else
        If preserveCoordinates Then
            preserveHeaders = Array("ENABLED", "OUTPUT_DWG_NAME", "SEED_ID", "CIRCUIT_ID", _
                                    "CIRCUIT_INSERT_X", "CIRCUIT_INSERT_Y", "CIRCUIT_INSERT_Z", _
                                    "CIRCUIT_ROTATION_DEG", "CIRCUIT_SCALE", _
                                    "RIGHT_CIRCUIT_INSERT_X", "RIGHT_CIRCUIT_INSERT_Y", "RIGHT_CIRCUIT_INSERT_Z", _
                                    "RIGHT_CIRCUIT_ROTATION_DEG", "RIGHT_CIRCUIT_SCALE", _
                                    "SHEET_NUMBER", "DRAWING_TITLE", "DRAWING_DESCRIPTION", "STATUS", "OUTPUT_PATH", _
                                    "LAST_RUN", "NOTES")
        Else
            preserveHeaders = Array("ENABLED", "OUTPUT_DWG_NAME", "SEED_ID", _
                                    "SHEET_NUMBER", "DRAWING_TITLE", "DRAWING_DESCRIPTION", "NOTES")
        End If
    End If

    For Each h In preserveHeaders
        If qMap.Exists(VFD_DWG_NormalizeHeader(CStr(h))) Then
            col = CLng(qMap(VFD_DWG_NormalizeHeader(CStr(h))))
            v = oldData(1, col)
            If Not IsNull(v) Then
                If Len(Trim$(CStr(v))) > 0 Then newRow(col) = v
            End If
        End If
    Next h
End Sub

Private Function VFD_DWG_UniqueBucketRows(ByVal sourceRows As Collection, _
                                                ByVal wsSource As Worksheet, _
                                                ByVal sourceMap As Object) As Collection
    Dim result As New Collection
    Dim seen As Object
    Dim item As Variant
    Dim rowNumber As Long
    Dim sisElement As String
    Dim sourceKey As String

    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    For Each item In sourceRows
        rowNumber = CLng(item)
        sisElement = VFD_DWG_CellText(wsSource, rowNumber, sourceMap, "SIS_ELEMENT_NUMBER")
        sourceKey = VFD_DWG_SourceIdentityKey(sisElement)

        If Len(sourceKey) > 0 Then
            If Not seen.Exists(sourceKey) Then
                seen.Add sourceKey, True
                result.Add rowNumber
            End If
        End If
    Next item

    If result.count = 0 Then
        Err.Raise vbObjectError + 714, "VFD_DWG_UniqueBucketRows", _
                  "A VFD drawing group contained no valid unique source rows."
    End If

    Set VFD_DWG_UniqueBucketRows = result
End Function

Private Function VFD_DWG_MatchingPlanRows(ByVal ws As Worksheet, ByVal planMap As Object, _
                                          ByVal sourceType As String) As Variant
    Dim specific As Collection, fallback As Collection, selected As Collection
    Dim r As Long, lastRow As Long, pattern As String
    Dim arr() As Long, i As Long, j As Long, temp As Long
    Dim orderI As Double, orderJ As Double

    Set specific = New Collection
    Set fallback = New Collection
    lastRow = VFD_DWG_LastDataRow(ws)

    For r = 2 To lastRow
        If VFD_DWG_IsYes(VFD_DWG_CellText(ws, r, planMap, "ENABLED")) Then
            pattern = Trim$(VFD_DWG_CellText(ws, r, planMap, "TYPE_MATCH"))
            If Len(pattern) = 0 Or pattern = "*" Then
                fallback.Add r
            ElseIf UCase$(sourceType) Like UCase$(pattern) Then
                specific.Add r
            End If
        End If
    Next r

    If specific.count > 0 Then Set selected = specific Else Set selected = fallback
    If selected.count = 0 Then
        VFD_DWG_MatchingPlanRows = Empty
        Exit Function
    End If

    ReDim arr(1 To selected.count)
    For i = 1 To selected.count: arr(i) = CLng(selected(i)): Next i

    For i = LBound(arr) To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            orderI = val(VFD_DWG_CellText(ws, arr(i), planMap, "PAGE_ORDER"))
            orderJ = val(VFD_DWG_CellText(ws, arr(j), planMap, "PAGE_ORDER"))
            If orderJ < orderI Then
                temp = arr(i): arr(i) = arr(j): arr(j) = temp
            End If
        Next j
    Next i

    VFD_DWG_MatchingPlanRows = arr
End Function

Private Sub VFD_DWG_PopulateQueueSlot(ByVal wsSource As Worksheet, ByVal sourceRow As Long, _
                                      ByVal sourceMap As Object, ByRef rowData As Variant, _
                                      ByVal queueMap As Object, ByVal prefix As String, _
                                      ByVal circuitID As String, ByRef sisElement As String, _
                                      ByRef sisSequence As String, ByRef areaNumber As String, _
                                      ByRef switchGroup As String, ByRef vfdType As String, _
                                      ByRef panel As String)
    Dim sourceValue As String

    sisElement = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "SIS_ELEMENT_NUMBER")
    vfdType = VFD_DWG_CellText(wsSource, sourceRow, sourceMap, "TYPE")
    panel = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("480V PANEL", "PANEL", "PNL"))
    VFD_DWG_ParseSISElement sisElement, areaNumber, switchGroup, sisSequence

    sourceValue = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("AREA_NUMBER", "AREA NUMBER", "LOCATION"))
    If Len(sourceValue) > 0 Then areaNumber = sourceValue
    sourceValue = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("SWITCHGROUP", "SWITCH GROUP", "PWG"))
    If Len(sourceValue) > 0 Then switchGroup = sourceValue

    VFD_DWG_SetRowValue rowData, queueMap, prefix & "SOURCE_ROW", sourceRow
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "CIRCUIT_ID", circuitID
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "SIS_ELEMENT_NUMBER", sisElement
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "SIS_SEQUENCE", sisSequence
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "AREA_NUMBER", areaNumber
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "SWITCHGROUP", switchGroup
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "TYPE", vfdType
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "PANEL", panel
    VFD_DWG_CopySourceFields wsSource, sourceRow, sourceMap, rowData, queueMap, prefix
End Sub

Private Sub VFD_DWG_CopySourceFields(ByVal wsSource As Worksheet, ByVal sourceRow As Long, _
                                     ByVal sourceMap As Object, ByRef rowData As Variant, _
                                     ByVal queueMap As Object, Optional ByVal prefix As String = vbNullString)
    Dim lpBusIn As String
    Dim lpBusOut As String

    VFD_DWG_SetRowValue rowData, queueMap, prefix & "LOAD", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("LOAD"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "BLOCK", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("BLOCK"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "TERMINAL_IN", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("TERMINAL (IN)", "TERMINAL_IN"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "TERMINAL_OUT", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("TERMINAL (OUT)", "TERMINAL_OUT"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "POWER_BUS_2", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("POWER BUS-2", "POWER_BUS_2"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "POWER_TERMINAL", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("TERMINAL", "POWER_TERMINAL"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "INSIDE_PSU_TERM", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("INSIDE PSU TERM", "INSIDE_PSU_TERM"))

    'C04.1 permanent LP BUS contract used by the AutoCAD VFD generator.
    'LP_BUS_IN  = terminal inside the BUS-2 PSU feeding this VFD.
    lpBusIn = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array( _
                    "INSIDE PSU TERM", _
                    "INSIDE_PSU_TERM", _
                    "POWER_24V_BUS_2_TERMINAL", _
                    "PD6_POWER_BUS_2_TERMINAL"))

    'LP_BUS_OUT = actual BUS-2 PSU feeding this VFD.
    lpBusOut = VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array( _
                    "POWER BUS-2", _
                    "POWER_BUS_2", _
                    "POWER_24V_BUS_2_PSU", _
                    "PD6_POWER_SUPPLY"))

    VFD_DWG_SetRowValue rowData, queueMap, prefix & "LP_BUS_IN", lpBusIn
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "LP_BUS_OUT", lpBusOut
    'Legacy seed compatibility. New seed drawings should use LP_BUS_OUT.
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "LP_BUS2_OUT", lpBusOut

    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NET_TERMINAL_IN", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NET TERMINAL (IN)", "NET_TERMINAL_IN"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NET_TERMINAL_OUT", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NET TERMINAL (OUT)", "NET_TERMINAL_OUT"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "BLOCK_IO", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("BLOCK IO", "BLOCK_IO"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "BUS_1_IN", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("BUS-1-IN", "BUS_1_IN"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "BUS_1_OUT", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("BUS-1-OUT", "BUS_1_OUT"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "BUS_2_IN", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("BUS-2-IN", "BUS_2_IN"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "BUS_2_OUT", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("BUS-2-OUT", "BUS_2_OUT"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "MOTOR_POWER_MAIN_DRIVE", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("Motor Power (Main Drive)", "MOTOR_POWER_MAIN_DRIVE"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_IP", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_IP", "NETWORK IP"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "LPN", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("LPN"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "LOAD_BUS_1", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("Load BUS-1", "LOAD_BUS_1"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "LOAD_BUS_2", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("Load BUS-2", "LOAD_BUS_2"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_PANEL", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_PANEL"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_SWITCH", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_SWITCH"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_PORT", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_PORT"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_ROUTE", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_ROUTE"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_FROM", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_FROM"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_TO", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_TO"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_SOURCE_SHEET", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_SOURCE_SHEET"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "NETWORK_DEVICE_REFERENCE", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("NETWORK_DEVICE_REFERENCE"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "POWER_24V_SOURCE_SHEET", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("POWER_24V_SOURCE_SHEET"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "POWER_24V_BUS_1_PSU", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("POWER_24V_BUS_1_PSU"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "POWER_24V_BUS_1_TERMINAL", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("POWER_24V_BUS_1_TERMINAL"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "POWER_24V_BUS_2_PSU", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("POWER_24V_BUS_2_PSU"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "POWER_24V_BUS_2_TERMINAL", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("POWER_24V_BUS_2_TERMINAL"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "PD6_SOURCE_ROW", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("PD6_SOURCE_ROW"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "PD6_BUS_POWER", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("PD6_BUS_POWER"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "PD6_POWER_SUPPLY", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("PD6_POWER_SUPPLY"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "PD6_POWER_BUS_1_TERMINAL", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("PD6_POWER_BUS_1_TERMINAL"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "PD6_POWER_BUS_2_TERMINAL", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("PD6_POWER_BUS_2_TERMINAL"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_SOURCE_SHEET", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_SOURCE_SHEET"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_SOURCE_ROWS", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_SOURCE_ROWS"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_BLOCK_ID", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_BLOCK_ID"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_IO_BLOCK", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_IO_BLOCK"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_CHANNEL_IO", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_CHANNEL_IO"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_PORT_LOCATION", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_PORT_LOCATION"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_FROM_TEXT", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_FROM_TEXT"))
    VFD_DWG_SetRowValue rowData, queueMap, prefix & "STO_MATCH_STATUS", VFD_DWG_FirstSourceValue(wsSource, sourceRow, sourceMap, Array("STO_MATCH_STATUS"))
End Sub

Private Function VFD_DWG_DeviceFolderName(ByVal leftSis As String, ByVal rightSis As String) As String
    Dim separatorText As String
    separatorText = CStr(VFD_DWG_GetConfigValue("DEVICE_GROUP_SEPARATOR", "__"))
    If Len(Trim$(rightSis)) > 0 Then
        VFD_DWG_DeviceFolderName = VFD_DWG_SafeID(leftSis) & separatorText & VFD_DWG_SafeID(rightSis)
    Else
        VFD_DWG_DeviceFolderName = VFD_DWG_SafeID(leftSis)
    End If
End Function

Private Sub VFD_DWG_SetDevicesPerSheet(ByVal requestedCount As Long)
    Dim wsConfig As Worksheet, wsPlan As Worksheet, configMap As Object
    Dim rowNumber As Long

    If requestedCount < 1 Then requestedCount = 1
    If requestedCount > 2 Then requestedCount = 2

    On Error GoTo EH
    VFD_DWG_BeginFastMode "Updating VFD devices-per-sheet mode..."
    VFD_DWG_SetupAllSheets

    Set wsConfig = VFD_DWG_GetOrCreateSheet(SH_CONFIG)
    Set configMap = VFD_DWG_HeaderMap(wsConfig)
    rowNumber = VFD_DWG_FindKeyedRow(wsConfig, configMap, "SETTING", "VFD_DEVICES_PER_SHEET")
    If rowNumber = 0 Then
        rowNumber = VFD_DWG_LastDataRow(wsConfig) + 1
        VFD_DWG_PutCell wsConfig, rowNumber, configMap, "SETTING", "VFD_DEVICES_PER_SHEET"
    End If
    VFD_DWG_PutCell wsConfig, rowNumber, configMap, "VALUE", requestedCount

    Set wsPlan = VFD_DWG_GetOrCreateSheet(SH_SHEET_PLAN)
    VFD_DWG_SyncDevicesPerSheet wsPlan
    Call VFD_DWG_BackfillPD6Core
    Call VFD_DWG_Backfill24VCore
    Call VFD_DWG_BackfillNetworkCore
    Call VFD_DWG_BackfillSTOCore
    VFD_DWG_RefreshQueueCore False, True
    VFD_DWG_EndFastMode

    MsgBox CStr(requestedCount) & " VFD device(s) per PWR/IO sheet is now active.", _
           vbInformation, "ONGEN VFD Sheet Mode"
    Exit Sub
EH:
    VFD_DWG_EndFastMode
    MsgBox "Could not change the VFD sheet mode:" & vbCrLf & Err.description, _
           vbCritical, "ONGEN VFD Sheet Mode"
End Sub

Private Sub VFD_DWG_SyncDevicesPerSheet(ByVal wsPlan As Worksheet)
    Dim planMap As Object, devicesPerSheet As Long, r As Long, lastRow As Long
    Dim planID As String, pageCode As String

    devicesPerSheet = CLng(val(CStr(VFD_DWG_GetConfigValue("VFD_DEVICES_PER_SHEET", 2))))
    If devicesPerSheet < 1 Then devicesPerSheet = 1
    If devicesPerSheet > 2 Then devicesPerSheet = 2

    Set planMap = VFD_DWG_HeaderMap(wsPlan)
    lastRow = VFD_DWG_LastDataRow(wsPlan)
    For r = 2 To lastRow
        planID = UCase$(VFD_DWG_CellText(wsPlan, r, planMap, "PLAN_ID"))
        pageCode = UCase$(VFD_DWG_CellText(wsPlan, r, planMap, "PAGE_CODE"))
        If planID = "MOVIFLEX_PWR" Or planID = "MOVIFLEX_IO" Or _
           pageCode = "PWR" Or pageCode = "IO" Then
            VFD_DWG_PutCell wsPlan, r, planMap, "MAX_DEVICES_PER_SHEET", devicesPerSheet
        End If
    Next r
End Sub

Private Function VFD_DWG_FindKeyedRow(ByVal ws As Worksheet, ByVal headerMap As Object, _
                                      ByVal keyHeader As String, ByVal keyValue As String) As Long
    Dim r As Long, lastRow As Long
    lastRow = VFD_DWG_LastDataRow(ws)
    For r = 2 To lastRow
        If StrComp(VFD_DWG_CellText(ws, r, headerMap, keyHeader), keyValue, vbTextCompare) = 0 Then
            VFD_DWG_FindKeyedRow = r
            Exit Function
        End If
    Next r
End Function

Private Sub VFD_DWG_ResolvePrimaryCircuitCoordinates( _
        ByVal wsPlan As Worksheet, ByVal planRow As Long, ByVal planMap As Object, _
        ByVal wsCircuits As Worksheet, ByVal circuitMap As Object, ByVal circuitID As String, _
        ByRef leftX As Variant, ByRef leftY As Variant, ByRef leftZ As Variant, _
        ByRef rightX As Variant, ByRef rightY As Variant, ByRef rightZ As Variant, _
        ByRef rotationValue As Variant, ByRef scaleValue As Variant)

    Dim circuitRow As Long
    Dim libraryX As Variant, libraryY As Variant, libraryZ As Variant
    Dim libraryRightX As Variant, libraryRightY As Variant, libraryRightZ As Variant
    Dim libraryRotation As Variant, libraryScale As Variant
    Dim usePlanCoordinates As Boolean

    circuitRow = VFD_DWG_FindKeyedRow(wsCircuits, circuitMap, "CIRCUIT_ID", circuitID)
    If circuitRow < 2 Then
        Err.Raise vbObjectError + 715, "VFD_DWG_ResolvePrimaryCircuitCoordinates", _
                  "CIRCUIT_ID was not found in VFD_DWG_CIRCUIT_LIBRARY: " & circuitID
    End If

    libraryX = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "INSERT_X"), _
                    VFD_DWG_GetConfigValue("DEFAULT_LEFT_INSERT_X", _
                        VFD_DWG_GetConfigValue("DEFAULT_INSERT_X", 0)))
    libraryY = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "INSERT_Y"), _
                    VFD_DWG_GetConfigValue("DEFAULT_LEFT_INSERT_Y", _
                        VFD_DWG_GetConfigValue("DEFAULT_INSERT_Y", 0)))
    libraryZ = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "INSERT_Z"), _
                    VFD_DWG_GetConfigValue("DEFAULT_LEFT_INSERT_Z", _
                        VFD_DWG_GetConfigValue("DEFAULT_INSERT_Z", 0)))
    libraryRotation = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "ROTATION_DEG"), _
                    VFD_DWG_GetConfigValue("DEFAULT_ROTATION_DEG", 0))
    libraryScale = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "SCALE"), _
                    VFD_DWG_GetConfigValue("DEFAULT_SCALE", 1))

    'Each circuit may define its own RIGHT insertion point.
    'A blank Circuit Library value falls back to the matching global config value.
    libraryRightX = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "DEFAULT_RIGHT_INSERT_X"), _
                    VFD_DWG_GetConfigValue("DEFAULT_RIGHT_INSERT_X", libraryX))
    libraryRightY = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "DEFAULT_RIGHT_INSERT_Y"), _
                    VFD_DWG_GetConfigValue("DEFAULT_RIGHT_INSERT_Y", libraryY))
    libraryRightZ = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsCircuits, circuitRow, circuitMap, "DEFAULT_RIGHT_INSERT_Z"), _
                    VFD_DWG_GetConfigValue("DEFAULT_RIGHT_INSERT_Z", libraryZ))

    usePlanCoordinates = VFD_DWG_IsYes(CStr(VFD_DWG_GetConfigValue( _
                             "VFD_USE_SHEET_PLAN_COORDINATES", "NO")))

    If usePlanCoordinates Then
        leftX = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "LEFT_INSERT_X"), _
                    VFD_DWG_DefaultIfBlank( _
                        VFD_DWG_CellValue(wsPlan, planRow, planMap, "INSERT_X"), libraryX))
        leftY = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "LEFT_INSERT_Y"), _
                    VFD_DWG_DefaultIfBlank( _
                        VFD_DWG_CellValue(wsPlan, planRow, planMap, "INSERT_Y"), libraryY))
        leftZ = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "LEFT_INSERT_Z"), _
                    VFD_DWG_DefaultIfBlank( _
                        VFD_DWG_CellValue(wsPlan, planRow, planMap, "INSERT_Z"), libraryZ))
        rightX = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "RIGHT_INSERT_X"), _
                    libraryRightX)
        rightY = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "RIGHT_INSERT_Y"), _
                    libraryRightY)
        rightZ = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "RIGHT_INSERT_Z"), _
                    libraryRightZ)
        rotationValue = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "ROTATION_DEG"), libraryRotation)
        scaleValue = VFD_DWG_DefaultIfBlank( _
                    VFD_DWG_CellValue(wsPlan, planRow, planMap, "SCALE"), libraryScale)
    Else
        'Authoritative mode: the selected circuit row feeds LEFT/main and RIGHT.
        'Blank RIGHT values on the circuit row fall back to VFD_DWG_CONFIG.
        leftX = libraryX
        leftY = libraryY
        leftZ = libraryZ
        rightX = libraryRightX
        rightY = libraryRightY
        rightZ = libraryRightZ
        rotationValue = libraryRotation
        scaleValue = libraryScale
    End If

    If IsNumeric(scaleValue) Then
        If CDbl(scaleValue) = 0 Then scaleValue = 1
    End If
End Sub

Private Function VFD_DWG_SourceIdentityKey(ByVal sisElement As String) As String
    Dim s As String, suffixText As String, p As Long
    s = UCase$(Trim$(sisElement))
    s = Replace(s, " ", "")
    p = InStrRev(s, "-K", -1, vbTextCompare)
    If p > 0 Then
        suffixText = mid$(s, p + 2)
        If Len(suffixText) > 0 And IsNumeric(suffixText) Then s = Left$(s, p - 1)
    End If
    VFD_DWG_SourceIdentityKey = s
End Function

Private Function VFD_DWG_PanelIdentityKey(ByVal panelText As String) As String
    Dim s As String
    s = UCase$(Trim$(panelText))
    s = Replace(s, " ", vbNullString)
    s = Replace(s, "-", vbNullString)
    s = Replace(s, "_", vbNullString)
    VFD_DWG_PanelIdentityKey = s
End Function

Private Function VFD_DWG_RowArrayText(ByVal rowData As Variant, ByVal headerMap As Object, _
                                      ByVal headerName As String) As String
    Dim key As String, col As Long
    On Error GoTo SafeExit
    key = VFD_DWG_NormalizeHeader(headerName)
    If Not headerMap.Exists(key) Then Exit Function
    col = CLng(headerMap(key))
    VFD_DWG_RowArrayText = Trim$(CStr(rowData(col)))
SafeExit:
End Function

'====================================================================================
' SHEET SETUP
'====================================================================================

Private Sub VFD_DWG_SetupAllSheets()
    VFD_DWG_SetupSourceColumns
    VFD_DWG_SetupReadme
    VFD_DWG_SetupConfig
    VFD_DWG_SetupSeedLibrary
    VFD_DWG_SetupSheetPlan
    VFD_DWG_SetupCircuitLibrary
    VFD_DWG_SetupCircuitPlacement
    VFD_DWG_SetupDeviceLibrary
    VFD_DWG_SetupDevicePlacement
    VFD_DWG_SetupBlockEdit
    VFD_DWG_SetupAttributeMap
    VFD_DWG_SetupQueue
End Sub


Private Sub VFD_DWG_SetupSourceColumns()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetSheet(SH_SOURCE)
    If ws Is Nothing Then Exit Sub

    VFD_DWG_EnsureHeaders ws, _
        "SIS_SEQUENCE|AREA_NUMBER|SWITCHGROUP|Motor Power (Main Drive)|NETWORK_IP|LPN|Load BUS-1|Load BUS-2|" & _
        "NETWORK_PANEL|NETWORK_SWITCH|NETWORK_PORT|NETWORK_ROUTE|NETWORK_FROM|NETWORK_TO|" & _
        "NETWORK_SOURCE_SHEET|NETWORK_DEVICE_REFERENCE|POWER_24V_SOURCE_SHEET|" & _
        "POWER_24V_BUS_1_PSU|POWER_24V_BUS_1_TERMINAL|POWER_24V_BUS_2_PSU|POWER_24V_BUS_2_TERMINAL|" & _
        "PD6_SOURCE_ROW|PD6_BUS_POWER|PD6_POWER_SUPPLY|PD6_POWER_BUS_1_TERMINAL|PD6_POWER_BUS_2_TERMINAL|" & _
        "STO_SOURCE_SHEET|STO_SOURCE_ROWS|STO_BLOCK_ID|STO_IO_BLOCK|STO_CHANNEL_IO|STO_PORT_LOCATION|" & _
        "STO_FROM_TEXT|STO_MATCH_STATUS"
End Sub

Private Sub VFD_DWG_SetupReadme()
    Dim ws As Worksheet
    Dim data As Variant
    Dim r As Long, c As Long

    Set ws = VFD_DWG_GetOrCreateSheet(SH_README)

    ws.Cells.Clear
    ws.Range("A1:D1").Merge
    ws.Range("A1").value = "ONGEN VFD SCHEMATIC DRAWING GENERATOR - FINAL MODEL V" & VFD_VERSION
    With ws.Range("A1:D1")
        .Font.Bold = True: .Font.Size = 16: .Font.Color = vbWhite
        .Interior.Color = RGB(31, 78, 121): .HorizontalAlignment = xlCenter
    End With

    ws.Range("A3:D3").value = Array("Order", "Worksheet", "Purpose", "Rule")
    VFD_DWG_StyleHeader ws.Range("A3:D3")

    data = Array( _
        Array(1, SH_SOURCE, "One unique source row per physical VFD device.", "Created by existing Step 08."), _
        Array(2, SH_SHEET_PLAN, "Defines grouped PWR/IO output pages and left/right coordinates; MPWR is panel-level.", "MAX_DEVICES_PER_SHEET is 1 or 2; paired VFDs must share Area, Panel, SwitchGroup, and Type."), _
        Array(3, SH_SEEDS, "Defines reusable border/template drawings.", "Queue SEED_ID selects a seed; SEED_DWG_PATH is fallback."), _
        Array(4, SH_QUEUE, "One final row per output DWG, with optional RIGHT_* device fields.", "The LISP places left/right circuits independently, validates one SwitchGroup per sheet, and asks for the output root every run."), _
        Array(5, SH_CIRCUITS, "Defines reusable circuit DWGs.", "Every CIRCUIT_ID must be unique."), _
        Array(6, SH_CIRCUIT_PLACEMENT, "Adds extra full circuits to an output drawing.", "Use DRAWING_ID, PLAN_ID, or PAGE_CODE selectors."), _
        Array(7, SH_DEVICES, "Defines optional individual device blocks/DWGs.", "Rows may be disabled until files exist."), _
        Array(8, SH_DEVICE_PLACEMENT, "Places optional devices by locator or X/Y/Z fallback.", "Use TARGET_VFD/TARGET_SIDE for exact VFD ownership; DRAWING_ID remains the exact drawing selector."), _
        Array(9, SH_BLOCK_EDIT, "Exact block names and exact attribute expressions for PWR/IO.", "Only listed blocks are edited. MPWR circuits/devices are never edited."), _
        Array(10, SH_ATTRMAP, "Maps title-block fields only.", "CIRCUIT and DEVICE mapping is intentionally removed; use BLOCK_EDIT."), _
        Array(11, SH_CONFIG, "Global library/default settings.", "The AutoLISP always asks the user for the exact generation root."), _
        Array(12, SH_IO_DEVICE_LIST, "VFD STO source table.", "SIS_SEQUENCE matches Device; Block ID and Channel IO populate STO_FROM_TEXT without an arrow."))

    For r = LBound(data) To UBound(data)
        For c = LBound(data(r)) To UBound(data(r))
            ws.Cells(r + 4, c + 1).value = data(r)(c)
        Next c
    Next r

    ws.Range("A17:D17").Merge
    ws.Range("A17").value = "OUTPUT CONTROL: ONGEN_VFD_DRAWING_GEN always asks for Workbook, Browse, or Cancel. The selected folder is the exact Area-folder root. Output is Area -> Panel -> DWG; there is no Devices sub-folder."
    ws.Range("A17").Font.Bold = True
    ws.Range("A17").Interior.Color = RGB(226, 239, 218)

    ws.Range("A18:D18").Merge
    ws.Range("A18").value = "ATTRIBUTE CONTROL: BLOCK_EDIT is authoritative for PWR/IO circuit and device blocks. MPWR is protected from BLOCK_EDIT changes."
    ws.Range("A18").Font.Bold = True
    ws.Range("A18").Interior.Color = RGB(255, 242, 204)

    ws.Range("A19:D19").Merge
    ws.Range("A19").value = "BACKFILL: VFD_DWG_Backfill_All_Ready_Data pulls Motor Power from PD6_IMPORT, 24V power from Step 07, network routes from Step 11B, and VFD STO sources from IO_DEVICE_LIST."
    ws.Range("A19").Font.Bold = True
    ws.Range("A19").Interior.Color = RGB(221, 235, 247)

    ws.Range("A20:D20").Merge
    ws.Range("A20").value = "UI CONTROL: VFD_DWG_Install_Workflow repairs data only. ONGEN_RELOAD_ALL_UI_BUTTONS is the sole UI rebuild command."
    ws.Range("A20").Font.Bold = True
    ws.Range("A20").Interior.Color = RGB(255, 242, 204)
    ws.Columns("A").columnWidth = 9
    ws.Columns("B").columnWidth = 34
    ws.Columns("C:D").columnWidth = 58
    ws.rows.AutoFit
End Sub

Private Sub VFD_DWG_SetupConfig()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetOrCreateSheet(SH_CONFIG)
    VFD_DWG_EnsureHeaders ws, "SETTING|VALUE|REQUIRED|DESCRIPTION"

    VFD_DWG_EnsureConfigRow ws, "WORKBOOK_VERSION", VFD_VERSION, "YES", "VFD data-model version."
    VFD_DWG_EnsureConfigRow ws, "LIBRARY_ROOT_PATH", DEFAULT_LIBRARY_ROOT, "YES", "Primary circuit, device, and seed library root."
    VFD_DWG_EnsureConfigRow ws, "OUTPUT_FOLDER", "Generated_Drawings\480V_POWER", "NO", "Legacy suggestion only. The AutoLISP asks for the exact output root on every generation run."
    VFD_DWG_EnsureConfigRow ws, "PROMPT_OUTPUT_FOLDER_ALWAYS", "YES", "YES", "Always asks the user to use the workbook folder, browse for a folder, or cancel."
    VFD_DWG_EnsureConfigRow ws, "AUTO_SHORT_OUTPUT_ROOT", "NO", "NO", "Legacy setting. V3.5 does not override the output folder selected by the user."
    VFD_DWG_EnsureConfigRow ws, "SHORT_OUTPUT_ROOT", "", "NO", "Optional absolute short output root. Blank uses the current user's Documents\ONGEN_Output\480V_POWER folder."
    VFD_DWG_EnsureConfigRow ws, "OUTPUT_ROOT_LENGTH_LIMIT", 140, "NO", "When the resolved output root exceeds this length and auto-short is enabled, the short root is used."
    VFD_DWG_EnsureConfigRow ws, "MAX_OUTPUT_PATH_LENGTH", 248, "NO", "Maximum final DWG path length for Selected Root -> Area -> Panel -> DWG."
    VFD_DWG_EnsureConfigRow ws, "OVERWRITE_EXISTING", "YES", "YES", "YES replaces existing output DWGs; NO safely skips them."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_SEED_ID", "VFD_STANDARD", "YES", "Default lookup in VFD_DWG_SEED_LIBRARY."
    VFD_DWG_EnsureConfigRow ws, "SEED_DWG_PATH", "480_24V_seed.dwg", "NO", "Legacy/fallback seed path when SEED_ID cannot be used."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_CIRCUIT_ID", "MOVIFLEX_IO", "YES", "Fallback primary CIRCUIT_ID."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_INSERT_X", 0, "YES", "Legacy left/main circuit insertion X."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_INSERT_Y", 0, "YES", "Legacy left/main circuit insertion Y."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_INSERT_Z", 0, "YES", "Legacy left/main circuit insertion Z."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_LEFT_INSERT_X", -5, "YES", "Default left VFD/IO circuit insertion X."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_LEFT_INSERT_Y", 3.9613, "YES", "Default left VFD/IO circuit insertion Y."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_LEFT_INSERT_Z", 0, "YES", "Default left VFD/IO circuit insertion Z."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_RIGHT_INSERT_X", 10, "YES", "Fallback right X used only when the matching Circuit Library right X is blank."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_RIGHT_INSERT_Y", 3.9613, "YES", "Fallback right Y used only when the matching Circuit Library right Y is blank."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_RIGHT_INSERT_Z", 0, "YES", "Fallback right Z used only when the matching Circuit Library right Z is blank."
    VFD_DWG_EnsureConfigRow ws, "VFD_USE_SHEET_PLAN_COORDINATES", "NO", "YES", "NO makes the selected Circuit Library row authoritative for LEFT and RIGHT coordinates; blank RIGHT values fall back to VFD_DWG_CONFIG. YES enables explicit Sheet Plan overrides."
    VFD_DWG_EnsureConfigRow ws, "VFD_PRESERVE_QUEUE_COORDINATE_OVERRIDES", "NO", "YES", "NO recalculates queue coordinates on every refresh. YES preserves manual queue coordinate edits."
    VFD_DWG_EnsureConfigRow ws, "RECOMMENDED_WORKBOOK_NAME", "ONGEN_Electrical_Generator_V21.0.xlsm", "NO", "Recommended abbreviated workbook filename."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_ROTATION_DEG", 0, "YES", "Default primary circuit rotation in degrees."
    VFD_DWG_EnsureConfigRow ws, "DEFAULT_SCALE", 1, "YES", "Default primary circuit scale."
    VFD_DWG_EnsureConfigRow ws, "AREA_FOLDER_PREFIX", "Area-", "YES", "Prefix used for Area_Number folders."
    VFD_DWG_EnsureConfigRow ws, "DEVICES_FOLDER_NAME", "", "NO", "Deprecated. V3.7 writes drawings directly under Area -> Panel. No device/group sub-folder is created."
    VFD_DWG_EnsureConfigRow ws, "DEVICE_GROUP_SEPARATOR", "__", "YES", "Deprecated compatibility field. No device-group folder is created in V3.7."
    VFD_DWG_EnsureConfigRow ws, "VFD_DEVICES_PER_SHEET", 2, "YES", "Use 1 or 2. Applied consistently to PWR and IO plan rows."
    VFD_DWG_EnsureConfigRow ws, "DEDUPLICATE_SOURCE_VFDS", "YES", "YES", "Keeps one queue source row per canonical physical VFD identity."
    VFD_DWG_EnsureConfigRow ws, "VFD_BACKFILL_OVERWRITE", "NO", "NO", "NO fills only blank VFD fields; YES replaces existing backfilled values."
    VFD_DWG_EnsureConfigRow ws, "VFD_NETWORK_BACKFILL_TO_NET_TERMINALS", "YES", "NO", "YES copies Step 11B route From/To text into blank NET TERMINAL IN/OUT fields."
    VFD_DWG_EnsureConfigRow ws, "VFD_24V_BACKFILL_ENABLED", "YES", "NO", "YES reads panel *_24V worksheets created by Step 07."
    VFD_DWG_EnsureConfigRow ws, "VFD_NETWORK_BACKFILL_ENABLED", "YES", "NO", "YES reads RCP-* network worksheets created by Step 11B."
    VFD_DWG_EnsureConfigRow ws, "VFD_STO_BACKFILL_ENABLED", "YES", "NO", "YES pulls VFD STO block/channel data from IO_DEVICE_LIST."
    VFD_DWG_EnsureConfigRow ws, "VFD_STO_BACKFILL_OVERWRITE", "YES", "NO", "YES keeps STO source fields synchronized with IO_DEVICE_LIST."
    VFD_DWG_EnsureConfigRow ws, "VFD_STO_MISSING_TEXT", "FROM- xxx", "NO", "Fallback STO text when SIS_SEQUENCE has no IO_DEVICE_LIST match."
    VFD_DWG_SetConfigValue ws, "WORKBOOK_VERSION", VFD_VERSION
    VFD_DWG_SetConfigValue ws, "PROMPT_OUTPUT_FOLDER_ALWAYS", "YES"
    VFD_DWG_SetConfigValue ws, "AUTO_SHORT_OUTPUT_ROOT", "NO"
    VFD_DWG_SetConfigValue ws, "DEVICES_FOLDER_NAME", ""

    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_ENABLED", "YES", "NO", "Adds the boxed PWR - Drawing ONLY label to PWR pages only."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_TEXT", "PWR - Drawing ONLY", "NO", "Text inside the boxed PWR-only label."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_X", 0.25, "NO", "Lower-left X of the PWR-only label box."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_Y", 10, "NO", "Lower-left Y of the PWR-only label box."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_Z", 0, "NO", "Z elevation of the PWR-only label box."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_WIDTH", 4, "NO", "Width of the PWR-only label box."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_HEIGHT", 0.8, "NO", "Height of the PWR-only label box."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_TEXT_HEIGHT", 0.3, "NO", "Text height for PWR - Drawing ONLY."
    VFD_DWG_EnsureConfigRow ws, "PWR_DRAWING_LABEL_LAYER", "LP_TITLE_DETAILS", "NO", "Layer used for the PWR-only label."

    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_ENABLED", "YES", "NO", "Adds From <Panel> <SwitchGroup> to PWR and IO pages only."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_PREFIX", "From {PANEL} - {SWITCHGROUP}", "NO", "Token template. Example: From RCP-101 - SWG104."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_SEPARATOR", " - ", "NO", "Fallback separator between Panel and SwitchGroup."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_SWITCHGROUP_PREFIX", "SWG", "NO", "Prefixes a numeric SwitchGroup in the feed header."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_GROUP_SEPARATOR", " / ", "NO", "Legacy separator for different SwitchGroups."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_X", 2.0148, "NO", "PWR/IO feed header X."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_Y", 5.6591, "NO", "PWR/IO feed header Y."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_Z", 0, "NO", "PWR/IO feed header Z."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_TEXT_HEIGHT", 0.2, "NO", "PWR/IO feed header text height."
    VFD_DWG_EnsureConfigRow ws, "FEED_HEADER_LAYER", "LP_TITLE_DETAILS", "NO", "Layer used by the PWR/IO feed header."

    VFD_DWG_EnsureConfigRow ws, "INCOMING_TITLE_ENABLED", "YES", "NO", "Adds INCOMING POWER FROM = <Panel> to PWR and IO pages only."
    VFD_DWG_EnsureConfigRow ws, "INCOMING_TITLE_PREFIX", "INCOMING POWER FROM = ", "NO", "Prefix for the incoming-power title."
    VFD_DWG_EnsureConfigRow ws, "INCOMING_TITLE_X", 10.5803, "NO", "Incoming-power title X."
    VFD_DWG_EnsureConfigRow ws, "INCOMING_TITLE_Y", 6.5026, "NO", "Incoming-power title Y."
    VFD_DWG_EnsureConfigRow ws, "INCOMING_TITLE_Z", 0, "NO", "Incoming-power title Z."
    VFD_DWG_EnsureConfigRow ws, "INCOMING_TITLE_TEXT_HEIGHT", 0.3, "NO", "Incoming-power title text height."
    VFD_DWG_EnsureConfigRow ws, "INCOMING_TITLE_LAYER", "LP_TITLE_DETAILS", "NO", "Layer used by the incoming-power title."

    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_ENABLED", "YES", "YES", "Creates panel-level MPWR sheets."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_SHEETS_PER_PANEL", 2, "YES", "Number of MPWR pages created for each Area/Panel combination."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_SEED_ID", "MAIN_PWR", "YES", "Seed used for MPWR pages."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_CIRCUIT_ID_1", "MAIN_PWR_6", "YES", "Circuit used on the first MPWR page."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_CIRCUIT_ID_2", "MAIN_PWR_6", "YES", "Circuit used on the second MPWR page."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_INSERT_X_1", 3, "NO", "First MPWR circuit insertion X."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_INSERT_Y_1", 20, "NO", "First MPWR circuit insertion Y."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_INSERT_Z_1", 0, "NO", "First MPWR circuit insertion Z."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_INSERT_X_2", 3, "NO", "Second MPWR circuit insertion X."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_INSERT_Y_2", 20, "NO", "Second MPWR circuit insertion Y."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_INSERT_Z_2", 0, "NO", "Second MPWR circuit insertion Z."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_TITLE_1", "PANEL INCOMING POWER", "NO", "Title block text for MPWR page 1."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_TITLE_2", "PANEL POWER DISTRIBUTION", "NO", "Title block text for MPWR page 2."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_DESCRIPTION_1", "Main incoming power for {PANEL}", "NO", "Description for MPWR page 1."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_DESCRIPTION_2", "Panel power distribution for {PANEL}", "NO", "Description for MPWR page 2."
    VFD_DWG_EnsureConfigRow ws, "PANEL_MPWR_DEVICE_FOLDER_SUFFIX", "PANEL POWER", "NO", "Folder suffix used for MPWR pages."

    VFD_DWG_EnsureConfigRow ws, "LOCATOR_LAYER", DEFAULT_LOCATOR_LAYER, "NO", "Optional device-placement locator layer."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_CALLOUTS_ENABLED", "YES", "NO", "Enables LP_BUS_IN, LP_BUS_OUT, LP_NET_IN, and LP_NET_OUT callouts on PWR/IO pages."
    VFD_DWG_EnsureConfigRow ws, "CALLOUT_LOCATOR_LAYER", "", "NO", "Blank searches all layers and nested blocks for LP_* callout locators."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_CALLOUT_LAYER", "LP_TITLE_DETAILS", "NO", "Generated locator-callout geometry layer."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_ARROW_LINE_LENGTH", 1.5, "NO", "Horizontal source/destination arrow line length."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_CALLOUT_TEXT_DISTANCE", 1.6, "NO", "Horizontal distance from the locator to callout text."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_ARROW_TEXT_HEIGHT", 0.125, "NO", "Text height for locator callouts."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_ARROW_TEXT_OFFSET", 0.2, "NO", "Vertical text offset above and below the arrow line."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_ARROW_HEAD_SIZE", 0.18, "NO", "Open arrowhead size."
    VFD_DWG_EnsureConfigRow ws, "LOCATOR_MISSING_TEXT", "MISSING", "NO", "Fallback when a required LP bus/network value is blank."
    VFD_DWG_EnsureConfigRow ws, "BUS2_IN_LOCATOR_TEXT", "LP_BUS_IN", "NO", "Canonical 24V incoming/source locator. LP_BUS2_IN remains a LISP compatibility alias."
    VFD_DWG_EnsureConfigRow ws, "BUS_OUT_LOCATOR_TEXT", "LP_BUS_OUT", "NO", "Canonical 24V outgoing/destination locator. LP_BUS2_OUT remains a compatibility alias."
    VFD_DWG_EnsureConfigRow ws, "NET_IN_LOCATOR_TEXT", "LP_NET_IN", "NO", "Network FROM-arrow locator."
    VFD_DWG_EnsureConfigRow ws, "NET_OUT_LOCATOR_TEXT", "LP_NET_OUT", "NO", "Network TO-arrow locator."
    VFD_DWG_EnsureConfigRow ws, "BUS2_IN_PREFIX", "From ", "NO", "Prefix placed before the feeding PSU at the left/source end of LP_BUS_IN."
    VFD_DWG_EnsureConfigRow ws, "BUS_OUT_PREFIX", "To ", "NO", "Prefix placed on the LP_BUS_OUT destination callout."
    VFD_DWG_EnsureConfigRow ws, "NET_IN_PREFIX", "From: ", "NO", "Prefix before NETWORK_FROM."
    VFD_DWG_EnsureConfigRow ws, "NET_OUT_PREFIX", "To: ", "NO", "Prefix before NETWORK_TO."
    VFD_DWG_EnsureConfigRow ws, "REMOVE_LOCATOR_AFTER_INSERT", "YES", "NO", "Deletes a used locator after device insertion."
    VFD_DWG_EnsureConfigRow ws, "SAVE_WORKBOOK_STATUS", "YES", "NO", "Writes STATUS, OUTPUT_PATH, and LAST_RUN to queue."
    VFD_DWG_EnsureConfigRow ws, "UPDATE_TITLE_BLOCKS", "YES", "NO", "Updates TITLEBLOCK attribute-map rows."
    VFD_DWG_EnsureConfigRow ws, "LOG_FILE_NAME", "LP_Electrical_Generator_Log.csv", "YES", "CSV generation log in output root."

    'Permanent C04.1 migration: normalize existing workbooks from LP_BUS2_IN to LP_BUS_IN.
    VFD_DWG_SetConfigValue ws, "BUS2_IN_LOCATOR_TEXT", "LP_BUS_IN"
    VFD_DWG_SetConfigValue ws, "BUS_OUT_LOCATOR_TEXT", "LP_BUS_OUT"
    VFD_DWG_FormatConfig ws
End Sub

Private Sub VFD_DWG_SetupSeedLibrary()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetOrCreateSheet(SH_SEEDS)
    VFD_DWG_EnsureHeaders ws, "ENABLED|SEED_ID|DESCRIPTION|DWG_PATH|NOTES"
    VFD_DWG_EnsureKeyedRow ws, "SEED_ID", "VFD_STANDARD", _
        Array("ENABLED", "SEED_ID", "DESCRIPTION", "DWG_PATH", "NOTES"), _
        Array("YES", "VFD_STANDARD", "Standard 480V/24V VFD border and title block", "Template\480_24V_seed.dwg", _
              "Path may be absolute, library-relative, or workbook-relative.")
    VFD_DWG_EnsureKeyedRow ws, "SEED_ID", "VFD_MOVI_IO", _
        Array("ENABLED", "SEED_ID", "DESCRIPTION", "DWG_PATH", "NOTES"), _
        Array("YES", "VFD_MOVI_IO", "24V border for VFD I/O", "Template\VFD-IO_SEED.dwg", _
              "Used by MOVIFLEX_IO pages.")
    VFD_DWG_EnsureKeyedRow ws, "SEED_ID", "MAIN_PWR", _
        Array("ENABLED", "SEED_ID", "DESCRIPTION", "DWG_PATH", "NOTES"), _
        Array("YES", "MAIN_PWR", "Main panel power border", "Template\gen_seed.dwg", _
              "Used by MPWR panel pages.")
    VFD_DWG_FormatDataSheet ws
End Sub

Private Sub VFD_DWG_SetupSheetPlan()
    Dim ws As Worksheet
    Dim planMap As Object
    Dim planRow As Long
    Set ws = VFD_DWG_GetOrCreateSheet(SH_SHEET_PLAN)
    VFD_DWG_EnsureHeaders ws, _
        "ENABLED|PLAN_ID|TYPE_MATCH|PAGE_CODE|PAGE_ORDER|SEED_ID|PRIMARY_CIRCUIT_ID|OUTPUT_SUFFIX|SHEET_PREFIX|TITLE_SUFFIX|DESCRIPTION_TEMPLATE|INSERT_X|INSERT_Y|INSERT_Z|ROTATION_DEG|SCALE|NOTES|MAX_DEVICES_PER_SHEET|LEFT_INSERT_X|LEFT_INSERT_Y|LEFT_INSERT_Z|RIGHT_INSERT_X|RIGHT_INSERT_Y|RIGHT_INSERT_Z|DRAWING_TITLE_TEMPLATE"

    VFD_DWG_EnsureKeyedRow ws, "PLAN_ID", "MOVIFLEX_PWR", _
        Array("ENABLED", "PLAN_ID", "TYPE_MATCH", "PAGE_CODE", "PAGE_ORDER", "SEED_ID", "PRIMARY_CIRCUIT_ID", "OUTPUT_SUFFIX", "SHEET_PREFIX", "TITLE_SUFFIX", "DESCRIPTION_TEMPLATE", "INSERT_X", "INSERT_Y", "INSERT_Z", "ROTATION_DEG", "SCALE", "NOTES", "MAX_DEVICES_PER_SHEET", "LEFT_INSERT_X", "LEFT_INSERT_Y", "LEFT_INSERT_Z", "RIGHT_INSERT_X", "RIGHT_INSERT_Y", "RIGHT_INSERT_Z", "DRAWING_TITLE_TEMPLATE"), _
        Array("YES", "MOVIFLEX_PWR", "MOVI-FLEXIBLE", "PWR", 1, "VFD_STANDARD", "MOVIFLEX", "-PWR", "PWR", "Power Circuit", "{TYPE} power circuit for {PANEL}: {SIS_ELEMENT_NUMBER} {RIGHT_SIS_ELEMENT_NUMBER}", 0, 0, 0, 0, 1, "Two VFD power circuits per PWR sheet. Coordinates come from Circuit Library/Config unless VFD_USE_SHEET_PLAN_COORDINATES=YES.", 2, "", "", "", "", "", "", "PWR - Drawing ONLY")

    VFD_DWG_EnsureKeyedRow ws, "PLAN_ID", "MOVIFLEX_IO", _
        Array("ENABLED", "PLAN_ID", "TYPE_MATCH", "PAGE_CODE", "PAGE_ORDER", "SEED_ID", "PRIMARY_CIRCUIT_ID", "OUTPUT_SUFFIX", "SHEET_PREFIX", "TITLE_SUFFIX", "DESCRIPTION_TEMPLATE", "INSERT_X", "INSERT_Y", "INSERT_Z", "ROTATION_DEG", "SCALE", "NOTES", "MAX_DEVICES_PER_SHEET", "LEFT_INSERT_X", "LEFT_INSERT_Y", "LEFT_INSERT_Z", "RIGHT_INSERT_X", "RIGHT_INSERT_Y", "RIGHT_INSERT_Z", "DRAWING_TITLE_TEMPLATE"), _
        Array("YES", "MOVIFLEX_IO", "MOVI-FLEXIBLE", "IO", 2, "VFD_MOVI_IO", "MOVIFLEX_IO", "-IO", "IO", "I/O Circuit", "{TYPE} I/O circuit for {PANEL}: {SIS_ELEMENT_NUMBER} {RIGHT_SIS_ELEMENT_NUMBER}", 0, 0, 0, 0, 1, "Two VFD I/O circuits per IO sheet. Coordinates come from Circuit Library/Config unless VFD_USE_SHEET_PLAN_COORDINATES=YES.", 2, "", "", "", "", "", "", "IO - Drawing ONLY")

    VFD_DWG_EnsureKeyedRow ws, "PLAN_ID", "DEFAULT_MAIN", _
        Array("ENABLED", "PLAN_ID", "TYPE_MATCH", "PAGE_CODE", "PAGE_ORDER", "SEED_ID", "PRIMARY_CIRCUIT_ID", "OUTPUT_SUFFIX", "SHEET_PREFIX", "TITLE_SUFFIX", "DESCRIPTION_TEMPLATE", "INSERT_X", "INSERT_Y", "INSERT_Z", "ROTATION_DEG", "SCALE", "NOTES", "MAX_DEVICES_PER_SHEET", "LEFT_INSERT_X", "LEFT_INSERT_Y", "LEFT_INSERT_Z", "RIGHT_INSERT_X", "RIGHT_INSERT_Y", "RIGHT_INSERT_Z", "DRAWING_TITLE_TEMPLATE"), _
        Array("YES", "DEFAULT_MAIN", "*", "MAIN", 100, "VFD_STANDARD", "MOVIFLEX_IO", "", "VFD", "VFD Circuit", "{TYPE} circuit for {PANEL}", 0, 0, 0, 0, 1, "Fallback only when no specific TYPE_MATCH plan exists. Coordinates come from Circuit Library/Config.", 1, "", "", "", "", "", "", "{SIS_ELEMENT_NUMBER} - VFD Circuit")

    'C04.3 canonical link repair. EnsureKeyedRow intentionally preserves existing
    'rows, so force only the identity fields that connect Excel to the AutoLISP.
    Set planMap = VFD_DWG_HeaderMap(ws)
    planRow = VFD_DWG_FindKeyedRow(ws, planMap, "PLAN_ID", "MOVIFLEX_IO")
    If planRow > 0 Then
        VFD_DWG_PutCell ws, planRow, planMap, "PAGE_CODE", "IO"
        VFD_DWG_PutCell ws, planRow, planMap, "SEED_ID", "VFD_MOVI_IO"
        VFD_DWG_PutCell ws, planRow, planMap, "PRIMARY_CIRCUIT_ID", "MOVIFLEX_IO"
        VFD_DWG_PutCell ws, planRow, planMap, "SHEET_PREFIX", "IO"
    End If

    planRow = VFD_DWG_FindKeyedRow(ws, planMap, "PLAN_ID", "MOVIFLEX_PWR")
    If planRow > 0 Then
        VFD_DWG_PutCell ws, planRow, planMap, "PAGE_CODE", "PWR"
        VFD_DWG_PutCell ws, planRow, planMap, "SEED_ID", "VFD_STANDARD"
        VFD_DWG_PutCell ws, planRow, planMap, "PRIMARY_CIRCUIT_ID", "MOVIFLEX"
        VFD_DWG_PutCell ws, planRow, planMap, "SHEET_PREFIX", "PWR"
    End If

    VFD_DWG_SyncDevicesPerSheet ws
    VFD_DWG_FormatDataSheet ws
End Sub

Private Sub VFD_DWG_SetupCircuitLibrary()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetOrCreateSheet(SH_CIRCUITS)
    VFD_DWG_EnsureHeaders ws, _
        "ENABLED|CIRCUIT_ID|DESCRIPTION|DWG_PATH|INSERT_X|INSERT_Y|INSERT_Z|DEFAULT_RIGHT_INSERT_X|DEFAULT_RIGHT_INSERT_Y|DEFAULT_RIGHT_INSERT_Z|ROTATION_DEG|SCALE|EXPLODE_AFTER_INSERT|LAYER|NOTES"

    VFD_DWG_EnsureKeyedRow ws, "CIRCUIT_ID", "MOVIFLEX", _
        Array("ENABLED", "CIRCUIT_ID", "DESCRIPTION", "DWG_PATH", "INSERT_X", "INSERT_Y", "INSERT_Z", "DEFAULT_RIGHT_INSERT_X", "DEFAULT_RIGHT_INSERT_Y", "DEFAULT_RIGHT_INSERT_Z", "ROTATION_DEG", "SCALE", "EXPLODE_AFTER_INSERT", "LAYER", "NOTES"), _
        Array("YES", "MOVIFLEX", "MOVIFLEX preset power circuit", "Circuits\HVI1_SEW_MOVIFLEX_ALL.dwg", 0, 0, 0, "", "", "", 0, 1, "YES", "", "Blank RIGHT X/Y/Z values use VFD_DWG_CONFIG fallbacks.")

    VFD_DWG_EnsureKeyedRow ws, "CIRCUIT_ID", "MOVIFLEX_IO", _
        Array("ENABLED", "CIRCUIT_ID", "DESCRIPTION", "DWG_PATH", "INSERT_X", "INSERT_Y", "INSERT_Z", "DEFAULT_RIGHT_INSERT_X", "DEFAULT_RIGHT_INSERT_Y", "DEFAULT_RIGHT_INSERT_Z", "ROTATION_DEG", "SCALE", "EXPLODE_AFTER_INSERT", "LAYER", "NOTES"), _
        Array("YES", "MOVIFLEX_IO", "MOVIFLEX I/O preset circuit", "Circuits\HVI1_MOVIFLEX_IO.dwg", 0, 0, 0, "", "", "", 0, 1, "YES", "", "Blank RIGHT X/Y/Z values use VFD_DWG_CONFIG fallbacks.")

    VFD_DWG_EnsureKeyedRow ws, "CIRCUIT_ID", "MAIN_PWR_6", _
        Array("ENABLED", "CIRCUIT_ID", "DESCRIPTION", "DWG_PATH", "INSERT_X", "INSERT_Y", "INSERT_Z", "DEFAULT_RIGHT_INSERT_X", "DEFAULT_RIGHT_INSERT_Y", "DEFAULT_RIGHT_INSERT_Z", "ROTATION_DEG", "SCALE", "EXPLODE_AFTER_INSERT", "LAYER", "NOTES"), _
        Array("YES", "MAIN_PWR_6", "RCP panel power group", "Circuits\HVI1_SL0103-001-0002_480V_SWG.dwg", 0, 0, 0, "", "", "", 0, 1, "YES", "", "MPWR is unaffected by BLOCK_EDIT; blank RIGHT coordinates use config fallback if this circuit is used on a paired page.")

    VFD_DWG_FormatDataSheet ws
End Sub

Private Sub VFD_DWG_SetupCircuitPlacement()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetOrCreateSheet(SH_CIRCUIT_PLACEMENT)
    VFD_DWG_EnsureHeaders ws, _
        "ENABLED|DRAWING_ID|PLAN_ID|PAGE_CODE|CIRCUIT_INSTANCE|CIRCUIT_ID|INSERT_X|INSERT_Y|INSERT_Z|ROTATION_DEG|SCALE|EXPLODE_AFTER_INSERT|LAYER|NOTES"

    VFD_DWG_EnsureKeyedRow ws, "CIRCUIT_INSTANCE", "EXAMPLE-AUX-01", _
        Array("ENABLED", "DRAWING_ID", "PLAN_ID", "PAGE_CODE", "CIRCUIT_INSTANCE", "CIRCUIT_ID", "INSERT_X", "INSERT_Y", "INSERT_Z", "ROTATION_DEG", "SCALE", "EXPLODE_AFTER_INSERT", "LAYER", "NOTES"), _
        Array("NO", "", "", "PWR", "EXAMPLE-AUX-01", "MOVIFLEX_IO", 15, 0, 0, 0, 1, "", "", "Disabled example: adds another full circuit to every PWR page.")
    VFD_DWG_FormatDataSheet ws
End Sub

Private Sub VFD_DWG_SetupDeviceLibrary()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetOrCreateSheet(SH_DEVICES)
    VFD_DWG_EnsureHeaders ws, _
        "ENABLED|DEVICE_TYPE|DESCRIPTION|DWG_PATH|BLOCK_NAME|LEFT_X_OFFSET|LEFT_Y_OFFSET|LEFT_Z_OFFSET|LEFT_ROTATION_DEG|LEFT_SCALE|RIGHT_X_OFFSET|RIGHT_Y_OFFSET|RIGHT_Z_OFFSET|RIGHT_ROTATION_DEG|RIGHT_SCALE|EXPLODE_AFTER_INSERT|LAYER|PRIMARY_TAG_ATTRIBUTE|TAG_SUFFIX|NOTES"

    VFD_DWG_EnsureDeviceRow ws, "ENCODER", "Encoder device/location block", "Devices\Encoder.dwg", "ENC"
    VFD_DWG_EnsureDeviceRow ws, "PHOTO_EYE", "Photo-eye device/location block", "Devices\PhotoEye.dwg", "PE"
    VFD_DWG_EnsureDeviceRow ws, "BRAKE", "Brake device/location block", "Devices\Brake.dwg", "BRK"
    VFD_DWG_EnsureDeviceRow ws, "MOTOR", "Motor device/location block", "Devices\Motor.dwg", "MOT"
    VFD_DWG_FormatDataSheet ws
End Sub

Private Sub VFD_DWG_SetupDevicePlacement()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetOrCreateSheet(SH_DEVICE_PLACEMENT)
    VFD_DWG_EnsureHeaders ws, _
        "ENABLED|DRAWING_ID|PLAN_ID|PAGE_CODE|TARGET_VFD|TARGET_SIDE|DEVICE_INSTANCE|DEVICE_TYPE|LOCATOR_TEXT|LOCATOR_LAYER|REMOVE_LOCATOR_AFTER_INSERT|DWG_PATH_OVERRIDE|X_OFFSET|Y_OFFSET|Z_OFFSET|ROTATION_DEG|SCALE|LAYER|SIS_SEQUENCE|SIS_ELEMENT_NUMBER|DEVICE_TAG|FUNCTION_TEXT|TERMINAL_IN|TERMINAL_OUT|NOTES|DEVICE_SLOT|POSITION_MODE|INSERT_X|INSERT_Y|INSERT_Z|OVERRIDE_ACTION"

    VFD_DWG_EnsureKeyedRow ws, "DEVICE_INSTANCE", "ENC-01", _
        Array("ENABLED", "DRAWING_ID", "PLAN_ID", "PAGE_CODE", "TARGET_VFD", "TARGET_SIDE", "DEVICE_INSTANCE", "DEVICE_TYPE", "LOCATOR_TEXT", "LOCATOR_LAYER", "REMOVE_LOCATOR_AFTER_INSERT", "X_OFFSET", "Y_OFFSET", "Z_OFFSET", "ROTATION_DEG", "SCALE", "DEVICE_TAG", "FUNCTION_TEXT", "NOTES", "POSITION_MODE", "INSERT_X", "INSERT_Y", "INSERT_Z"), _
        Array("NO", "", "", "IO", "", "", "ENC-01", "ENCODER", "LP_SLOT_ENCODER", DEFAULT_LOCATOR_LAYER, "YES", 10, 0, 0, 0, 1, "ENC-01", "Encoder", "Disabled example. OFFSET uses locator/circuit plus offsets; ABSOLUTE uses INSERT_X/Y/Z as final coordinates.", "OFFSET", "", "", "")
    VFD_DWG_FormatDataSheet ws
End Sub

Private Sub VFD_DWG_SetupBlockEdit()
    Dim ws As Worksheet
    Dim defaults As Variant
    Dim r As Long, c As Long, lastBlockRow As Long

    Set ws = VFD_DWG_GetOrCreateSheet(SH_BLOCK_EDIT)

    'Preserve the existing worksheet layout, shapes, and instructions.
    'The exact data-table header begins on row 4.
    ws.Range("A4:G4").value = Array("BLOCK-DESC", "BLOCK", "TAG1", "RATING1", "RATING2", "DESC1", "DESC2")
    VFD_DWG_StyleHeader ws.Range("A4:G4")

    lastBlockRow = ws.Cells(ws.rows.count, 2).End(xlUp).Row
    If lastBlockRow < 5 Then
        defaults = Array( _
            Array("VFD DRIVE", "HDR11_001_SEW_3DSC", "SIS_sequence", "LOAD [AMPS]", "", "TYPE", "SIS_Element_Number"), _
            Array("STO IN", "HA1X3Y", "", "", "", "STO", "STO_FROM_TEXT"), _
            Array("CABLE TO VFD", "HW01_5", "[CBL-]SIS_NUMBER", "", "", "", ""), _
            Array("BRAKE RESISTOR", "HDV1T6", "SIS_sequence - BW1", "", "", "DYNAMIC BRAKE RESISTOR", ""), _
            Array("CABLE - MOTOR", "HW01", "[CBL-]SIS_NUMBER", "", "", "", ""), _
            Array("ARROW", "HA1X1", "", "", "", "NET", ""), _
            Array("ARROW", "HA1X1", "", "", "", "NET OUT", ""), _
            Array("VFD", "HDR1_001_MOVIFLEX", "SIS_NUMBER", "", "", "TYPE", ""), _
            Array("MOTOR", "HMO13", "[MOT-]SIS_SEQUENCE", "LOAD [AMPS]", "", "", ""))

        For r = LBound(defaults) To UBound(defaults)
            For c = LBound(defaults(r)) To UBound(defaults(r))
                ws.Cells(r + 5, c + 1).value = defaults(r)(c)
            Next c
        Next r
    End If

    VFD_DWG_UpdateSTOBlockEditRow ws

    ws.Columns("A").columnWidth = 24
    ws.Columns("B").columnWidth = 30
    ws.Columns("C:G").columnWidth = 22
    ws.Range("A4:G" & Application.Max(13, ws.Cells(ws.rows.count, 2).End(xlUp).Row)).VerticalAlignment = xlCenter
End Sub

Private Sub VFD_DWG_UpdateSTOBlockEditRow(ByVal ws As Worksheet)
    'Keeps the exact HA1X3Y STO attribute rule synchronized with the IO-device backfill.
    Dim lastRow As Long, r As Long
    lastRow = ws.Cells(ws.rows.count, 2).End(xlUp).Row

    For r = 5 To lastRow
        If StrComp(Trim$(CStr(ws.Cells(r, 2).Value2)), "HA1X3Y", vbTextCompare) = 0 Or _
           StrComp(Trim$(CStr(ws.Cells(r, 1).Value2)), "STO IN", vbTextCompare) = 0 Then
            ws.Cells(r, 1).Value2 = "STO IN"
            ws.Cells(r, 2).Value2 = "HA1X3Y"
            ws.Cells(r, 6).Value2 = "STO"
            ws.Cells(r, 7).Value2 = "STO_FROM_TEXT"
            Exit Sub
        End If
    Next r

    r = Application.Max(5, lastRow + 1)
    ws.Cells(r, 1).Value2 = "STO IN"
    ws.Cells(r, 2).Value2 = "HA1X3Y"
    ws.Cells(r, 6).Value2 = "STO"
    ws.Cells(r, 7).Value2 = "STO_FROM_TEXT"
End Sub

Private Sub VFD_DWG_SetupAttributeMap()
    Dim ws As Worksheet
    Dim map As Object
    Dim r As Long, lastRow As Long, scopeText As String

    Set ws = VFD_DWG_GetOrCreateSheet(SH_ATTRMAP)
    VFD_DWG_EnsureHeaders ws, _
        "ENABLED|SCOPE|TARGET_BLOCK_PATTERN|ATTRIBUTE_TAG|SOURCE_HEADER|STATIC_VALUE|NOTES"

    'V3.5 safety rule: circuit/device blocks are controlled only by BLOCK_EDIT.
    'Remove legacy broad maps so a future setup/refresh cannot re-enable them.
    Set map = VFD_DWG_HeaderMap(ws)
    lastRow = VFD_DWG_LastDataRow(ws)
    For r = lastRow To 2 Step -1
        scopeText = UCase$(Trim$(VFD_DWG_CellText(ws, r, map, "SCOPE")))
        If scopeText = "CIRCUIT" Or scopeText = "DEVICE" Then
            ws.rows(r).Delete
        End If
    Next r

    VFD_DWG_EnsureMapRow ws, "TITLEBLOCK", "*", "SHEET_NUMBER", "SHEET_NUMBER"
    VFD_DWG_EnsureMapRow ws, "TITLEBLOCK", "*", "DRAWING_TITLE", "DRAWING_TITLE"
    VFD_DWG_EnsureMapRow ws, "TITLEBLOCK", "*", "DRAWING_DESCRIPTION", "DRAWING_DESCRIPTION"
    VFD_DWG_FormatDataSheet ws
End Sub

Private Sub VFD_DWG_SetupQueue()
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetOrCreateSheet(SH_QUEUE)

    VFD_DWG_EnsureHeaders ws, _
        "ENABLED|DRAWING_ID|PARENT_DRAWING_ID|PLAN_ID|PAGE_CODE|PAGE_ORDER|SOURCE_SHEET|SOURCE_ROW|" & _
        "OUTPUT_DWG_NAME|SEED_ID|CIRCUIT_ID|SIS_ELEMENT_NUMBER|SIS_SEQUENCE|AREA_NUMBER|SWITCHGROUP|TYPE|PANEL|" & _
        "LOAD|BLOCK|TERMINAL_IN|TERMINAL_OUT|POWER_BUS_2|POWER_TERMINAL|INSIDE_PSU_TERM|LP_BUS_IN|LP_BUS_OUT|LP_BUS2_OUT|" & _
        "NET_TERMINAL_IN|NET_TERMINAL_OUT|BLOCK_IO|BUS_1_IN|BUS_1_OUT|BUS_2_IN|BUS_2_OUT|CIRCUIT_INSERT_X|CIRCUIT_INSERT_Y|" & _
        "CIRCUIT_INSERT_Z|CIRCUIT_ROTATION_DEG|CIRCUIT_SCALE|SHEET_NUMBER|DRAWING_TITLE|DRAWING_DESCRIPTION|" & _
        "STATUS|OUTPUT_PATH|LAST_RUN|NOTES|DEVICE_COUNT|DEVICE_FOLDER_NAME|RIGHT_SOURCE_ROW|RIGHT_CIRCUIT_ID|" & _
        "RIGHT_SIS_ELEMENT_NUMBER|RIGHT_SIS_SEQUENCE|RIGHT_AREA_NUMBER|RIGHT_SWITCHGROUP|RIGHT_TYPE|RIGHT_PANEL|" & _
        "RIGHT_LOAD|RIGHT_BLOCK|RIGHT_TERMINAL_IN|RIGHT_TERMINAL_OUT|RIGHT_POWER_BUS_2|RIGHT_POWER_TERMINAL|" & _
        "RIGHT_INSIDE_PSU_TERM|RIGHT_LP_BUS_IN|RIGHT_LP_BUS_OUT|RIGHT_LP_BUS2_OUT|RIGHT_NET_TERMINAL_IN|RIGHT_NET_TERMINAL_OUT|" & _
        "RIGHT_BLOCK_IO|RIGHT_BUS_1_IN|RIGHT_BUS_1_OUT|RIGHT_BUS_2_IN|RIGHT_BUS_2_OUT|RIGHT_CIRCUIT_INSERT_X|RIGHT_CIRCUIT_INSERT_Y|" & _
        "RIGHT_CIRCUIT_INSERT_Z|RIGHT_CIRCUIT_ROTATION_DEG|RIGHT_CIRCUIT_SCALE|" & _
        "MOTOR_POWER_MAIN_DRIVE|NETWORK_IP|LPN|LOAD_BUS_1|LOAD_BUS_2|NETWORK_PANEL|NETWORK_SWITCH|" & _
        "NETWORK_PORT|NETWORK_ROUTE|NETWORK_FROM|NETWORK_TO|NETWORK_SOURCE_SHEET|NETWORK_DEVICE_REFERENCE|" & _
        "POWER_24V_SOURCE_SHEET|POWER_24V_BUS_1_PSU|POWER_24V_BUS_1_TERMINAL|POWER_24V_BUS_2_PSU|" & _
        "POWER_24V_BUS_2_TERMINAL|PD6_SOURCE_ROW|PD6_BUS_POWER|PD6_POWER_SUPPLY|PD6_POWER_BUS_1_TERMINAL|" & _
        "PD6_POWER_BUS_2_TERMINAL|RIGHT_MOTOR_POWER_MAIN_DRIVE|RIGHT_NETWORK_IP|RIGHT_LPN|RIGHT_LOAD_BUS_1|" & _
        "RIGHT_LOAD_BUS_2|RIGHT_NETWORK_PANEL|RIGHT_NETWORK_SWITCH|RIGHT_NETWORK_PORT|RIGHT_NETWORK_ROUTE|" & _
        "RIGHT_NETWORK_FROM|RIGHT_NETWORK_TO|RIGHT_NETWORK_SOURCE_SHEET|RIGHT_NETWORK_DEVICE_REFERENCE|" & _
        "RIGHT_POWER_24V_SOURCE_SHEET|RIGHT_POWER_24V_BUS_1_PSU|RIGHT_POWER_24V_BUS_1_TERMINAL|" & _
        "RIGHT_POWER_24V_BUS_2_PSU|RIGHT_POWER_24V_BUS_2_TERMINAL|RIGHT_PD6_SOURCE_ROW|RIGHT_PD6_BUS_POWER|" & _
        "RIGHT_PD6_POWER_SUPPLY|RIGHT_PD6_POWER_BUS_1_TERMINAL|RIGHT_PD6_POWER_BUS_2_TERMINAL"

    'STO fields are appended separately to remain below VBA's physical-line continuation limit.
    VFD_DWG_EnsureHeaders ws, _
        "STO_SOURCE_SHEET|STO_SOURCE_ROWS|STO_BLOCK_ID|STO_IO_BLOCK|STO_CHANNEL_IO|STO_PORT_LOCATION|" & _
        "STO_FROM_TEXT|STO_MATCH_STATUS|RIGHT_STO_SOURCE_SHEET|RIGHT_STO_SOURCE_ROWS|RIGHT_STO_BLOCK_ID|" & _
        "RIGHT_STO_IO_BLOCK|RIGHT_STO_CHANNEL_IO|RIGHT_STO_PORT_LOCATION|RIGHT_STO_FROM_TEXT|RIGHT_STO_MATCH_STATUS"

    VFD_DWG_FormatQueue ws
End Sub

'====================================================================================
' SETUP HELPERS
'====================================================================================

Private Sub VFD_DWG_EnsureConfigRow(ByVal ws As Worksheet, ByVal settingName As String, _
                                    ByVal defaultValue As Variant, ByVal requiredText As String, _
                                    ByVal descriptionText As String)
    VFD_DWG_EnsureKeyedRow ws, "SETTING", settingName, _
        Array("SETTING", "VALUE", "REQUIRED", "DESCRIPTION"), _
        Array(settingName, defaultValue, requiredText, descriptionText)
End Sub

Private Sub VFD_DWG_SetConfigValue(ByVal ws As Worksheet, ByVal settingName As String, ByVal settingValue As Variant)
    Dim map As Object, r As Long, lastRow As Long
    Set map = VFD_DWG_HeaderMap(ws)
    lastRow = VFD_DWG_LastDataRow(ws)

    For r = 2 To lastRow
        If StrComp(VFD_DWG_CellText(ws, r, map, "SETTING"), settingName, vbTextCompare) = 0 Then
            VFD_DWG_PutCell ws, r, map, "VALUE", settingValue
            Exit Sub
        End If
    Next r
End Sub

Private Sub VFD_DWG_EnsureDeviceRow(ByVal ws As Worksheet, ByVal deviceType As String, _
                                    ByVal descriptionText As String, ByVal pathText As String, _
                                    ByVal tagSuffix As String)
    VFD_DWG_EnsureKeyedRow ws, "DEVICE_TYPE", deviceType, _
        Array("ENABLED", "DEVICE_TYPE", "DESCRIPTION", "DWG_PATH", _
              "LEFT_X_OFFSET", "LEFT_Y_OFFSET", "LEFT_Z_OFFSET", "LEFT_ROTATION_DEG", "LEFT_SCALE", _
              "RIGHT_X_OFFSET", "RIGHT_Y_OFFSET", "RIGHT_Z_OFFSET", "RIGHT_ROTATION_DEG", "RIGHT_SCALE", _
              "EXPLODE_AFTER_INSERT", "PRIMARY_TAG_ATTRIBUTE", "TAG_SUFFIX", "NOTES"), _
        Array("NO", deviceType, descriptionText, pathText, _
              0, 0, 0, 0, 1, _
              0, 0, 0, 0, 1, _
              "NO", "TAG1", tagSuffix, _
              "Enable only after the DWG path/block and LEFT/RIGHT device placement are configured.")
End Sub

Private Sub VFD_DWG_EnsureMapRow(ByVal ws As Worksheet, ByVal scopeText As String, _
                                 ByVal blockPattern As String, ByVal attributeTag As String, _
                                 ByVal sourceHeader As String)
    Dim map As Object, r As Long, lastRow As Long, found As Boolean
    Set map = VFD_DWG_HeaderMap(ws)
    lastRow = VFD_DWG_LastDataRow(ws)

    For r = 2 To lastRow
        If StrComp(VFD_DWG_CellText(ws, r, map, "SCOPE"), scopeText, vbTextCompare) = 0 And _
           StrComp(VFD_DWG_CellText(ws, r, map, "TARGET_BLOCK_PATTERN"), blockPattern, vbTextCompare) = 0 And _
           StrComp(VFD_DWG_CellText(ws, r, map, "ATTRIBUTE_TAG"), attributeTag, vbTextCompare) = 0 Then
            found = True
            Exit For
        End If
    Next r

    If Not found Then
        r = lastRow + 1
        If r < 2 Then r = 2
        VFD_DWG_PutCell ws, r, map, "ENABLED", "YES"
        VFD_DWG_PutCell ws, r, map, "SCOPE", scopeText
        VFD_DWG_PutCell ws, r, map, "TARGET_BLOCK_PATTERN", blockPattern
        VFD_DWG_PutCell ws, r, map, "ATTRIBUTE_TAG", attributeTag
        VFD_DWG_PutCell ws, r, map, "SOURCE_HEADER", sourceHeader
    ElseIf Len(VFD_DWG_CellText(ws, r, map, "SOURCE_HEADER")) = 0 Then
        VFD_DWG_PutCell ws, r, map, "SOURCE_HEADER", sourceHeader
    End If
End Sub

Private Sub VFD_DWG_EnsureKeyedRow(ByVal ws As Worksheet, ByVal keyHeader As String, _
                                   ByVal keyValue As String, ByVal headers As Variant, _
                                   ByVal values As Variant)
    Dim map As Object, r As Long, lastRow As Long, targetRow As Long, i As Long, col As Long
    Dim currentValue As Variant
    Set map = VFD_DWG_HeaderMap(ws)
    lastRow = VFD_DWG_LastDataRow(ws)

    For r = 2 To lastRow
        If StrComp(VFD_DWG_CellText(ws, r, map, keyHeader), keyValue, vbTextCompare) = 0 Then
            targetRow = r
            Exit For
        End If
    Next r

    If targetRow = 0 Then
        targetRow = lastRow + 1
        If targetRow < 2 Then targetRow = 2
    End If

    For i = LBound(headers) To UBound(headers)
        If map.Exists(VFD_DWG_NormalizeHeader(CStr(headers(i)))) Then
            col = CLng(map(VFD_DWG_NormalizeHeader(CStr(headers(i)))))
            currentValue = ws.Cells(targetRow, col).Value2
            If IsError(currentValue) Or IsEmpty(currentValue) Or IsNull(currentValue) Then
                ws.Cells(targetRow, col).Value2 = values(i)
            ElseIf Len(Trim$(CStr(currentValue))) = 0 Then
                ws.Cells(targetRow, col).Value2 = values(i)
            End If
        End If
    Next i
End Sub

Private Sub VFD_DWG_EnsureHeaders(ByVal ws As Worksheet, ByVal headerList As String)
    Dim map As Object, headers As Variant, h As Variant, lastCol As Long
    Set map = VFD_DWG_HeaderMap(ws)
    headers = Split(headerList, "|")
    lastCol = VFD_DWG_LastDataCol(ws)

    For Each h In headers
        If Not map.Exists(VFD_DWG_NormalizeHeader(CStr(h))) Then
            lastCol = lastCol + 1
            ws.Cells(1, lastCol).value = CStr(h)
            map.Add VFD_DWG_NormalizeHeader(CStr(h)), lastCol
        End If
    Next h

    VFD_DWG_StyleHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, VFD_DWG_LastDataCol(ws)))
End Sub

'====================================================================================
' GENERIC DATA HELPERS
'====================================================================================

Private Function VFD_DWG_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set VFD_DWG_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function VFD_DWG_GetOrCreateSheet(ByVal sheetName As String) As Worksheet
    Set VFD_DWG_GetOrCreateSheet = VFD_DWG_GetSheet(sheetName)
    If VFD_DWG_GetOrCreateSheet Is Nothing Then
        Set VFD_DWG_GetOrCreateSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        VFD_DWG_GetOrCreateSheet.Name = sheetName
    End If
End Function

Private Sub VFD_DWG_OpenSheet(ByVal sheetName As String)
    Dim ws As Worksheet
    Set ws = VFD_DWG_GetSheet(sheetName)
    If ws Is Nothing Then
        VFD_DWG_SetupAllSheets
        Set ws = VFD_DWG_GetSheet(sheetName)
    End If
    ws.Visible = xlSheetVisible
    ws.Activate
    ws.Range("A1").Select
End Sub

Private Function VFD_DWG_HeaderMap(ByVal ws As Worksheet) As Object
    Dim d As Object, lastCol As Long, c As Long, key As String
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    lastCol = VFD_DWG_LastDataCol(ws)
    For c = 1 To lastCol
        key = VFD_DWG_NormalizeHeader(CStr(ws.Cells(1, c).Value2))
        If Len(key) > 0 And Not d.Exists(key) Then d.Add key, c
    Next c
    Set VFD_DWG_HeaderMap = d
End Function

Private Function VFD_DWG_NormalizeHeader(ByVal textValue As String) As String
    Dim s As String
    s = UCase$(Trim$(textValue))
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    s = Replace(s, "-", "_")
    s = Replace(s, "(", "")
    s = Replace(s, ")", "")
    Do While InStr(s, "  ") > 0: s = Replace(s, "  ", " "): Loop
    s = Replace(s, " ", "_")
    Do While InStr(s, "__") > 0: s = Replace(s, "__", "_"): Loop
    VFD_DWG_NormalizeHeader = s
End Function

Private Function VFD_DWG_LastDataRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                          LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If f Is Nothing Then VFD_DWG_LastDataRow = 1 Else VFD_DWG_LastDataRow = f.Row
End Function

Private Function VFD_DWG_LastDataCol(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                          LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If f Is Nothing Then VFD_DWG_LastDataCol = 0 Else VFD_DWG_LastDataCol = f.Column
End Function

Private Function VFD_DWG_CellValue(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                   ByVal map As Object, ByVal headerName As String) As Variant
    Dim key As String
    key = VFD_DWG_NormalizeHeader(headerName)
    If map.Exists(key) Then
        VFD_DWG_CellValue = ws.Cells(rowNumber, CLng(map(key))).Value2
    Else
        VFD_DWG_CellValue = Empty
    End If
End Function

Private Function VFD_DWG_CellText(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                  ByVal map As Object, ByVal headerName As String) As String
    Dim v As Variant
    v = VFD_DWG_CellValue(ws, rowNumber, map, headerName)
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then
        VFD_DWG_CellText = vbNullString
    Else
        VFD_DWG_CellText = Trim$(CStr(v))
    End If
End Function

Private Sub VFD_DWG_PutCell(ByVal ws As Worksheet, ByVal rowNumber As Long, ByVal map As Object, _
                            ByVal headerName As String, ByVal value As Variant)
    Dim key As String
    key = VFD_DWG_NormalizeHeader(headerName)
    If map.Exists(key) Then ws.Cells(rowNumber, CLng(map(key))).Value2 = value
End Sub

Private Sub VFD_DWG_SetRowValue(ByRef rowData As Variant, ByVal map As Object, _
                                ByVal headerName As String, ByVal value As Variant)
    Dim key As String
    key = VFD_DWG_NormalizeHeader(headerName)
    If map.Exists(key) Then rowData(CLng(map(key))) = value
End Sub

Private Function VFD_DWG_FirstSourceValue(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                          ByVal map As Object, ByVal headerChoices As Variant) As Variant
    Dim h As Variant, v As Variant
    For Each h In headerChoices
        If map.Exists(VFD_DWG_NormalizeHeader(CStr(h))) Then
            v = ws.Cells(rowNumber, CLng(map(VFD_DWG_NormalizeHeader(CStr(h))))).Value2
            If Not IsError(v) And Not IsEmpty(v) And Not IsNull(v) Then
                If Len(Trim$(CStr(v))) > 0 Then
                    VFD_DWG_FirstSourceValue = v
                    Exit Function
                End If
            End If
        End If
    Next h
    VFD_DWG_FirstSourceValue = vbNullString
End Function

Private Sub VFD_DWG_RequireHeaders(ByVal map As Object, ByVal requiredHeaders As Variant)
    Dim h As Variant
    For Each h In requiredHeaders
        If Not map.Exists(VFD_DWG_NormalizeHeader(CStr(h))) Then
            Err.Raise vbObjectError + 720, "VFD_DWG_RequireHeaders", "Required header not found: " & CStr(h)
        End If
    Next h
End Sub

Private Function VFD_DWG_DefaultIfBlank(ByVal value As Variant, ByVal defaultValue As Variant) As Variant
    If IsError(value) Or IsEmpty(value) Or IsNull(value) Then
        VFD_DWG_DefaultIfBlank = defaultValue
    ElseIf Len(Trim$(CStr(value))) = 0 Then
        VFD_DWG_DefaultIfBlank = defaultValue
    Else
        VFD_DWG_DefaultIfBlank = value
    End If
End Function

Private Function VFD_DWG_IsYes(ByVal value As String) As Boolean
    Select Case UCase$(Trim$(value))
        Case "YES", "Y", "TRUE", "1", "ON", "ENABLED": VFD_DWG_IsYes = True
    End Select
End Function

Private Function VFD_DWG_QueueKey(ByVal sisElement As String, ByVal rightSisElement As String, _
                                  ByVal planID As String) As String
    VFD_DWG_QueueKey = UCase$(Trim$(sisElement) & "|" & Trim$(rightSisElement) & "|" & Trim$(planID))
End Function

Private Function VFD_DWG_SafeID(ByVal value As String) As String
    Dim i As Long, ch As String, out As String
    value = UCase$(Trim$(value))
    For i = 1 To Len(value)
        ch = mid$(value, i, 1)
        If ch Like "[A-Z0-9_-]" Then out = out & ch Else out = out & "_"
    Next i
    Do While InStr(out, "__") > 0: out = Replace(out, "__", "_"): Loop
    VFD_DWG_SafeID = Trim$(out)
End Function

Private Function VFD_DWG_SafeFileName(ByVal value As String) As String
    Dim invalidChars As Variant, ch As Variant
    invalidChars = Array("<", ">", ":", Chr$(34), "/", "\", "|", "?", "*")
    value = Trim$(value)
    For Each ch In invalidChars: value = Replace(value, CStr(ch), "_"): Next ch
    If LCase$(Right$(value, 4)) <> ".dwg" Then value = value & ".dwg"
    VFD_DWG_SafeFileName = value
End Function

Private Sub VFD_DWG_ParseSISElement(ByVal sisElement As String, ByRef areaNumber As String, _
                                    ByRef switchGroup As String, ByRef sisSequence As String)
    Dim parts As Variant, lastIndex As Long, i As Long, token As String
    parts = Split(Trim$(sisElement), "-")
    areaNumber = vbNullString: switchGroup = vbNullString: sisSequence = vbNullString
    If UBound(parts) >= 0 Then areaNumber = CStr(parts(0))
    If UBound(parts) >= 1 Then switchGroup = CStr(parts(1))
    lastIndex = UBound(parts)
    If lastIndex >= 2 Then
        token = UCase$(CStr(parts(lastIndex)))
        If token Like "K#" Or token Like "K##" Or token Like "K###" Then lastIndex = lastIndex - 1
        For i = 2 To lastIndex
            If Len(sisSequence) > 0 Then sisSequence = sisSequence & "-"
            sisSequence = sisSequence & CStr(parts(i))
        Next i
    End If
End Sub

Private Function VFD_DWG_ExpandTokens(ByVal templateText As String, ByVal sisElement As String, _
                                      ByVal sisSequence As String, ByVal areaNumber As String, _
                                      ByVal switchGroup As String, ByVal vfdType As String, _
                                      ByVal panel As String, ByVal planID As String, _
                                      ByVal pageCode As String, Optional ByVal rightSisElement As String = vbNullString) As String
    Dim s As String
    s = templateText
    s = Replace(s, "{SIS_ELEMENT_NUMBER}", sisElement, 1, -1, vbTextCompare)
    s = Replace(s, "{SIS_SEQUENCE}", sisSequence, 1, -1, vbTextCompare)
    s = Replace(s, "{AREA_NUMBER}", areaNumber, 1, -1, vbTextCompare)
    s = Replace(s, "{SWITCHGROUP}", switchGroup, 1, -1, vbTextCompare)
    s = Replace(s, "{TYPE}", vfdType, 1, -1, vbTextCompare)
    s = Replace(s, "{PANEL}", panel, 1, -1, vbTextCompare)
    s = Replace(s, "{PLAN_ID}", planID, 1, -1, vbTextCompare)
    s = Replace(s, "{PAGE_CODE}", pageCode, 1, -1, vbTextCompare)
    s = Replace(s, "{RIGHT_SIS_ELEMENT_NUMBER}", rightSisElement, 1, -1, vbTextCompare)
    VFD_DWG_ExpandTokens = Trim$(s)
End Function

Private Function VFD_DWG_GetConfigValue(ByVal settingName As String, ByVal defaultValue As Variant) As Variant
    Dim ws As Worksheet, map As Object, r As Long, lastRow As Long
    Set ws = VFD_DWG_GetSheet(SH_CONFIG)
    If ws Is Nothing Then
        VFD_DWG_GetConfigValue = defaultValue
        Exit Function
    End If
    Set map = VFD_DWG_HeaderMap(ws)
    lastRow = VFD_DWG_LastDataRow(ws)
    For r = 2 To lastRow
        If StrComp(VFD_DWG_CellText(ws, r, map, "SETTING"), settingName, vbTextCompare) = 0 Then
            If Len(VFD_DWG_CellText(ws, r, map, "VALUE")) > 0 Then
                VFD_DWG_GetConfigValue = VFD_DWG_CellValue(ws, r, map, "VALUE")
            Else
                VFD_DWG_GetConfigValue = defaultValue
            End If
            Exit Function
        End If
    Next r
    VFD_DWG_GetConfigValue = defaultValue
End Function

'====================================================================================
' FORMATTING / APPLICATION STATE / LOGGING
'====================================================================================

Private Sub VFD_DWG_StyleHeader(ByVal target As Range)
    With target
        .Font.Bold = True
        .Font.Color = vbWhite
        .Interior.Color = RGB(31, 78, 121)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(191, 191, 191)
    End With
End Sub

Private Sub VFD_DWG_FormatConfig(ByVal ws As Worksheet)
    VFD_DWG_FormatDataSheet ws
    ws.Columns("A").columnWidth = 31
    ws.Columns("B").columnWidth = 54
    ws.Columns("C").columnWidth = 12
    ws.Columns("D").columnWidth = 70
End Sub

Private Sub VFD_DWG_FormatQueue(ByVal ws As Worksheet)
    VFD_DWG_FormatDataSheet ws
    ws.rows(1).RowHeight = 34
    ws.Columns.AutoFit
    VFD_DWG_CapColumnWidths ws, 9, 34
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(2, VFD_DWG_LastDataRow(ws)), VFD_DWG_LastDataCol(ws))).AutoFilter
    ws.Activate
    ActiveWindow.FreezePanes = False
    ws.Range("A2").Select
    ActiveWindow.FreezePanes = True
End Sub

Private Sub VFD_DWG_FormatDataSheet(ByVal ws As Worksheet)
    Dim lastRow As Long, lastCol As Long
    lastRow = VFD_DWG_LastDataRow(ws)
    lastCol = VFD_DWG_LastDataCol(ws)
    If lastCol = 0 Then Exit Sub

    VFD_DWG_StyleHeader ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol))
    If lastRow >= 2 Then
        With ws.Range(ws.Cells(2, 1), ws.Cells(lastRow, lastCol))
            .VerticalAlignment = xlTop
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(217, 217, 217)
        End With
    End If
    ws.Columns.AutoFit
    VFD_DWG_CapColumnWidths ws, 9, 55
End Sub

Private Sub VFD_DWG_CapColumnWidths(ByVal ws As Worksheet, ByVal minWidth As Double, ByVal maxWidth As Double)
    Dim c As Long, lastCol As Long
    lastCol = VFD_DWG_LastDataCol(ws)
    For c = 1 To lastCol
        If ws.Columns(c).columnWidth < minWidth Then ws.Columns(c).columnWidth = minWidth
        If ws.Columns(c).columnWidth > maxWidth Then ws.Columns(c).columnWidth = maxWidth
    Next c
End Sub

Private Sub VFD_DWG_BeginFastMode(ByVal statusText As String)
    If mFastModeDepth = 0 Then
        mPrevScreenUpdating = Application.ScreenUpdating
        mPrevEnableEvents = Application.EnableEvents
        mPrevDisplayAlerts = Application.DisplayAlerts
        mPrevCalculation = Application.Calculation
        Application.ScreenUpdating = False
        Application.EnableEvents = False
        Application.DisplayAlerts = False
        Application.Calculation = xlCalculationManual
    End If
    mFastModeDepth = mFastModeDepth + 1
    Application.StatusBar = statusText
End Sub

Private Sub VFD_DWG_EndFastMode()
    If mFastModeDepth > 0 Then mFastModeDepth = mFastModeDepth - 1
    If mFastModeDepth = 0 Then
        Application.ScreenUpdating = mPrevScreenUpdating
        Application.EnableEvents = mPrevEnableEvents
        Application.DisplayAlerts = mPrevDisplayAlerts
        Application.Calculation = mPrevCalculation
        Application.StatusBar = False
    End If
End Sub

Private Sub VFD_DWG_AppendLog(ByVal procedureName As String, ByVal statusText As String, _
                              ByVal detailsText As String)
    Dim ws As Worksheet, outRow As Long
    On Error Resume Next
    Set ws = VFD_DWG_GetOrCreateSheet(SH_PROCESS_LOG)
    If Len(CStr(ws.Cells(1, 1).Value2)) = 0 Then
        ws.Range("A1:D1").value = Array("Timestamp", "Procedure", "Status", "Details")
        VFD_DWG_StyleHeader ws.Range("A1:D1")
    End If
    outRow = VFD_DWG_LastDataRow(ws) + 1
    ws.Cells(outRow, 1).value = Now
    ws.Cells(outRow, 2).value = procedureName
    ws.Cells(outRow, 3).value = statusText
    ws.Cells(outRow, 4).value = detailsText
    ws.Columns("A:D").AutoFit
    On Error GoTo 0
End Sub

