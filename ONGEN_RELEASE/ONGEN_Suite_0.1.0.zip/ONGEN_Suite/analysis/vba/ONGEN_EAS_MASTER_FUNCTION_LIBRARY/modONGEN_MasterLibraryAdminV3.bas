Attribute VB_Name = "modONGEN_MasterLibraryAdminV3"
Option Explicit

' ============================================================================
' Author: Lee Pierre
' Module: modONGEN_MasterLibraryAdminV3
' Release: 3.1.3
' Purpose:
'   Controlled create/edit/bulk-import administration for the central ONGEN
'   Master Function / Part Library.
'
' ENGINEERING IDENTIFIERS
'   PART_KEY             = PK-{PART_TYPE}-{NNNN}
'   DEVICE VARIANT       = DV-{PART_TYPE}-{NNN}
'   FUNCTION_CODE        = CF-{FUNCTION_TYPE}-{NNN}
'   COMPONENT_CODE       = {FUNCTION_CODE}-C{NN}
'
' CENTRAL FUNCTION RULE
'   Master FUNCTION_CODE = PD CONTROL_FUNCTION_NUMBER = Specification code variant
'
' USER / NAVIGATION WORKSHEETS
'   00_LIBRARY_GUIDE (read-only navigation / guide)
'   01_ADD_NEW_PART
'   02_BUILD_FUNCTION_ASSEMBLY
'   03_BULK_PART_IMPORT
'   04_LIBRARY_BROWSER
'   05_CHANGE_REVIEW
'
' SYSTEM WORKSHEETS
'   FUNCTION_MASTER, FUNCTION_COMPONENTS, VARIANT_MASTER, VARIANT_BOM,
'   PART_MASTER, COST_HISTORY, TYPE_CODES, REVISION_HISTORY, CONFIG, IMPORT_LOG
'
' Duplicate key:
'   normalized MANUFACTURER + normalized PART_NUMBER
'
' V3.1.1 workbook controls:
'   - Restores tab-color standard for user, review, guide, and system sheets.
'   - Protects ONLY RED system/database sheets against accidental edits.
'   - BLUE, GREEN, and YELLOW user-facing sheets remain fully unlocked.
'   - Re-applies UserInterfaceOnly protection only to RED system sheets at the start of every button macro.
'
' V3.0.2 full compile hardening:
'   - Corrected CSV quote escaping with a simple quote constant.
'   - Removed reserved-word parameter name Variant.
'   - Removed early-bound Office FileDialog/Shape types and mso constants.
'   - Moved all procedure declarations before executable statements.
'   - Renamed local fixed variable for parser/reference safety.
'   - Added defensive guards around part-selection lookups.
'   - Standardized BOM signature separator to colon.
' ============================================================================

Private Const RELEASE As String = "3.1.3"
Private Const PROTECT_PWD As String = "ONGEN_EAS"
Private Const WS_GUIDE As String = "00_LIBRARY_GUIDE"
Private Const WS_PART_UI As String = "01_ADD_NEW_PART"
Private Const WS_FUNC_UI As String = "02_BUILD_FUNCTION_ASSEMBLY"
Private Const WS_IMPORT As String = "03_BULK_PART_IMPORT"
Private Const WS_BROWSER As String = "04_LIBRARY_BROWSER"
Private Const WS_REVIEW As String = "05_CHANGE_REVIEW"

Private Const WS_FUNCTION As String = "FUNCTION_MASTER"
Private Const WS_COMPONENT As String = "FUNCTION_COMPONENTS"
Private Const WS_VARIANT As String = "VARIANT_MASTER"
Private Const WS_BOM As String = "VARIANT_BOM"
Private Const WS_PART As String = "PART_MASTER"
Private Const WS_COST As String = "COST_HISTORY"
Private Const WS_TYPES As String = "TYPE_CODES"
Private Const WS_REV As String = "REVISION_HISTORY"
Private Const WS_CONFIG As String = "CONFIG"
Private Const WS_IMPORT_LOG As String = "IMPORT_LOG"

Private Const LOOKUP_CSV As String = "ONGEN_FUNCTION_CODE_LOOKUP.csv"

' V3.1.3 user-action navigation state. Every button/action captures the worksheet
' where the user started and returns to it after the action is complete.
Private mONGEN_ReturnSheetName As String
Private mONGEN_RestoreScheduled As Boolean


' =============================== INSTALL =====================================

Public Sub ONGEN_ML3_INSTALL()
    On Error GoTo EH
    Application.ScreenUpdating = False

    ONGEN_ML3_UnprotectWorkbook
    ONGEN_ML3_EnsureSystemHeaders
    ONGEN_ML3_SetupPartSearchUI
    ONGEN_ML3_CreateButtons
    ONGEN_ML3_RefreshBrowser
    ONGEN_ML3_RefreshReview
    ONGEN_ML3_ExportFunctionLookupCSV
    ONGEN_ML3_ApplyWorkbookSecurity

    Application.ScreenUpdating = True
    MsgBox "ONGEN Master Library V" & RELEASE & " controls installed." & vbCrLf & vbCrLf & _
           "Normal workflow:" & vbCrLf & _
           "1. Add/edit individual parts or bulk import a BOM." & vbCrLf & _
           "2. Build/edit a function assembly." & vbCrLf & _
           "3. Save/validate the function." & vbCrLf & _
           "4. Sync PD Master and Specification." & vbCrLf & vbCrLf & _
           "Worksheet colors restored. Only RED system sheets are protected; BLUE/GREEN/YELLOW sheets are unlocked.", vbInformation, "ONGEN Master Library"
    Exit Sub
EH:
    Application.ScreenUpdating = True
    MsgBox "Master Library install failed:" & vbCrLf & Err.Description, vbCritical, "ONGEN Master Library"
End Sub

Public Sub ONGEN_ML3_InitializeOnOpen()
    ' Lightweight workbook-open initialization. No user data is changed.
    On Error Resume Next
    ONGEN_ML3_SetupPartSearchUI
    ONGEN_ML3_CreateButtons
    ONGEN_ML3_ApplyWorkbookSecurity
    On Error GoTo 0
End Sub

Public Sub ONGEN_ML3_RestoreColorsAndProtection()
    On Error GoTo EH
    Application.ScreenUpdating = False
    ONGEN_ML3_UnprotectWorkbook
    ONGEN_ML3_ApplyWorkbookSecurity
    Application.ScreenUpdating = True
    MsgBox "Worksheet colors restored. Only RED system sheets are protected; BLUE/GREEN/YELLOW sheets are unlocked.", vbInformation, "ONGEN Master Library"
    Exit Sub
EH:
    Application.ScreenUpdating = True
    MsgBox "Restore colors/protection failed:" & vbCrLf & Err.Description, vbCritical, "ONGEN Master Library"
End Sub

Private Sub ONGEN_ML3_PrepareWorkbook()
    Dim currentSheetName As String

    ' Capture the worksheet where the user started the button action.
    ' Some Excel operations (sheet protection loops, file dialogs, refreshes) can
    ' change the active worksheet. The scheduled restore runs when Excel is idle
    ' after the current button macro finishes.
    On Error Resume Next
    If ActiveWorkbook Is ThisWorkbook Then currentSheetName = ActiveSheet.Name
    On Error GoTo 0

    If Not mONGEN_RestoreScheduled Then
        If Len(currentSheetName) > 0 Then mONGEN_ReturnSheetName = currentSheetName
        mONGEN_RestoreScheduled = True
        On Error Resume Next
        Application.OnTime EarliestTime:=Now + TimeSerial(0, 0, 1), _
                           Procedure:="'" & Replace(ThisWorkbook.Name, "'", "''") & _
                                      "'!modONGEN_MasterLibraryAdminV3.ONGEN_ML3_RestoreUserSheetAfterAction"
        On Error GoTo 0
    End If

    ONGEN_ML3_ApplyWorkbookSecurity
    ONGEN_ML3_ReturnToWorksheet currentSheetName
End Sub

Public Sub ONGEN_ML3_RestoreUserSheetAfterAction()
    ' Runs after the current user action has completed.
    On Error Resume Next
    If Len(mONGEN_ReturnSheetName) > 0 Then
        ThisWorkbook.Activate
        ThisWorkbook.Worksheets(mONGEN_ReturnSheetName).Activate
    End If
    mONGEN_ReturnSheetName = vbNullString
    mONGEN_RestoreScheduled = False
    On Error GoTo 0
End Sub

Private Sub ONGEN_ML3_ReturnToWorksheet(ByVal sheetName As String)
    If Len(sheetName) = 0 Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Activate
    ThisWorkbook.Worksheets(sheetName).Activate
    On Error GoTo 0
End Sub

Private Sub ONGEN_ML3_UnprotectWorkbook()
    Dim ws As Worksheet
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        ws.Unprotect Password:=PROTECT_PWD
    Next ws
    On Error GoTo 0
End Sub

Private Sub ONGEN_ML3_ApplyWorkbookSecurity()
    Dim ws As Worksheet
    Dim nm As String
    Dim returnSheetName As String

    On Error Resume Next
    If ActiveWorkbook Is ThisWorkbook Then returnSheetName = ActiveSheet.Name
    On Error GoTo 0

    ' V3.1.2 ACCESS STANDARD
    '   BLUE   = guide/navigation        -> UNPROTECTED
    '   GREEN  = engineering work area  -> UNPROTECTED
    '   YELLOW = staging/review/browser -> UNPROTECTED
    '   RED    = system/database        -> PROTECTED
    ' Only RED sheets are locked. This prevents the normal ONGEN buttons from
    ' re-locking the working sheets each time ONGEN_ML3_PrepareWorkbook runs.

    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        nm = ws.Name
        ws.Unprotect Password:=PROTECT_PWD
        ws.EnableSelection = xlNoRestrictions

        Select Case nm
            Case WS_GUIDE
                ws.Tab.Color = RGB(31, 78, 121)          ' Blue - guide / navigation
                ws.Cells.Locked = False

            Case WS_PART_UI, WS_FUNC_UI
                ws.Tab.Color = RGB(112, 173, 71)         ' Green - engineering working sheets
                ws.Cells.Locked = False

            Case WS_IMPORT, WS_BROWSER, WS_REVIEW
                ws.Tab.Color = RGB(255, 192, 0)          ' Yellow - staging / browser / review
                ws.Cells.Locked = False

            Case Else
                ws.Tab.Color = RGB(192, 0, 0)            ' Red - system managed / do not edit
                ws.Cells.Locked = True
                ws.Protect Password:=PROTECT_PWD, _
                           DrawingObjects:=True, _
                           Contents:=True, _
                           Scenarios:=True, _
                           UserInterfaceOnly:=True, _
                           AllowFiltering:=True
        End Select
    Next ws
    On Error GoTo 0
    ONGEN_ML3_ReturnToWorksheet returnSheetName
End Sub

Private Sub ONGEN_ML3_SetupPartSearchUI()
    Dim ui As Worksheet
    On Error Resume Next
    Set ui = ThisWorkbook.Worksheets(WS_PART_UI)
    If ui Is Nothing Then Exit Sub

    ui.Range("A4").Value = "SEARCH FILTERS"
    ui.Range("B4").Value = "Set PART TYPE and/or MANUFACTURER below, then click SEARCH TYPE / MFG."
    ui.Range("C4").Value = "Use C5 / C6"
    ui.Range("E3").Value = "SEARCH RESULTS - TYPE / MANUFACTURER"
    ui.Range("E17:J17").ClearContents
    On Error GoTo 0
End Sub

Public Sub ONGEN_ML3_ButtonDispatcher()
    Dim callerSheetName As String
    Dim buttonName As String

    On Error GoTo EH
    If ActiveWorkbook Is ThisWorkbook Then callerSheetName = ActiveSheet.Name
    buttonName = CStr(Application.Caller)

    Select Case buttonName
        Case "ml3_btnRestoreProtection": ONGEN_ML3_RestoreColorsAndProtection
        Case "ml3_btnSearchPart": ONGEN_ML3_SearchPart
        Case "ml3_btnLoadPart": ONGEN_ML3_LoadSelectedPart
        Case "ml3_btnSavePart": ONGEN_ML3_SavePart
        Case "ml3_btnRetirePart": ONGEN_ML3_RetirePart
        Case "ml3_btnNewPart": ONGEN_ML3_ClearPartForm
        Case "ml3_btnSearchFunction": ONGEN_ML3_SearchFunction
        Case "ml3_btnLoadFunction": ONGEN_ML3_LoadSelectedFunction
        Case "ml3_btnSearchAssemblyPart": ONGEN_ML3_SearchAssemblyPart
        Case "ml3_btnAddAssemblyPart": ONGEN_ML3_AddSelectedPartToAssembly
        Case "ml3_btnRemoveAssemblyPart": ONGEN_ML3_RemoveSelectedAssemblyRow
        Case "ml3_btnValidateAssembly": ONGEN_ML3_ValidateAssembly
        Case "ml3_btnSaveRevision": ONGEN_ML3_SaveFunctionRevision
        Case "ml3_btnCreateNewFunction": ONGEN_ML3_CreateAsNewFunction
        Case "ml3_btnClearFunction": ONGEN_ML3_ClearFunctionForm
        Case "ml3_btnImportParts": ONGEN_ML3_ImportPartsFromWorkbook
        Case "ml3_btnValidateImport": ONGEN_ML3_ValidateBulkImport
        Case "ml3_btnCommitImport": ONGEN_ML3_CommitBulkImport
        Case "ml3_btnClearImport": ONGEN_ML3_ClearBulkStaging
        Case "ml3_btnConfirmTypes": ONGEN_ML3_ConfirmSuggestedTypes
        Case "ml3_btnRefreshBrowser": ONGEN_ML3_RefreshBrowser
        Case "ml3_btnRefreshReview": ONGEN_ML3_RefreshReview
        Case Else
            MsgBox "ONGEN button action is not recognized: " & buttonName, vbExclamation, "ONGEN Master Library"
    End Select

SafeExit:
    ONGEN_ML3_ReturnToWorksheet callerSheetName
    Exit Sub
EH:
    MsgBox "ONGEN button action failed:" & vbCrLf & Err.Description, vbCritical, "ONGEN Master Library"
    Resume SafeExit
End Sub

Private Sub ONGEN_ML3_CreateButtons()
    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(WS_GUIDE)
    ONGEN_ML3_AddButton ws, "ml3_btnRestoreProtection", "RESTORE COLORS / PROTECTION", "ONGEN_ML3_RestoreColorsAndProtection", ws.Range("D3"), 210

    Set ws = ThisWorkbook.Worksheets(WS_PART_UI)
    ONGEN_ML3_AddButton ws, "ml3_btnSearchPart", "SEARCH TYPE / MFG", "ONGEN_ML3_SearchPart", ws.Range("K5"), 160
    ONGEN_ML3_AddButton ws, "ml3_btnLoadPart", "LOAD SELECTED PART", "ONGEN_ML3_LoadSelectedPart", ws.Range("K7"), 160
    ONGEN_ML3_AddButton ws, "ml3_btnSavePart", "SAVE PART", "ONGEN_ML3_SavePart", ws.Range("K9"), 160
    ONGEN_ML3_AddButton ws, "ml3_btnRetirePart", "RETIRE PART", "ONGEN_ML3_RetirePart", ws.Range("K11"), 160
    ONGEN_ML3_AddButton ws, "ml3_btnNewPart", "NEW / CLEAR", "ONGEN_ML3_ClearPartForm", ws.Range("K13"), 160

    Set ws = ThisWorkbook.Worksheets(WS_FUNC_UI)
    ONGEN_ML3_AddButton ws, "ml3_btnSearchFunction", "SEARCH FUNCTION", "ONGEN_ML3_SearchFunction", ws.Range("T3"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnLoadFunction", "LOAD FUNCTION", "ONGEN_ML3_LoadSelectedFunction", ws.Range("T5"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnSearchAssemblyPart", "SEARCH PART", "ONGEN_ML3_SearchAssemblyPart", ws.Range("T7"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnAddAssemblyPart", "ADD SELECTED PART", "ONGEN_ML3_AddSelectedPartToAssembly", ws.Range("T9"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnRemoveAssemblyPart", "REMOVE SELECTED ROW", "ONGEN_ML3_RemoveSelectedAssemblyRow", ws.Range("T11"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnValidateAssembly", "VALIDATE ASSEMBLY", "ONGEN_ML3_ValidateAssembly", ws.Range("T13"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnSaveRevision", "SAVE FUNCTION REVISION", "ONGEN_ML3_SaveFunctionRevision", ws.Range("T15"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnCreateNewFunction", "CREATE AS NEW FUNCTION", "ONGEN_ML3_CreateAsNewFunction", ws.Range("T17"), 175
    ONGEN_ML3_AddButton ws, "ml3_btnClearFunction", "NEW / CLEAR FUNCTION", "ONGEN_ML3_ClearFunctionForm", ws.Range("T19"), 175

    Set ws = ThisWorkbook.Worksheets(WS_IMPORT)
    ONGEN_ML3_AddButton ws, "ml3_btnImportParts", "IMPORT BOM / PRICE LIST", "ONGEN_ML3_ImportPartsFromWorkbook", ws.Range("T3"), 185
    ONGEN_ML3_AddButton ws, "ml3_btnValidateImport", "VALIDATE IMPORT", "ONGEN_ML3_ValidateBulkImport", ws.Range("T5"), 185
    ONGEN_ML3_AddButton ws, "ml3_btnCommitImport", "COMMIT APPROVED ROWS", "ONGEN_ML3_CommitBulkImport", ws.Range("T7"), 185
    ONGEN_ML3_AddButton ws, "ml3_btnClearImport", "CLEAR STAGING", "ONGEN_ML3_ClearBulkStaging", ws.Range("T9"), 185
    ONGEN_ML3_AddButton ws, "ml3_btnConfirmTypes", "CONFIRM VALID TYPES", "ONGEN_ML3_ConfirmSuggestedTypes", ws.Range("T11"), 185

    Set ws = ThisWorkbook.Worksheets(WS_BROWSER)
    ONGEN_ML3_AddButton ws, "ml3_btnRefreshBrowser", "REFRESH BROWSER", "ONGEN_ML3_RefreshBrowser", ws.Range("O3"), 165

    Set ws = ThisWorkbook.Worksheets(WS_REVIEW)
    ONGEN_ML3_AddButton ws, "ml3_btnRefreshReview", "REFRESH REVIEW", "ONGEN_ML3_RefreshReview", ws.Range("J3"), 165
End Sub

Private Sub ONGEN_ML3_AddButton(ByVal ws As Worksheet, ByVal shapeName As String, ByVal caption As String, ByVal macroName As String, ByVal anchor As Range, ByVal widthVal As Double)
    Dim shp As Object
    On Error Resume Next
    ws.Shapes(shapeName).Delete
    On Error GoTo 0
    Set shp = ws.Shapes.AddShape(5, anchor.Left, anchor.Top, widthVal, 28)
    shp.Name = shapeName
    shp.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!modONGEN_MasterLibraryAdminV3.ONGEN_ML3_ButtonDispatcher"
    With shp
        .Fill.ForeColor.RGB = RGB(31, 78, 121)
        .Line.ForeColor.RGB = RGB(20, 55, 90)
        .TextFrame.Characters.Text = caption
        .TextFrame.Characters.Font.Bold = True
        .TextFrame.Characters.Font.Color = RGB(255, 255, 255)
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .Placement = xlMoveAndSize
    End With
End Sub

' =========================== PART CREATE / EDIT ===============================

Public Sub ONGEN_ML3_SearchPart()
    Dim ui As Worksheet, pws As Worksheet
    Dim typeFilter As String, mfgFilter As String
    Dim hdr As Long, cKey As Long, cType As Long, cMfg As Long, cPart As Long, cDesc As Long
    Dim lastRow As Long, r As Long, tr As Long
    Dim rowType As String, rowMfg As String
    Dim matchType As Boolean, matchMfg As Boolean
    Dim matchCount As Long, shownCount As Long
    Const MAX_RESULTS As Long = 12

    ONGEN_ML3_PrepareWorkbook
    On Error GoTo EH
    Set ui = ThisWorkbook.Worksheets(WS_PART_UI)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    ONGEN_ML3_SetupPartSearchUI

    ' Search is intentionally limited to the two most useful engineering filters.
    ' PART TYPE (C5) is an exact match. MANUFACTURER (C6) is a partial match so
    ' typing SEW will also find SEW-EURODRIVE, for example. Either filter may be blank.
    typeFilter = UCase$(Trim$(ONGEN_ML3_CodeToken(ui.Range("C5").Value2)))
    mfgFilter = UCase$(Trim$(CStr(ui.Range("C6").Value2)))

    If Len(typeFilter) = 0 And Len(mfgFilter) = 0 Then
        MsgBox "Enter PART TYPE in C5 and/or MANUFACTURER in C6, then click SEARCH TYPE / MFG." & vbCrLf & vbCrLf & _
               "You do not need to enter Part Number, Description, or Part Key to search for an existing part.", _
               vbExclamation, "Search Existing Part"
        Exit Sub
    End If

    ui.Range("E5:J16").ClearContents
    ui.Range("E17:J17").ClearContents

    cKey = ONGEN_ML3_FindHeaderInTopRows(pws, "PART_KEY", hdr)
    cType = ONGEN_ML3_FindHeaderColumn(pws, "PART_TYPE", hdr)
    cMfg = ONGEN_ML3_FindHeaderColumn(pws, "MANUFACTURER", hdr)
    cPart = ONGEN_ML3_FindHeaderColumn(pws, "PART_NUMBER", hdr)
    cDesc = ONGEN_ML3_FindHeaderColumn(pws, "PART_DESCRIPTION", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(pws)

    tr = 5
    For r = hdr + 1 To lastRow
        rowType = UCase$(Trim$(CStr(ONGEN_ML3_CellValue(pws, r, cType))))
        rowMfg = UCase$(Trim$(CStr(ONGEN_ML3_CellValue(pws, r, cMfg))))

        matchType = (Len(typeFilter) = 0 Or StrComp(rowType, typeFilter, vbTextCompare) = 0)
        matchMfg = (Len(mfgFilter) = 0 Or InStr(1, rowMfg, mfgFilter, vbTextCompare) > 0)

        If matchType And matchMfg Then
            matchCount = matchCount + 1
            If shownCount < MAX_RESULTS Then
                ui.Cells(tr, 5).Value = ""
                ui.Cells(tr, 6).Value = ONGEN_ML3_CellValue(pws, r, cKey)
                ui.Cells(tr, 7).Value = ONGEN_ML3_CellValue(pws, r, cType)
                ui.Cells(tr, 8).Value = ONGEN_ML3_CellValue(pws, r, cMfg)
                ui.Cells(tr, 9).Value = ONGEN_ML3_CellValue(pws, r, cPart)
                ui.Cells(tr, 10).Value = ONGEN_ML3_CellValue(pws, r, cDesc)
                tr = tr + 1
                shownCount = shownCount + 1
            End If
        End If
    Next r

    If matchCount = 0 Then
        ui.Range("E17").Value = "No matches. Change PART TYPE and/or MANUFACTURER and search again."
        MsgBox "No part matched the selected PART TYPE / MANUFACTURER filters.", vbInformation, "Search Existing Part"
    ElseIf matchCount > MAX_RESULTS Then
        ui.Range("E17").Value = "Showing first " & MAX_RESULTS & " of " & matchCount & " matches. Narrow TYPE / MANUFACTURER if needed."
    Else
        ui.Range("E17").Value = "Showing " & matchCount & " matching part(s). Mark X in SELECT or click a result row, then LOAD SELECTED PART."
    End If
    Exit Sub
EH:
    MsgBox "Part search failed:" & vbCrLf & Err.Description, vbCritical
End Sub

Public Sub ONGEN_ML3_LoadSelectedPart()
    Dim ui As Worksheet, pws As Worksheet, selectedRow As Long, partKey As String, pr As Long, hdr As Long
    ONGEN_ML3_PrepareWorkbook
    Set ui = ThisWorkbook.Worksheets(WS_PART_UI)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    selectedRow = ONGEN_ML3_SelectedResultRow(ui, 5, 16, 5)
    If selectedRow = 0 Then
        MsgBox "Mark X in the SELECT column or select a search-result row first.", vbExclamation
        Exit Sub
    End If
    partKey = Trim$(CStr(ui.Cells(selectedRow, 6).Value2))
    pr = ONGEN_ML3_FindPartRowByKey(pws, partKey, hdr)
    If pr = 0 Then MsgBox "Part Key not found in PART_MASTER: " & partKey, vbCritical: Exit Sub

    ui.Range("C3").Value = "EDIT EXISTING PART"
    ui.Range("C5").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PART_TYPE")
    ui.Range("C6").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "MANUFACTURER")
    ui.Range("C7").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PART_NUMBER")
    ui.Range("C8").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PART_DESCRIPTION")
    ui.Range("C9").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "RATING_SIZE")
    ui.Range("C10").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "CURRENT_COST")
    ui.Range("C11").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "COST_CURRENCY")
    ui.Range("C12").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PREFERRED_VENDOR")
    ui.Range("C13").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "NOTES")
    ui.Range("C14").Value = partKey
    ui.Range("C15").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "DEVICE_VARIANT_CODE")
    ui.Range("C16").Value = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "REVISION")
    ui.Range("C17").Value = "LOADED FOR EDIT"
End Sub

Public Sub ONGEN_ML3_SavePart()
    Dim ui As Worksheet, pws As Worksheet, modeText As String
    Dim pType As String, mfg As String, partNo As String, descr As String, rating As String, curr As String, vendor As String, notes As String
    Dim costVal As Variant, partKey As String, variantCode As String, hdr As Long, pr As Long, dupRow As Long
    Dim oldType As String, oldMfg As String, oldPart As String, oldCost As Variant, revision As String

    ONGEN_ML3_PrepareWorkbook
    On Error GoTo EH
    Set ui = ThisWorkbook.Worksheets(WS_PART_UI)
    Set pws = ThisWorkbook.Worksheets(WS_PART)

    modeText = UCase$(Trim$(CStr(ui.Range("C3").Value2)))
    pType = ONGEN_ML3_CodeToken(ui.Range("C5").Value2)
    mfg = Trim$(CStr(ui.Range("C6").Value2))
    partNo = Trim$(CStr(ui.Range("C7").Value2))
    descr = Trim$(CStr(ui.Range("C8").Value2))
    rating = Trim$(CStr(ui.Range("C9").Value2))
    costVal = ui.Range("C10").Value
    curr = UCase$(Trim$(CStr(ui.Range("C11").Value2)))
    If Len(curr) = 0 Then curr = ONGEN_ML3_ConfigValue("DEFAULT_CURRENCY", "USD")
    vendor = Trim$(CStr(ui.Range("C12").Value2))
    notes = Trim$(CStr(ui.Range("C13").Value2))

    If Len(pType) = 0 Or Len(mfg) = 0 Or Len(partNo) = 0 Or Len(descr) = 0 Then
        ui.Range("C17").Value = "ERROR - complete PART TYPE, MANUFACTURER, PART NUMBER, and DESCRIPTION."
        Exit Sub
    End If

    If modeText = "EDIT EXISTING PART" Then
        partKey = Trim$(CStr(ui.Range("C14").Value2))
        If Len(partKey) = 0 Then MsgBox "Load an existing part before saving an edit.", vbExclamation: Exit Sub
        pr = ONGEN_ML3_FindPartRowByKey(pws, partKey, hdr)
        If pr = 0 Then MsgBox "Existing Part Key not found: " & partKey, vbCritical: Exit Sub

        oldType = ONGEN_ML3_CodeToken(ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PART_TYPE"))
        If StrComp(oldType, pType, vbTextCompare) <> 0 Then
            MsgBox "PART_TYPE is part of the generated Part Key identity and cannot be changed on an existing record." & vbCrLf & _
                   "Create a NEW PART instead if this is actually a different product/type.", vbExclamation
            Exit Sub
        End If
        dupRow = ONGEN_ML3_FindExactPartRow(pws, mfg, partNo, hdr)
        If dupRow > 0 And dupRow <> pr Then
            MsgBox "The corrected manufacturer + part number already belongs to another Part Key: " & _
                   ONGEN_ML3_GetAtHeader(pws, dupRow, hdr, "PART_KEY"), vbCritical
            Exit Sub
        End If

        oldMfg = CStr(ONGEN_ML3_GetAtHeader(pws, pr, hdr, "MANUFACTURER"))
        oldPart = CStr(ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PART_NUMBER"))
        oldCost = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "CURRENT_COST")
        revision = ONGEN_ML3_NextRevision(CStr(ONGEN_ML3_GetAtHeader(pws, pr, hdr, "REVISION")))

        ONGEN_ML3_SetAtHeader pws, pr, hdr, "MANUFACTURER", mfg
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "NORMALIZED_MANUFACTURER", ONGEN_ML3_NormalizeManufacturer(mfg)
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "PART_NUMBER", partNo
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "NORMALIZED_PART_NUMBER", ONGEN_ML3_NormalizePartNumber(partNo)
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "PART_DESCRIPTION", descr
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "RATING_SIZE", rating
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "CURRENT_COST", costVal
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "COST_CURRENCY", curr
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "COST_AS_OF_DATE", Date
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "PREFERRED_VENDOR", vendor
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "NOTES", notes
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "REVISION", revision
        ONGEN_ML3_SetAtHeader pws, pr, hdr, "MODIFIED_DATE", Now

        ONGEN_ML3_UpdateVariantBOMPartReference partKey, mfg, partNo
        If ONGEN_ML3_ValueChanged(oldCost, costVal) Then ONGEN_ML3_AppendCostHistory partKey, costVal, curr, vendor, "MANUAL EDIT", 0, "COST UPDATE"
        ONGEN_ML3_AppendRevision "CORRECT PART " & partKey & ": " & oldMfg & " / " & oldPart & " -> " & mfg & " / " & partNo
        ui.Range("C16").Value = revision
        ui.Range("C17").Value = "UPDATED - Part Key and Device Variant were preserved."
    Else
        dupRow = ONGEN_ML3_FindExactPartRow(pws, mfg, partNo, hdr)
        If dupRow > 0 Then
            ui.Range("C14").Value = ONGEN_ML3_GetAtHeader(pws, dupRow, hdr, "PART_KEY")
            ui.Range("C15").Value = ONGEN_ML3_GetAtHeader(pws, dupRow, hdr, "DEVICE_VARIANT_CODE")
            ui.Range("C16").Value = ONGEN_ML3_GetAtHeader(pws, dupRow, hdr, "REVISION")
            ui.Range("C17").Value = "EXISTING PART FOUND - no duplicate created."
            MsgBox "This manufacturer + part number already exists. No duplicate was created.", vbInformation
            Exit Sub
        End If
        ONGEN_ML3_AddNewPartRecord pType, mfg, partNo, descr, rating, costVal, curr, vendor, "", "", "", notes, "MANUAL ENTRY", 0, partKey, variantCode
        ui.Range("C14").Value = partKey
        ui.Range("C15").Value = variantCode
        ui.Range("C16").Value = "A"
        ui.Range("C17").Value = "ADDED"
        ONGEN_ML3_AppendRevision "ADD PART " & partKey
    End If

    ONGEN_ML3_BumpLibraryVersion
    ONGEN_ML3_RefreshBrowser
    ONGEN_ML3_RefreshReview
    Exit Sub
EH:
    MsgBox "Save Part failed:" & vbCrLf & Err.Description, vbCritical
End Sub

Public Sub ONGEN_ML3_RetirePart()
    Dim ui As Worksheet, pws As Worksheet, partKey As String, hdr As Long, pr As Long, ans As VbMsgBoxResult
    ONGEN_ML3_PrepareWorkbook
    Set ui = ThisWorkbook.Worksheets(WS_PART_UI)
    partKey = Trim$(CStr(ui.Range("C14").Value2))
    If Len(partKey) = 0 Then MsgBox "Load the part you want to retire first.", vbExclamation: Exit Sub
    ans = MsgBox("Retire " & partKey & "?" & vbCrLf & "This does not delete historical references.", vbYesNo + vbQuestion)
    If ans <> vbYes Then Exit Sub
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    pr = ONGEN_ML3_FindPartRowByKey(pws, partKey, hdr)
    If pr = 0 Then Exit Sub
    ONGEN_ML3_SetAtHeader pws, pr, hdr, "ACTIVE", "NO"
    ONGEN_ML3_SetAtHeader pws, pr, hdr, "REVISION", ONGEN_ML3_NextRevision(CStr(ONGEN_ML3_GetAtHeader(pws, pr, hdr, "REVISION")))
    ONGEN_ML3_SetAtHeader pws, pr, hdr, "MODIFIED_DATE", Now
    ui.Range("C17").Value = "RETIRED"
    ONGEN_ML3_AppendRevision "RETIRE PART " & partKey
    ONGEN_ML3_BumpLibraryVersion
    ONGEN_ML3_RefreshBrowser
End Sub

Public Sub ONGEN_ML3_ClearPartForm()
    ONGEN_ML3_PrepareWorkbook
    With ThisWorkbook.Worksheets(WS_PART_UI)
        .Range("C3").Value = "NEW PART"
        .Range("C5:C17").ClearContents
        .Range("C3").Value = "NEW PART"
        .Range("E5:J17").ClearContents
    End With
    ONGEN_ML3_SetupPartSearchUI
End Sub

' ============================== BULK IMPORT ==================================

Public Sub ONGEN_ML3_ImportPartsFromWorkbook()
    Dim fd As Object, sourcePath As String, srcWB As Workbook, srcWS As Worksheet
    Dim hdr As Long, cPart As Long, cMfg As Long, cDesc As Long, cCost As Long, cVendor As Long, cGroup As Long, cGroupDesc As Long, cFixed As Long, cInputType As Long
    Dim lastRow As Long, r As Long, tr As Long, p As String, m As String, d As String, pt As String
    Dim costVal As Variant, vendor As String, mg As String, mgd As String, fixedVendorText As String
    Dim seen As Object, key As String, exactRow As Long, pHdr As Long, existingKey As String, existingVariant As String
    Dim status As String, actionText As String, noteText As String
    Dim ui As Worksheet, pws As Worksheet, foundSheet As Boolean
    Dim sourceName As String

    ONGEN_ML3_PrepareWorkbook
    On Error GoTo EH
    Set fd = Application.FileDialog(3)
    With fd
        .Title = "Select BOM / pricing workbook"
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Excel / CSV", "*.xlsx;*.xlsm;*.xls;*.csv"
        If .Show <> -1 Then Exit Sub
        sourcePath = .SelectedItems(1)
    End With

    Application.ScreenUpdating = False
    Set srcWB = Workbooks.Open(sourcePath, UpdateLinks:=0, ReadOnly:=True)
    For Each srcWS In srcWB.Worksheets
        cPart = ONGEN_ML3_FindHeaderByAliasesInTopRows(srcWS, Array("PART NUMBER", "PART_NUMBER", "PART NO", "PART NO.", "MATERIAL", "MATERIAL NUMBER"), hdr)
        If cPart > 0 Then foundSheet = True: Exit For
    Next srcWS
    If Not foundSheet Then Err.Raise vbObjectError + 4001, , "No Part Number header was found in the selected workbook."

    cMfg = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("MANUFACTURER", "MFG", "MANUF", "MANUFACTURER NAME"))
    cDesc = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("DESCRIPTION", "PART DESCRIPTION", "MATERIAL DESCRIPTION"))
    cCost = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("VALUATION PRICE", "CURRENT COST", "COST", "PRICE", "UNIT COST"))
    cVendor = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("VENDOR NAME", "PREFERRED VENDOR", "VENDOR"))
    cGroup = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("MATERIALS GROUP", "MATERIAL GROUP"))
    cGroupDesc = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("MATERIALS GROUP DESC.", "MATERIALS GROUP DESC", "MATERIAL GROUP DESCRIPTION"))
    cFixed = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("FIXED VENDOR", "FIXED_VENDOR"))
    cInputType = ONGEN_ML3_FindHeaderByAliases(srcWS, hdr, Array("PART TYPE", "PART_TYPE", "DEVICE TYPE", "COMPONENT TYPE"))

    Set ui = ThisWorkbook.Worksheets(WS_IMPORT)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    ui.Range("A11:R100000").ClearContents
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    sourceName = Dir$(sourcePath)
    lastRow = srcWS.Cells(srcWS.rows.Count, cPart).End(xlUp).Row
    tr = 11

    For r = hdr + 1 To lastRow
        p = Trim$(CStr(srcWS.Cells(r, cPart).Value2))
        If Len(p) > 0 Then
            m = Trim$(CStr(ONGEN_ML3_CellValue(srcWS, r, cMfg)))
            d = Trim$(CStr(ONGEN_ML3_CellValue(srcWS, r, cDesc)))
            costVal = ONGEN_ML3_CellValue(srcWS, r, cCost)
            vendor = Trim$(CStr(ONGEN_ML3_CellValue(srcWS, r, cVendor)))
            mg = Trim$(CStr(ONGEN_ML3_CellValue(srcWS, r, cGroup)))
            mgd = Trim$(CStr(ONGEN_ML3_CellValue(srcWS, r, cGroupDesc)))
            fixedVendorText = Trim$(CStr(ONGEN_ML3_CellValue(srcWS, r, cFixed)))
            If cInputType > 0 Then
                pt = ONGEN_ML3_CodeToken(ONGEN_ML3_CellValue(srcWS, r, cInputType))
            Else
                pt = ONGEN_ML3_SuggestPartType(d, mgd)
            End If
            key = ONGEN_ML3_NormalizeManufacturer(m) & "|" & ONGEN_ML3_NormalizePartNumber(p)

            exactRow = ONGEN_ML3_FindExactPartRow(pws, m, p, pHdr)
            If seen.Exists(key) Then
                status = "DUP_IN_IMPORT": actionText = "REVIEW": noteText = "Duplicate manufacturer + part number occurs more than once in this import."
            ElseIf exactRow > 0 Then
                status = "EXISTING": actionText = "UPDATE COST ONLY"
                existingKey = CStr(ONGEN_ML3_GetAtHeader(pws, exactRow, pHdr, "PART_KEY"))
                existingVariant = CStr(ONGEN_ML3_GetAtHeader(pws, exactRow, pHdr, "DEVICE_VARIANT_CODE"))
                noteText = "Existing " & existingKey & "; a new Part Key will NOT be created."
            ElseIf ONGEN_ML3_PartNumberExistsUnderDifferentManufacturer(pws, p, m) Then
                status = "REVIEW_MANUFACTURER": actionText = "REVIEW": existingKey = "": existingVariant = ""
                noteText = "Part number already exists under another manufacturer. Verify before commit."
            ElseIf Len(pt) = 0 Or pt = "AUX" Or Not ONGEN_ML3_IsValidPartType(pt) Then
                status = "REVIEW_TYPE": actionText = "REVIEW": existingKey = "": existingVariant = ""
                noteText = "Select/confirm a valid PART_TYPE before commit."
            ElseIf cInputType = 0 Then
                status = "REVIEW_TYPE": actionText = "REVIEW": existingKey = "": existingVariant = ""
                noteText = "PART_TYPE was auto-suggested. Review/adjust it, then set ACTION=ADD NEW or click CONFIRM VALID TYPES."
            Else
                status = "NEW": actionText = "ADD NEW": existingKey = "": existingVariant = ""
                noteText = "Source supplied a valid PART_TYPE; ready to add."
            End If
            If Not seen.Exists(key) Then seen.Add key, 1

            ui.Cells(tr, 1).Value = tr - 10
            ui.Cells(tr, 2).Value = actionText
            ui.Cells(tr, 3).Value = status
            ui.Cells(tr, 4).Value = pt
            ui.Cells(tr, 5).Value = m
            ui.Cells(tr, 6).Value = p
            ui.Cells(tr, 7).Value = d
            ui.Cells(tr, 8).Value = costVal
            ui.Cells(tr, 9).Value = ONGEN_ML3_ConfigValue("DEFAULT_CURRENCY", "USD")
            ui.Cells(tr, 10).Value = vendor
            ui.Cells(tr, 11).Value = mg
            ui.Cells(tr, 12).Value = mgd
            ui.Cells(tr, 13).Value = fixedVendorText
            ui.Cells(tr, 14).Value = existingKey
            ui.Cells(tr, 15).Value = existingVariant
            ui.Cells(tr, 16).Value = noteText
            ui.Cells(tr, 17).Value = sourceName
            ui.Cells(tr, 18).Value = r
            tr = tr + 1
        End If
    Next r

    srcWB.Close SaveChanges:=False
    ONGEN_ML3_ValidateBulkImport False
    ONGEN_ML3_AppendImportLog sourceName, tr - 11, "STAGED"
    Application.ScreenUpdating = True
    MsgBox CStr(tr - 11) & " import rows staged and duplicate-checked." & vbCrLf & _
           "If PART_TYPE was not supplied by the source, review the suggested yellow PART_TYPE values and use CONFIRM VALID TYPES before commit.", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not srcWB Is Nothing Then srcWB.Close SaveChanges:=False
    Application.ScreenUpdating = True
    MsgBox "Bulk import failed:" & vbCrLf & Err.Description, vbCritical
End Sub

Public Sub ONGEN_ML3_ValidateBulkImport(Optional ByVal showMessage As Boolean = True)
    Dim ws As Worksheet, pws As Worksheet, lastRow As Long, r As Long, pHdr As Long, exactRow As Long
    Dim m As String, p As String, pType As String, actionText As String, key As String
    Dim d As Object, st As String, noteText As String, existingKey As String, existingVariant As String
    Dim nNew As Long, nExist As Long, nReview As Long, nDup As Long

    ONGEN_ML3_PrepareWorkbook
    Set ws = ThisWorkbook.Worksheets(WS_IMPORT)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = 11 To lastRow
        p = Trim$(CStr(ws.Cells(r, 6).Value2))
        If Len(p) > 0 Then
            m = Trim$(CStr(ws.Cells(r, 5).Value2))
            pType = ONGEN_ML3_CodeToken(ws.Cells(r, 4).Value2)
            actionText = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
            key = ONGEN_ML3_NormalizeManufacturer(m) & "|" & ONGEN_ML3_NormalizePartNumber(p)
            exactRow = ONGEN_ML3_FindExactPartRow(pws, m, p, pHdr)
            existingKey = "": existingVariant = ""

            If d.Exists(key) Then
                st = "DUP_IN_IMPORT": noteText = "Duplicate in staging; keep only one row or set the extra row to SKIP.": nDup = nDup + 1
            ElseIf exactRow > 0 Then
                st = "EXISTING": existingKey = CStr(ONGEN_ML3_GetAtHeader(pws, exactRow, pHdr, "PART_KEY"))
                existingVariant = CStr(ONGEN_ML3_GetAtHeader(pws, exactRow, pHdr, "DEVICE_VARIANT_CODE"))
                noteText = "Existing " & existingKey & "; no duplicate Part Key will be created.": nExist = nExist + 1
                If actionText = "ADD NEW" Then ws.Cells(r, 2).Value = "UPDATE COST ONLY"
            ElseIf ONGEN_ML3_PartNumberExistsUnderDifferentManufacturer(pws, p, m) Then
                st = "REVIEW_MANUFACTURER": noteText = "Same part number exists under another manufacturer.": nReview = nReview + 1
            ElseIf Len(pType) = 0 Or Not ONGEN_ML3_IsValidPartType(pType) Then
                st = "REVIEW_TYPE": noteText = "Select a valid PART_TYPE.": nReview = nReview + 1
            ElseIf actionText <> "ADD NEW" Then
                st = "REVIEW_TYPE": noteText = "Valid suggested PART_TYPE is not yet approved. Set ACTION=ADD NEW or use CONFIRM VALID TYPES.": nReview = nReview + 1
            Else
                st = "NEW": noteText = "Approved and ready to add.": nNew = nNew + 1
            End If
            If Not d.Exists(key) Then d.Add key, 1

            ws.Cells(r, 3).Value = st
            ws.Cells(r, 14).Value = existingKey
            ws.Cells(r, 15).Value = existingVariant
            ws.Cells(r, 16).Value = noteText
        End If
    Next r
    ws.Range("E4").Value = nNew
    ws.Range("E5").Value = nExist
    ws.Range("E6").Value = nReview
    ws.Range("E7").Value = nDup
    If showMessage Then MsgBox "Validation complete." & vbCrLf & "NEW: " & nNew & vbCrLf & "EXISTING: " & nExist & vbCrLf & "REVIEW: " & nReview & vbCrLf & "DUP_IN_IMPORT: " & nDup, vbInformation
End Sub

Public Sub ONGEN_ML3_ConfirmSuggestedTypes()
    Dim ws As Worksheet, pws As Worksheet, lastRow As Long, r As Long, hdr As Long
    Dim p As String, m As String, pType As String, changed As Long

    ONGEN_ML3_PrepareWorkbook
    Set ws = ThisWorkbook.Worksheets(WS_IMPORT)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    lastRow = ONGEN_ML3_LastUsedRow(ws)

    If MsgBox("Confirm all currently valid suggested PART_TYPE values for new, non-duplicate rows?" & vbCrLf & vbCrLf & _
              "Review the yellow PART_TYPE column first. Existing and conflict rows will not be changed.", _
              vbYesNo + vbQuestion, "Confirm Suggested Part Types") <> vbYes Then Exit Sub

    For r = 11 To lastRow
        p = Trim$(CStr(ws.Cells(r, 6).Value2))
        If Len(p) > 0 Then
            m = Trim$(CStr(ws.Cells(r, 5).Value2))
            pType = ONGEN_ML3_CodeToken(ws.Cells(r, 4).Value2)
            If ONGEN_ML3_IsValidPartType(pType) Then
                If ONGEN_ML3_FindExactPartRow(pws, m, p, hdr) = 0 Then
                    If Not ONGEN_ML3_PartNumberExistsUnderDifferentManufacturer(pws, p, m) Then
                        If UCase$(Trim$(CStr(ws.Cells(r, 3).Value2))) = "REVIEW_TYPE" Then
                            ws.Cells(r, 2).Value = "ADD NEW"
                            changed = changed + 1
                        End If
                    End If
                End If
            End If
        End If
    Next r

    ONGEN_ML3_ValidateBulkImport False
    MsgBox CStr(changed) & " row(s) confirmed. Review any remaining REVIEW or DUP_IN_IMPORT rows, then COMMIT APPROVED ROWS.", vbInformation
End Sub

Public Sub ONGEN_ML3_CommitBulkImport()
    Dim ws As Worksheet, pws As Worksheet, lastRow As Long, r As Long, status As String, actionText As String
    Dim pType As String, m As String, p As String, d As String, curr As String, vendor As String, mg As String, mgd As String, fixedVendorText As String
    Dim costVal As Variant, hdr As Long, pr As Long, oldCost As Variant, partKey As String, variantCode As String
    Dim added As Long, costsUpdated As Long, skipped As Long, sourceName As String, sourceRow As Long

    ONGEN_ML3_PrepareWorkbook
    On Error GoTo EH
    ONGEN_ML3_ValidateBulkImport False
    Set ws = ThisWorkbook.Worksheets(WS_IMPORT)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    Application.ScreenUpdating = False

    For r = 11 To lastRow
        p = Trim$(CStr(ws.Cells(r, 6).Value2))
        If Len(p) > 0 Then
            status = UCase$(Trim$(CStr(ws.Cells(r, 3).Value2)))
            actionText = UCase$(Trim$(CStr(ws.Cells(r, 2).Value2)))
            pType = ONGEN_ML3_CodeToken(ws.Cells(r, 4).Value2)
            m = Trim$(CStr(ws.Cells(r, 5).Value2))
            d = Trim$(CStr(ws.Cells(r, 7).Value2))
            costVal = ws.Cells(r, 8).Value
            curr = UCase$(Trim$(CStr(ws.Cells(r, 9).Value2))): If Len(curr) = 0 Then curr = ONGEN_ML3_ConfigValue("DEFAULT_CURRENCY", "USD")
            vendor = Trim$(CStr(ws.Cells(r, 10).Value2))
            mg = Trim$(CStr(ws.Cells(r, 11).Value2))
            mgd = Trim$(CStr(ws.Cells(r, 12).Value2))
            fixedVendorText = Trim$(CStr(ws.Cells(r, 13).Value2))
            sourceName = Trim$(CStr(ws.Cells(r, 17).Value2))
            sourceRow = Val(ws.Cells(r, 18).Value2)

            If actionText = "SKIP" Then
                skipped = skipped + 1
            ElseIf status = "EXISTING" And actionText = "UPDATE COST ONLY" Then
                pr = ONGEN_ML3_FindExactPartRow(pws, m, p, hdr)
                If pr > 0 Then
                    partKey = CStr(ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PART_KEY"))
                    oldCost = ONGEN_ML3_GetAtHeader(pws, pr, hdr, "CURRENT_COST")
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "CURRENT_COST", costVal
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "COST_CURRENCY", curr
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "COST_AS_OF_DATE", ThisWorkbook.Worksheets(WS_IMPORT).Range("B4").Value
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "PREFERRED_VENDOR", vendor
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "FIXED_VENDOR", fixedVendorText
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "MATERIALS_GROUP", mg
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "MATERIALS_GROUP_DESC", mgd
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "COST_SOURCE", sourceName
                    If Len(CStr(ONGEN_ML3_GetAtHeader(pws, pr, hdr, "PART_DESCRIPTION"))) = 0 Then ONGEN_ML3_SetAtHeader pws, pr, hdr, "PART_DESCRIPTION", d
                    ONGEN_ML3_SetAtHeader pws, pr, hdr, "MODIFIED_DATE", Now
                    If ONGEN_ML3_ValueChanged(oldCost, costVal) Then ONGEN_ML3_AppendCostHistory partKey, costVal, curr, vendor, sourceName, sourceRow, "BULK COST UPDATE"
                    costsUpdated = costsUpdated + 1
                    ws.Cells(r, 16).Value = "Existing part updated; no duplicate created."
                End If
            ElseIf status = "NEW" And actionText = "ADD NEW" Then
                ONGEN_ML3_AddNewPartRecord pType, m, p, d, "", costVal, curr, vendor, fixedVendorText, mg, mgd, "", sourceName, sourceRow, partKey, variantCode
                ws.Cells(r, 14).Value = partKey
                ws.Cells(r, 15).Value = variantCode
                ws.Cells(r, 3).Value = "IMPORTED"
                ws.Cells(r, 16).Value = "Added to Master Library."
                added = added + 1
            Else
                skipped = skipped + 1
            End If
        End If
    Next r

    If added > 0 Or costsUpdated > 0 Then
        ONGEN_ML3_AppendRevision "BULK PART IMPORT: added " & added & "; cost-updated " & costsUpdated
        ONGEN_ML3_BumpLibraryVersion
    End If
    ONGEN_ML3_AppendImportLog sourceName, lastRow - 10, "COMMITTED: added=" & added & "; cost-updated=" & costsUpdated & "; skipped=" & skipped
    ONGEN_ML3_RefreshBrowser
    ONGEN_ML3_RefreshReview
    Application.ScreenUpdating = True
    MsgBox "Bulk import completed." & vbCrLf & vbCrLf & "New parts added: " & added & vbCrLf & "Existing costs updated: " & costsUpdated & vbCrLf & "Skipped/review rows: " & skipped, vbInformation
    Exit Sub
EH:
    Application.ScreenUpdating = True
    MsgBox "Bulk commit failed:" & vbCrLf & Err.Description, vbCritical
End Sub

Public Sub ONGEN_ML3_ClearBulkStaging()
    Dim ws As Worksheet
    ONGEN_ML3_PrepareWorkbook
    Set ws = ThisWorkbook.Worksheets(WS_IMPORT)
    If MsgBox("Clear the current import staging rows?", vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    ws.Range("A11:R100000").ClearContents
    ws.Range("E4:E7").Value = 0
End Sub

' ========================= FUNCTION CREATE / EDIT =============================

Public Sub ONGEN_ML3_SearchFunction()
    Dim ui As Worksheet, fws As Worksheet, q As String, hdr As Long, cFn As Long, cDesc As Long, cFam As Long, cRev As Long, cAct As Long, cStatus As Long
    Dim lastRow As Long, r As Long, tr As Long, hay As String
    ONGEN_ML3_PrepareWorkbook
    Set ui = ThisWorkbook.Worksheets(WS_FUNC_UI)
    Set fws = ThisWorkbook.Worksheets(WS_FUNCTION)
    q = UCase$(Trim$(CStr(ui.Range("C4").Value2)))
    If Len(q) = 0 Then MsgBox "Enter a Function Code or description in FUNCTION SEARCH.", vbExclamation: Exit Sub
    ui.Range("E5:K11").ClearContents
    cFn = ONGEN_ML3_FindHeaderInTopRows(fws, "FUNCTION_CODE", hdr)
    cDesc = ONGEN_ML3_FindHeaderColumn(fws, "FUNCTION_DESCRIPTION", hdr)
    cFam = ONGEN_ML3_FindHeaderColumn(fws, "FUNCTION_FAMILY", hdr)
    cRev = ONGEN_ML3_FindHeaderColumn(fws, "REVISION", hdr)
    cAct = ONGEN_ML3_FindHeaderColumn(fws, "ACTIVE", hdr)
    cStatus = ONGEN_ML3_FindHeaderColumn(fws, "STATUS", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(fws): tr = 5
    For r = hdr + 1 To lastRow
        hay = UCase$(CStr(ONGEN_ML3_CellValue(fws, r, cFn)) & " " & CStr(ONGEN_ML3_CellValue(fws, r, cDesc)) & " " & CStr(ONGEN_ML3_CellValue(fws, r, cFam)))
        If InStr(1, hay, q, vbTextCompare) > 0 Then
            ui.Cells(tr, 5).Value = ""
            ui.Cells(tr, 6).Value = ONGEN_ML3_CellValue(fws, r, cFn)
            ui.Cells(tr, 7).Value = ONGEN_ML3_CellValue(fws, r, cDesc)
            ui.Cells(tr, 8).Value = ONGEN_ML3_CellValue(fws, r, cFam)
            ui.Cells(tr, 9).Value = ONGEN_ML3_CellValue(fws, r, cRev)
            ui.Cells(tr, 10).Value = ONGEN_ML3_CellValue(fws, r, cAct)
            ui.Cells(tr, 11).Value = ONGEN_ML3_CellValue(fws, r, cStatus)
            tr = tr + 1
            If tr > 11 Then Exit For
        End If
    Next r
    If tr = 5 Then MsgBox "No matching function was found.", vbInformation
End Sub

Public Sub ONGEN_ML3_LoadSelectedFunction()
    Dim ui As Worksheet, fws As Worksheet, cws As Worksheet, bws As Worksheet, pws As Worksheet
    Dim selectedRow As Long, fn As String, fHdr As Long, fr As Long, cHdr As Long, bHdr As Long, pHdr As Long
    Dim lastComp As Long, cr As Long, lastBom As Long, br As Long, tr As Long, compNo As Long
    Dim variantCode As String, partKey As String, pr As Long

    ONGEN_ML3_PrepareWorkbook
    Set ui = ThisWorkbook.Worksheets(WS_FUNC_UI)
    selectedRow = ONGEN_ML3_SelectedResultRow(ui, 5, 11, 5)
    If selectedRow = 0 Then
        ' allow exact code typed in search box
        fn = Trim$(CStr(ui.Range("C4").Value2))
    Else
        fn = Trim$(CStr(ui.Cells(selectedRow, 6).Value2))
    End If
    If Len(fn) = 0 Then MsgBox "Search/select a function first.", vbExclamation: Exit Sub

    Set fws = ThisWorkbook.Worksheets(WS_FUNCTION)
    Set cws = ThisWorkbook.Worksheets(WS_COMPONENT)
    Set bws = ThisWorkbook.Worksheets(WS_BOM)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    fr = ONGEN_ML3_FindRowByField(fws, "FUNCTION_CODE", fn, fHdr)
    If fr = 0 Then MsgBox "Function not found: " & fn, vbCritical: Exit Sub

    ui.Range("C3").Value = "EDIT EXISTING FUNCTION"
    ui.Range("C5").Value = ONGEN_ML3_GetAtHeader(fws, fr, fHdr, "FUNCTION_FAMILY")
    ui.Range("C6").Value = ONGEN_ML3_GetAtHeader(fws, fr, fHdr, "FUNCTION_DESCRIPTION")
    ui.Range("C7").Value = ONGEN_ML3_GetAtHeader(fws, fr, fHdr, "CONVEYOR_TYPES")
    ui.Range("C8").Value = ONGEN_ML3_GetAtHeader(fws, fr, fHdr, "ENGINEERING_NOTES")
    ui.Range("C9").Value = fn
    ui.Range("C10").Value = ONGEN_ML3_GetAtHeader(fws, fr, fHdr, "REVISION")
    ui.Range("C11").Value = "LOADED FOR EDIT"
    ui.Range("A18:M67").ClearContents

    ONGEN_ML3_FindHeaderInTopRows cws, "FUNCTION_CODE", cHdr
    ONGEN_ML3_FindHeaderInTopRows bws, "VARIANT_CODE", bHdr
    tr = 18: compNo = 0
    lastComp = ONGEN_ML3_LastUsedRow(cws)
    For cr = cHdr + 1 To lastComp
        If StrComp(Trim$(CStr(ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "FUNCTION_CODE"))), fn, vbTextCompare) = 0 And _
           UCase$(Trim$(CStr(ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "ACTIVE")))) <> "NO" Then
            compNo = compNo + 1
            variantCode = Trim$(CStr(ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "VARIANT_CODE")))
            lastBom = ONGEN_ML3_LastUsedRow(bws)
            For br = bHdr + 1 To lastBom
                If StrComp(Trim$(CStr(ONGEN_ML3_GetAtHeader(bws, br, bHdr, "VARIANT_CODE"))), variantCode, vbTextCompare) = 0 Then
                    partKey = Trim$(CStr(ONGEN_ML3_GetAtHeader(bws, br, bHdr, "PART_KEY")))
                    If Len(partKey) > 0 Then
                        ui.Cells(tr, 1).Value = compNo
                        ui.Cells(tr, 2).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "COMPONENT_TYPE")
                        ui.Cells(tr, 3).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "BLOCK")
                        ui.Cells(tr, 4).Value = partKey
                        ui.Cells(tr, 5).Value = ONGEN_ML3_GetAtHeader(bws, br, bHdr, "QTY")
                        ui.Cells(tr, 6).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "INPUT")
                        ui.Cells(tr, 7).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "OUTPUT")
                        ui.Cells(tr, 8).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "S_IN")
                        ui.Cells(tr, 9).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "S_OUT")
                        ui.Cells(tr, 10).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "NOTE")
                        ui.Cells(tr, 11).Value = ONGEN_ML3_GetAtHeader(cws, cr, cHdr, "CONVEYOR_TYPE")
                        pr = ONGEN_ML3_FindPartRowByKey(pws, partKey, pHdr)
                        If pr > 0 Then
                            ui.Cells(tr, 12).Value = ONGEN_ML3_GetAtHeader(pws, pr, pHdr, "PART_DESCRIPTION")
                            ui.Cells(tr, 13).Value = ONGEN_ML3_GetAtHeader(pws, pr, pHdr, "CURRENT_COST")
                        End If
                        tr = tr + 1
                        If tr > 67 Then Exit For
                    End If
                End If
            Next br
            If tr > 67 Then Exit For
        End If
    Next cr
End Sub

Public Sub ONGEN_ML3_SearchAssemblyPart()
    Dim ui As Worksheet, pws As Worksheet, q As String, hdr As Long, cKey As Long, cType As Long, cMfg As Long, cPart As Long, cDesc As Long, cActive As Long
    Dim lastRow As Long, r As Long, tr As Long, hay As String
    ONGEN_ML3_PrepareWorkbook
    Set ui = ThisWorkbook.Worksheets(WS_FUNC_UI)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    q = UCase$(Trim$(CStr(ui.Range("N4").Value2)))
    If Len(q) = 0 Then MsgBox "Enter a part search in N4.", vbExclamation: Exit Sub
    ui.Range("M7:R15").ClearContents
    cKey = ONGEN_ML3_FindHeaderInTopRows(pws, "PART_KEY", hdr)
    cType = ONGEN_ML3_FindHeaderColumn(pws, "PART_TYPE", hdr)
    cMfg = ONGEN_ML3_FindHeaderColumn(pws, "MANUFACTURER", hdr)
    cPart = ONGEN_ML3_FindHeaderColumn(pws, "PART_NUMBER", hdr)
    cDesc = ONGEN_ML3_FindHeaderColumn(pws, "PART_DESCRIPTION", hdr)
    cActive = ONGEN_ML3_FindHeaderColumn(pws, "ACTIVE", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(pws): tr = 7
    For r = hdr + 1 To lastRow
        If UCase$(Trim$(CStr(ONGEN_ML3_CellValue(pws, r, cActive)))) <> "NO" Then
            hay = UCase$(CStr(ONGEN_ML3_CellValue(pws, r, cKey)) & " " & CStr(ONGEN_ML3_CellValue(pws, r, cType)) & " " & CStr(ONGEN_ML3_CellValue(pws, r, cMfg)) & " " & CStr(ONGEN_ML3_CellValue(pws, r, cPart)) & " " & CStr(ONGEN_ML3_CellValue(pws, r, cDesc)))
            If InStr(1, hay, q, vbTextCompare) > 0 Then
                ui.Cells(tr, 13).Value = ""
                ui.Cells(tr, 14).Value = ONGEN_ML3_CellValue(pws, r, cKey)
                ui.Cells(tr, 15).Value = ONGEN_ML3_CellValue(pws, r, cType)
                ui.Cells(tr, 16).Value = ONGEN_ML3_CellValue(pws, r, cMfg)
                ui.Cells(tr, 17).Value = ONGEN_ML3_CellValue(pws, r, cPart)
                ui.Cells(tr, 18).Value = ONGEN_ML3_CellValue(pws, r, cDesc)
                tr = tr + 1
                If tr > 15 Then Exit For
            End If
        End If
    Next r
    If tr = 7 Then MsgBox "No matching active part was found.", vbInformation
End Sub

Public Sub ONGEN_ML3_AddSelectedPartToAssembly()
    Dim ui As Worksheet, selectedRow As Long, partKey As String, pws As Worksheet, pr As Long, ph As Long, tr As Long, targetComp As Long
    ONGEN_ML3_PrepareWorkbook
    Set ui = ThisWorkbook.Worksheets(WS_FUNC_UI)
    selectedRow = ONGEN_ML3_SelectedResultRow(ui, 7, 15, 13)
    If selectedRow = 0 Then MsgBox "Mark X in the part-search SELECT column or select a result row.", vbExclamation: Exit Sub
    partKey = Trim$(CStr(ui.Cells(selectedRow, 14).Value2))
    If Len(partKey) = 0 Then Exit Sub
    targetComp = Val(ui.Range("N16").Value2): If targetComp <= 0 Then targetComp = 1
    For tr = 18 To 67
        If Len(Trim$(CStr(ui.Cells(tr, 4).Value2))) = 0 Then Exit For
    Next tr
    If tr > 67 Then MsgBox "Assembly grid is full.", vbExclamation: Exit Sub
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    pr = ONGEN_ML3_FindPartRowByKey(pws, partKey, ph)
    If pr = 0 Then
        MsgBox "Selected Part Key was not found in PART_MASTER: " & partKey, vbCritical
        Exit Sub
    End If
    ui.Cells(tr, 1).Value = targetComp
    ui.Cells(tr, 2).Value = ONGEN_ML3_GetAtHeader(pws, pr, ph, "PART_TYPE")
    ui.Cells(tr, 4).Value = partKey
    ui.Cells(tr, 5).Value = 1
    ui.Cells(tr, 12).Value = ONGEN_ML3_GetAtHeader(pws, pr, ph, "PART_DESCRIPTION")
    ui.Cells(tr, 13).Value = ONGEN_ML3_GetAtHeader(pws, pr, ph, "CURRENT_COST")
End Sub

Public Sub ONGEN_ML3_RemoveSelectedAssemblyRow()
    Dim ws As Worksheet, r As Long
    ONGEN_ML3_PrepareWorkbook
    Set ws = ThisWorkbook.Worksheets(WS_FUNC_UI)
    r = ActiveCell.Row
    If ActiveSheet.Name <> WS_FUNC_UI Or r < 18 Or r > 67 Then
        MsgBox "Select a row in the assembly grid first.", vbExclamation
        Exit Sub
    End If
    If MsgBox("Remove assembly row " & r & "?", vbYesNo + vbQuestion) = vbYes Then ws.Range("A" & r & ":M" & r).ClearContents
End Sub

Public Sub ONGEN_ML3_ValidateAssembly()
    Dim msg As String
    ONGEN_ML3_PrepareWorkbook
    If ONGEN_ML3_AssemblyIsValid(msg) Then MsgBox "Assembly validation passed.", vbInformation Else MsgBox "Assembly validation failed:" & vbCrLf & msg, vbExclamation
End Sub

Public Sub ONGEN_ML3_SaveFunctionRevision()
    ONGEN_ML3_PrepareWorkbook
    ONGEN_ML3_SaveFunction False
End Sub

Public Sub ONGEN_ML3_CreateAsNewFunction()
    ONGEN_ML3_PrepareWorkbook
    ONGEN_ML3_SaveFunction True
End Sub

Private Sub ONGEN_ML3_SaveFunction(ByVal forceNew As Boolean)
    Dim ui As Worksheet, fws As Worksheet, cws As Worksheet, vws As Worksheet, bws As Worksheet, pws As Worksheet
    Dim msg As String, fn As String, family As String, descr As String, convDefault As String, engNotes As String, oldRev As String, newRev As String
    Dim fHdr As Long, fr As Long, r As Long, lastRow As Long, compGroups As Object, compOrder As Collection, compNo As String, rec As Object, rows As Collection
    Dim rowData As Variant, item As Variant, componentIndex As Long, componentCode As String, componentType As String, blockName As String, variantCode As String
    Dim componentQty As Double, inV As Variant, outV As Variant, sinV As Variant, soutV As Variant, noteText As String, conv As String
    Dim signature As String, fnSignature As String, tags As String, blocks As String, convs As String, dupFn As String

    On Error GoTo EH
    If Not ONGEN_ML3_AssemblyIsValid(msg) Then MsgBox "Cannot save function:" & vbCrLf & msg, vbExclamation: Exit Sub
    Set ui = ThisWorkbook.Worksheets(WS_FUNC_UI)
    Set fws = ThisWorkbook.Worksheets(WS_FUNCTION)
    Set cws = ThisWorkbook.Worksheets(WS_COMPONENT)
    Set vws = ThisWorkbook.Worksheets(WS_VARIANT)
    Set bws = ThisWorkbook.Worksheets(WS_BOM)
    Set pws = ThisWorkbook.Worksheets(WS_PART)

    family = ONGEN_ML3_CodeToken(ui.Range("C5").Value2)
    descr = Trim$(CStr(ui.Range("C6").Value2))
    convDefault = Trim$(CStr(ui.Range("C7").Value2))
    engNotes = Trim$(CStr(ui.Range("C8").Value2))
    fn = Trim$(CStr(ui.Range("C9").Value2))

    Set compGroups = CreateObject("Scripting.Dictionary"): compGroups.CompareMode = vbTextCompare
    Set compOrder = New Collection
    For r = 18 To 67
        If Len(Trim$(CStr(ui.Cells(r, 4).Value2))) > 0 Then
            compNo = Trim$(CStr(ui.Cells(r, 1).Value2)): If Len(compNo) = 0 Then compNo = "1"
            If Not compGroups.Exists(compNo) Then
                Set rec = CreateObject("Scripting.Dictionary")
                Set rows = New Collection
                rec.Add "ROWS", rows
                rec("TYPE") = ONGEN_ML3_CodeToken(ui.Cells(r, 2).Value2)
                rec("BLOCK") = Trim$(CStr(ui.Cells(r, 3).Value2))
                rec("INPUT") = ui.Cells(r, 6).Value
                rec("OUTPUT") = ui.Cells(r, 7).Value
                rec("S_IN") = ui.Cells(r, 8).Value
                rec("S_OUT") = ui.Cells(r, 9).Value
                rec("NOTE") = Trim$(CStr(ui.Cells(r, 10).Value2))
                rec("CONV") = Trim$(CStr(ui.Cells(r, 11).Value2))
                compGroups.Add compNo, rec
                compOrder.Add compNo
            End If
            Set rec = compGroups(compNo)
            Set rows = rec("ROWS")
            rows.Add Array(Trim$(CStr(ui.Cells(r, 4).Value2)), CDbl(Val(ui.Cells(r, 5).Value2)))
        End If
    Next r

    ' Apply the function-level default conveyor to groups that do not override it
    ' before building the duplicate-detection signature.
    For Each item In compOrder
        Set rec = compGroups(CStr(item))
        If Len(Trim$(CStr(rec("CONV")))) = 0 Then rec("CONV") = convDefault
    Next item
    fnSignature = ONGEN_ML3_BuildFunctionSignature(compGroups, compOrder)
    If forceNew Or UCase$(Trim$(CStr(ui.Range("C3").Value2))) = "NEW FUNCTION" Or Len(fn) = 0 Then
        dupFn = ONGEN_ML3_FindFunctionBySignature(fws, fnSignature)
        If Len(dupFn) > 0 Then
            MsgBox "An active function with the same assembly already exists:" & vbCrLf & dupFn & vbCrLf & _
                   "Load that function instead of creating a duplicate.", vbExclamation
            Exit Sub
        End If
        fn = ONGEN_ML3_NextCode(fws, "FUNCTION_CODE", "CF-" & family & "-", 3)
        newRev = "A"
        fr = ONGEN_ML3_LastUsedRow(fws) + 1
        ONGEN_ML3_FindHeaderInTopRows fws, "FUNCTION_CODE", fHdr
    Else
        fr = ONGEN_ML3_FindRowByField(fws, "FUNCTION_CODE", fn, fHdr)
        If fr = 0 Then MsgBox "Function Code not found: " & fn, vbCritical: Exit Sub
        oldRev = CStr(ONGEN_ML3_GetAtHeader(fws, fr, fHdr, "REVISION"))
        newRev = ONGEN_ML3_NextRevision(oldRev)
        ' Retain component history by inactivating current active rows.
        ONGEN_ML3_InactivateFunctionComponents cws, fn
    End If

    componentIndex = 0
    For Each item In compOrder
        componentIndex = componentIndex + 1
        Set rec = compGroups(CStr(item))
        Set rows = rec("ROWS")
        componentType = CStr(rec("TYPE"))
        blockName = CStr(rec("BLOCK"))
        inV = rec("INPUT"): outV = rec("OUTPUT"): sinV = rec("S_IN"): soutV = rec("S_OUT")
        noteText = CStr(rec("NOTE")): conv = CStr(rec("CONV")): If Len(conv) = 0 Then conv = convDefault
        componentCode = fn & "-C" & Format$(componentIndex, "00")
        signature = ONGEN_ML3_ComponentSignature(rows)
        variantCode = ONGEN_ML3_FindMatchingVariant(vws, signature, componentType)
        If Len(variantCode) = 0 Then
            variantCode = ONGEN_ML3_NextCode(vws, "VARIANT_CODE", "DV-" & componentType & "-", 3)
            ONGEN_ML3_AppendVariant vws, variantCode, componentType, descr, signature, "FUNCTION ASSEMBLY"
            ONGEN_ML3_AppendVariantBOMFromRows bws, pws, variantCode, rows
        End If
        componentQty = 1
        Call ONGEN_ML3_AppendFunctionComponent( _
            cws, fn, componentCode, variantCode, componentType, blockName, _
            noteText, conv, componentQty, inV, outV, sinV, soutV, newRev)
        tags = ONGEN_ML3_JoinUnique(tags, componentType)
        blocks = ONGEN_ML3_JoinUnique(blocks, blockName)
        convs = ONGEN_ML3_JoinUnique(convs, conv)
    Next item

    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "FUNCTION_CODE", fn
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "FUNCTION_FAMILY", family
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "FUNCTION_DESCRIPTION", descr
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "CONTROL_FUNCTION_TAGS", tags
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "BLOCKS", blocks
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "CONVEYOR_TYPES", convs
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "REVISION", newRev
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "ACTIVE", "YES"
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "SOURCE", "USER FUNCTION ASSEMBLY"
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "STATUS", "APPROVED"
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "ENGINEERING_NOTES", engNotes
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "ASSEMBLY_SIGNATURE", fnSignature
    If Len(CStr(ONGEN_ML3_GetAtHeader(fws, fr, fHdr, "CREATED_DATE"))) = 0 Then ONGEN_ML3_SetAtHeader fws, fr, fHdr, "CREATED_DATE", Now
    ONGEN_ML3_SetAtHeader fws, fr, fHdr, "MODIFIED_DATE", Now

    ui.Range("C9").Value = fn
    ui.Range("C10").Value = newRev
    ui.Range("C11").Value = "SAVED"
    ui.Range("C3").Value = "EDIT EXISTING FUNCTION"
    ONGEN_ML3_AppendRevision IIf(newRev = "A", "CREATE FUNCTION ", "REVISE FUNCTION ") & fn & " REV " & newRev
    ONGEN_ML3_BumpLibraryVersion
    ONGEN_ML3_ExportFunctionLookupCSV
    ONGEN_ML3_RefreshBrowser
    ONGEN_ML3_RefreshReview
    MsgBox "Function saved." & vbCrLf & "FUNCTION_CODE: " & fn & vbCrLf & "Revision: " & newRev, vbInformation
    Exit Sub
EH:
    MsgBox "Function save failed:" & vbCrLf & Err.Description, vbCritical
End Sub

Private Function ONGEN_ML3_AssemblyIsValid(ByRef messageText As String) As Boolean
    Dim ws As Worksheet, pws As Worksheet, family As String, descr As String, r As Long, partKey As String, pHdr As Long, pr As Long, componentNo As String
    Dim errs As String
    Set ws = ThisWorkbook.Worksheets(WS_FUNC_UI)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    family = ONGEN_ML3_CodeToken(ws.Range("C5").Value2)
    descr = Trim$(CStr(ws.Range("C6").Value2))
    If Len(family) = 0 Then errs = errs & "- FUNCTION TYPE is required." & vbCrLf
    If Len(descr) = 0 Then errs = errs & "- FUNCTION DESCRIPTION is required." & vbCrLf
    For r = 18 To 67
        partKey = Trim$(CStr(ws.Cells(r, 4).Value2))
        If Len(partKey) > 0 Then
            componentNo = Trim$(CStr(ws.Cells(r, 1).Value2))
            If Len(componentNo) = 0 Then errs = errs & "- Row " & r & ": COMPONENT_NO is required." & vbCrLf
            If Len(ONGEN_ML3_CodeToken(ws.Cells(r, 2).Value2)) = 0 Then errs = errs & "- Row " & r & ": COMPONENT_TYPE is required." & vbCrLf
            If Val(ws.Cells(r, 5).Value2) <= 0 Then errs = errs & "- Row " & r & ": QTY must be greater than 0." & vbCrLf
            pr = ONGEN_ML3_FindPartRowByKey(pws, partKey, pHdr)
            If pr = 0 Then
                errs = errs & "- Row " & r & ": Part Key not found: " & partKey & vbCrLf
            ElseIf UCase$(Trim$(CStr(ONGEN_ML3_GetAtHeader(pws, pr, pHdr, "ACTIVE")))) = "NO" Then
                errs = errs & "- Row " & r & ": Part is retired/inactive: " & partKey & vbCrLf
            End If
        End If
    Next r
    If WorksheetFunction.CountA(ws.Range("D18:D67")) = 0 Then errs = errs & "- Add at least one part to the assembly." & vbCrLf
    messageText = errs
    ONGEN_ML3_AssemblyIsValid = (Len(errs) = 0)
End Function

Public Sub ONGEN_ML3_ClearFunctionForm()
    ONGEN_ML3_PrepareWorkbook
    With ThisWorkbook.Worksheets(WS_FUNC_UI)
        .Range("C3").Value = "NEW FUNCTION"
        .Range("C4:C11").ClearContents
        .Range("C3").Value = "NEW FUNCTION"
        .Range("E5:K11").ClearContents
        .Range("N4").ClearContents
        .Range("M7:R15").ClearContents
        .Range("N16").Value = 1
        .Range("A18:M67").ClearContents
        .Range("E18:E67").Value = 1
    End With
End Sub

' =============================== BROWSER =====================================

Public Sub ONGEN_ML3_RefreshBrowser()
    Dim ws As Worksheet, fws As Worksheet, pws As Worksheet, fh As Long, ph As Long, r As Long, tr As Long, lastRow As Long
    ONGEN_ML3_PrepareWorkbook
    On Error GoTo SafeExit
    Set ws = ThisWorkbook.Worksheets(WS_BROWSER)
    Set fws = ThisWorkbook.Worksheets(WS_FUNCTION)
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    ws.Range("A7:F5000,H7:M5000").ClearContents
    ONGEN_ML3_FindHeaderInTopRows fws, "FUNCTION_CODE", fh
    lastRow = ONGEN_ML3_LastUsedRow(fws): tr = 7
    For r = fh + 1 To lastRow
        If Len(Trim$(CStr(ONGEN_ML3_GetAtHeader(fws, r, fh, "FUNCTION_CODE")))) > 0 Then
            ws.Cells(tr, 1).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "FUNCTION_CODE")
            ws.Cells(tr, 2).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "FUNCTION_DESCRIPTION")
            ws.Cells(tr, 3).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "FUNCTION_FAMILY")
            ws.Cells(tr, 4).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "REVISION")
            ws.Cells(tr, 5).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "ACTIVE")
            ws.Cells(tr, 6).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "BLOCKS")
            tr = tr + 1
        End If
    Next r
    ONGEN_ML3_FindHeaderInTopRows pws, "PART_KEY", ph
    lastRow = ONGEN_ML3_LastUsedRow(pws): tr = 7
    For r = ph + 1 To lastRow
        If Len(Trim$(CStr(ONGEN_ML3_GetAtHeader(pws, r, ph, "PART_KEY")))) > 0 Then
            ws.Cells(tr, 8).Value = ONGEN_ML3_GetAtHeader(pws, r, ph, "PART_KEY")
            ws.Cells(tr, 9).Value = ONGEN_ML3_GetAtHeader(pws, r, ph, "PART_TYPE")
            ws.Cells(tr, 10).Value = ONGEN_ML3_GetAtHeader(pws, r, ph, "MANUFACTURER")
            ws.Cells(tr, 11).Value = ONGEN_ML3_GetAtHeader(pws, r, ph, "PART_NUMBER")
            ws.Cells(tr, 12).Value = ONGEN_ML3_GetAtHeader(pws, r, ph, "PART_DESCRIPTION")
            ws.Cells(tr, 13).Value = ONGEN_ML3_GetAtHeader(pws, r, ph, "CURRENT_COST")
            tr = tr + 1
        End If
    Next r
SafeExit:
End Sub

Public Sub ONGEN_ML3_RefreshReview()
    Dim ws As Worksheet, fws As Worksheet, iws As Worksheet, fh As Long, r As Long, tr As Long, lastRow As Long, statusText As String
    ONGEN_ML3_PrepareWorkbook
    On Error GoTo SafeExit
    Set ws = ThisWorkbook.Worksheets(WS_REVIEW)
    Set fws = ThisWorkbook.Worksheets(WS_FUNCTION)
    Set iws = ThisWorkbook.Worksheets(WS_IMPORT)
    ws.Range("A4:D5000,F4:H50").ClearContents
    ONGEN_ML3_FindHeaderInTopRows fws, "FUNCTION_CODE", fh
    lastRow = ONGEN_ML3_LastUsedRow(fws): tr = 4
    For r = fh + 1 To lastRow
        statusText = UCase$(Trim$(CStr(ONGEN_ML3_GetAtHeader(fws, r, fh, "STATUS"))))
        If InStr(1, statusText, "REVIEW", vbTextCompare) > 0 Then
            ws.Cells(tr, 1).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "FUNCTION_CODE")
            ws.Cells(tr, 2).Value = ONGEN_ML3_GetAtHeader(fws, r, fh, "FUNCTION_DESCRIPTION")
            ws.Cells(tr, 3).Value = statusText
            ws.Cells(tr, 4).Value = "Review before final release"
            tr = tr + 1
        End If
    Next r
    ONGEN_ML3_ValidateBulkImport False
    ws.Range("F4").Value = "NEW": ws.Range("G4").Value = iws.Range("E4").Value: ws.Range("H4").Value = "Ready after validation"
    ws.Range("F5").Value = "EXISTING": ws.Range("G5").Value = iws.Range("E5").Value: ws.Range("H5").Value = "Cost update only"
    ws.Range("F6").Value = "REVIEW": ws.Range("G6").Value = iws.Range("E6").Value: ws.Range("H6").Value = "Resolve before commit"
    ws.Range("F7").Value = "DUP_IN_IMPORT": ws.Range("G7").Value = iws.Range("E7").Value: ws.Range("H7").Value = "Remove or skip duplicate row"
SafeExit:
End Sub

' ========================== DATABASE WRITE HELPERS ============================

Private Sub ONGEN_ML3_AddNewPartRecord(ByVal pType As String, ByVal mfg As String, ByVal partNo As String, ByVal descr As String, _
                                        ByVal rating As String, ByVal costVal As Variant, ByVal curr As String, ByVal vendor As String, _
                                        ByVal fixedVendor As String, ByVal materialGroup As String, ByVal materialGroupDesc As String, ByVal notes As String, _
                                        ByVal sourceFile As String, ByVal sourceRow As Long, ByRef partKey As String, ByRef variantCode As String)
    Dim pws As Worksheet, vws As Worksheet, bws As Worksheet, hdr As Long, r As Long
    Set pws = ThisWorkbook.Worksheets(WS_PART)
    Set vws = ThisWorkbook.Worksheets(WS_VARIANT)
    Set bws = ThisWorkbook.Worksheets(WS_BOM)
    pType = ONGEN_ML3_CodeToken(pType)
    If Not ONGEN_ML3_IsValidPartType(pType) Then Err.Raise vbObjectError + 4101, , "Invalid PART_TYPE: " & pType
    ONGEN_ML3_FindHeaderInTopRows pws, "PART_KEY", hdr
    partKey = ONGEN_ML3_NextCode(pws, "PART_KEY", "PK-" & pType & "-", 4)
    variantCode = ONGEN_ML3_NextCode(vws, "VARIANT_CODE", "DV-" & pType & "-", 3)
    r = ONGEN_ML3_LastUsedRow(pws) + 1
    ONGEN_ML3_SetAtHeader pws, r, hdr, "PART_KEY", partKey
    ONGEN_ML3_SetAtHeader pws, r, hdr, "PART_TYPE", pType
    ONGEN_ML3_SetAtHeader pws, r, hdr, "MANUFACTURER", mfg
    ONGEN_ML3_SetAtHeader pws, r, hdr, "NORMALIZED_MANUFACTURER", ONGEN_ML3_NormalizeManufacturer(mfg)
    ONGEN_ML3_SetAtHeader pws, r, hdr, "PART_NUMBER", partNo
    ONGEN_ML3_SetAtHeader pws, r, hdr, "NORMALIZED_PART_NUMBER", ONGEN_ML3_NormalizePartNumber(partNo)
    ONGEN_ML3_SetAtHeader pws, r, hdr, "PART_DESCRIPTION", descr
    ONGEN_ML3_SetAtHeader pws, r, hdr, "RATING_SIZE", rating
    ONGEN_ML3_SetAtHeader pws, r, hdr, "DEVICE_VARIANT_CODE", variantCode
    ONGEN_ML3_SetAtHeader pws, r, hdr, "CURRENT_COST", costVal
    ONGEN_ML3_SetAtHeader pws, r, hdr, "COST_CURRENCY", curr
    If Len(Trim$(CStr(costVal))) > 0 Then ONGEN_ML3_SetAtHeader pws, r, hdr, "COST_AS_OF_DATE", ThisWorkbook.Worksheets(WS_IMPORT).Range("B4").Value
    ONGEN_ML3_SetAtHeader pws, r, hdr, "PREFERRED_VENDOR", vendor
    ONGEN_ML3_SetAtHeader pws, r, hdr, "FIXED_VENDOR", fixedVendor
    ONGEN_ML3_SetAtHeader pws, r, hdr, "MATERIALS_GROUP", materialGroup
    ONGEN_ML3_SetAtHeader pws, r, hdr, "MATERIALS_GROUP_DESC", materialGroupDesc
    ONGEN_ML3_SetAtHeader pws, r, hdr, "COST_SOURCE", sourceFile
    ONGEN_ML3_SetAtHeader pws, r, hdr, "NOTES", notes
    ONGEN_ML3_SetAtHeader pws, r, hdr, "REVISION", "A"
    ONGEN_ML3_SetAtHeader pws, r, hdr, "ACTIVE", "YES"
    ONGEN_ML3_SetAtHeader pws, r, hdr, "CREATED_DATE", Now
    ONGEN_ML3_SetAtHeader pws, r, hdr, "MODIFIED_DATE", Now

    ONGEN_ML3_AppendVariant vws, variantCode, pType, descr, partKey & ":1", "PART ENTRY"
    ONGEN_ML3_AppendVariantBOM bws, variantCode, 1, 1, partKey, mfg, partNo, "PART ENTRY"
    If Len(Trim$(CStr(costVal))) > 0 Then ONGEN_ML3_AppendCostHistory partKey, costVal, curr, vendor, sourceFile, sourceRow, "INITIAL COST"
End Sub

Private Sub ONGEN_ML3_AppendVariant(ByVal ws As Worksheet, ByVal variantCode As String, ByVal componentType As String, ByVal descr As String, ByVal signature As String, ByVal sourceText As String)
    Dim hdr As Long, r As Long
    ONGEN_ML3_FindHeaderInTopRows ws, "VARIANT_CODE", hdr
    r = ONGEN_ML3_LastUsedRow(ws) + 1
    ONGEN_ML3_SetAtHeader ws, r, hdr, "VARIANT_CODE", variantCode
    ONGEN_ML3_SetAtHeader ws, r, hdr, "COMPONENT_TYPE", componentType
    ONGEN_ML3_SetAtHeader ws, r, hdr, "DESCRIPTION", descr
    ONGEN_ML3_SetAtHeader ws, r, hdr, "REVISION", "A"
    ONGEN_ML3_SetAtHeader ws, r, hdr, "ACTIVE", "YES"
    ONGEN_ML3_SetAtHeader ws, r, hdr, "SOURCE", sourceText
    ONGEN_ML3_SetAtHeader ws, r, hdr, "CREATED_DATE", Now
    ONGEN_ML3_SetAtHeader ws, r, hdr, "MODIFIED_DATE", Now
    ONGEN_ML3_SetAtHeader ws, r, hdr, "BOM_SIGNATURE", signature
End Sub

Private Sub ONGEN_ML3_AppendVariantBOM(ByVal ws As Worksheet, ByVal variantCode As String, ByVal slot As Long, ByVal qty As Double, ByVal partKey As String, ByVal mfg As String, ByVal partNo As String, ByVal sourceText As String)
    Dim hdr As Long, r As Long
    ONGEN_ML3_FindHeaderInTopRows ws, "VARIANT_CODE", hdr
    r = ONGEN_ML3_LastUsedRow(ws) + 1
    ONGEN_ML3_SetAtHeader ws, r, hdr, "VARIANT_CODE", variantCode
    ONGEN_ML3_SetAtHeader ws, r, hdr, "BOM_SLOT", slot
    ONGEN_ML3_SetAtHeader ws, r, hdr, "QTY", qty
    ONGEN_ML3_SetAtHeader ws, r, hdr, "PART_KEY", partKey
    ONGEN_ML3_SetAtHeader ws, r, hdr, "MANUFACTURER", mfg
    ONGEN_ML3_SetAtHeader ws, r, hdr, "PART_NUMBER", partNo
    ONGEN_ML3_SetAtHeader ws, r, hdr, "SOURCE", sourceText
End Sub

Private Sub ONGEN_ML3_AppendVariantBOMFromRows(ByVal bws As Worksheet, ByVal pws As Worksheet, ByVal variantCode As String, ByVal rows As Collection)
    Dim i As Long, a As Variant, partKey As String, qty As Double, ph As Long, pr As Long, mfg As String, pn As String
    For i = 1 To rows.Count
        a = rows(i): partKey = CStr(a(0)): qty = CDbl(a(1)): If qty <= 0 Then qty = 1
        pr = ONGEN_ML3_FindPartRowByKey(pws, partKey, ph)
        If pr = 0 Then Err.Raise vbObjectError + 4201, , "Part Key not found: " & partKey
        mfg = CStr(ONGEN_ML3_GetAtHeader(pws, pr, ph, "MANUFACTURER"))
        pn = CStr(ONGEN_ML3_GetAtHeader(pws, pr, ph, "PART_NUMBER"))
        ONGEN_ML3_AppendVariantBOM bws, variantCode, i, qty, partKey, mfg, pn, "FUNCTION ASSEMBLY"
    Next i
End Sub

Private Sub ONGEN_ML3_AppendFunctionComponent( _
    ByVal ws As Worksheet, ByVal fn As String, ByVal comp As String, _
    ByVal variantCodeArg As String, ByVal typ As String, ByVal blockName As String, _
    ByVal noteText As String, ByVal conv As String, ByVal qty As Double, _
    ByVal inV As Variant, ByVal outV As Variant, ByVal sinV As Variant, _
    ByVal soutV As Variant, ByVal rev As String)
    Dim hdr As Long, r As Long
    ONGEN_ML3_FindHeaderInTopRows ws, "FUNCTION_CODE", hdr
    r = ONGEN_ML3_LastUsedRow(ws) + 1
    ONGEN_ML3_SetAtHeader ws, r, hdr, "FUNCTION_CODE", fn
    ONGEN_ML3_SetAtHeader ws, r, hdr, "COMPONENT_CODE", comp
    ONGEN_ML3_SetAtHeader ws, r, hdr, "VARIANT_CODE", variantCodeArg
    ONGEN_ML3_SetAtHeader ws, r, hdr, "COMPONENT_TYPE", typ
    ONGEN_ML3_SetAtHeader ws, r, hdr, "BLOCK", blockName
    ONGEN_ML3_SetAtHeader ws, r, hdr, "NOTE", noteText
    ONGEN_ML3_SetAtHeader ws, r, hdr, "CONVEYOR_TYPE", conv
    ONGEN_ML3_SetAtHeader ws, r, hdr, "QTY", qty
    ONGEN_ML3_SetAtHeader ws, r, hdr, "INPUT", inV
    ONGEN_ML3_SetAtHeader ws, r, hdr, "OUTPUT", outV
    ONGEN_ML3_SetAtHeader ws, r, hdr, "S_IN", sinV
    ONGEN_ML3_SetAtHeader ws, r, hdr, "S_OUT", soutV
    ONGEN_ML3_SetAtHeader ws, r, hdr, "REVISION", rev
    ONGEN_ML3_SetAtHeader ws, r, hdr, "ACTIVE", "YES"
    ONGEN_ML3_SetAtHeader ws, r, hdr, "SOURCE", "FUNCTION ASSEMBLY"
End Sub

Private Sub ONGEN_ML3_InactivateFunctionComponents(ByVal ws As Worksheet, ByVal fn As String)
    Dim hdr As Long, lastRow As Long, r As Long
    ONGEN_ML3_FindHeaderInTopRows ws, "FUNCTION_CODE", hdr
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = hdr + 1 To lastRow
        If StrComp(Trim$(CStr(ONGEN_ML3_GetAtHeader(ws, r, hdr, "FUNCTION_CODE"))), fn, vbTextCompare) = 0 And _
           UCase$(Trim$(CStr(ONGEN_ML3_GetAtHeader(ws, r, hdr, "ACTIVE")))) <> "NO" Then
            ONGEN_ML3_SetAtHeader ws, r, hdr, "ACTIVE", "NO"
        End If
    Next r
End Sub

Private Sub ONGEN_ML3_UpdateVariantBOMPartReference(ByVal partKey As String, ByVal mfg As String, ByVal partNo As String)
    Dim ws As Worksheet, hdr As Long, lastRow As Long, r As Long
    Set ws = ThisWorkbook.Worksheets(WS_BOM)
    ONGEN_ML3_FindHeaderInTopRows ws, "VARIANT_CODE", hdr
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = hdr + 1 To lastRow
        If StrComp(Trim$(CStr(ONGEN_ML3_GetAtHeader(ws, r, hdr, "PART_KEY"))), partKey, vbTextCompare) = 0 Then
            ONGEN_ML3_SetAtHeader ws, r, hdr, "MANUFACTURER", mfg
            ONGEN_ML3_SetAtHeader ws, r, hdr, "PART_NUMBER", partNo
        End If
    Next r
End Sub

Private Sub ONGEN_ML3_AppendCostHistory(ByVal partKey As String, ByVal costVal As Variant, ByVal curr As String, ByVal vendor As String, ByVal sourceFile As String, ByVal sourceRow As Long, ByVal changeType As String)
    Dim ws As Worksheet, hdr As Long, r As Long
    Set ws = ThisWorkbook.Worksheets(WS_COST)
    ONGEN_ML3_FindHeaderInTopRows ws, "PART_KEY", hdr
    r = ONGEN_ML3_LastUsedRow(ws) + 1
    ONGEN_ML3_SetAtHeader ws, r, hdr, "PART_KEY", partKey
    ONGEN_ML3_SetAtHeader ws, r, hdr, "DATE", Date
    ONGEN_ML3_SetAtHeader ws, r, hdr, "COST", costVal
    ONGEN_ML3_SetAtHeader ws, r, hdr, "CURRENCY", curr
    ONGEN_ML3_SetAtHeader ws, r, hdr, "VENDOR", vendor
    ONGEN_ML3_SetAtHeader ws, r, hdr, "SOURCE_FILE", sourceFile
    ONGEN_ML3_SetAtHeader ws, r, hdr, "SOURCE_ROW", sourceRow
    ONGEN_ML3_SetAtHeader ws, r, hdr, "CHANGE_TYPE", changeType
End Sub

' ============================ SIGNATURE HELPERS ===============================

Private Function ONGEN_ML3_ComponentSignature(ByVal rows As Collection) As String
    Dim arr() As String, i As Long, j As Long, a As Variant, tmp As String
    ReDim arr(1 To rows.Count)
    For i = 1 To rows.Count
        a = rows(i)
        arr(i) = UCase$(Trim$(CStr(a(0)))) & ":" & CStr(CDbl(a(1)))
    Next i
    For i = 1 To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If StrComp(arr(i), arr(j), vbTextCompare) > 0 Then tmp = arr(i): arr(i) = arr(j): arr(j) = tmp
        Next j
    Next i
    For i = 1 To UBound(arr)
        If Len(ONGEN_ML3_ComponentSignature) > 0 Then ONGEN_ML3_ComponentSignature = ONGEN_ML3_ComponentSignature & ";"
        ONGEN_ML3_ComponentSignature = ONGEN_ML3_ComponentSignature & arr(i)
    Next i
End Function

Private Function ONGEN_ML3_BuildFunctionSignature(ByVal groups As Object, ByVal order As Collection) As String
    Dim arr() As String, i As Long, j As Long, rec As Object, rows As Collection, tmp As String, key As String
    ReDim arr(1 To order.Count)
    For i = 1 To order.Count
        Set rec = groups(CStr(order(i)))
        Set rows = rec("ROWS")
        arr(i) = UCase$(CStr(rec("TYPE"))) & "|" & UCase$(CStr(rec("BLOCK"))) & "|" & ONGEN_ML3_ComponentSignature(rows) & "|" & _
                 CStr(rec("INPUT")) & "|" & CStr(rec("OUTPUT")) & "|" & CStr(rec("S_IN")) & "|" & CStr(rec("S_OUT")) & "|" & UCase$(CStr(rec("CONV")))
    Next i
    For i = 1 To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If StrComp(arr(i), arr(j), vbTextCompare) > 0 Then tmp = arr(i): arr(i) = arr(j): arr(j) = tmp
        Next j
    Next i
    For i = 1 To UBound(arr)
        If Len(ONGEN_ML3_BuildFunctionSignature) > 0 Then ONGEN_ML3_BuildFunctionSignature = ONGEN_ML3_BuildFunctionSignature & "||"
        ONGEN_ML3_BuildFunctionSignature = ONGEN_ML3_BuildFunctionSignature & arr(i)
    Next i
End Function

Private Function ONGEN_ML3_FindMatchingVariant(ByVal vws As Worksheet, ByVal signature As String, ByVal componentType As String) As String
    Dim hdr As Long, cCode As Long, cSig As Long, cType As Long, cActive As Long, lastRow As Long, r As Long
    cCode = ONGEN_ML3_FindHeaderInTopRows(vws, "VARIANT_CODE", hdr)
    cSig = ONGEN_ML3_FindHeaderColumn(vws, "BOM_SIGNATURE", hdr)
    cType = ONGEN_ML3_FindHeaderColumn(vws, "COMPONENT_TYPE", hdr)
    cActive = ONGEN_ML3_FindHeaderColumn(vws, "ACTIVE", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(vws)
    For r = hdr + 1 To lastRow
        If StrComp(Trim$(CStr(ONGEN_ML3_CellValue(vws, r, cSig))), signature, vbTextCompare) = 0 And _
           StrComp(ONGEN_ML3_CodeToken(ONGEN_ML3_CellValue(vws, r, cType)), ONGEN_ML3_CodeToken(componentType), vbTextCompare) = 0 And _
           UCase$(Trim$(CStr(ONGEN_ML3_CellValue(vws, r, cActive)))) <> "NO" Then
            ONGEN_ML3_FindMatchingVariant = Trim$(CStr(ONGEN_ML3_CellValue(vws, r, cCode))): Exit Function
        End If
    Next r
End Function

Private Function ONGEN_ML3_FindFunctionBySignature(ByVal fws As Worksheet, ByVal signature As String) As String
    Dim hdr As Long, cFn As Long, cSig As Long, cActive As Long, lastRow As Long, r As Long
    cFn = ONGEN_ML3_FindHeaderInTopRows(fws, "FUNCTION_CODE", hdr)
    cSig = ONGEN_ML3_FindHeaderColumn(fws, "ASSEMBLY_SIGNATURE", hdr)
    cActive = ONGEN_ML3_FindHeaderColumn(fws, "ACTIVE", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(fws)
    For r = hdr + 1 To lastRow
        If StrComp(Trim$(CStr(ONGEN_ML3_CellValue(fws, r, cSig))), signature, vbTextCompare) = 0 And _
           UCase$(Trim$(CStr(ONGEN_ML3_CellValue(fws, r, cActive)))) <> "NO" Then
            ONGEN_ML3_FindFunctionBySignature = Trim$(CStr(ONGEN_ML3_CellValue(fws, r, cFn))): Exit Function
        End If
    Next r
End Function

' ============================== EXPORT / LOG =================================

Public Sub ONGEN_ML3_ExportFunctionLookupCSV()
    Dim ws As Worksheet, hdr As Long, cFn As Long, cDesc As Long, cActive As Long, lastRow As Long, r As Long, f As Integer, pathText As String
    ONGEN_ML3_PrepareWorkbook
    Set ws = ThisWorkbook.Worksheets(WS_FUNCTION)
    cFn = ONGEN_ML3_FindHeaderInTopRows(ws, "FUNCTION_CODE", hdr)
    cDesc = ONGEN_ML3_FindHeaderColumn(ws, "FUNCTION_DESCRIPTION", hdr)
    cActive = ONGEN_ML3_FindHeaderColumn(ws, "ACTIVE", hdr)
    pathText = ThisWorkbook.Path & Application.PathSeparator & LOOKUP_CSV
    f = FreeFile
    Open pathText For Output As #f
    Print #f, "FUNCTION_CODE,FUNCTION_DESCRIPTION"
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = hdr + 1 To lastRow
        If Len(Trim$(CStr(ONGEN_ML3_CellValue(ws, r, cFn)))) > 0 And UCase$(Trim$(CStr(ONGEN_ML3_CellValue(ws, r, cActive)))) <> "NO" Then
            Print #f, ONGEN_ML3_CSV(CStr(ONGEN_ML3_CellValue(ws, r, cFn))) & "," & ONGEN_ML3_CSV(CStr(ONGEN_ML3_CellValue(ws, r, cDesc)))
        End If
    Next r
    Close #f
End Sub

Private Sub ONGEN_ML3_AppendRevision(ByVal changeText As String)
    Dim ws As Worksheet, hdr As Long, r As Long
    Set ws = ThisWorkbook.Worksheets(WS_REV)
    ONGEN_ML3_FindHeaderInTopRows ws, "VERSION", hdr
    r = ONGEN_ML3_LastUsedRow(ws) + 1
    ONGEN_ML3_SetAtHeader ws, r, hdr, "VERSION", ONGEN_ML3_ConfigValue("LIBRARY_VERSION", RELEASE)
    ONGEN_ML3_SetAtHeader ws, r, hdr, "DATE", Now
    ONGEN_ML3_SetAtHeader ws, r, hdr, "AUTHOR", "Lee Pierre"
    ONGEN_ML3_SetAtHeader ws, r, hdr, "CHANGE", changeText
    ONGEN_ML3_SetAtHeader ws, r, hdr, "STATUS", "COMMITTED"
    ONGEN_ML3_SetAtHeader ws, r, hdr, "SOURCE", "MASTER ADMIN V3"
End Sub

Private Sub ONGEN_ML3_AppendImportLog(ByVal sourceFile As String, ByVal rowsRead As Long, ByVal statusText As String)
    Dim ws As Worksheet, hdr As Long, r As Long
    If Not ONGEN_ML3_SheetExists(WS_IMPORT_LOG) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(WS_IMPORT_LOG)
    ONGEN_ML3_FindHeaderInTopRows ws, "IMPORT_DATE", hdr
    r = ONGEN_ML3_LastUsedRow(ws) + 1
    ONGEN_ML3_SetAtHeader ws, r, hdr, "IMPORT_DATE", Now
    ONGEN_ML3_SetAtHeader ws, r, hdr, "SOURCE_FILE", sourceFile
    ONGEN_ML3_SetAtHeader ws, r, hdr, "ROWS_READ", rowsRead
    ONGEN_ML3_SetAtHeader ws, r, hdr, "STATUS", statusText
End Sub

Private Sub ONGEN_ML3_BumpLibraryVersion()
    Dim ws As Worksheet, hdr As Long, r As Long, v As String, a() As String, major As Long, minor As Long, patch As Long
    Set ws = ThisWorkbook.Worksheets(WS_CONFIG)
    r = ONGEN_ML3_FindRowByField(ws, "SETTING", "LIBRARY_VERSION", hdr)
    If r = 0 Then Exit Sub
    v = Trim$(CStr(ONGEN_ML3_GetAtHeader(ws, r, hdr, "VALUE")))
    a = Split(v, ".")
    If UBound(a) >= 2 Then
        major = Val(a(0)): minor = Val(a(1)): patch = Val(a(2)) + 1
        ONGEN_ML3_SetAtHeader ws, r, hdr, "VALUE", CStr(major) & "." & CStr(minor) & "." & CStr(patch)
    Else
        ONGEN_ML3_SetAtHeader ws, r, hdr, "VALUE", RELEASE & ".1"
    End If
End Sub

' =============================== VALIDATION ==================================

Private Function ONGEN_ML3_IsValidPartType(ByVal pType As String) As Boolean
    Dim ws As Worksheet, hdr As Long, c As Long, lastRow As Long, r As Long
    Set ws = ThisWorkbook.Worksheets(WS_TYPES)
    c = ONGEN_ML3_FindHeaderInTopRows(ws, "PART_TYPE", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = hdr + 1 To lastRow
        If StrComp(ONGEN_ML3_CodeToken(ws.Cells(r, c).Value2), ONGEN_ML3_CodeToken(pType), vbTextCompare) = 0 Then ONGEN_ML3_IsValidPartType = True: Exit Function
    Next r
End Function

Private Function ONGEN_ML3_SuggestPartType(ByVal descr As String, ByVal groupDesc As String) As String
    Dim s As String
    s = UCase$(descr & " " & groupDesc)
    Select Case True
        Case InStr(s, "FREQUENCY INVERTER") > 0 Or InStr(s, " VFD") > 0 Or InStr(s, "INVERTER") > 0: ONGEN_ML3_SuggestPartType = "VFD"
        Case InStr(s, "POWER SUPPLY") > 0: ONGEN_ML3_SuggestPartType = "PSU"
        Case InStr(s, "SCANNER") > 0: ONGEN_ML3_SuggestPartType = "SCN"
        Case InStr(s, "ROPE PULL") > 0 Or InStr(s, "PULL CORD") > 0: ONGEN_ML3_SuggestPartType = "EPC"
        Case InStr(s, "EMERGENCY STOP") > 0 Or InStr(s, "E-STOP") > 0 Or InStr(s, "ESTOP") > 0: ONGEN_ML3_SuggestPartType = "EST"
        Case InStr(s, "TOWER LIGHT") > 0 Or InStr(s, "INDICATOR") > 0 Or InStr(s, "EZ-LIGHT") > 0 Or InStr(s, "BEACON") > 0: ONGEN_ML3_SuggestPartType = "B"
        Case InStr(s, "PUSHBUTTON") > 0 Or InStr(s, "PUSH BUTTON") > 0 Or InStr(s, "BUTTON") > 0: ONGEN_ML3_SuggestPartType = "PBL"
        Case InStr(s, "CABLE") > 0 Or InStr(s, "CORDSET") > 0 Or InStr(s, "CORD SET") > 0: ONGEN_ML3_SuggestPartType = "CBL"
        Case InStr(s, "CONNECTOR") > 0 Or InStr(s, "GLAND") > 0 Or InStr(s, "ADAPTER") > 0 Or InStr(s, "PLUG") > 0 Or InStr(s, "SOCKET") > 0: ONGEN_ML3_SuggestPartType = "CON"
        Case InStr(s, "CABINET") > 0: ONGEN_ML3_SuggestPartType = "CAB"
        Case InStr(s, "MOUNTING") > 0 Or InStr(s, "BRACKET") > 0: ONGEN_ML3_SuggestPartType = "MNT"
        Case InStr(s, "CONTROLS") > 0: ONGEN_ML3_SuggestPartType = "CTRL"
        Case Else: ONGEN_ML3_SuggestPartType = "AUX"
    End Select
End Function

Private Function ONGEN_ML3_PartNumberExistsUnderDifferentManufacturer(ByVal pws As Worksheet, ByVal partNo As String, ByVal mfg As String) As Boolean
    Dim hdr As Long, cPart As Long, cMfg As Long, lastRow As Long, r As Long
    cPart = ONGEN_ML3_FindHeaderInTopRows(pws, "PART_NUMBER", hdr)
    cMfg = ONGEN_ML3_FindHeaderColumn(pws, "MANUFACTURER", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(pws)
    For r = hdr + 1 To lastRow
        If ONGEN_ML3_NormalizePartNumber(ONGEN_ML3_CellValue(pws, r, cPart)) = ONGEN_ML3_NormalizePartNumber(partNo) And _
           ONGEN_ML3_NormalizeManufacturer(ONGEN_ML3_CellValue(pws, r, cMfg)) <> ONGEN_ML3_NormalizeManufacturer(mfg) Then
            ONGEN_ML3_PartNumberExistsUnderDifferentManufacturer = True: Exit Function
        End If
    Next r
End Function

' ============================== SHEET SETUP ==================================

Private Sub ONGEN_ML3_EnsureSystemHeaders()
    Dim ws As Worksheet, hdr As Long, h As Variant
    Set ws = ThisWorkbook.Worksheets(WS_PART)
    ONGEN_ML3_FindHeaderInTopRows ws, "PART_KEY", hdr
    For Each h In Array("PART_TYPE", "NORMALIZED_MANUFACTURER", "NORMALIZED_PART_NUMBER", "PART_DESCRIPTION", "RATING_SIZE", "DEVICE_VARIANT_CODE", "CURRENT_COST", "COST_CURRENCY", "COST_AS_OF_DATE", "PREFERRED_VENDOR", "FIXED_VENDOR", "MATERIALS_GROUP", "MATERIALS_GROUP_DESC", "COST_SOURCE", "NOTES", "REVISION", "ACTIVE", "CREATED_DATE", "MODIFIED_DATE", "REPLACED_BY")
        ONGEN_ML3_EnsureHeaderAtHeaderRow ws, CStr(h), hdr
    Next h
    Set ws = ThisWorkbook.Worksheets(WS_VARIANT)
    ONGEN_ML3_FindHeaderInTopRows ws, "VARIANT_CODE", hdr
    For Each h In Array("COMPONENT_TYPE", "DESCRIPTION", "REVISION", "ACTIVE", "SOURCE", "CREATED_DATE", "MODIFIED_DATE", "BOM_SIGNATURE")
        ONGEN_ML3_EnsureHeaderAtHeaderRow ws, CStr(h), hdr
    Next h
    Set ws = ThisWorkbook.Worksheets(WS_FUNCTION)
    ONGEN_ML3_FindHeaderInTopRows ws, "FUNCTION_CODE", hdr
    For Each h In Array("FUNCTION_FAMILY", "FUNCTION_DESCRIPTION", "CONTROL_FUNCTION_TAGS", "BLOCKS", "CONVEYOR_TYPES", "REVISION", "ACTIVE", "SOURCE", "STATUS", "CREATED_DATE", "MODIFIED_DATE", "ENGINEERING_NOTES", "ASSEMBLY_SIGNATURE")
        ONGEN_ML3_EnsureHeaderAtHeaderRow ws, CStr(h), hdr
    Next h
End Sub

' ================================ GENERIC ====================================

Private Function ONGEN_ML3_SelectedResultRow(ByVal ws As Worksheet, ByVal firstRow As Long, ByVal lastRow As Long, ByVal selectCol As Long) As Long
    Dim r As Long, s As String
    For r = firstRow To lastRow
        s = UCase$(Trim$(CStr(ws.Cells(r, selectCol).Value2)))
        If s = "X" Or s = "YES" Or s = "1" Then ONGEN_ML3_SelectedResultRow = r: Exit Function
    Next r
    If ActiveSheet.Name = ws.Name And ActiveCell.Row >= firstRow And ActiveCell.Row <= lastRow Then ONGEN_ML3_SelectedResultRow = ActiveCell.Row
End Function

Private Function ONGEN_ML3_FindExactPartRow(ByVal ws As Worksheet, ByVal mfg As String, ByVal partNo As String, ByRef hdr As Long) As Long
    Dim cMfg As Long, cPart As Long, lastRow As Long, r As Long
    ONGEN_ML3_FindHeaderInTopRows ws, "PART_KEY", hdr
    cMfg = ONGEN_ML3_FindHeaderColumn(ws, "MANUFACTURER", hdr)
    cPart = ONGEN_ML3_FindHeaderColumn(ws, "PART_NUMBER", hdr)
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = hdr + 1 To lastRow
        If ONGEN_ML3_NormalizeManufacturer(ws.Cells(r, cMfg).Value2) = ONGEN_ML3_NormalizeManufacturer(mfg) And _
           ONGEN_ML3_NormalizePartNumber(ws.Cells(r, cPart).Value2) = ONGEN_ML3_NormalizePartNumber(partNo) Then
            ONGEN_ML3_FindExactPartRow = r: Exit Function
        End If
    Next r
End Function

Private Function ONGEN_ML3_FindPartRowByKey(ByVal ws As Worksheet, ByVal partKey As String, ByRef hdr As Long) As Long
    ONGEN_ML3_FindPartRowByKey = ONGEN_ML3_FindRowByField(ws, "PART_KEY", partKey, hdr)
End Function

Private Function ONGEN_ML3_FindRowByField(ByVal ws As Worksheet, ByVal headerName As String, ByVal target As String, ByRef hdr As Long) As Long
    Dim c As Long, lastRow As Long, r As Long
    c = ONGEN_ML3_FindHeaderInTopRows(ws, headerName, hdr)
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = hdr + 1 To lastRow
        If StrComp(Trim$(CStr(ws.Cells(r, c).Value2)), Trim$(target), vbTextCompare) = 0 Then ONGEN_ML3_FindRowByField = r: Exit Function
    Next r
End Function

Private Function ONGEN_ML3_NextCode(ByVal ws As Worksheet, ByVal headerName As String, ByVal prefix As String, ByVal digits As Long) As String
    Dim hdr As Long, c As Long, lastRow As Long, r As Long, s As String, n As Long, maxN As Long
    c = ONGEN_ML3_FindHeaderInTopRows(ws, headerName, hdr)
    lastRow = ONGEN_ML3_LastUsedRow(ws)
    For r = hdr + 1 To lastRow
        s = UCase$(Trim$(CStr(ws.Cells(r, c).Value2)))
        If Left$(s, Len(prefix)) = UCase$(prefix) Then
            n = Val(Mid$(s, Len(prefix) + 1))
            If n > maxN Then maxN = n
        End If
    Next r
    ONGEN_ML3_NextCode = UCase$(prefix) & Format$(maxN + 1, String$(digits, "0"))
End Function

Private Function ONGEN_ML3_NextRevision(ByVal rev As String) As String
    rev = UCase$(Trim$(rev))
    If Len(rev) = 0 Then ONGEN_ML3_NextRevision = "A": Exit Function
    If Len(rev) = 1 And rev >= "A" And rev < "Z" Then ONGEN_ML3_NextRevision = Chr$(Asc(rev) + 1) Else ONGEN_ML3_NextRevision = rev & "A"
End Function

Private Function ONGEN_ML3_ConfigValue(ByVal settingName As String, ByVal defaultValue As String) As String
    Dim ws As Worksheet, hdr As Long, r As Long
    Set ws = ThisWorkbook.Worksheets(WS_CONFIG)
    r = ONGEN_ML3_FindRowByField(ws, "SETTING", settingName, hdr)
    If r > 0 Then ONGEN_ML3_ConfigValue = CStr(ONGEN_ML3_GetAtHeader(ws, r, hdr, "VALUE")) Else ONGEN_ML3_ConfigValue = defaultValue
End Function

Private Function ONGEN_ML3_NormalizeManufacturer(ByVal v As Variant) As String
    ONGEN_ML3_NormalizeManufacturer = UCase$(WorksheetFunction.Trim(CStr(v)))
End Function

Private Function ONGEN_ML3_NormalizePartNumber(ByVal v As Variant) As String
    ONGEN_ML3_NormalizePartNumber = UCase$(Replace(Replace(Replace(Trim$(CStr(v)), " ", ""), vbTab, ""), Chr$(160), ""))
End Function

Private Function ONGEN_ML3_CodeToken(ByVal v As Variant) As String
    Dim s As String, i As Long, ch As String, out As String
    s = UCase$(Trim$(CStr(v)))
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If (ch >= "A" And ch <= "Z") Or (ch >= "0" And ch <= "9") Or ch = "-" Then out = out & ch
    Next i
    ONGEN_ML3_CodeToken = out
End Function

Private Function ONGEN_ML3_ValueChanged(ByVal a As Variant, ByVal b As Variant) As Boolean
    If Len(Trim$(CStr(a))) = 0 And Len(Trim$(CStr(b))) = 0 Then Exit Function
    If IsNumeric(a) And IsNumeric(b) Then ONGEN_ML3_ValueChanged = (Abs(CDbl(a) - CDbl(b)) > 0.000001) Else ONGEN_ML3_ValueChanged = (CStr(a) <> CStr(b))
End Function

Private Function ONGEN_ML3_JoinUnique(ByVal currentText As String, ByVal addText As String) As String
    Dim s As String
    s = Trim$(addText)
    If Len(s) = 0 Then ONGEN_ML3_JoinUnique = currentText: Exit Function
    If InStr(1, "|" & UCase$(currentText) & "|", "|" & UCase$(s) & "|", vbTextCompare) > 0 Then ONGEN_ML3_JoinUnique = currentText: Exit Function
    If Len(currentText) = 0 Then ONGEN_ML3_JoinUnique = s Else ONGEN_ML3_JoinUnique = currentText & " | " & s
End Function

Private Function ONGEN_ML3_CSV(ByVal textValue As String) As String
    Dim quoteChar As String
    quoteChar = Chr$(34)
    ONGEN_ML3_CSV = quoteChar & Replace(textValue, quoteChar, quoteChar & quoteChar) & quoteChar
End Function

Private Function ONGEN_ML3_SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    ONGEN_ML3_SheetExists = Not ws Is Nothing
End Function

Private Function ONGEN_ML3_FindHeaderInTopRows(ByVal ws As Worksheet, ByVal headerText As String, ByRef headerRow As Long) As Long
    Dim r As Long, c As Long
    For r = 1 To 20
        c = ONGEN_ML3_FindHeaderColumn(ws, headerText, r)
        If c > 0 Then headerRow = r: ONGEN_ML3_FindHeaderInTopRows = c: Exit Function
    Next r
End Function

Private Function ONGEN_ML3_FindHeaderColumn(ByVal ws As Worksheet, ByVal headerText As String, ByVal headerRow As Long) As Long
    Dim lastCol As Long, c As Long
    lastCol = ws.Cells(headerRow, ws.Columns.Count).End(xlToLeft).Column
    For c = 1 To lastCol
        If StrComp(Trim$(CStr(ws.Cells(headerRow, c).Value2)), headerText, vbTextCompare) = 0 Then ONGEN_ML3_FindHeaderColumn = c: Exit Function
    Next c
End Function

Private Function ONGEN_ML3_FindHeaderByAliasesInTopRows(ByVal ws As Worksheet, ByVal aliases As Variant, ByRef headerRow As Long) As Long
    Dim r As Long, c As Long
    For r = 1 To 20
        c = ONGEN_ML3_FindHeaderByAliases(ws, r, aliases)
        If c > 0 Then headerRow = r: ONGEN_ML3_FindHeaderByAliasesInTopRows = c: Exit Function
    Next r
End Function

Private Function ONGEN_ML3_FindHeaderByAliases(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal aliases As Variant) As Long
    Dim lastCol As Long, c As Long, a As Variant, h As String
    lastCol = ws.Cells(headerRow, ws.Columns.Count).End(xlToLeft).Column
    For c = 1 To lastCol
        h = UCase$(Trim$(CStr(ws.Cells(headerRow, c).Value2)))
        For Each a In aliases
            If h = UCase$(Trim$(CStr(a))) Then ONGEN_ML3_FindHeaderByAliases = c: Exit Function
        Next a
    Next c
End Function

Private Function ONGEN_ML3_EnsureHeaderAtHeaderRow(ByVal ws As Worksheet, ByVal headerText As String, ByVal headerRow As Long) As Long
    Dim c As Long, lastCol As Long
    c = ONGEN_ML3_FindHeaderColumn(ws, headerText, headerRow)
    If c > 0 Then ONGEN_ML3_EnsureHeaderAtHeaderRow = c: Exit Function
    lastCol = ws.Cells(headerRow, ws.Columns.Count).End(xlToLeft).Column
    c = lastCol + 1
    ws.Cells(headerRow, c).Value = headerText
    ONGEN_ML3_EnsureHeaderAtHeaderRow = c
End Function

Private Sub ONGEN_ML3_SetAtHeader(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal headerRow As Long, ByVal headerText As String, ByVal valueData As Variant)
    ws.Cells(rowNo, ONGEN_ML3_EnsureHeaderAtHeaderRow(ws, headerText, headerRow)).Value = valueData
End Sub

Private Function ONGEN_ML3_GetAtHeader(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal headerRow As Long, ByVal headerText As String) As Variant
    Dim c As Long
    c = ONGEN_ML3_FindHeaderColumn(ws, headerText, headerRow)
    If c > 0 Then ONGEN_ML3_GetAtHeader = ws.Cells(rowNo, c).Value Else ONGEN_ML3_GetAtHeader = vbNullString
End Function

Private Function ONGEN_ML3_CellValue(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal colNo As Long) As Variant
    If colNo > 0 Then ONGEN_ML3_CellValue = ws.Cells(rowNo, colNo).Value Else ONGEN_ML3_CellValue = vbNullString
End Function

Private Function ONGEN_ML3_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If f Is Nothing Then ONGEN_ML3_LastUsedRow = 1 Else ONGEN_ML3_LastUsedRow = f.Row
End Function
