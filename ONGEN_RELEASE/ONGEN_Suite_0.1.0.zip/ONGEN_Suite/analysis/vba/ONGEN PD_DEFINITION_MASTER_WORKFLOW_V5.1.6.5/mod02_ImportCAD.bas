Attribute VB_Name = "mod02_ImportCAD"
Option Explicit

Sub Import_CSV_To_SIS_TAG_EXPORT()

    Dim csvFile As Variant
    Dim wbCSV As Workbook
    Dim wsCSV As Worksheet
    Dim wsDest As Worksheet
    Dim lastRow As Long
    Dim lastCol As Long
    
    On Error GoTo ErrHandler
    
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.EnableEvents = False
    
    'Ask user to pick CSV file
    csvFile = Application.GetOpenFilename( _
        FileFilter:="CSV Files (*.csv), *.csv", _
        title:="Select SIS_TAG_EXPORT CSV File")
    
    If csvFile = False Then
        MsgBox "Import cancelled.", vbInformation
        GoTo SafeExit
    End If
    
    'Get or create destination sheet
    Set wsDest = Nothing
    On Error Resume Next
    Set wsDest = ThisWorkbook.Worksheets("SIS_TAG_EXPORT")
    On Error GoTo ErrHandler
    
    If wsDest Is Nothing Then
        Set wsDest = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        wsDest.name = "SIS_TAG_EXPORT"
        mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation wsDest
    End If
    
    'Open CSV
    Set wbCSV = Workbooks.Open(Filename:=CStr(csvFile))
    Set wsCSV = wbCSV.Worksheets(1)
    
    'Find used range
    If Application.WorksheetFunction.CountA(wsCSV.Cells) = 0 Then
        MsgBox "The selected CSV file is empty.", vbExclamation
        GoTo SafeExit
    End If
    
    lastRow = wsCSV.Cells.Find(What:="*", SearchOrder:=xlByRows, SearchDirection:=xlPrevious).Row
    lastCol = wsCSV.Cells.Find(What:="*", SearchOrder:=xlByColumns, SearchDirection:=xlPrevious).Column
    
    'Clear destination and copy data
    wsDest.UsedRange.Clear
    wsCSV.Range(wsCSV.Cells(1, 1), wsCSV.Cells(lastRow, lastCol)).Copy
    wsDest.Range("A1").PasteSpecial Paste:=xlPasteValues
    Application.CutCopyMode = False
    
    wbCSV.Close SaveChanges:=False
    
    MsgBox "CSV imported successfully into sheet 'SIS_TAG_EXPORT'.", vbInformation

SafeExit:
    On Error Resume Next
    If Not wbCSV Is Nothing Then wbCSV.Close SaveChanges:=False
    Application.CutCopyMode = False
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Exit Sub

ErrHandler:
    MsgBox "Error: " & Err.description, vbCritical
    Resume SafeExit

End Sub

