Attribute VB_Name = "mod16_IOBlockLibrary"
Option Explicit

Sub Fill_IO_BlockFromLibraryWorkbook()

    Dim wbDest As Workbook
    Dim wsDest As Worksheet
    
    Dim wbLib As Workbook
    Dim wsLib As Worksheet
    
    Dim FilePath As Variant
    Dim lastRowDest As Long
    Dim lastRowLib As Long
    
    Dim colTypeDest As Long
    Dim colBlockDest As Long
    Dim colTypeLib As Long
    Dim colBlockLib As Long
    
    Dim dict As Object
    Dim i As Long
    Dim key As String
    Dim filledCount As Long
    Dim notFoundCount As Long
    
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    
    On Error GoTo CleanFail
    
    Set wbDest = ThisWorkbook
    
    '--- Destination sheet
    On Error Resume Next
    Set wsDest = wbDest.Worksheets("IO DEVICE EM")
    On Error GoTo CleanFail
    
    If wsDest Is Nothing Then
        MsgBox "Sheet 'IO DEVICE EM' was not found in this workbook.", vbExclamation
        GoTo SafeExit
    End If
    
    '--- Ask user to select library workbook
    FilePath = Application.GetOpenFilename( _
        FileFilter:="Excel Files (*.xls*), *.xls*", _
        title:="Select the workbook that contains the 'Library' sheet")
    
    If FilePath = False Then
        MsgBox "Operation cancelled. No workbook selected.", vbInformation
        GoTo SafeExit
    End If
    
    '--- Open selected workbook
    Set wbLib = Workbooks.Open(CStr(FilePath), ReadOnly:=True)
    
    On Error Resume Next
    Set wsLib = wbLib.Worksheets("Library")
    On Error GoTo CleanFail
    
    If wsLib Is Nothing Then
        MsgBox "Sheet 'Library' was not found in the selected workbook.", vbExclamation
        GoTo SafeExit
    End If
    
    '--- Find required headers
    colTypeDest = FindHeaderColumn(wsDest, "TYPE")
    colBlockDest = FindHeaderColumn(wsDest, "BLOCK")
    
    colTypeLib = FindHeaderColumn(wsLib, "TYPE")
    colBlockLib = FindHeaderColumn(wsLib, "BLOCK")
    
    If colTypeDest = 0 Then
        MsgBox "'TYPE' header not found on sheet 'IO DEVICE EM'.", vbExclamation
        GoTo SafeExit
    End If
    
    If colBlockDest = 0 Then
        MsgBox "'BLOCK' header not found on sheet 'IO DEVICE EM'.", vbExclamation
        GoTo SafeExit
    End If
    
    If colTypeLib = 0 Then
        MsgBox "'TYPE' header not found on sheet 'Library'.", vbExclamation
        GoTo SafeExit
    End If
    
    If colBlockLib = 0 Then
        MsgBox "'BLOCK' header not found on sheet 'Library'.", vbExclamation
        GoTo SafeExit
    End If
    
    '--- Build dictionary from Library sheet: TYPE -> BLOCK
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare
    
    lastRowLib = wsLib.Cells(wsLib.rows.count, colTypeLib).End(xlUp).Row
    
    For i = 2 To lastRowLib
        key = Trim(CStr(wsLib.Cells(i, colTypeLib).Value))
        
        If key <> "" Then
            If Not dict.Exists(key) Then
                dict.Add key, Trim(CStr(wsLib.Cells(i, colBlockLib).Value))
            End If
        End If
    Next i
    
    '--- Fill IO DEVICE EM Block column
    lastRowDest = wsDest.Cells(wsDest.rows.count, colTypeDest).End(xlUp).Row
    
    For i = 2 To lastRowDest
        key = Trim(CStr(wsDest.Cells(i, colTypeDest).Value))
        
        If key <> "" Then
            If dict.Exists(key) Then
                wsDest.Cells(i, colBlockDest).Value = dict(key)
                filledCount = filledCount + 1
            Else
                notFoundCount = notFoundCount + 1
            End If
        End If
    Next i
    
    MsgBox "Done." & vbCrLf & vbCrLf & _
           "Blocks filled: " & filledCount & vbCrLf & _
           "Types not found in Library: " & notFoundCount, vbInformation

SafeExit:
    On Error Resume Next
    If Not wbLib Is Nothing Then wbLib.Close SaveChanges:=False
    
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Exit Sub

CleanFail:
    MsgBox "Error: " & Err.description, vbCritical
    Resume SafeExit

End Sub

Private Function FindHeaderColumn(ws As Worksheet, headerName As String) As Long
    Dim lastCol As Long
    Dim c As Long
    
    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    
    For c = 1 To lastCol
        If Trim(UCase(CStr(ws.Cells(1, c).Value))) = Trim(UCase(headerName)) Then
            FindHeaderColumn = c
            Exit Function
        End If
    Next c
    
    FindHeaderColumn = 0
End Function





