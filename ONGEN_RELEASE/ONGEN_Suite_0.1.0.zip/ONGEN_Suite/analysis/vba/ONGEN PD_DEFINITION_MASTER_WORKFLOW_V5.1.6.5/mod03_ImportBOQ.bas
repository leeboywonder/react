Attribute VB_Name = "mod03_ImportBOQ"
Option Explicit

Public Sub BOQ_Import()
    If PDPerf_IsYielding Then Exit Sub
    Dim srcWB As Workbook, srcWS As Worksheet, dstWS As Worksheet
    Dim f As Variant, hdrs As Variant, aliases As Variant
    Dim hr As Long, lr As Long, n As Long, i As Long, sc As Long
    Dim missing As String

    On Error GoTo Fail
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual

    f = Application.GetOpenFilename("Excel Workbooks (*.xlsx;*.xlsm;*.xlsb;*.xls),*.xlsx;*.xlsm;*.xlsb;*.xls", , _
                                    "Phase 1B - Select workbook containing conveyor BOQ data")
    If VarType(f) = vbBoolean Then GoTo done

    Set srcWB = Workbooks.Open(CStr(f), ReadOnly:=True, UpdateLinks:=False)
    Set srcWS = BOQ_FindSourceSheet(srcWB, hr)
    If srcWS Is Nothing Then
        MsgBox "No worksheet containing 'Layout Position Number' and 'Conveyor Type' could be found." & vbCrLf & _
               "The source sheet does not have to be named BOQ.", vbCritical, "Phase 1B - Import BOQ"
        GoTo done
    End If

    hdrs = Array( _
        "Layout Position Number", "Product Code", "Qty of Modules", "System Type", "Conveyor Type", _
        "Module Length (ML)", "Zone Length (ZL)", "Qty of Zones", "Total Qty of Drives", _
        "Motor Type 1  (Main Drive)", "Motor Power (Main Drive)", "Motor Voltage (Main Drive)", _
        "Motor Brake Voltage (Main Drive)", "Motor Protection (Main Drive)", "Encoder Type (Main Drive)", _
        "Total Qty of Sensors", "Control Card", "x Coord", "y Coord", "z Coord", "Insertion Angle", _
        "Control Card Abbreviation", "Qty of Control Card")

    aliases = Array( _
        Array("Layout Position Number", "LPN"), Array("Product Code"), Array("Qty of Modules"), Array("System Type"), _
        Array("Conveyor Type"), Array("Module Length (ML)"), Array("Zone Length (ZL)"), Array("Qty of Zones"), _
        Array("Total Qty of Drives"), Array("Motor Type 1 (Main Drive)"), Array("Motor Power (Main Drive)"), _
        Array("Motor Voltage (Main Drive)"), Array("Motor Brake Voltage (Main Drive)"), Array("Motor Protection (Main Drive)"), _
        Array("Encoder Type (Main Drive)"), Array("Total Qty of Sensors"), Array("Control Card"), _
        Array("x Coord", "X"), Array("y Coord", "Y"), Array("z Coord", "Z"), Array("Insertion Angle", "ROTATION_DEG"), _
        Array("Control Card Abbreviation"), Array("Qty of Control Card"))

    Set dstWS = BOQ_GetOrCreate(ThisWorkbook, "BOQ")
    dstWS.UsedRange.ClearContents
    For i = 0 To UBound(hdrs)
        dstWS.Cells(1, i + 1).Value = hdrs(i)
        dstWS.Cells(1, i + 1).Font.Bold = True
        sc = BOQ_FindHeaderAny(srcWS, hr, aliases(i))
        If sc = 0 Then
            If i = 0 Or i = 4 Then missing = missing & vbCrLf & "- " & hdrs(i)
        Else
            lr = BOQ_LastRowInColumn(srcWS, sc)
            If lr > hr Then
                n = lr - hr
                dstWS.Cells(2, i + 1).Resize(n, 1).Value2 = srcWS.Cells(hr + 1, sc).Resize(n, 1).Value2
            End If
        End If
    Next i

    If Len(missing) > 0 Then
        MsgBox "The selected worksheet is missing required BOQ fields:" & missing, vbCritical, "Phase 1B - Import BOQ"
        GoTo done
    End If

    dstWS.rows(1).WrapText = True
    dstWS.UsedRange.Columns.AutoFit
    MsgBox "BOQ import completed successfully." & vbCrLf & vbCrLf & _
           "Source sheet: " & srcWS.name & vbCrLf & _
           "Detected header row: " & hr & vbCrLf & _
           "Definition sheet: BOQ", vbInformation, "Phase 1B - Import BOQ"

done:
    On Error Resume Next
    If Not srcWB Is Nothing Then srcWB.Close SaveChanges:=False
    If Not PDPerf_IsRunning Then Application.Calculation = xlCalculationAutomatic
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Exit Sub
Fail:
    MsgBox "Phase 1B failed: " & Err.description, vbCritical, "Import BOQ"
    Resume done
End Sub

Private Function BOQ_FindSourceSheet(ByVal wb As Workbook, ByRef headerRow As Long) As Worksheet
    Dim ws As Worksheet, r As Long, bestScore As Long, score As Long, bestRow As Long
    For Each ws In wb.Worksheets
        PDPerf_Pulse "mod03_ImportBOQ.BOQ_FindSourceSheet [L89]"
        For r = 1 To BOQ_Min(30, BOQ_LastUsedRow(ws))
            PDPerf_Pulse "mod03_ImportBOQ.BOQ_FindSourceSheet [L90]" & " row " & CStr(r)
            If BOQ_FindHeaderAny(ws, r, Array("Layout Position Number", "LPN")) > 0 Then
                If BOQ_FindHeaderAny(ws, r, Array("Conveyor Type", "CONVEYOR_TYPE", "CONVEYOR TYPE")) > 0 Then
                    score = BOQ_HeaderScore(ws, r)
                    If score > bestScore Then
                        bestScore = score: bestRow = r: Set BOQ_FindSourceSheet = ws
                    End If
                End If
            End If
        Next r
    Next ws
    headerRow = bestRow
End Function

Private Function BOQ_HeaderScore(ByVal ws As Worksheet, ByVal r As Long) As Long
    Dim a As Variant, x As Variant
    a = Array("Layout Position Number", "Conveyor Type", "Module Length (ML)", "Motor Power (Main Drive)", _
              "Motor Voltage (Main Drive)", "Total Qty of Drives", "Control Card", "Insertion Angle")
    For Each x In a
        PDPerf_Pulse "mod03_ImportBOQ.BOQ_HeaderScore [L108]"
        If BOQ_FindHeaderAny(ws, r, Array(CStr(x))) > 0 Then BOQ_HeaderScore = BOQ_HeaderScore + 1
    Next x
End Function

Private Function BOQ_FindHeaderAny(ByVal ws As Worksheet, ByVal r As Long, ByVal names As Variant) As Long
    Dim c As Long, lc As Long, x As Variant, v As String
    lc = ws.Cells(r, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lc
        v = BOQ_Norm(ws.Cells(r, c).Value)
        If Len(v) > 0 Then
            For Each x In names
                PDPerf_Pulse "mod03_ImportBOQ.BOQ_FindHeaderAny [L119]"
                If v = BOQ_Norm(x) Then BOQ_FindHeaderAny = c: Exit Function
            Next x
        End If
    Next c
End Function

Private Function BOQ_Norm(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(v)))
    s = Replace(s, vbCr, " "): s = Replace(s, vbLf, " ")
    s = Replace(s, "_", " "): s = Replace(s, "-", " "): s = Replace(s, "(", ""): s = Replace(s, ")", "")
    Do While InStr(s, "  ") > 0: s = Replace(s, "  ", " "): Loop
    BOQ_Norm = s
End Function

Private Function BOQ_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then BOQ_LastUsedRow = f.Row Else BOQ_LastUsedRow = 1
End Function

Private Function BOQ_LastRowInColumn(ByVal ws As Worksheet, ByVal c As Long) As Long
    BOQ_LastRowInColumn = ws.Cells(ws.rows.count, c).End(xlUp).Row
End Function

Private Function BOQ_GetOrCreate(ByVal wb As Workbook, ByVal nm As String) As Worksheet
    On Error Resume Next
    Set BOQ_GetOrCreate = wb.Worksheets(nm)
    On Error GoTo 0
    If BOQ_GetOrCreate Is Nothing Then
        Set BOQ_GetOrCreate = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        BOQ_GetOrCreate.name = nm
        If wb Is ThisWorkbook Then mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation BOQ_GetOrCreate
    End If
End Function

Private Function BOQ_Min(ByVal a As Long, ByVal b As Long) As Long
    If a < b Then BOQ_Min = a Else BOQ_Min = b
End Function
