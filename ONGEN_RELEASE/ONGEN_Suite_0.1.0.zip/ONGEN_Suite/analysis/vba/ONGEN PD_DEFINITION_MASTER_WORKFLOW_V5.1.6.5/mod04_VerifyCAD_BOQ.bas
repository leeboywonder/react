Attribute VB_Name = "mod04_VerifyCAD_BOQ"
Option Explicit

' Phase 1C is QA only. It must never rewrite SIS_TAG_PD5.
Public Sub Verify_SIS_TAG_EXPORT_From_BOQ_v2()
    If PDPerf_IsYielding Then Exit Sub
    Dim b As Worksheet, s As Worksheet, m As Worksheet
    Dim cb As Long, cs As Long, ct As Long, r As Long, rr As Long
    Dim db As Object, ds As Object, k As Variant
    Dim matched As Long, missBOQ As Long, missCAD As Long

    On Error GoTo Fail
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    Set b = V_GetSheet("BOQ")
    Set s = V_GetSheet("SIS_TAG_EXPORT")
    If b Is Nothing Then MsgBox "Sheet 'BOQ' was not found. Run Phase 1B first.", vbCritical: GoTo done
    If s Is Nothing Then MsgBox "Sheet 'SIS_TAG_EXPORT' was not found. Run Phase 1A first.", vbCritical: GoTo done

    cb = V_FindHdr(b, "Layout Position Number")
    ct = V_FindHdr(b, "Conveyor Type")
    cs = V_FindHdr(s, "LPN")
    If cb = 0 Then MsgBox "BOQ header 'Layout Position Number' was not found.", vbCritical: GoTo done
    If cs = 0 Then MsgBox "SIS_TAG_EXPORT header 'LPN' was not found.", vbCritical: GoTo done

    Set db = CreateObject("Scripting.Dictionary"): db.CompareMode = vbTextCompare
    Set ds = CreateObject("Scripting.Dictionary"): ds.CompareMode = vbTextCompare

    For r = 2 To V_LastRow(b, cb)
        PDPerf_Pulse "mod04_VerifyCAD_BOQ.Verify_SIS_TAG_EXPORT_From_BOQ_v2 [L29]" & " row " & CStr(r)
        k = V_Key(b.Cells(r, cb).Value)
        If Len(k) > 0 Then If Not db.Exists(k) Then db.Add k, r
    Next r
    For r = 2 To V_LastRow(s, cs)
        PDPerf_Pulse "mod04_VerifyCAD_BOQ.Verify_SIS_TAG_EXPORT_From_BOQ_v2 [L33]" & " row " & CStr(r)
        k = V_Key(s.Cells(r, cs).Value)
        If Len(k) > 0 Then If Not ds.Exists(k) Then ds.Add k, r
    Next r

    Set m = V_GetOrCreate("MISSING_LPN")
    m.UsedRange.ClearContents
    m.Range("A1:C1").Value = Array("Layout Position Number", "Conveyor Type", "Issue")
    m.rows(1).Font.Bold = True
    rr = 2

    For Each k In db.Keys
        PDPerf_Pulse "mod04_VerifyCAD_BOQ.Verify_SIS_TAG_EXPORT_From_BOQ_v2 [L44]"
        If ds.Exists(k) Then
            matched = matched + 1
        Else
            m.Cells(rr, 1).Value = b.Cells(db(k), cb).Value
            If ct > 0 Then m.Cells(rr, 2).Value = b.Cells(db(k), ct).Value
            m.Cells(rr, 3).Value = "BOQ LPN NOT FOUND IN CAD SIS_TAG_EXPORT"
            rr = rr + 1: missBOQ = missBOQ + 1
        End If
    Next k

    For Each k In ds.Keys
        PDPerf_Pulse "mod04_VerifyCAD_BOQ.Verify_SIS_TAG_EXPORT_From_BOQ_v2 [L55]"
        If Not db.Exists(k) Then
            m.Cells(rr, 1).Value = s.Cells(ds(k), cs).Value
            m.Cells(rr, 3).Value = "CAD LPN NOT FOUND IN BOQ"
            rr = rr + 1: missCAD = missCAD + 1
        End If
    Next k

    m.Columns("A:C").AutoFit
    MsgBox "CAD / BOQ verification complete." & vbCrLf & vbCrLf & _
           "Matched LPNs: " & matched & vbCrLf & _
           "BOQ LPNs missing from CAD: " & missBOQ & vbCrLf & _
           "CAD LPNs missing from BOQ: " & missCAD & vbCrLf & vbCrLf & _
           "SIS_TAG_PD5 was not changed. Run Phase 1D to build it.", vbInformation, "Phase 1C - Verify CAD vs BOQ"

done:
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Exit Sub
Fail:
    MsgBox "Phase 1C failed: " & Err.description, vbCritical, "Verify CAD vs BOQ"
    Resume done
End Sub

Private Function V_GetSheet(ByVal nm As String) As Worksheet
    Dim w As Worksheet
    For Each w In ThisWorkbook.Worksheets
        PDPerf_Pulse "mod04_VerifyCAD_BOQ.V_GetSheet [L81]"
        If StrComp(Trim$(w.name), Trim$(nm), vbTextCompare) = 0 Then Set V_GetSheet = w: Exit Function
    Next w
End Function

Private Function V_GetOrCreate(ByVal nm As String) As Worksheet
    Set V_GetOrCreate = V_GetSheet(nm)
    If V_GetOrCreate Is Nothing Then
        Set V_GetOrCreate = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        V_GetOrCreate.name = nm
        mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation V_GetOrCreate
    End If
End Function

Private Function V_FindHdr(ByVal w As Worksheet, ByVal h As String) As Long
    Dim c As Long, lc As Long
    lc = w.Cells(1, w.Columns.count).End(xlToLeft).Column
    For c = 1 To lc
        If V_Key(w.Cells(1, c).Value) = V_Key(h) Then V_FindHdr = c: Exit Function
    Next c
End Function

Private Function V_Key(ByVal v As Variant) As String
    Dim x As String
    x = UCase$(Trim$(CStr(v)))
    x = Replace(x, vbCr, ""): x = Replace(x, vbLf, "")
    x = Replace(x, "_", ""): x = Replace(x, "-", ""): x = Replace(x, " ", "")
    V_Key = x
End Function

Private Function V_LastRow(ByVal w As Worksheet, ByVal c As Long) As Long
    V_LastRow = w.Cells(w.rows.count, c).End(xlUp).Row
End Function
