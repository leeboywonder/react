Attribute VB_Name = "mod07_PD4Estimate"
Option Explicit

'==============================================================
' STEP 2B - GENERATE PD4
' Reads Estimated_Power_Supply created by Step 2A and restores
' Definition metadata from SIS_TAG_PD5.
'
' Matching is resilient when CAD has not populated SIS_SEQUENCE yet:
'   1) SIS_SEQUENCE when present
'   2) 4+ digit sequence token derived from LPN
'==============================================================
Public Sub PD4_ESTIMATE()
    If PDPerf_IsYielding Then Exit Sub
    Dim wsSrc As Worksheet
    Dim wsTag As Worksheet
    Dim wsOut As Worksheet
    Dim srcMap As Object
    Dim tagMap As Object
    Dim best As Object
    Dim scoreMap As Object
    Dim srcData As Variant
    Dim tagData As Variant
    Dim outData() As Variant
    Dim headers As Variant
    Dim lrS As Long
    Dim lcS As Long
    Dim lrT As Long
    Dim lcT As Long
    Dim r As Long
    Dim c As Long
    Dim o As Long
    Dim tr As Long
    Dim score As Long
    Dim sourceSeq As String
    Dim deviceSeq As String
    Dim key As String

    On Error GoTo Fail

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Set wsSrc = Sheet2B("Estimated_Power_Supply")
    Set wsTag = Sheet2B("SIS_TAG_PD5")
    If wsSrc Is Nothing Then
        Err.Raise vbObjectError + 2500, , "Run Step 2A first. Estimated_Power_Supply was not found."
    End If
    If wsTag Is Nothing Then
        Err.Raise vbObjectError + 2501, , "SIS_TAG_PD5 was not found."
    End If
    Set wsOut = GetOrCreate2B("PD4_Estimate_PSU")

    lrS = LastRow2B(wsSrc)
    lcS = LastCol2B(wsSrc)
    lrT = LastRow2B(wsTag)
    lcT = LastCol2B(wsTag)
    If lrS < 2 Then
        Err.Raise vbObjectError + 2502, , "Step 2A did not create any PSU/VFD estimates."
    End If

    srcData = wsSrc.Range(wsSrc.Cells(1, 1), wsSrc.Cells(lrS, lcS)).Value2
    tagData = wsTag.Range(wsTag.Cells(1, 1), wsTag.Cells(lrT, lcT)).Value2
    Set srcMap = HeaderMap2B(srcData)
    Set tagMap = HeaderMap2B(tagData)

    RequireMap2B srcMap, "SOURCE_SIS_SEQUENCE", "Estimated_Power_Supply"
    RequireMap2B srcMap, "SIS_SEQUENCE", "Estimated_Power_Supply"
    RequireMap2B srcMap, "TYPE", "Estimated_Power_Supply"
    RequireMap2B tagMap, "LPN", "SIS_TAG_PD5"

    Set best = CreateObject("Scripting.Dictionary")
    best.CompareMode = vbTextCompare
    Set scoreMap = CreateObject("Scripting.Dictionary")
    scoreMap.CompareMode = vbTextCompare

    'Choose the best Definition row for each source sequence.  Parent
    'ONGEN_MECH rows win over MultiControl / Interface_Card / MOT rows.
    For r = 2 To UBound(tagData, 1)
        PDPerf_Pulse "mod07_PD4Estimate.PD4_ESTIMATE [L79]" & " row " & CStr(r)
        key = PD5SourceKey2B(tagData, r, tagMap)
        If key <> "" Then
            score = TagScore2B(Value2B(tagData, r, tagMap, "BLOCK_NAME"))
            If Not best.Exists(key) Then
                best.Add key, r
                scoreMap.Add key, score
            ElseIf score > CLng(scoreMap(key)) Then
                best(key) = r
                scoreMap(key) = score
            End If
        End If
    Next r

    headers = Array("SEQUENCE", "TYPE", "SOURCE_SIS_SEQUENCE", "AREA_NUMBER", "SWITCHGROUP", "LPN", "X", "Y", "Z", "ROTATION_DEG", _
                    "Motor_Power_Main_Drive", "Motor_Voltage_Main_Drive", "Motor_Brake_Voltage_Main_Drive", "CURRENT_LOAD", "BUS", "BLOCK")

    ReDim outData(1 To UBound(srcData, 1), 1 To UBound(headers) + 1)
    For c = LBound(headers) To UBound(headers)
        outData(1, c + 1) = headers(c)
    Next c
    o = 1

    For r = 2 To UBound(srcData, 1)
        PDPerf_Pulse "mod07_PD4Estimate.PD4_ESTIMATE [L102]" & " row " & CStr(r)
        sourceSeq = Text2B(Value2B(srcData, r, srcMap, "SOURCE_SIS_SEQUENCE"))
        deviceSeq = Text2B(Value2B(srcData, r, srcMap, "SIS_SEQUENCE"))
        If deviceSeq <> "" Then
            o = o + 1
            outData(o, 1) = deviceSeq
            outData(o, 2) = Value2B(srcData, r, srcMap, "TYPE")
            outData(o, 3) = sourceSeq
            outData(o, 14) = Value2B(srcData, r, srcMap, "CURRENT_LOAD")
            outData(o, 15) = Value2B(srcData, r, srcMap, "BUS")

            key = Key2B(sourceSeq)
            If best.Exists(key) Then
                tr = CLng(best(key))
                outData(o, 4) = Value2B(tagData, tr, tagMap, "AREA_NUMBER")
                outData(o, 5) = Value2B(tagData, tr, tagMap, "SWITCHGROUP")
                outData(o, 6) = Value2B(tagData, tr, tagMap, "LPN")
                outData(o, 7) = Value2B(tagData, tr, tagMap, "X")
                outData(o, 8) = Value2B(tagData, tr, tagMap, "Y")
                outData(o, 9) = Value2B(tagData, tr, tagMap, "Z")
                outData(o, 10) = Value2B(tagData, tr, tagMap, "ROTATION_DEG")
                outData(o, 11) = Value2B(tagData, tr, tagMap, "Motor Power (Main Drive)")
                outData(o, 12) = Value2B(tagData, tr, tagMap, "Motor Voltage (Main Drive)")
                outData(o, 13) = Value2B(tagData, tr, tagMap, "Motor Brake Voltage (Main Drive)")
            End If
        End If
    Next r

    wsOut.UsedRange.Clear
    If o = 1 Then
        wsOut.Range("A1").Resize(1, UBound(headers) + 1).Value = outData
    Else
        wsOut.Range("A1").Resize(o, UBound(headers) + 1).Value = outData
    End If
    wsOut.rows(1).Font.Bold = True
    wsOut.UsedRange.Columns.AutoFit

    Application.ScreenUpdating = True
    Application.EnableEvents = True
    If Not PDPerf_IsRunning Then Application.Calculation = xlCalculationAutomatic

    MsgBox "Step 2B complete." & vbCrLf & vbCrLf & _
           "PD4 PSU/VFD rows: " & CStr(o - 1) & vbCrLf & _
           "Coordinates and motor data were restored from the best SIS_TAG_PD5 Definition row.", _
           vbInformation, "Definition PD4"
    Exit Sub

Fail:
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    If Not PDPerf_IsRunning Then Application.Calculation = xlCalculationAutomatic
    MsgBox "Step 2B failed: " & Err.description, vbCritical, "Definition PD4"
End Sub

Private Function PD5SourceKey2B(ByRef a As Variant, ByVal r As Long, ByVal m As Object) As String
    Dim s As String
    Dim lpn As String

    s = Text2B(Value2B(a, r, m, "SIS_SEQUENCE"))
    If s <> "" Then
        PD5SourceKey2B = Key2B(s)
        Exit Function
    End If

    lpn = Text2B(Value2B(a, r, m, "LPN"))
    s = SequenceFromLPN2B(lpn)
    If s = "" Then s = lpn
    PD5SourceKey2B = Key2B(s)
End Function

Private Function SequenceFromLPN2B(ByVal lpn As String) As String
    Dim a As Variant
    Dim i As Long
    Dim s As String

    If lpn = "" Then Exit Function
    a = Split(Replace(lpn, "_", "-"), "-")
    For i = LBound(a) To UBound(a)
        s = Trim$(CStr(a(i)))
        If Len(s) >= 4 And IsNumeric(s) Then
            SequenceFromLPN2B = s
            Exit Function
        End If
    Next i
End Function

Private Function TagScore2B(ByVal v As Variant) As Long
    Dim b As String
    b = UCase$(Replace$(Text2B(v), " ", ""))

    If InStr(1, b, "ONGEN_MECH", vbTextCompare) > 0 Then
        TagScore2B = 400
    ElseIf b = "MULTICONTROL" Or b = "INTERFACE_CARD" Or b = "INTERFACECARD" Or b = "MOT" Then
        TagScore2B = 10
    ElseIf b = "" Then
        TagScore2B = 100
    Else
        TagScore2B = 250
    End If
End Function

Private Function HeaderMap2B(ByRef a As Variant) As Object
    Dim d As Object
    Dim c As Long
    Dim h As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    For c = 1 To UBound(a, 2)
        h = Trim$(CStr(a(1, c)))
        If h <> "" Then
            If Not d.Exists(h) Then d.Add h, c
        End If
    Next c
    Set HeaderMap2B = d
End Function

Private Function Value2B(ByRef a As Variant, ByVal r As Long, ByVal m As Object, ByVal h As String) As Variant
    If m.Exists(h) Then
        Value2B = a(r, CLng(m(h)))
    Else
        Value2B = ""
    End If
End Function

Private Sub RequireMap2B(ByVal m As Object, ByVal h As String, ByVal sheetName As String)
    If Not m.Exists(h) Then
        Err.Raise vbObjectError + 2510, , "Header '" & h & "' not found in '" & sheetName & "'."
    End If
End Sub

Private Function Sheet2B(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set Sheet2B = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function GetOrCreate2B(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet

    Set ws = Sheet2B(sheetName)
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.name = sheetName
        mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation ws
    End If
    Set GetOrCreate2B = ws
End Function

Private Function LastRow2B(ByVal ws As Worksheet) As Long
    Dim x As Range
    On Error Resume Next
    Set x = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If x Is Nothing Then
        LastRow2B = 1
    Else
        LastRow2B = x.Row
    End If
End Function

Private Function LastCol2B(ByVal ws As Worksheet) As Long
    Dim x As Range
    On Error Resume Next
    Set x = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If x Is Nothing Then
        LastCol2B = 1
    Else
        LastCol2B = x.Column
    End If
End Function

Private Function Text2B(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Then Exit Function
    Text2B = Trim$(CStr(v))
End Function

Private Function Key2B(ByVal v As Variant) As String
    Key2B = UCase$(Replace$(Text2B(v), " ", ""))
End Function

'==============================================================
' STEP 2D - EXPORT PD4 ESTIMATE TO HWE_PSU.CSV
'==============================================================
Public Sub Export_PD4_Estimate_PSU_To_HWE_PSU_CSV()
    If PDPerf_IsYielding Then Exit Sub
    Dim ws As Worksheet, wbCSV As Workbook, fd As Object, folderPath As String, outPath As String
    On Error GoTo Fail
    Set ws = Sheet2B("PD4_Estimate_PSU")
    If ws Is Nothing Then Err.Raise vbObjectError + 2520, , "PD4_Estimate_PSU was not found. Run Step 2B first."
    If LastRow2B(ws) < 2 Then Err.Raise vbObjectError + 2521, , "PD4_Estimate_PSU does not contain any data rows."

    Set fd = Application.FileDialog(4)
    fd.title = "Select folder for HWE_PSU.csv"
    If fd.Show <> -1 Then Exit Sub
    folderPath = CStr(fd.SelectedItems(1))
    If Right$(folderPath, 1) <> Application.PathSeparator Then folderPath = folderPath & Application.PathSeparator
    outPath = folderPath & "HWE_PSU.csv"

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    ws.Copy
    Set wbCSV = ActiveWorkbook
    mod23_WorksheetNavigation.NAV_Remove_Navigation_Controls wbCSV.Worksheets(1)

    ' V4.6.6 mandatory CSV traceability. The exported SIS_SEQUENCE is the
    ' PSU sequence; ML/ZL are inherited from SOURCE_SIS_SEQUENCE / LPN.
    mod21_CSVTraceability.CSVTrace_EnsureTraceColumns wbCSV.Worksheets(1), _
        Array("SIS_SEQUENCE", "SEQUENCE"), Array("SOURCE_SIS_SEQUENCE"), Array("LPN")

    wbCSV.SaveAs Filename:=outPath, FileFormat:=xlCSVUTF8, CreateBackup:=False
    wbCSV.Close SaveChanges:=False
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    MsgBox "Step 2D complete." & vbCrLf & vbCrLf & "Exported: " & outPath, vbInformation, "HWE PSU Export"
    Exit Sub
Fail:
    On Error Resume Next
    If Not wbCSV Is Nothing Then wbCSV.Close SaveChanges:=False
    Application.DisplayAlerts = True: Application.ScreenUpdating = True
    MsgBox "Step 2D failed: " & Err.description, vbCritical, "HWE PSU Export"
End Sub

