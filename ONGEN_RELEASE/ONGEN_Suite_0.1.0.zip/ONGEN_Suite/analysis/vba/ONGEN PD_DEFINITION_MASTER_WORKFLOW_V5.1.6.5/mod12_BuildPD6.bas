Attribute VB_Name = "mod12_BuildPD6"
Option Explicit

'==========================================================
' Macro Name : Build_PD6_System_Designed_RELEASED
' Author     : Lee Pierre
' Version    : V4.8 - Child Electrical Priority
'
' Purpose:
'   Creates / rebuilds worksheet "PD6 System Designed"
'   by appending selected headers from:
'       - SIS_TAG_PD5
'       - PD4_Estimate_PSU
'       - IO DEVICE EM
'       - FUNCTION DEVICE PD2
'
' Important Update:
'   - ONGEN_MECH parent geometry is suppressed when the same SIS_SEQUENCE has
'     one or more child electrical-device rows.
'   - All child electrical rows are retained (MultiControl, Interface_Card, MOT,
'     Nn, IO/S, IO/D, etc.).
'   - A parent geometry row is retained only when no child exists for it.
'   - Output order follows source sheet order, then row order.
'
' Source Sheet Rule:
'   - If a source sheet does not exist, it is skipped.
'   - The process continues to the next source sheet.
'
' SIS_ELEMENT_NUMBER Rule:
'   - SIS_ELEMENT_NUMBER is generated as:
'       AREA_NUMBER-SWITCHGROUP-SIS_SEQUENCE
'
'   - If SWITCHGROUP is blank or "Not Found", use 0.
'
'   Examples:
'       AREA_NUMBER = 11, SWITCHGROUP = 353, SIS_SEQUENCE = 1130
'       Result = 11-353-1130
'
'       AREA_NUMBER = 11, SWITCHGROUP blank, SIS_SEQUENCE = 1130
'       Result = 11-0-1130
'
' Notes:
'   - Common header aliases are supported:
'       PNL -> Panel
'       BLOCK_NAME -> BLOCK
'       Load -> CURRENT_LOAD
'       SYSTEM_TYPE -> SYSTEM TYPE
'==========================================================

Private Const OUT_SHEET_PD6 As String = "PD6 System Designed"

Public Sub Build_PD6_System_Designed_RELEASED()
    If PDPerf_IsYielding Then Exit Sub
    Dim wb As Workbook, wsOut As Worksheet, ws As Worksheet
    Dim sourceSheets As Variant, headers As Variant
    Dim outData() As Variant, writeData() As Variant, maxRows As Long, outRow As Long
    Dim wr As Long, wc As Long
    Dim i As Long, rowsAdded As Long, srcName As String
    Dim missingSheets As String, skippedSheets As String, processedSheets As String
    Dim oldCalc As XlCalculation, oldScreen As Boolean, oldEvents As Boolean
    Dim childSeqs As Object

    Set wb = ThisWorkbook
    sourceSheets = Array("SIS_TAG_PD5", "PD4_Estimate_PSU", "IO DEVICE EM", "FUNCTION DEVICE PD2")
    headers = PD6_TargetHeaders()

    oldScreen = Application.ScreenUpdating: oldEvents = Application.EnableEvents: oldCalc = Application.Calculation
    Application.ScreenUpdating = False: Application.EnableEvents = False: Application.Calculation = xlCalculationManual
    Application.StatusBar = "Phase 4B: sizing one PD6 output array..."
    On Error GoTo CleanFail

    Set wsOut = GetOrCreateSheetLoose(wb, OUT_SHEET_PD6)

    'Allocate once at the maximum possible row count. Blank SIS rows are simply skipped.
    For i = LBound(sourceSheets) To UBound(sourceSheets)
        Set ws = SheetByNameLoose(wb, CStr(sourceSheets(i)))
        If Not ws Is Nothing Then
            If LastUsedRow(ws) > 1 Then maxRows = maxRows + LastUsedRow(ws) - 1
        End If
    Next i
    If maxRows < 1 Then maxRows = 1
    Set childSeqs = PD6_BuildChildSequenceIndex(wb, sourceSheets)
    ReDim outData(1 To maxRows, 1 To UBound(headers))

    Application.StatusBar = "Phase 4B: reading each source once and building PD6 in memory..."
    For i = LBound(sourceSheets) To UBound(sourceSheets)
        srcName = CStr(sourceSheets(i))
        Set ws = SheetByNameLoose(wb, srcName)
        If ws Is Nothing Then
            missingSheets = missingSheets & " - " & srcName & vbCrLf
        Else
            rowsAdded = PD6_FillSourceFast(ws, headers, outData, outRow, childSeqs)
            If rowsAdded < 0 Then
                skippedSheets = skippedSheets & " - " & ws.name & vbCrLf
            Else
                processedSheets = processedSheets & " - " & ws.name & " : " & rowsAdded & " rows added" & vbCrLf
            End If
        End If
    Next i

    Application.StatusBar = "Phase 4B: one bulk write to PD6 System Designed..."
    ClearAndSetupPD6 wsOut, headers
    If outRow > 0 Then
        ReDim writeData(1 To outRow, 1 To UBound(headers))
        For wr = 1 To outRow
            PDPerf_Pulse "mod12_BuildPD6.Build_PD6_System_Designed_RELEASED [L104]" & " row " & CStr(wr)
            For wc = 1 To UBound(headers)
                writeData(wr, wc) = outData(wr, wc)
            Next wc
        Next wr
        wsOut.Cells(2, 1).Resize(outRow, UBound(headers)).Value2 = writeData
    End If
    FormatPD6Sheet wsOut, UBound(headers)

    Application.StatusBar = False
    Application.ScreenUpdating = oldScreen: Application.EnableEvents = oldEvents: Application.Calculation = oldCalc

    MsgBox "Phase 4B complete." & vbCrLf & vbCrLf & _
           "Rows added: " & Format$(outRow, "#,##0") & vbCrLf & _
           "ONGEN_MECH parents were suppressed wherever child electrical rows exist." & vbCrLf & vbCrLf & _
           "Processed sheets:" & vbCrLf & IIf(Len(processedSheets) > 0, processedSheets, "None") & _
           IIf(Len(missingSheets) > 0, vbCrLf & "Missing sheets skipped:" & vbCrLf & missingSheets, "") & _
           IIf(Len(skippedSheets) > 0, vbCrLf & "Sheets skipped because SIS_SEQUENCE was not found:" & vbCrLf & skippedSheets, ""), _
           vbInformation, "PD6 System Designed - FAST"
    Exit Sub

CleanFail:
    Application.StatusBar = False
    Application.ScreenUpdating = oldScreen: Application.EnableEvents = oldEvents: Application.Calculation = oldCalc
    MsgBox "Phase 4B failed. Error " & Err.number & ": " & Err.description, vbCritical, "PD6 System Designed - FAST"
End Sub

Private Function PD6_FillSourceFast(ByVal wsSrc As Worksheet, _
                                    ByVal headers As Variant, _
                                    ByRef outData As Variant, _
                                    ByRef outRow As Long, _
                                    ByVal childSeqs As Object) As Long
    Dim lastRow As Long, lastCol As Long, headerRow As Long
    Dim data As Variant, exactMap As Object, normMap As Object
    Dim srcCols() As Long, sisCol As Long, blockCol As Long, nHeaders As Long
    Dim colSeq As Long, colElement As Long, colArea As Long, colSwitch As Long
    Dim r As Long, c As Long, added As Long, seq As String, valueIn As Variant

    lastRow = LastUsedRow(wsSrc): lastCol = LastUsedCol(wsSrc)
    If lastRow < 1 Or lastCol < 1 Then PD6_FillSourceFast = 0: Exit Function
    headerRow = LocateHeaderRow(wsSrc, lastRow, lastCol)
    If headerRow = 0 Then PD6_FillSourceFast = -1: Exit Function

    data = wsSrc.Range(wsSrc.Cells(1, 1), wsSrc.Cells(lastRow, lastCol)).Value2
    Set exactMap = CreateObject("Scripting.Dictionary"): exactMap.CompareMode = vbTextCompare
    Set normMap = CreateObject("Scripting.Dictionary"): normMap.CompareMode = vbTextCompare
    BuildHeaderMaps data, headerRow, lastCol, exactMap, normMap

    sisCol = FindHeaderColumn(exactMap, normMap, "SIS_SEQUENCE")
    blockCol = FindHeaderColumn(exactMap, normMap, "BLOCK")
    If sisCol = 0 Then PD6_FillSourceFast = -1: Exit Function

    nHeaders = UBound(headers)
    ReDim srcCols(1 To nHeaders)
    For c = 1 To nHeaders
        If NormalizeHeader(headers(c)) = "SISELEMENTNUMBER" Then
            srcCols(c) = 0
        Else
            srcCols(c) = FindHeaderColumn(exactMap, normMap, CStr(headers(c)))
        End If
    Next c

    colSeq = OutputHeaderIndex(headers, "SIS_SEQUENCE")
    colElement = OutputHeaderIndex(headers, "SIS_ELEMENT_NUMBER")
    colArea = OutputHeaderIndex(headers, "AREA_NUMBER")
    colSwitch = OutputHeaderIndex(headers, "SWITCHGROUP")

    For r = headerRow + 1 To lastRow
        PDPerf_Pulse "mod12_BuildPD6.PD6_FillSourceFast [L171]" & " row " & CStr(r)
        seq = TrimSafe(data(r, sisCol))
        If Len(seq) > 0 Then
            If blockCol > 0 Then
                If PD6_IsONGENMechParent(data(r, blockCol)) Then
                    If Not childSeqs Is Nothing Then
                        If childSeqs.Exists(PD6_SequenceKey(seq)) Then GoTo NextPD6SourceRow
                    End If
                End If
            End If
            outRow = outRow + 1
            For c = 1 To nHeaders
                If srcCols(c) > 0 Then
                    valueIn = data(r, srcCols(c))
                    If Not IsBlankValue(valueIn) Then outData(outRow, c) = valueIn
                End If
            Next c
            If colSeq > 0 Then outData(outRow, colSeq) = seq
            If colElement > 0 And colArea > 0 And colSeq > 0 Then
                If colSwitch > 0 Then
                    outData(outRow, colElement) = BuildPD6ElementNumber(outData(outRow, colArea), outData(outRow, colSwitch), outData(outRow, colSeq))
                Else
                    outData(outRow, colElement) = BuildPD6ElementNumber(outData(outRow, colArea), vbNullString, outData(outRow, colSeq))
                End If
            End If
            added = added + 1
        End If
NextPD6SourceRow:
    Next r
    PD6_FillSourceFast = added
End Function


Private Function PD6_BuildChildSequenceIndex(ByVal wb As Workbook, ByVal sourceSheets As Variant) As Object
    Dim d As Object, ws As Worksheet
    Dim i As Long, lr As Long, lc As Long, hr As Long, r As Long
    Dim data As Variant, exactMap As Object, normMap As Object
    Dim cSeq As Long, cBlock As Long, seq As String, blockText As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    For i = LBound(sourceSheets) To UBound(sourceSheets)
        Set ws = SheetByNameLoose(wb, CStr(sourceSheets(i)))
        If Not ws Is Nothing Then
            lr = LastUsedRow(ws): lc = LastUsedCol(ws)
            If lr > 1 And lc > 0 Then
                hr = LocateHeaderRow(ws, lr, lc)
                If hr > 0 Then
                    data = ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).Value2
                    Set exactMap = CreateObject("Scripting.Dictionary"): exactMap.CompareMode = vbTextCompare
                    Set normMap = CreateObject("Scripting.Dictionary"): normMap.CompareMode = vbTextCompare
                    BuildHeaderMaps data, hr, lc, exactMap, normMap
                    cSeq = FindHeaderColumn(exactMap, normMap, "SIS_SEQUENCE")
                    cBlock = FindHeaderColumn(exactMap, normMap, "BLOCK")
                    If cSeq > 0 And cBlock > 0 Then
                        For r = hr + 1 To lr
                            PDPerf_Pulse "mod12_BuildPD6.PD6_BuildChildSequenceIndex [L227]" & " row " & CStr(r)
                            seq = TrimSafe(data(r, cSeq))
                            blockText = TrimSafe(data(r, cBlock))
                            If Len(seq) > 0 And Len(blockText) > 0 Then
                                If Not PD6_IsONGENMechParent(blockText) Then d(PD6_SequenceKey(seq)) = True
                            End If
                        Next r
                    End If
                End If
            End If
        End If
    Next i

    Set PD6_BuildChildSequenceIndex = d
End Function

Private Function PD6_IsONGENMechParent(ByVal blockValue As Variant) As Boolean
    Dim s As String
    s = UCase$(TrimSafe(blockValue))
    s = Replace$(s, " ", vbNullString)
    PD6_IsONGENMechParent = (Left$(s, 10) = "ONGEN_MECH")
End Function

Private Function PD6_SequenceKey(ByVal seqValue As Variant) As String
    PD6_SequenceKey = UCase$(Replace$(TrimSafe(seqValue), " ", vbNullString))
End Function

Private Function PD6_TargetHeaders() As Variant

    Dim h As Collection
    Dim arr() As String
    Dim i As Long

    Set h = New Collection

    h.Add "SIS_SEQUENCE"
    h.Add "SIS_ELEMENT_NUMBER"
    h.Add "AREA_NUMBER"
    h.Add "SWITCHGROUP"
    h.Add "Panel"
    h.Add "TYPE"
    h.Add "NETWORK_IP"
    h.Add "LPN"
    h.Add "LAYER"
    h.Add "BLOCK"
    h.Add "X"
    h.Add "Y"
    h.Add "Z"
    h.Add "ROTATION_DEG"
    h.Add "SYSTEM TYPE"
    h.Add "CONTROL_FUNCTION_NUMBER"
    h.Add "CONTROL_FUNCTION_TAG"
    h.Add "CONVEYOR TYPE"
    h.Add "Module Length (ML)"
    h.Add "Motor_Power_Main_Drive"
    h.Add "Motor_Voltage_Main_Drive"
    h.Add "Motor_Brake_Voltage_Main_Drive"
    h.Add "CURRENT_LOAD"
    h.Add "Encoder Type (Main Drive)"
    h.Add "Total Qty of Sensors"
    h.Add "Control Card"
    h.Add "Qty of Control Card"
    h.Add "Total Qty of Drives"
    h.Add "Motor Power (Main Drive)"
    h.Add "Motor Voltage (Main Drive)"
    h.Add "Motor Brake Voltage (Main Drive)"
    h.Add "PART_NUM_1"
    h.Add "MANUF_NAME_1"
    h.Add "PART_NUM_2"
    h.Add "MANUF_NAME_2"
    h.Add "PART_NUM_3"
    h.Add "MANUF_NAME_3"
    h.Add "PART_NUM_4"
    h.Add "MANUF_NAME_4"
    h.Add "PART_NUM_5"
    h.Add "MANUF_NAME_5"

    ReDim arr(1 To h.count)

    For i = 1 To h.count
        arr(i) = CStr(h(i))
    Next i

    PD6_TargetHeaders = arr

End Function

Private Sub ClearAndSetupPD6(ByVal wsOut As Worksheet, ByVal headers As Variant)
    Dim headerArr() As Variant, c As Long, n As Long
    On Error Resume Next
    wsOut.UsedRange.ClearContents
    On Error GoTo 0
    n = UBound(headers) - LBound(headers) + 1
    ReDim headerArr(1 To 1, 1 To n)
    For c = LBound(headers) To UBound(headers)
        headerArr(1, c - LBound(headers) + 1) = headers(c)
    Next c
    wsOut.Cells(1, 1).Resize(1, n).Value = headerArr
End Sub

Private Function BuildPD6ElementNumber( _
    ByVal areaValue As Variant, _
    ByVal switchValue As Variant, _
    ByVal seqValue As Variant) As String

    Dim areaText As String
    Dim switchText As String
    Dim seqText As String

    areaText = TrimSafe(areaValue)
    switchText = TrimSafe(switchValue)
    seqText = TrimSafe(seqValue)

    If Len(switchText) = 0 Then switchText = "0"
    If UCase$(switchText) = "NOT FOUND" Then switchText = "0"

    BuildPD6ElementNumber = areaText & "-" & switchText & "-" & seqText

End Function

Private Function OutputHeaderIndex( _
    ByVal headers As Variant, _
    ByVal headerName As String) As Long

    Dim i As Long

    For i = LBound(headers) To UBound(headers)

        If UCase$(Trim$(CStr(headers(i)))) = UCase$(Trim$(headerName)) Then
            OutputHeaderIndex = i
            Exit Function
        End If

    Next i

    OutputHeaderIndex = 0

End Function

Private Sub FormatPD6Sheet(ByVal wsOut As Worksheet, ByVal lastCol As Long)

    Dim lastRow As Long

    lastRow = LastUsedRow(wsOut)

    With wsOut.rows(1)
        .Font.Bold = True
        .Interior.Color = RGB(255, 242, 204)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With

    'Do not redraw borders or AutoFit the entire PD6 table. Those operations are
    'cosmetic and become the largest runtime cost on engineering-size datasets.

    On Error Resume Next
    wsOut.Activate
    wsOut.Range("A2").Select
    ActiveWindow.FreezePanes = True
    On Error GoTo 0

End Sub

Private Sub BuildHeaderMaps( _
    ByRef data As Variant, _
    ByVal headerRow As Long, _
    ByVal lastCol As Long, _
    ByVal exactMap As Object, _
    ByVal normMap As Object)

    Dim c As Long
    Dim rawHeader As String
    Dim exactKey As String
    Dim NormKey As String

    For c = 1 To lastCol

        rawHeader = TrimSafe(data(headerRow, c))

        If Len(rawHeader) > 0 Then

            exactKey = UCase$(rawHeader)
            NormKey = NormalizeHeader(rawHeader)

            If Len(exactKey) > 0 Then
                If Not exactMap.Exists(exactKey) Then exactMap.Add exactKey, c
            End If

            If Len(NormKey) > 0 Then
                If Not normMap.Exists(NormKey) Then normMap.Add NormKey, c
            End If

        End If

    Next c

End Sub

Private Function FindHeaderColumn( _
    ByVal exactMap As Object, _
    ByVal normMap As Object, _
    ByVal wantedHeader As String) As Long

    Dim aliases As Variant
    Dim i As Long
    Dim exactKey As String
    Dim NormKey As String

    aliases = HeaderAliases(wantedHeader)

    For i = LBound(aliases) To UBound(aliases)

        exactKey = UCase$(Trim$(CStr(aliases(i))))

        If exactMap.Exists(exactKey) Then
            FindHeaderColumn = CLng(exactMap(exactKey))
            Exit Function
        End If

    Next i

    For i = LBound(aliases) To UBound(aliases)

        NormKey = NormalizeHeader(CStr(aliases(i)))

        If normMap.Exists(NormKey) Then
            FindHeaderColumn = CLng(normMap(NormKey))
            Exit Function
        End If

    Next i

    FindHeaderColumn = 0

End Function

Private Function HeaderAliases(ByVal targetHeader As String) As Variant

    Dim key As String
    Dim s As String

    key = NormalizeHeader(targetHeader)
    s = targetHeader

    Select Case key

        Case "SISSEQUENCE"
            s = "SIS_SEQUENCE|SIS SEQUENCE|SIS_SEQUENCE_NUMBER|SEQUENCE|SIS #|SIS"

        Case "SISELEMENTNUMBER"
            s = "SIS_ELEMENT_NUMBER|SIS ELEMENT NUMBER|ELEMENT_NUMBER|ELEMENT NUMBER"

        Case "AREANUMBER"
            s = "AREA_NUMBER|AREA NUMBER|AREA"

        Case "SWITCHGROUP"
            s = "SWITCHGROUP|SWITCH GROUP|SWITCH_GROUP|PWG"

        Case "PANEL"
            s = "Panel|PNL|PANEL"

        Case "TYPE"
            s = "TYPE|Device Type|DEVICE TYPE|ITEM TYPE|Item Type"

        Case "NETWORKIP"
            s = "NETWORK_IP|NETWORK IP|IP|IP ADDRESS|NETWORK_IP_ADDRESS"

        Case "LPN"
            s = "LPN|Layout Position Number|LAYOUT POSITION NUMBER"

        Case "LAYER"
            s = "LAYER|CAD Layer|CAD_LAYER"

        Case "BLOCK"
            s = "BLOCK|BLOCK_NAME|BLOCK NAME|BLOCKNAME"

        Case "X"
            s = "X"

        Case "Y"
            s = "Y"

        Case "Z"
            s = "Z"

        Case "ROTATIONDEG"
            s = "ROTATION_DEG|ROTATION DEG|ROTATION|ROTATION_DEGREES"

        Case "SYSTEMTYPE"
            s = "SYSTEM TYPE|SYSTEM_TYPE|System Type|SYSTEM"

        Case "CONTROLFUNCTIONNUMBER"
            s = "CONTROL_FUNCTION_NUMBER|CONTROL FUNCTION NUMBER|CONTROL_FUNCTION_NUM"

        Case "CONTROLFUNCTIONTAG"
            s = "CONTROL_FUNCTION_TAG|CONTROL FUNCTION TAG|Control_Function_TAG"

        Case "CONVEYORTYPE"
            s = "CONVEYOR TYPE|CONVEYOR_TYPE|Conveyor Type"

        Case "MODULELENGTHML"
            s = "Module Length (ML)|MODULE_LENGTH_ML|MODULE LENGTH ML|Module Length"

        Case "MOTORPOWERMAINDRIVE"
            s = "Motor_Power_Main_Drive|Motor Power (Main Drive)|MOTOR_POWER_MAIN_DRIVE|Motor Power Main Drive"

        Case "MOTORVOLTAGEMAINDRIVE"
            s = "Motor_Voltage_Main_Drive|Motor Voltage (Main Drive)|MOTOR_VOLTAGE_MAIN_DRIVE|Motor Voltage Main Drive"

        Case "MOTORBRAKEVOLTAGEMAINDRIVE"
            s = "Motor_Brake_Voltage_Main_Drive|Motor Brake Voltage (Main Drive)|MOTOR_BRAKE_VOLTAGE_MAIN_DRIVE|Motor Brake Voltage Main Drive"

        Case "CURRENTLOAD"
            s = "CURRENT_LOAD|CURRENT LOAD|Load|LOAD|Current Load"

        Case "ENCODERTYPEMAINDRIVE"
            s = "Encoder Type (Main Drive)|ENCODER_TYPE_MAIN_DRIVE|Encoder Type Main Drive"

        Case "TOTALQTYOFSENSORS"
            s = "Total Qty of Sensors|TOTAL_QTY_OF_SENSORS|Total Quantity of Sensors"

        Case "CONTROLCARD"
            s = "Control Card|CONTROL_CARD"

        Case "QTYOFCONTROLCARD"
            s = "Qty of Control Card|QTY_OF_CONTROL_CARD|Quantity of Control Card"

        Case "TOTALQTYOFDRIVES"
            s = "Total Qty of Drives|TOTAL_QTY_OF_DRIVES|Total Quantity of Drives"

        Case "PARTNUM1"
            s = "PART_NUM_1|PART NUM 1|PARTNUM1"

        Case "MANUFNAME1"
            s = "MANUF_NAME_1|MANUF NAME 1|MANUFNAME1"

        Case "PARTNUM2"
            s = "PART_NUM_2|PART NUM 2|PARTNUM2"

        Case "MANUFNAME2"
            s = "MANUF_NAME_2|MANUF NAME 2|MANUFNAME2"

        Case "PARTNUM3"
            s = "PART_NUM_3|PART NUM 3|PARTNUM3"

        Case "MANUFNAME3"
            s = "MANUF_NAME_3|MANUF NAME 3|MANUFNAME3"

        Case "PARTNUM4"
            s = "PART_NUM_4|PART NUM 4|PARTNUM4"

        Case "MANUFNAME4"
            s = "MANUF_NAME_4|MANUF NAME 4|MANUFNAME4"

        Case "PARTNUM5"
            s = "PART_NUM_5|PART NUM 5|PARTNUM5"

        Case "MANUFNAME5"
            s = "MANUF_NAME_5|MANUF NAME 5|MANUFNAME5"

    End Select

    HeaderAliases = Split(s, "|")

End Function

Private Function LocateHeaderRow( _
    ByVal ws As Worksheet, _
    ByVal lastRow As Long, _
    ByVal lastCol As Long) As Long

    Dim r As Long
    Dim c As Long
    Dim maxScanRow As Long
    Dim cellText As String

    maxScanRow = Application.Min(lastRow, 25)

    For r = 1 To maxScanRow
        PDPerf_Pulse "mod12_BuildPD6.LocateHeaderRow [L605]" & " row " & CStr(r)

        For c = 1 To lastCol

            cellText = NormalizeHeader(ws.Cells(r, c).Value)

            If cellText = "SISSEQUENCE" _
               Or cellText = "SEQUENCE" _
               Or cellText = "SIS" Then

                LocateHeaderRow = r
                Exit Function

            End If

        Next c

    Next r

    LocateHeaderRow = 0

End Function

Private Function GetOrCreateSheetLoose( _
    ByVal wb As Workbook, _
    ByVal sheetName As String) As Worksheet

    Dim ws As Worksheet

    Set ws = SheetByNameLoose(wb, sheetName)

    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ws.name = sheetName
        If wb Is ThisWorkbook Then mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation ws
    End If

    Set GetOrCreateSheetLoose = ws

End Function

Private Function SheetByNameLoose( _
    ByVal wb As Workbook, _
    ByVal sheetName As String) As Worksheet

    Dim ws As Worksheet

    For Each ws In wb.Worksheets
        PDPerf_Pulse "mod12_BuildPD6.SheetByNameLoose [L652]"

        If UCase$(Trim$(ws.name)) = UCase$(Trim$(sheetName)) Then
            Set SheetByNameLoose = ws
            Exit Function
        End If

    Next ws

    Set SheetByNameLoose = Nothing

End Function

Private Function LastUsedRow(ByVal ws As Worksheet) As Long

    Dim f As Range

    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", _
                          LookIn:=xlFormulas, _
                          SearchOrder:=xlByRows, _
                          SearchDirection:=xlPrevious)
    On Error GoTo 0

    If f Is Nothing Then
        LastUsedRow = 0
    Else
        LastUsedRow = f.Row
    End If

End Function

Private Function LastUsedCol(ByVal ws As Worksheet) As Long

    Dim f As Range

    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", _
                          LookIn:=xlFormulas, _
                          SearchOrder:=xlByColumns, _
                          SearchDirection:=xlPrevious)
    On Error GoTo 0

    If f Is Nothing Then
        LastUsedCol = 0
    Else
        LastUsedCol = f.Column
    End If

End Function

Private Function NormalizeHeader(ByVal valueIn As Variant) As String

    Dim s As String

    If IsError(valueIn) Then
        NormalizeHeader = vbNullString
        Exit Function
    End If

    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace(s, Chr$(160), " ")
    s = Replace(s, "_", "")
    s = Replace(s, " ", "")
    s = Replace(s, "-", "")
    s = Replace(s, "(", "")
    s = Replace(s, ")", "")
    s = Replace(s, "/", "")
    s = Replace(s, "\", "")
    s = Replace(s, ".", "")
    s = Replace(s, "#", "")
    s = Replace(s, ":", "")

    NormalizeHeader = s

End Function

Private Function TrimSafe(ByVal valueIn As Variant) As String

    If IsError(valueIn) Then
        TrimSafe = vbNullString
    ElseIf IsNull(valueIn) Then
        TrimSafe = vbNullString
    ElseIf IsEmpty(valueIn) Then
        TrimSafe = vbNullString
    Else
        TrimSafe = Trim$(CStr(valueIn))
    End If

End Function

Private Function IsBlankValue(ByVal valueIn As Variant) As Boolean

    If IsError(valueIn) Then
        IsBlankValue = True
    ElseIf IsNull(valueIn) Then
        IsBlankValue = True
    ElseIf IsEmpty(valueIn) Then
        IsBlankValue = True
    ElseIf VarType(valueIn) = vbString Then
        IsBlankValue = Len(Trim$(CStr(valueIn))) = 0
    Else
        IsBlankValue = False
    End If

End Function

