Attribute VB_Name = "mod15_IOReturnMerge"
Option Explicit

' V4.6 FAST IO return merge.
' Reads all supporting worksheets into arrays/dictionaries and writes IO DEVICE EM once.
Public Sub IOReturn_Update_IO_DEVICE_EM_From_PD2_And_FunctionDefinition()
    If PDPerf_IsYielding Then Exit Sub
    Dim wsDst As Worksheet, wsFuncDev As Worksheet, wsTag As Worksheet, wsFuncDef As Worksheet
    Dim dstData As Variant, funcData As Variant, tagData As Variant, defData As Variant
    Dim dstMap As Object, funcMap As Object, tagMap As Object, defMap As Object
    Dim devDict As Object, tagDict As Object, defDict As Object
    Dim lr As Long, lc As Long, r As Long, i As Long
    Dim cSeq As Long, cType As Long, cCtrl As Long, cTag As Long, cX As Long, cY As Long, cZ As Long, cRot As Long
    Dim partNames As Variant, dstPart(0 To 9) As Long
    Dim outData As Variant, key As String, baseSeq As String, typ As String, ctrl As String, a As Variant
    Dim matchedDevice As Long, matchedTag As Long, matchedDef As Long
    Dim oldCalc As XlCalculation, oldScreen As Boolean, oldEvents As Boolean

    Set wsDst = IOM_Sheet(ThisWorkbook, "IO DEVICE EM")
    If wsDst Is Nothing Then MsgBox "Missing 'IO DEVICE EM'.", vbCritical: Exit Sub
    Set wsFuncDev = IOM_Sheet(ThisWorkbook, "FUNCTION DEVICE pd2")
    Set wsTag = IOM_Sheet(ThisWorkbook, "SIS_TAG_IMPORT_PD2")
    Set wsFuncDef = IOM_Sheet(ThisWorkbook, "FUNCTION DEFINITION")

    oldScreen = Application.ScreenUpdating: oldEvents = Application.EnableEvents: oldCalc = Application.Calculation
    Application.ScreenUpdating = False: Application.EnableEvents = False: Application.Calculation = xlCalculationManual
    On Error GoTo Fail

    lr = IOM_LastRow(wsDst): lc = IOM_LastCol(wsDst)
    If lr < 2 Or lc < 1 Then GoTo CleanExit
    dstData = wsDst.Range(wsDst.Cells(1, 1), wsDst.Cells(lr, lc)).Value2
    Set dstMap = IOM_HeaderMap(dstData, lc)

    cSeq = IOM_ColAny(dstMap, Array("SEQUENCE", "SIS_SEQUENCE"))
    cType = IOM_ColAny(dstMap, Array("TYPE", "ITEM TYPE"))
    cCtrl = IOM_ColAny(dstMap, Array("CONTROL_FUNCTION_NUMBER", "CONTROL FUNCTION NUMBER"))
    cTag = IOM_ColAny(dstMap, Array("CONTROL_FUNCTION_TAG", "CONTROL FUNCTION TAG"))
    cX = IOM_ColAny(dstMap, Array("X")): cY = IOM_ColAny(dstMap, Array("Y"))
    cZ = IOM_ColAny(dstMap, Array("Z")): cRot = IOM_ColAny(dstMap, Array("ROTATION_DEG", "ROTATION"))
    If cSeq = 0 Or cType = 0 Then Err.Raise vbObjectError + 6501, , "IO DEVICE EM is missing SEQUENCE or TYPE."

    partNames = Array("PART_NUM_1", "MANUF_NAME_1", "PART_NUM_2", "MANUF_NAME_2", "PART_NUM_3", "MANUF_NAME_3", "PART_NUM_4", "MANUF_NAME_4", "PART_NUM_5", "MANUF_NAME_5")
    For i = 0 To 9
        dstPart(i) = IOM_ColAny(dstMap, Array(CStr(partNames(i))))
    Next i

    Set devDict = IOM_BuildFunctionDeviceMap(wsFuncDev)
    Set tagDict = IOM_BuildTagCoordinateMap(wsTag)
    Set defDict = IOM_BuildFunctionDefinitionMap(wsFuncDef)

    outData = dstData
    Application.StatusBar = "Step 5D: merging IO return data in one memory pass..."

    For r = 2 To lr
        PDPerf_Pulse "mod15_IOReturnMerge.IOReturn_Update_IO_DEVICE_EM_From_PD2_And_FunctionDefinition [L53]" & " row " & CStr(r)
        baseSeq = IOM_Text(dstData(r, cSeq))
        typ = IOM_Text(dstData(r, cType))
        If Len(baseSeq) > 0 Then
            key = UCase$(baseSeq & "|" & typ)
            If devDict.Exists(key) Then
                a = devDict(key)
                If cCtrl > 0 Then outData(r, cCtrl) = a(0)
                If cTag > 0 Then outData(r, cTag) = a(1)
                If cX > 0 Then outData(r, cX) = a(2)
                If cY > 0 Then outData(r, cY) = a(3)
                If cZ > 0 Then outData(r, cZ) = a(4)
                If cRot > 0 Then outData(r, cRot) = a(5)
                For i = 0 To 9
                    If dstPart(i) > 0 And IOM_Usable(a(6 + i)) Then outData(r, dstPart(i)) = a(6 + i)
                Next i
                matchedDevice = matchedDevice + 1
            ElseIf tagDict.Exists(UCase$(baseSeq)) Then
                a = tagDict(UCase$(baseSeq))
                If cX > 0 Then outData(r, cX) = a(0)
                If cY > 0 Then outData(r, cY) = a(1)
                If cZ > 0 Then outData(r, cZ) = a(2)
                If cRot > 0 Then outData(r, cRot) = a(3)
                matchedTag = matchedTag + 1
            End If

            If cCtrl > 0 Then ctrl = IOM_Text(outData(r, cCtrl)) Else ctrl = vbNullString
            If Len(ctrl) > 0 And defDict.Exists(UCase$(ctrl)) Then
                a = defDict(UCase$(ctrl))
                For i = 0 To 9
                    If dstPart(i) > 0 Then
                        If Not IOM_Usable(outData(r, dstPart(i))) And IOM_Usable(a(i)) Then outData(r, dstPart(i)) = a(i)
                    End If
                Next i
                matchedDef = matchedDef + 1
            End If
        End If
    Next r

    wsDst.Range(wsDst.Cells(1, 1), wsDst.Cells(lr, lc)).Value2 = outData

CleanExit:
    Application.StatusBar = False
    Application.ScreenUpdating = oldScreen: Application.EnableEvents = oldEvents: Application.Calculation = oldCalc
    MsgBox "IO DEVICE EM fast merge complete." & vbCrLf & vbCrLf & _
           "Matched FUNCTION DEVICE rows: " & matchedDevice & vbCrLf & _
           "Coordinate fallback matches: " & matchedTag & vbCrLf & _
           "Function Definition part fallbacks: " & matchedDef, vbInformation, "IO Return Merge"
    Exit Sub
Fail:
    Application.StatusBar = False
    Application.ScreenUpdating = oldScreen: Application.EnableEvents = oldEvents: Application.Calculation = oldCalc
    MsgBox "IO return merge failed. Error " & Err.number & ": " & Err.description, vbCritical, "IO Return Merge"
End Sub

Private Function IOM_BuildFunctionDeviceMap(ByVal ws As Worksheet) As Object
    Dim d As Object, data As Variant, m As Object, lr As Long, lc As Long, r As Long, i As Long
    Dim cBase As Long, cDev As Long, cType As Long, cCtrl As Long, cTag As Long, cX As Long, cY As Long, cZ As Long, cRot As Long
    Dim partNames As Variant, partCol(0 To 9) As Long, baseSeq As String, typ As String, dev As String, a As Variant
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    If ws Is Nothing Then Set IOM_BuildFunctionDeviceMap = d: Exit Function
    lr = IOM_LastRow(ws): lc = IOM_LastCol(ws): If lr < 2 Then Set IOM_BuildFunctionDeviceMap = d: Exit Function
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).Value2: Set m = IOM_HeaderMap(data, lc)
    cBase = IOM_ColAny(m, Array("SEQUENCE", "BASE SIS_SEQUENCE"))
    cDev = IOM_ColAny(m, Array("SIS_SEQUENCE", "DEVICE NAME"))
    cType = IOM_ColAny(m, Array("CONTROL_FUNCTION_TAG", "ITEM TYPE", "TYPE"))
    cCtrl = IOM_ColAny(m, Array("CONTROL_FUNCTION_NUMBER")): cTag = IOM_ColAny(m, Array("CONTROL_FUNCTION_TAG"))
    cX = IOM_ColAny(m, Array("X")): cY = IOM_ColAny(m, Array("Y")): cZ = IOM_ColAny(m, Array("Z")): cRot = IOM_ColAny(m, Array("ROTATION_DEG"))
    partNames = Array("PART_NUM_1", "MANUF_NAME_1", "PART_NUM_2", "MANUF_NAME_2", "PART_NUM_3", "MANUF_NAME_3", "PART_NUM_4", "MANUF_NAME_4", "PART_NUM_5", "MANUF_NAME_5")
    For i = 0 To 9
        partCol(i) = IOM_ColAny(m, Array(CStr(partNames(i))))
    Next i

    For r = 2 To lr
        PDPerf_Pulse "mod15_IOReturnMerge.IOM_BuildFunctionDeviceMap [L126]" & " row " & CStr(r)
        If cDev > 0 Then dev = IOM_Text(data(r, cDev)) Else dev = vbNullString
        If cType > 0 Then typ = IOM_Text(data(r, cType)) Else typ = vbNullString
        If cBase > 0 Then baseSeq = IOM_Text(data(r, cBase)) Else baseSeq = IOM_BaseSequence(dev, typ)
        If Len(baseSeq) > 0 Then
            ReDim a(0 To 15)
            If cCtrl > 0 Then a(0) = data(r, cCtrl)
            If cTag > 0 Then a(1) = data(r, cTag)
            If cX > 0 Then a(2) = data(r, cX)
            If cY > 0 Then a(3) = data(r, cY)
            If cZ > 0 Then a(4) = data(r, cZ)
            If cRot > 0 Then a(5) = data(r, cRot)
            For i = 0 To 9
                If partCol(i) > 0 Then
                    a(6 + i) = data(r, partCol(i))
                End If
            Next i
            d(UCase$(baseSeq & "|" & typ)) = a
        End If
    Next r
    Set IOM_BuildFunctionDeviceMap = d
End Function

Private Function IOM_BuildTagCoordinateMap(ByVal ws As Worksheet) As Object
    Dim d As Object, data As Variant, m As Object, lr As Long, lc As Long, r As Long
    Dim cSeq As Long, cX As Long, cY As Long, cZ As Long, cRot As Long, seq As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    If ws Is Nothing Then Set IOM_BuildTagCoordinateMap = d: Exit Function
    lr = IOM_LastRow(ws): lc = IOM_LastCol(ws): If lr < 2 Then Set IOM_BuildTagCoordinateMap = d: Exit Function
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).Value2: Set m = IOM_HeaderMap(data, lc)
    cSeq = IOM_ColAny(m, Array("SIS_SEQUENCE", "SEQUENCE")): cX = IOM_ColAny(m, Array("X"))
    cY = IOM_ColAny(m, Array("Y")): cZ = IOM_ColAny(m, Array("Z")): cRot = IOM_ColAny(m, Array("ROTATION_DEG"))
    If cSeq = 0 Then Set IOM_BuildTagCoordinateMap = d: Exit Function
    For r = 2 To lr
        PDPerf_Pulse "mod15_IOReturnMerge.IOM_BuildTagCoordinateMap [L159]" & " row " & CStr(r)
        seq = IOM_Text(data(r, cSeq))
        If Len(seq) > 0 Then d(UCase$(seq)) = Array(IOM_At(data, r, cX), IOM_At(data, r, cY), IOM_At(data, r, cZ), IOM_At(data, r, cRot))
    Next r
    Set IOM_BuildTagCoordinateMap = d
End Function

Private Function IOM_BuildFunctionDefinitionMap(ByVal ws As Worksheet) As Object
    Dim d As Object, data As Variant, m As Object, lr As Long, lc As Long, r As Long, i As Long
    Dim cCtrl As Long, partNames As Variant, partCol(0 To 9) As Long, ctrl As String, a As Variant
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    If ws Is Nothing Then Set IOM_BuildFunctionDefinitionMap = d: Exit Function
    lr = IOM_LastRow(ws): lc = IOM_LastCol(ws): If lr < 2 Then Set IOM_BuildFunctionDefinitionMap = d: Exit Function
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).Value2: Set m = IOM_HeaderMap(data, lc)
    cCtrl = IOM_ColAny(m, Array("CONTROL_FUNCTION_NUMBER", "CONTROL FUNTION NUMBER"))
    If cCtrl = 0 Then Set IOM_BuildFunctionDefinitionMap = d: Exit Function
    partNames = Array("PART_NUM_1", "MANUF_NAME_1", "PART_NUM_2", "MANUF_NAME_2", "PART_NUM_3", "MANUF_NAME_3", "PART_NUM_4", "MANUF_NAME_4", "PART_NUM_5", "MANUF_NAME_5")
    For i = 0 To 9
        partCol(i) = IOM_ColAny(m, Array(CStr(partNames(i))))
    Next i
    For r = 2 To lr
        PDPerf_Pulse "mod15_IOReturnMerge.IOM_BuildFunctionDefinitionMap [L179]" & " row " & CStr(r)
        ctrl = IOM_Text(data(r, cCtrl))
        If Len(ctrl) > 0 Then
            ReDim a(0 To 9)
            For i = 0 To 9
                If partCol(i) > 0 Then
                    a(i) = data(r, partCol(i))
                End If
            Next i
            d(UCase$(ctrl)) = a
        End If
    Next r
    Set IOM_BuildFunctionDefinitionMap = d
End Function

Private Function IOM_HeaderMap(ByRef data As Variant, ByVal lc As Long) As Object
    Dim d As Object, c As Long, k As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    For c = 1 To lc
        k = IOM_Key(data(1, c))
        If Len(k) > 0 Then
            If Not d.Exists(k) Then d(k) = c
        End If
    Next c
    Set IOM_HeaderMap = d
End Function

Private Function IOM_ColAny(ByVal m As Object, ByVal names As Variant) As Long
    Dim i As Long, k As String
    If m Is Nothing Then Exit Function
    For i = LBound(names) To UBound(names)
        k = IOM_Key(names(i))
        If m.Exists(k) Then
            IOM_ColAny = CLng(m(k))
            Exit Function
        End If
    Next i
End Function

Private Function IOM_Key(ByVal v As Variant) As String
    Dim s As String: s = UCase$(Trim$(CStr(v)))
    s = Replace(s, " ", ""): s = Replace(s, "_", ""): s = Replace(s, "-", ""): s = Replace(s, "(", ""): s = Replace(s, ")", ""): s = Replace(s, "/", "")
    IOM_Key = s
End Function

Private Function IOM_Text(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then Exit Function
    IOM_Text = Trim$(CStr(v))
End Function

Private Function IOM_Usable(ByVal v As Variant) As Boolean
    Dim s As String: s = UCase$(IOM_Text(v))
    IOM_Usable = (Len(s) > 0 And s <> "NOT FOUND" And s <> "N/A")
End Function

Private Function IOM_At(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As Variant
    If c > 0 Then IOM_At = data(r, c) Else IOM_At = vbNullString
End Function

Private Function IOM_BaseSequence(ByVal deviceName As String, ByVal itemType As String) As String
    Dim suffix As String
    If Len(itemType) > 0 Then
        suffix = "-" & itemType
        If Len(deviceName) > Len(suffix) Then If StrComp(Right$(deviceName, Len(suffix)), suffix, vbTextCompare) = 0 Then IOM_BaseSequence = Left$(deviceName, Len(deviceName) - Len(suffix)): Exit Function
    End If
    IOM_BaseSequence = deviceName
End Function

Private Function IOM_Sheet(ByVal wb As Workbook, ByVal nm As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        PDPerf_Pulse "mod15_IOReturnMerge.IOM_Sheet [L249]"
        If StrComp(Trim$(ws.name), Trim$(nm), vbTextCompare) = 0 Then
            Set IOM_Sheet = ws
            Exit Function
        End If
    Next ws
End Function

Private Function IOM_LastRow(ByVal ws As Worksheet) As Long
    Dim f As Range: On Error Resume Next: Set f = ws.Cells.Find("*", ws.Cells(1, 1), xlFormulas, xlPart, xlByRows, xlPrevious, False): On Error GoTo 0
    If f Is Nothing Then IOM_LastRow = 0 Else IOM_LastRow = f.Row
End Function

Private Function IOM_LastCol(ByVal ws As Worksheet) As Long
    Dim f As Range: On Error Resume Next: Set f = ws.Cells.Find("*", ws.Cells(1, 1), xlFormulas, xlPart, xlByColumns, xlPrevious, False): On Error GoTo 0
    If f Is Nothing Then IOM_LastCol = 0 Else IOM_LastCol = f.Column
End Function
