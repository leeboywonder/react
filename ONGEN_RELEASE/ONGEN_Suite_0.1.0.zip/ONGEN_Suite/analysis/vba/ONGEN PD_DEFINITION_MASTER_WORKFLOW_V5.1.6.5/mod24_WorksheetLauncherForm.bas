Attribute VB_Name = "mod24_WorksheetLauncherForm"
Option Explicit

'===============================================================================
' PD MASTER V4.7.3 - REAL ONGEN frmPDLauncher USERFORM SUPPORT
'
' The launcher UI itself is copied from an ONGEN workbook containing the actual
' frmPDLauncher component. Excel performs the UserForm Export/Import, which
' preserves both the .frm source and the required binary .frx control layout.
'
' This avoids attempting to recreate a UserForm as a worksheet and avoids
' shipping an invalid/missing FRX file.
'===============================================================================

Private Const LAUNCHER_FORM_NAME As String = "frmPDLauncher"
Private Const LEGACY_LAUNCHER_SHEET As String = "WORKSHEET LAUNCHER"

'UI_ShowLauncher is owned by mod01_UI so all existing button/macro references remain stable.



'One-time installer/repairer. The user chooses the source ONGEN workbook, so
'no filename, revision, or folder is hardcoded.
Public Sub NAV_Install_ONGEN_Launcher_Form()
    If PDPerf_IsYielding Then Exit Sub
    Dim sourcePath As String
    Dim sourceWb As Workbook
    Dim sourceWasOpen As Boolean
    Dim srcProject As Object
    Dim dstProject As Object
    Dim srcComponent As Object
    Dim oldComponent As Object
    Dim importedComponent As Object
    Dim frmPath As String
    Dim frxPath As String
    Dim tempFolder As String
    Dim oldSecurity As Long
    Dim securityChanged As Boolean
    Dim errNo As Long
    Dim errText As String

    On Error GoTo EH

    sourcePath = Launcher_SelectSourceWorkbook()
    If Len(sourcePath) = 0 Then Exit Sub

    If StrComp(sourcePath, ThisWorkbook.FullName, vbTextCompare) = 0 Then
        MsgBox "Select the ONGEN source workbook, not the PD Master workbook.", _
               vbExclamation, "Install frmPDLauncher"
        Exit Sub
    End If

    'Open source workbook with automatic macros disabled. If it is already open,
    'reuse the existing instance and do not close it afterward.
    Set sourceWb = Launcher_FindOpenWorkbook(sourcePath)
    sourceWasOpen = Not sourceWb Is Nothing

    If sourceWb Is Nothing Then
        oldSecurity = Application.AutomationSecurity
        Application.AutomationSecurity = 3   'msoAutomationSecurityForceDisable
        securityChanged = True

        Set sourceWb = Workbooks.Open( _
            Filename:=sourcePath, _
            UpdateLinks:=0, _
            ReadOnly:=True, _
            AddToMru:=False, _
            IgnoreReadOnlyRecommended:=True)

        Application.AutomationSecurity = oldSecurity
        securityChanged = False
    End If

    'Accessing VBProject requires:
    'File > Options > Trust Center > Macro Settings >
    'Trust access to the VBA project object model.
    Set srcProject = sourceWb.VBProject
    Set dstProject = ThisWorkbook.VBProject

    On Error Resume Next
    Set srcComponent = srcProject.VBComponents(LAUNCHER_FORM_NAME)
    On Error GoTo EH

    If srcComponent Is Nothing Then
        Err.Raise vbObjectError + 2401, "NAV_Install_ONGEN_Launcher_Form", _
                  "The selected workbook does not contain frmPDLauncher."
    End If

    tempFolder = Environ$("TEMP") & "\PDMaster_frmPDLauncher\"
    Launcher_EnsureFolder tempFolder

    frmPath = tempFolder & LAUNCHER_FORM_NAME & ".frm"
    frxPath = tempFolder & LAUNCHER_FORM_NAME & ".frx"

    On Error Resume Next
    Kill frmPath
    Kill frxPath
    On Error GoTo EH

    'Excel itself creates both frmPDLauncher.frm and frmPDLauncher.frx.
    srcComponent.Export frmPath

    If Len(Dir$(frmPath)) = 0 Then
        Err.Raise vbObjectError + 2402, "NAV_Install_ONGEN_Launcher_Form", _
                  "Excel did not export frmPDLauncher.frm."
    End If
    If Len(Dir$(frxPath)) = 0 Then
        Err.Raise vbObjectError + 2403, "NAV_Install_ONGEN_Launcher_Form", _
                  "Excel did not export the required frmPDLauncher.frx companion file."
    End If

    'Remove/replace an older launcher form if one is already present.
    On Error Resume Next
    Set oldComponent = dstProject.VBComponents(LAUNCHER_FORM_NAME)
    On Error GoTo EH

    If Not oldComponent Is Nothing Then
        dstProject.VBComponents.Remove oldComponent
        Set oldComponent = Nothing
    End If

    Set importedComponent = dstProject.VBComponents.Import(frmPath)

    If importedComponent Is Nothing Then
        Err.Raise vbObjectError + 2404, "NAV_Install_ONGEN_Launcher_Form", _
                  "The UserForm import did not return a component."
    End If

    If StrComp(importedComponent.name, LAUNCHER_FORM_NAME, vbTextCompare) <> 0 Then
        Err.Raise vbObjectError + 2405, "NAV_Install_ONGEN_Launcher_Form", _
                  "The imported form name is '" & importedComponent.name & _
                  "' instead of frmPDLauncher."
    End If

    If Not sourceWasOpen Then sourceWb.Close SaveChanges:=False
    Set sourceWb = Nothing

    'Remove the incorrect V4.7.2 launcher worksheet and repair all sheet buttons.
    mod23_WorksheetNavigation.NAV_Remove_Legacy_Launcher_Worksheet False
    mod23_WorksheetNavigation.NAV_Install_Worksheet_Navigation_All_Sheets False

    On Error Resume Next
    Kill frmPath
    Kill frxPath
    RmDir tempFolder
    On Error GoTo 0

    MsgBox "frmPDLauncher was copied successfully into the PD Master." & vbCrLf & _
           "The worksheet launcher is now the actual ONGEN-style UserForm." & vbCrLf & vbCrLf & _
           "No WORKSHEET LAUNCHER worksheet is used.", _
           vbInformation, "PD Master Worksheet Launcher"

    mod01_UI.UI_ShowLauncher
    Exit Sub

EH:
    errNo = Err.number
    errText = Err.description

    On Error Resume Next
    If securityChanged Then Application.AutomationSecurity = oldSecurity
    If Not sourceWb Is Nothing Then
        If Not sourceWasOpen Then sourceWb.Close SaveChanges:=False
    End If
    On Error GoTo 0

    If InStr(1, errText, "programmatic access", vbTextCompare) > 0 Or _
       InStr(1, errText, "VBProject", vbTextCompare) > 0 Or _
       errNo = 1004 Then

        MsgBox "Excel blocked access to the VBA project while copying frmPDLauncher." & vbCrLf & vbCrLf & _
               "Enable this once:" & vbCrLf & _
               "File > Options > Trust Center > Trust Center Settings > Macro Settings >" & vbCrLf & _
               "Trust access to the VBA project object model" & vbCrLf & vbCrLf & _
               "Then run NAV_Install_ONGEN_Launcher_Form again." & vbCrLf & vbCrLf & _
               "Error " & errNo & ": " & errText, _
               vbExclamation, "Install frmPDLauncher"
    Else
        MsgBox "frmPDLauncher could not be installed." & vbCrLf & _
               "Error " & errNo & ": " & errText, _
               vbExclamation, "Install frmPDLauncher"
    End If
End Sub

Public Sub NAV_Repair_Form_Based_Launcher()
    If PDPerf_IsYielding Then Exit Sub
    'Convenience entry point after the form is already installed.
    mod23_WorksheetNavigation.NAV_Remove_Legacy_Launcher_Worksheet False
    mod23_WorksheetNavigation.NAV_Install_Worksheet_Navigation_All_Sheets False
    mod01_UI.UI_ShowLauncher
End Sub

Private Function Launcher_SelectSourceWorkbook() As String
    Dim fd As FileDialog

    Set fd = Application.FileDialog(msoFileDialogFilePicker)
    With fd
        .title = "Select ONGEN workbook containing frmPDLauncher"
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Excel Macro-Enabled Workbooks", "*.xlsm;*.xlsb"
        .Filters.Add "All Excel Workbooks", "*.xls*"

        If .Show <> -1 Then Exit Function
        Launcher_SelectSourceWorkbook = CStr(.SelectedItems(1))
    End With
End Function

Private Function Launcher_FindOpenWorkbook(ByVal fullPath As String) As Workbook
    Dim wb As Workbook
    For Each wb In Application.Workbooks
        PDPerf_Pulse "mod24_WorksheetLauncherForm.Launcher_FindOpenWorkbook [L209]"
        If StrComp(wb.FullName, fullPath, vbTextCompare) = 0 Then
            Set Launcher_FindOpenWorkbook = wb
            Exit Function
        End If
    Next wb
End Function

Private Sub Launcher_EnsureFolder(ByVal folderPath As String)
    If Len(Dir$(folderPath, vbDirectory)) = 0 Then MkDir folderPath
End Sub
