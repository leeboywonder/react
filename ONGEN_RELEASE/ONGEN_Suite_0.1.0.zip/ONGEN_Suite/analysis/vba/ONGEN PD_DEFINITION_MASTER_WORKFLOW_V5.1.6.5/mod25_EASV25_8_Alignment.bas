Attribute VB_Name = "mod25_EASV25_8_Alignment"
Option Explicit

'===============================================================================
' PD DEFINITION MASTER - EAS V25.8 POWER ALIGNMENT
'
' Purpose
'   1) Add Beckhoff IO/S and IO/D modules to the existing BUS-2 PSU estimate.
'   2) Match each IO module to the PSU group of its conveyor SIS sequence.
'      The matching key intentionally removes -IO/S or -IO/D and, when needed,
'      uses the conveyor numeric root (example 1060 -> 1060-01B).
'   3) Allocate each IO module to one of the same four PSU terminals without
'      adding another conveyor-length span. The IO module is physically tied to
'      the conveyor location; it adds electrical load, not another ML distance.
'   4) Keep Power Supply Bus, Estimated_Power_Supply and
'      PSU_Terminal_Assignment synchronized.
'
' EAS V25.8 limits
'   PSU = 40 A, 35 ft center span
'   terminal = 20 A, 20 ft, four terminals
'
' This module does NOT change PD6 System Designed headers and does NOT add EAS
' helper columns to the AutoCAD PD6 CSV.
'===============================================================================

Private Const SH_IO As String = "IO DEVICE EM"
Private Const SH_POWER As String = "DATA_POWER"
Private Const SH_BUS As String = "Power Supply Bus"
Private Const SH_EST As String = "Estimated_Power_Supply"
Private Const SH_TERM As String = "PSU_Terminal_Assignment"
Private Const PSU_LIMIT_A As Double = 40#
Private Const TERM_LIMIT_A As Double = 20#
Private Const RULE_VERSION As String = "V5.1.5-EAS-V25.8-DATAPOWER-CENTER50-40A-35FT-20A-20FT-IO-INCLUDED"

'===============================================================================
' STANDALONE BACKFILL
' Run this as Step 5G, AFTER Step 5D has imported the completed B03 IO return
' and Step 5F has filled the IO library blocks. The PSU breakout from Step 2A/2B
' is reused as-is.  It does NOT call Step 2A, Step 2B, rebuild PD6, clear any power
' sheet, resequence PSUs, or create a different PSU group.
'
' It only attaches IO/S and IO/D modules to the EXISTING BUS-2 PSU groups and
' existing terminals, preferring the terminal already used by the module's
' parent conveyor.  Re-running this command is safe: IO records already present
' in PSU_Terminal_Assignment are skipped.
'===============================================================================
Public Sub Step05G_Backfill_IO_PSU_Terminals()
    If PDPerf_IsYielding Then Exit Sub
    PD_Backfill_IO_PSU_Terminals_Only
End Sub

'Legacy compatibility alias only. The MAIN workflow now exposes this as Step 5G.
Public Sub Step02C_Backfill_IO_PSU_Terminals()
    If PDPerf_IsYielding Then Exit Sub
    PD_Backfill_IO_PSU_Terminals_Only
End Sub

Public Sub PD_Backfill_IO_PSU_Terminals_Only()
    If PDPerf_IsYielding Then Exit Sub
    Dim wsBus As Worksheet, wsEst As Worksheet, wsTerm As Worksheet
    Dim oldCalc As XlCalculation, oldScreen As Boolean, oldEvents As Boolean

    Set wsBus = EA_Sheet(ThisWorkbook, SH_BUS)
    Set wsEst = EA_Sheet(ThisWorkbook, SH_EST)
    Set wsTerm = EA_Sheet(ThisWorkbook, SH_TERM)

    If wsBus Is Nothing Or wsEst Is Nothing Or wsTerm Is Nothing Then
        MsgBox "The existing PSU calculation sheets are required:" & vbCrLf & _
               "  " & SH_BUS & vbCrLf & _
               "  " & SH_EST & vbCrLf & _
               "  " & SH_TERM & vbCrLf & vbCrLf & _
               "Step 5G reuses the existing Step 2A/2B PSU breakout. Rerun Step 2A/2B only if those calculation sheets are missing or intentionally need redesign.", _
               vbExclamation, "IO PSU Terminal Backfill"
        Exit Sub
    End If

    oldCalc = Application.Calculation
    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents

    On Error GoTo Fail
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    EASAlign_AddIOModulesToPowerBreakout wsBus, wsEst, wsTerm, True

CleanExit:
    Application.Calculation = oldCalc
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents
    Exit Sub

Fail:
    MsgBox "IO PSU/terminal backfill stopped: " & Err.description, vbCritical, "IO PSU Terminal Backfill"
    Resume CleanExit
End Sub

Public Sub EASAlign_AddIOModulesToPowerBreakout(ByVal wsBus As Worksheet, _
                                                 ByVal wsEst As Worksheet, _
                                                 ByVal wsTerm As Worksheet, _
                                                 Optional ByVal showSummary As Boolean = False)
    Dim wsIO As Worksheet, wsPower As Worksheet
    Dim lrIO As Long, lrBus As Long, lrTerm As Long, lrEst As Long
    Dim cIOSeq As Long, cIOType As Long, cIOArea As Long, cIOSwg As Long, cIOPanel As Long
    Dim cBusLoad As Long, cBusDevice As Long, cBusSeqList As Long, cBusArea As Long
    Dim cBusSwg As Long, cBusPanel As Long, cBusCode As Long, cBusTerm1 As Long
    Dim cBusAssign As Long, cBusFullPSU As Long
    Dim cTPsu As Long, cTSource As Long, cTBlock As Long, cTBus As Long, cTTerm As Long
    Dim cTLoad As Long, cTReach As Long, cTML As Long, cTZL As Long, cTArea As Long
    Dim cTSwg As Long, cTPanel As Long, cTStatus As Long
    Dim counts As Object, ordinals As Object, termLoad As Object, reachByRoot As Object
    Dim exactBus As Object, rootBus As Object, rootBusCount As Object
    Dim existingIO As Object, parentTermMap As Object
    Dim r As Long, rr As Long, n As Long, occurrence As Long, groupRow As Long
    Dim baseSeq As String, typ As String, ioSeq As String, key As String, root As String
    Dim amps As Double, oldLoad As Double, newLoad As Double
    Dim shortPSU As String, fullPSU As String, areaVal As String, swgVal As String, panelVal As String
    Dim termIdx As Long, termDesc As String, labelText As String, statusText As String
    Dim busReach As Double, mlVal As Variant, zlVal As Variant
    Dim terminalNames(1 To 4) As String
    Dim added As Long, skippedExisting As Long, missingGroup As Long, overLimit As Long
    Dim preferredTerm As String, blockType As String

    If wsBus Is Nothing Or wsEst Is Nothing Or wsTerm Is Nothing Then Exit Sub
    Set wsIO = EA_Sheet(ThisWorkbook, SH_IO)
    Set wsPower = EA_Sheet(ThisWorkbook, SH_POWER)
    If wsIO Is Nothing Then Exit Sub
    If wsPower Is Nothing Then Err.Raise vbObjectError + 5820, , "DATA_POWER is required for IO-module BUS load lookup."

    cIOSeq = EA_HeaderAny(wsIO, "SEQUENCE", "SIS_SEQUENCE", "SIS_sequence")
    cIOType = EA_HeaderAny(wsIO, "TYPE", "DEVICE TYPE", "DEVICE_TYPE")
    cIOArea = EA_HeaderAny(wsIO, "AREA_NUMBER", "AREA_Number")
    cIOSwg = EA_HeaderAny(wsIO, "SWITCHGROUP", "SwitchGroup", "PWG")
    cIOPanel = EA_HeaderAny(wsIO, "Panel", "PNL")
    If cIOSeq = 0 Or cIOType = 0 Then Exit Sub

    cBusLoad = EA_FindHeaderInRows(wsBus, "Load (A)", 1, 5)
    cBusDevice = EA_FindHeaderInRows(wsBus, "Device 1", 1, 5)
    cBusSeqList = EA_FindHeaderInRows(wsBus, "Sequence", 1, 5)
    cBusArea = EA_FindHeaderInRows(wsBus, "Area_Number", 1, 5)
    cBusSwg = EA_FindHeaderInRows(wsBus, "SwitchGroup", 1, 5)
    cBusPanel = EA_FindHeaderInRows(wsBus, "PNL", 1, 5)
    cBusCode = EA_FindHeaderInRows(wsBus, "BUS", 1, 5)
    cBusTerm1 = EA_FindHeaderInRows(wsBus, "Terminal 1 Sequence", 1, 5)
    cBusAssign = EA_FindHeaderInRows(wsBus, "Terminal Assignment", 1, 5)
    cBusFullPSU = EA_FindHeaderInRows(wsBus, "PSU SIS Element Number", 1, 5)
    If cBusLoad = 0 Or cBusDevice = 0 Or cBusSeqList = 0 Or cBusCode = 0 Or cBusTerm1 = 0 Or cBusAssign = 0 Then
        Err.Raise vbObjectError + 5821, , "Power Supply Bus does not have the V4.7.4/V25.8 alignment headers."
    End If

    cTPsu = EA_HeaderAny(wsTerm, "PSU_SIS_SEQUENCE")
    cTSource = EA_HeaderAny(wsTerm, "SOURCE_SIS_SEQUENCE")
    cTBlock = EA_HeaderAny(wsTerm, "BLOCK_NAME")
    cTBus = EA_HeaderAny(wsTerm, "BUS")
    cTTerm = EA_HeaderAny(wsTerm, "PSU_TERMINAL")
    cTLoad = EA_HeaderAny(wsTerm, "CURRENT_LOAD")
    cTReach = EA_HeaderAny(wsTerm, "BUS_REACH_MM")
    cTML = EA_HeaderAny(wsTerm, "MODULE_LENGTH_ML")
    cTZL = EA_HeaderAny(wsTerm, "ZONE_LENGTH_ZL")
    cTArea = EA_HeaderAny(wsTerm, "AREA_NUMBER")
    cTSwg = EA_HeaderAny(wsTerm, "SWITCHGROUP")
    cTPanel = EA_HeaderAny(wsTerm, "PNL")
    cTStatus = EA_HeaderAny(wsTerm, "STATUS")
    If cTPsu = 0 Or cTSource = 0 Or cTBlock = 0 Or cTBus = 0 Or cTTerm = 0 Or cTLoad = 0 Then
        Err.Raise vbObjectError + 5822, , "PSU_Terminal_Assignment does not have the required headers."
    End If

    For n = 1 To 4
        terminalNames(n) = mod22_PSUTerminalAllocator.PSUTerm_TerminalName(n)
    Next n

    Set counts = EA_Dict()
    Set ordinals = EA_Dict()
    Set termLoad = EA_Dict()
    Set reachByRoot = EA_Dict()
    Set exactBus = EA_Dict()
    Set rootBus = EA_Dict()
    Set rootBusCount = EA_Dict()
    Set existingIO = EA_Dict()
    Set parentTermMap = EA_Dict()

    'Index existing BUS-2 groups by exact conveyor sequence and numeric root.
    lrBus = EA_LastRow(wsBus)
    For r = 1 To lrBus
        PDPerf_Pulse "mod25_EASV25_8_Alignment.EASAlign_AddIOModulesToPowerBreakout [L182]" & " row " & CStr(r)
        If UCase$(EA_Text(wsBus.Cells(r, cBusCode).Value2)) = "BUS-2" Then
            EA_IndexBusSequenceList exactBus, rootBus, rootBusCount, CStr(wsBus.Cells(r, cBusSeqList).Value2), r
        End If
    Next r

    'Count physical IO modules. Identical IO DEVICE EM rows represent separate modules.
    lrIO = EA_LastRow(wsIO)
    For r = 2 To lrIO
        PDPerf_Pulse "mod25_EASV25_8_Alignment.EASAlign_AddIOModulesToPowerBreakout [L190]" & " row " & CStr(r)
        baseSeq = EA_Text(wsIO.Cells(r, cIOSeq).Value2)
        typ = EA_NormalizeIOType(EA_Text(wsIO.Cells(r, cIOType).Value2))
        If Len(baseSeq) > 0 And EA_IsIOModuleType(typ) Then
            key = UCase$(baseSeq & "|" & typ)
            If counts.Exists(key) Then counts(key) = CLng(counts(key)) + 1 Else counts(key) = 1
        End If
    Next r

    'Build terminal amp load and physical reach reference from the already-calculated devices.
    lrTerm = EA_LastRow(wsTerm)
    For r = 2 To lrTerm
        PDPerf_Pulse "mod25_EASV25_8_Alignment.EASAlign_AddIOModulesToPowerBreakout [L201]" & " row " & CStr(r)
        If UCase$(EA_Text(wsTerm.Cells(r, cTBus).Value2)) = "BUS-2" Then
            shortPSU = EA_Text(wsTerm.Cells(r, cTPsu).Value2)
            termDesc = EA_Text(wsTerm.Cells(r, cTTerm).Value2)
            If Len(shortPSU) > 0 And Len(termDesc) > 0 And UCase$(termDesc) <> "MISSING" Then
                key = UCase$(shortPSU & "|BUS-2|" & termDesc)
                If termLoad.Exists(key) Then
                    termLoad(key) = CDbl(termLoad(key)) + EA_Number(wsTerm.Cells(r, cTLoad).Value2)
                Else
                    termLoad(key) = EA_Number(wsTerm.Cells(r, cTLoad).Value2)
                End If
            End If
            root = EA_ConveyorRoot(EA_Text(wsTerm.Cells(r, cTSource).Value2))
            If Len(shortPSU) > 0 And Len(root) > 0 Then
                key = UCase$(shortPSU & "|BUS-2|" & root)
                busReach = EA_Number(wsTerm.Cells(r, cTReach).Value2)
                If Not reachByRoot.Exists(key) Then
                    reachByRoot(key) = busReach
                ElseIf busReach > CDbl(reachByRoot(key)) Then
                    reachByRoot(key) = busReach
                End If

                'Remember which terminal(s) the parent conveyor already uses.
                'IO modules prefer one of these terminals before falling back to
                'another available terminal on the same pre-calculated PSU.
                blockType = EA_NormalizeIOType(EA_Text(wsTerm.Cells(r, cTBlock).Value2))
                If Not EA_IsIOModuleType(blockType) And Len(termDesc) > 0 And UCase$(termDesc) <> "MISSING" Then
                    EA_AddUniqueMapValue parentTermMap, key, termDesc
                End If
            End If

            'Idempotency: an IO module already backfilled is not added twice.
            blockType = EA_NormalizeIOType(EA_Text(wsTerm.Cells(r, cTBlock).Value2))
            If EA_IsIOModuleType(blockType) Then
                key = UCase$(EA_Text(wsTerm.Cells(r, cTSource).Value2) & "|" & blockType & "|BUS-2")
                If Len(EA_Text(wsTerm.Cells(r, cTSource).Value2)) > 0 Then existingIO(key) = True
            End If
        End If
    Next r

    'Append IO modules to the BUS-2 group which already powers the parent conveyor.
    For r = 2 To lrIO
        PDPerf_Pulse "mod25_EASV25_8_Alignment.EASAlign_AddIOModulesToPowerBreakout [L242]" & " row " & CStr(r)
        baseSeq = EA_Text(wsIO.Cells(r, cIOSeq).Value2)
        typ = EA_NormalizeIOType(EA_Text(wsIO.Cells(r, cIOType).Value2))
        If Len(baseSeq) = 0 Or Not EA_IsIOModuleType(typ) Then GoTo NextIO

        key = UCase$(baseSeq & "|" & typ)
        If ordinals.Exists(key) Then
            occurrence = CLng(ordinals(key)) + 1
        Else
            occurrence = 1
        End If
        ordinals(key) = occurrence
        If CLng(counts(key)) > 1 Then
            ioSeq = baseSeq & "-" & typ & "-" & CStr(occurrence)
        Else
            ioSeq = baseSeq & "-" & typ
        End If

        key = UCase$(ioSeq & "|" & typ & "|BUS-2")
        If existingIO.Exists(key) Then
            skippedExisting = skippedExisting + 1
            GoTo NextIO
        End If

        amps = EA_DataPowerBusAmps(wsPower, typ, "BUS-2")
        If amps <= 0# Then
            Err.Raise vbObjectError + 5823, , "DATA_POWER has no positive BUS-2 load for " & typ & "."
        End If

        groupRow = EA_FindBusGroupRow(exactBus, rootBus, rootBusCount, baseSeq)
        If groupRow = 0 Then
            missingGroup = missingGroup + 1
            EA_AppendTermRow wsTerm, cTPsu, cTSource, cTBlock, cTBus, cTTerm, cTLoad, cTReach, cTML, cTZL, cTArea, cTSwg, cTPanel, cTStatus, _
                             "MISSING", ioSeq, typ, "BUS-2", "MISSING", amps, 0#, Empty, Empty, _
                             EA_CellText(wsIO, r, cIOArea), EA_CellText(wsIO, r, cIOSwg), EA_CellText(wsIO, r, cIOPanel), _
                             "NO BUS-2 PSU GROUP FOR PARENT CONVEYOR " & baseSeq
            GoTo NextIO
        End If

        shortPSU = EA_Text(wsBus.Cells(groupRow, cBusDevice).Value2)
        fullPSU = vbNullString
        If cBusFullPSU > 0 Then fullPSU = EA_Text(wsBus.Cells(groupRow, cBusFullPSU).Value2)
        areaVal = EA_CellText(wsIO, r, cIOArea): If Len(areaVal) = 0 And cBusArea > 0 Then areaVal = EA_Text(wsBus.Cells(groupRow, cBusArea).Value2)
        swgVal = EA_CellText(wsIO, r, cIOSwg): If Len(swgVal) = 0 And cBusSwg > 0 Then swgVal = EA_Text(wsBus.Cells(groupRow, cBusSwg).Value2)
        panelVal = EA_CellText(wsIO, r, cIOPanel): If Len(panelVal) = 0 And cBusPanel > 0 Then panelVal = EA_Text(wsBus.Cells(groupRow, cBusPanel).Value2)
        If Len(fullPSU) = 0 Then fullPSU = EA_BuildFullPSU(areaVal, swgVal, shortPSU)

        oldLoad = EA_Number(wsBus.Cells(groupRow, cBusLoad).Value2)
        newLoad = oldLoad + amps
        wsBus.Cells(groupRow, cBusLoad).Value2 = Round(newLoad, 2)

        root = EA_ConveyorRoot(baseSeq)
        key = UCase$(shortPSU & "|BUS-2|" & root)
        If reachByRoot.Exists(key) Then busReach = CDbl(reachByRoot(key)) Else busReach = 0#
        EA_ResolveLengths baseSeq, mlVal, zlVal

        termIdx = 0
        If newLoad <= PSU_LIMIT_A Then
            'First choice: terminal already associated with this parent conveyor.
            key = UCase$(shortPSU & "|BUS-2|" & root)
            preferredTerm = EA_FindPreferredParentTerminal(parentTermMap, key, shortPSU, termLoad, amps)
            If Len(preferredTerm) > 0 Then termIdx = EA_TerminalIndex(preferredTerm, terminalNames)

            'Fallback: another terminal on the SAME pre-calculated PSU.
            If termIdx = 0 Then
                For n = 1 To 4
                    termDesc = terminalNames(n)
                    key = UCase$(shortPSU & "|BUS-2|" & termDesc)
                    If termLoad.Exists(key) Then oldLoad = CDbl(termLoad(key)) Else oldLoad = 0#
                    If oldLoad + amps <= TERM_LIMIT_A Then
                        termIdx = n
                        Exit For
                    End If
                Next n
            End If
        End If

        labelText = ioSeq & "[" & typ & "]"
        If termIdx > 0 Then
            termDesc = terminalNames(termIdx)
            key = UCase$(shortPSU & "|BUS-2|" & termDesc)
            If termLoad.Exists(key) Then termLoad(key) = CDbl(termLoad(key)) + amps Else termLoad(key) = amps
            EA_AppendUniqueTextCell wsBus.Cells(groupRow, cBusTerm1 + termIdx - 1), labelText, ", "
            EA_AppendUniqueTextCell wsBus.Cells(groupRow, cBusAssign), labelText & "=" & termDesc, "; "
            statusText = "OK - IO MODULE ADDED BY EAS V25.8 ALIGNMENT"
        Else
            termDesc = "MISSING"
            EA_AppendUniqueTextCell wsBus.Cells(groupRow, cBusAssign), labelText & "=MISSING", "; "
            If newLoad > PSU_LIMIT_A Then
                statusText = "PSU OVER 40A AFTER IO MODULE LOAD"
                overLimit = overLimit + 1
            Else
                statusText = "NO TERMINAL WITH 20A CAPACITY FOR IO MODULE"
            End If
        End If

        EA_AppendTermRow wsTerm, cTPsu, cTSource, cTBlock, cTBus, cTTerm, cTLoad, cTReach, cTML, cTZL, cTArea, cTSwg, cTPanel, cTStatus, _
                         shortPSU, ioSeq, typ, "BUS-2", termDesc, amps, busReach, mlVal, zlVal, areaVal, swgVal, panelVal, statusText
        existingIO(UCase$(ioSeq & "|" & typ & "|BUS-2")) = True

        EA_UpdateEstimatedBUS2 wsEst, shortPSU, groupRow, wsBus, cBusLoad, cBusAssign
        added = added + 1
NextIO:
    Next r

    'Make the rule version explicit on every generated estimate row.
    lrEst = EA_LastRow(wsEst)
    Dim cRule As Long
    cRule = EA_HeaderAny(wsEst, "ESTIMATE_RULE_VERSION")
    If cRule > 0 Then
        For r = 2 To lrEst
            PDPerf_Pulse "mod25_EASV25_8_Alignment.EASAlign_AddIOModulesToPowerBreakout [L352]" & " row " & CStr(r)
            If Len(EA_Text(wsEst.Cells(r, 1).Value2)) > 0 Then wsEst.Cells(r, cRule).Value2 = RULE_VERSION
        Next r
    End If

    If showSummary Then
        MsgBox "IO PSU/terminal backfill complete." & vbCrLf & vbCrLf & _
               "Added: " & CStr(added) & vbCrLf & _
               "Already present / skipped: " & CStr(skippedExisting) & vbCrLf & _
               "No parent BUS-2 PSU group: " & CStr(missingGroup) & vbCrLf & _
               "PSU over 40 A after IO load: " & CStr(overLimit) & vbCrLf & vbCrLf & _
               "Step 2A and Step 2B were NOT rerun and no PSU grouping was rebuilt.", _
               IIf(missingGroup > 0 Or overLimit > 0, vbExclamation, vbInformation), _
               "IO PSU Terminal Backfill"
    ElseIf missingGroup > 0 Or overLimit > 0 Then
        MsgBox CStr(added) & " IO modules were added to BUS-2 PSU/terminal breakout." & vbCrLf & _
               CStr(missingGroup) & " IO modules could not find a parent conveyor BUS-2 group." & vbCrLf & _
               CStr(overLimit) & " PSU groups exceeded 40 A after IO load and were flagged MISSING.", _
               vbExclamation, "EAS V25.8 IO Power Alignment"
    End If
End Sub

Private Sub EA_UpdateEstimatedBUS2(ByVal wsEst As Worksheet, ByVal shortPSU As String, _
                                   ByVal busRow As Long, ByVal wsBus As Worksheet, _
                                   ByVal cBusLoad As Long, ByVal cBusAssign As Long)
    Dim cSeq As Long, cBus As Long, cLoad As Long, cAssign As Long, lr As Long, r As Long
    cSeq = EA_HeaderAny(wsEst, "SIS_SEQUENCE")
    cBus = EA_HeaderAny(wsEst, "BUS")
    cLoad = EA_HeaderAny(wsEst, "CURRENT_LOAD")
    cAssign = EA_HeaderAny(wsEst, "PSU_TERMINAL_ASSIGNMENTS")
    If cSeq = 0 Or cBus = 0 Then Exit Sub
    lr = EA_LastRow(wsEst)
    For r = 2 To lr
        PDPerf_Pulse "mod25_EASV25_8_Alignment.EA_UpdateEstimatedBUS2 [L384]" & " row " & CStr(r)
        If StrComp(EA_Text(wsEst.Cells(r, cSeq).Value2), shortPSU, vbTextCompare) = 0 Then
            If InStr(1, UCase$(EA_Text(wsEst.Cells(r, cBus).Value2)), "BUS 2", vbTextCompare) > 0 Or _
               InStr(1, UCase$(EA_Text(wsEst.Cells(r, cBus).Value2)), "BUS-2", vbTextCompare) > 0 Or _
               InStr(1, UCase$(EA_Text(wsEst.Cells(r, cBus).Value2)), "LOGIC", vbTextCompare) > 0 Then
                If cLoad > 0 Then wsEst.Cells(r, cLoad).Value2 = wsBus.Cells(busRow, cBusLoad).Value2
                If cAssign > 0 Then wsEst.Cells(r, cAssign).NumberFormat = "@": wsEst.Cells(r, cAssign).Value2 = CStr(wsBus.Cells(busRow, cBusAssign).Value2)
                Exit Sub
            End If
        End If
    Next r
End Sub

Private Sub EA_AppendTermRow(ByVal ws As Worksheet, ByVal cPsu As Long, ByVal cSource As Long, _
                             ByVal cBlock As Long, ByVal cBus As Long, ByVal cTerm As Long, _
                             ByVal cLoad As Long, ByVal cReach As Long, ByVal cML As Long, _
                             ByVal cZL As Long, ByVal cArea As Long, ByVal cSwg As Long, _
                             ByVal cPanel As Long, ByVal cStatus As Long, _
                             ByVal psu As String, ByVal src As String, ByVal blockName As String, _
                             ByVal busName As String, ByVal terminal As String, ByVal amps As Double, _
                             ByVal reachMM As Double, ByVal ml As Variant, ByVal zl As Variant, _
                             ByVal areaVal As String, ByVal swgVal As String, ByVal panelVal As String, _
                             ByVal statusVal As String)
    Dim r As Long
    r = EA_LastRow(ws) + 1
    ws.Cells(r, cPsu).NumberFormat = "@": ws.Cells(r, cPsu).Value2 = psu
    ws.Cells(r, cSource).NumberFormat = "@": ws.Cells(r, cSource).Value2 = src
    ws.Cells(r, cBlock).Value2 = blockName
    ws.Cells(r, cBus).Value2 = busName
    ws.Cells(r, cTerm).Value2 = terminal
    ws.Cells(r, cLoad).Value2 = amps
    If cReach > 0 Then ws.Cells(r, cReach).Value2 = reachMM
    If cML > 0 Then ws.Cells(r, cML).Value2 = ml
    If cZL > 0 Then ws.Cells(r, cZL).Value2 = zl
    If cArea > 0 Then ws.Cells(r, cArea).Value2 = areaVal
    If cSwg > 0 Then ws.Cells(r, cSwg).Value2 = swgVal
    If cPanel > 0 Then ws.Cells(r, cPanel).Value2 = panelVal
    If cStatus > 0 Then ws.Cells(r, cStatus).Value2 = statusVal
End Sub

Private Sub EA_ResolveLengths(ByVal baseSeq As String, ByRef ml As Variant, ByRef zl As Variant)
    ml = Empty: zl = Empty
    On Error Resume Next
    mod21_CSVTraceability.CSVTrace_ResolveLengths baseSeq, baseSeq, vbNullString, ml, zl
    On Error GoTo 0
End Sub

Private Function EA_DataPowerBusAmps(ByVal ws As Worksheet, ByVal typ As String, ByVal busName As String) As Double
    Dim lr As Long, lc As Long, c As Long, r As Long, cType As Long, cBus As Long
    Dim h As String, targetBus As String, t As String
    lr = EA_LastRow(ws): lc = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    targetBus = EA_Norm(busName)
    For c = 1 To lc
        If EA_Norm(ws.Cells(1, c).Value2) = "TYPE" Then
            Dim j As Long
            For j = c + 1 To WorksheetFunction.Min(c + 8, lc)
                If EA_Norm(ws.Cells(1, j).Value2) = targetBus Then cType = c: cBus = j: Exit For
            Next j
            If cType > 0 Then Exit For
        End If
    Next c
    If cType = 0 Or cBus = 0 Then Err.Raise vbObjectError + 5824, , "DATA_POWER 24V Type/BUS table was not found."
    For r = 2 To lr
        PDPerf_Pulse "mod25_EASV25_8_Alignment.EA_DataPowerBusAmps [L446]" & " row " & CStr(r)
        t = EA_NormalizeIOType(EA_Text(ws.Cells(r, cType).Value2))
        If StrComp(t, EA_NormalizeIOType(typ), vbTextCompare) = 0 Then
            EA_DataPowerBusAmps = EA_Number(ws.Cells(r, cBus).Value2)
            Exit Function
        End If
    Next r
End Function

Private Sub EA_IndexBusSequenceList(ByVal exactBus As Object, ByVal rootBus As Object, ByVal rootCount As Object, _
                                    ByVal listText As String, ByVal rowNo As Long)
    Dim a As Variant, i As Long, s As String, root As String, k As String
    a = Split(listText, ",")
    For i = LBound(a) To UBound(a)
        s = EA_Text(a(i))
        If Len(s) > 0 Then
            k = UCase$(s)
            If Not exactBus.Exists(k) Then exactBus(k) = rowNo
            root = EA_ConveyorRoot(s)
            If Len(root) > 0 Then
                k = UCase$(root)
                If rootCount.Exists(k) Then rootCount(k) = CLng(rootCount(k)) + 1 Else rootCount(k) = 1
                If Not rootBus.Exists(k) Then rootBus(k) = rowNo
            End If
        End If
    Next i
End Sub

Private Function EA_FindBusGroupRow(ByVal exactBus As Object, ByVal rootBus As Object, _
                                    ByVal rootCount As Object, ByVal baseSeq As String) As Long
    Dim k As String
    k = UCase$(EA_Text(baseSeq))
    If exactBus.Exists(k) Then EA_FindBusGroupRow = CLng(exactBus(k)): Exit Function
    k = UCase$(EA_ConveyorRoot(baseSeq))
    If rootBus.Exists(k) Then EA_FindBusGroupRow = CLng(rootBus(k))
End Function

Private Function EA_ConveyorRoot(ByVal v As Variant) As String
    Dim s As String, p As Long, a As Variant
    s = UCase$(EA_Text(v))
    s = Replace$(s, "_", "-")
    p = InStr(1, s, "-IO/", vbTextCompare): If p = 0 Then p = InStr(1, s, "-IO-", vbTextCompare)
    If p > 0 Then s = Left$(s, p - 1)
    a = Split(s, "-")
    If UBound(a) >= 0 Then EA_ConveyorRoot = Trim$(CStr(a(0))) Else EA_ConveyorRoot = s
End Function

Private Function EA_NormalizeIOType(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(EA_Text(v))
    s = Replace$(s, "_", "/")
    If Left$(s, 4) = "IO/D" Then EA_NormalizeIOType = "IO/D": Exit Function
    If Left$(s, 4) = "IO/S" Then EA_NormalizeIOType = "IO/S": Exit Function
    EA_NormalizeIOType = s
End Function

Private Function EA_IsIOModuleType(ByVal typ As String) As Boolean
    EA_IsIOModuleType = (UCase$(typ) = "IO/D" Or UCase$(typ) = "IO/S")
End Function

Private Function EA_BuildFullPSU(ByVal areaVal As String, ByVal swgVal As String, ByVal shortPSU As String) As String
    If Len(areaVal) > 0 And Len(swgVal) > 0 And Len(shortPSU) > 0 Then
        EA_BuildFullPSU = areaVal & "-" & swgVal & "-" & shortPSU
    Else
        EA_BuildFullPSU = shortPSU
    End If
End Function

Private Sub EA_AppendUniqueTextCell(ByVal cell As Range, ByVal addText As String, ByVal delim As String)
    Dim cur As String, padded As String
    addText = Trim$(addText): If Len(addText) = 0 Then Exit Sub
    cur = CStr(cell.Value2)
    padded = delim & cur & delim
    If InStr(1, padded, delim & addText & delim, vbTextCompare) = 0 Then
        If Len(cur) > 0 Then cur = cur & delim
        cell.NumberFormat = "@"
        cell.Value2 = cur & addText
    End If
End Sub


Private Sub EA_AddUniqueMapValue(ByVal d As Object, ByVal mapKey As String, ByVal addValue As String)
    Const SEP As String = "|~|"
    Dim cur As String, a As Variant, i As Long
    addValue = EA_Text(addValue)
    If Len(mapKey) = 0 Or Len(addValue) = 0 Then Exit Sub
    If d.Exists(mapKey) Then
        cur = CStr(d(mapKey))
        a = Split(cur, SEP)
        For i = LBound(a) To UBound(a)
            If StrComp(EA_Text(a(i)), addValue, vbTextCompare) = 0 Then Exit Sub
        Next i
        d(mapKey) = cur & SEP & addValue
    Else
        d(mapKey) = addValue
    End If
End Sub

Private Function EA_FindPreferredParentTerminal(ByVal parentTermMap As Object, ByVal mapKey As String, _
                                                 ByVal shortPSU As String, ByVal termLoad As Object, _
                                                 ByVal amps As Double) As String
    Const SEP As String = "|~|"
    Dim a As Variant, i As Long, t As String, k As String, existingLoad As Double
    If Not parentTermMap.Exists(mapKey) Then Exit Function
    a = Split(CStr(parentTermMap(mapKey)), SEP)
    For i = LBound(a) To UBound(a)
        t = EA_Text(a(i))
        If Len(t) > 0 Then
            k = UCase$(shortPSU & "|BUS-2|" & t)
            If termLoad.Exists(k) Then existingLoad = CDbl(termLoad(k)) Else existingLoad = 0#
            If existingLoad + amps <= TERM_LIMIT_A Then
                EA_FindPreferredParentTerminal = t
                Exit Function
            End If
        End If
    Next i
End Function

Private Function EA_TerminalIndex(ByVal terminalDesc As String, ByRef terminalNames() As String) As Long
    Dim n As Long
    For n = LBound(terminalNames) To UBound(terminalNames)
        If StrComp(EA_Text(terminalNames(n)), EA_Text(terminalDesc), vbTextCompare) = 0 Then
            EA_TerminalIndex = n
            Exit Function
        End If
    Next n
End Function

Private Function EA_FindHeaderInRows(ByVal ws As Worksheet, ByVal headerName As String, ByVal firstRow As Long, ByVal lastRow As Long) As Long
    Dim r As Long, c As Long, lc As Long
    For r = firstRow To lastRow
        PDPerf_Pulse "mod25_EASV25_8_Alignment.EA_FindHeaderInRows [L576]" & " row " & CStr(r)
        lc = ws.Cells(r, ws.Columns.count).End(xlToLeft).Column
        For c = 1 To lc
            If EA_Norm(ws.Cells(r, c).Value2) = EA_Norm(headerName) Then EA_FindHeaderInRows = c: Exit Function
        Next c
    Next r
End Function

Private Function EA_HeaderAny(ByVal ws As Worksheet, ParamArray names() As Variant) As Long
    Dim i As Long, c As Long, lc As Long
    lc = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    For i = LBound(names) To UBound(names)
        For c = 1 To lc
            If EA_Norm(ws.Cells(1, c).Value2) = EA_Norm(CStr(names(i))) Then EA_HeaderAny = c: Exit Function
        Next c
    Next i
End Function

Private Function EA_Sheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set EA_Sheet = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function EA_LastRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
                          SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then EA_LastRow = 1 Else EA_LastRow = f.Row
End Function

Private Function EA_Dict() As Object
    Set EA_Dict = CreateObject("Scripting.Dictionary")
    EA_Dict.CompareMode = vbTextCompare
End Function

Private Function EA_Text(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Then Exit Function
    EA_Text = Trim$(CStr(v))
End Function

Private Function EA_CellText(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c > 0 Then EA_CellText = EA_Text(ws.Cells(r, c).Value2)
End Function

Private Function EA_Number(ByVal v As Variant) As Double
    Dim s As String
    If IsError(v) Or IsEmpty(v) Then Exit Function
    If IsNumeric(v) Then EA_Number = CDbl(v): Exit Function
    s = UCase$(Trim$(CStr(v))): s = Replace$(s, "A", ""): s = Replace$(s, ",", "")
    If IsNumeric(s) Then EA_Number = CDbl(s)
End Function

Private Function EA_Norm(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(EA_Text(v))
    s = Replace$(s, " ", ""): s = Replace$(s, "_", ""): s = Replace$(s, "-", "")
    s = Replace$(s, "(", ""): s = Replace$(s, ")", ""): s = Replace$(s, "/", "")
    EA_Norm = s
End Function
