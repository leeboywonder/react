Attribute VB_Name = "mod05_BuildPD5"
Option Explicit

'==============================================================
' STEP 1D - BUILD SIS_TAG_PD5
' V5.1.5 rules:
'   1. Normal CAD rows are kept when their LPN exists in BOQ.
'   2. CAD TYPE is NEVER overwritten for an exported CAD row.
'   3. CAD RIO, VFD*, PNL, AK, IPC and AE rows are also kept when LPN is blank/missing.
'      This prevents electrical-only devices from disappearing before Step 2A.
'   4. For direct electrical rows, engineering fields are copied from
'      SIS_TAG_EXPORT when present. BOQ remains authoritative when LPN matches.
'   5. Listed non-electrical/support conveyor types are excluded from PD5.
'   6. BOQ-only LPNs still create one fallback PD5 row.
'==============================================================
Public Sub Build_PD5_From_BOQ()
    If PDPerf_IsYielding Then Exit Sub

    Const BOQ_SHEET As String = "BOQ"
    Const SIS_SHEET As String = "SIS_TAG_EXPORT"
    Const OUT_SHEET As String = "SIS_TAG_PD5"
    Const MISS_SHEET As String = "MISSING_LPN"

    Dim wb As Workbook, wsBOQ As Worksheet, wsSIS As Worksheet
    Dim wsOut As Worksheet, wsMiss As Worksheet
    Dim arrBOQ As Variant, arrSis As Variant, arrOut() As Variant, arrMiss() As Variant
    Dim boqMap As Object, sisMap As Object, dictBOQ As Object, dictExport As Object, dictExcludedLPN As Object
    Dim headers As Variant, outMap As Object
    Dim lrB As Long, lcB As Long, lrS As Long, lcS As Long
    Dim r As Long, c As Long, outRow As Long, missRow As Long
    Dim key As String, lpn As String, bRow As Long, v As Variant
    Dim cadType As String, cadConv As String, boqConv As String
    Dim keepDirect As Boolean, isExcluded As Boolean
    Dim cntMC As Long, cntIC As Long, cntMOT As Long, cntFallback As Long
    Dim cntDirectRIO As Long, cntDirectVFD As Long, cntExcluded As Long
    Dim savedCancel As XlEnableCancelKey, errorNumber As Long, errorText As String
    Dim cntDirectPanels As Long

    savedCancel = Application.EnableCancelKey
    On Error GoTo ErrHandler
    Set wb = ThisWorkbook
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "Step 1D - Building SIS_TAG_PD5..."

    Set wsBOQ = SheetByName_1D(wb, BOQ_SHEET)
    Set wsSIS = SheetByName_1D(wb, SIS_SHEET)
    If wsBOQ Is Nothing Then Err.Raise vbObjectError + 1100, , "Sheet 'BOQ' was not found."
    If wsSIS Is Nothing Then Err.Raise vbObjectError + 1101, , "Sheet 'SIS_TAG_EXPORT' was not found."

    lrB = LastRow_1D(wsBOQ): lcB = LastCol_1D(wsBOQ)
    lrS = LastRow_1D(wsSIS): lcS = LastCol_1D(wsSIS)
    If lrB < 2 Then Err.Raise vbObjectError + 1102, , "No BOQ data was found."
    If lrS < 2 Then Err.Raise vbObjectError + 1103, , "No SIS_TAG_EXPORT data was found."

    arrBOQ = wsBOQ.Range(wsBOQ.Cells(1, 1), wsBOQ.Cells(lrB, lcB)).Value2
    arrSis = wsSIS.Range(wsSIS.Cells(1, 1), wsSIS.Cells(lrS, lcS)).Value2
    Set boqMap = HeaderMap_1D(arrBOQ)
    Set sisMap = HeaderMap_1D(arrSis)

    Require_1D boqMap, "Layout Position Number", BOQ_SHEET
    Require_1D boqMap, "Conveyor Type", BOQ_SHEET
    Require_1D boqMap, "Control Card Abbreviation", BOQ_SHEET
    Require_1D sisMap, "LPN", SIS_SHEET
    Require_1D sisMap, "TYPE", SIS_SHEET
    Require_1D sisMap, "SIS_SEQUENCE", SIS_SHEET

    headers = OutputHeaders_1D()
    Set outMap = HeaderListMap_1D(headers)

    Set dictBOQ = CreateObject("Scripting.Dictionary")
    dictBOQ.CompareMode = vbTextCompare
    Set dictExcludedLPN = CreateObject("Scripting.Dictionary")
    dictExcludedLPN.CompareMode = vbTextCompare

    'Build the usable BOQ map and separately remember excluded LPNs.
    For r = 2 To UBound(arrBOQ, 1)
        PDPerf_Pulse "mod05_BuildPD5.Build_PD5_From_BOQ [L78]" & " row " & CStr(r)
        lpn = Txt_1D(arrBOQ(r, boqMap("Layout Position Number")))
        key = Key_1D(lpn)
        boqConv = Txt_1D(GetArr_1D(arrBOQ, r, boqMap, "Conveyor Type"))

        If key <> "" Then
            If IsExcludedConveyorType_1D(boqConv) Then
                If Not dictExcludedLPN.Exists(key) Then dictExcludedLPN.Add key, True
            Else
                If Not dictBOQ.Exists(key) Then dictBOQ.Add key, r
            End If
        End If
    Next r

    Set dictExport = CreateObject("Scripting.Dictionary")
    dictExport.CompareMode = vbTextCompare
    For r = 2 To UBound(arrSis, 1)
        PDPerf_Pulse "mod05_BuildPD5.Build_PD5_From_BOQ [L94]" & " row " & CStr(r)
        key = Key_1D(GetArr_1D(arrSis, r, sisMap, "LPN"))
        cadConv = Txt_1D(GetArr_1D(arrSis, r, sisMap, "CONVEYOR_TYPE"))
        If key <> "" And Not IsExcludedConveyorType_1D(cadConv) Then
            If Not dictExport.Exists(key) Then dictExport.Add key, True
        End If
    Next r

    ReDim arrOut(1 To UBound(arrSis, 1) + dictBOQ.count + 2, 1 To UBound(headers) + 1)
    For c = LBound(headers) To UBound(headers)
        arrOut(1, c + 1) = headers(c)
    Next c
    outRow = 1

    'CAD rows:
    ' - ordinary devices require a valid BOQ LPN;
    ' - RIO, VFD*, PNL, AK, IPC and AE are electrical-only exceptions and remain in PD5 even when
    '   their CAD block does not carry an LPN.
    For r = 2 To UBound(arrSis, 1)
        PDPerf_Pulse "mod05_BuildPD5.Build_PD5_From_BOQ [L112]" & " row " & CStr(r)
        lpn = Txt_1D(GetArr_1D(arrSis, r, sisMap, "LPN"))
        key = Key_1D(lpn)
        cadType = NormalizeDeviceType_1D(GetArr_1D(arrSis, r, sisMap, "TYPE"))
        cadConv = Txt_1D(GetArr_1D(arrSis, r, sisMap, "CONVEYOR_TYPE"))
        keepDirect = IsDirectElectricalType_1D(cadType)
        isExcluded = IsExcludedConveyorType_1D(cadConv)

        If key <> "" And dictExcludedLPN.Exists(key) Then isExcluded = True

        If isExcluded Then
            cntExcluded = cntExcluded + 1

        ElseIf key <> "" And dictBOQ.Exists(key) Then
            bRow = CLng(dictBOQ(key))
            outRow = outRow + 1

            CopyCADFields_1D arrOut, outRow, outMap, arrSis, r, sisMap
            CopyExportEngineeringFields_1D arrOut, outRow, outMap, arrSis, r, sisMap
            arrOut(outRow, outMap("LPN")) = lpn
            FillBOQFields_1D arrOut, outRow, outMap, arrBOQ, bRow, boqMap
            CountKeptCADRow_1D arrSis, r, sisMap, cntMC, cntIC, cntMOT

        ElseIf keepDirect Then
            outRow = outRow + 1

            CopyCADFields_1D arrOut, outRow, outMap, arrSis, r, sisMap
            CopyExportEngineeringFields_1D arrOut, outRow, outMap, arrSis, r, sisMap
            arrOut(outRow, outMap("LPN")) = lpn

            If cadType = "RIO" Then
                cntDirectRIO = cntDirectRIO + 1
            ElseIf Left$(cadType, 3) = "VFD" Then
                cntDirectVFD = cntDirectVFD + 1
            Else
                cntDirectPanels = cntDirectPanels + 1
            End If
            CountKeptCADRow_1D arrSis, r, sisMap, cntMC, cntIC, cntMOT
        End If
    Next r

    'BOQ-only LPNs: append one fallback record. Excluded conveyor types were
    'removed from dictBOQ above and therefore never enter PD5 or MISSING_LPN.
    ReDim arrMiss(1 To dictBOQ.count + 1, 1 To 3)
    arrMiss(1, 1) = "Layout Position Number"
    arrMiss(1, 2) = "Conveyor Type"
    arrMiss(1, 3) = "TYPE Source"
    missRow = 1

    For Each v In dictBOQ.Keys
        PDPerf_Pulse "mod05_BuildPD5.Build_PD5_From_BOQ [L161]"
        key = CStr(v)
        If Not dictExport.Exists(key) Then
            bRow = CLng(dictBOQ(key))
            missRow = missRow + 1
            cntFallback = cntFallback + 1
            arrMiss(missRow, 1) = Txt_1D(arrBOQ(bRow, boqMap("Layout Position Number")))
            arrMiss(missRow, 2) = GetArr_1D(arrBOQ, bRow, boqMap, "Conveyor Type")
            arrMiss(missRow, 3) = "BOQ fallback - LPN not in CAD export"

            outRow = outRow + 1
            arrOut(outRow, outMap("LPN")) = arrMiss(missRow, 1)
            arrOut(outRow, outMap("TYPE")) = GetArr_1D(arrBOQ, bRow, boqMap, "Control Card Abbreviation")
            FillBOQFields_1D arrOut, outRow, outMap, arrBOQ, bRow, boqMap
        End If
    Next v

    'Finish array construction before touching the previous outputs.
    PDPerf_Pulse "1D - ready to write output", True
    Set wsOut = GetOrCreate_1D(wb, OUT_SHEET)
    Set wsMiss = GetOrCreate_1D(wb, MISS_SHEET)
    'No DoEvents / cancellation inside the two-output commit.
    Application.EnableCancelKey = xlDisabled
    WriteUsed_1D wsOut, arrOut, outRow, UBound(headers) + 1
    WriteUsed_1D wsMiss, arrMiss, missRow, 3
    wsOut.Range("A1").Resize(1, UBound(headers) + 1).Font.Bold = True
    wsMiss.Range("A1:C1").Font.Bold = True
    wsOut.Range("A1").Resize(outRow, UBound(headers) + 1).Columns.AutoFit
    wsMiss.Range("A1").Resize(missRow, 3).Columns.AutoFit
    If PDPerf_IsRunning Then Application.EnableCancelKey = xlErrorHandler

    MsgBox "Step 1D complete." & vbCrLf & vbCrLf & _
           "PD5 rows created: " & (outRow - 1) & vbCrLf & _
           "CAD TYPE values preserved exactly." & vbCrLf & _
           "Standalone RIO rows kept: " & cntDirectRIO & vbCrLf & _
           "Standalone VFD rows kept: " & cntDirectVFD & vbCrLf & _
           "Standalone PNL/AK/IPC/AE rows kept: " & cntDirectPanels & vbCrLf & _
           "Excluded support/non-electrical rows skipped: " & cntExcluded & vbCrLf & _
           "MultiControl rows kept: " & cntMC & vbCrLf & _
           "Interface_Card rows kept: " & cntIC & vbCrLf & _
           "MOT/EM_LM rows kept: " & cntMOT & vbCrLf & _
           "BOQ-only fallback LPN rows: " & cntFallback, vbInformation

SafeExit:
    Application.EnableCancelKey = savedCancel
    Application.StatusBar = False
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    If Not PDPerf_IsRunning Then Application.Calculation = xlCalculationAutomatic
    Exit Sub

ErrHandler:
    errorNumber = Err.number: errorText = Err.description
    PDPerf_RecordError errorNumber, errorText
    MsgBox "Step 1D failed or cancelled: " & errorText & vbCrLf & _
           "If output writing had started, rerun 1D before continuing.", vbCritical
    Resume SafeExit
End Sub

Private Function OutputHeaders_1D() As Variant
    OutputHeaders_1D = Array("HANDLE", "BLOCK_NAME", "SIS_SEQUENCE", "SIS_ELEMENT_NUMBER", "AREA_NUMBER", "SWITCHGROUP", "TYPE", "NETWORK_IP", "LPN", "LAYER", "X", "Y", "Z", "ROTATION_DEG", "System Type", "Conveyor Type", "Module Length (ML)", "Motor Power (Main Drive)", "Motor Voltage (Main Drive)", "Motor Brake Voltage (Main Drive)", "Motor Protection (Main Drive)", "Encoder Type (Main Drive)", "Total Qty of Sensors", "Control Card", "Qty of Control Card", "Total Qty of Drives", "Predecessor", "Successor")
End Function

Private Sub CopyCADFields_1D(ByRef dst As Variant, ByVal dr As Long, ByVal dm As Object, ByRef src As Variant, ByVal sr As Long, ByVal sm As Object)
    Dim a As Variant, i As Long, h As String
    a = Array("HANDLE", "BLOCK_NAME", "SIS_SEQUENCE", "SIS_ELEMENT_NUMBER", "AREA_NUMBER", "SWITCHGROUP", "TYPE", "NETWORK_IP", "LAYER", "X", "Y", "Z", "ROTATION_DEG", "Predecessor", "Successor")
    For i = LBound(a) To UBound(a)
        h = CStr(a(i))
        If sm.Exists(h) Then dst(dr, dm(h)) = src(sr, sm(h))
    Next i
End Sub

Private Sub CopyExportEngineeringFields_1D(ByRef dst As Variant, ByVal dr As Long, ByVal dm As Object, _
                                           ByRef src As Variant, ByVal sr As Long, ByVal sm As Object)
    PutExport_1D dst, dr, dm, src, sr, sm, "System Type", "SYSTEM_TYPE"
    PutExport_1D dst, dr, dm, src, sr, sm, "Conveyor Type", "CONVEYOR_TYPE"
    PutExport_1D dst, dr, dm, src, sr, sm, "Module Length (ML)", "MODULE_LENGTH_ML"
    PutExport_1D dst, dr, dm, src, sr, sm, "Motor Power (Main Drive)", "MOTOR_POWER_MAIN_DRIVE"
    PutExport_1D dst, dr, dm, src, sr, sm, "Motor Voltage (Main Drive)", "MOTOR_VOLTAGE_MAIN_DRIVE"
    PutExport_1D dst, dr, dm, src, sr, sm, "Motor Brake Voltage (Main Drive)", "MOTOR_BRAKE_VOLTAGE_MAIN_DRIVE"
    PutExport_1D dst, dr, dm, src, sr, sm, "Motor Protection (Main Drive)", "MOTOR_PROTECTION_MAIN_DRIVE"
    PutExport_1D dst, dr, dm, src, sr, sm, "Encoder Type (Main Drive)", "ENCODER_TYPE_MAIN_DRIVE"
    PutExport_1D dst, dr, dm, src, sr, sm, "Total Qty of Sensors", "TOTAL_QTY_OF_SENSORS"
    PutExport_1D dst, dr, dm, src, sr, sm, "Control Card", "CONTROL_CARD"
    PutExport_1D dst, dr, dm, src, sr, sm, "Qty of Control Card", "QTY_OF_CONTROL_CARD"
    PutExport_1D dst, dr, dm, src, sr, sm, "Total Qty of Drives", "TOTAL_QTY_OF_DRIVES"
End Sub

Private Sub PutExport_1D(ByRef d As Variant, ByVal dr As Long, ByVal dm As Object, _
                         ByRef s As Variant, ByVal sr As Long, ByVal sm As Object, _
                         ByVal dh As String, ByVal sh As String)
    If dm.Exists(dh) And sm.Exists(sh) Then d(dr, dm(dh)) = s(sr, sm(sh))
End Sub

Private Sub FillBOQFields_1D(ByRef dst As Variant, ByVal dr As Long, ByVal dm As Object, ByRef src As Variant, ByVal sr As Long, ByVal bm As Object)
    PutBOQ_1D dst, dr, dm, src, sr, bm, "System Type", "System Type"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Conveyor Type", "Conveyor Type"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Module Length (ML)", "Module Length (ML)"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Motor Power (Main Drive)", "Motor Power (Main Drive)"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Motor Voltage (Main Drive)", "Motor Voltage (Main Drive)"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Motor Brake Voltage (Main Drive)", "Motor Brake Voltage (Main Drive)"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Motor Protection (Main Drive)", "Motor Protection (Main Drive)"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Encoder Type (Main Drive)", "Encoder Type (Main Drive)"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Total Qty of Sensors", "Total Qty of Sensors"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Control Card", "Control Card"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Qty of Control Card", "Qty of Control Card"
    PutBOQ_1D dst, dr, dm, src, sr, bm, "Total Qty of Drives", "Total Qty of Drives"
End Sub

Private Sub PutBOQ_1D(ByRef d As Variant, ByVal dr As Long, ByVal dm As Object, ByRef s As Variant, ByVal sr As Long, ByVal sm As Object, ByVal dh As String, ByVal sh As String)
    If dm.Exists(dh) And sm.Exists(sh) Then d(dr, dm(dh)) = s(sr, sm(sh))
End Sub

Private Sub CountKeptCADRow_1D(ByRef arrSis As Variant, ByVal r As Long, ByVal sisMap As Object, _
                               ByRef cntMC As Long, ByRef cntIC As Long, ByRef cntMOT As Long)
    Select Case UCase$(Replace$(Txt_1D(GetArr_1D(arrSis, r, sisMap, "BLOCK_NAME")), " ", ""))
        Case "MULTICONTROL": cntMC = cntMC + 1
        Case "INTERFACE_CARD", "INTERFACECARD": cntIC = cntIC + 1
        Case "MOT", "EM_LM1", "EM_LM2": cntMOT = cntMOT + 1
    End Select
End Sub

Private Function IsDirectElectricalType_1D(ByVal deviceType As String) As Boolean
    deviceType = NormalizeDeviceType_1D(deviceType)
    IsDirectElectricalType_1D = (deviceType = "RIO" Or Left$(deviceType, 3) = "VFD" Or _
                                  deviceType = "PNL" Or deviceType = "AK" Or _
                                  deviceType = "IPC" Or deviceType = "AE")
End Function

Private Function NormalizeDeviceType_1D(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Txt_1D(v))
    s = Replace$(s, ChrW$(160), " ")
    s = Replace$(s, " ", "")
    NormalizeDeviceType_1D = s
End Function

Private Function IsExcludedConveyorType_1D(ByVal v As Variant) As Boolean
    Dim k As String
    k = NormalizeConveyorType_1D(v)

    Select Case k
        Case "ENDSTOPDROPIN", _
             "SUPPORTLENGTHSTRUT", _
             "SUPPORTDOUBLEH", _
             "PB1MC50M", _
             "PB2MC50M", _
             "POWERSUPPLY24V", _
             "MCMAGNET", _
             "POWERSUPPLYLOGIC24V", _
             "ENDCAPSFR", _
             "HCONNECTOR", _
             "VCONNECTOR"
            IsExcludedConveyorType_1D = True
    End Select
End Function

Private Function NormalizeConveyorType_1D(ByVal v As Variant) As String
    Dim s As String, i As Long, ch As String, out As String
    s = UCase$(Txt_1D(v))

    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If (ch >= "A" And ch <= "Z") Or (ch >= "0" And ch <= "9") Then out = out & ch
    Next i

    NormalizeConveyorType_1D = out
End Function

Private Function HeaderMap_1D(ByRef a As Variant) As Object
    Dim d As Object, c As Long, s As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    For c = 1 To UBound(a, 2)
        s = Trim$(CStr(a(1, c))): If s <> "" Then If Not d.Exists(s) Then d.Add s, c
    Next c
    Set HeaderMap_1D = d
End Function

Private Function HeaderListMap_1D(ByRef a As Variant) As Object
    Dim d As Object, i As Long
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    For i = LBound(a) To UBound(a)
        d(CStr(a(i))) = i + 1
    Next i
    Set HeaderListMap_1D = d
End Function

Private Function GetArr_1D(ByRef a As Variant, ByVal r As Long, ByVal m As Object, ByVal h As String) As Variant
    If m.Exists(h) Then GetArr_1D = a(r, m(h)) Else GetArr_1D = ""
End Function

Private Sub Require_1D(ByVal m As Object, ByVal h As String, ByVal sn As String)
    If Not m.Exists(h) Then Err.Raise vbObjectError + 1110, , "Header '" & h & "' not found in '" & sn & "'."
End Sub

Private Function SheetByName_1D(ByVal wb As Workbook, ByVal n As String) As Worksheet
    On Error Resume Next: Set SheetByName_1D = wb.Worksheets(n): On Error GoTo 0
End Function

Private Function GetOrCreate_1D(ByVal wb As Workbook, ByVal n As String) As Worksheet
    Set GetOrCreate_1D = SheetByName_1D(wb, n)
    If GetOrCreate_1D Is Nothing Then
        Set GetOrCreate_1D = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        GetOrCreate_1D.name = n
        If wb Is ThisWorkbook Then mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation GetOrCreate_1D
    End If
End Function

Private Function LastRow_1D(ByVal ws As Worksheet) As Long
    Dim x As Range: On Error Resume Next
    Set x = ws.Cells.Find(What:="*", LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)
    On Error GoTo 0: If x Is Nothing Then LastRow_1D = 1 Else LastRow_1D = x.Row
End Function

Private Function LastCol_1D(ByVal ws As Worksheet) As Long
    Dim x As Range: On Error Resume Next
    Set x = ws.Cells.Find(What:="*", LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)
    On Error GoTo 0: If x Is Nothing Then LastCol_1D = 1 Else LastCol_1D = x.Column
End Function

Private Function Txt_1D(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then Txt_1D = "" Else Txt_1D = Trim$(CStr(v))
End Function

Private Function Key_1D(ByVal v As Variant) As String
    Dim s As String: s = UCase$(Txt_1D(v))
    s = Replace$(s, " ", ""): s = Replace$(s, ChrW$(160), "")
    Key_1D = s
End Function

Private Sub WriteUsed_1D(ByVal ws As Worksheet, ByRef data As Variant, ByVal usedRows As Long, ByVal usedCols As Long)
    Dim exactData() As Variant, r As Long, c As Long
    ReDim exactData(1 To usedRows, 1 To usedCols)
    For r = 1 To usedRows
        For c = 1 To usedCols
            exactData(r, c) = data(r, c)
        Next c
    Next r
    'Clear only actual prior content and formatting, not all 17 billion cells.
    ws.Range(ws.Cells(1, 1), ws.Cells(LastRow_1D(ws), LastCol_1D(ws))).Clear
    ws.Range("A1").Resize(usedRows, usedCols).Value2 = exactData
End Sub
