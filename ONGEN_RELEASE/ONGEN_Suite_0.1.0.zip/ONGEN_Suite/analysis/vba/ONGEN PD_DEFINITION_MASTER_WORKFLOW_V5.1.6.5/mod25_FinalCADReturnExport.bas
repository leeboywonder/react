Attribute VB_Name = "mod25_FinalCADReturnExport"
Option Explicit

'===============================================================================
' ONGEN FINAL CAD RETURN EXPORT
' Module: mod25_FinalCADReturnExport
'
' Does NOT replace mod24_WorksheetLauncherForm.
'
' Public commands:
'   Export_Final_SIS_PD5_PSU_To_AutoCAD_CSV
'   Export_Final_AutoCAD_Return
'
' Sources:
'   SIS_TAG_PD5
'   PD4_Estimate_PSU
'
' Output:
'   ONGEN_SIS_PD5_PSU_RETURN.csv
'
' Design:
'   - Union of every header from both worksheets.
'   - Canonical SOURCE_SHEET, HANDLE, BLOCK_NAME, SIS_SEQUENCE, LPN, TYPE first.
'   - HANDLE is exported with an Excel text wrapper so CSV reopening cannot
'     convert hexadecimal/numeric-looking handles to numbers.
'   - PSU SEQUENCE aliases to SIS_SEQUENCE.
'   - PSU BLOCK aliases to BLOCK_NAME.
'   - No source-sheet values are modified.
'   - Error handler preserves the REAL error number/description.
'===============================================================================

Private Const FR_PD5 As String = "SIS_TAG_PD5"
Private Const FR_PSU As String = "PD4_Estimate_PSU"
Private Const FR_CAD As String = "SIS_TAG_EXPORT"
Private Const FR_DEFAULT As String = "ONGEN_SIS_PD5_PSU_RETURN.csv"

Public Sub Export_Final_SIS_PD5_PSU_To_AutoCAD_CSV()
    If PDPerf_IsYielding Then Exit Sub
    Dim wsPD5 As Worksheet, wsPSU As Worksheet
    Dim hdr As Object, ordered As Collection
    Dim cadBlockMap As Object
    Dim savePath As Variant
    Dim f As Integer
    Dim nPD5 As Long, nPSU As Long
    Dim stage As String
    Dim errNumber As Long, errDescription As String, errSource As String
    Dim oldScreen As Boolean, oldEvents As Boolean, oldAlerts As Boolean
    Dim oldStatus As Variant

    On Error GoTo Fail

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts
    oldStatus = Application.StatusBar

    stage = "Locating source worksheets"
    Set wsPD5 = FR_GetSheet(FR_PD5)
    Set wsPSU = FR_GetSheet(FR_PSU)

    If wsPD5 Is Nothing Then
        Err.Raise vbObjectError + 2501, "mod25_FinalCADReturnExport", _
                  "Worksheet '" & FR_PD5 & "' was not found."
    End If
    If wsPSU Is Nothing Then
        Err.Raise vbObjectError + 2502, "mod25_FinalCADReturnExport", _
                  "Worksheet '" & FR_PSU & "' was not found."
    End If

    stage = "Indexing SIS_TAG_EXPORT BLOCK_NAME values"
    Set cadBlockMap = FR_BuildCADBlockMap()

    stage = "Building union CSV header"
    Set hdr = CreateObject("Scripting.Dictionary")
    hdr.CompareMode = vbTextCompare
    Set ordered = New Collection

    FR_AddHeader hdr, ordered, "SOURCE_SHEET"
    FR_AddHeader hdr, ordered, "HANDLE"
    FR_AddHeader hdr, ordered, "BLOCK_NAME"
    FR_AddHeader hdr, ordered, "SIS_SEQUENCE"
    FR_AddHeader hdr, ordered, "SIS_ELEMENT_NUMBER"
    FR_AddHeader hdr, ordered, "LPN"
    FR_AddHeader hdr, ordered, "TYPE"

    FR_AddSheetHeaders wsPD5, hdr, ordered
    FR_AddSheetHeaders wsPSU, hdr, ordered

    stage = "Choosing output CSV"
    savePath = FR_ChooseOutputPath()

    If VarType(savePath) = vbBoolean Then
        If savePath = False Then GoTo SafeExit
    End If

    If Len(Trim$(CStr(savePath))) = 0 Then GoTo SafeExit
    If LCase$(Right$(CStr(savePath), 4)) <> ".csv" Then savePath = CStr(savePath) & ".csv"

    stage = "Validating output folder"
    FR_ValidateOutputFolder CStr(savePath)

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.StatusBar = "Creating final AutoCAD return CSV..."

    stage = "Opening output CSV: " & CStr(savePath)
    f = FreeFile
    Open CStr(savePath) For Output Access Write As #f

    stage = "Writing CSV header"
    FR_WriteHeader f, ordered

    stage = "Writing SIS_TAG_PD5 rows"
    nPD5 = FR_WriteRows(f, wsPD5, ordered, False, cadBlockMap)

    stage = "Writing PD4_Estimate_PSU rows"
    nPSU = FR_WriteRows(f, wsPSU, ordered, True, cadBlockMap)

    stage = "Closing output CSV"
    Close #f
    f = 0

    Application.StatusBar = oldStatus
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents
    Application.DisplayAlerts = oldAlerts

    MsgBox "Final AutoCAD return CSV created successfully." & vbCrLf & vbCrLf & _
           "SIS_TAG_PD5 rows: " & nPD5 & vbCrLf & _
           "PD4_Estimate_PSU rows: " & nPSU & vbCrLf & _
           "Total rows: " & (nPD5 + nPSU) & vbCrLf & vbCrLf & _
           CStr(savePath) & vbCrLf & vbCrLf & _
           "AutoCAD command: ONGEN_PD_IMPORT_FINAL_RETURN", _
           vbInformation, "Final CAD Return"
    Exit Sub

SafeExit:
    On Error Resume Next
    If f <> 0 Then Close #f
    Application.StatusBar = oldStatus
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents
    Application.DisplayAlerts = oldAlerts
    On Error GoTo 0
    Exit Sub

Fail:
    'Capture FIRST. Cleanup must never destroy the useful error.
    errNumber = Err.number
    errDescription = Err.description
    errSource = Err.Source

    On Error Resume Next
    If f <> 0 Then Close #f
    Application.StatusBar = oldStatus
    Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents
    Application.DisplayAlerts = oldAlerts
    On Error GoTo 0

    MsgBox "Final CAD return export failed." & vbCrLf & vbCrLf & _
           "Stage: " & stage & vbCrLf & _
           "Error: " & CStr(errNumber) & vbCrLf & _
           "Source: " & errSource & vbCrLf & _
           "Description: " & errDescription, _
           vbCritical, "Final CAD Return"
End Sub

Public Sub Export_Final_AutoCAD_Return()
    If PDPerf_IsYielding Then Exit Sub
    Export_Final_SIS_PD5_PSU_To_AutoCAD_CSV
End Sub

Private Function FR_WriteRows(ByVal f As Integer, ByVal ws As Worksheet, _
                              ByVal ordered As Collection, ByVal isPSU As Boolean, _
                              ByVal cadBlockMap As Object) As Long
    Dim map As Object
    Dim lr As Long, lc As Long
    Dim r As Long, i As Long, srcCol As Long
    Dim h As String, valText As String, line As String
    Dim cSeq As Long, cBlock As Long, cHandle As Long
    Dim n As Long

    Set map = FR_HeaderMap(ws)
    lr = FR_LastRow(ws)
    lc = FR_LastCol(ws)
    If lr < 2 Or lc < 1 Then Exit Function

    cSeq = FR_FindAny(map, Array("SIS_SEQUENCE", "SEQUENCE"))
    cBlock = FR_FindAny(map, Array("BLOCK_NAME", "BLOCK"))
    cHandle = FR_FindAny(map, Array("HANDLE"))

    For r = 2 To lr
        PDPerf_Pulse "mod25_FinalCADReturnExport.FR_WriteRows [L192]" & " row " & CStr(r)
        If FR_RowHasData(ws, r, lc) Then
            line = vbNullString

            For i = 1 To ordered.count
                h = CStr(ordered(i))
                valText = vbNullString

                Select Case FR_NormHeader(h)
                    Case "SOURCESHEET"
                        valText = ws.name

                    Case "HANDLE"
                        If cHandle > 0 Then
                            valText = FR_HandleText(ws, r, cHandle)
                            'CSV has no native cell data type. Wrap HANDLE as an Excel
                            'text formula so opening the CSV cannot convert it to a number.
                            If Len(valText) > 0 Then
                                valText = "=""" & Replace(valText, """", """""") & """"
                            End If
                        End If

                    Case "BLOCKNAME"
                        If cBlock > 0 Then valText = FR_CellText(ws, r, cBlock)
                        If Len(Trim$(valText)) = 0 Then
                            valText = FR_FindCADBlockName( _
                                        FR_CellText(ws, r, cSeq), _
                                        FR_HandleText(ws, r, cHandle), _
                                        cadBlockMap)
                        End If

                    Case "SISSEQUENCE"
                        If cSeq > 0 Then valText = FR_CellText(ws, r, cSeq)

                    Case Else
                        If map.Exists(FR_NormHeader(h)) Then
                            srcCol = CLng(map(FR_NormHeader(h)))
                            valText = FR_CellText(ws, r, srcCol)
                        End If
                End Select

                If i > 1 Then line = line & ","
                line = line & FR_CSV(valText)
            Next i

            Print #f, line
            n = n + 1
        End If
    Next r

    FR_WriteRows = n
End Function

Private Sub FR_WriteHeader(ByVal f As Integer, ByVal ordered As Collection)
    Dim i As Long, line As String
    For i = 1 To ordered.count
        If i > 1 Then line = line & ","
        line = line & FR_CSV(CStr(ordered(i)))
    Next i
    Print #f, line
End Sub

Private Sub FR_AddSheetHeaders(ByVal ws As Worksheet, ByVal d As Object, ByVal ordered As Collection)
    Dim c As Long, lc As Long, h As String
    lc = FR_LastCol(ws)
    For c = 1 To lc
        h = Trim$(FR_CellText(ws, 1, c))
        If Len(h) > 0 Then FR_AddHeader d, ordered, h
    Next c
End Sub

Private Sub FR_AddHeader(ByVal d As Object, ByVal ordered As Collection, ByVal h As String)
    Dim k As String
    k = FR_NormHeader(h)
    If Len(k) = 0 Then Exit Sub
    If Not d.Exists(k) Then
        d.Add k, h
        ordered.Add h
    End If
End Sub

Private Function FR_HeaderMap(ByVal ws As Worksheet) As Object
    Dim d As Object, c As Long, lc As Long, k As String
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    lc = FR_LastCol(ws)
    For c = 1 To lc
        k = FR_NormHeader(FR_CellText(ws, 1, c))
        If Len(k) > 0 Then
            If Not d.Exists(k) Then d.Add k, c
        End If
    Next c
    Set FR_HeaderMap = d
End Function

Private Function FR_FindAny(ByVal d As Object, ByVal names As Variant) As Long
    Dim i As Long, k As String
    For i = LBound(names) To UBound(names)
        k = FR_NormHeader(CStr(names(i)))
        If d.Exists(k) Then
            FR_FindAny = CLng(d(k))
            Exit Function
        End If
    Next i
End Function

Private Function FR_HandleText(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    Dim rawValue As Variant
    Dim shownText As String
    Dim formulaText As String
    Dim s As String

    If c <= 0 Then Exit Function

    'HANDLE IS AN IDENTIFIER, NEVER A NUMBER.
    '
    'Priority:
    '  1) Formula text when a formula explicitly returns/stores the handle.
    '  2) Displayed worksheet text (.Text) when it is not scientific notation.
    '  3) Value2 converted ONLY to String as a final fallback.
    '
    'No Val / CDbl / CLng / CSng conversion is permitted.

    On Error Resume Next
    formulaText = CStr(ws.Cells(r, c).Formula)
    shownText = CStr(ws.Cells(r, c).Text)
    rawValue = ws.Cells(r, c).Value2
    On Error GoTo 0

    'If the cell is a literal text entry, Formula contains that same literal.
    If Len(formulaText) > 0 Then
        If Left$(formulaText, 1) <> "=" Then
            s = formulaText
        End If
    End If

    'Prefer exactly what is visibly stored in the worksheet when usable.
    If Len(s) = 0 Then
        If Len(shownText) > 0 Then
            If InStr(1, shownText, "E+", vbTextCompare) = 0 And _
               InStr(1, shownText, "E-", vbTextCompare) = 0 And _
               InStr(1, shownText, "#", vbBinaryCompare) = 0 Then
                s = shownText
            End If
        End If
    End If

    If Len(s) = 0 Then
        If Not IsError(rawValue) And Not IsEmpty(rawValue) And Not IsNull(rawValue) Then
            s = CStr(rawValue)
        End If
    End If

    s = Trim$(s)

    'Excel leading apostrophe is a storage marker and is not part of the handle.
    If Len(s) > 1 Then
        If Left$(s, 1) = "'" Then s = Mid$(s, 2)
    End If

    FR_HandleText = s
End Function

Private Function FR_CellText(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    Dim v As Variant
    If c <= 0 Then Exit Function
    v = ws.Cells(r, c).Value2
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then Exit Function
    FR_CellText = CStr(v)
End Function

Private Function FR_CSV(ByVal s As String) As String
    s = Replace(s, """", """""")
    FR_CSV = """" & s & """"
End Function

Private Function FR_NormHeader(ByVal s As String) As String
    s = UCase$(Trim$(s))
    s = Replace(s, " ", "")
    s = Replace(s, "_", "")
    s = Replace(s, "-", "")
    s = Replace(s, vbTab, "")
    FR_NormHeader = s
End Function

Private Function FR_LastRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                          LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then FR_LastRow = 0 Else FR_LastRow = f.Row
End Function

Private Function FR_LastCol(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                          LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then FR_LastCol = 0 Else FR_LastCol = f.Column
End Function

Private Function FR_RowHasData(ByVal ws As Worksheet, ByVal r As Long, ByVal lc As Long) As Boolean
    Dim c As Long
    For c = 1 To lc
        If Len(FR_CellText(ws, r, c)) > 0 Then
            FR_RowHasData = True
            Exit Function
        End If
    Next c
End Function

Private Function FR_GetSheet(ByVal name As String) As Worksheet
    On Error Resume Next
    Set FR_GetSheet = ThisWorkbook.Worksheets(name)
    On Error GoTo 0
End Function

Private Function FR_BuildCADBlockMap() As Object
    Dim root As Object, byHandle As Object, bySeq As Object
    Dim ws As Worksheet, map As Object
    Dim lr As Long, r As Long
    Dim cHandle As Long, cSeq As Long, cBlock As Long
    Dim h As String, seq As String, blockName As String

    Set root = CreateObject("Scripting.Dictionary")
    Set byHandle = CreateObject("Scripting.Dictionary")
    Set bySeq = CreateObject("Scripting.Dictionary")
    byHandle.CompareMode = vbTextCompare
    bySeq.CompareMode = vbTextCompare

    root.Add "HANDLE", byHandle
    root.Add "SEQUENCE", bySeq

    Set ws = FR_GetSheet(FR_CAD)
    If ws Is Nothing Then
        Set FR_BuildCADBlockMap = root
        Exit Function
    End If

    Set map = FR_HeaderMap(ws)
    cHandle = FR_FindAny(map, Array("HANDLE"))
    cSeq = FR_FindAny(map, Array("SIS_SEQUENCE", "SEQUENCE"))
    cBlock = FR_FindAny(map, Array("BLOCK_NAME", "BLOCK"))

    If cBlock = 0 Then
        Set FR_BuildCADBlockMap = root
        Exit Function
    End If

    lr = FR_LastRow(ws)

    For r = 2 To lr
        PDPerf_Pulse "mod25_FinalCADReturnExport.FR_BuildCADBlockMap [L445]" & " row " & CStr(r)
        blockName = FR_CellText(ws, r, cBlock)
        If Len(Trim$(blockName)) > 0 Then
            If cHandle > 0 Then
                h = FR_HandleText(ws, r, cHandle)
                If Len(h) > 0 Then
                    If Not byHandle.Exists(UCase$(h)) Then byHandle.Add UCase$(h), blockName
                End If
            End If

            If cSeq > 0 Then
                seq = Trim$(FR_CellText(ws, r, cSeq))
                If Len(seq) > 0 Then
                    If Not bySeq.Exists(UCase$(seq)) Then bySeq.Add UCase$(seq), blockName
                End If
            End If
        End If
    Next r

    Set FR_BuildCADBlockMap = root
End Function

Private Function FR_FindCADBlockName(ByVal seq As String, ByVal handleText As String, _
                                     ByVal root As Object) As String
    Dim byHandle As Object, bySeq As Object
    Dim candidate As String, p As Long, first4 As String
    Dim k As Variant

    If root Is Nothing Then Exit Function
    Set byHandle = root("HANDLE")
    Set bySeq = root("SEQUENCE")

    If Len(Trim$(handleText)) > 0 Then
        If byHandle.Exists(UCase$(Trim$(handleText))) Then
            FR_FindCADBlockName = CStr(byHandle(UCase$(Trim$(handleText))))
            Exit Function
        End If
    End If

    candidate = Trim$(seq)
    If Len(candidate) = 0 Then Exit Function

    If bySeq.Exists(UCase$(candidate)) Then
        FR_FindCADBlockName = CStr(bySeq(UCase$(candidate)))
        Exit Function
    End If

    Do
        p = InStrRev(candidate, "-")
        If p <= 0 Then Exit Do
        candidate = Left$(candidate, p - 1)

        If bySeq.Exists(UCase$(candidate)) Then
            FR_FindCADBlockName = CStr(bySeq(UCase$(candidate)))
            Exit Function
        End If
    Loop

    first4 = Left$(Trim$(seq), 4)
    If Len(first4) = 4 Then
        For Each k In bySeq.Keys
            PDPerf_Pulse "mod25_FinalCADReturnExport.FR_FindCADBlockName [L505]"
            If Left$(CStr(k), 4) = UCase$(first4) Then
                FR_FindCADBlockName = CStr(bySeq(k))
                Exit Function
            End If
        Next k
    End If
End Function

'Run once after importing this module if the Phase 7B button is not already present.
Public Sub Install_Final_CAD_Return_Button()
    If PDPerf_IsYielding Then Exit Sub
    Dim ws As Worksheet
    Dim shp As Shape
    Dim anchor As Range
    Dim buttonName As String

    Set ws = FR_GetSheet("MAIN")
    If ws Is Nothing Then
        MsgBox "Worksheet 'MAIN' was not found.", vbCritical, "Final CAD Return"
        Exit Sub
    End If

    buttonName = "btn_Phase7B_FinalCADReturn"

    On Error Resume Next
    ws.Shapes(buttonName).Delete
    On Error GoTo 0

    Set anchor = ws.Range("h50")

    Set shp = ws.Shapes.AddFormControl( _
                Type:=xlButtonControl, _
                Left:=anchor.Left, _
                Top:=anchor.Top, _
                Width:=210, _
                Height:=30)

    shp.name = buttonName
    shp.OnAction = "'" & ThisWorkbook.name & "'!Export_Final_SIS_PD5_PSU_To_AutoCAD_CSV"
    shp.TextFrame.Characters.Text = "7B - Export Final CAD Return"

    MsgBox "Phase 7B button added at MAIN!B50." & vbCrLf & _
           "Button: 7B - Export Final CAD Return", _
           vbInformation, "Final CAD Return"
End Sub

Private Function FR_ChooseOutputPath() As Variant
    Dim startFolder As String
    Dim proposed As String
    Dim picked As Variant

    startFolder = FR_ExistingStartFolder()

    If Len(startFolder) > 0 Then
        proposed = startFolder & Application.PathSeparator & FR_DEFAULT
    Else
        proposed = FR_DEFAULT
    End If

    picked = Application.GetSaveAsFilename( _
                InitialFileName:=proposed, _
                FileFilter:="CSV Files (*.csv),*.csv", _
                title:="Export Final SIS_TAG_PD5 + PSU Return for AutoCAD")

    FR_ChooseOutputPath = picked
End Function

Private Function FR_ExistingStartFolder() As String
    Dim candidates(1 To 3) As String
    Dim i As Long
    Dim p As String

    'Workbook path is preferred only when it is a real Windows folder.
    candidates(1) = ThisWorkbook.path
    candidates(2) = Application.DefaultFilePath
    candidates(3) = Environ$("USERPROFILE") & "\Documents"

    For i = 1 To 3
        p = Trim$(candidates(i))
        If Len(p) > 0 Then
            If FR_FolderExists(p) Then
                FR_ExistingStartFolder = p
                Exit Function
            End If
        End If
    Next i
End Function

Private Sub FR_ValidateOutputFolder(ByVal fullFileName As String)
    Dim folderName As String
    Dim p As Long

    p = InStrRev(fullFileName, "\")
    If p = 0 Then p = InStrRev(fullFileName, "/")

    If p > 0 Then
        folderName = Left$(fullFileName, p - 1)

        If Not FR_FolderExists(folderName) Then
            Err.Raise vbObjectError + 2510, "mod25_FinalCADReturnExport", _
                      "The selected output folder does not exist or is not available:" & _
                      vbCrLf & folderName & vbCrLf & vbCrLf & _
                      "Choose a local or currently available network/OneDrive folder."
        End If
    End If
End Sub

Private Function FR_FolderExists(ByVal folderName As String) As Boolean
    Dim attr As Long

    On Error GoTo Nope

    If Len(Trim$(folderName)) = 0 Then Exit Function

    attr = GetAttr(folderName)
    FR_FolderExists = ((attr And vbDirectory) = vbDirectory)
    Exit Function

Nope:
    FR_FolderExists = False
End Function

Private Function FR_DefaultPath() As String
    Dim p As String
    p = FR_ExistingStartFolder()

    If Len(p) > 0 Then
        FR_DefaultPath = p & Application.PathSeparator & FR_DEFAULT
    Else
        FR_DefaultPath = FR_DEFAULT
    End If
End Function
