Attribute VB_Name = "mod06_EstimatePSU"
Option Explicit

'======================================================================
' V5.2.0 BROAD AUTO-SPLIT POLICY
' ---------------------------------------------------------------------
' SIS root/suffix grouping is a preference, never a fatal allocation rule.
'
' For BUS-1 and BUS-2, ANY of these allocation conflicts:
'   - PSU current > 40 A
'   - PSU BUS/reach > 35 ft / 10,668 mm
'   - terminal current > 20 A
'   - terminal reach > 20 ft / 6,096 mm
'   - no available terminal
'   - existing same-root PSU cannot accept the remaining family
'   - complete family load is larger than one PSU
'
' is handled by:
'   1) close/reject the current candidate PSU,
'   2) record a warning,
'   3) try another valid existing PSU (XYZ reuse where applicable),
'   4) create a new PSU if no existing PSU can legally accept the row,
'   5) continue Step 2A.
'
' The family may therefore span 1555-PSU, 1555-PSU-2, 1555-PSU-3, etc.
' Configuration/data errors (missing required sheets/headers or invalid
' DATA_POWER definitions) remain true errors because allocation cannot
' safely be calculated without those inputs.
'======================================================================

Private Const SH_PD5 As String = "SIS_TAG_PD5"
Private Const SH_BUS As String = "Power Supply Bus"
Private Const SH_EST As String = "Estimated_Power_Supply"
Private Const SH_TERM As String = "PSU_Terminal_Assignment"
Private Const ESTIMATE_RULE_VERSION As String = "V5.2.0-DATAPOWER-CENTER50-40A-35FT-20A-20FT-ROOTFAMILY-FLEX-SPLIT-XYZ-PSUREUSE"
Private Const SENSOR_AMPS As Double = 1.6
Private Const VFD_BUS2_AMPS As Double = 3.5
Private mFlowKeyCol As Long

Private mBus2LoadByType As Object

Private mAutoSplitWarnings As Collection
Private mAutoSplitWarningCount As Long

Public Sub Build_SIS_TAG_PD5_Manifest_Using_MotorVoltage()
    If PDPerf_IsYielding Then Exit Sub
    Dim ws As Worksheet, bus As Worksheet, est As Worksheet, termWs As Worksheet
    Dim lr As Long, cBlock As Long, cType As Long, cSeq As Long, cLPN As Long, cLen As Long, cZL As Long
    Dim cQtyDrv As Long, cPower As Long, cVolt As Long, cSensors As Long, cBrake As Long, cSys As Long
    Dim cPred As Long, cSucc As Long, cArea As Long, cSwg As Long, cPanel As Long
    Dim cX As Long, cY As Long, cZ As Long
    Dim outRow As Long
    Dim termRows As Collection

    On Error GoTo Fail
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Set ws = GetSheet2A(SH_PD5)
    If ws Is Nothing Then Err.Raise vbObjectError + 2400, , "Worksheet 'SIS_TAG_PD5' was not found."
    Set bus = GetOrCreate2A(SH_BUS)
    Set est = GetOrCreate2A(SH_EST)
    Set termWs = GetOrCreate2A(SH_TERM)
    Set termRows = New Collection

    cBlock = HeaderAny2A(ws, "BLOCK_NAME", "BLOCK NAME", "BLOCK")

    cType = HeaderAny2A(ws, "TYPE", "Item Type", "DEVICE TYPE", "DEVICE_TYPE")
    cSeq = HeaderAny2A(ws, "SIS_SEQUENCE", "SIS_sequence")
    cLPN = HeaderAny2A(ws, "LPN")
    cLen = HeaderAny2A(ws, "Module Length (ML)", "MODULE_LENGTH_ML", "ML")
    cZL = HeaderAny2A(ws, "Zone Length (ZL)", "ZONE_LENGTH_ZL", "ZL")
    cQtyDrv = HeaderAny2A(ws, "Total Qty of Drives")
    cPower = HeaderAny2A(ws, "Motor Power (Main Drive)", "Motor Power (Main)")
    cVolt = HeaderAny2A(ws, "Motor Voltage (Main Drive)", "Motor Voltage (Main)")
    cSensors = HeaderAny2A(ws, "Total Qty of Sensors")
    cBrake = HeaderAny2A(ws, "Motor Brake Voltage (Main Drive)", "Motor Brake Voltage (Main)")
    cSys = HeaderAny2A(ws, "System Type")
    cPred = HeaderAny2A(ws, "Predecessor")
    cSucc = HeaderAny2A(ws, "Successor")
    cArea = HeaderAny2A(ws, "AREA_Number", "AREA_NUMBER", "Area Number", "LOCATION")
    cSwg = HeaderAny2A(ws, "SwitchGroup", "SWITCHGROUP", "PWG")
    cPanel = HeaderAny2A(ws, "Panel", "PNL", "Feeding Panel")
    cX = HeaderAny2A(ws, "X")
    cY = HeaderAny2A(ws, "Y")
    cZ = HeaderAny2A(ws, "Z")

    Require2A cBlock, "BLOCK_NAME"
    Require2A cType, "TYPE"
    Require2A cLPN, "LPN"
    Require2A cLen, "Module Length (ML)"
    Require2A cQtyDrv, "Total Qty of Drives"
    Require2A cPower, "Motor Power (Main Drive)"
    Require2A cVolt, "Motor Voltage (Main Drive)"
    Require2A cSensors, "Total Qty of Sensors"
    Require2A cX, "X"
    Require2A cY, "Y"
    Require2A cZ, "Z"

    lr = LastRow2A(ws)
    If lr < 2 Then Err.Raise vbObjectError + 2401, , "SIS_TAG_PD5 does not contain any data rows."


    Set mBus2LoadByType = LoadBus2TypeMap2A()
    Set mAutoSplitWarnings = New Collection
    mAutoSplitWarningCount = 0


    'Predecessor/Successor establishes the engineered conveyor path. When those
    'links are unavailable the existing PD5 row order is preserved.
    mFlowKeyCol = ApplyPredSuccFlowOrder2A(ws, lr, cSeq, cLPN, cPred, cSucc, cType, cLen, cArea)

    'V5.2.0: keep each normalized SIS power family contiguous before either
    'BUS is calculated. Same-root rows are kept together whenever electrically
    'possible, but ANY PSU/terminal/current/reach limit may split the family.
    'A family split is a warning and processing continues; it is never a
    'same-family fatal error.
    ApplyPowerFamilyContiguousOrder2A ws, lr, cSeq, cLPN

    PrepareBusSheet2A bus
    PrepareTerminalSheet2A termWs

    outRow = 1
    WriteSection2A bus, outRow, "Power Bus 1": outRow = outRow + 2
    BuildBus12A ws, bus, lr, outRow, cBlock, cSeq, cLPN, cLen, cZL, cQtyDrv, cPower, cVolt, _
                 cArea, cSwg, cPanel, termRows

    outRow = outRow + 2
    WriteSection2A bus, outRow, "Logic Bus 2": outRow = outRow + 2
    BuildBus22A ws, bus, lr, outRow, cBlock, cType, cSeq, cLPN, cLen, cZL, cQtyDrv, cPower, cVolt, _
                 cSensors, cSys, cArea, cSwg, cPanel, cX, cY, cZ, termRows

    outRow = outRow + 2
    WriteVFDSection2A bus, outRow: outRow = outRow + 2
    BuildVFD2A ws, bus, lr, outRow, cBlock, cType, cSeq, cLPN, cPower, cVolt, cBrake, cSys

    WriteTerminalRows2A termWs, termRows
    BuildEstimated2A bus, est
    mod25_EASV25_8_Alignment.EASAlign_AddIOModulesToPowerBreakout bus, est, termWs

    bus.Columns("A:T").AutoFit
    termWs.Columns("A:M").AutoFit
    est.Columns("A:R").AutoFit

CleanExit:
    On Error Resume Next
    If Not ws Is Nothing And mFlowKeyCol > 0 Then ws.Columns(mFlowKeyCol).ClearContents

    Set mBus2LoadByType = Nothing
    On Error GoTo 0
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    If Not PDPerf_IsRunning Then Application.Calculation = xlCalculationAutomatic
    Application.StatusBar = False

    If Err.number = 0 Then
        MsgBox "Step 2A complete using the Mod03 terminal / length engine." & vbCrLf & vbCrLf & _
               "PSU estimate limit: 40 A / 10668 mm [35 ft]." & vbCrLf & _
               "Terminal limit: 20 A / 6096 mm [20 ft], four terminals." & vbCrLf & _
               "BUS-1 and BUS-2 use independent 50%-center span lengths." & vbCrLf & _
               "BUS-2 load is read PER DEVICE TYPE from DATA_POWER[Bus-2]." & vbCrLf & _
               "SIS root/suffix rows (for example 1270 + 1270-01A) are processed contiguously and stay together when the electrical limits allow." & vbCrLf & _
               "ANY allocation limit (40 A PSU, 35-ft BUS reach, 20 A terminal, 20-ft terminal reach, or no available terminal) automatically closes/rejects that PSU, records a warning, and continues on another/new PSU." & vbCrLf & _
               "Same-root/suffix grouping is a preference, not a fatal restriction. A family may span PSU-2, PSU-3, etc. when required by electrical limits." & vbCrLf & _
               "Existing electrically available PSUs are reused by XYZ proximity before the +/-20 sequence-gap fallback whenever the applicable remaining load can fit." & vbCrLf & _
               "RIO rows use XYZ cable reach; same-base conveyor PSU sharing is attempted first." & vbCrLf & _
               "VFD point rows with Module Length < 10 mm (or blank ML) use dedicated XYZ PSU grouping." & vbCrLf & _
               "VFD/VFD_MF/VFD_MC are counted once from the typed device row; VFD base load = DATA_POWER[VFD].Bus-2." & vbCrLf & _
               "Interface_Card receives BUS-1 power with 0 mm length and receives no BUS-2 power." & vbCrLf & _
               "IO/S and IO/D modules are added to BUS-2 using their parent conveyor SIS sequence and DATA_POWER load." & vbCrLf & _
               "Terminal outputs use DATA_POWER[PSUDESC] (DC1+/DC1-, DC2+/DC2-, etc.)." & vbCrLf & _
               "Power Supply Bus contains exact Sequence and terminal assignment detail for Power Calc." & _
               AutoSplitSummary2A(), _
               vbInformation, "Definition Power Estimate"
    End If
    Set mAutoSplitWarnings = Nothing
    Exit Sub

Fail:
    MsgBox "Step 2A failed: " & Err.description, vbCritical, "Definition Power Estimate"
    Resume CleanExit
End Sub

Private Sub BuildBus12A(ByVal ws As Worksheet, ByVal outWs As Worksheet, ByVal lr As Long, ByRef outRow As Long, _
                        ByVal cBlock As Long, ByVal cSeq As Long, ByVal cLPN As Long, ByVal cLen As Long, ByVal cZL As Long, _
                        ByVal cQtyDrv As Long, ByVal cPower As Long, ByVal cVolt As Long, ByVal cArea As Long, _
                        ByVal cSwg As Long, ByVal cPanel As Long, ByVal termRows As Collection)
    Dim hasQual As Object, fallback As Object
    Dim r As Long, k As String, b As String, amps As Double

    Set hasQual = Dict2A()
    Set fallback = Dict2A()

    'BUS-1 keeps every controller record. MultiControl + Interface_Card on the
    'same SIS sequence are both powered records; Interface_Card contributes 0 mm.
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.BuildBus12A [L196]" & " row " & CStr(r)
        k = DeviceKey2A(ws, r, cSeq, cLPN)
        If k <> "" Then
            b = BlockKey2A(ws.Cells(r, cBlock).Value)
            If IsBus1Controller2A(b) Then
                hasQual(k) = True
            ElseIf Not fallback.Exists(k) Then
                amps = OriginalBus1Amps2A(ws, r, cQtyDrv, cPower, cVolt)
                If amps > 0# Then fallback(k) = r
            End If
        End If
    Next r

    BuildBus1FromRows2A ws, outWs, lr, outRow, hasQual, fallback, cBlock, cSeq, cLPN, cLen, cZL, _
                        cQtyDrv, cPower, cVolt, cArea, cSwg, cPanel, termRows
End Sub

Private Sub BuildBus1FromRows2A(ByVal ws As Worksheet, ByVal outWs As Worksheet, ByVal lr As Long, ByRef outRow As Long, _
                                ByVal hasQual As Object, ByVal fallback As Object, ByVal cBlock As Long, _
                                ByVal cSeq As Long, ByVal cLPN As Long, ByVal cLen As Long, ByVal cZL As Long, _
                                ByVal cQtyDrv As Long, ByVal cPower As Long, ByVal cVolt As Long, _
                                ByVal cArea As Long, ByVal cSwg As Long, ByVal cPanel As Long, ByVal termRows As Collection)
    Dim doneFB As Object, ctlSeen As Object
    Dim r As Long, k As String, b As String, useRow As Boolean, includeRecord As Boolean
    Dim amps As Double, mm As Double, rawML As Variant, rawZL As Variant
    Dim runA As Double, runMM As Double, grp As Long, runCtl As Long
    Dim startSeq As String, endSeq As String, seq As String, runSeqList As String
    Dim reason As String, started As Boolean, flowKey As String, lastFlowKey As String
    Dim termLoad(1 To 4) As Double, termLengthMM(1 To 4) As Double, termSeq(1 To 4) As String
    Dim termIdx As Long, terminalName As String, terminalAssignments As String, forceClose As Boolean
    Dim areaNum As String, swg As String, panel As String, psuName As String, deviceLabel As String
    Dim spanSeen As Object, spanCount As Long, lastSpanML As Double, projectedMM As Double, deviceReachMM As Double
    Dim terminalLengthContributionMM As Double
    Dim isNewSpanSeq As Boolean
    Dim baseSeq As String, sameBaseActive As Boolean, baseGroupFound As Boolean
    Dim familyRemainingA As Double
    Dim attachTerminal As String, attachPSU As String, attachReach As Double

    Set doneFB = Dict2A()
    Set ctlSeen = Dict2A()
    Set spanSeen = Dict2A()
    grp = 1
    mod22_PSUTerminalAllocator.PSUTerm_ResetState termLoad, termLengthMM, termSeq

    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.BuildBus1FromRows2A [L240]" & " row " & CStr(r)
        k = DeviceKey2A(ws, r, cSeq, cLPN)
        useRow = False
        b = BlockKey2A(ws.Cells(r, cBlock).Value)

        If k <> "" Then
            If IsBus1Controller2A(b) Then
                useRow = True
            ElseIf Not hasQual.Exists(k) And fallback.Exists(k) And Not doneFB.Exists(k) Then
                If CLng(fallback(k)) = r Then
                    useRow = True
                    doneFB(k) = True
                End If
            End If
        End If

        If useRow Then
            amps = OriginalBus1Amps2A(ws, r, cQtyDrv, cPower, cVolt)
            If amps > 0# Then
                seq = SourceSeq2A(ws, r, cSeq, cLPN)
                rawML = ValueAt2A(ws, r, cLen)
                rawZL = ValueAt2A(ws, r, cZL)
                mm = mod22_PSUTerminalAllocator.PSUTerm_BusLengthMM("BUS-1", b, rawML, includeRecord)
                If Not includeRecord Then GoTo NextBus1Row
                flowKey = FlowSortKeyAtRow2A(ws, r)
                baseSeq = BaseSequenceKey2A(seq)
                sameBaseActive = (started And SequenceListHasBase2A(runSeqList, baseSeq))

                'A suffixed SIS sequence is part of the same power family as its
                'non-suffixed/root sequence. Do not split that family on a flow
                'branch, and do not count the same conveyor span twice.
                If started And Not sameBaseActive And Not FlowContinues2A(lastFlowKey, flowKey) Then
                    FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Power Bus 1", "BUS-1", _
                                "Flow branch / new conveyor path", runCtl, runSeqList, areaNum, swg, panel, psuName, _
                                termSeq, terminalAssignments
                    grp = grp + 1
                    ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                       terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                       spanSeen, spanCount, lastSpanML
                    sameBaseActive = False
                End If

                'V5.2.0 atomic-family reservation. Because the family rows are now
                'contiguous, reserve the current row plus every remaining suffix
                'member before putting the parent on the active PSU. If the entire
                'family will not fit, close the current PSU BEFORE the parent so
                'the parent and children start together on the new PSU.
                familyRemainingA = Bus1FamilyRemainingAmps2A(ws, r, lr, baseSeq, hasQual, fallback, _
                                                             cBlock, cSeq, cLPN, cLen, cQtyDrv, cPower, cVolt)
                'V5.2.0: a family may legitimately require more than one PSU.
                'Do not stop when the complete remaining root family is over 40 A.
                'Rows stay contiguous and the normal allocation checks below split
                'the family across uniquely named PSUs as needed.

                If started And Not sameBaseActive Then
                    If runA + familyRemainingA > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitA() Then
                        FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Power Bus 1", "BUS-1", _
                                    "Closed early so power family " & baseSeq & " starts together on a new PSU", _
                                    runCtl, runSeqList, areaNum, swg, panel, psuName, termSeq, terminalAssignments
                        grp = grp + 1
                        ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                           terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                           spanSeen, spanCount, lastSpanML
                        sameBaseActive = False
                    End If
                End If

                'If the root family was already written to a completed BUS-1 PSU,
                'reuse it rather than generating a second PSU for a suffix row.
                'If the family exists but cannot accept the load within the hard
                'electrical limits, stop instead of violating the same-PSU rule.
                If Not started Then
                    baseGroupFound = False
                    attachTerminal = vbNullString
                    attachPSU = vbNullString
                    attachReach = 0#
                    If TryAttachToExistingBusGroup2A(ws, outWs, outRow, lr, r, cBlock, cSeq, cLPN, _
                                                     cLen, cZL, cArea, cSwg, cPanel, 0, 0, 0, _
                                                     amps, "Power Bus 1", "BUS-1", True, termRows, _
                                                     baseGroupFound, attachPSU, attachTerminal, attachReach, familyRemainingA) Then
                        GoTo NextBus1Row
                    End If
                    'V5.2.0: same-root PSU reuse is preferred, not mandatory.
                    'If the completed family PSU cannot accept the remaining load,
                    'continue to a new PSU instead of failing Step 2A.
                End If

                If sameBaseActive Then
                    isNewSpanSeq = False
                Else
                    isNewSpanSeq = (mm > 0# And Not spanSeen.Exists(k))
                End If
                If isNewSpanSeq Then
                    projectedMM = mod22_PSUTerminalAllocator.PSUTerm_ProjectCenteredSpanMM(spanCount, runMM, lastSpanML, mm)
                    terminalLengthContributionMM = projectedMM - runMM
                Else
                    projectedMM = runMM
                    terminalLengthContributionMM = 0#
                End If
                deviceReachMM = projectedMM

                termIdx = mod22_PSUTerminalAllocator.PSUTerm_FindTerminal(termLoad, termLengthMM, amps, terminalLengthContributionMM)
                reason = vbNullString
                If started Then
                    If runA + amps > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitA() Then
                        reason = "Stopped before exceeding 40 A"
                    ElseIf projectedMM > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitMM() Then
                        reason = "Stopped before exceeding 10668 mm [35FT] center span"
                    ElseIf termIdx = 0 Then
                        reason = "Stopped before exceeding terminal 20 A / 20 ft capacity"
                    End If
                End If

                If Len(reason) > 0 Then
                    AddAutoSplitWarning2A "BUS-1", seq, baseSeq, psuName, reason
                    reason = "WARNING - " & reason & "; current PSU closed and device continued on another/new PSU"

                    FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Power Bus 1", "BUS-1", _
                                reason, runCtl, runSeqList, areaNum, swg, panel, psuName, termSeq, terminalAssignments
                    grp = grp + 1
                    ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                       terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                       spanSeen, spanCount, lastSpanML
                    sameBaseActive = False

                    'The just-closed group may not be the root family for this
                    'row. Before a new BUS-1 PSU is started, search all completed
                    'BUS-1 groups for the same root sequence.
                    baseGroupFound = False
                    attachTerminal = vbNullString
                    attachPSU = vbNullString
                    attachReach = 0#
                    If TryAttachToExistingBusGroup2A(ws, outWs, outRow, lr, r, cBlock, cSeq, cLPN, _
                                                     cLen, cZL, cArea, cSwg, cPanel, 0, 0, 0, _
                                                     amps, "Power Bus 1", "BUS-1", True, termRows, _
                                                     baseGroupFound, attachPSU, attachTerminal, attachReach, familyRemainingA) Then
                        GoTo NextBus1Row
                    End If
                    'V5.2.0: an existing same-root BUS-1 PSU that cannot accept
                    'the row after a reach/capacity break is not fatal. Continue
                    'to a new PSU so the estimator never stops solely because a
                    'previous family PSU has reached its physical/electrical limit.

                    isNewSpanSeq = (mm > 0# And Not spanSeen.Exists(k))
                    If isNewSpanSeq Then
                        projectedMM = mod22_PSUTerminalAllocator.PSUTerm_ProjectCenteredSpanMM(spanCount, runMM, lastSpanML, mm)
                        terminalLengthContributionMM = projectedMM - runMM
                    Else
                        projectedMM = runMM
                        terminalLengthContributionMM = 0#
                    End If
                    deviceReachMM = projectedMM
                    termIdx = mod22_PSUTerminalAllocator.PSUTerm_FindTerminal(termLoad, termLengthMM, amps, terminalLengthContributionMM)
                End If

                If Not started Then
                    started = True
                    startSeq = seq
                    areaNum = TextAt2A(ws, r, cArea)
                    swg = TextAt2A(ws, r, cSwg)
                    panel = TextAt2A(ws, r, cPanel)
                    psuName = NextPSUName2A(outWs, outRow, BaseSequenceKey2A(startSeq), "BUS-1")
                End If

                endSeq = seq
                lastFlowKey = flowKey
                runA = runA + amps
                If isNewSpanSeq Then
                    mod22_PSUTerminalAllocator.PSUTerm_AcceptCenteredSpan spanCount, runMM, lastSpanML, mm
                    spanSeen(k) = True
                    deviceReachMM = runMM
                End If
                If Not ctlSeen.Exists(k) Then
                    ctlSeen(k) = True
                    runCtl = runCtl + 1
                    AppendSequence2A runSeqList, seq
                End If

                deviceLabel = PowerRecordLabel2A(seq, b)
                forceClose = False
                If termIdx > 0 Then
                    terminalName = mod22_PSUTerminalAllocator.PSUTerm_TerminalName(termIdx)
                    mod22_PSUTerminalAllocator.PSUTerm_Reserve termLoad, termLengthMM, termSeq, termIdx, amps, terminalLengthContributionMM, deviceLabel
                    AppendText2A terminalAssignments, deviceLabel & "=" & terminalName, "; "
                Else
                    terminalName = "MISSING"
                    AppendText2A terminalAssignments, deviceLabel & "=MISSING", "; "
                    AddAutoSplitWarning2A "BUS-1", seq, baseSeq, psuName, _
                                          "Device cannot fit an available 20 A / 20 ft terminal; recorded MISSING and continued"
                    forceClose = True
                End If

                termRows.Add Array(psuName, seq, b, "BUS-1", terminalName, Round(amps, 2), Round(deviceReachMM, 0), _
                                   rawML, rawZL, areaNum, swg, panel, _
                                   IIf(termIdx > 0, "OK", "DEVICE OVER 20A / 20FT TERMINAL CAPACITY LIMIT"))

                If forceClose Then
                    FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Power Bus 1", "BUS-1", _
                                "Device exceeds terminal 20 A / 20 ft capacity", runCtl, runSeqList, areaNum, swg, panel, _
                                psuName, termSeq, terminalAssignments
                    grp = grp + 1
                    ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                       terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                       spanSeen, spanCount, lastSpanML
                End If
            End If
        End If
NextBus1Row:
    Next r

    If started Then
        FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Power Bus 1", "BUS-1", _
                    "End of SIS_TAG_PD5", runCtl, runSeqList, areaNum, swg, panel, psuName, termSeq, terminalAssignments
    End If
End Sub

Private Sub BuildBus22A(ByVal ws As Worksheet, ByVal outWs As Worksheet, ByVal lr As Long, ByRef outRow As Long, _
                        ByVal cBlock As Long, ByVal cType As Long, ByVal cSeq As Long, ByVal cLPN As Long, _
                        ByVal cLen As Long, ByVal cZL As Long, ByVal cQtyDrv As Long, ByVal cPower As Long, _
                        ByVal cVolt As Long, ByVal cSensors As Long, ByVal cSys As Long, ByVal cArea As Long, _
                        ByVal cSwg As Long, ByVal cPanel As Long, ByVal cX As Long, ByVal cY As Long, _
                        ByVal cZ As Long, ByVal termRows As Collection)

    Dim hasTypedDevice As Object, fallback As Object
    Dim r As Long, k As String, typ As String
    Dim fallbackAmps As Double

    Set hasTypedDevice = Dict2A()
    Set fallback = Dict2A()

    'A DATA_POWER-configured TYPE row is the authoritative physical BUS-2 device.
    'The conveyor/parent row is only a fallback when no configured device TYPE
    'exists for that SIS sequence. This prevents VFD parent + MOT/VFD double count.
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.BuildBus22A [L473]" & " row " & CStr(r)
        k = DeviceKey2A(ws, r, cSeq, cLPN)
        If k <> "" Then
            typ = NormalizeDeviceType2A(TextAt2A(ws, r, cType))

            If typ <> "" And Not mBus2LoadByType Is Nothing Then
                If mBus2LoadByType.Exists(typ) Then
                    hasTypedDevice(k) = True
                End If
            End If

            If Not fallback.Exists(k) Then
                fallbackAmps = OriginalBus2Amps2A(ws, r, cQtyDrv, cPower, cVolt, cSensors, cSys)
                If fallbackAmps > 0# Then fallback(k) = r
            End If
        End If
    Next r

    BuildBus2FromRows2A ws, outWs, lr, outRow, hasTypedDevice, fallback, _
                        cBlock, cType, cSeq, cLPN, cLen, cZL, cQtyDrv, cPower, cVolt, _
                        cSensors, cSys, cArea, cSwg, cPanel, cX, cY, cZ, termRows
End Sub

Private Sub BuildBus2FromRows2A(ByVal ws As Worksheet, ByVal outWs As Worksheet, ByVal lr As Long, ByRef outRow As Long, _
                                ByVal hasTypedDevice As Object, ByVal fallback As Object, _
                                ByVal cBlock As Long, ByVal cType As Long, ByVal cSeq As Long, ByVal cLPN As Long, _
                                ByVal cLen As Long, ByVal cZL As Long, ByVal cQtyDrv As Long, ByVal cPower As Long, _
                                ByVal cVolt As Long, ByVal cSensors As Long, ByVal cSys As Long, ByVal cArea As Long, _
                                ByVal cSwg As Long, ByVal cPanel As Long, ByVal cX As Long, ByVal cY As Long, _
                                ByVal cZ As Long, ByVal termRows As Collection)

    Dim ctlSeen As Object, spanSeen As Object
    Dim r As Long, k As String, b As String, typ As String
    Dim amps As Double, mm As Double, seq As String, rawML As Variant, rawZL As Variant, mlMM As Double
    Dim useRow As Boolean, includeRecord As Boolean
    Dim runA As Double, runMM As Double, grp As Long, runCtl As Long
    Dim startSeq As String, endSeq As String, reason As String, started As Boolean
    Dim flowKey As String, lastFlowKey As String, runSeqList As String
    Dim termLoad(1 To 4) As Double, termLengthMM(1 To 4) As Double, termSeq(1 To 4) As String
    Dim termIdx As Long, terminalName As String, terminalAssignments As String, forceClose As Boolean
    Dim areaNum As String, swg As String, panel As String, psuName As String, deviceLabel As String
    Dim spanCount As Long, lastSpanML As Double, projectedMM As Double, deviceReachMM As Double
    Dim terminalLengthContributionMM As Double
    Dim isNewSpanSeq As Boolean
    Dim isRIO As Boolean, isPointVFD As Boolean, isPointDevice As Boolean
    Dim specialMode As String
    Dim anchorX As Double, anchorY As Double, anchorZ As Double, anchorValid As Boolean
    Dim curX As Double, curY As Double, curZ As Double, curXYZValid As Boolean
    Dim lastSpecialSeqNum As Double, currentSeqNum As Double, lastSpecialML As Double
    Dim canShare As Boolean, attachTerminal As String, attachPSU As String
    Dim attachReach As Double
    Dim baseSeq As String, sameBaseActive As Boolean, baseGroupFound As Boolean
    Dim familyRemainingA As Double, familyRowCount As Long
    Dim familyPoweredRows As Collection
    Dim activeReach As Double, activeReachValid As Boolean

    Set ctlSeen = Dict2A()
    Set spanSeen = Dict2A()
    grp = 1
    mod22_PSUTerminalAllocator.PSUTerm_ResetState termLoad, termLengthMM, termSeq

    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.BuildBus2FromRows2A [L534]" & " row " & CStr(r)
        k = DeviceKey2A(ws, r, cSeq, cLPN)
        b = BlockKey2A(ws.Cells(r, cBlock).Value)
        typ = NormalizeDeviceType2A(TextAt2A(ws, r, cType))
        amps = 0#
        useRow = False

        If k <> "" Then
            If hasTypedDevice.Exists(k) Then
                If typ <> "" And mBus2LoadByType.Exists(typ) Then
                    useRow = True
                    amps = Bus2AmpsForDeviceRow2A(ws, r, cType, cBlock, cQtyDrv, cPower, cVolt, cSensors, cSys)
                End If
            ElseIf fallback.Exists(k) Then
                useRow = (CLng(fallback(k)) = r)
                If useRow Then
                    amps = OriginalBus2Amps2A(ws, r, cQtyDrv, cPower, cVolt, cSensors, cSys)
                End If
            End If

            If useRow And IsVFDDeviceRow2A(ws, r, cType, cBlock, cSys, cVolt) And amps <= 0# Then
                Err.Raise vbObjectError + 2468, , _
                          "VFD BUS-2 load was not counted for SIS_SEQUENCE '" & _
                          SourceSeq2A(ws, r, cSeq, cLPN) & "'." & vbCrLf & _
                          "TYPE='" & TextAt2A(ws, r, cType) & "', BLOCK_NAME='" & _
                          TextAt2A(ws, r, cBlock) & "'." & vbCrLf & _
                          "DATA_POWER must contain the matching Type with a positive Bus-2 load."
            End If
        End If

        If Not useRow Then GoTo NextBus2Row
        If amps <= 0# Then GoTo NextBus2Row

        seq = SourceSeq2A(ws, r, cSeq, cLPN)
        rawML = ValueAt2A(ws, r, cLen)
        rawZL = ValueAt2A(ws, r, cZL)
        mlMM = mod22_PSUTerminalAllocator.PSUTerm_LengthValueMM(rawML)
        flowKey = FlowSortKeyAtRow2A(ws, r)
        curXYZValid = XYZAtRow2A(ws, r, cX, cY, cZ, curX, curY, curZ)
        currentSeqNum = SequenceNumber2A(seq)
        baseSeq = BaseSequenceKey2A(seq)
        sameBaseActive = (started And SequenceListHasBase2A(runSeqList, baseSeq))

        isRIO = (typ = "RIO")
        isPointVFD = IsSpecialVFDPoint2A(ws, r, cType, cBlock, cSys, cVolt, mlMM)
        isPointDevice = (isRIO Or isPointVFD)

        'V5.2.0 atomic-family reservation. Reserve all still-unprocessed members
        'of this normalized root family before assigning its first row.
        familyRemainingA = Bus2FamilyRemainingAmps2A(ws, r, lr, baseSeq, hasTypedDevice, fallback, _
                                                     cBlock, cType, cSeq, cLPN, cQtyDrv, cPower, cVolt, cSensors, cSys)
        Set familyPoweredRows = Bus2FamilyPoweredRows2A(ws, r, lr, baseSeq, hasTypedDevice, fallback, _
                                                       cBlock, cType, cSeq, cLPN, cQtyDrv, cPower, cVolt, cSensors, cSys)
        familyRowCount = familyPoweredRows.count

        'V5.2.0: a normalized family is allowed to span multiple PSUs.
        'The complete family may exceed 40 A; allocation below will split it
        'without treating the shared SIS root as a fatal restriction.

        'V5.2.0: a multi-row root/suffix family is evaluated as one placement.
        'Close the current unrelated active group first, then let the existing-PSU
        'search decide whether that just-closed PSU (or any other nearby PSU) can
        'accept the COMPLETE family. If not, the family starts on a new PSU.
        'This prevents the parent from being attached to an almost-valid PSU and
        'the child later failing the same-root restriction.
        If started And Not sameBaseActive And familyRowCount > 1 Then
            FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                        "Atomic placement check before power family " & baseSeq, _
                        runCtl, runSeqList, areaNum, swg, panel, psuName, termSeq, terminalAssignments
            grp = grp + 1
            ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                               terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                               spanSeen, spanCount, lastSpanML
            ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
            sameBaseActive = False
        End If

        If started And Not sameBaseActive Then
            If runA + familyRemainingA > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitA() Then
                FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                            "Closed early so power family " & baseSeq & " starts together on a new PSU", _
                            runCtl, runSeqList, areaNum, swg, panel, psuName, termSeq, terminalAssignments
                grp = grp + 1
                ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                   terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                   spanSeen, spanCount, lastSpanML
                ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
                sameBaseActive = False
            End If
        End If

        'A normal conveyor group must be closed before an electrical point-device
        'group starts. Point-device groups are also isolated from one another
        'when their sharing rules are not met.
        If started Then
            'Root/suffix family rule has first priority. If the active PSU already
            'contains 1270, rows such as 1270-01A/1270-01B remain on that PSU even
            'when their flow key or point-device sequence-gap rule would split.
            If sameBaseActive Then
                'Keep the active group open. Hard current/reach/terminal limits
                'are still checked below.
            ElseIf isPointVFD Then
                If specialMode <> "VFDPOINT" Then
                    FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                                "Dedicated VFD point-device PSU", runCtl, runSeqList, areaNum, swg, panel, psuName, _
                                termSeq, terminalAssignments
                    grp = grp + 1
                    ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                       terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                       spanSeen, spanCount, lastSpanML
                    ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
                Else
                    canShare = SpecialPointCanShare2A("VFDPOINT", areaNum, TextAt2A(ws, r, cArea), _
                                                      anchorValid, anchorX, anchorY, anchorZ, curXYZValid, curX, curY, curZ, _
                                                      lastSpecialSeqNum, currentSeqNum, lastSpecialML, mlMM)
                    If Not canShare Then
                        FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                                    "VFD point-device spacing/sequence rule", runCtl, runSeqList, areaNum, swg, panel, psuName, _
                                    termSeq, terminalAssignments
                        grp = grp + 1
                        ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                           terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                           spanSeen, spanCount, lastSpanML
                        ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
                    End If
                End If

            ElseIf isRIO Then
                If specialMode <> "RIO" Then
                    FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                                "RIO point-device processing", runCtl, runSeqList, areaNum, swg, panel, psuName, _
                                termSeq, terminalAssignments
                    grp = grp + 1
                    ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                       terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                       spanSeen, spanCount, lastSpanML
                    ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
                Else
                    canShare = SpecialPointCanShare2A("RIO", areaNum, TextAt2A(ws, r, cArea), _
                                                      anchorValid, anchorX, anchorY, anchorZ, curXYZValid, curX, curY, curZ, _
                                                      lastSpecialSeqNum, currentSeqNum, lastSpecialML, mlMM)
                    If Not canShare Then
                        FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                                    "RIO spacing/sequence rule", runCtl, runSeqList, areaNum, swg, panel, psuName, _
                                    termSeq, terminalAssignments
                        grp = grp + 1
                        ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                           terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                           spanSeen, spanCount, lastSpanML
                        ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
                    End If
                End If

            Else
                If specialMode <> "" Then
                    FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                                "End of point-device PSU group", runCtl, runSeqList, areaNum, swg, panel, psuName, _
                                termSeq, terminalAssignments
                    grp = grp + 1
                    ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                       terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                       spanSeen, spanCount, lastSpanML
                    ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML

                ElseIf Not FlowContinues2A(lastFlowKey, flowKey) Then
                    FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                                "Flow branch / new conveyor path", runCtl, runSeqList, areaNum, swg, panel, psuName, _
                                termSeq, terminalAssignments
                    grp = grp + 1
                    ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                                       terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                                       spanSeen, spanCount, lastSpanML
                End If
            End If
        End If

        'Before creating a new BUS-2 PSU, always try to reuse an existing PSU.
        'Priority 1 = exact power-family/root match (1270 and 1270-01A).
        'Priority 2 = nearest physically available PSU using XYZ, regardless of
        'the +/-20 sequence-gap rule. Only an electrically available PSU is used.
        If Not started Then
            baseGroupFound = False
            attachTerminal = vbNullString
            attachPSU = vbNullString
            attachReach = 0#

            If TryAttachToExistingBusGroup2A(ws, outWs, outRow, lr, r, cBlock, cSeq, cLPN, _
                                             cLen, cZL, cArea, cSwg, cPanel, cX, cY, cZ, _
                                             amps, "Logic Bus 2", "BUS-2", True, termRows, _
                                             baseGroupFound, attachPSU, attachTerminal, attachReach, familyRemainingA, familyPoweredRows) Then
                GoTo NextBus2Row
            End If

            'V5.2.0: finding the same-root PSU is not a reason to fail.
            'If that existing PSU cannot accept the COMPLETE remaining family,
            'continue to the proximity search and then start a new family PSU.
            'The first family row was not committed to the rejected PSU.

            If curXYZValid Then
                If TryAttachToExistingBusGroup2A(ws, outWs, outRow, lr, r, cBlock, cSeq, cLPN, _
                                                 cLen, cZL, cArea, cSwg, cPanel, cX, cY, cZ, _
                                                 amps, "Logic Bus 2", "BUS-2", False, termRows, _
                                                 baseGroupFound, attachPSU, attachTerminal, attachReach, familyRemainingA, familyPoweredRows) Then
                    GoTo NextBus2Row
                End If
            End If
        End If

        If isPointDevice Then
            includeRecord = True
            mm = 0#

            activeReach = 0#
            activeReachValid = False

            If started And curXYZValid Then
                If anchorValid Then
                    activeReach = Distance3D2A(anchorX, anchorY, anchorZ, curX, curY, curZ)
                    activeReachValid = True
                Else
                    activeReachValid = TryDistanceFromSequenceAnchor2A(ws, lr, startSeq, cSeq, cLPN, _
                                                                      cX, cY, cZ, curX, curY, curZ, activeReach)
                End If
            End If

            If activeReachValid Then
                projectedMM = activeReach
                terminalLengthContributionMM = projectedMM
            Else
                projectedMM = 0#
                terminalLengthContributionMM = 0#
            End If

            deviceReachMM = projectedMM
            isNewSpanSeq = False
        Else
            mm = mod22_PSUTerminalAllocator.PSUTerm_BusLengthMM("BUS-2", b, rawML, includeRecord)
            If Not includeRecord Then GoTo NextBus2Row

            If sameBaseActive Then
                isNewSpanSeq = False
            Else
                isNewSpanSeq = (mm > 0# And Not spanSeen.Exists(k))
            End If
            If isNewSpanSeq Then
                projectedMM = mod22_PSUTerminalAllocator.PSUTerm_ProjectCenteredSpanMM(spanCount, runMM, lastSpanML, mm)
                terminalLengthContributionMM = projectedMM - runMM
            Else
                projectedMM = runMM
                terminalLengthContributionMM = 0#
            End If
            deviceReachMM = projectedMM
        End If

        termIdx = mod22_PSUTerminalAllocator.PSUTerm_FindTerminal(termLoad, termLengthMM, amps, terminalLengthContributionMM)
        reason = vbNullString

        If started Then
            If runA + amps > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitA() Then
                reason = "Stopped before exceeding 40 A"
            ElseIf projectedMM > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitMM() Then
                reason = "Stopped before exceeding 10668 mm [35FT] BUS-2 reach"
            ElseIf termIdx = 0 Then
                reason = "Stopped before exceeding terminal 20 A / 20 ft capacity"
            End If
        End If

        If Len(reason) > 0 Then
            AddAutoSplitWarning2A "BUS-2", seq, baseSeq, psuName, reason
            reason = "WARNING - " & reason & "; current PSU closed and device continued on another/new PSU"

            FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                        reason, runCtl, runSeqList, areaNum, swg, panel, psuName, termSeq, terminalAssignments
            grp = grp + 1
            ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                               terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                               spanSeen, spanCount, lastSpanML
            ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
            sameBaseActive = False

            'A capacity/reach split is not permission to create a new PSU yet.
            'First reuse a completed root-family PSU, then the nearest physically
            'available PSU. Only if neither can accept the device is a new PSU
            'allowed to start.
            baseGroupFound = False
            attachTerminal = vbNullString
            attachPSU = vbNullString
            attachReach = 0#

            If TryAttachToExistingBusGroup2A(ws, outWs, outRow, lr, r, cBlock, cSeq, cLPN, _
                                             cLen, cZL, cArea, cSwg, cPanel, cX, cY, cZ, _
                                             amps, "Logic Bus 2", "BUS-2", True, termRows, _
                                             baseGroupFound, attachPSU, attachTerminal, attachReach, familyRemainingA, familyPoweredRows) Then
                GoTo NextBus2Row
            End If

            'V5.2.0: do not stop merely because a previously completed
            'same-root PSU is unavailable. Reuse another valid nearby PSU when
            'possible; otherwise allow a new PSU to be started for this family.

            If curXYZValid Then
                If TryAttachToExistingBusGroup2A(ws, outWs, outRow, lr, r, cBlock, cSeq, cLPN, _
                                                 cLen, cZL, cArea, cSwg, cPanel, cX, cY, cZ, _
                                                 amps, "Logic Bus 2", "BUS-2", False, termRows, _
                                                 baseGroupFound, attachPSU, attachTerminal, attachReach, familyRemainingA, familyPoweredRows) Then
                    GoTo NextBus2Row
                End If
            End If

            If isPointDevice Then
                projectedMM = 0#
                terminalLengthContributionMM = 0#
                deviceReachMM = 0#
                termIdx = mod22_PSUTerminalAllocator.PSUTerm_FindTerminal(termLoad, termLengthMM, amps, 0#)
            Else
                isNewSpanSeq = (mm > 0# And Not spanSeen.Exists(k))
                If isNewSpanSeq Then
                    projectedMM = mod22_PSUTerminalAllocator.PSUTerm_ProjectCenteredSpanMM(spanCount, runMM, lastSpanML, mm)
                    terminalLengthContributionMM = projectedMM - runMM
                Else
                    projectedMM = runMM
                    terminalLengthContributionMM = 0#
                End If
                deviceReachMM = projectedMM
                termIdx = mod22_PSUTerminalAllocator.PSUTerm_FindTerminal(termLoad, termLengthMM, amps, terminalLengthContributionMM)
            End If
        End If

        If Not started Then
            started = True
            startSeq = seq
            areaNum = TextAt2A(ws, r, cArea)
            swg = TextAt2A(ws, r, cSwg)
            panel = TextAt2A(ws, r, cPanel)
            psuName = NextPSUName2A(outWs, outRow, BaseSequenceKey2A(startSeq), "BUS-2")

            If isPointVFD Then
                specialMode = "VFDPOINT"
            ElseIf isRIO Then
                specialMode = "RIO"
            Else
                specialMode = vbNullString
            End If

            If isPointDevice And curXYZValid Then
                anchorX = curX: anchorY = curY: anchorZ = curZ: anchorValid = True
            Else
                anchorValid = False
            End If

            'Keep the first point-device sequence/ML as the group anchor.
            'This prevents chained 20-digit hops (1005 -> 1025 -> 1045) from
            'silently growing a group beyond 20 digits from its first device.
            If isPointDevice Then
                lastSpecialSeqNum = currentSeqNum
                lastSpecialML = mlMM
            End If
        End If

        endSeq = seq
        lastFlowKey = flowKey
        runA = runA + amps

        If isPointDevice Then
            If projectedMM > runMM Then runMM = projectedMM
        ElseIf isNewSpanSeq Then
            mod22_PSUTerminalAllocator.PSUTerm_AcceptCenteredSpan spanCount, runMM, lastSpanML, mm
            spanSeen(k) = True
            deviceReachMM = runMM
        End If

        If Not ctlSeen.Exists(k) Then
            ctlSeen(k) = True
            runCtl = runCtl + 1
            AppendSequence2A runSeqList, seq
        End If

        deviceLabel = PowerRecordLabel2A(seq, b)
        forceClose = False

        If termIdx > 0 Then
            terminalName = mod22_PSUTerminalAllocator.PSUTerm_TerminalName(termIdx)
            mod22_PSUTerminalAllocator.PSUTerm_Reserve termLoad, termLengthMM, termSeq, termIdx, amps, terminalLengthContributionMM, deviceLabel
            AppendText2A terminalAssignments, deviceLabel & "=" & terminalName, "; "
        Else
            terminalName = "MISSING"
            AppendText2A terminalAssignments, deviceLabel & "=MISSING", "; "
            AddAutoSplitWarning2A "BUS-2", seq, baseSeq, psuName, _
                                  "Device cannot fit an available 20 A / 20 ft terminal; recorded MISSING and continued"
            forceClose = True
        End If

        termRows.Add Array(psuName, seq, b, "BUS-2", terminalName, Round(amps, 2), Round(deviceReachMM, 0), _
                           rawML, rawZL, areaNum, swg, panel, _
                           IIf(termIdx > 0, "OK", "DEVICE OVER 20A / 20FT TERMINAL CAPACITY LIMIT"))

        If forceClose Then
            FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                        "Device exceeds terminal 20 A / 20 ft capacity", runCtl, runSeqList, areaNum, swg, panel, _
                        psuName, termSeq, terminalAssignments
            grp = grp + 1
            ResetPowerGroup2A started, runA, runMM, runCtl, startSeq, endSeq, runSeqList, _
                               terminalAssignments, termLoad, termLengthMM, termSeq, ctlSeen, _
                               spanSeen, spanCount, lastSpanML
            ResetSpecialState2A specialMode, anchorValid, anchorX, anchorY, anchorZ, lastSpecialSeqNum, lastSpecialML
        End If

NextBus2Row:
    Next r

    If started Then
        FlushBus2A outWs, outRow, grp, startSeq, endSeq, runA, runMM, "Logic Bus 2", "BUS-2", _
                    "End of SIS_TAG_PD5", runCtl, runSeqList, areaNum, swg, panel, psuName, termSeq, terminalAssignments
    End If
End Sub


Private Function IsSpecialVFDPoint2A(ByVal ws As Worksheet, ByVal r As Long, _
                                           ByVal cType As Long, ByVal cBlock As Long, _
                                           ByVal cSys As Long, ByVal cVolt As Long, _
                                           ByVal mlMM As Double) As Boolean
    If Not IsVFDDeviceRow2A(ws, r, cType, cBlock, cSys, cVolt) Then Exit Function

    'Electrical-only VFD points in SIS_TAG_EXPORT often have blank ML.
    'Blank/zero ML cannot be evaluated by the conveyor center-span engine, so it
    'uses the same XYZ rule as an explicit Module Length below 10 mm.
    IsSpecialVFDPoint2A = (mlMM < 10#)
End Function

Private Sub ResetSpecialState2A(ByRef specialMode As String, ByRef anchorValid As Boolean, _
                                ByRef anchorX As Double, ByRef anchorY As Double, ByRef anchorZ As Double, _
                                ByRef lastSeqNum As Double, ByRef lastML As Double)
    specialMode = vbNullString
    anchorValid = False
    anchorX = 0#: anchorY = 0#: anchorZ = 0#
    lastSeqNum = 0#
    lastML = 0#
End Sub

Private Function SpecialPointCanShare2A(ByVal modeName As String, _
                                        ByVal groupArea As String, ByVal rowArea As String, _
                                        ByVal anchorValid As Boolean, ByVal anchorX As Double, _
                                        ByVal anchorY As Double, ByVal anchorZ As Double, _
                                        ByVal curValid As Boolean, ByVal curX As Double, _
                                        ByVal curY As Double, ByVal curZ As Double, _
                                        ByVal lastSeqNum As Double, ByVal curSeqNum As Double, _
                                        ByVal lastML As Double, ByVal curML As Double) As Boolean
    Dim reachMM As Double, seqNear As Boolean, sameML As Boolean

    If Not AreasCompatible2A(groupArea, rowArea) Then Exit Function
    If Not anchorValid Or Not curValid Then Exit Function

    reachMM = Distance3D2A(anchorX, anchorY, anchorZ, curX, curY, curZ)
    If reachMM > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitMM() Then Exit Function

    'Physical availability outranks the sequence-number gap. If the device is
    'within one terminal cable reach of the active PSU, keep it on that PSU even
    'when the SIS sequence difference is greater than 20. The terminal allocator
    'still performs the final 20 A / 20 ft capacity check.
    If reachMM <= mod22_PSUTerminalAllocator.PSUTerm_TerminalLimitMM() Then
        SpecialPointCanShare2A = True
        Exit Function
    End If

    seqNear = SequenceNumbersNear2A(lastSeqNum, curSeqNum, 20#)

    If UCase$(modeName) = "RIO" Then
        SpecialPointCanShare2A = seqNear
    Else
        sameML = (lastML > 0# And curML > 0# And Abs(lastML - curML) <= 0.01)
        SpecialPointCanShare2A = (sameML Or seqNear)
    End If
End Function

Private Function AreasCompatible2A(ByVal a As String, ByVal b As String) As Boolean
    a = UCase$(Trim$(a)): b = UCase$(Trim$(b))
    If a = "" Or b = "" Then
        AreasCompatible2A = True
    Else
        AreasCompatible2A = (a = b)
    End If
End Function

Private Function SequenceNumbersNear2A(ByVal a As Double, ByVal b As Double, ByVal maxGap As Double) As Boolean
    If a <= 0# Or b <= 0# Then Exit Function
    SequenceNumbersNear2A = (Abs(a - b) <= maxGap)
End Function

Private Function SequenceNumber2A(ByVal seq As String) As Double
    Dim s As String, i As Long, ch As String, digits As String
    s = Trim$(seq)

    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            digits = digits & ch
        ElseIf Len(digits) > 0 Then
            Exit For
        End If
    Next i

    If Len(digits) > 0 Then SequenceNumber2A = CDbl(digits)
End Function

Private Function BaseSequenceKey2A(ByVal seq As String) As String
    Dim s As String, p As Long, prefix As String
    s = UCase$(Replace$(Trim$(seq), " ", ""))

    'Power-family normalization:
    '  1270       -> 1270
    '  1270-01A   -> 1270
    '  1270-RIO   -> 1270
    '  1270-VFD   -> 1270
    'Only strip at the first hyphen when the leading token is a numeric SIS
    'sequence. Non-numeric compound identifiers are preserved as-is.
    p = InStr(1, s, "-", vbBinaryCompare)
    If p > 1 Then
        prefix = Left$(s, p - 1)
        If Len(prefix) >= 3 And IsNumeric(prefix) Then s = prefix
    End If

    BaseSequenceKey2A = s
End Function

Private Function TryDistanceFromSequenceAnchor2A(ByVal ws As Worksheet, ByVal lr As Long, _
                                                 ByVal anchorSeq As String, ByVal cSeq As Long, ByVal cLPN As Long, _
                                                 ByVal cX As Long, ByVal cY As Long, ByVal cZ As Long, _
                                                 ByVal curX As Double, ByVal curY As Double, ByVal curZ As Double, _
                                                 ByRef reachMM As Double) As Boolean
    Dim anchorRow As Long
    Dim x1 As Double, y1 As Double, z1 As Double

    anchorRow = FindPD5RowBySequence2A(ws, lr, anchorSeq, cSeq, cLPN)
    If anchorRow = 0 Then anchorRow = FindPD5RowByBaseSequence2A(ws, lr, BaseSequenceKey2A(anchorSeq), cSeq, cLPN)
    If anchorRow = 0 Then Exit Function

    If Not XYZAtRow2A(ws, anchorRow, cX, cY, cZ, x1, y1, z1) Then Exit Function

    reachMM = Distance3D2A(x1, y1, z1, curX, curY, curZ)
    TryDistanceFromSequenceAnchor2A = True
End Function

Private Function XYZAtRow2A(ByVal ws As Worksheet, ByVal r As Long, _
                            ByVal cX As Long, ByVal cY As Long, ByVal cZ As Long, _
                            ByRef x As Double, ByRef y As Double, ByRef z As Double) As Boolean
    If cX <= 0 Or cY <= 0 Or cZ <= 0 Then Exit Function
    If Not IsNumeric(ws.Cells(r, cX).Value) Then Exit Function
    If Not IsNumeric(ws.Cells(r, cY).Value) Then Exit Function
    If Not IsNumeric(ws.Cells(r, cZ).Value) Then Exit Function

    x = CDbl(ws.Cells(r, cX).Value)
    y = CDbl(ws.Cells(r, cY).Value)
    z = CDbl(ws.Cells(r, cZ).Value)
    XYZAtRow2A = True
End Function

Private Function Distance3D2A(ByVal x1 As Double, ByVal y1 As Double, ByVal z1 As Double, _
                              ByVal x2 As Double, ByVal y2 As Double, ByVal z2 As Double) As Double
    Distance3D2A = Sqr((x2 - x1) ^ 2 + (y2 - y1) ^ 2 + (z2 - z1) ^ 2)
End Function

Private Function FindPD5RowBySequence2A(ByVal ws As Worksheet, ByVal lr As Long, _
                                        ByVal wantedSeq As String, ByVal cSeq As Long, ByVal cLPN As Long) As Long
    Dim r As Long, s As String
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.FindPD5RowBySequence2A [L1098]" & " row " & CStr(r)
        s = SourceSeq2A(ws, r, cSeq, cLPN)
        If StrComp(Trim$(s), Trim$(wantedSeq), vbTextCompare) = 0 Then
            FindPD5RowBySequence2A = r
            Exit Function
        End If
    Next r
End Function

Private Function FindPD5RowByBaseSequence2A(ByVal ws As Worksheet, ByVal lr As Long, _
                                            ByVal wantedBase As String, ByVal cSeq As Long, ByVal cLPN As Long) As Long
    Dim r As Long, s As String
    wantedBase = BaseSequenceKey2A(wantedBase)
    If wantedBase = "" Then Exit Function

    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.FindPD5RowByBaseSequence2A [L1113]" & " row " & CStr(r)
        s = BaseSequenceKey2A(SourceSeq2A(ws, r, cSeq, cLPN))
        If StrComp(s, wantedBase, vbTextCompare) = 0 Then
            FindPD5RowByBaseSequence2A = r
            Exit Function
        End If
    Next r
End Function

Private Function SequenceListHasExact2A(ByVal listText As String, ByVal wantedSeq As String) As Boolean
    Dim parts As Variant, i As Long
    wantedSeq = UCase$(Replace$(Trim$(wantedSeq), " ", ""))
    If wantedSeq = "" Then Exit Function

    parts = Split(listText, ",")
    For i = LBound(parts) To UBound(parts)
        If UCase$(Replace$(Trim$(CStr(parts(i))), " ", "")) = wantedSeq Then
            SequenceListHasExact2A = True
            Exit Function
        End If
    Next i
End Function

Private Function SequenceListHasBase2A(ByVal listText As String, ByVal wantedBase As String) As Boolean
    Dim parts As Variant, i As Long, oneSeq As String
    wantedBase = UCase$(Trim$(wantedBase))
    If wantedBase = "" Then Exit Function

    parts = Split(listText, ",")
    For i = LBound(parts) To UBound(parts)
        oneSeq = BaseSequenceKey2A(CStr(parts(i)))
        If StrComp(oneSeq, wantedBase, vbTextCompare) = 0 Then
            SequenceListHasBase2A = True
            Exit Function
        End If
    Next i
End Function

Private Function TryAttachToExistingBusGroup2A(ByVal ws As Worksheet, ByVal bus As Worksheet, _
                                                   ByVal nextBusRow As Long, ByVal lr As Long, ByVal deviceRow As Long, _
                                                   ByVal cBlock As Long, ByVal cSeq As Long, ByVal cLPN As Long, _
                                                   ByVal cLen As Long, ByVal cZL As Long, _
                                                   ByVal cArea As Long, ByVal cSwg As Long, ByVal cPanel As Long, _
                                                   ByVal cX As Long, ByVal cY As Long, ByVal cZ As Long, _
                                                   ByVal amps As Double, ByVal busName As String, ByVal busCode As String, _
                                                   ByVal requireSameBase As Boolean, ByVal termRows As Collection, _
                                                   ByRef matchingBaseFound As Boolean, _
                                                   ByRef attachedPSU As String, ByRef attachedTerminal As String, _
                                                   ByRef attachedReachMM As Double, _
                                                   Optional ByVal capacityReservationA As Double = -1#, _
                                                   Optional ByVal familyRows As Variant) As Boolean
    Dim br As Long, i As Long, anchorRow As Long, emptyTerm As Long
    Dim seq As String, baseSeq As String, src As String, b As String, label As String
    Dim curArea As String, busArea As String, seqList As String
    Dim x1 As Double, y1 As Double, z1 As Double, x2 As Double, y2 As Double, z2 As Double
    Dim curXYZValid As Boolean, anchorXYZValid As Boolean
    Dim loadNow As Double, terminalName As String, reachMM As Double
    Dim bestRow As Long, bestTerm As Long, bestReach As Double, bestHasReach As Boolean
    Dim candidateBaseMatch As Boolean, capacityOK As Boolean, reachOK As Boolean
    Dim capacityTestA As Double
    Dim seqListTmp As String, assignmentTmp As String
    Dim rawML As Variant, rawZL As Variant, statusText As String
    Dim isNewSequence As Boolean
    Dim famRows As Collection, famItem As Variant, famRow As Long
    Dim emptyCount As Long, famArea As String
    Dim fx As Double, fy As Double, fz As Double, famReach As Double
    Dim famXYZValid As Boolean, familyCandidateOK As Boolean

    matchingBaseFound = False
    attachedPSU = vbNullString
    attachedTerminal = vbNullString
    attachedReachMM = 0#

    seq = SourceSeq2A(ws, deviceRow, cSeq, cLPN)
    baseSeq = BaseSequenceKey2A(seq)
    If baseSeq = "" Then Exit Function

    curArea = TextAt2A(ws, deviceRow, cArea)
    b = BlockKey2A(ws.Cells(deviceRow, cBlock).Value)
    label = PowerRecordLabel2A(seq, b)
    rawML = ValueAt2A(ws, deviceRow, cLen)
    rawZL = ValueAt2A(ws, deviceRow, cZL)

    curXYZValid = XYZAtRow2A(ws, deviceRow, cX, cY, cZ, x2, y2, z2)
    bestReach = 1E+99

    If IsObject(familyRows) Then
        On Error Resume Next
        Set famRows = familyRows
        On Error GoTo 0
    End If

    For br = 1 To nextBusRow - 1
        PDPerf_Pulse "mod06_EstimatePSU.TryAttachToExistingBusGroup2A [L1205]" & " row " & CStr(br)
        If StrComp(Clean2A(bus.Cells(br, 6).Value), busName, vbTextCompare) = 0 And _
           StrComp(Clean2A(bus.Cells(br, 14).Value), busCode, vbTextCompare) = 0 Then

            seqList = CStr(bus.Cells(br, 10).Value2)
            candidateBaseMatch = SequenceListHasBase2A(seqList, baseSeq)

            If requireSameBase Then
                If Not candidateBaseMatch Then GoTo NextCandidate
                matchingBaseFound = True
            End If

            busArea = Clean2A(bus.Cells(br, 11).Value)
            If Not AreasCompatible2A(busArea, curArea) Then GoTo NextCandidate

            loadNow = Num2A(bus.Cells(br, 3).Value)
            capacityTestA = amps
            If capacityReservationA > capacityTestA Then capacityTestA = capacityReservationA
            capacityOK = (loadNow + capacityTestA <= mod22_PSUTerminalAllocator.PSUTerm_PsuLimitA())
            If Not capacityOK Then GoTo NextCandidate

            reachMM = 0#
            reachOK = False
            anchorXYZValid = False

            src = StripPSU2A(Clean2A(bus.Cells(br, 5).Value))
            anchorRow = FindPD5RowBySequence2A(ws, lr, src, cSeq, cLPN)
            If anchorRow = 0 Then anchorRow = FindPD5RowByBaseSequence2A(ws, lr, BaseSequenceKey2A(src), cSeq, cLPN)

            If curXYZValid And anchorRow > 0 Then
                If XYZAtRow2A(ws, anchorRow, cX, cY, cZ, x1, y1, z1) Then
                    anchorXYZValid = True
                    reachMM = Distance3D2A(x1, y1, z1, x2, y2, z2)
                End If
            End If

            If requireSameBase Then
                'Same-root rows may lack XYZ because they are logical/electrical
                'children of the same conveyor. When XYZ is present it must still
                'respect the hard PSU/terminal reach.
                If curXYZValid And anchorXYZValid Then
                    reachOK = (reachMM <= mod22_PSUTerminalAllocator.PSUTerm_PsuLimitMM() And _
                               reachMM <= mod22_PSUTerminalAllocator.PSUTerm_TerminalLimitMM())
                Else
                    reachMM = 0#
                    reachOK = True
                End If
            Else
                'General PSU reuse is explicitly physical: both endpoints require
                'XYZ and the device must be reachable by one available terminal.
                If Not curXYZValid Or Not anchorXYZValid Then GoTo NextCandidate
                reachOK = (reachMM <= mod22_PSUTerminalAllocator.PSUTerm_PsuLimitMM() And _
                           reachMM <= mod22_PSUTerminalAllocator.PSUTerm_TerminalLimitMM())
            End If

            If Not reachOK Then GoTo NextCandidate

            emptyTerm = 0
            emptyCount = 0
            For i = 1 To mod22_PSUTerminalAllocator.PSUTerm_TerminalCount()
                If Len(Trim$(CStr(bus.Cells(br, 14 + i).Value2))) = 0 Then
                    emptyCount = emptyCount + 1
                    If emptyTerm = 0 Then emptyTerm = i
                End If
            Next i
            If emptyTerm = 0 Then GoTo NextCandidate

            'V5.2.0 family preflight: do not attach only the parent to an existing
            'PSU unless every still-unprocessed powered member of that root family
            'can also be placed on that SAME PSU. Existing-PSU reuse consumes one
            'open terminal slot per attached row, so reserve the required slots.
            If Not (famRows Is Nothing) Then
                If famRows.count > 1 Then
                    If emptyCount < famRows.count Then GoTo NextCandidate

                    familyCandidateOK = True
                    If StrComp(busCode, "BUS-2", vbTextCompare) = 0 Then
                        For Each famItem In famRows
                            PDPerf_Pulse "mod06_EstimatePSU.TryAttachToExistingBusGroup2A [L1282]"
                            famRow = CLng(famItem)
                            famArea = TextAt2A(ws, famRow, cArea)
                            If Not AreasCompatible2A(busArea, famArea) Then
                                familyCandidateOK = False
                                Exit For
                            End If

                            famXYZValid = XYZAtRow2A(ws, famRow, cX, cY, cZ, fx, fy, fz)

                            If requireSameBase Then
                                'Logical same-root children may have no XYZ. When
                                'coordinates exist, they must be reachable from the
                                'candidate PSU anchor just like the parent.
                                If famXYZValid And anchorXYZValid Then
                                    famReach = Distance3D2A(x1, y1, z1, fx, fy, fz)
                                    If famReach > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitMM() Or _
                                       famReach > mod22_PSUTerminalAllocator.PSUTerm_TerminalLimitMM() Then
                                        familyCandidateOK = False
                                        Exit For
                                    End If
                                End If
                            Else
                                'General XYZ reuse is allowed only when every
                                'powered family member is physically reachable.
                                If Not famXYZValid Or Not anchorXYZValid Then
                                    familyCandidateOK = False
                                    Exit For
                                End If
                                famReach = Distance3D2A(x1, y1, z1, fx, fy, fz)
                                If famReach > mod22_PSUTerminalAllocator.PSUTerm_PsuLimitMM() Or _
                                   famReach > mod22_PSUTerminalAllocator.PSUTerm_TerminalLimitMM() Then
                                    familyCandidateOK = False
                                    Exit For
                                End If
                            End If
                        Next famItem
                    End If

                    If Not familyCandidateOK Then GoTo NextCandidate
                End If
            End If

            'For proximity reuse choose the nearest valid PSU. For a same-base
            'family, also prefer the nearest valid candidate when XYZ exists.
            If bestRow = 0 Or reachMM < bestReach Then
                bestRow = br
                bestTerm = emptyTerm
                bestReach = reachMM
                bestHasReach = (curXYZValid And anchorXYZValid)
            End If
        End If
NextCandidate:
    Next br

    If bestRow = 0 Then Exit Function

    terminalName = mod22_PSUTerminalAllocator.PSUTerm_TerminalName(bestTerm)
    attachedPSU = Clean2A(bus.Cells(bestRow, 5).Value)
    attachedTerminal = terminalName
    If bestHasReach Then attachedReachMM = bestReach Else attachedReachMM = 0#

    loadNow = Num2A(bus.Cells(bestRow, 3).Value)
    bus.Cells(bestRow, 3).Value = Round(loadNow + amps, 2)
    If attachedReachMM > Num2A(bus.Cells(bestRow, 4).Value) Then _
        bus.Cells(bestRow, 4).Value = Round(attachedReachMM, 0)

    seqListTmp = CStr(bus.Cells(bestRow, 10).Value2)
    isNewSequence = Not SequenceListHasExact2A(seqListTmp, seq)
    If isNewSequence Then
        bus.Cells(bestRow, 9).Value = CLng(Val(bus.Cells(bestRow, 9).Value)) + 1
        AppendSequence2A seqListTmp, seq
        bus.Cells(bestRow, 10).NumberFormat = "@"
        bus.Cells(bestRow, 10).Value2 = seqListTmp
    End If

    bus.Cells(bestRow, 14 + bestTerm).Value2 = label

    assignmentTmp = CStr(bus.Cells(bestRow, 19).Value2)
    AppendText2A assignmentTmp, label & "=" & terminalName, "; "
    bus.Cells(bestRow, 19).NumberFormat = "@"
    bus.Cells(bestRow, 19).Value2 = assignmentTmp

    If requireSameBase Then
        statusText = "OK - same SIS root reused existing " & busCode & " PSU"
    Else
        statusText = "OK - XYZ proximity reused existing " & busCode & " PSU"
    End If

    termRows.Add Array(attachedPSU, seq, b, busCode, terminalName, _
                       Round(amps, 2), Round(attachedReachMM, 0), rawML, rawZL, _
                       curArea, TextAt2A(ws, deviceRow, cSwg), TextAt2A(ws, deviceRow, cPanel), _
                       statusText)

    TryAttachToExistingBusGroup2A = True
End Function


'===============================================================================
' V5.1.8 POWER-FAMILY ORDER / RESERVATION HELPERS
'===============================================================================

Private Sub ApplyPowerFamilyContiguousOrder2A(ByVal ws As Worksheet, ByVal lr As Long, _
                                               ByVal cSeq As Long, ByVal cLPN As Long)
    Dim familyRank As Object
    Dim r As Long, lc As Long, cFamily As Long, cMember As Long
    Dim rankNo As Long, seq As String, baseSeq As String, normSeq As String
    Dim memberOrder As Double

    If ws Is Nothing Then Exit Sub
    If lr < 2 Then Exit Sub

    Set familyRank = Dict2A()

    lc = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    cFamily = lc + 1
    cMember = lc + 2

    ws.Cells(1, cFamily).Value = "__POWER_FAMILY_ORDER"
    ws.Cells(1, cMember).Value = "__POWER_FAMILY_MEMBER"

    'The worksheet is already in engineered Pred/Succ order when that data is
    'available. Assign each normalized root a rank at its first appearance in
    'that order, then pull every suffix member beside the root.
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.ApplyPowerFamilyContiguousOrder2A [L1406]" & " row " & CStr(r)
        seq = SourceSeq2A(ws, r, cSeq, cLPN)
        baseSeq = BaseSequenceKey2A(seq)

        If baseSeq = "" Then
            baseSeq = "__ROW__" & Right$("0000000" & CStr(r), 7)
        End If

        If Not familyRank.Exists(baseSeq) Then
            rankNo = rankNo + 1
            familyRank(baseSeq) = rankNo
        End If

        ws.Cells(r, cFamily).Value = CLng(familyRank(baseSeq))

        normSeq = FlowKey2A(seq)
        If StrComp(normSeq, baseSeq, vbTextCompare) = 0 Then
            'Root/non-suffixed rows first.
            memberOrder = CDbl(r)
        Else
            'Suffix/child rows immediately after all root rows.
            memberOrder = 1000000# + CDbl(r)
        End If
        ws.Cells(r, cMember).Value = memberOrder
    Next r

    With ws.Sort
        .SortFields.Clear
        .SortFields.Add key:=ws.Range(ws.Cells(2, cFamily), ws.Cells(lr, cFamily)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add key:=ws.Range(ws.Cells(2, cMember), ws.Cells(lr, cMember)), _
                        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lr, cMember))
        .header = xlYes
        .MatchCase = False
        .Orientation = xlTopToBottom
        .Apply
    End With

    ws.Range(ws.Cells(1, cFamily), ws.Cells(lr, cMember)).Clear
End Sub

Private Function Bus1FamilyRemainingAmps2A(ByVal ws As Worksheet, ByVal fromRow As Long, ByVal lr As Long, _
                                            ByVal wantedBase As String, ByVal hasQual As Object, ByVal fallback As Object, _
                                            ByVal cBlock As Long, ByVal cSeq As Long, ByVal cLPN As Long, _
                                            ByVal cLen As Long, ByVal cQtyDrv As Long, ByVal cPower As Long, _
                                            ByVal cVolt As Long) As Double
    Dim rr As Long, k As String, b As String, seq As String, baseSeq As String
    Dim useRow As Boolean, amps As Double, dummyMM As Double, includeRecord As Boolean

    For rr = fromRow To lr
        PDPerf_Pulse "mod06_EstimatePSU.Bus1FamilyRemainingAmps2A [L1456]" & " row " & CStr(rr)
        seq = SourceSeq2A(ws, rr, cSeq, cLPN)
        baseSeq = BaseSequenceKey2A(seq)

        If baseSeq <> wantedBase Then
            'Families are contiguous after ApplyPowerFamilyContiguousOrder2A.
            Exit For
        End If

        k = DeviceKey2A(ws, rr, cSeq, cLPN)
        b = BlockKey2A(ws.Cells(rr, cBlock).Value)
        useRow = False

        If k <> "" Then
            If IsBus1Controller2A(b) Then
                useRow = True
            ElseIf Not hasQual.Exists(k) And fallback.Exists(k) Then
                useRow = (CLng(fallback(k)) = rr)
            End If
        End If

        If useRow Then
            amps = OriginalBus1Amps2A(ws, rr, cQtyDrv, cPower, cVolt)
            If amps > 0# Then
                dummyMM = mod22_PSUTerminalAllocator.PSUTerm_BusLengthMM( _
                              "BUS-1", b, ValueAt2A(ws, rr, cLen), includeRecord)
                If includeRecord Then Bus1FamilyRemainingAmps2A = Bus1FamilyRemainingAmps2A + amps
            End If
        End If
    Next rr
End Function

Private Function Bus2FamilyRemainingAmps2A(ByVal ws As Worksheet, ByVal fromRow As Long, ByVal lr As Long, _
                                            ByVal wantedBase As String, ByVal hasTypedDevice As Object, _
                                            ByVal fallback As Object, ByVal cBlock As Long, ByVal cType As Long, _
                                            ByVal cSeq As Long, ByVal cLPN As Long, ByVal cQtyDrv As Long, _
                                            ByVal cPower As Long, ByVal cVolt As Long, ByVal cSensors As Long, _
                                            ByVal cSys As Long) As Double
    Dim rr As Long, k As String, typ As String, seq As String, baseSeq As String
    Dim useRow As Boolean, amps As Double

    For rr = fromRow To lr
        PDPerf_Pulse "mod06_EstimatePSU.Bus2FamilyRemainingAmps2A [L1497]" & " row " & CStr(rr)
        seq = SourceSeq2A(ws, rr, cSeq, cLPN)
        baseSeq = BaseSequenceKey2A(seq)

        If baseSeq <> wantedBase Then Exit For

        k = DeviceKey2A(ws, rr, cSeq, cLPN)
        typ = NormalizeDeviceType2A(TextAt2A(ws, rr, cType))
        useRow = False
        amps = 0#

        If k <> "" Then
            If hasTypedDevice.Exists(k) Then
                If typ <> "" And Not mBus2LoadByType Is Nothing Then
                    If mBus2LoadByType.Exists(typ) Then
                        useRow = True
                        amps = Bus2AmpsForDeviceRow2A(ws, rr, cType, cBlock, cQtyDrv, cPower, cVolt, cSensors, cSys)
                    End If
                End If
            ElseIf fallback.Exists(k) Then
                useRow = (CLng(fallback(k)) = rr)
                If useRow Then
                    amps = OriginalBus2Amps2A(ws, rr, cQtyDrv, cPower, cVolt, cSensors, cSys)
                End If
            End If
        End If

        If useRow And amps > 0# Then
            Bus2FamilyRemainingAmps2A = Bus2FamilyRemainingAmps2A + amps
        End If
    Next rr
End Function

Private Function Bus2FamilyPoweredRows2A(ByVal ws As Worksheet, ByVal fromRow As Long, ByVal lr As Long, _
                                         ByVal wantedBase As String, ByVal hasTypedDevice As Object, _
                                         ByVal fallback As Object, ByVal cBlock As Long, ByVal cType As Long, _
                                         ByVal cSeq As Long, ByVal cLPN As Long, ByVal cQtyDrv As Long, _
                                         ByVal cPower As Long, ByVal cVolt As Long, ByVal cSensors As Long, _
                                         ByVal cSys As Long) As Collection
    Dim rowsOut As New Collection
    Dim rr As Long, k As String, typ As String, seq As String, baseSeq As String
    Dim useRow As Boolean, amps As Double

    For rr = fromRow To lr
        PDPerf_Pulse "mod06_EstimatePSU.Bus2FamilyPoweredRows2A [L1540]" & " row " & CStr(rr)
        seq = SourceSeq2A(ws, rr, cSeq, cLPN)
        baseSeq = BaseSequenceKey2A(seq)
        If baseSeq <> wantedBase Then Exit For

        k = DeviceKey2A(ws, rr, cSeq, cLPN)
        typ = NormalizeDeviceType2A(TextAt2A(ws, rr, cType))
        useRow = False
        amps = 0#

        If k <> "" Then
            If hasTypedDevice.Exists(k) Then
                If typ <> "" And Not mBus2LoadByType Is Nothing Then
                    If mBus2LoadByType.Exists(typ) Then
                        useRow = True
                        amps = Bus2AmpsForDeviceRow2A(ws, rr, cType, cBlock, cQtyDrv, cPower, cVolt, cSensors, cSys)
                    End If
                End If
            ElseIf fallback.Exists(k) Then
                useRow = (CLng(fallback(k)) = rr)
                If useRow Then
                    amps = OriginalBus2Amps2A(ws, rr, cQtyDrv, cPower, cVolt, cSensors, cSys)
                End If
            End If
        End If

        If useRow And amps > 0# Then rowsOut.Add rr
    Next rr

    Set Bus2FamilyPoweredRows2A = rowsOut
End Function


Private Sub BuildVFD2A(ByVal ws As Worksheet, ByVal outWs As Worksheet, ByVal lr As Long, ByRef outRow As Long, _
                       ByVal cBlock As Long, ByVal cType As Long, ByVal cSeq As Long, ByVal cLPN As Long, _
                       ByVal cPower As Long, ByVal cVolt As Long, ByVal cBrake As Long, ByVal cSys As Long)

    Dim rep As Object, fallback As Object, done As Object
    Dim r As Long, k As String, b As String, typ As String
    Dim useRow As Boolean, seq As String
    Dim loadA As Double, found As Boolean

    Set rep = Dict2A()
    Set fallback = Dict2A()
    Set done = Dict2A()

    'Prefer the actual electrical device row whose TYPE is VFD/VFD_*.
    'Only fall back to the parent 400/460/480 V row when no typed VFD exists.
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.BuildVFD2A [L1588]" & " row " & CStr(r)
        k = DeviceKey2A(ws, r, cSeq, cLPN)
        If k <> "" Then
            b = BlockKey2A(ws.Cells(r, cBlock).Value)
            typ = NormalizeDeviceType2A(TextAt2A(ws, r, cType))

            If Left$(typ, 3) = "VFD" Or b = "VFD" Then
                If Not rep.Exists(k) Then rep(k) = r
            ElseIf Not fallback.Exists(k) Then
                If IsOriginalVFD2A(ws, r, cSys, cVolt) Then fallback(k) = r
            End If
        End If
    Next r

    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.BuildVFD2A [L1602]" & " row " & CStr(r)
        k = DeviceKey2A(ws, r, cSeq, cLPN)
        useRow = False

        If k <> "" And Not done.Exists(k) Then
            If rep.Exists(k) Then
                useRow = (CLng(rep(k)) = r)
            ElseIf fallback.Exists(k) Then
                useRow = (CLng(fallback(k)) = r)
            End If

            If useRow Then
                done(k) = True
                seq = SourceSeq2A(ws, r, cSeq, cLPN)
                typ = NormalizeDeviceType2A(TextAt2A(ws, r, cType))

                found = False
                If typ <> "" Then loadA = Bus2LookupAmps2A(typ, found)
                If Not found Then loadA = Bus2LookupAmps2A("VFD", found)

                If Not found Or loadA <= 0# Then
                    'Compatibility fallback: keep Step 2A running even if DATA_POWER
                    'has not yet been aligned to the final EAS V25.8 VFD row.
                    loadA = VFD_BUS2_AMPS
                    found = True
                End If

                outWs.Cells(outRow, 1).Value = seq
                outWs.Cells(outRow, 2).Value = "VFD"
                outWs.Cells(outRow, 3).Value = ws.Cells(r, cPower).Value
                outWs.Cells(outRow, 4).Value = ws.Cells(r, cVolt).Value
                If cBrake > 0 Then outWs.Cells(outRow, 5).Value = ws.Cells(r, cBrake).Value
                outWs.Cells(outRow, 6).Value = loadA
                outRow = outRow + 1
            End If
        End If
    Next r
End Sub

Private Function LoadBus2TypeMap2A() As Object
    Dim d As Object, ws As Worksheet
    Dim cType As Long, cBus2 As Long, lr As Long, r As Long
    Dim typ As String, raw As Variant, amps As Double

    Set d = Dict2A()
    Set ws = GetSheet2A("DATA_POWER")
    If ws Is Nothing Then
        Err.Raise vbObjectError + 2460, , _
                  "Worksheet 'DATA_POWER' was not found. BUS-2 loads must be configured in DATA_POWER[Type, Bus-2]."
    End If

    cBus2 = HeaderAny2A(ws, "Bus-2", "BUS-2", "BUS 2", "BUS2")
    'DATA_POWER contains more than one table with a "Type" header.
    'Pair BUS-2 with the nearest literal Type header to its left so we read
    'the 24 V device-load table (AA:AE in the current PD workbook), not the
    'older motor/VFD table beginning in column D.
    cType = HeaderNearestLeft2A(ws, cBus2, "Type")
    If cType = 0 Then cType = HeaderAny2A(ws, "Type", "TYPE", "DEVICE TYPE", "DEVICE_TYPE")

    If cType = 0 Or cBus2 = 0 Then
        Err.Raise vbObjectError + 2461, , _
                  "DATA_POWER must contain headers 'Type' and 'Bus-2'."
    End If

    lr = LastRow2A(ws)
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.LoadBus2TypeMap2A [L1667]" & " row " & CStr(r)
        typ = NormalizeDeviceType2A(ws.Cells(r, cType).Value)
        If typ <> "" Then
            raw = ws.Cells(r, cBus2).Value

            'Blank Bus-2 is an intentional 0 A configuration.
            If Len(Trim$(CStr(raw))) = 0 Then
                amps = 0#
            ElseIf IsNumeric(raw) Then
                amps = CDbl(raw)
            Else
                amps = Num2A(raw)
            End If

            If d.Exists(typ) Then
                If Abs(CDbl(d(typ)) - amps) > 0.000001 Then
                    Err.Raise vbObjectError + 2462, , _
                              "DATA_POWER contains conflicting Bus-2 values for Type '" & typ & "'."
                End If
            Else
                d.Add typ, amps
            End If
        End If
    Next r

    ApplyBus2Defaults2A d

    If d.count = 0 Then
        Err.Raise vbObjectError + 2463, , _
                  "DATA_POWER does not contain any usable Type / Bus-2 rows."
    End If

    Set LoadBus2TypeMap2A = d
End Function

Private Sub ApplyBus2Defaults2A(ByVal d As Object)
    'Final EAS V25.8 compatibility defaults.
    'This prevents Step 2A from failing when the PD workbook still carries
    'an older or incomplete DATA_POWER table.
    ApplyBus2Default2A d, "VFD", VFD_BUS2_AMPS
    ApplyBus2Default2A d, "VFD_MF", VFD_BUS2_AMPS
    ApplyBus2Default2A d, "VFD_MC", VFD_BUS2_AMPS
    ApplyBus2Default2A d, "IO/S", 2#
    ApplyBus2Default2A d, "IO/D", 2#
    ApplyBus2Default2A d, "IO_S", 2#
    ApplyBus2Default2A d, "IO_D", 2#
End Sub

Private Sub ApplyBus2Default2A(ByVal d As Object, ByVal deviceType As String, ByVal defaultAmps As Double)
    Dim key As String
    key = NormalizeDeviceType2A(deviceType)
    If key = "" Then Exit Sub

    If d.Exists(key) Then
        If CDbl(d(key)) <= 0# Then d(key) = defaultAmps
    Else
        d.Add key, defaultAmps
    End If
End Sub

Private Function NormalizeDeviceType2A(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Trim$(Clean2A(v)))
    s = Replace$(s, ChrW$(160), " ")
    s = Replace$(s, " ", "")
    NormalizeDeviceType2A = s
End Function

Private Function Bus2AmpsForDeviceRow2A(ByVal ws As Worksheet, ByVal r As Long, _
                                        ByVal cType As Long, ByVal cBlock As Long, _
                                        ByVal cQty As Long, ByVal cPower As Long, _
                                        ByVal cVolt As Long, ByVal cSensors As Long, _
                                        ByVal cSys As Long) As Double
    Dim b As String, typ As String
    Dim found As Boolean, amps As Double

    b = BlockKey2A(ws.Cells(r, cBlock).Value)
    typ = NormalizeDeviceType2A(TextAt2A(ws, r, cType))

    'Hard architecture exception:
    'Interface_Card never receives BUS-2 power, even if TYPE happens to be MC.
    If b = "INTERFACE_CARD" Then
        Bus2AmpsForDeviceRow2A = 0#
        Exit Function
    End If

    '1) AUTHORITATIVE RULE:
    '   SIS_TAG_PD5[TYPE] -> DATA_POWER[Type] -> DATA_POWER[Bus-2]
    '   Each physical device row contributes the configured load once.
    If typ <> "" Then
        amps = Bus2LookupAmps2A(typ, found)
        If found Then
            Bus2AmpsForDeviceRow2A = amps
            Exit Function
        End If
    End If

    '2) VFD aliases:
    '   VFD_MF / VFD_MC / other VFD_* rows should use their exact configured
    '   DATA_POWER value if present. If an alias is missing from DATA_POWER,
    '   fall back to the base VFD row.
    If Left$(typ, 3) = "VFD" Then
        amps = Bus2LookupAmps2A("VFD", found)
        If found Then
            Bus2AmpsForDeviceRow2A = amps
            Exit Function
        End If
    End If

    '3) PD mechanical/electrical export fallback:
    '   Some VFD devices arrive as BLOCK_NAME=MOT and are identifiable by
    '   400/460/480 V electrical data even when TYPE is blank.
    If IsVFDDeviceRow2A(ws, r, cType, cBlock, cSys, cVolt) Then
        amps = Bus2LookupAmps2A("VFD", found)
        If found Then
            Bus2AmpsForDeviceRow2A = amps
            Exit Function
        End If

        'Compatibility fallback for legacy DATA_POWER tables.
        Bus2AmpsForDeviceRow2A = VFD_BUS2_AMPS
        Exit Function
    End If

    '4) Compatibility fallback for legacy/unconfigured non-VFD device types.
    If IsBus2Controller2A(b) Then
        Bus2AmpsForDeviceRow2A = ControlBus2Amps2A(ws, r, cSensors, cPower)
    Else
        Bus2AmpsForDeviceRow2A = OriginalBus2Amps2A(ws, r, cQty, cPower, cVolt, cSensors, cSys)
    End If
End Function

Private Function Bus2LookupAmps2A(ByVal deviceType As String, ByRef found As Boolean) As Double
    Dim key As String

    found = False
    key = NormalizeDeviceType2A(deviceType)
    If key = "" Then Exit Function
    If mBus2LoadByType Is Nothing Then Exit Function

    If mBus2LoadByType.Exists(key) Then
        found = True
        Bus2LookupAmps2A = CDbl(mBus2LoadByType(key))
    End If
End Function

Private Function IsVFDDeviceRow2A(ByVal ws As Worksheet, ByVal r As Long, _
                                  ByVal cType As Long, ByVal cBlock As Long, _
                                  ByVal cSys As Long, ByVal cVolt As Long) As Boolean
    Dim typ As String, b As String

    typ = NormalizeDeviceType2A(TextAt2A(ws, r, cType))
    b = BlockKey2A(ws.Cells(r, cBlock).Value)

    'Any DATA_POWER VFD family TYPE is a VFD device.
    If Left$(typ, 3) = "VFD" Then
        IsVFDDeviceRow2A = True
        Exit Function
    End If

    If b = "VFD" Then
        IsVFDDeviceRow2A = True
        Exit Function
    End If

    'Current PD geometry commonly exports the physical drive row as MOT.
    If b = "MOT" Then
        If IsOriginalVFD2A(ws, r, cSys, cVolt) Then
            IsVFDDeviceRow2A = True
        End If
    End If
End Function

Private Function OriginalBus1Amps2A(ByVal ws As Worksheet, ByVal r As Long, ByVal cQty As Long, ByVal cPower As Long, ByVal cVolt As Long) As Double
    Dim kw As Double, volts As Double, qty As Double, watts As Long, unitA As Double
    kw = Num2A(ws.Cells(r, cPower).Value): volts = VoltageNum2A(ws.Cells(r, cVolt).Value): qty = Num2A(ws.Cells(r, cQty).Value)
    If kw <= 0# Or (volts <> 24# And volts <> 48#) Then Exit Function
    watts = CLng(Round(kw * 1000#, 0))
    If watts = 100 Then OriginalBus1Amps2A = 10#: Exit Function
    If volts = 24# Then
        If watts = 35 Then
            unitA = 2#
        ElseIf watts = 50 Then
            unitA = 3.6
        End If
    Else
        If watts = 35 Then
            unitA = 1.3
        ElseIf watts = 50 Then
            unitA = 1.9
        End If
    End If
    If unitA > 0# And qty > 0# Then OriginalBus1Amps2A = unitA * qty
End Function

Private Function ControlBus2Amps2A(ByVal ws As Worksheet, ByVal r As Long, ByVal cSensors As Long, ByVal cPower As Long) As Double
    Dim q As Double
    If Is100W2A(Num2A(ws.Cells(r, cPower).Value)) Then ControlBus2Amps2A = SENSOR_AMPS: Exit Function
    q = Num2A(ws.Cells(r, cSensors).Value)
    If q > 0# Then ControlBus2Amps2A = SENSOR_AMPS * q
End Function

Private Function VFDBus2Amps2A(ByVal ws As Worksheet, ByVal r As Long, ByVal cQty As Long) As Double
    Dim q As Double
    q = Num2A(ws.Cells(r, cQty).Value): If q <= 0# Then q = 1#
    VFDBus2Amps2A = VFD_BUS2_AMPS * q
End Function

Private Function OriginalBus2Amps2A(ByVal ws As Worksheet, ByVal r As Long, ByVal cQty As Long, ByVal cPower As Long, _
                                    ByVal cVolt As Long, ByVal cSensors As Long, ByVal cSys As Long) As Double
    If IsOriginalVFD2A(ws, r, cSys, cVolt) Then OriginalBus2Amps2A = VFDBus2Amps2A(ws, r, cQty): Exit Function
    OriginalBus2Amps2A = ControlBus2Amps2A(ws, r, cSensors, cPower)
End Function

Private Function IsOriginalVFD2A(ByVal ws As Worksheet, ByVal r As Long, ByVal cSys As Long, ByVal cVolt As Long) As Boolean
    Dim s As String, v As Double
    If cSys > 0 Then
        s = UCase$(Replace$(Clean2A(ws.Cells(r, cSys).Value), " ", ""))
        If s = "VFD" Or s = "400" Or s = "460" Or s = "480" Or s = "400V" Or s = "460V" Or s = "480V" Then IsOriginalVFD2A = True: Exit Function
    End If
    v = VoltageNum2A(ws.Cells(r, cVolt).Value)
    IsOriginalVFD2A = (v = 400# Or v = 460# Or v = 480#)
End Function

Private Function VoltageNum2A(ByVal v As Variant) As Double
    Dim s As String
    If IsNumeric(v) Then VoltageNum2A = CDbl(v): Exit Function
    s = UCase$(Clean2A(v)): s = Replace$(s, "VDC", ""): s = Replace$(s, "VAC", ""): s = Replace$(s, "V", ""): s = Replace$(s, "R", ""): s = Replace$(s, "B", ""): s = Replace$(s, " ", "")
    If IsNumeric(s) Then VoltageNum2A = CDbl(s)
End Function



Private Sub AddAutoSplitWarning2A(ByVal busCode As String, ByVal seq As String, _
                                  ByVal baseSeq As String, ByVal oldPSU As String, _
                                  ByVal reason As String)
    Dim msg As String

    If mAutoSplitWarnings Is Nothing Then Set mAutoSplitWarnings = New Collection
    mAutoSplitWarningCount = mAutoSplitWarningCount + 1

    msg = busCode & " | SIS " & seq & " | family " & baseSeq & _
          " | previous PSU " & oldPSU & _
          " | " & reason & _
          " | Action: allocation conflict handled automatically; Step 2A will reuse another valid PSU or create a new PSU and continue."

    mAutoSplitWarnings.Add msg

    On Error Resume Next
    Application.StatusBar = "Step 2A warning: " & busCode & " allocation split for SIS " & seq & _
                            ". Creating/reusing another PSU and continuing..."
    Debug.Print "[ONGEN Step 2A WARNING] " & msg
    On Error GoTo 0
End Sub

Private Function AutoSplitSummary2A() As String
    Dim s As String, i As Long, maxShow As Long

    If mAutoSplitWarningCount <= 0 Then
        AutoSplitSummary2A = vbNullString
        Exit Function
    End If

    s = vbCrLf & vbCrLf & _
        "WARNING: Step 2A encountered " & CStr(mAutoSplitWarningCount) & _
        " automatic PSU/terminal allocation split(s). Processing continued automatically." & vbCrLf & _
        "Current/reach/terminal conflicts no longer stop Step 2A. The affected device was moved to another valid PSU or a new PSU when possible."

    If Not mAutoSplitWarnings Is Nothing Then
        maxShow = mAutoSplitWarnings.count
        If maxShow > 8 Then maxShow = 8

        For i = 1 To maxShow
            s = s & vbCrLf & " - " & CStr(mAutoSplitWarnings(i))
        Next i

        If mAutoSplitWarnings.count > maxShow Then
            s = s & vbCrLf & " - ... plus " & CStr(mAutoSplitWarnings.count - maxShow) & " additional automatic split(s)."
        End If
    End If

    AutoSplitSummary2A = s
End Function

Private Function NextPSUName2A(ByVal outWs As Worksheet, ByVal outRow As Long, _
                               ByVal baseSeq As String, ByVal busCode As String) As String
    Dim baseName As String, candidate As String
    Dim used As Object
    Dim r As Long, n As Long, existingName As String, existingBus As String

    baseName = Trim$(baseSeq)
    If baseName = "" Then baseName = "PSU"
    baseName = baseName & "-PSU"

    Set used = CreateObject("Scripting.Dictionary")
    used.CompareMode = vbTextCompare

    'Power Supply Bus stores PSU name in column E and BUS in column N.
    For r = 1 To outRow - 1
        PDPerf_Pulse "mod06_EstimatePSU.NextPSUName2A [L1965]" & " row " & CStr(r)
        existingBus = Trim$(CStr(outWs.Cells(r, 14).Value2))
        existingName = Trim$(CStr(outWs.Cells(r, 5).Value2))
        If StrComp(existingBus, busCode, vbTextCompare) = 0 And existingName <> "" Then
            used(existingName) = True
        End If
    Next r

    candidate = baseName
    If Not used.Exists(candidate) Then
        NextPSUName2A = candidate
        Exit Function
    End If

    n = 2
    Do
        candidate = baseName & "-" & CStr(n)
        If Not used.Exists(candidate) Then
            NextPSUName2A = candidate
            Exit Function
        End If
        n = n + 1
    Loop
End Function

Private Sub FlushBus2A(ByVal ws As Worksheet, ByRef outRow As Long, ByVal grp As Long, ByVal startSeq As String, _
                       ByVal endSeq As String, ByVal amps As Double, ByVal mm As Double, ByVal busName As String, _
                       ByVal busCode As String, ByVal reason As String, ByVal totalCtl As Long, ByVal sequenceList As String, _
                       ByVal areaNum As String, ByVal swg As String, ByVal panel As String, ByVal psuName As String, _
                       ByRef termSeq() As String, ByVal terminalAssignments As String)
    ws.Cells(outRow, 1).Value = grp
    ws.Cells(outRow, 2).Value = endSeq
    ws.Cells(outRow, 3).Value = Round(amps, 2)
    ws.Cells(outRow, 4).Value = Round(mm, 0)
    ws.Cells(outRow, 5).Value = psuName
    ws.Cells(outRow, 6).Value = busName
    ws.Cells(outRow, 7).Value = startSeq & " to " & endSeq
    ws.Cells(outRow, 8).Value = reason
    ws.Cells(outRow, 9).Value = totalCtl

    With ws.Cells(outRow, 10)
        .NumberFormat = "@"
        .Value2 = CStr(sequenceList)
    End With

    ws.Cells(outRow, 11).Value = areaNum
    ws.Cells(outRow, 12).Value = swg
    ws.Cells(outRow, 13).Value = panel
    ws.Cells(outRow, 14).Value = busCode

    ws.Cells(outRow, 15).NumberFormat = "@"
    ws.Cells(outRow, 16).NumberFormat = "@"
    ws.Cells(outRow, 17).NumberFormat = "@"
    ws.Cells(outRow, 18).NumberFormat = "@"
    ws.Cells(outRow, 19).NumberFormat = "@"
    ws.Cells(outRow, 15).Value2 = termSeq(1)
    ws.Cells(outRow, 16).Value2 = termSeq(2)
    ws.Cells(outRow, 17).Value2 = termSeq(3)
    ws.Cells(outRow, 18).Value2 = termSeq(4)
    ws.Cells(outRow, 19).Value2 = terminalAssignments

    outRow = outRow + 1
End Sub

Private Sub ResetPowerGroup2A(ByRef started As Boolean, ByRef runA As Double, ByRef runMM As Double, _
                              ByRef runCtl As Long, ByRef startSeq As String, ByRef endSeq As String, _
                              ByRef runSeqList As String, ByRef terminalAssignments As String, _
                              ByRef termLoad() As Double, ByRef termLengthMM() As Double, _
                              ByRef termSeq() As String, ByRef ctlSeen As Object, _
                              ByRef spanSeen As Object, ByRef spanCount As Long, ByRef lastSpanML As Double)
    started = False
    runA = 0#
    runMM = 0#
    runCtl = 0
    spanCount = 0
    lastSpanML = 0#
    startSeq = vbNullString
    endSeq = vbNullString
    runSeqList = vbNullString
    terminalAssignments = vbNullString
    Set ctlSeen = Dict2A()
    Set spanSeen = Dict2A()
    mod22_PSUTerminalAllocator.PSUTerm_ResetState termLoad, termLengthMM, termSeq
End Sub

Private Sub AppendSequence2A(ByRef sequenceList As String, ByVal seq As String)
    seq = Trim$(seq)
    If seq = "" Then Exit Sub
    If sequenceList = "" Then
        sequenceList = seq
    Else
        sequenceList = sequenceList & ", " & seq
    End If
End Sub

Private Sub AppendText2A(ByRef target As String, ByVal valueText As String, ByVal delimiter As String)
    valueText = Trim$(valueText)
    If Len(valueText) = 0 Then Exit Sub
    If Len(target) = 0 Then
        target = valueText
    Else
        target = target & delimiter & valueText
    End If
End Sub

Private Function PowerRecordLabel2A(ByVal seq As String, ByVal blockKey As String) As String
    If Len(Trim$(blockKey)) > 0 Then
        PowerRecordLabel2A = seq & "[" & blockKey & "]"
    Else
        PowerRecordLabel2A = seq
    End If
End Function

Private Sub BuildEstimated2A(ByVal bus As Worksheet, ByVal est As Worksheet)
    Dim lr As Long, r As Long, outRow As Long, section As String
    Dim typ As String, src As String, dev As String, k As String, seen As Object
    Dim ml As Variant, zl As Variant

    Set seen = Dict2A()
    est.UsedRange.Clear
    est.Cells(1, 1).Resize(1, 18).Value = Array( _
        "SOURCE_SIS_SEQUENCE", "TYPE", "SIS_SEQUENCE", "CONTROL_FUNTION_NUMBER", "CURRENT_LOAD", "BUS", _
        "AREA_NUMBER", "SWITCHGROUP", "FEEDING_PANEL", "PSU_POWERED_SEQUENCES", "PSU_RANGE", _
        "PSU_TOTAL_CONTROLLER", "PSU_GROUP_NO", "PSU_CLOSE_REASON", "PSU_TERMINAL_ASSIGNMENTS", _
        "MODULE_LENGTH_ML", "ZONE_LENGTH_ZL", "ESTIMATE_RULE_VERSION")
    est.rows(1).Font.Bold = True
    est.Columns(10).NumberFormat = "@"
    est.Columns(15).NumberFormat = "@"

    lr = LastRow2A(bus)
    outRow = 2

    For r = 1 To lr
        PDPerf_Pulse "mod06_EstimatePSU.BuildEstimated2A [L2097]" & " row " & CStr(r)
        If Clean2A(bus.Cells(r, 1).Value) = "Power Bus 1" Or Clean2A(bus.Cells(r, 1).Value) = "Logic Bus 2" Then
            section = "BUS"
        ElseIf Clean2A(bus.Cells(r, 1).Value) = "VFD" Then
            section = "VFD"
        ElseIf section = "BUS" Then
            typ = Clean2A(bus.Cells(r, 6).Value)
            If typ = "Power Bus 1" Or typ = "Logic Bus 2" Then
                dev = Clean2A(bus.Cells(r, 5).Value)
                src = StripPSU2A(dev)
                If src <> "" Then
                    k = UCase$(src & "|PSU|" & typ)
                    If Not seen.Exists(k) Then
                        seen(k) = True
                        ml = Empty
                        zl = Empty
                        On Error Resume Next
                        mod21_CSVTraceability.CSVTrace_ResolveLengths src, src, vbNullString, ml, zl
                        On Error GoTo 0

                        est.Cells(outRow, 1).Value = src
                        est.Cells(outRow, 2).Value = "PSU"
                        est.Cells(outRow, 3).Value = dev
                        est.Cells(outRow, 5).Value = bus.Cells(r, 3).Value
                        est.Cells(outRow, 6).Value = typ
                        est.Cells(outRow, 7).Value = bus.Cells(r, 11).Value
                        est.Cells(outRow, 8).Value = bus.Cells(r, 12).Value
                        est.Cells(outRow, 9).Value = bus.Cells(r, 13).Value
                        est.Cells(outRow, 10).NumberFormat = "@"
                        est.Cells(outRow, 10).Value2 = CStr(bus.Cells(r, 10).Value2)
                        est.Cells(outRow, 11).Value = bus.Cells(r, 7).Value
                        est.Cells(outRow, 12).Value = bus.Cells(r, 9).Value
                        est.Cells(outRow, 13).Value = bus.Cells(r, 1).Value
                        est.Cells(outRow, 14).Value = bus.Cells(r, 8).Value
                        est.Cells(outRow, 15).NumberFormat = "@"
                        est.Cells(outRow, 15).Value2 = CStr(bus.Cells(r, 19).Value2)
                        est.Cells(outRow, 16).Value = ml
                        est.Cells(outRow, 17).Value = zl
                        est.Cells(outRow, 18).Value = ESTIMATE_RULE_VERSION
                        outRow = outRow + 1
                    End If
                End If
            End If
        ElseIf section = "VFD" Then
            src = Clean2A(bus.Cells(r, 1).Value)
            typ = Clean2A(bus.Cells(r, 2).Value)
            If src <> "" And UCase$(typ) = "VFD" Then
                k = UCase$(src & "|VFD")
                If Not seen.Exists(k) Then
                    seen(k) = True
                    ml = Empty
                    zl = Empty
                    On Error Resume Next
                    mod21_CSVTraceability.CSVTrace_ResolveLengths src, src, vbNullString, ml, zl
                    On Error GoTo 0

                    est.Cells(outRow, 1).Value = src
                    est.Cells(outRow, 2).Value = "VFD"
                    est.Cells(outRow, 3).Value = src & "-VFD"
                    est.Cells(outRow, 5).Value = bus.Cells(r, 6).Value
                    est.Cells(outRow, 6).Value = "BUS-2"
                    est.Cells(outRow, 16).Value = ml
                    est.Cells(outRow, 17).Value = zl
                    est.Cells(outRow, 18).Value = ESTIMATE_RULE_VERSION
                    outRow = outRow + 1
                End If
            End If
        End If
    Next r
End Sub

Private Sub PrepareTerminalSheet2A(ByVal ws As Worksheet)
    ws.UsedRange.Clear
    ws.Cells(1, 1).Resize(1, 13).Value = Array( _
        "PSU_SIS_SEQUENCE", "SOURCE_SIS_SEQUENCE", "BLOCK_NAME", "BUS", "PSU_TERMINAL", _
        "CURRENT_LOAD", "BUS_REACH_MM", "MODULE_LENGTH_ML", "ZONE_LENGTH_ZL", _
        "AREA_NUMBER", "SWITCHGROUP", "PNL", "STATUS")
    ws.rows(1).Font.Bold = True
    ws.Columns(1).NumberFormat = "@"
    ws.Columns(2).NumberFormat = "@"
    ws.Columns(5).NumberFormat = "@"
End Sub

Private Sub WriteTerminalRows2A(ByVal ws As Worksheet, ByVal rows As Collection)
    Dim data() As Variant, rec As Variant
    Dim r As Long, c As Long

    If ws Is Nothing Then Exit Sub
    If rows Is Nothing Then Exit Sub
    If rows.count = 0 Then Exit Sub

    ReDim data(1 To rows.count, 1 To 13)
    For r = 1 To rows.count
        PDPerf_Pulse "mod06_EstimatePSU.WriteTerminalRows2A [L2189]" & " row " & CStr(r)
        rec = rows(r)
        For c = 1 To 13
            data(r, c) = rec(c - 1)
        Next c
    Next r

    ws.Cells(2, 1).Resize(rows.count, 13).Value2 = data
End Sub

Private Function ApplyPredSuccFlowOrder2A(ByVal ws As Worksheet, ByVal lr As Long, ByVal cSeq As Long, ByVal cLPN As Long, ByVal cPred As Long, ByVal cSucc As Long, ByVal cType As Long, ByVal cLen As Long, ByVal cArea As Long) As Long
    Dim allSeq As Object, pred As Object, related As Object, edgeRank As Object, childCount As Object, rootRank As Object, seen As Object
    Dim r As Long, lc As Long, ck As Long, co As Long, n As Long, er As Long
    Dim cur As String, root As String, parent As String, pathKey As String, eKey As String
    If cPred = 0 Or cSucc = 0 Then Exit Function
    Set allSeq = Dict2A(): Set pred = Dict2A(): Set related = Dict2A(): Set edgeRank = Dict2A(): Set childCount = Dict2A(): Set rootRank = Dict2A()
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.ApplyPredSuccFlowOrder2A [L2205]" & " row " & CStr(r)
        cur = FlowKey2A(SourceSeq2A(ws, r, cSeq, cLPN)): If cur <> "" Then allSeq(cur) = True
    Next r

    'Successor links are primary. Each comma-separated value is a separate branch.
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.ApplyPredSuccFlowOrder2A [L2210]" & " row " & CStr(r)
        cur = FlowKey2A(SourceSeq2A(ws, r, cSeq, cLPN))
        AddFlowListEdges2A cur, ws.Cells(r, cSucc).Value, True, allSeq, pred, related, edgeRank, childCount
    Next r
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.ApplyPredSuccFlowOrder2A [L2214]" & " row " & CStr(r)
        cur = FlowKey2A(SourceSeq2A(ws, r, cSeq, cLPN))
        AddFlowListEdges2A cur, ws.Cells(r, cPred).Value, False, allSeq, pred, related, edgeRank, childCount
    Next r
    If related.count = 0 Then Exit Function

    lc = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column: ck = lc + 1: co = lc + 2
    ws.Cells(1, ck).Value = "__POWER_FLOW_KEY": ws.Cells(1, co).Value = "__FLOW_ORIG"
    For r = 2 To lr
        PDPerf_Pulse "mod06_EstimatePSU.ApplyPredSuccFlowOrder2A [L2222]" & " row " & CStr(r)
        cur = FlowKey2A(SourceSeq2A(ws, r, cSeq, cLPN)): pathKey = ""
        If cur <> "" And related.Exists(cur) Then
            root = cur: Set seen = Dict2A(): n = 0
            Do While pred.Exists(root) And Not seen.Exists(root)
                seen(root) = True: parent = CStr(pred(root)): eKey = parent & ">" & root
                If edgeRank.Exists(eKey) Then er = CLng(edgeRank(eKey)) Else er = 1
                pathKey = "." & Right$("0000" & CStr(er), 4) & pathKey
                root = parent: n = n + 1: If n > allSeq.count Then Exit Do
            Loop
            If Not rootRank.Exists(root) Then rootRank(root) = rootRank.count + 1
            pathKey = "F" & Right$("000000" & CStr(rootRank(root)), 6) & pathKey
        Else
            'Unlinked point devices are deliberately sorted after the normal
            'conveyor flow. This lets RIO rows see any already-built same-base
            'conveyor PSU before creating a RIO-only PSU, and it puts VFD point
            'rows in stable numeric sequence order for the +/-20 rule.
            pathKey = SpecialPointSortKey2A(ws, r, cType, cLen, cArea, cSeq, cLPN)
            If pathKey = "" Then pathKey = "U" & Right$("000000" & CStr(r), 6)
        End If
        ws.Cells(r, ck).Value = pathKey: ws.Cells(r, co).Value = r
    Next r
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add key:=ws.Range(ws.Cells(2, ck), ws.Cells(lr, ck)), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SortFields.Add key:=ws.Range(ws.Cells(2, co), ws.Cells(lr, co)), SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
        .SetRange ws.Range(ws.Cells(1, 1), ws.Cells(lr, co))
        .header = xlYes: .MatchCase = False: .Orientation = xlTopToBottom: .Apply
    End With
    ws.Range(ws.Cells(1, co), ws.Cells(lr, co)).Clear
    ApplyPredSuccFlowOrder2A = ck
End Function

Private Function SpecialPointSortKey2A(ByVal ws As Worksheet, ByVal r As Long, _
                                        ByVal cType As Long, ByVal cLen As Long, ByVal cArea As Long, _
                                        ByVal cSeq As Long, ByVal cLPN As Long) As String
    Dim typ As String, classKey As String, areaKey As String, seqText As String
    Dim mlMM As Double, seqNo As Double, seqKey As String

    typ = NormalizeDeviceType2A(TextAt2A(ws, r, cType))
    mlMM = mod22_PSUTerminalAllocator.PSUTerm_LengthValueMM(ValueAt2A(ws, r, cLen))

    If typ = "RIO" Then
        classKey = "RIO"
    ElseIf Left$(typ, 3) = "VFD" And mlMM < 10# Then
        classKey = "VFD"
    Else
        Exit Function
    End If

    areaKey = UCase$(Replace$(TextAt2A(ws, r, cArea), " ", ""))
    If areaKey = "" Then areaKey = "NOAREA"

    seqText = SourceSeq2A(ws, r, cSeq, cLPN)
    seqNo = SequenceNumber2A(seqText)
    If seqNo > 0# Then
        seqKey = Right$("0000000000" & CStr(CLng(seqNo)), 10)
    Else
        seqKey = "9999999999"
    End If

    SpecialPointSortKey2A = "ZP|" & classKey & "|" & areaKey & "|" & seqKey & "|" & Right$("000000" & CStr(r), 6)
End Function

Private Sub AddFlowListEdges2A(ByVal cur As String, ByVal v As Variant, ByVal asSuccessor As Boolean, ByVal allSeq As Object, ByVal pred As Object, ByVal related As Object, ByVal edgeRank As Object, ByVal childCount As Object)
    Dim a As Variant, i As Long, x As String
    If cur = "" Then Exit Sub
    a = Split(Clean2A(v), ",")
    For i = LBound(a) To UBound(a)
        x = FlowKey2A(a(i))
        If x <> "" And allSeq.Exists(x) Then
            If asSuccessor Then AddFlowEdge2A cur, x, pred, related, edgeRank, childCount Else AddFlowEdge2A x, cur, pred, related, edgeRank, childCount
        End If
    Next i
End Sub

Private Function WouldCycle2A(ByVal parent As String, ByVal child As String, ByVal pred As Object) As Boolean
    Dim x As String, n As Long
    x = parent
    Do While x <> "" And n <= pred.count
        If StrComp(x, child, vbTextCompare) = 0 Then WouldCycle2A = True: Exit Function
        If pred.Exists(x) Then x = CStr(pred(x)) Else Exit Do
        n = n + 1
    Loop
End Function

Private Sub AddFlowEdge2A(ByVal parent As String, ByVal child As String, ByVal pred As Object, ByVal related As Object, ByVal edgeRank As Object, ByVal childCount As Object)
    Dim k As String, n As Long
    If parent = "" Or child = "" Or parent = child Then Exit Sub
    If WouldCycle2A(parent, child, pred) Then Exit Sub
    If pred.Exists(child) Then If StrComp(CStr(pred(child)), parent, vbTextCompare) <> 0 Then Exit Sub
    pred(child) = parent: related(parent) = True: related(child) = True: k = parent & ">" & child
    If Not edgeRank.Exists(k) Then
        If childCount.Exists(parent) Then n = CLng(childCount(parent)) + 1 Else n = 1
        childCount(parent) = n: edgeRank(k) = n
    End If
End Sub

Private Function FlowKey2A(ByVal v As Variant) As String
    FlowKey2A = UCase$(Replace$(Clean2A(v), " ", ""))
End Function

Private Function FlowSortKeyAtRow2A(ByVal ws As Worksheet, ByVal r As Long) As String
    If mFlowKeyCol > 0 Then FlowSortKeyAtRow2A = Clean2A(ws.Cells(r, mFlowKeyCol).Value)
End Function

Private Function FlowContinues2A(ByVal prevKey As String, ByVal newKey As String) As Boolean
    If prevKey = "" Or newKey = "" Then FlowContinues2A = True: Exit Function
    If Left$(prevKey, 1) = "U" And Left$(newKey, 1) = "U" Then FlowContinues2A = True: Exit Function
    If prevKey = newKey Then FlowContinues2A = True: Exit Function
    FlowContinues2A = (Left$(newKey, Len(prevKey) + 1) = prevKey & ".")
End Function

Private Sub PrepareBusSheet2A(ByVal ws As Worksheet)
    ws.Cells.UnMerge
    ws.UsedRange.Clear
    ws.Columns(10).NumberFormat = "@"
    ws.Columns(15).Resize(, 5).NumberFormat = "@"
End Sub

Private Sub WriteSection2A(ByVal ws As Worksheet, ByVal r As Long, ByVal title As String)
    Dim headers As Variant
    headers = Array("Group No.", "SIS_SEQUENCE", "Load (A)", "Length (mm)", "Device 1", "Type", _
                    "Range", "Close Reason", "Total Controller", "Sequence", "Area_Number", "SwitchGroup", _
                    "PNL", "BUS", "Terminal 1 Sequence", "Terminal 2 Sequence", "Terminal 3 Sequence", _
                    "Terminal 4 Sequence", "Terminal Assignment")

    ws.Cells(r, 1).Value = title
    ws.Range(ws.Cells(r, 1), ws.Cells(r, 19)).Merge
    ws.Cells(r, 1).Font.Bold = True
    ws.Cells(r + 1, 1).Resize(1, 19).Value = headers
    ws.Cells(r + 1, 1).Resize(1, 19).Font.Bold = True
End Sub

Private Sub WriteVFDSection2A(ByVal ws As Worksheet, ByVal r As Long)
    ws.Cells(r, 1).Value = "VFD": ws.Range(ws.Cells(r, 1), ws.Cells(r, 8)).Merge: ws.Cells(r, 1).Font.Bold = True
    ws.Cells(r + 1, 1).Resize(1, 6).Value = Array("SIS_SEQUENCE", "Type", "Motor Power (Main Drive)", "Motor Voltage (Main Drive)", "Motor Brake Voltage (Main Drive)", "Bus-2 Load (A)")
    ws.Cells(r + 1, 1).Resize(1, 6).Font.Bold = True
End Sub

Private Function DeviceKey2A(ByVal ws As Worksheet, ByVal r As Long, ByVal cSeq As Long, ByVal cLPN As Long) As String
    Dim s As String
    If cSeq > 0 Then s = Clean2A(ws.Cells(r, cSeq).Value)
    If s <> "" Then DeviceKey2A = "S:" & UCase$(Replace$(s, " ", "")): Exit Function
    s = Clean2A(ws.Cells(r, cLPN).Value)
    If s <> "" Then DeviceKey2A = "L:" & UCase$(Replace$(s, " ", ""))
End Function

Private Function SourceSeq2A(ByVal ws As Worksheet, ByVal r As Long, ByVal cSeq As Long, ByVal cLPN As Long) As String
    Dim s As String, lpn As String
    If cSeq > 0 Then s = Clean2A(ws.Cells(r, cSeq).Value)
    If s <> "" Then SourceSeq2A = s: Exit Function
    lpn = Clean2A(ws.Cells(r, cLPN).Value): s = SequenceFromLPN2A(lpn)
    If s = "" Then s = lpn
    SourceSeq2A = s
End Function

Private Function SequenceFromLPN2A(ByVal lpn As String) As String
    Dim a As Variant, i As Long, s As String
    If lpn = "" Then Exit Function
    a = Split(Replace(lpn, "_", "-"), "-")
    For i = LBound(a) To UBound(a)
        s = Trim$(CStr(a(i)))
        If Len(s) >= 4 And IsNumeric(s) Then SequenceFromLPN2A = s: Exit Function
    Next i
End Function

Private Function IsBus1Controller2A(ByVal b As String) As Boolean
    IsBus1Controller2A = (b = "MULTICONTROL" Or b = "INTERFACE_CARD" Or b = "NN" Or b = "NONE")
End Function

Private Function IsBus2Controller2A(ByVal b As String) As Boolean
    IsBus2Controller2A = (b = "MULTICONTROL" Or b = "NN" Or b = "NONE")
End Function

Private Function BlockKey2A(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Clean2A(v)): s = Replace$(s, " ", ""): s = Replace$(s, "-", "_")
    If s = "INTERFACECARD" Then s = "INTERFACE_CARD"
    BlockKey2A = s
End Function

Private Function StripPSU2A(ByVal s As String) As String
    s = Trim$(s): If Len(s) >= 4 Then If UCase$(Right$(s, 4)) = "-PSU" Then s = Left$(s, Len(s) - 4)
    StripPSU2A = s
End Function

Private Function Is100W2A(ByVal kw As Double) As Boolean
    Is100W2A = (CLng(Round(kw * 1000#, 0)) = 100)
End Function

Private Function HeaderNearestLeft2A(ByVal ws As Worksheet, ByVal fromCol As Long, ByVal headerName As String) As Long
    Dim c As Long, target As String
    target = UCase$(Trim$(headerName))
    If fromCol <= 1 Then Exit Function
    For c = fromCol - 1 To 1 Step -1
        If UCase$(Trim$(CStr(ws.Cells(1, c).Value))) = target Then
            HeaderNearestLeft2A = c
            Exit Function
        End If
    Next c
End Function

Private Function HeaderAny2A(ByVal ws As Worksheet, ParamArray names() As Variant) As Long
    Dim i As Long, c As Long
    For i = LBound(names) To UBound(names)
        c = Header2A(ws, CStr(names(i)))
        If c > 0 Then HeaderAny2A = c: Exit Function
    Next i
End Function

Private Function ValueAt2A(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As Variant
    If c > 0 Then ValueAt2A = ws.Cells(r, c).Value2 Else ValueAt2A = Empty
End Function

Private Function TextAt2A(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    If c > 0 Then TextAt2A = Clean2A(ws.Cells(r, c).Value2)
End Function

Private Function Header2A(ByVal ws As Worksheet, ByVal headerName As String) As Long
    Dim lc As Long, c As Long
    lc = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lc
        If UCase$(Trim$(CStr(ws.Cells(1, c).Value))) = UCase$(Trim$(headerName)) Then Header2A = c: Exit Function
    Next c
End Function

Private Sub Require2A(ByVal colNum As Long, ByVal headerName As String)
    If colNum <= 0 Then Err.Raise vbObjectError + 2410, , "Required header not found in SIS_TAG_PD5: " & headerName
End Sub

Private Function GetSheet2A(ByVal sheetName As String) As Worksheet
    On Error Resume Next: Set GetSheet2A = ThisWorkbook.Worksheets(sheetName): On Error GoTo 0
End Function

Private Function GetOrCreate2A(ByVal sheetName As String) As Worksheet
    Set GetOrCreate2A = GetSheet2A(sheetName)
    If GetOrCreate2A Is Nothing Then
        Set GetOrCreate2A = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        GetOrCreate2A.name = sheetName
        mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation GetOrCreate2A
    End If
End Function

Private Function LastRow2A(ByVal ws As Worksheet) As Long
    Dim x As Range
    On Error Resume Next: Set x = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious): On Error GoTo 0
    If x Is Nothing Then LastRow2A = 1 Else LastRow2A = x.Row
End Function

Private Function Num2A(ByVal v As Variant) As Double
    If IsError(v) Or IsEmpty(v) Then Exit Function
    If IsNumeric(v) Then Num2A = CDbl(v)
End Function

Private Function Clean2A(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Then Exit Function
    Clean2A = Trim$(CStr(v))
End Function

Private Function Dict2A() As Object
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    Set Dict2A = d
End Function
