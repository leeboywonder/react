Attribute VB_Name = "mod26_Performance"
Option Explicit

' Shared workflow runner. No Windows API declarations; 32/64-bit Excel compatible.
Private mBusy As Boolean, mYielding As Boolean, mHadError As Boolean
Private mStarted As Double, mLastPulse As Double, mLastLog As Double
Private mLogPath As String, mStage As String, mStep As String

Public Function PDPerf_IsRunning() As Boolean
    PDPerf_IsRunning = mBusy
End Function

Public Function PDPerf_IsYielding() As Boolean
    PDPerf_IsYielding = mYielding
End Function

Private Function PDPerf_Seconds(ByVal since As Double) As Double
    PDPerf_Seconds = Timer - since
    If PDPerf_Seconds < 0 Then PDPerf_Seconds = PDPerf_Seconds + 86400#
End Function

Private Sub PDPerf_Log(ByVal message As String)
    Dim f As Integer
    On Error GoTo Unavailable
    Debug.Print Format$(Now, "yyyy-mm-dd hh:nn:ss"), message
    If Len(mLogPath) = 0 Then Exit Sub
    f = FreeFile
    Open mLogPath For Append As #f
    Print #f, Format$(Now, "yyyy-mm-dd hh:nn:ss") & vbTab & message
    Close #f
    Exit Sub
Unavailable:
    On Error Resume Next
    If f > 0 Then Close #f
End Sub

Public Sub PDPerf_RecordError(ByVal number As Long, ByVal description As String)
    If Not mBusy Or number = 0 Then Exit Sub
    mHadError = True
    PDPerf_Log "ERROR " & CStr(number) & " at " & mStage & ": " & description
End Sub

Public Sub PDPerf_Pulse(ByVal stage As String, Optional ByVal force As Boolean = False)
    Dim e As Long, d As String
    If Not mBusy Or mYielding Then Exit Sub
    mStage = stage
    If Not force And PDPerf_Seconds(mLastPulse) < 0.25 Then Exit Sub
    mLastPulse = Timer
    On Error GoTo Interrupted
    Application.StatusBar = mStep & " | " & stage & " | " & _
                            Format$(PDPerf_Seconds(mStarted), "0.0") & " s | Esc/Ctrl+Break cancels"
    If force Or PDPerf_Seconds(mLastLog) >= 2 Then
        PDPerf_Log "CHECKPOINT " & stage & " | elapsed " & Format$(PDPerf_Seconds(mStarted), "0.0") & " s"
        mLastLog = Timer
    End If
    mYielding = True
    DoEvents
    mYielding = False
    Exit Sub
Interrupted:
    e = Err.number: d = Err.description
    mYielding = False
    mHadError = True
    PDPerf_Log "INTERRUPTED " & CStr(e) & " at " & stage
    Err.Raise e, "PDPerf_Pulse", d
End Sub

Private Sub PDPerf_Execute(ByVal qualifiedMacro As String)
    Dim oldCalc As XlCalculation, oldCancel As XlEnableCancelKey
    Dim oldScreen As Boolean, oldEvents As Boolean, oldAlerts As Boolean
    Dim oldStatus As Variant, e As Long, d As String
    If mBusy Then
        MsgBox "A workflow step is already running. Wait for it to return or cancel it with Esc/Ctrl+Break.", vbInformation
        Exit Sub
    End If
    oldCalc = Application.Calculation: oldCancel = Application.EnableCancelKey
    oldScreen = Application.ScreenUpdating: oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts: oldStatus = Application.StatusBar
    mBusy = True: mHadError = False: mYielding = False
    mStep = qualifiedMacro: mStage = "starting"
    mStarted = Timer: mLastPulse = Timer: mLastLog = Timer
    mLogPath = Environ$("TEMP") & Application.PathSeparator & _
               "ONGEN_Performance_" & Format$(Now, "yyyymmdd_hhnnss") & ".log"
    On Error GoTo Failed
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    Application.EnableCancelKey = xlErrorHandler
    PDPerf_Log "START " & qualifiedMacro & " | workbook " & ThisWorkbook.name
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & qualifiedMacro
    PDPerf_Log "RETURNED " & qualifiedMacro & " | elapsed " & Format$(PDPerf_Seconds(mStarted), "0.0") & _
               " s | see workflow dialog for result; detected error=" & CStr(mHadError)
    GoTo Restore
Failed:
    e = Err.number: d = Err.description
    mHadError = True
    PDPerf_Log "FAILED " & CStr(e) & " at " & mStage & ": " & d
    MsgBox "Workflow stopped: " & d & vbCrLf & "Last checkpoint: " & mStage & vbCrLf & _
           "Rerun this step before continuing. Log: " & mLogPath, vbExclamation, "ONGEN workflow"
Restore:
    'Suppress a second cancellation while restoring Excel. Restore every captured setting.
    On Error Resume Next
    mYielding = False
    Application.EnableCancelKey = xlDisabled
    PDPerf_Log "RESTORE calculation / events / screen / alerts"
    Application.Calculation = oldCalc
    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    Application.StatusBar = oldStatus
    Application.EnableCancelKey = oldCancel
    PDPerf_Log "END " & qualifiedMacro
    mBusy = False
End Sub

Public Sub PDPerf_ShowLastLog()
    If Len(mLogPath) = 0 Then
        MsgBox "No workflow log was started in this Excel session.", vbInformation
    Else
        MsgBox mLogPath, vbInformation, "Last ONGEN performance log"
    End If
End Sub

Public Sub PDPerf_InstallButtons()
    Dim ws As Worksheet, shp As Shape, action As String, entry As String, p As Long
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            action = shp.OnAction
            If Len(action) > 0 Then
                p = InStrRev(action, "!")
                If p > 0 Then action = Mid$(action, p + 1)
                entry = PDPerf_EntryFor(action)
                If entry <> action Then shp.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & entry
            End If
        Next shp
    Next ws
End Sub

Public Function PDPerf_EntryFor(ByVal macroName As String) As String
    PDPerf_EntryFor = macroName
    Select Case LCase$(macroName)
        Case "boq_import": PDPerf_EntryFor = "PF_01"
        Case "build_function_device_clean": PDPerf_EntryFor = "PF_02"
        Case "build_pd5_from_boq": PDPerf_EntryFor = "PF_03"
        Case "build_pd6_system_designed_released": PDPerf_EntryFor = "PF_04"
        Case "build_sis_tag_pd5_manifest_using_motorvoltage": PDPerf_EntryFor = "PF_05"
        Case "copy_pd5_to_import_and_fill_from_boq": PDPerf_EntryFor = "PF_06"
        Case "devicewf_5a_update_specification_fast": PDPerf_EntryFor = "PF_07"
        Case "devicewf_5b_build_fieldio_fast": PDPerf_EntryFor = "PF_08"
        Case "devicewf_5c_send_run_b03": PDPerf_EntryFor = "PF_09"
        Case "devicewf_5d_import_b03_return_fast": PDPerf_EntryFor = "PF_10"
        Case "export_final_sis_pd5_psu_to_autocad_csv": PDPerf_EntryFor = "PF_11"
        Case "export_function_device_pd2_to_csv": PDPerf_EntryFor = "PF_12"
        Case "export_ioblock_to_csv": PDPerf_EntryFor = "PF_13"
        Case "export_pd4_estimate_psu_to_hwe_psu_csv": PDPerf_EntryFor = "PF_14"
        Case "export_pd6_export_system_to_csv": PDPerf_EntryFor = "PF_15"
        Case "fillblockfromlibraryworkbook": PDPerf_EntryFor = "PF_16"
        Case "fill_io_blockfromlibraryworkbook": PDPerf_EntryFor = "PF_17"
        Case "fill_pd6_from_powercalculation_released": PDPerf_EntryFor = "PF_18"
        Case "import_csv_to_sis_tag_export": PDPerf_EntryFor = "PF_19"
        Case "ongen_exportfunctiondevicecsv_withdescription": PDPerf_EntryFor = "PF_20"
        Case "ongen_pushdesigndetailtospecification": PDPerf_EntryFor = "PF_21"
        Case "ongen_syncmasterlibrary": PDPerf_EntryFor = "PF_22"
        Case "pd4_estimate": PDPerf_EntryFor = "PF_23"
        Case "powerrt_4a_send_pd5_fast": PDPerf_EntryFor = "PF_24"
        Case "powerrt_4b_build_pd6_fast": PDPerf_EntryFor = "PF_25"
        Case "powerrt_4c_send_pd6_fast": PDPerf_EntryFor = "PF_26"
        Case "powerrt_4d_import_power_fast": PDPerf_EntryFor = "PF_27"
        Case "step05g_backfill_io_psu_terminals": PDPerf_EntryFor = "PF_28"
        Case "ui_refreshall": PDPerf_EntryFor = "PF_29"
        Case "validate_definition_workflow": PDPerf_EntryFor = "PF_30"
        Case "verify_sis_tag_export_from_boq_v2": PDPerf_EntryFor = "PF_31"
    End Select
End Function

' Protected entry for BOQ_Import
Public Sub PF_01()
    PDPerf_Execute "mod03_ImportBOQ.BOQ_Import"
End Sub

' Protected entry for Build_Function_Device_Clean
Public Sub PF_02()
    PDPerf_Execute "mod10_FunctionDevices.Build_Function_Device_Clean"
End Sub

' Protected entry for Build_PD5_From_BOQ
Public Sub PF_03()
    PDPerf_Execute "mod05_BuildPD5.Build_PD5_From_BOQ"
End Sub

' Protected entry for Build_PD6_System_Designed_RELEASED
Public Sub PF_04()
    PDPerf_Execute "mod12_BuildPD6.Build_PD6_System_Designed_RELEASED"
End Sub

' Protected entry for Build_SIS_TAG_PD5_Manifest_Using_MotorVoltage
Public Sub PF_05()
    PDPerf_Execute "mod06_EstimatePSU.Build_SIS_TAG_PD5_Manifest_Using_MotorVoltage"
End Sub

' Protected entry for Copy_PD5_To_Import_And_Fill_From_BOQ
Public Sub PF_06()
    PDPerf_Execute "mod09_GeneratePD2.Copy_PD5_To_Import_And_Fill_From_BOQ"
End Sub

' Protected entry for DeviceWF_5A_Update_Specification_FAST
Public Sub PF_07()
    PDPerf_Execute "mod20_DeviceWorkflow.DeviceWF_5A_Update_Specification_FAST"
End Sub

' Protected entry for DeviceWF_5B_Build_FieldIO_FAST
Public Sub PF_08()
    PDPerf_Execute "mod20_DeviceWorkflow.DeviceWF_5B_Build_FieldIO_FAST"
End Sub

' Protected entry for DeviceWF_5C_Send_Run_B03
Public Sub PF_09()
    PDPerf_Execute "mod20_DeviceWorkflow.DeviceWF_5C_Send_Run_B03"
End Sub

' Protected entry for DeviceWF_5D_Import_B03_Return_FAST
Public Sub PF_10()
    PDPerf_Execute "mod20_DeviceWorkflow.DeviceWF_5D_Import_B03_Return_FAST"
End Sub

' Protected entry for Export_Final_SIS_PD5_PSU_To_AutoCAD_CSV
Public Sub PF_11()
    PDPerf_Execute "mod25_FinalCADReturnExport.Export_Final_SIS_PD5_PSU_To_AutoCAD_CSV"
End Sub

' Protected entry for Export_Function_Device_PD2_To_CSV
Public Sub PF_12()
    PDPerf_Execute "mod17_FunctionCSV.Export_Function_Device_PD2_To_CSV"
End Sub

' Protected entry for Export_IOBLOCK_To_CSV
Public Sub PF_13()
    PDPerf_Execute "mod18_IOBlockCSV.Export_IOBLOCK_To_CSV"
End Sub

' Protected entry for Export_PD4_Estimate_PSU_To_HWE_PSU_CSV
Public Sub PF_14()
    PDPerf_Execute "mod07_PD4Estimate.Export_PD4_Estimate_PSU_To_HWE_PSU_CSV"
End Sub

' Protected entry for Export_PD6_Export_System_To_CSV
Public Sub PF_15()
    PDPerf_Execute "mod19_PD6CSV.Export_PD6_Export_System_To_CSV"
End Sub

' Protected entry for FillBlockFromLibraryWorkbook
Public Sub PF_16()
    PDPerf_Execute "mod08_PSUBlockLibrary.FillBlockFromLibraryWorkbook"
End Sub

' Protected entry for Fill_IO_BlockFromLibraryWorkbook
Public Sub PF_17()
    PDPerf_Execute "mod16_IOBlockLibrary.Fill_IO_BlockFromLibraryWorkbook"
End Sub

' Protected entry for Fill_PD6_From_PowerCalculation_RELEASED
Public Sub PF_18()
    PDPerf_Execute "mod14_ImportPD6Power.Fill_PD6_From_PowerCalculation_RELEASED"
End Sub

' Protected entry for Import_CSV_To_SIS_TAG_EXPORT
Public Sub PF_19()
    PDPerf_Execute "mod02_ImportCAD.Import_CSV_To_SIS_TAG_EXPORT"
End Sub

' Protected entry for ONGEN_ExportFunctionDeviceCSV_WithDescription
Public Sub PF_20()
    PDPerf_Execute "modONGEN_CentralFunctionSystem.ONGEN_ExportFunctionDeviceCSV_WithDescription"
End Sub

' Protected entry for ONGEN_PushDesignDetailToSpecification
Public Sub PF_21()
    PDPerf_Execute "modONGEN_CentralFunctionSystem.ONGEN_PushDesignDetailToSpecification"
End Sub

' Protected entry for ONGEN_SyncMasterLibrary
Public Sub PF_22()
    PDPerf_Execute "modONGEN_CentralFunctionSystem.ONGEN_SyncMasterLibrary"
End Sub

' Protected entry for PD4_ESTIMATE
Public Sub PF_23()
    PDPerf_Execute "mod07_PD4Estimate.PD4_ESTIMATE"
End Sub

' Protected entry for PowerRT_4A_Send_PD5_FAST
Public Sub PF_24()
    PDPerf_Execute "mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST"
End Sub

' Protected entry for PowerRT_4B_Build_PD6_FAST
Public Sub PF_25()
    PDPerf_Execute "mod11_PowerRoundTrip.PowerRT_4B_Build_PD6_FAST"
End Sub

' Protected entry for PowerRT_4C_Send_PD6_FAST
Public Sub PF_26()
    PDPerf_Execute "mod11_PowerRoundTrip.PowerRT_4C_Send_PD6_FAST"
End Sub

' Protected entry for PowerRT_4D_Import_Power_FAST
Public Sub PF_27()
    PDPerf_Execute "mod11_PowerRoundTrip.PowerRT_4D_Import_Power_FAST"
End Sub

' Protected entry for Step05G_Backfill_IO_PSU_Terminals
Public Sub PF_28()
    PDPerf_Execute "mod25_EASV25_8_Alignment.Step05G_Backfill_IO_PSU_Terminals"
End Sub

' Protected entry for UI_RefreshAll
Public Sub PF_29()
    PDPerf_Execute "mod01_UI.UI_RefreshAll"
End Sub

' Protected entry for Validate_Definition_Workflow
Public Sub PF_30()
    PDPerf_Execute "mod00_MainDashboard.Validate_Definition_Workflow"
End Sub

' Protected entry for Verify_SIS_TAG_EXPORT_From_BOQ_v2
Public Sub PF_31()
    PDPerf_Execute "mod04_VerifyCAD_BOQ.Verify_SIS_TAG_EXPORT_From_BOQ_v2"
End Sub
