Attribute VB_Name = "mod10_FunctionDevices"
Option Explicit

'V5.1.5: FUNCTION DEVICE pd2 now carries PART_NUM_x / MANUF_NAME_x through x=10.
'Missing PART_NUM_8..10 / MANUF_NAME_8..10 columns in FUNCTION DEFINITION are
'allowed and produce blank output until the master library is extended.

Public Sub Build_Function_Device_Clean()
    If PDPerf_IsYielding Then Exit Sub

    Dim wb As Workbook
    Dim wsSrc As Worksheet, wsDef As Worksheet, wsOut As Worksheet

    Dim colSrcSIS As Long, colSrcCONTROL_FUNCTION_NUMBER As Long, colSrcConvType As Long
    Dim colSrcX As Long, colSrcY As Long, colSrcZ As Long, colSrcRot As Long
    Dim colSrcArea As Long, colSrcSwitchGroup As Long
    Dim colSrcInput As Long, colSrcOutput As Long, colSrcSIn As Long, colSrcSOut As Long

    Dim colDefCONTROL_FUNCTION_NUMBER As Long, colDefCONTROL_FUNCTION_TAG As Long, colDefBlock As Long
    Dim colDefInput As Long, colDefOutput As Long, colDefSIn As Long, colDefSOut As Long
    Dim colDefPartNum1 As Long, colDefManufName1 As Long
    Dim colDefPartNum2 As Long, colDefManufName2 As Long
    Dim colDefPartNum3 As Long, colDefManufName3 As Long
    Dim colDefPartNum4 As Long, colDefManufName4 As Long
    Dim colDefPartNum5 As Long, colDefManufName5 As Long
    Dim colDefPartNum6 As Long, colDefManufName6 As Long
    Dim colDefPartNum7 As Long, colDefManufName7 As Long
    Dim colDefPartNum8 As Long, colDefManufName8 As Long
    Dim colDefPartNum9 As Long, colDefManufName9 As Long
    Dim colDefPartNum10 As Long, colDefManufName10 As Long

    Dim lastRowSrc As Long, lastRowDef As Long
    Dim rSrc As Long, rDef As Long, outRow As Long

    Dim srcSIS As String, srcFuncKey As String, srcConvType As String
    Dim srcX As Variant, srcY As Variant, srcZ As Variant, srcRot As Variant
    Dim srcArea As Variant, srcSwitchGroup As Variant
    Dim srcInput As Variant, srcOutput As Variant, srcSIn As Variant, srcSOut As Variant

    Dim defFuncKey As String, lastDefFunctionKey As String
    Dim defInput As Variant, defOutput As Variant, defSIn As Variant, defSOut As Variant
    Dim startOutRow As Long, ioFromDefinition As Long, ioParentFallback As Long, ioUnresolved As Long
    Dim usedParentFallback As Boolean
    Dim defCONTROL_FUNCTION_TAG As String, defBlock As String
    Dim defPartNum1 As String, defManufName1 As String
    Dim defPartNum2 As String, defManufName2 As String
    Dim defPartNum3 As String, defManufName3 As String
    Dim defPartNum4 As String, defManufName4 As String
    Dim defPartNum5 As String, defManufName5 As String
    Dim defPartNum6 As String, defManufName6 As String
    Dim defPartNum7 As String, defManufName7 As String
    Dim defPartNum8 As String, defManufName8 As String
    Dim defPartNum9 As String, defManufName9 As String
    Dim defPartNum10 As String, defManufName10 As String

    Dim rowKey As String
    Dim dictSeen As Object

    Set wb = ThisWorkbook

    On Error Resume Next
    Set wsSrc = wb.Worksheets("SIS_TAG_Import_PD2")
    Set wsDef = wb.Worksheets("FUNCTION DEFINITION")
    On Error GoTo 0

    If wsSrc Is Nothing Then MsgBox "Sheet 'SIS_TAG_Import_PD2' not found.", vbCritical: Exit Sub
    If wsDef Is Nothing Then MsgBox "Sheet 'FUNCTION DEFINITION' not found.", vbCritical: Exit Sub

    colSrcSIS = FindHeaderColumn(wsSrc, "SIS_SEQUENCE")
    colSrcCONTROL_FUNCTION_NUMBER = FindHeaderColumn(wsSrc, "CONTROL_FUNCTION_NUMBER")
    colSrcConvType = FindHeaderColumn(wsSrc, "CONVEYOR TYPE")
    colSrcArea = FindHeaderColumn(wsSrc, "AREA_NUMBER")
    colSrcSwitchGroup = FindHeaderColumn(wsSrc, "SWITCHGROUP")
    colSrcInput = FindHeaderColumn(wsSrc, "INPUT")
    colSrcOutput = FindHeaderColumn(wsSrc, "OUTPUT")
    colSrcSIn = FindHeaderColumn(wsSrc, "S_IN")
    colSrcSOut = FindHeaderColumn(wsSrc, "S_OUT")
    colSrcX = FindHeaderColumn(wsSrc, "X")
    colSrcY = FindHeaderColumn(wsSrc, "Y")
    colSrcZ = FindHeaderColumn(wsSrc, "Z")
    colSrcRot = FindHeaderColumn(wsSrc, "ROTATION_DEG")

    colDefCONTROL_FUNCTION_NUMBER = FindHeaderColumn(wsDef, "CONTROL_FUNCTION_NUMBER")
    colDefCONTROL_FUNCTION_TAG = FindHeaderColumn(wsDef, "CONTROL_FUNCTION_TAG")
    colDefBlock = FindHeaderColumn(wsDef, "BLOCK")
    colDefInput = FindHeaderColumn(wsDef, "INPUT")
    colDefOutput = FindHeaderColumn(wsDef, "OUTPUT")
    colDefSIn = FindHeaderColumn(wsDef, "S_IN")
    colDefSOut = FindHeaderColumn(wsDef, "S_OUT")

    colDefPartNum1 = FindHeaderColumn(wsDef, "PART_NUM_1")
    colDefManufName1 = FindHeaderColumn(wsDef, "MANUF_NAME_1")
    colDefPartNum2 = FindHeaderColumn(wsDef, "PART_NUM_2")
    colDefManufName2 = FindHeaderColumn(wsDef, "MANUF_NAME_2")
    colDefPartNum3 = FindHeaderColumn(wsDef, "PART_NUM_3")
    colDefManufName3 = FindHeaderColumn(wsDef, "MANUF_NAME_3")
    colDefPartNum4 = FindHeaderColumn(wsDef, "PART_NUM_4")
    colDefManufName4 = FindHeaderColumn(wsDef, "MANUF_NAME_4")
    colDefPartNum5 = FindHeaderColumn(wsDef, "PART_NUM_5")
    colDefManufName5 = FindHeaderColumn(wsDef, "MANUF_NAME_5")
    colDefPartNum6 = FindHeaderColumn(wsDef, "PART_NUM_6")
    colDefManufName6 = FindHeaderColumn(wsDef, "MANUF_NAME_6")
    colDefPartNum7 = FindHeaderColumn(wsDef, "PART_NUM_7")
    colDefManufName7 = FindHeaderColumn(wsDef, "MANUF_NAME_7")
    colDefPartNum8 = FindHeaderColumn(wsDef, "PART_NUM_8")
    colDefManufName8 = FindHeaderColumn(wsDef, "MANUF_NAME_8")
    colDefPartNum9 = FindHeaderColumn(wsDef, "PART_NUM_9")
    colDefManufName9 = FindHeaderColumn(wsDef, "MANUF_NAME_9")
    colDefPartNum10 = FindHeaderColumn(wsDef, "PART_NUM_10")
    colDefManufName10 = FindHeaderColumn(wsDef, "MANUF_NAME_10")

    If colSrcSIS = 0 Then MsgBox "Header 'SIS_SEQUENCE' not found on 'SIS_TAG_Import_PD2'.", vbCritical: Exit Sub
    If colSrcCONTROL_FUNCTION_NUMBER = 0 Then MsgBox "Header 'CONTROL_FUNCTION_NUMBER' not found on 'SIS_TAG_Import_PD2'.", vbCritical: Exit Sub
    If colDefCONTROL_FUNCTION_NUMBER = 0 Then MsgBox "Header 'CONTROL_FUNCTION_NUMBER' not found on 'FUNCTION DEFINITION'.", vbCritical: Exit Sub
    If colDefCONTROL_FUNCTION_TAG = 0 Then MsgBox "Header 'CONTROL_FUNCTION_TAG' not found on 'FUNCTION DEFINITION'.", vbCritical: Exit Sub
    If colDefBlock = 0 Then MsgBox "Header 'BLOCK' not found on 'FUNCTION DEFINITION'.", vbCritical: Exit Sub

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Application.DisplayAlerts = False
    On Error Resume Next
    wb.Worksheets("FUNCTION DEVICE pd2").Delete
    On Error GoTo 0
    Application.DisplayAlerts = True

    Set wsOut = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
    wsOut.name = "FUNCTION DEVICE pd2"
    mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation wsOut

    wsOut.Range("A1:AM1").Value = Array( _
        "SIS_SEQUENCE", "SEQUENCE", "CONTROL_FUNCTION_NUMBER", "CONTROL_FUNCTION_TAG", _
        "CONVEYOR TYPE", "BLOCK", "AREA_NUMBER", "SWITCHGROUP", _
        "X", "Y", "Z", "ROTATION_DEG", "Scale", "SideGap", "SideClearance", _
        "PART_NUM_1", "MANUF_NAME_1", "PART_NUM_2", "MANUF_NAME_2", _
        "PART_NUM_3", "MANUF_NAME_3", "PART_NUM_4", "MANUF_NAME_4", _
        "PART_NUM_5", "MANUF_NAME_5", "PART_NUM_6", "MANUF_NAME_6", _
        "PART_NUM_7", "MANUF_NAME_7", "PART_NUM_8", "MANUF_NAME_8", _
        "PART_NUM_9", "MANUF_NAME_9", "PART_NUM_10", "MANUF_NAME_10", _
        "INPUT", "OUTPUT", "S_IN", "S_OUT")

    outRow = 2
    lastRowSrc = wsSrc.Cells(wsSrc.rows.count, colSrcSIS).End(xlUp).Row
    lastRowDef = wsDef.Cells(wsDef.rows.count, colDefBlock).End(xlUp).Row

    For rSrc = 2 To lastRowSrc
        PDPerf_Pulse "mod10_FunctionDevices.Build_Function_Device_Clean [L146]" & " row " & CStr(rSrc)

        srcSIS = Trim(CStr(wsSrc.Cells(rSrc, colSrcSIS).Value))
        srcFuncKey = NormalizeFunction(wsSrc.Cells(rSrc, colSrcCONTROL_FUNCTION_NUMBER).Value)

        srcConvType = GetCellValue(wsSrc, rSrc, colSrcConvType)
        srcArea = GetCellValue(wsSrc, rSrc, colSrcArea)
        srcSwitchGroup = GetCellValue(wsSrc, rSrc, colSrcSwitchGroup)
        srcInput = GetCellValue(wsSrc, rSrc, colSrcInput)
        srcOutput = GetCellValue(wsSrc, rSrc, colSrcOutput)
        srcSIn = GetCellValue(wsSrc, rSrc, colSrcSIn)
        srcSOut = GetCellValue(wsSrc, rSrc, colSrcSOut)
        srcX = GetCellValue(wsSrc, rSrc, colSrcX)
        srcY = GetCellValue(wsSrc, rSrc, colSrcY)
        srcZ = GetCellValue(wsSrc, rSrc, colSrcZ)
        srcRot = GetCellValue(wsSrc, rSrc, colSrcRot)

        If srcSIS <> "" And srcFuncKey <> "" Then

            Set dictSeen = CreateObject("Scripting.Dictionary")
            lastDefFunctionKey = ""
            startOutRow = outRow

            For rDef = 2 To lastRowDef
                PDPerf_Pulse "mod10_FunctionDevices.Build_Function_Device_Clean [L169]" & " row " & CStr(rDef)

                If Trim(CStr(wsDef.Cells(rDef, colDefCONTROL_FUNCTION_NUMBER).Value)) <> "" Then
                    lastDefFunctionKey = NormalizeFunction(wsDef.Cells(rDef, colDefCONTROL_FUNCTION_NUMBER).Value)
                End If

                defFuncKey = lastDefFunctionKey
                defCONTROL_FUNCTION_TAG = Trim(CStr(wsDef.Cells(rDef, colDefCONTROL_FUNCTION_TAG).Value))
                defBlock = Trim(CStr(wsDef.Cells(rDef, colDefBlock).Value))
                defInput = GetCellValue(wsDef, rDef, colDefInput)
                defOutput = GetCellValue(wsDef, rDef, colDefOutput)
                defSIn = GetCellValue(wsDef, rDef, colDefSIn)
                defSOut = GetCellValue(wsDef, rDef, colDefSOut)

                defPartNum1 = GetCellValue(wsDef, rDef, colDefPartNum1)
                defManufName1 = GetCellValue(wsDef, rDef, colDefManufName1)
                defPartNum2 = GetCellValue(wsDef, rDef, colDefPartNum2)
                defManufName2 = GetCellValue(wsDef, rDef, colDefManufName2)
                defPartNum3 = GetCellValue(wsDef, rDef, colDefPartNum3)
                defManufName3 = GetCellValue(wsDef, rDef, colDefManufName3)
                defPartNum4 = GetCellValue(wsDef, rDef, colDefPartNum4)
                defManufName4 = GetCellValue(wsDef, rDef, colDefManufName4)
                defPartNum5 = GetCellValue(wsDef, rDef, colDefPartNum5)
                defManufName5 = GetCellValue(wsDef, rDef, colDefManufName5)
                defPartNum6 = GetCellValue(wsDef, rDef, colDefPartNum6)
                defManufName6 = GetCellValue(wsDef, rDef, colDefManufName6)
                defPartNum7 = GetCellValue(wsDef, rDef, colDefPartNum7)
                defManufName7 = GetCellValue(wsDef, rDef, colDefManufName7)
                defPartNum8 = GetCellValue(wsDef, rDef, colDefPartNum8)
                defManufName8 = GetCellValue(wsDef, rDef, colDefManufName8)
                defPartNum9 = GetCellValue(wsDef, rDef, colDefPartNum9)
                defManufName9 = GetCellValue(wsDef, rDef, colDefManufName9)
                defPartNum10 = GetCellValue(wsDef, rDef, colDefPartNum10)
                defManufName10 = GetCellValue(wsDef, rDef, colDefManufName10)

                If defFuncKey = srcFuncKey And defBlock <> "" Then

                    rowKey = UCase$(defCONTROL_FUNCTION_TAG) & "|" & UCase$(defBlock) & "|" & _
                             UCase$(defPartNum1) & "|" & UCase$(defManufName1) & "|" & _
                             UCase$(defPartNum2) & "|" & UCase$(defManufName2) & "|" & _
                             UCase$(defPartNum3) & "|" & UCase$(defManufName3) & "|" & _
                             UCase$(defPartNum4) & "|" & UCase$(defManufName4) & "|" & _
                             UCase$(defPartNum5) & "|" & UCase$(defManufName5) & "|" & _
                             UCase$(defPartNum6) & "|" & UCase$(defManufName6) & "|" & _
                             UCase$(defPartNum7) & "|" & UCase$(defManufName7) & "|" & _
                             UCase$(defPartNum8) & "|" & UCase$(defManufName8) & "|" & _
                             UCase$(defPartNum9) & "|" & UCase$(defManufName9) & "|" & _
                             UCase$(defPartNum10) & "|" & UCase$(defManufName10)

                    If Not dictSeen.Exists(rowKey) Then
                        dictSeen.Add rowKey, True

                        wsOut.Cells(outRow, 1).Value = srcSIS & IIf(defCONTROL_FUNCTION_TAG <> "", "-" & defCONTROL_FUNCTION_TAG, "")
                        wsOut.Cells(outRow, 2).Value = srcSIS
                        wsOut.Cells(outRow, 3).Value = wsSrc.Cells(rSrc, colSrcCONTROL_FUNCTION_NUMBER).Value
                        wsOut.Cells(outRow, 4).Value = defCONTROL_FUNCTION_TAG
                        wsOut.Cells(outRow, 5).Value = srcConvType
                        wsOut.Cells(outRow, 6).Value = defBlock
                        wsOut.Cells(outRow, 7).Value = srcArea
                        wsOut.Cells(outRow, 8).Value = srcSwitchGroup
                        wsOut.Cells(outRow, 9).Value = srcX
                        wsOut.Cells(outRow, 10).Value = srcY
                        wsOut.Cells(outRow, 11).Value = srcZ
                        wsOut.Cells(outRow, 12).Value = srcRot
                        wsOut.Cells(outRow, 13).Value = ""
                        wsOut.Cells(outRow, 14).Value = ""
                        wsOut.Cells(outRow, 15).Value = ""
                        wsOut.Cells(outRow, 16).Value = defPartNum1
                        wsOut.Cells(outRow, 17).Value = defManufName1
                        wsOut.Cells(outRow, 18).Value = defPartNum2
                        wsOut.Cells(outRow, 19).Value = defManufName2
                        wsOut.Cells(outRow, 20).Value = defPartNum3
                        wsOut.Cells(outRow, 21).Value = defManufName3
                        wsOut.Cells(outRow, 22).Value = defPartNum4
                        wsOut.Cells(outRow, 23).Value = defManufName4
                        wsOut.Cells(outRow, 24).Value = defPartNum5
                        wsOut.Cells(outRow, 25).Value = defManufName5
                        wsOut.Cells(outRow, 26).Value = defPartNum6
                        wsOut.Cells(outRow, 27).Value = defManufName6
                        wsOut.Cells(outRow, 28).Value = defPartNum7
                        wsOut.Cells(outRow, 29).Value = defManufName7
                        wsOut.Cells(outRow, 30).Value = defPartNum8
                        wsOut.Cells(outRow, 31).Value = defManufName8
                        wsOut.Cells(outRow, 32).Value = defPartNum9
                        wsOut.Cells(outRow, 33).Value = defManufName9
                        wsOut.Cells(outRow, 34).Value = defPartNum10
                        wsOut.Cells(outRow, 35).Value = defManufName10
                        wsOut.Cells(outRow, 36).Value = defInput
                        wsOut.Cells(outRow, 37).Value = defOutput
                        wsOut.Cells(outRow, 38).Value = defSIn
                        wsOut.Cells(outRow, 39).Value = defSOut

                        If FD_HasValue(defInput) Or FD_HasValue(defOutput) Or FD_HasValue(defSIn) Or FD_HasValue(defSOut) Then
                            ioFromDefinition = ioFromDefinition + 1
                        Else
                            ioUnresolved = ioUnresolved + 1
                        End If

                        outRow = outRow + 1
                    End If

                End If

            Next rDef

            'If this control function produced exactly one device row and its FUNCTION DEFINITION
            'IO cells were blank, the parent Step 3A values are unambiguous and may be used.
            If outRow - startOutRow = 1 Then
                usedParentFallback = False

                If Not FD_HasValue(wsOut.Cells(startOutRow, 36).Value) And FD_HasValue(srcInput) Then
                    wsOut.Cells(startOutRow, 36).Value = srcInput
                    usedParentFallback = True
                End If
                If Not FD_HasValue(wsOut.Cells(startOutRow, 37).Value) And FD_HasValue(srcOutput) Then
                    wsOut.Cells(startOutRow, 37).Value = srcOutput
                    usedParentFallback = True
                End If
                If Not FD_HasValue(wsOut.Cells(startOutRow, 38).Value) And FD_HasValue(srcSIn) Then
                    wsOut.Cells(startOutRow, 38).Value = srcSIn
                    usedParentFallback = True
                End If
                If Not FD_HasValue(wsOut.Cells(startOutRow, 39).Value) And FD_HasValue(srcSOut) Then
                    wsOut.Cells(startOutRow, 39).Value = srcSOut
                    usedParentFallback = True
                End If

                If usedParentFallback Then
                    ioParentFallback = ioParentFallback + 1
                    If ioUnresolved > 0 Then ioUnresolved = ioUnresolved - 1
                End If
            End If

        End If

    Next rSrc

    With wsOut
        .rows(1).Font.Bold = True
        .Columns.AutoFit
    End With

    Application.ScreenUpdating = True
    Application.EnableEvents = True
    If Not PDPerf_IsRunning Then Application.Calculation = xlCalculationAutomatic

    MsgBox "FUNCTION DEVICE pd2 sheet created successfully." & vbCrLf & vbCrLf & _
           "Device rows with IO from FUNCTION DEFINITION: " & ioFromDefinition & vbCrLf & _
           "Single-device rows using Step 3A parent IO fallback: " & ioParentFallback & vbCrLf & _
           "Device rows still requiring IO engineering: " & ioUnresolved, vbInformation

End Sub

Private Function FD_HasValue(ByVal v As Variant) As Boolean
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function
    FD_HasValue = (Len(Trim$(CStr(v))) > 0)
End Function

Private Function FindHeaderColumn(ws As Worksheet, headerName As String) As Long
    Dim lastCol As Long, c As Long

    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column

    For c = 1 To lastCol
        If Trim(UCase$(CStr(ws.Cells(1, c).Value))) = Trim(UCase$(headerName)) Then
            FindHeaderColumn = c
            Exit Function
        End If
    Next c

    FindHeaderColumn = 0
End Function

Private Function GetCellValue(ws As Worksheet, rowNum As Long, colNum As Long) As Variant
    If colNum > 0 Then
        GetCellValue = ws.Cells(rowNum, colNum).Value
    Else
        GetCellValue = ""
    End If
End Function

Private Function NormalizeFunction(ByVal v As Variant) As String
    Dim s As String

    s = Trim(CStr(v))

    If s = "" Then
        NormalizeFunction = ""
    ElseIf IsNumeric(s) Then
        NormalizeFunction = CStr(CLng(Val(s)))
    Else
        NormalizeFunction = UCase$(s)
    End If
End Function

