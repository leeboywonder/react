Attribute VB_Name = "mod00_MainDashboard"
Option Explicit

Private Const home As String = "MAIN"
Private Const B03S As String = "Field Device IO ONGEN"
Private Const spec As String = "Specification Devices"

Public Sub Build_Main_Dashboard()
    If PDPerf_IsYielding Then Exit Sub
    ' V3.1 CLEAN REBUILD
    ' Safe dashboard setup only: updates captions and assigns macros to existing V2.3 shapes.
    ' It never deletes/recreates shapes, clears cells, changes dimensions, or runs automatically.
    Dim ws As Worksheet
    Dim oldEvents As Boolean, oldScreen As Boolean

    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    On Error GoTo Fail
    Set ws = ThisWorkbook.Worksheets(home)

    Application.EnableEvents = False
    Application.ScreenUpdating = False

    ' Master labels.
    UI_SetShapeLabel ws, "PD_UI_MASTER_TITLE", "PROJECT DESIGN DEFINITION  |  MASTER ENGINEERING WORKFLOW"
    UI_SetShapeLabel ws, "PD_UI_MASTER_FLOW", "CAD + BOQ  >  DEFINITION  >  POWER CALC <-> DEFINITION  >  B03 IO <-> DEFINITION  >  PD6  >  ONGEN  >  CAD"

    ' Phase 0 - workbook control.
    UI_SetShapeLabel ws, "PD_UI_PHASE_0", "PHASE 0  |  WORKBOOK CONTROL"
    UI_SetShapeButton ws, "PD_UI_P0_0", "Rebind MAIN Buttons", "Build_Main_Dashboard"
    UI_SetShapeButton ws, "PD_UI_P0_1", "Validate Workflow", "Validate_Definition_Workflow"
    UI_SetShapeButton ws, "PD_UI_P0_2", "Refresh Workbook", "UI_RefreshAll"
    UI_SetShapeButton ws, "PD_UI_P0_3", "Worksheet Launcher", "NAV_Open_Worksheet_Launcher"

    ' Phase 1 - CAD + BOQ intake.
    UI_SetShapeLabel ws, "PD_UI_PHASE_1", "PHASE 1  |  CAD + BOQ INTAKE"
    UI_SetShapeButton ws, "PD_UI_P1_0", "1A  Import CAD SIS CSV", "Import_CSV_To_SIS_TAG_EXPORT"
    UI_SetShapeButton ws, "PD_UI_P1_1", "1B  Import BOQ", "BOQ_Import"
    UI_SetShapeButton ws, "PD_UI_P1_2", "1C  Verify CAD vs BOQ", "Verify_SIS_TAG_EXPORT_From_BOQ_v2"
    UI_SetShapeButton ws, "PD_UI_P1_3", "1D  Build SIS TAG PD5", "Build_PD5_From_BOQ"

    ' Phase 2 - PSU / PD4 design.
    UI_SetShapeLabel ws, "PD_UI_PHASE_2", "PHASE 2  |  POWER / PD4 DESIGN"
    UI_SetShapeButton ws, "PD_UI_P2_0", "2A  Estimate PSU + VFD", "Build_SIS_TAG_PD5_Manifest_Using_MotorVoltage"
    UI_SetShapeButton ws, "PD_UI_P2_1", "2B  Generate PD4", "PD4_ESTIMATE"
    UI_SetShapeButton ws, "PD_UI_P2_2", "2C  Fill PD4 Library Blocks", "FillBlockFromLibraryWorkbook"
    UI_SetShapeButton ws, "PD_UI_P2_3", "2D  Export HWE_PSU.csv", "Export_PD4_Estimate_PSU_To_HWE_PSU_CSV"

    ' Ordered workflow requested: 3A, 3B, then 4A-4D, then B03 return flow.
    UI_SetShapeLabel ws, "PD_UI_PHASE_3", "PHASE 3/4/5  |  FUNCTION DEVICE  >  POWER CALC  >  B03 IO"
    UI_SetShapeButton ws, "PD_UI_P3_0", "3A  Generate PD2 Import", "Copy_PD5_To_Import_And_Fill_From_BOQ"
    UI_SetShapeButton ws, "PD_UI_P3_1", "3B  Build Function Devices", "Build_Function_Device_Clean"
    UI_SetShapeButton ws, "PD_UI_P3_2", "4A  FAST Send PD5 To Power Calc", "PowerRT_4A_Send_PD5_FAST"
    UI_SetShapeButton ws, "PD_UI_P3_3", "4B  FAST Build PD6", "PowerRT_4B_Build_PD6_FAST"
    UI_SetShapeButton ws, "PD_UI_P3_4", "4C  FAST Finalize Power Calc Return", "PowerRT_4C_Send_PD6_FAST"
    UI_SetShapeButton ws, "PD_UI_P3_5", "4D  FAST Import Power Return", "PowerRT_4D_Import_Power_FAST"
    UI_SetShapeButton ws, "PD_UI_P3_6", "5A  FAST Update Specification + PD6", "DeviceWF_5A_Update_Specification_FAST"
    UI_SetShapeButton ws, "PD_UI_P3_7", "5B  FAST Build B03 Device Input", "DeviceWF_5B_Build_FieldIO_FAST"

    UI_SetShapeLabel ws, "PD_UI_PHASE_4", "PHASE 5 CONT.  |  B03 HANDOFF + IO LIBRARY"
    UI_SetShapeButton ws, "PD_UI_P4_0", "5C  Send + Run B03 IO Generator", "DeviceWF_5C_Send_Run_B03"
    UI_SetShapeButton ws, "PD_UI_P4_1", "5D  FAST Import B03 Return", "DeviceWF_5D_Import_B03_Return_FAST"
    UI_SetShapeButton ws, "PD_UI_P4_2", "5E  Review / Edit IO Counts", "GoSheet_SpecificationDevices"
    UI_SetShapeButton ws, "PD_UI_P4_3", "5F  Fill IO Library Blocks", "Fill_IO_BlockFromLibraryWorkbook"
    UI_RemoveLegacyPhase2BackfillButton ws
    UI_EnsurePhase5GBackfillButton ws
    UI_SetShapeButton ws, "PD_UI_P4_4", "5G  Backfill IO PSU / Terminals", "Step05G_Backfill_IO_PSU_Terminals"

    UI_SetShapeLabel ws, "PD_UI_PHASE_5", "PHASE 6  |  FINAL PD6 + ONGEN"
    UI_SetShapeButton ws, "PD_UI_P5_0", "6A  Rebuild Final PD6", "Build_PD6_System_Designed_RELEASED"
    UI_SetShapeButton ws, "PD_UI_P5_1", "6B  Apply Power Return", "Fill_PD6_From_PowerCalculation_RELEASED"
    UI_SetShapeButton ws, "PD_UI_P5_2", "6C  Export PD6 CSV To ONGEN", "Export_PD6_Export_System_To_CSV"
    UI_SetShapeButton ws, "PD_UI_P5_3", "6D  Export IO Block CSV", "Export_IOBLOCK_To_CSV"

    UI_SetShapeLabel ws, "PD_UI_PHASE_6", "PHASE 7  |  CAD RETURN + QA"
    UI_SetShapeButton ws, "PD_UI_P6_0", "7A  Export Function Device CSV", "Export_Function_Device_PD2_To_CSV"
    UI_SetShapeButton ws, "PD_UI_P6_1", "7B  Export PD6 AutoCAD CSV", "Export_PD6_Export_System_To_CSV"
    UI_SetShapeButton ws, "PD_UI_P6_2", "7C  Open PD6 System Designed", "GoSheet_PD6_System_Designed"
    UI_SetShapeButton ws, "PD_UI_P6_3", "7D  Final Workflow Validation", "Validate_Definition_Workflow"

    UI_SetShapeLabel ws, "PD_UI_NOTE", "CONTROL RULE: Definition is the master. Phase 2 remains unchanged at 2A/2B/2C/2D. Step 5G backfills the completed B03 IO modules into the existing BUS-2 PSU/terminal assignments after 5F and before Phase 6 final PD6. MAIN geometry remains the V2.3 layout."


    'Phase color theme for a clearer workflow visual.
    UI_ApplyPhaseTheme ws, "PD_UI_PHASE_0", RGB(77, 77, 77), RGB(217, 217, 217), "PD_UI_P0_0", "PD_UI_P0_1", "PD_UI_P0_2", "PD_UI_P0_3"
    UI_ApplyPhaseTheme ws, "PD_UI_PHASE_1", RGB(47, 84, 150), RGB(221, 235, 247), "PD_UI_P1_0", "PD_UI_P1_1", "PD_UI_P1_2", "PD_UI_P1_3"
    UI_ApplyPhaseTheme ws, "PD_UI_PHASE_2", RGB(192, 80, 77), RGB(252, 228, 214), "PD_UI_P2_0", "PD_UI_P2_1", "PD_UI_P2_2", "PD_UI_P2_3"
    UI_ApplyPhaseTheme ws, "PD_UI_PHASE_3", RGB(0, 112, 192), RGB(218, 238, 243), "PD_UI_P3_0", "PD_UI_P3_1", "PD_UI_P3_2", "PD_UI_P3_3", "PD_UI_P3_4", "PD_UI_P3_5", "PD_UI_P3_6", "PD_UI_P3_7"
    UI_ApplyPhaseTheme ws, "PD_UI_PHASE_4", RGB(112, 48, 160), RGB(234, 209, 220), "PD_UI_P4_0", "PD_UI_P4_1", "PD_UI_P4_2", "PD_UI_P4_3", "PD_UI_P4_4"
    UI_ApplyPhaseTheme ws, "PD_UI_PHASE_5", RGB(0, 176, 80), RGB(226, 239, 218), "PD_UI_P5_0", "PD_UI_P5_1", "PD_UI_P5_2", "PD_UI_P5_3"
    UI_ApplyPhaseTheme ws, "PD_UI_PHASE_6", RGB(191, 144, 0), RGB(255, 242, 204), "PD_UI_P6_0", "PD_UI_P6_1", "PD_UI_P6_2", "PD_UI_P6_3"
    UI_ColorShape ws, "PD_UI_MASTER_TITLE", RGB(31, 78, 121), RGB(255, 255, 255), True
    UI_ColorShape ws, "PD_UI_MASTER_FLOW", RGB(221, 235, 247), RGB(31, 31, 31), False
    UI_ColorShape ws, "PD_UI_NOTE", RGB(242, 242, 242), RGB(63, 63, 63), False

    'Keep ONGEN-style worksheet navigation synchronized on all existing PD sheets.
    mod23_WorksheetNavigation.NAV_Install_Worksheet_Navigation_All_Sheets False

SafeExit:
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    Exit Sub
Fail:
    MsgBox "MAIN setup failed. Error " & Err.number & ": " & Err.description, vbExclamation, "V3.1 MAIN Setup"
    Resume SafeExit
End Sub

Private Sub UI_RemoveLegacyPhase2BackfillButton(ByVal ws As Worksheet)
    'Cleanup from the interim 2E concept. Phase 2 must remain 2A-2D only.
    On Error Resume Next
    ws.Shapes("PD_UI_P2_4").Delete
    On Error GoTo 0
End Sub

Private Sub UI_EnsurePhase5GBackfillButton(ByVal ws As Worksheet)
    Dim shp As Shape, p4 As Shape, phase4 As Shape, phase5 As Shape
    Dim newTop As Double, availH As Double, newH As Double

    On Error Resume Next
    Set shp = ws.Shapes("PD_UI_P4_4")
    Set p4 = ws.Shapes("PD_UI_P4_0")
    Set phase4 = ws.Shapes("PD_UI_PHASE_4")
    Set phase5 = ws.Shapes("PD_UI_PHASE_5")
    On Error GoTo 0

    If p4 Is Nothing Or phase4 Is Nothing Or phase5 Is Nothing Then Exit Sub

    newTop = p4.Top + p4.Height + 2
    availH = phase5.Top - newTop - 2
    If availH < 14 Then Exit Sub
    newH = availH
    If newH > 20 Then newH = 20

    If shp Is Nothing Then
        Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, phase4.Left, newTop, phase4.Width, newH)
        shp.name = "PD_UI_P4_4"
    Else
        shp.Left = phase4.Left
        shp.Top = newTop
        shp.Width = phase4.Width
        shp.Height = newH
    End If

    On Error Resume Next
    shp.TextFrame2.MarginLeft = 4
    shp.TextFrame2.MarginRight = 4
    shp.TextFrame2.MarginTop = 1
    shp.TextFrame2.MarginBottom = 1
    shp.TextFrame2.VerticalAnchor = msoAnchorMiddle
    shp.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    shp.TextFrame2.TextRange.Font.Size = 9
    On Error GoTo 0
End Sub

Private Sub UI_ApplyPhaseTheme(ByVal ws As Worksheet, ByVal phaseShape As String, ByVal headerColor As Long, ByVal buttonColor As Long, ParamArray buttonNames() As Variant)
    Dim i As Long
    UI_ColorShape ws, phaseShape, headerColor, RGB(255, 255, 255), True
    For i = LBound(buttonNames) To UBound(buttonNames)
        UI_ColorShape ws, CStr(buttonNames(i)), buttonColor, RGB(31, 31, 31), False
    Next i
End Sub

Private Sub UI_ColorShape(ByVal ws As Worksheet, ByVal shapeName As String, ByVal fillColor As Long, ByVal fontColor As Long, ByVal boldText As Boolean)
    Dim shp As Shape
    On Error Resume Next
    Set shp = ws.Shapes(shapeName)
    On Error GoTo 0
    If shp Is Nothing Then Exit Sub

    On Error Resume Next
    shp.Fill.Visible = msoTrue
    shp.Fill.Solid
    shp.Fill.ForeColor.RGB = fillColor
    shp.line.Visible = msoTrue
    shp.line.ForeColor.RGB = RGB(128, 128, 128)
    shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = fontColor
    shp.TextFrame2.TextRange.Font.Bold = boldText
    If Err.number <> 0 Then
        Err.Clear
        shp.TextFrame.Characters.Font.Color = fontColor
        shp.TextFrame.Characters.Font.Bold = boldText
    End If
    On Error GoTo 0
End Sub

Public Sub Refresh_MAIN_Dashboard_Colors_And_Steps()
    If PDPerf_IsYielding Then Exit Sub
    Build_Main_Dashboard
End Sub

Private Sub UI_SetShapeButton(ByVal ws As Worksheet, ByVal shapeName As String, ByVal caption As String, ByVal macroName As String)
    Dim shp As Shape, wbName As String
    On Error Resume Next
    Set shp = ws.Shapes(shapeName)
    On Error GoTo 0
    If shp Is Nothing Then Exit Sub

    wbName = Replace(ThisWorkbook.name, "'", "''")
    On Error Resume Next
    shp.OnAction = "'" & wbName & "'!" & PDPerf_EntryFor(macroName)
    shp.TextFrame2.TextRange.Text = caption
    If Err.number <> 0 Then
        Err.Clear
        shp.TextFrame.Characters.Text = caption
    End If
    On Error GoTo 0
End Sub

Private Sub UI_SetShapeLabel(ByVal ws As Worksheet, ByVal shapeName As String, ByVal caption As String)
    Dim shp As Shape
    On Error Resume Next
    Set shp = ws.Shapes(shapeName)
    On Error GoTo 0
    If shp Is Nothing Then Exit Sub

    On Error Resume Next
    shp.OnAction = vbNullString
    shp.TextFrame2.TextRange.Text = caption
    If Err.number <> 0 Then
        Err.Clear
        shp.TextFrame.Characters.Text = caption
    End If
    On Error GoTo 0
End Sub

Public Sub Validate_Definition_Workflow()
    If PDPerf_IsYielding Then Exit Sub
    Dim req As Variant, s As Variant, msg As String, bad As Long
    req = Array("MAIN", "SIS_TAG_EXPORT", "BOQ", "SIS_TAG_PD5", "PD6 System Designed")
    For Each s In req
        PDPerf_Pulse "mod00_MainDashboard.Validate_Definition_Workflow [L227]"
        If Not UI_WorksheetExists(CStr(s)) Then msg = msg & vbCrLf & "- Missing worksheet: " & s: bad = bad + 1
    Next s
    If bad = 0 Then
        MsgBox "Definition workflow structure is ready." & vbCrLf & vbCrLf & _
               "Master: Definition" & vbCrLf & "B03 interface: " & B03S & " -> IO_DEVICE_LIST" & vbCrLf & _
               "Power interface: PD5_IMPORT / Export PD6 Designed Definition" & vbCrLf & _
               "ONGEN interface: PD6 CSV + B03 IO output", vbInformation, "Definition Workflow"
    Else
        MsgBox "Workflow validation found " & bad & " issue(s):" & msg, vbExclamation, "Definition Workflow"
    End If
End Sub

Public Sub DEF_Update_Spec_From_PD2()
    If PDPerf_IsYielding Then Exit Sub
    'Legacy compatibility entry point. V4.6 uses the bulk single-stage 5A routine.
    mod20_DeviceWorkflow.DeviceWF_5A_Update_Specification_FAST
End Sub
Public Sub DEF_Build_B03_Input()
    If PDPerf_IsYielding Then Exit Sub
    'Legacy compatibility entry point. V4.6 uses the bulk single-stage 5B routine.
    mod20_DeviceWorkflow.DeviceWF_5B_Build_FieldIO_FAST
End Sub
Public Sub DEF_Send_B03_Input()
    If PDPerf_IsYielding Then Exit Sub
    'Legacy compatibility entry point. V4.6 5C only performs the external B03 handoff.
    mod20_DeviceWorkflow.DeviceWF_5C_Send_Run_B03
End Sub
Public Sub DEF_Import_B03_Return()
    If PDPerf_IsYielding Then Exit Sub
    'Legacy compatibility entry point. V4.6 uses the bulk single-stage 5D import.
    mod20_DeviceWorkflow.DeviceWF_5D_Import_B03_Return_FAST
End Sub

Public Sub DEF_Export_PD5_To_Power()
    If PDPerf_IsYielding Then Exit Sub
    'Compatibility entry point: use the optimized Phase 4A engine.
    mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST
End Sub

Private Function FindBestPD5SourceRow(ByVal s As Worksheet, ByVal seq As String) As Long
    Dim r As Long, cSeq As Long, cand As Long, b As String
    cSeq = FindHdr(s, "SIS_SEQUENCE"): If cSeq = 0 Or Len(Trim$(seq)) = 0 Then Exit Function
    For r = 2 To LastDataRow(s, cSeq)
        PDPerf_Pulse "mod00_MainDashboard.FindBestPD5SourceRow [L265]" & " row " & CStr(r)
        If StrComp(Trim$(CStr(s.Cells(r, cSeq).Value)), Trim$(seq), vbTextCompare) = 0 Then
            If cand = 0 Then cand = r
            b = UCase$(Trim$(CStr(CellHdr(s, r, "BLOCK_NAME"))))
            If InStr(1, b, "ONGEN_MECH", vbTextCompare) > 0 Then FindBestPD5SourceRow = r: Exit Function
        End If
    Next r
    FindBestPD5SourceRow = cand
End Function

Private Function CalcLoad(ByVal s As Worksheet, ByVal r As Long) As Variant
    Dim st As String, p As Double, v As Double, q As Double
    st = UCase(Trim(CStr(CellHdr(s, r, "System Type"))))
    If InStr(st, "400V") > 0 Or InStr(st, "480V") > 0 Or st = "B400V" Then CalcLoad = 1.6: Exit Function
    If InStr(st, "24V") > 0 Then
        p = Num(CellHdr(s, r, "Motor Power (Main Drive)")): v = Num(CellHdr(s, r, "Motor Voltage (Main Drive)")): q = Num(CellHdr(s, r, "Total Qty of Drives"))
        If v <> 0 Then CalcLoad = p * 1000# / v * q Else CalcLoad = ""
    Else: CalcLoad = ""
    End If
End Function

Private Function MakeControlID(ByVal a As Variant, ByVal sw As Variant, ByVal seq As Variant, ByVal typ As Variant) As String
    Dim b As String, t As String: b = Trim(CStr(a)) & "-" & Trim(CStr(sw)) & "-" & Trim(CStr(seq)): t = UCase(Trim(CStr(typ)))
    Select Case t: Case "MC": MakeControlID = b & "-K1": Case "SCANNER", "SCN": MakeControlID = b & "-K70": Case "VFD": MakeControlID = b & "-K7": Case "IO/D": MakeControlID = b & "-K4": Case "IO/S": MakeControlID = b & "-K5": Case Else: MakeControlID = b: End Select
End Function

Private Function Num(ByVal v As Variant) As Double
    If IsNumeric(v) Then
        Num = CDbl(v)
    Else
        Num = 0
    End If
End Function
Private Function EnsureSheet(ByVal nm As String) As Worksheet
    Set EnsureSheet = GetSheetCI(nm)
    If EnsureSheet Is Nothing Then
        Set EnsureSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        EnsureSheet.name = nm
        mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation EnsureSheet
    End If
End Function
Private Function GetSheetCI(ByVal nm As String) As Worksheet
    Dim w As Worksheet
    For Each w In ThisWorkbook.Worksheets
        PDPerf_Pulse "mod00_MainDashboard.GetSheetCI [L308]"
        If StrComp(Trim$(w.name), Trim$(nm), vbTextCompare) = 0 Then
            Set GetSheetCI = w
            Exit Function
        End If
    Next w
End Function

Private Function FindHdr(ByVal w As Worksheet, ByVal h As String) As Long
    Dim c As Long
    Dim z As Long
    If w Is Nothing Then Exit Function
    z = w.Cells(1, w.Columns.count).End(xlToLeft).Column
    For c = 1 To z
        If Norm(w.Cells(1, c).Value) = Norm(h) Then
            FindHdr = c
            Exit Function
        End If
    Next c
End Function
Private Function CellHdr(ByVal w As Worksheet, ByVal r As Long, ByVal h As String) As Variant
    Dim c As Long: c = FindHdr(w, h): If c > 0 Then CellHdr = w.Cells(r, c).Value Else CellHdr = ""
End Function
Private Function LastDataRow(ByVal w As Worksheet, ByVal c As Long) As Long
    If c < 1 Then
        c = 1
    End If
    LastDataRow = w.Cells(w.rows.count, c).End(xlUp).Row
End Function
Private Function Norm(ByVal v As Variant) As String
    Norm = UCase(Trim(CStr(v))): Norm = Replace(Norm, "_", " "): Norm = Replace(Norm, "-", " "): Norm = Replace(Norm, "  ", " ")
End Function

Public Function UI_WorksheetExists(ByVal sheetName As String) As Boolean
    Dim w As Worksheet: Set w = GetSheetCI(sheetName): UI_WorksheetExists = Not (w Is Nothing)
End Function
Public Function UI_IsWorkflowSheet(ByVal sheetName As String) As Boolean
    UI_IsWorkflowSheet = (UCase$(sheetName) <> "UI_CONFIG" And UCase$(sheetName) <> "MAIN")
End Function
Public Function UI_GetWorkflowGroup(ByVal sheetName As String) As String
    Dim n As String: n = UCase(sheetName)
    If InStr(n, "PD6") > 0 Then
        UI_GetWorkflowGroup = "Phase 5 - PD6 / ONGEN"
    ElseIf InStr(n, "IO") > 0 Or InStr(n, "FUNCTION") > 0 Or InStr(n, "SPEC") > 0 Then
        UI_GetWorkflowGroup = "Phase 3 - B03 IO"
    ElseIf InStr(n, "PD4") > 0 Or InStr(n, "PSU") > 0 Then
        UI_GetWorkflowGroup = "Phase 2 - Power"
    Else
        UI_GetWorkflowGroup = "Definition"
    End If
End Function
Private Sub GoS(ByVal nm As String)
    If UI_WorksheetExists(nm) Then
        ThisWorkbook.Worksheets(nm).Activate
    End If
End Sub
Public Sub GoSheet_SIS_TAG_EXPORT()
    If PDPerf_IsYielding Then Exit Sub
    GoS "SIS_TAG_EXPORT"
End Sub
Public Sub GoSheet_BOQ()
    If PDPerf_IsYielding Then Exit Sub
    GoS "BOQ"
End Sub
Public Sub GoSheet_SIS_TAG_PD5()
    If PDPerf_IsYielding Then Exit Sub
    GoS "SIS_TAG_PD5"
End Sub
Public Sub GoSheet_SpecificationDevices()
    If PDPerf_IsYielding Then Exit Sub
    GoS spec
End Sub
Public Sub GoSheet_PD6_System_Designed()
    If PDPerf_IsYielding Then Exit Sub
    GoS "PD6 System Designed"
End Sub
Public Sub Go_PD0()
    If PDPerf_IsYielding Then Exit Sub
    GoS "FUNCTION DEFINITION"
End Sub
Public Sub Go_PD1()
    If PDPerf_IsYielding Then Exit Sub
    GoS "SIS_TAG_EXPORT"
End Sub
Public Sub Go_PD2()
    If PDPerf_IsYielding Then Exit Sub
    GoS "SIS_TAG_IMPORT_PD2"
End Sub
Public Sub Go_PD3()
    If PDPerf_IsYielding Then Exit Sub
    GoS spec
End Sub
Public Sub Go_PD4()
    If PDPerf_IsYielding Then Exit Sub
    GoS "PD4_Estimate_PSU"
End Sub
Public Sub Go_PD5()
    If PDPerf_IsYielding Then Exit Sub
    GoS "SIS_TAG_PD5"
End Sub
Public Sub Go_PD6()
    If PDPerf_IsYielding Then Exit Sub
    GoS "PD6 System Designed"
End Sub
Public Sub Go_Reports()
    If PDPerf_IsYielding Then Exit Sub
    mod01_UI.UI_ShowLauncher
End Sub
Public Sub Run_Import_SIS_TAG()
    If PDPerf_IsYielding Then Exit Sub
    mod02_ImportCAD.Import_CSV_To_SIS_TAG_EXPORT
End Sub
Public Sub Run_Import_BOQ_INTERROLL()
    If PDPerf_IsYielding Then Exit Sub
    mod03_ImportBOQ.BOQ_Import
End Sub
Public Sub Run_Check_SIS_TAG_With_BOQ()
    If PDPerf_IsYielding Then Exit Sub
    mod04_VerifyCAD_BOQ.Verify_SIS_TAG_EXPORT_From_BOQ_v2
End Sub
Public Sub Run_Create_PD5()
    If PDPerf_IsYielding Then Exit Sub
    mod05_BuildPD5.Build_PD5_From_BOQ
End Sub
Public Sub Run_Estimate_PSU_VFD_Location()
    If PDPerf_IsYielding Then Exit Sub
    mod06_EstimatePSU.Build_SIS_TAG_PD5_Manifest_Using_MotorVoltage
End Sub
Public Sub Run_Create_PD4()
    If PDPerf_IsYielding Then Exit Sub
    mod07_PD4Estimate.PD4_ESTIMATE
End Sub
Public Sub Run_Add_Block_Library_Into_PD4()
    If PDPerf_IsYielding Then Exit Sub
    mod08_PSUBlockLibrary.FillBlockFromLibraryWorkbook
End Sub
Public Sub Run_Create_CSV_Export_VFD_PSU()
    If PDPerf_IsYielding Then Exit Sub
    mod07_PD4Estimate.Export_PD4_Estimate_PSU_To_HWE_PSU_CSV
End Sub
Public Sub Run_ReImport_SIS_TAG()
    If PDPerf_IsYielding Then Exit Sub
    mod02_ImportCAD.Import_CSV_To_SIS_TAG_EXPORT
End Sub
Public Sub Run_Redo_PD5()
    If PDPerf_IsYielding Then Exit Sub
    mod05_BuildPD5.Build_PD5_From_BOQ
End Sub
Public Sub Run_Generate_PD2()
    If PDPerf_IsYielding Then Exit Sub
    mod09_GeneratePD2.Copy_PD5_To_Import_And_Fill_From_BOQ
End Sub
Public Sub Run_Create_Device_Function_With_AutoCAD_Library()
    If PDPerf_IsYielding Then Exit Sub
    mod10_FunctionDevices.Build_Function_Device_Clean
End Sub
Public Sub Run_Create_Device_Export()
    If PDPerf_IsYielding Then Exit Sub
    mod17_FunctionCSV.Export_Function_Device_PD2_To_CSV
End Sub
Public Sub Run_PD2_To_Specification_Devices()
    If PDPerf_IsYielding Then Exit Sub
    mod20_DeviceWorkflow.DeviceWF_5A_Update_Specification_FAST
End Sub
Public Sub Run_Import_Device_Panel_From_Organizer()
    If PDPerf_IsYielding Then Exit Sub
    mod15_IOReturnMerge.IOReturn_Update_IO_DEVICE_EM_From_PD2_And_FunctionDefinition
End Sub
Public Sub Run_Export_To_ONGEN()
    If PDPerf_IsYielding Then Exit Sub
    mod20_DeviceWorkflow.DeviceWF_5B_Build_FieldIO_FAST
End Sub
Public Sub Run_Add_IO_Block_Coordinate_And_Part()
    If PDPerf_IsYielding Then Exit Sub
    mod15_IOReturnMerge.IOReturn_Update_IO_DEVICE_EM_From_PD2_And_FunctionDefinition
End Sub
Public Sub Run_Add_Block_Library_Into_EM_Device()
    If PDPerf_IsYielding Then Exit Sub
    mod16_IOBlockLibrary.Fill_IO_BlockFromLibraryWorkbook
End Sub
Public Sub Run_IO_Block_EM_Export_CSV_File()
    If PDPerf_IsYielding Then Exit Sub
    mod18_IOBlockCSV.Export_IOBLOCK_To_CSV
End Sub
Public Sub Run_Export_To_GEN_24V()
    If PDPerf_IsYielding Then Exit Sub
    mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST
End Sub

Public Sub Export_SIS_TAG_PD5_To_PD5_IMPORT()
    If PDPerf_IsYielding Then Exit Sub
    mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST
End Sub

Public Sub Run_Build_PD6()
    If PDPerf_IsYielding Then Exit Sub
    mod12_BuildPD6.Build_PD6_System_Designed_RELEASED
End Sub
Public Sub Run_Fill_PD6_Power()
    If PDPerf_IsYielding Then Exit Sub
    mod11_PowerRoundTrip.PowerRT_4D_Import_Power_FAST
End Sub
Public Sub Run_Export_PD6_Definition()
    If PDPerf_IsYielding Then Exit Sub
    mod11_PowerRoundTrip.PowerRT_4C_Send_PD6_FAST
End Sub
Public Sub Run_Export_PD6_AutoCAD_CSV()
    If PDPerf_IsYielding Then Exit Sub
    mod19_PD6CSV.Export_PD6_Export_System_To_CSV
End Sub

' ================================================================
' V2.4.3 LEGACY MAIN BUTTON COMPATIBILITY WRAPPERS
' These names existed on the V2.3 MAIN dashboard. Keep them public so
' the physical V2.3 button layout can remain unchanged.
' ================================================================
Public Sub Copy_FunctionDevicePD2_To_SpecificationDevices()
    If PDPerf_IsYielding Then Exit Sub
    mod20_DeviceWorkflow.DeviceWF_5A_Update_Specification_FAST
End Sub

Public Sub Copy_SpecificationDevices_To_FieldDeviceIOONGEN()
    If PDPerf_IsYielding Then Exit Sub
    mod20_DeviceWorkflow.DeviceWF_5B_Build_FieldIO_FAST
End Sub

Public Sub Copy_FieldDeviceIOONGEN_To_IO_DEVICE_LIST()
    If PDPerf_IsYielding Then Exit Sub
    mod20_DeviceWorkflow.DeviceWF_5C_Send_Run_B03
End Sub

