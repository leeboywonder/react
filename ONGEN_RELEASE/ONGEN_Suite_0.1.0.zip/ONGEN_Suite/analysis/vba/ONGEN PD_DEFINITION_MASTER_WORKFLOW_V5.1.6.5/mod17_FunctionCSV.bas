Attribute VB_Name = "mod17_FunctionCSV"
Option Explicit

'==========================================================
' Macro Name : Export_Function_Device_PD2_To_CSV
'
' Purpose:
'   Export the existing EM_Hardware_import CSV, now including:
'       "FUNCTION DEVICE pd2"
'       "PD4_Estimate_PSU"
'       "IO DEVICE EM"
'
' Existing Mod17 behavior is preserved:
'   - One EM_Hardware_import.csv output
'   - Same public macro name used by mod00
'   - Selected output columns only
'   - Values only
'   - Existing mod21_CSVTraceability call retained
'   - Existing Save As workflow retained
'
' Added Step 7A behavior:
'   - Refresh HANDLE, X, Y, Z, ROTATION_DEG from SIS_TAG_EXPORT
'   - Include PSU and IO-device rows in the same EM_Hardware_import output
'   - Fill Conveyor Type from SIS_TAG_EXPORT first, then BOQ by LPN when possible
'   - Conveyor Type is optional and never blocks the export
'   - HANDLE remains literal text from SIS_TAG_EXPORT
'   - Geometry is never invented; unmatched rows keep existing values
'
' CAD matching priority:
'   1. Exact SIS_SEQUENCE/SEQUENCE + TYPE when possible
'   2. Exact SIS_SEQUENCE/SEQUENCE
'   3. Progressive SIS parent fallback (1065-01B-B -> 1065-01B -> 1065)
'   4. First-four-digit family fallback when no literal parent exists
'   5. Unique normalized base sequence + TYPE
'
' Requested Output Headers:
'   Sequence
'   TYPE
'   Conveyor Type
'   BLOCK
'   AREA_NUMBER
'   SWITCHGROUP
'   x
'   y
'   z
'   ROTATION_DEG
'   Scale
'   SideGAP
'   SideClearance
'   PART_NUM_1 / MANUF_NAME_1 through PART_NUM_5 / MANUF_NAME_5
'   SIS_SEQUENCE
'   HANDLE
'==========================================================

Public Sub Export_Function_Device_PD2_To_CSV()
    If PDPerf_IsYielding Then Exit Sub

    Dim wsFunc As Worksheet
    Dim wsPSU As Worksheet
    Dim wsIO As Worksheet
    Dim wsCAD As Worksheet
    Dim wsBOQ As Worksheet

    Dim wbNew As Workbook
    Dim wsNew As Worksheet
    Dim savePath As Variant

    Dim specs As Collection
    Dim spec As Variant
    Dim outArr() As Variant
    Dim totalRows As Long
    Dim outRow As Long
    Dim outCol As Long
    Dim r As Long

    Dim cadExact As Object
    Dim cadTyped As Object
    Dim cadBaseTyped As Object
    Dim boqConv As Object

    Dim oldScreenUpdating As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldCalc As XlCalculation

    Dim funcMatched As Long, funcUnmatched As Long
    Dim psuMatched As Long, psuUnmatched As Long
    Dim ioMatched As Long, ioUnmatched As Long

    On Error GoTo ErrHandler

    Set wsFunc = GetSheetSafe("FUNCTION DEVICE pd2")
    Set wsPSU = GetSheetSafe("PD4_Estimate_PSU")
    Set wsIO = GetSheetSafe("IO DEVICE EM")
    Set wsCAD = GetSheetSafe("SIS_TAG_EXPORT")
    Set wsBOQ = GetSheetSafe("BOQ")

    If wsFunc Is Nothing Then
        MsgBox "Worksheet 'FUNCTION DEVICE pd2' not found.", vbCritical
        Exit Sub
    End If

    If wsPSU Is Nothing Then
        MsgBox "Worksheet 'PD4_Estimate_PSU' not found. Run the PSU estimate step first.", vbCritical
        Exit Sub
    End If

    If wsIO Is Nothing Then
        MsgBox "Worksheet 'IO DEVICE EM' not found. Run the IO-device build first.", vbCritical
        Exit Sub
    End If

    If wsCAD Is Nothing Then
        MsgBox "Worksheet 'SIS_TAG_EXPORT' not found. Import the AutoCAD SIS_TAG_EXPORT before Step 7A.", vbCritical
        Exit Sub
    End If

    oldScreenUpdating = Application.ScreenUpdating
    oldDisplayAlerts = Application.DisplayAlerts
    oldEnableEvents = Application.EnableEvents
    oldCalc = Application.Calculation

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Application.StatusBar = "Step 7A: indexing SIS_TAG_EXPORT..."

    BuildCADMaps wsCAD, cadExact, cadTyped, cadBaseTyped

    Set boqConv = CreateObject("Scripting.Dictionary")
    boqConv.CompareMode = vbTextCompare
    If Not wsBOQ Is Nothing Then BuildBOQConveyorMap wsBOQ, boqConv

    'Refresh the actual workbook sheets first so Step 7A data is visible in Excel.
    Application.StatusBar = "Step 7A: refreshing FUNCTION DEVICE pd2 CAD fields..."
    RefreshSourceSheet wsFunc, cadExact, cadTyped, cadBaseTyped, boqConv, funcMatched, funcUnmatched

    Application.StatusBar = "Step 7A: refreshing PD4_Estimate_PSU CAD fields..."
    RefreshSourceSheet wsPSU, cadExact, cadTyped, cadBaseTyped, boqConv, psuMatched, psuUnmatched

    Application.StatusBar = "Step 7A: refreshing IO DEVICE EM CAD fields..."
    RefreshSourceSheet wsIO, cadExact, cadTyped, cadBaseTyped, boqConv, ioMatched, ioUnmatched

    Set specs = New Collection

    'Output Header, source aliases.
    AddExportField specs, "SEQUENCE", "SEQUENCE", "SIS_SEQUENCE", "DEVICE NAME"
    AddExportField specs, "TYPE", "CONTROL_FUNCTION_TAG", "TYPE", "ITEM TYPE"
    AddExportField specs, "Conveyor Type", "Conveyor Type", "CONVEYOR_TYPE"
    AddExportField specs, "BLOCK", "BLOCK", "Block", "BLOCK_NAME", "Block Name"
    AddExportField specs, "BLOCK_NAME", "BLOCK_NAME", "Block Name", "BLOCK"
    AddExportField specs, "AREA_NUMBER", "AREA_NUMBER", "Area Number"
    AddExportField specs, "SWITCHGROUP", "SWITCHGROUP", "SwitchGroup", "Switch Group"
    AddExportField specs, "x", "x"
    AddExportField specs, "y", "y"
    AddExportField specs, "z", "z"
    AddExportField specs, "ROTATION_DEG", "ROTATION_DEG", "Rotation Deg", "Rotation_deg"
    AddExportField specs, "Scale", "Scale", "SCALE_X"
    AddExportField specs, "SideGAP", "SideGAP", "Side Gap"
    AddExportField specs, "SideClearance", "SideClearance", "Side Clearance"

    AddExportField specs, "PART_NUM_1", "PART_NUM_1"
    AddExportField specs, "MANUF_NAME_1", "MANUF_NAME_1"
    AddExportField specs, "PART_NUM_2", "PART_NUM_2"
    AddExportField specs, "MANUF_NAME_2", "MANUF_NAME_2"
    AddExportField specs, "PART_NUM_3", "PART_NUM_3"
    AddExportField specs, "MANUF_NAME_3", "MANUF_NAME_3"
    AddExportField specs, "PART_NUM_4", "PART_NUM_4"
    AddExportField specs, "MANUF_NAME_4", "MANUF_NAME_4"
    AddExportField specs, "PART_NUM_5", "PART_NUM_5"
    AddExportField specs, "MANUF_NAME_5", "MANUF_NAME_5"
    AddExportField specs, "PART_NUM_6", "PART_NUM_6"
    AddExportField specs, "MANUF_NAME_6", "MANUF_NAME_6"
    AddExportField specs, "PART_NUM_7", "PART_NUM_7"
    AddExportField specs, "MANUF_NAME_7", "MANUF_NAME_7"
    AddExportField specs, "PART_NUM_8", "PART_NUM_8"
    AddExportField specs, "MANUF_NAME_8", "MANUF_NAME_8"
    AddExportField specs, "PART_NUM_9", "PART_NUM_9"
    AddExportField specs, "MANUF_NAME_9", "MANUF_NAME_9"
    AddExportField specs, "PART_NUM_10", "PART_NUM_10"
    AddExportField specs, "MANUF_NAME_10", "MANUF_NAME_10"

    'Existing traceability field retained.
    AddExportField specs, "SIS_SEQUENCE", "SIS_SEQUENCE", "SEQUENCE", "DEVICE NAME"

    'Requested CAD traceability field.
    AddExportField specs, "HANDLE", "HANDLE"

    totalRows = DataRowCount(wsFunc) + DataRowCount(wsPSU) + DataRowCount(wsIO)

    If totalRows = 0 Then
        MsgBox "No Step 7A rows were found on FUNCTION DEVICE pd2, PD4_Estimate_PSU, or IO DEVICE EM.", vbExclamation
        GoTo CleanExit
    End If

    Set wbNew = Workbooks.Add(xlWBATWorksheet)
    Set wsNew = wbNew.Worksheets(1)
    wsNew.name = "EM_Hardware_import"

    ReDim outArr(1 To totalRows + 1, 1 To specs.count)

    outCol = 1
    For Each spec In specs
        PDPerf_Pulse "mod17_FunctionCSV.Export_Function_Device_PD2_To_CSV [L204]"
        outArr(1, outCol) = CStr(spec(0))
        outCol = outCol + 1
    Next spec

    outRow = 1

    'Keep the original FUNCTION DEVICE pd2 rows first.
    AppendSheetToOutput wsFunc, specs, outArr, outRow

    'Then append PSU rows.
    AppendSheetToOutput wsPSU, specs, outArr, outRow

    'Then append IO-device rows.
    AppendSheetToOutput wsIO, specs, outArr, outRow

    'HANDLE must remain literal text in the generated EM_Hardware_import workbook.
    Dim outHandleCol As Long
    outHandleCol = FindOutputSpecIndex(specs, "HANDLE")
    If outHandleCol > 0 Then wsNew.Columns(outHandleCol).NumberFormat = "@"

    wsNew.Range("A1").Resize(outRow, specs.count).Value = outArr

    'Preserve the existing Mod17 physical-traceability post-processing.
    mod23_WorksheetNavigation.NAV_Remove_Navigation_Controls wsNew

    mod21_CSVTraceability.CSVTrace_EnsureTraceColumns wsNew, _
        Array("SIS_SEQUENCE"), Array("SEQUENCE"), Array("LPN")

    wsNew.rows(1).Font.Bold = True
    wsNew.UsedRange.Columns.AutoFit

    savePath = Application.GetSaveAsFilename( _
                InitialFileName:="EM_Hardware_import.csv", _
                FileFilter:="CSV Files (*.csv), *.csv")

    If savePath <> False Then

        wbNew.SaveAs Filename:=CStr(savePath), _
                     FileFormat:=xlCSVUTF8

        MsgBox "CSV exported successfully:" & vbCrLf & CStr(savePath) & vbCrLf & vbCrLf & _
               "FUNCTION DEVICE pd2 CAD matches: " & funcMatched & _
               " | unmatched: " & funcUnmatched & vbCrLf & _
               "PD4_Estimate_PSU CAD matches: " & psuMatched & _
               " | unmatched: " & psuUnmatched & vbCrLf & _
               "IO DEVICE EM CAD matches: " & ioMatched & _
               " | unmatched: " & ioUnmatched & vbCrLf & vbCrLf & _
               "HANDLE, X, Y, Z, and ROTATION_DEG were refreshed from SIS_TAG_EXPORT where matched." & vbCrLf & _
               "Conveyor Type was filled from CAD/BOQ where possible.", vbInformation

    Else

        wbNew.Close SaveChanges:=False
        MsgBox "Export cancelled.", vbExclamation

    End If

CleanExit:
    Application.StatusBar = False
    Application.DisplayAlerts = oldDisplayAlerts
    Application.ScreenUpdating = oldScreenUpdating
    Application.EnableEvents = oldEnableEvents
    Application.Calculation = oldCalc
    Exit Sub

ErrHandler:
    On Error Resume Next
    If Not wbNew Is Nothing Then wbNew.Close SaveChanges:=False
    Application.StatusBar = False
    Application.DisplayAlerts = oldDisplayAlerts
    Application.ScreenUpdating = oldScreenUpdating
    Application.EnableEvents = oldEnableEvents
    Application.Calculation = oldCalc
    On Error GoTo 0

    MsgBox "Export failed:" & vbCrLf & Err.description, vbCritical
End Sub

'==========================================================
' Append one source sheet into the existing EM_Hardware_import
' output contract. Missing optional fields export blank.
'==========================================================
Private Sub AppendSheetToOutput(ByVal ws As Worksheet, ByVal specs As Collection, _
                                ByRef outArr() As Variant, ByRef outRow As Long)

    Dim lastRow As Long
    Dim r As Long
    Dim outCol As Long
    Dim srcCol As Long
    Dim spec As Variant

    lastRow = LastUsedRow(ws)
    If lastRow < 2 Then Exit Sub

    For r = 2 To lastRow
        PDPerf_Pulse "mod17_FunctionCSV.AppendSheetToOutput [L299]" & " row " & CStr(r)
        If RowHasData(ws, r) Then
            outRow = outRow + 1
            outCol = 1

            For Each spec In specs
                PDPerf_Pulse "mod17_FunctionCSV.AppendSheetToOutput [L304]"
                srcCol = FindHeaderCol(ws, spec)

                If srcCol > 0 Then
                    If NormalizeHeader(CStr(spec(0))) = "HANDLE" Then
                        outArr(outRow, outCol) = HandleTextSafe(ws, r, srcCol)
                    Else
                        outArr(outRow, outCol) = ws.Cells(r, srcCol).Value
                    End If
                Else
                    'TYPE needs a sensible fixed fallback for sheets whose
                    'device identity is implicit.
                    If NormalizeHeader(CStr(spec(0))) = "TYPE" Then
                        If StrComp(ws.name, "PD4_Estimate_PSU", vbTextCompare) = 0 Then
                            outArr(outRow, outCol) = "PSU"
                        End If
                    End If
                End If

                outCol = outCol + 1
            Next spec
        End If
    Next r
End Sub

'==========================================================
' Refresh HANDLE / X / Y / Z / ROTATION_DEG / LPN /
' Conveyor Type on one Step 7A source sheet.
'==========================================================
Private Sub RefreshSourceSheet(ByVal ws As Worksheet, _
                               ByVal cadExact As Object, _
                               ByVal cadTyped As Object, _
                               ByVal cadBaseTyped As Object, _
                               ByVal boqConv As Object, _
                               ByRef matched As Long, _
                               ByRef unmatched As Long)

    Dim cSeq As Long, cType As Long
    Dim cHandle As Long, cX As Long, cY As Long, cZ As Long, cRot As Long
    Dim cLPN As Long, cConv As Long
    Dim lastRow As Long, r As Long
    Dim seq As String, typ As String, base As String, key As String
    Dim rec As Variant
    Dim found As Boolean
    Dim lpn As String

    cSeq = FindHeaderByAliases(ws, Array("SIS_SEQUENCE", "SEQUENCE", "DEVICE NAME"))
    cType = FindHeaderByAliases(ws, Array("TYPE", "ITEM TYPE", "CONTROL_FUNCTION_TAG"))

    If cSeq = 0 Then
        Err.Raise vbObjectError + 7171, , _
                  "Worksheet '" & ws.name & "' is missing SIS_SEQUENCE / SEQUENCE."
    End If

    cHandle = EnsureHeader(ws, "HANDLE")
    ws.Columns(cHandle).NumberFormat = "@"
    cX = EnsureHeader(ws, "X")
    cY = EnsureHeader(ws, "Y")
    cZ = EnsureHeader(ws, "Z")
    cRot = EnsureHeader(ws, "ROTATION_DEG")
    cLPN = EnsureHeader(ws, "LPN")
    cConv = EnsureHeader(ws, "Conveyor Type")
    Dim cBlockName As Long
    cBlockName = EnsureHeader(ws, "BLOCK_NAME")

    lastRow = LastUsedRow(ws)

    For r = 2 To lastRow
        PDPerf_Pulse "mod17_FunctionCSV.RefreshSourceSheet [L371]" & " row " & CStr(r)
        If RowHasData(ws, r) Then
            seq = Trim$(CStrSafe(ws.Cells(r, cSeq).Value))
            If cType > 0 Then typ = Trim$(CStrSafe(ws.Cells(r, cType).Value)) Else typ = vbNullString

            'FUNCTION DEVICE pd2 TYPE is CONTROL_FUNCTION_TAG, not a CAD TYPE.
            'Do not force typed matching for that sheet.
            If StrComp(ws.name, "FUNCTION DEVICE pd2", vbTextCompare) = 0 Then
                typ = vbNullString
            End If

            found = False

            If Len(seq) > 0 Then
                If Len(typ) > 0 Then
                    key = NormKey(seq) & "|" & NormType(typ)
                    If cadTyped.Exists(key) Then
                        rec = cadTyped(key)
                        found = True
                    End If
                End If

                If Not found Then
                    key = NormKey(seq)
                    If cadExact.Exists(key) Then
                        rec = cadExact(key)
                        found = True
                    End If
                End If

                'Progressive parent SIS fallback:
                'Examples:
                '  1065-01B-B   -> 1065-01B -> 1065
                '  1065-01B-PBL -> 1065-01B -> 1065
                '  1065-PSU     -> 1065
                'This is only used after the full SIS sequence fails.
                If Not found Then
                    rec = FindProgressiveCADRecord(seq, cadExact)
                    If IsArray(rec) Then found = True
                End If

                If Not found And Len(typ) > 0 Then
                    base = BaseSequence(seq, typ)
                    key = NormKey(base) & "|" & NormType(typ)

                    If cadBaseTyped.Exists(key) Then
                        If IsArray(cadBaseTyped(key)) Then
                            rec = cadBaseTyped(key)
                            found = True
                        End If
                    End If
                End If
            End If

            If found Then
                'CAD is authoritative only when the CAD field itself is populated.
                If Usable(rec(0)) Then
                    ws.Cells(r, cHandle).NumberFormat = "@"
                    ws.Cells(r, cHandle).Value2 = CStr(rec(0))
                End If
                If Usable(rec(1)) Then ws.Cells(r, cX).Value = rec(1)
                If Usable(rec(2)) Then ws.Cells(r, cY).Value = rec(2)
                If Usable(rec(3)) Then ws.Cells(r, cZ).Value = rec(3)
                If Usable(rec(4)) Then ws.Cells(r, cRot).Value = rec(4)
                If Usable(rec(5)) Then ws.Cells(r, cLPN).Value = rec(5)

                If Usable(rec(8)) Then
                    ws.Cells(r, cConv).Value = rec(8)
                End If
                If UBound(rec) >= 9 Then
                    If Usable(rec(9)) Then ws.Cells(r, cBlockName).Value = rec(9)
                End If

                matched = matched + 1
            Else
                unmatched = unmatched + 1
            End If

            'BOQ Conveyor Type is optional and is only a fallback.
            lpn = Trim$(CStrSafe(ws.Cells(r, cLPN).Value))
            If Len(lpn) > 0 Then
                If boqConv.Exists(NormKey(lpn)) Then
                    If Not Usable(ws.Cells(r, cConv).Value) Then
                        ws.Cells(r, cConv).Value = boqConv(NormKey(lpn))
                    End If
                End If
            End If
        End If
    Next r
End Sub

'==========================================================
' Build SIS_TAG_EXPORT lookup maps.
'
' Record:
'   0 HANDLE
'   1 X
'   2 Y
'   3 Z
'   4 ROTATION_DEG
'   5 LPN
'   6 TYPE
'   7 SIS_SEQUENCE
'   8 CONVEYOR_TYPE
'   9 BLOCK_NAME
'==========================================================
Private Sub BuildCADMaps(ByVal ws As Worksheet, _
                         ByRef exactMap As Object, _
                         ByRef typedMap As Object, _
                         ByRef baseTypedMap As Object)

    Dim cSeq As Long, cType As Long, cHandle As Long
    Dim cX As Long, cY As Long, cZ As Long, cRot As Long
    Dim cLPN As Long, cConv As Long
    Dim lastRow As Long, r As Long
    Dim seq As String, typ As String, base As String, key As String
    Dim rec As Variant

    Set exactMap = CreateObject("Scripting.Dictionary")
    exactMap.CompareMode = vbTextCompare

    Set typedMap = CreateObject("Scripting.Dictionary")
    typedMap.CompareMode = vbTextCompare

    Set baseTypedMap = CreateObject("Scripting.Dictionary")
    baseTypedMap.CompareMode = vbTextCompare

    cSeq = FindHeaderByAliases(ws, Array("SIS_SEQUENCE", "SEQUENCE", "DEVICE NAME"))
    cType = FindHeaderByAliases(ws, Array("TYPE", "ITEM TYPE"))
    cHandle = FindHeaderByAliases(ws, Array("HANDLE"))
    cX = FindHeaderByAliases(ws, Array("X"))
    cY = FindHeaderByAliases(ws, Array("Y"))
    cZ = FindHeaderByAliases(ws, Array("Z"))
    cRot = FindHeaderByAliases(ws, Array("ROTATION_DEG", "ROTATION DEG"))
    cLPN = FindHeaderByAliases(ws, Array("LPN", "LAYOUT_POSITION_NUMBER", "LAYOUT POSITION NUMBER"))
    cConv = FindHeaderByAliases(ws, Array("CONVEYOR_TYPE", "CONVEYOR TYPE"))
    Dim cBlockName As Long
    cBlockName = FindHeaderByAliases(ws, Array("BLOCK_NAME", "BLOCK NAME", "BLOCK"))

    If cSeq = 0 Then
        Err.Raise vbObjectError + 7172, , "SIS_TAG_EXPORT is missing SIS_SEQUENCE."
    End If

    lastRow = LastUsedRow(ws)

    For r = 2 To lastRow
        PDPerf_Pulse "mod17_FunctionCSV.BuildCADMaps [L516]" & " row " & CStr(r)
        seq = Trim$(CStrSafe(ws.Cells(r, cSeq).Value))

        If Len(seq) > 0 Then
            If cType > 0 Then typ = Trim$(CStrSafe(ws.Cells(r, cType).Value)) Else typ = vbNullString

            rec = Array( _
                HandleTextSafe(ws, r, cHandle), _
                CellValueSafe(ws, r, cX), _
                CellValueSafe(ws, r, cY), _
                CellValueSafe(ws, r, cZ), _
                CellValueSafe(ws, r, cRot), _
                CellValueSafe(ws, r, cLPN), _
                typ, _
                seq, _
                CellValueSafe(ws, r, cConv), _
                CellValueSafe(ws, r, cBlockName))

            key = NormKey(seq)

            If Not exactMap.Exists(key) Then
                exactMap.Add key, rec
            ElseIf CADRecordPriority(rec) > CADRecordPriority(exactMap(key)) Then
                exactMap(key) = rec
            End If

            If Len(typ) > 0 Then
                key = NormKey(seq) & "|" & NormType(typ)

                If Not typedMap.Exists(key) Then
                    typedMap.Add key, rec
                ElseIf CADRecordScore(rec) > CADRecordScore(typedMap(key)) Then
                    typedMap(key) = rec
                End If

                base = BaseSequence(seq, typ)
                key = NormKey(base) & "|" & NormType(typ)

                If Not baseTypedMap.Exists(key) Then
                    baseTypedMap.Add key, rec
                Else
                    'Ambiguous base/type match: do not guess.
                    baseTypedMap(key) = vbNullString
                End If
            End If
        End If
    Next r
End Sub

Private Function CADRecordPriority(ByVal rec As Variant) As Long
    Dim p As Long

    'Top-level/parent AutoCAD rows normally have blank TYPE.
    'Prefer them when the same SIS_SEQUENCE is repeated by nested electrical blocks.
    If Not Usable(rec(6)) Then p = p + 1000

    p = p + CADRecordScore(rec)
    CADRecordPriority = p
End Function

Private Function FindProgressiveCADRecord(ByVal seq As String, ByVal exactMap As Object) As Variant
    Dim candidate As String
    Dim p As Long
    Dim first4 As String

    candidate = Trim$(seq)

    'First remove trailing device suffixes one level at a time.
    Do
        p = InStrRev(candidate, "-")
        If p <= 0 Then Exit Do

        candidate = Left$(candidate, p - 1)
        If Len(candidate) = 0 Then Exit Do

        If exactMap.Exists(NormKey(candidate)) Then
            FindProgressiveCADRecord = exactMap(NormKey(candidate))
            Exit Function
        End If
    Loop

    'Final family fallback: first four numeric characters.
    first4 = FirstSISNumber(seq)
    If Len(first4) >= 4 Then first4 = Left$(first4, 4)

    If Len(first4) = 4 Then
        If exactMap.Exists(NormKey(first4)) Then
            FindProgressiveCADRecord = exactMap(NormKey(first4))
            Exit Function
        End If

        'If a literal 4-digit SIS row does not exist, use the best CAD row
        'whose SIS_SEQUENCE starts with that same 4-digit family.
        FindProgressiveCADRecord = FindFourDigitFamilyRecord(first4, exactMap)
    End If
End Function

Private Function FindFourDigitFamilyRecord(ByVal first4 As String, ByVal exactMap As Object) As Variant
    Dim k As Variant
    Dim rec As Variant
    Dim best As Variant
    Dim haveBest As Boolean

    For Each k In exactMap.Keys
        PDPerf_Pulse "mod17_FunctionCSV.FindFourDigitFamilyRecord [L619]"
        If Left$(CStr(k), 4) = UCase$(first4) Then
            rec = exactMap(k)

            If Not haveBest Then
                best = rec
                haveBest = True
            ElseIf CADRecordPriority(rec) > CADRecordPriority(best) Then
                best = rec
            ElseIf CADRecordPriority(rec) = CADRecordPriority(best) Then
                'Prefer the shorter SIS sequence when priorities tie.
                If Len(CStr(rec(7))) < Len(CStr(best(7))) Then best = rec
            End If
        End If
    Next k

    If haveBest Then FindFourDigitFamilyRecord = best
End Function

Private Function CADRecordScore(ByVal rec As Variant) As Long
    Dim n As Long
    If Usable(rec(0)) Then n = n + 1
    If Usable(rec(1)) Then n = n + 1
    If Usable(rec(2)) Then n = n + 1
    If Usable(rec(3)) Then n = n + 1
    If Usable(rec(4)) Then n = n + 1
    If Usable(rec(5)) Then n = n + 1
    CADRecordScore = n
End Function

'==========================================================
' BOQ LPN -> Conveyor Type
'==========================================================
Private Sub BuildBOQConveyorMap(ByVal ws As Worksheet, ByVal d As Object)

    Dim cLPN As Long, cConv As Long
    Dim lastRow As Long, r As Long
    Dim k As String
    Dim v As Variant

    cLPN = FindHeaderByAliases(ws, Array("LPN", "LAYOUT POSITION NUMBER", "LAYOUT_POSITION_NUMBER"))
    cConv = FindHeaderByAliases(ws, Array("CONVEYOR TYPE", "CONVEYOR_TYPE"))

    If cLPN = 0 Or cConv = 0 Then Exit Sub

    lastRow = LastUsedRow(ws)

    For r = 2 To lastRow
        PDPerf_Pulse "mod17_FunctionCSV.BuildBOQConveyorMap [L666]" & " row " & CStr(r)
        k = NormKey(ws.Cells(r, cLPN).Value)
        v = ws.Cells(r, cConv).Value

        If Len(k) > 0 And Usable(v) Then
            If Not d.Exists(k) Then d.Add k, v
        End If
    Next r
End Sub

'==========================================================
' AddExportField
' Stores:
'   item(0) = Output header
'   item(1...) = Possible source header names
'==========================================================
Private Sub AddExportField(ByRef specs As Collection, ByVal outputHeader As String, ParamArray sourceHeaders() As Variant)

    Dim item() As Variant
    Dim i As Long

    ReDim item(0 To UBound(sourceHeaders) + 1)

    item(0) = outputHeader

    For i = LBound(sourceHeaders) To UBound(sourceHeaders)
        item(i + 1) = CStr(sourceHeaders(i))
    Next i

    specs.Add item

End Sub

'==========================================================
' FindHeaderCol
' Existing Mod17 helper retained.
'==========================================================
Private Function FindHeaderCol(ByVal ws As Worksheet, ByVal spec As Variant) As Long

    Dim lastCol As Long
    Dim c As Long
    Dim i As Long
    Dim actualHeader As String
    Dim wantedHeader As String

    FindHeaderCol = 0

    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column

    For c = 1 To lastCol

        actualHeader = NormalizeHeader(CStr(ws.Cells(1, c).Value))

        If Len(actualHeader) > 0 Then

            For i = LBound(spec) + 1 To UBound(spec)

                wantedHeader = NormalizeHeader(CStr(spec(i)))

                If actualHeader = wantedHeader Then
                    FindHeaderCol = c
                    Exit Function
                End If

            Next i

        End If

    Next c

End Function

'==========================================================
' NormalizeHeader
' Existing Mod17 helper retained.
'==========================================================
Private Function NormalizeHeader(ByVal headerText As String) As String

    headerText = Trim$(headerText)
    headerText = Replace(headerText, " ", "")
    headerText = Replace(headerText, "_", "")
    headerText = Replace(headerText, "-", "")
    headerText = Replace(headerText, vbTab, "")
    headerText = UCase$(headerText)

    NormalizeHeader = headerText

End Function

Private Function FirstSISNumber(ByVal seq As String) As String
    Dim s As String
    Dim p As Long

    s = Trim$(seq)
    If Len(s) = 0 Then Exit Function

    p = InStr(1, s, "-", vbBinaryCompare)
    If p > 1 Then
        FirstSISNumber = Left$(s, p - 1)
    Else
        FirstSISNumber = s
    End If
End Function

Private Function HandleTextSafe(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As String
    Dim v As Variant
    Dim t As String

    If c <= 0 Then Exit Function

    'Prefer the literal worksheet text. This is important for AutoCAD hexadecimal
    'handles and prevents VBA/Excel from turning them into scientific notation.
    t = CStr(ws.Cells(r, c).Text)

    If Len(t) > 0 And InStr(1, t, "E+", vbTextCompare) = 0 And t <> "####" Then
        HandleTextSafe = t
        Exit Function
    End If

    v = ws.Cells(r, c).Value2
    If Not IsError(v) And Not IsEmpty(v) And Not IsNull(v) Then
        HandleTextSafe = CStr(v)
    End If
End Function

Private Function FindOutputSpecIndex(ByVal specs As Collection, ByVal outputHeader As String) As Long
    Dim i As Long
    Dim spec As Variant

    For i = 1 To specs.count
        spec = specs(i)
        If NormalizeHeader(CStr(spec(0))) = NormalizeHeader(outputHeader) Then
            FindOutputSpecIndex = i
            Exit Function
        End If
    Next i
End Function

'==========================================================
' Generic helpers
'==========================================================
Private Function GetSheetSafe(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set GetSheetSafe = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function LastUsedRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find("*", SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then
        LastUsedRow = 0
    Else
        LastUsedRow = f.Row
    End If
End Function

Private Function DataRowCount(ByVal ws As Worksheet) As Long
    Dim lr As Long
    lr = LastUsedRow(ws)
    If lr >= 2 Then DataRowCount = lr - 1
End Function

Private Function RowHasData(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim lastCol As Long
    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    RowHasData = (Application.WorksheetFunction.CountA(ws.Range(ws.Cells(r, 1), ws.Cells(r, lastCol))) > 0)
End Function

Private Function FindHeaderByAliases(ByVal ws As Worksheet, ByVal aliases As Variant) As Long
    Dim lastCol As Long
    Dim c As Long, i As Long
    Dim actual As String, wanted As String

    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column

    For c = 1 To lastCol
        actual = NormalizeHeader(CStrSafe(ws.Cells(1, c).Value))

        For i = LBound(aliases) To UBound(aliases)
            wanted = NormalizeHeader(CStr(aliases(i)))

            If actual = wanted Then
                FindHeaderByAliases = c
                Exit Function
            End If
        Next i
    Next c
End Function

Private Function EnsureHeader(ByVal ws As Worksheet, ByVal headerName As String) As Long
    Dim c As Long
    c = FindHeaderByAliases(ws, Array(headerName))

    If c > 0 Then
        EnsureHeader = c
        Exit Function
    End If

    c = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column + 1
    ws.Cells(1, c).Value = headerName
    ws.Cells(1, c).Font.Bold = True
    EnsureHeader = c
End Function

Private Function CellValueSafe(ByVal ws As Worksheet, ByVal r As Long, ByVal c As Long) As Variant
    If c > 0 Then CellValueSafe = ws.Cells(r, c).Value
End Function

Private Function CStrSafe(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function
    CStrSafe = CStr(v)
End Function

Private Function Usable(ByVal v As Variant) As Boolean
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function
    Usable = (Len(Trim$(CStr(v))) > 0)
End Function

Private Function NormKey(ByVal v As Variant) As String
    NormKey = UCase$(Trim$(CStrSafe(v)))
End Function

Private Function NormType(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStrSafe(v)))
    s = Replace(s, " ", "")

    Select Case s
        Case "IOD", "IO/D", "IO-D"
            s = "IO/D"
        Case "IOS", "IO/S", "IO-S"
            s = "IO/S"
    End Select

    NormType = s
End Function

Private Function BaseSequence(ByVal seq As String, ByVal typ As String) As String
    Dim s As String
    Dim t As String

    s = Trim$(seq)
    t = NormType(typ)

    If Len(s) = 0 Then Exit Function

    Select Case t
        Case "PSU"
            'Preserve numbered PSU identity (xxxx-PSU-1, -2, etc.).
            'Only strip a terminal plain "-PSU".
            If Len(s) >= 4 Then
                If UCase$(Right$(s, 4)) = "-PSU" Then s = Left$(s, Len(s) - 4)
            End If

        Case "IO/D"
            If Len(s) >= 5 Then
                If UCase$(Right$(s, 5)) = "-IO/D" Then s = Left$(s, Len(s) - 5)
            End If

        Case "IO/S"
            If Len(s) >= 5 Then
                If UCase$(Right$(s, 5)) = "-IO/S" Then s = Left$(s, Len(s) - 5)
            End If

        Case "VFD"
            If Len(s) >= 4 Then
                If UCase$(Right$(s, 4)) = "-VFD" Then s = Left$(s, Len(s) - 4)
            End If
    End Select

    BaseSequence = s
End Function
