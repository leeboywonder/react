Attribute VB_Name = "mod11_PowerRoundTrip"
Option Explicit

Private mPowerCalcPath As String

Public Sub PowerRT_4A_Send_PD5_FAST()
    If PDPerf_IsYielding Then Exit Sub
    Dim wsSrc As Worksheet, wsEst As Worksheet, wsBus As Worksheet, wbPower As Workbook, wsDest As Worksheet
    Dim hdrs As Variant, srcMap As Object, estMap As Object, best As Object, busMeta As Object
    Dim srcData As Variant, estData As Variant, outData() As Variant, headerData() As Variant
    Dim srcLastRow As Long, srcLastCol As Long, estLastRow As Long, estLastCol As Long
    Dim totalRows As Long, outRow As Long, r As Long, c As Long, h As String
    Dim seq As String, srcSeq As String, devSeq As String, typ As String, blockName As String, busName As String
    Dim sr As Long, curLoad As Variant, v As Variant, path As String, openedHere As Boolean
    Dim oldCalc As XlCalculation, oldScreen As Boolean, oldEvents As Boolean, oldAlerts As Boolean

    hdrs = Array("SIS_sequence", "AREA_Number", "SwitchGroup", "TYPE", "SIS_Element_Number", "Control_ID", "Load", _
                 "Module Length (ML)", "Motor Power (Main Drive)", "Motor Voltage (Main Drive)", "Total Qty of Sensors", _
                 "Control Card", "Total Qty of Drives", "System Type", "Conveyor Type", "Motor Brake Voltage (Main Drive)", _
                 "Motor Protection (Main Drive)", "Encoder Type (Main Drive)", "Qty of Control Card", "NETWORK_IP", "LPN", _
                 "X", "Y", "Z", "ROTATION_DEG", "SOURCE_SIS_SEQUENCE", "CURRENT_LOAD", "Feeding Panel", _
                 "PSU_POWERED_SEQUENCES", "PSU_RANGE", "PSU_TOTAL_CONTROLLER", "PSU_BUS", "PSU_GROUP_NO", "PSU_CLOSE_REASON", _
                 "PSU_TERMINAL_1_SEQUENCE", "PSU_TERMINAL_2_SEQUENCE", "PSU_TERMINAL_3_SEQUENCE", "PSU_TERMINAL_4_SEQUENCE", _
                 "PSU_TERMINAL_ASSIGNMENTS", "PSU_ESTIMATED_LENGTH_MM", "ZONE_LENGTH_ZL")

    Set wsSrc = PowerRT_Sheet(ThisWorkbook, "SIS_TAG_PD5")
    If wsSrc Is Nothing Then MsgBox "Missing SIS_TAG_PD5.", vbCritical: Exit Sub
    Set wsEst = PowerRT_Sheet(ThisWorkbook, "Estimated_Power_Supply")
    Set wsBus = PowerRT_Sheet(ThisWorkbook, "Power Supply Bus")
    Set busMeta = PowerRT_BuildPSUMeta(wsBus)

    path = PowerRT_SelectPowerCalcPath("Phase 4A - Send PD5 to Power Calculation")
    If Len(path) = 0 Then Exit Sub

    oldScreen = Application.ScreenUpdating: oldEvents = Application.EnableEvents
    oldCalc = Application.Calculation: oldAlerts = Application.DisplayAlerts
    Application.ScreenUpdating = False: Application.EnableEvents = False
    Application.Calculation = xlCalculationManual: Application.DisplayAlerts = False
    Application.StatusBar = "Phase 4A: building bulk PD5_IMPORT array..."
    On Error GoTo Fail

    srcLastRow = PowerRT_LastRow(wsSrc): srcLastCol = PowerRT_LastCol(wsSrc)
    If srcLastRow < 2 Or srcLastCol < 1 Then Err.Raise vbObjectError + 4101, , "SIS_TAG_PD5 contains no data rows."
    srcData = wsSrc.Range(wsSrc.Cells(1, 1), wsSrc.Cells(srcLastRow, srcLastCol)).Value2
    Set srcMap = PowerRT_HeaderMap(srcData, srcLastCol)
    If PowerRT_Col(srcMap, "SIS_SEQUENCE") = 0 Then Err.Raise vbObjectError + 4102, , "SIS_TAG_PD5 is missing SIS_SEQUENCE."

    Set best = CreateObject("Scripting.Dictionary"): best.CompareMode = vbTextCompare
    For r = 2 To srcLastRow
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST [L48]" & " row " & CStr(r)
        seq = Trim$(CStr(PowerRT_Arr(srcData, r, srcMap, "SIS_SEQUENCE")))
        If Len(seq) > 0 Then
            totalRows = totalRows + 1
            If Not best.Exists(seq) Then
                best(seq) = r
            Else
                blockName = UCase$(Trim$(CStr(PowerRT_Arr(srcData, r, srcMap, "BLOCK_NAME"))))
                If InStr(1, blockName, "ONGEN_MECH", vbTextCompare) > 0 Then best(seq) = r
            End If
        End If
    Next r

    If Not wsEst Is Nothing Then
        estLastRow = PowerRT_LastRow(wsEst): estLastCol = PowerRT_LastCol(wsEst)
        If estLastRow >= 2 And estLastCol >= 1 Then
            estData = wsEst.Range(wsEst.Cells(1, 1), wsEst.Cells(estLastRow, estLastCol)).Value2
            Set estMap = PowerRT_HeaderMap(estData, estLastCol)
            For r = 2 To estLastRow
                PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST [L66]" & " row " & CStr(r)
                If Len(Trim$(CStr(PowerRT_Arr(estData, r, estMap, "SIS_SEQUENCE")))) > 0 Then totalRows = totalRows + 1
            Next r
        End If
    End If

    If totalRows < 1 Then Err.Raise vbObjectError + 4103, , "No rows are available for PD5_IMPORT."
    ReDim outData(1 To totalRows, 1 To UBound(hdrs) + 1)
    ReDim headerData(1 To 1, 1 To UBound(hdrs) + 1)
    For c = 0 To UBound(hdrs)
        headerData(1, c + 1) = hdrs(c)
    Next c

    For r = 2 To srcLastRow
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST [L79]" & " row " & CStr(r)
        seq = Trim$(CStr(PowerRT_Arr(srcData, r, srcMap, "SIS_SEQUENCE")))
        If Len(seq) > 0 Then
            outRow = outRow + 1
            For c = 0 To UBound(hdrs)
                h = UCase$(CStr(hdrs(c)))
                Select Case h
                    Case "CONTROL_ID": v = PowerRT_ControlID(PowerRT_Arr(srcData, r, srcMap, "AREA_NUMBER"), PowerRT_Arr(srcData, r, srcMap, "SWITCHGROUP"), seq, PowerRT_Arr(srcData, r, srcMap, "TYPE"))
                    Case "LOAD", "CURRENT_LOAD": v = PowerRT_Load(srcData, r, srcMap)
                    Case "SOURCE_SIS_SEQUENCE": v = vbNullString
                    Case "FEEDING PANEL", "PSU_POWERED_SEQUENCES", "PSU_RANGE", "PSU_TOTAL_CONTROLLER", "PSU_BUS", "PSU_GROUP_NO", "PSU_CLOSE_REASON", _
                         "PSU_TERMINAL_1_SEQUENCE", "PSU_TERMINAL_2_SEQUENCE", "PSU_TERMINAL_3_SEQUENCE", "PSU_TERMINAL_4_SEQUENCE", _
                         "PSU_TERMINAL_ASSIGNMENTS", "PSU_ESTIMATED_LENGTH_MM": v = vbNullString
                    Case "ZONE_LENGTH_ZL": v = PowerRT_ResolveZL(seq, CStr(PowerRT_Arr(srcData, r, srcMap, "LPN")))
                    Case Else: v = PowerRT_Arr(srcData, r, srcMap, CStr(hdrs(c)))
                End Select
                outData(outRow, c + 1) = v
            Next c
        End If
    Next r

    If Not estMap Is Nothing Then
        For r = 2 To estLastRow
            PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_4A_Send_PD5_FAST [L101]" & " row " & CStr(r)
            devSeq = Trim$(CStr(PowerRT_Arr(estData, r, estMap, "SIS_SEQUENCE")))
            If Len(devSeq) > 0 Then
                outRow = outRow + 1
                srcSeq = Trim$(CStr(PowerRT_Arr(estData, r, estMap, "SOURCE_SIS_SEQUENCE")))
                typ = Trim$(CStr(PowerRT_Arr(estData, r, estMap, "TYPE")))
                curLoad = PowerRT_Arr(estData, r, estMap, "CURRENT_LOAD")
                busName = Trim$(CStr(PowerRT_Arr(estData, r, estMap, "BUS")))
                sr = 0: If best.Exists(srcSeq) Then sr = CLng(best(srcSeq))
                For c = 0 To UBound(hdrs)
                    h = UCase$(CStr(hdrs(c)))
                    Select Case h
                        Case "SIS_SEQUENCE": v = devSeq
                        Case "TYPE": v = typ
                        Case "SOURCE_SIS_SEQUENCE": v = srcSeq
                        Case "CURRENT_LOAD", "LOAD": v = curLoad
                        Case "FEEDING PANEL": v = vbNullString
                        Case "PSU_POWERED_SEQUENCES": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 3)
                        Case "PSU_RANGE": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 1)
                        Case "PSU_TOTAL_CONTROLLER": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 2)
                        Case "PSU_BUS": v = busName
                        Case "PSU_GROUP_NO": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 0)
                        Case "PSU_CLOSE_REASON": v = PowerRT_FirstNonBlank(PowerRT_Arr(estData, r, estMap, "PSU_CLOSE_REASON"), PowerRT_PSUMetaValue(busMeta, devSeq, busName, 4))
                        Case "PSU_TERMINAL_1_SEQUENCE": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 7)
                        Case "PSU_TERMINAL_2_SEQUENCE": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 8)
                        Case "PSU_TERMINAL_3_SEQUENCE": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 9)
                        Case "PSU_TERMINAL_4_SEQUENCE": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 10)
                        Case "PSU_TERMINAL_ASSIGNMENTS": v = PowerRT_FirstNonBlank(PowerRT_Arr(estData, r, estMap, "PSU_TERMINAL_ASSIGNMENTS"), PowerRT_PSUMetaValue(busMeta, devSeq, busName, 5))
                        Case "PSU_ESTIMATED_LENGTH_MM": v = PowerRT_PSUMetaValue(busMeta, devSeq, busName, 6)
                        Case "ZONE_LENGTH_ZL"
                            v = PowerRT_Arr(estData, r, estMap, "ZONE_LENGTH_ZL")
                            If Len(Trim$(CStr(v))) = 0 Then
                                If sr > 0 Then v = PowerRT_ResolveZL(srcSeq, CStr(PowerRT_Arr(srcData, sr, srcMap, "LPN")))
                            End If
                        Case "CONTROL_ID"
                            If sr > 0 Then v = PowerRT_ControlID(PowerRT_Arr(srcData, sr, srcMap, "AREA_NUMBER"), PowerRT_Arr(srcData, sr, srcMap, "SWITCHGROUP"), devSeq, typ) Else v = vbNullString
                        Case Else
                            If sr > 0 Then v = PowerRT_Arr(srcData, sr, srcMap, CStr(hdrs(c))) Else v = vbNullString
                    End Select
                    outData(outRow, c + 1) = v
                Next c
            End If
        Next r
    End If

    Application.StatusBar = "Phase 4A: one bulk write to Power Calculation..."
    Set wbPower = PowerRT_OpenWorkbook(path, False, openedHere)
    If Not PowerRT_ValidatePowerCalcWorkbook(wbPower, "4A") Then Err.Raise vbObjectError + 4190, , "The selected workbook is not a compatible Power Calculation workbook for Phase 4A."
    Set wsDest = PowerRT_Sheet(wbPower, "PD5_IMPORT")
    If wsDest Is Nothing Then Set wsDest = wbPower.Worksheets.Add(After:=wbPower.Worksheets(wbPower.Worksheets.count)): wsDest.name = "PD5_IMPORT"
    PowerRT_ClearContents wsDest
    wsDest.Cells(1, 1).Resize(1, UBound(hdrs) + 1).Value2 = headerData
    wsDest.Cells(2, 1).Resize(totalRows, UBound(hdrs) + 1).Value = outData

    Application.StatusBar = "Phase 4A: rebuilding Power Calc Definition_Import..."
    Application.Run "'" & Replace(wbPower.name, "'", "''") & "'!PC_Refresh_Definition_From_PD5"
    wbPower.Save

    Application.StatusBar = False
    Application.ScreenUpdating = oldScreen: Application.EnableEvents = oldEvents
    Application.Calculation = oldCalc: Application.DisplayAlerts = oldAlerts
    MsgBox "Phase 4A complete: " & Format$(totalRows, "#,##0") & " rows were transferred with one bulk write." & vbCrLf & _
           "Power Calc Definition_Import was rebuilt from PD5_IMPORT automatically." & vbCrLf & _
           "Selected Power Calc: " & wbPower.name & vbCrLf & _
           "Steps 4C and 4D will ask you to select the workbook again, so revision/location can change safely.", vbInformation, "Fast Power Calculation Round Trip"
    Exit Sub
Fail:
    Application.StatusBar = False
    Application.ScreenUpdating = oldScreen: Application.EnableEvents = oldEvents
    Application.Calculation = oldCalc: Application.DisplayAlerts = oldAlerts
    MsgBox "Phase 4A failed. Error " & Err.number & ": " & Err.description, vbCritical, "Fast Power Calculation Round Trip"
End Sub

Public Sub PowerRT_4B_Build_PD6_FAST()
    If PDPerf_IsYielding Then Exit Sub
    mod12_BuildPD6.Build_PD6_System_Designed_RELEASED
End Sub

Public Sub PowerRT_4C_Send_PD6_FAST()
    If PDPerf_IsYielding Then Exit Sub
    Dim path As String, wbPower As Workbook, openedHere As Boolean
    Dim finalOK As Variant, finalMsg As Variant
    Dim wsExport As Worksheet

    path = PowerRT_SelectPowerCalcPath("Phase 4C - Finalize Power Calculation Return")
    If Len(path) = 0 Then Exit Sub

    On Error GoTo Fail
    Set wbPower = PowerRT_OpenWorkbook(path, False, openedHere)
    If Not PowerRT_ValidatePowerCalcWorkbook(wbPower, "4C") Then
        Err.Raise vbObjectError + 4290, , "The selected workbook is not a compatible Power Calculation workbook for Phase 4C."
    End If

    Application.Run "'" & Replace(wbPower.name, "'", "''") & "'!PC_Finalize_PD_Return"

    'Do not trust a swallowed inner error. The current Power Calc module exposes
    'a success handshake, and we also verify that the export has actual data rows.
    finalOK = Application.Run("'" & Replace(wbPower.name, "'", "''") & "'!PC_LastFinalizationOK")
    finalMsg = Application.Run("'" & Replace(wbPower.name, "'", "''") & "'!PC_LastFinalizationMessage")
    If Not CBool(finalOK) Then
        Err.Raise vbObjectError + 4291, , "Power Calculation Step 4C did not complete: " & CStr(finalMsg)
    End If

    Set wsExport = PowerRT_Sheet(wbPower, "Export PD6 Designed Definition")
    If Not PowerRT_ExportSheetHasData(wsExport) Then
        Err.Raise vbObjectError + 4292, , _
                  "Step 4C did not produce data rows in 'Export PD6 Designed Definition'. Do not run Step 4D."
    End If

    wbPower.Save

    MsgBox "Phase 4C complete: Power Calculation applied automatic PSU groups, final manual overrides, rebuilt Definition_Import, and rebuilt Export PD6 Designed Definition." & vbCrLf & _
           "Selected Power Calc: " & wbPower.FullName & vbCrLf & vbCrLf & _
           "The export contains data rows and is ready for Step 4D.", _
           vbInformation, "Fast Power Calculation Round Trip"
    Exit Sub
Fail:
    MsgBox "Phase 4C could not finalize the selected Power Calculation workbook." & vbCrLf & _
           "Selected file: " & path & vbCrLf & vbCrLf & _
           "Install the V4.6.5 Power Calc modules modPC00_PDWorkflow and modPC01_PSUManualOverride." & vbCrLf & vbCrLf & _
           "Error " & Err.number & ": " & Err.description, vbCritical, "Fast Power Calculation Round Trip"
End Sub

Public Sub PowerRT_4D_Import_Power_FAST()
    If PDPerf_IsYielding Then Exit Sub
    Dim path As String, wbPower As Workbook, openedHere As Boolean
    Dim wsExport As Worksheet
    Dim errNum As Long, errDesc As String

    path = PowerRT_SelectPowerCalcPath("Phase 4D - Import Final Power Calculation Return")
    If Len(path) = 0 Then Exit Sub

    On Error GoTo Fail
    Application.StatusBar = "Phase 4D: validating Power Calculation return..."
    Set wbPower = PowerRT_OpenWorkbook(path, True, openedHere)
    If Not PowerRT_ValidatePowerCalcWorkbook(wbPower, "4D") Then _
        Err.Raise vbObjectError + 4390, , "The selected workbook is not a compatible Power Calculation return workbook."

    Set wsExport = PowerRT_Sheet(wbPower, "Export PD6 Designed Definition")
    If Not PowerRT_ExportSheetHasData(wsExport) Then
        Err.Raise vbObjectError + 4391, , _
                  "Power Calculation export has no data rows. Step 4C did not finish successfully. Run Step 4C first; then run Step 4D."
    End If

    Application.StatusBar = "Phase 4D: importing final Power Calculation return..."
    mod14_ImportPD6Power.Fill_PD6_From_PowerCalculation_Path_RELEASED path
    PowerRT_BackfillFinalPowerAssignments path

    If openedHere Then wbPower.Close SaveChanges:=False
    Application.StatusBar = False
    Exit Sub
Fail:
    'Capture the real error BEFORE cleanup. V4.6.4 switched to Resume Next first,
    'which allowed cleanup calls to replace/clear Err and displayed misleading Error 0.
    errNum = Err.number
    errDesc = Err.description
    On Error Resume Next
    If Not wbPower Is Nothing Then If openedHere Then wbPower.Close SaveChanges:=False
    Application.StatusBar = False
    On Error GoTo 0
    MsgBox "Phase 4D failed. Error " & errNum & ": " & errDesc, vbCritical, "Fast Power Calculation Round Trip"
End Sub

Private Function PowerRT_ExportSheetHasData(ByVal ws As Worksheet) As Boolean
    Dim lr As Long, lc As Long, data As Variant, m As Object, cSeq As Long
    If ws Is Nothing Then Exit Function
    lr = PowerRT_LastRow(ws): lc = PowerRT_LastCol(ws)
    If lr < 2 Or lc < 1 Then Exit Function
    data = ws.Range(ws.Cells(1, 1), ws.Cells(1, lc)).Value2
    Set m = PowerRT_HeaderMap(data, lc)
    cSeq = PowerRT_Col(m, "SIS_SEQUENCE")
    If cSeq = 0 Then Exit Function
    PowerRT_ExportSheetHasData = (ws.Cells(ws.rows.count, cSeq).End(xlUp).Row >= 2)
End Function

' Compatibility helper for any older code that still calls PowerRT_GetPath.
' No path is stored in UI_Config or any worksheet.
Public Function PowerRT_GetPath(Optional ByVal forcePrompt As Boolean = False) As String
    If forcePrompt Or Len(PowerRT_ValidSessionPath()) = 0 Then
        PowerRT_GetPath = PowerRT_SelectPowerCalcPath("Select Power Calculation Workbook")
    Else
        PowerRT_GetPath = mPowerCalcPath
    End If
End Function

Public Sub PowerRT_Choose_PowerCalc_Workbook()
    If PDPerf_IsYielding Then Exit Sub
    Dim p As String
    p = PowerRT_SelectPowerCalcPath("Choose / Change Power Calculation Workbook")
    If Len(p) > 0 Then
        MsgBox "Power Calculation workbook selected for this Excel session:" & vbCrLf & vbCrLf & p & vbCrLf & vbCrLf & _
               "Phase 4A, 4C, and 4D will still ask you to confirm by selecting the workbook at run time.", _
               vbInformation, "Power Calculation Workbook"
    End If
End Sub

Public Function PowerRT_SelectPowerCalcPath(Optional ByVal phaseLabel As String = "Phase 4") As String
    Dim fd As Object, p As String

    Set fd = Application.FileDialog(3)
    With fd
        .title = phaseLabel & ": select the Power Calculation workbook"
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Excel Workbooks", "*.xls;*.xlsx;*.xlsm;*.xlsb"

        On Error Resume Next
        If Len(PowerRT_ValidSessionPath()) > 0 Then
            .InitialFileName = mPowerCalcPath
        ElseIf Len(ThisWorkbook.path) > 0 Then
            .InitialFileName = ThisWorkbook.path & Application.PathSeparator
        End If
        On Error GoTo 0

        If .Show <> -1 Then Exit Function
        p = CStr(.SelectedItems(1))
    End With

    If Len(p) = 0 Then Exit Function

    On Error Resume Next
    If StrComp(p, ThisWorkbook.FullName, vbTextCompare) = 0 Then
        On Error GoTo 0
        MsgBox "You selected the PD Definition workbook itself." & vbCrLf & _
               "Please select the Power Calculation workbook instead.", _
               vbExclamation, "Select Power Calculation Workbook"
        Exit Function
    End If
    On Error GoTo 0

    mPowerCalcPath = p
    PowerRT_SelectPowerCalcPath = p
End Function

Public Function PowerRT_CurrentPowerCalcPath() As String
    PowerRT_CurrentPowerCalcPath = PowerRT_ValidSessionPath()
End Function

Public Sub PowerRT_ClearPowerCalcSelection()
    If PDPerf_IsYielding Then Exit Sub
    mPowerCalcPath = vbNullString
    MsgBox "The temporary Power Calculation workbook selection has been cleared." & vbCrLf & _
           "No Power Calc path is stored in the PD workbook.", _
           vbInformation, "Power Calculation Workbook"
End Sub

Private Function PowerRT_ValidSessionPath() As String
    Dim p As String
    p = Trim$(mPowerCalcPath)
    If Len(p) = 0 Then Exit Function

    On Error Resume Next
    If Len(Dir$(p)) > 0 Then PowerRT_ValidSessionPath = p
    On Error GoTo 0
End Function

Public Function PowerRT_ValidatePowerCalcWorkbook(ByVal wb As Workbook, ByVal phaseCode As String) As Boolean
    Dim code As String
    Dim wsAnchor As Worksheet, wsPD5 As Worksheet, wsExport As Worksheet

    If wb Is Nothing Then Exit Function

    Set wsAnchor = PowerRT_Sheet(wb, "EM MTR LIST")
    Set wsPD5 = PowerRT_Sheet(wb, "PD5_IMPORT")
    Set wsExport = PowerRT_Sheet(wb, "Export PD6 Designed Definition")

    code = UCase$(Trim$(phaseCode))
    Select Case code
        Case "4A"
            ' EM MTR LIST is the stable Power Calc anchor. PD5_IMPORT can be created by 4A.
            PowerRT_ValidatePowerCalcWorkbook = (Not wsAnchor Is Nothing)
        Case "4C"
            PowerRT_ValidatePowerCalcWorkbook = (Not wsPD5 Is Nothing) And (Not wsAnchor Is Nothing)
        Case "4D"
            PowerRT_ValidatePowerCalcWorkbook = (Not wsExport Is Nothing)
        Case Else
            PowerRT_ValidatePowerCalcWorkbook = True
    End Select
End Function

Public Function PowerRT_OpenWorkbook(ByVal FilePath As String, ByVal readOnlyMode As Boolean, ByRef openedHere As Boolean) As Workbook
    Dim wb As Workbook
    openedHere = False
    For Each wb In Application.Workbooks
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_OpenWorkbook [L379]"
        On Error Resume Next
        If StrComp(wb.FullName, FilePath, vbTextCompare) = 0 Then
            Set PowerRT_OpenWorkbook = wb
            On Error GoTo 0
            Exit Function
        End If
        On Error GoTo 0
    Next wb
    Set PowerRT_OpenWorkbook = Workbooks.Open(FilePath, ReadOnly:=readOnlyMode, UpdateLinks:=False, AddToMru:=False)
    openedHere = True
End Function

Private Function PowerRT_HeaderMap(ByRef data As Variant, ByVal lastCol As Long) As Object
    Dim d As Object, c As Long, k As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    For c = 1 To lastCol
        k = PowerRT_Key(data(1, c))
        If Len(k) > 0 Then If Not d.Exists(k) Then d(k) = c
    Next c
    Set PowerRT_HeaderMap = d
End Function

Private Function PowerRT_Col(ByVal m As Object, ByVal h As String) As Long
    Dim k As String: k = PowerRT_Key(h)
    If Not m Is Nothing Then If m.Exists(k) Then PowerRT_Col = CLng(m(k))
End Function

Private Function PowerRT_Arr(ByRef data As Variant, ByVal r As Long, ByVal m As Object, ByVal h As String) As Variant
    Dim c As Long: c = PowerRT_Col(m, h)
    If c > 0 Then PowerRT_Arr = data(r, c) Else PowerRT_Arr = vbNullString
End Function

Private Function PowerRT_Key(ByVal v As Variant) As String
    Dim s As String: s = UCase$(Trim$(CStr(v)))
    s = Replace(s, " ", ""): s = Replace(s, "_", ""): s = Replace(s, "-", "")
    s = Replace(s, "(", ""): s = Replace(s, ")", ""): s = Replace(s, "/", "")
    PowerRT_Key = s
End Function

Private Function PowerRT_Load(ByRef data As Variant, ByVal r As Long, ByVal m As Object) As Variant
    Dim st As String, p As Double, v As Double, q As Double
    st = UCase$(Trim$(CStr(PowerRT_Arr(data, r, m, "System Type"))))
    If InStr(st, "400V") > 0 Or InStr(st, "480V") > 0 Or st = "B400V" Then PowerRT_Load = 1.6: Exit Function
    If InStr(st, "24V") > 0 Then
        p = PowerRT_Num(PowerRT_Arr(data, r, m, "Motor Power (Main Drive)"))
        v = PowerRT_Num(PowerRT_Arr(data, r, m, "Motor Voltage (Main Drive)"))
        q = PowerRT_Num(PowerRT_Arr(data, r, m, "Total Qty of Drives"))
        If v <> 0 Then PowerRT_Load = p * 1000# / v * q Else PowerRT_Load = vbNullString
    Else
        PowerRT_Load = vbNullString
    End If
End Function

Private Function PowerRT_FirstNonBlank(ByVal primaryValue As Variant, ByVal fallbackValue As Variant) As Variant
    If Len(Trim$(CStr(primaryValue))) > 0 Then
        PowerRT_FirstNonBlank = primaryValue
    Else
        PowerRT_FirstNonBlank = fallbackValue
    End If
End Function

Private Function PowerRT_ResolveZL(ByVal sisSequence As String, ByVal lpn As String) As Variant
    Dim ml As Variant, zl As Variant
    On Error Resume Next
    mod21_CSVTraceability.CSVTrace_ResolveLengths sisSequence, sisSequence, lpn, ml, zl
    On Error GoTo 0
    PowerRT_ResolveZL = zl
End Function

Private Function PowerRT_ControlID(ByVal a As Variant, ByVal sw As Variant, ByVal seq As Variant, ByVal typ As Variant) As String
    Dim b As String, t As String
    b = Trim$(CStr(a)) & "-" & Trim$(CStr(sw)) & "-" & Trim$(CStr(seq)): t = UCase$(Trim$(CStr(typ)))
    Select Case t
        Case "MC": PowerRT_ControlID = b & "-K1"
        Case "SCANNER", "SCN": PowerRT_ControlID = b & "-K70"
        Case "VFD": PowerRT_ControlID = b & "-K7"
        Case "IO/D": PowerRT_ControlID = b & "-K4"
        Case "IO/S": PowerRT_ControlID = b & "-K5"
        Case Else: PowerRT_ControlID = b
    End Select
End Function

Private Function PowerRT_Num(ByVal v As Variant) As Double
    If IsNumeric(v) Then PowerRT_Num = CDbl(v) Else PowerRT_Num = 0
End Function

Private Function PowerRT_Sheet(ByVal wb As Workbook, ByVal nm As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_Sheet [L468]"
        If StrComp(Trim$(ws.name), Trim$(nm), vbTextCompare) = 0 Then Set PowerRT_Sheet = ws: Exit Function
    Next ws
End Function

Private Function PowerRT_LastRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next: Set f = ws.Cells.Find("*", ws.Cells(1, 1), xlFormulas, xlPart, xlByRows, xlPrevious, False): On Error GoTo 0
    If f Is Nothing Then PowerRT_LastRow = 0 Else PowerRT_LastRow = f.Row
End Function

Private Function PowerRT_LastCol(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next: Set f = ws.Cells.Find("*", ws.Cells(1, 1), xlFormulas, xlPart, xlByColumns, xlPrevious, False): On Error GoTo 0
    If f Is Nothing Then PowerRT_LastCol = 0 Else PowerRT_LastCol = f.Column
End Function


Private Function PowerRT_BuildPSUMeta(ByVal wsBus As Worksheet) As Object
    Dim d As Object, lr As Long, r As Long
    Dim dev As String, busName As String, k As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare
    If wsBus Is Nothing Then Set PowerRT_BuildPSUMeta = d: Exit Function

    lr = PowerRT_LastRow(wsBus)
    For r = 1 To lr
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_BuildPSUMeta [L495]" & " row " & CStr(r)
        dev = Trim$(CStr(wsBus.Cells(r, 5).Value2))
        busName = Trim$(CStr(wsBus.Cells(r, 6).Value2))
        If Len(dev) > 0 And Len(busName) > 0 Then
            If UCase$(busName) = "POWER BUS 1" Or UCase$(busName) = "LOGIC BUS 2" Then
                k = UCase$(dev) & "|" & UCase$(busName)
                d(k) = Array( _
                    wsBus.Cells(r, 1).Value2, _
                    wsBus.Cells(r, 7).Value2, _
                    wsBus.Cells(r, 9).Value2, _
                    CStr(wsBus.Cells(r, 10).Value2), _
                    wsBus.Cells(r, 8).Value2, _
                    CStr(wsBus.Cells(r, 19).Value2), _
                    wsBus.Cells(r, 4).Value2, _
                    CStr(wsBus.Cells(r, 15).Value2), _
                    CStr(wsBus.Cells(r, 16).Value2), _
                    CStr(wsBus.Cells(r, 17).Value2), _
                    CStr(wsBus.Cells(r, 18).Value2))
            End If
        End If
    Next r

    Set PowerRT_BuildPSUMeta = d
End Function

Private Function PowerRT_PSUMetaValue(ByVal d As Object, ByVal devSeq As String, _
                                      ByVal busName As String, ByVal itemIndex As Long) As Variant
    Dim k As String, a As Variant
    If d Is Nothing Then Exit Function
    k = UCase$(Trim$(devSeq)) & "|" & UCase$(Trim$(busName))
    If d.Exists(k) Then
        a = d(k)
        If itemIndex >= LBound(a) And itemIndex <= UBound(a) Then PowerRT_PSUMetaValue = a(itemIndex)
    End If
End Function

Private Sub PowerRT_BackfillFinalPowerAssignments(ByVal path As String)
    Dim wbPower As Workbook, openedHere As Boolean, wsExp As Worksheet
    Dim data As Variant, m As Object, d As Object, lr As Long, lc As Long, r As Long
    Dim cSeq As Long, cArea As Long, cSw As Long, cElem As Long, cPanel As Long
    Dim seq As String

    On Error GoTo Fail
    If Len(Trim$(path)) = 0 Then Exit Sub
    Set wbPower = PowerRT_OpenWorkbook(path, True, openedHere)
    If Not PowerRT_ValidatePowerCalcWorkbook(wbPower, "4D") Then Exit Sub
    Set wsExp = PowerRT_Sheet(wbPower, "Export PD6 Designed Definition")
    If wsExp Is Nothing Then Exit Sub

    lr = PowerRT_LastRow(wsExp): lc = PowerRT_LastCol(wsExp)
    If lr < 2 Then Exit Sub
    data = wsExp.Range(wsExp.Cells(1, 1), wsExp.Cells(lr, lc)).Value2
    Set m = PowerRT_HeaderMap(data, lc)
    cSeq = PowerRT_Col(m, "SIS_Sequence")
    cArea = PowerRT_Col(m, "Area_Number")
    cSw = PowerRT_Col(m, "SWITCHGROUP")
    cElem = PowerRT_Col(m, "SIS_ELEMENT_NUMBER")
    cPanel = PowerRT_Col(m, "Panel")
    If cSeq = 0 Or cSw = 0 Or cElem = 0 Then Exit Sub

    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    For r = 2 To lr
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_BackfillFinalPowerAssignments [L556]" & " row " & CStr(r)
        seq = Trim$(CStr(data(r, cSeq)))
        If Len(seq) > 0 Then
            If Len(Trim$(CStr(data(r, cSw)))) > 0 Then
                If Not d.Exists(seq) Then
                    d(seq) = Array(PowerRT_ValAt(data, r, cArea), PowerRT_ValAt(data, r, cSw), _
                                   PowerRT_ValAt(data, r, cElem), PowerRT_ValAt(data, r, cPanel))
                End If
            End If
        End If
    Next r

    PowerRT_BackfillSISTagPD5 d
    PowerRT_BackfillEstimatedPSU d
    PowerRT_BackfillPD4Estimate d
    PowerRT_BackfillPowerBus d
    Exit Sub
Fail:
    MsgBox "Power return was imported, but PD source-sheet backfill reported Error " & Err.number & _
           ": " & Err.description, vbExclamation, "Power Assignment Backfill"
End Sub

Private Function PowerRT_ValAt(ByRef data As Variant, ByVal r As Long, ByVal c As Long) As Variant
    If c > 0 Then PowerRT_ValAt = data(r, c) Else PowerRT_ValAt = vbNullString
End Function

Private Sub PowerRT_BackfillSISTagPD5(ByVal d As Object)
    Dim ws As Worksheet, data As Variant, m As Object, lr As Long, lc As Long, r As Long
    Dim cSeq As Long, cSw As Long, cElem As Long, cControl As Long, cArea As Long, cType As Long
    Dim seq As String, a As Variant
    Dim outSw() As Variant, outElem() As Variant, outControl() As Variant

    Set ws = PowerRT_Sheet(ThisWorkbook, "SIS_TAG_PD5")
    If ws Is Nothing Then Exit Sub
    lr = PowerRT_LastRow(ws): If lr < 2 Then Exit Sub

    cSw = PowerRT_EnsureHeader(ws, "SwitchGroup")
    cElem = PowerRT_EnsureHeader(ws, "SIS_Element_Number")
    cControl = PowerRT_EnsureHeader(ws, "Control_ID")
    lc = PowerRT_LastCol(ws)
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).Value2
    Set m = PowerRT_HeaderMap(data, lc)
    cSeq = PowerRT_Col(m, "SIS_SEQUENCE")
    cArea = PowerRT_Col(m, "AREA_NUMBER")
    cType = PowerRT_Col(m, "TYPE")
    If cSeq = 0 Then Exit Sub

    ReDim outSw(1 To lr - 1, 1 To 1)
    ReDim outElem(1 To lr - 1, 1 To 1)
    ReDim outControl(1 To lr - 1, 1 To 1)

    For r = 2 To lr
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_BackfillSISTagPD5 [L607]" & " row " & CStr(r)
        outSw(r - 1, 1) = data(r, cSw)
        outElem(r - 1, 1) = data(r, cElem)
        outControl(r - 1, 1) = data(r, cControl)
        seq = Trim$(CStr(data(r, cSeq)))
        If d.Exists(seq) Then
            a = d(seq)
            outSw(r - 1, 1) = a(1)
            outElem(r - 1, 1) = a(2)
            outControl(r - 1, 1) = PowerRT_ControlID(PowerRT_ValAt(data, r, cArea), a(1), seq, PowerRT_ValAt(data, r, cType))
        End If
    Next r

    ws.Cells(2, cSw).Resize(lr - 1, 1).Value2 = outSw
    ws.Cells(2, cElem).Resize(lr - 1, 1).Value2 = outElem
    ws.Cells(2, cControl).Resize(lr - 1, 1).Value2 = outControl
End Sub

Private Sub PowerRT_BackfillEstimatedPSU(ByVal d As Object)
    Dim ws As Worksheet, data As Variant, lr As Long, lc As Long, r As Long
    Dim cSeq As Long, cSw As Long, cElem As Long, cPanel As Long
    Dim seq As String, a As Variant
    Dim outSw() As Variant, outElem() As Variant, outPanel() As Variant

    Set ws = PowerRT_Sheet(ThisWorkbook, "Estimated_Power_Supply")
    If ws Is Nothing Then Exit Sub
    lr = PowerRT_LastRow(ws): If lr < 2 Then Exit Sub

    cSeq = PowerRT_FindHeader(ws, "SIS_SEQUENCE")
    If cSeq = 0 Then Exit Sub
    cSw = PowerRT_EnsureHeader(ws, "SwitchGroup")
    cElem = PowerRT_EnsureHeader(ws, "SIS_Element_Number")
    cPanel = PowerRT_EnsureHeader(ws, "Feeding Panel")
    lc = PowerRT_LastCol(ws)
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).Value2

    ReDim outSw(1 To lr - 1, 1 To 1)
    ReDim outElem(1 To lr - 1, 1 To 1)
    ReDim outPanel(1 To lr - 1, 1 To 1)

    For r = 2 To lr
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_BackfillEstimatedPSU [L647]" & " row " & CStr(r)
        outSw(r - 1, 1) = data(r, cSw)
        outElem(r - 1, 1) = data(r, cElem)
        outPanel(r - 1, 1) = data(r, cPanel)
        seq = Trim$(CStr(data(r, cSeq)))
        If d.Exists(seq) Then
            a = d(seq)
            outSw(r - 1, 1) = a(1)
            outElem(r - 1, 1) = a(2)
            outPanel(r - 1, 1) = a(3)
        End If
    Next r

    ws.Cells(2, cSw).Resize(lr - 1, 1).Value2 = outSw
    ws.Cells(2, cElem).Resize(lr - 1, 1).Value2 = outElem
    ws.Cells(2, cPanel).Resize(lr - 1, 1).Value2 = outPanel
End Sub

Private Sub PowerRT_BackfillPD4Estimate(ByVal d As Object)
    Dim ws As Worksheet, data As Variant, lr As Long, lc As Long, r As Long
    Dim cSeq As Long, cSw As Long, cElem As Long, cPanel As Long
    Dim seq As String, a As Variant
    Dim outSw() As Variant, outElem() As Variant, outPanel() As Variant

    Set ws = PowerRT_Sheet(ThisWorkbook, "PD4_Estimate_PSU")
    If ws Is Nothing Then Exit Sub
    lr = PowerRT_LastRow(ws): If lr < 2 Then Exit Sub

    cSeq = PowerRT_FindHeader(ws, "SEQUENCE")
    If cSeq = 0 Then Exit Sub
    cSw = PowerRT_EnsureHeader(ws, "SWITCHGROUP")
    cElem = PowerRT_EnsureHeader(ws, "SIS_ELEMENT_NUMBER")
    cPanel = PowerRT_EnsureHeader(ws, "Feeding Panel")
    lc = PowerRT_LastCol(ws)
    data = ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).Value2

    ReDim outSw(1 To lr - 1, 1 To 1)
    ReDim outElem(1 To lr - 1, 1 To 1)
    ReDim outPanel(1 To lr - 1, 1 To 1)

    For r = 2 To lr
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_BackfillPD4Estimate [L687]" & " row " & CStr(r)
        outSw(r - 1, 1) = data(r, cSw)
        outElem(r - 1, 1) = data(r, cElem)
        outPanel(r - 1, 1) = data(r, cPanel)
        seq = Trim$(CStr(data(r, cSeq)))
        If d.Exists(seq) Then
            a = d(seq)
            outSw(r - 1, 1) = a(1)
            outElem(r - 1, 1) = a(2)
            outPanel(r - 1, 1) = a(3)
        End If
    Next r

    ws.Cells(2, cSw).Resize(lr - 1, 1).Value2 = outSw
    ws.Cells(2, cElem).Resize(lr - 1, 1).Value2 = outElem
    ws.Cells(2, cPanel).Resize(lr - 1, 1).Value2 = outPanel
End Sub

Private Sub PowerRT_BackfillPowerBus(ByVal d As Object)
    Dim ws As Worksheet, lr As Long, r As Long
    Dim seq As String, a As Variant
    Dim outSw() As Variant, outPanel() As Variant, outElem() As Variant

    Set ws = PowerRT_Sheet(ThisWorkbook, "Power Supply Bus")
    If ws Is Nothing Then Exit Sub
    lr = PowerRT_LastRow(ws)
    If lr < 2 Then Exit Sub

    ReDim outSw(1 To lr, 1 To 1)
    ReDim outPanel(1 To lr, 1 To 1)
    ReDim outElem(1 To lr, 1 To 1)

    For r = 1 To lr
        PDPerf_Pulse "mod11_PowerRoundTrip.PowerRT_BackfillPowerBus [L719]" & " row " & CStr(r)
        If UCase$(Trim$(CStr(ws.Cells(r, 2).Value2))) = "SIS_SEQUENCE" Then
            outSw(r, 1) = "SwitchGroup"
            outPanel(r, 1) = "PNL"
            outElem(r, 1) = "PSU SIS Element Number"
        Else
            outSw(r, 1) = ws.Cells(r, 12).Value2
            outPanel(r, 1) = ws.Cells(r, 13).Value2
            outElem(r, 1) = ws.Cells(r, 20).Value2

            seq = Trim$(CStr(ws.Cells(r, 5).Value2))
            If Len(seq) > 0 And Not d Is Nothing Then
                If d.Exists(seq) Then
                    a = d(seq)
                    outSw(r, 1) = a(1)
                    outPanel(r, 1) = a(3)
                    outElem(r, 1) = a(2)
                End If
            End If
        End If
    Next r

    ws.Cells(1, 12).Resize(lr, 1).Value2 = outSw
    ws.Cells(1, 13).Resize(lr, 1).Value2 = outPanel
    ws.Cells(1, 20).Resize(lr, 1).Value2 = outElem
End Sub

Private Function PowerRT_FindHeader(ByVal ws As Worksheet, ByVal headerName As String) As Long
    Dim lc As Long, c As Long
    lc = PowerRT_LastCol(ws)
    For c = 1 To lc
        If PowerRT_Key(ws.Cells(1, c).Value2) = PowerRT_Key(headerName) Then PowerRT_FindHeader = c: Exit Function
    Next c
End Function

Private Function PowerRT_EnsureHeader(ByVal ws As Worksheet, ByVal headerName As String) As Long
    Dim c As Long, lc As Long
    c = PowerRT_FindHeader(ws, headerName)
    If c > 0 Then PowerRT_EnsureHeader = c: Exit Function
    lc = PowerRT_LastCol(ws)
    If lc < 1 Then lc = 0
    PowerRT_EnsureHeader = lc + 1
    ws.Cells(1, PowerRT_EnsureHeader).Value2 = headerName
End Function

Private Sub PowerRT_ClearContents(ByVal ws As Worksheet)
    Dim lr As Long, lc As Long
    lr = PowerRT_LastRow(ws): lc = PowerRT_LastCol(ws)
    If lr > 0 And lc > 0 Then ws.Range(ws.Cells(1, 1), ws.Cells(lr, lc)).ClearContents
End Sub
