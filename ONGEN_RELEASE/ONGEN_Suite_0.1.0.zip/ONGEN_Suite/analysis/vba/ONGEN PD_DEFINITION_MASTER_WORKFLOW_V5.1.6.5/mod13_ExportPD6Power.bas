Attribute VB_Name = "mod13_ExportPD6Power"
Option Explicit

'====================================================================================
' Macro Name : Export_PD6_System_Designed_Definition_FAST_RELEASED
' Author     : Lee Pierre
' Version    : Fast Released - Value Refresh, No Formulas
'
' Purpose:
'   Exports worksheet "PD6 System Designed" into a user-selected destination workbook.
'   It creates/updates:
'       - Definition_Import
'       - Export PD6 Designed Definition
'
' Speed Improvements:
'   - No formulas are written.
'   - No full-sheet refresh loop.
'   - Refresh reads only the needed columns into arrays.
'   - Refresh writes back only the updated columns.
'   - AutoFit is disabled by default because AutoFit is slow on large sheets.
'
' EM MTR LIST Refresh Rules:
'   - Match by SIS_SEQUENCE / SIS_Sequence / Sequence.
'   - Fill SWITCHGROUP on "Export PD6 Designed Definition" from "EM MTR LIST":
'       SwitchGroup
'       Power Group (SwitchGroup)
'       Power Group
'     Only usable values are copied. Blank and "Not Found" are ignored.
'   - Fill Panel on "Export PD6 Designed Definition" from "EM MTR LIST":
'       Panel
'       PNL
'     Only usable values are copied. Blank and "Not Found" are ignored.
'   - Rebuild SIS_ELEMENT_NUMBER as a value:
'       Area_Number-Switchgroup-SIS_Sequence
'     If Switchgroup is blank or "Not Found", 0 is used.
'====================================================================================

Private Const SRC_SHEET_PD6 As String = "PD6 System Designed"
Private Const DEST_IMPORT_SHEET As String = "Definition_Import"
Private Const DEST_EXPORT_SHEET As String = "Export PD6 Designed Definition"
Private Const EM_MTR_SHEET As String = "EM MTR LIST"
Private Const HEADER_ROW As Long = 1
Private Const AUTO_FIT_AFTER_EXPORT As Boolean = False

Public Sub Export_PD6_System_Designed_Definition_FAST_RELEASED()
    If PDPerf_IsYielding Then Exit Sub

    Dim headers As Variant
    Dim wbSrc As Workbook
    Dim wbDest As Workbook
    Dim wsSrc As Worksheet
    Dim wsImport As Worksheet
    Dim wsExport As Worksheet
    Dim wsEM As Worksheet
    Dim srcHeaderMap As Object
    Dim srcCols() As Long
    Dim srcValues As Variant
    Dim outData As Variant
    Dim headerCount As Long
    Dim lastSrcRow As Long
    Dim lastSrcCol As Long
    Dim rowCount As Long
    Dim r As Long
    Dim c As Long
    Dim sourceCol As Long
    Dim missingHeaders As String
    Dim warningText As String
    Dim destFile As Variant
    Dim finalMsg As String
    Dim oldScreenUpdating As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim oldCalculation As XlCalculation
    Dim oldStatusBar As Variant

    headers = ExportPD6Headers()
    headerCount = UBound(headers) - LBound(headers) + 1

    Set wbSrc = ResolveSourceWorkbook(SRC_SHEET_PD6)

    If wbSrc Is Nothing Then
        MsgBox "Source worksheet '" & SRC_SHEET_PD6 & "' was not found in any open workbook.", vbCritical, "PD6 Export"
        Exit Sub
    End If

    Set wsSrc = GetWorksheetByNameLoose(wbSrc, SRC_SHEET_PD6)

    destFile = mod11_PowerRoundTrip.PowerRT_GetPath(False)
    If Len(CStr(destFile)) = 0 Then
        MsgBox "No Power Calculation workbook was selected. Run Phase 4A or select one when prompted.", vbExclamation, "PD6 Export"
        Exit Sub
    End If

    If Len(wbSrc.FullName) > 0 Then
        If StrComp(CStr(destFile), wbSrc.FullName, vbTextCompare) = 0 Then
            MsgBox "The selected destination workbook is the same as the source workbook." & vbCrLf & "Please select a different destination workbook.", vbExclamation, "PD6 Export"
            Exit Sub
        End If
    End If

    On Error GoTo CleanFail

    oldScreenUpdating = Application.ScreenUpdating
    oldEnableEvents = Application.EnableEvents
    oldDisplayAlerts = Application.DisplayAlerts
    oldCalculation = Application.Calculation
    oldStatusBar = Application.StatusBar

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "PD6 export running..."

    Set wbDest = OpenOrGetWorkbook(CStr(destFile))
    Set wsImport = EnsureWorksheet(wbDest, DEST_IMPORT_SHEET)
    Set wsExport = EnsureWorksheet(wbDest, DEST_EXPORT_SHEET)
    Set wsEM = GetWorksheetByNameLoose(wbDest, EM_MTR_SHEET)

    Set srcHeaderMap = BuildHeaderMap(wsSrc, HEADER_ROW)
    ReDim srcCols(LBound(headers) To UBound(headers))

    For c = LBound(headers) To UBound(headers)
        srcCols(c) = GetHeaderColumn(srcHeaderMap, CStr(headers(c)))
        If srcCols(c) = 0 Then missingHeaders = missingHeaders & vbCrLf & "  - " & CStr(headers(c))
    Next c

    lastSrcRow = MaxLastRowFromColumns(wsSrc, srcCols)
    lastSrcCol = MaxColumnFromArray(srcCols)

    PrepareOutputSheetFast wsImport, headers
    PrepareOutputSheetFast wsExport, headers

    If lastSrcRow >= 2 And lastSrcCol >= 1 Then
        rowCount = lastSrcRow - 1
        srcValues = wsSrc.Range(wsSrc.Cells(1, 1), wsSrc.Cells(lastSrcRow, lastSrcCol)).Value2
        ReDim outData(1 To rowCount, 1 To headerCount)

        For r = 2 To lastSrcRow
            PDPerf_Pulse "mod13_ExportPD6Power.Export_PD6_System_Designed_Definition_FAST_RELEASED [L138]" & " row " & CStr(r)
            For c = LBound(headers) To UBound(headers)
                sourceCol = srcCols(c)
                If sourceCol > 0 Then
                    outData(r - 1, c + 1) = srcValues(r, sourceCol)
                Else
                    outData(r - 1, c + 1) = vbNullString
                End If
            Next c
        Next r

        wsImport.Cells(2, 1).Resize(rowCount, headerCount).Value = outData
        wsExport.Cells(2, 1).Resize(rowCount, headerCount).Value = outData

        Application.StatusBar = "Refreshing PD6 values from EM MTR LIST..."
        warningText = FastRefreshExportPD6DesignedDefinitionValues(wsExport, wsEM)
    Else
        rowCount = 0
        warningText = vbCrLf & "No source data rows were found below the headers."
    End If

    If AUTO_FIT_AFTER_EXPORT Then
        wsImport.UsedRange.Columns.AutoFit
        wsExport.UsedRange.Columns.AutoFit
    End If

    'Persist the bulk transfer once. The workbook remains open for Phase 4D.
    wbDest.Save

    Application.StatusBar = oldStatusBar
    Application.Calculation = oldCalculation
    Application.DisplayAlerts = oldDisplayAlerts
    Application.EnableEvents = oldEnableEvents
    Application.ScreenUpdating = oldScreenUpdating

    finalMsg = "PD6 export complete." & vbCrLf & vbCrLf
    finalMsg = finalMsg & "Source workbook: " & wbSrc.name & vbCrLf
    finalMsg = finalMsg & "Destination workbook: " & wbDest.name & vbCrLf
    finalMsg = finalMsg & "Rows exported: " & Format$(rowCount, "#,##0") & vbCrLf & vbCrLf
    finalMsg = finalMsg & "Updated sheets:" & vbCrLf
    finalMsg = finalMsg & "  - " & DEST_IMPORT_SHEET & vbCrLf
    finalMsg = finalMsg & "  - " & DEST_EXPORT_SHEET & vbCrLf & vbCrLf
    finalMsg = finalMsg & "Destination workbook was saved and remains open for Phase 4D."

    If Len(missingHeaders) > 0 Then finalMsg = finalMsg & vbCrLf & vbCrLf & "Missing source headers. These columns were left blank:" & missingHeaders
    If Len(warningText) > 0 Then finalMsg = finalMsg & vbCrLf & vbCrLf & "Refresh results/warnings:" & warningText

    MsgBox finalMsg, vbInformation, "PD6 Export"
    Exit Sub

CleanFail:
    On Error Resume Next
    Application.StatusBar = oldStatusBar
    Application.Calculation = oldCalculation
    Application.DisplayAlerts = oldDisplayAlerts
    Application.EnableEvents = oldEnableEvents
    Application.ScreenUpdating = oldScreenUpdating
    On Error GoTo 0

    MsgBox "PD6 export failed." & vbCrLf & vbCrLf & "Error " & Err.number & ": " & Err.description, vbCritical, "PD6 Export"

End Sub

Public Sub Refresh_Export_PD6_Designed_Definition_FAST_RELEASED()
    If PDPerf_IsYielding Then Exit Sub

    Dim wbTarget As Workbook
    Dim wsExport As Worksheet
    Dim wsEM As Worksheet
    Dim resultText As String
    Dim oldScreenUpdating As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim oldCalculation As XlCalculation
    Dim oldStatusBar As Variant

    Set wbTarget = ResolveWorkbookContainingSheet(DEST_EXPORT_SHEET)

    If wbTarget Is Nothing Then
        MsgBox "Worksheet '" & DEST_EXPORT_SHEET & "' was not found in any open workbook.", vbCritical, "PD6 Refresh"
        Exit Sub
    End If

    Set wsExport = GetWorksheetByNameLoose(wbTarget, DEST_EXPORT_SHEET)
    Set wsEM = GetWorksheetByNameLoose(wbTarget, EM_MTR_SHEET)

    On Error GoTo CleanFail

    oldScreenUpdating = Application.ScreenUpdating
    oldEnableEvents = Application.EnableEvents
    oldDisplayAlerts = Application.DisplayAlerts
    oldCalculation = Application.Calculation
    oldStatusBar = Application.StatusBar

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "Refreshing Export PD6 Designed Definition..."

    resultText = FastRefreshExportPD6DesignedDefinitionValues(wsExport, wsEM)

    Application.StatusBar = oldStatusBar
    Application.Calculation = oldCalculation
    Application.DisplayAlerts = oldDisplayAlerts
    Application.EnableEvents = oldEnableEvents
    Application.ScreenUpdating = oldScreenUpdating

    If Len(resultText) = 0 Then resultText = vbCrLf & "Refresh completed with no warnings."

    MsgBox "Export PD6 Designed Definition refresh complete." & vbCrLf & "Workbook: " & wbTarget.name & vbCrLf & "Sheet: " & wsExport.name & vbCrLf & resultText, vbInformation, "PD6 Refresh"
    Exit Sub

CleanFail:
    On Error Resume Next
    Application.StatusBar = oldStatusBar
    Application.Calculation = oldCalculation
    Application.DisplayAlerts = oldDisplayAlerts
    Application.EnableEvents = oldEnableEvents
    Application.ScreenUpdating = oldScreenUpdating
    On Error GoTo 0

    MsgBox "PD6 refresh failed." & vbCrLf & vbCrLf & "Error " & Err.number & ": " & Err.description, vbCritical, "PD6 Refresh"

End Sub

Private Function FastRefreshExportPD6DesignedDefinitionValues(ByVal wsExport As Worksheet, ByVal wsEM As Worksheet) As String

    Dim warningText As String
    Dim exportMap As Object
    Dim emMap As Object
    Dim colSeq As Long
    Dim colArea As Long
    Dim colSwitch As Long
    Dim colElement As Long
    Dim colPanel As Long
    Dim emSeqCol As Long
    Dim emSwitchCols As Collection
    Dim emPanelCol As Long
    Dim lastExportRow As Long
    Dim lastEMRow As Long
    Dim emSeqArr As Variant
    Dim emPanelArr As Variant
    Dim emSwitchArrays As Variant
    Dim exportSeqArr As Variant
    Dim exportAreaArr As Variant
    Dim exportSwitchArr As Variant
    Dim exportPanelArr As Variant
    Dim exportElementArr As Variant
    Dim dictSwitch As Object
    Dim dictPanel As Object
    Dim r As Long
    Dim i As Long
    Dim seqText As String
    Dim seqKey As String
    Dim switchText As String
    Dim panelText As String
    Dim switchUpdates As Long
    Dim panelUpdates As Long
    Dim elementUpdates As Long
    Dim emRowsScanned As Long

    If wsExport Is Nothing Then
        FastRefreshExportPD6DesignedDefinitionValues = vbCrLf & "Export sheet was not found."
        Exit Function
    End If

    If wsEM Is Nothing Then
        FastRefreshExportPD6DesignedDefinitionValues = vbCrLf & "Sheet '" & EM_MTR_SHEET & "' was not found. SWITCHGROUP and Panel were not refreshed."
        Exit Function
    End If

    Set exportMap = BuildHeaderMap(wsExport, HEADER_ROW)
    colSeq = GetHeaderColumnAny(exportMap, Split("SIS_Sequence|SIS_SEQUENCE|SIS Sequence|Sequence", "|"))
    colArea = GetHeaderColumnAny(exportMap, Split("Area_Number|AREA_NUMBER|Area Number|Area", "|"))
    colSwitch = GetHeaderColumnAny(exportMap, Split("SWITCHGROUP|SwitchGroup|Switch Group|Power Group|Power Group (SwitchGroup)", "|"))
    colElement = GetHeaderColumnAny(exportMap, Split("SIS_ELEMENT_NUMBER|SIS Element Number|Element Number", "|"))
    colPanel = GetHeaderColumnAny(exportMap, Split("Panel|PANEL|PNL", "|"))

    If colSeq = 0 Then
        FastRefreshExportPD6DesignedDefinitionValues = vbCrLf & "Export sheet is missing SIS_Sequence. Refresh cancelled."
        Exit Function
    End If

    If colSwitch = 0 Then warningText = warningText & vbCrLf & "Export sheet is missing SWITCHGROUP. SWITCHGROUP was not refreshed."
    If colPanel = 0 Then warningText = warningText & vbCrLf & "Export sheet is missing Panel. Panel was not refreshed."
    If colElement > 0 And colArea = 0 Then warningText = warningText & vbCrLf & "Export sheet is missing Area_Number. SIS_ELEMENT_NUMBER was not refreshed."

    Set emMap = BuildHeaderMap(wsEM, HEADER_ROW)
    emSeqCol = GetHeaderColumnAny(emMap, Split("SIS_Sequence|SIS_SEQUENCE|SIS Sequence|Sequence", "|"))
    Set emSwitchCols = GetHeaderColumnsAny(emMap, Split("SwitchGroup|SWITCHGROUP|Switch Group|Power Group (SwitchGroup)|PowerGroup (SwitchGroup)|Power Group SwitchGroup|PowerGroup SwitchGroup|Power Group", "|"))
    emPanelCol = GetHeaderColumnAny(emMap, Split("Panel|PANEL|PNL", "|"))

    If emSeqCol = 0 Then
        FastRefreshExportPD6DesignedDefinitionValues = warningText & vbCrLf & "Sheet '" & wsEM.name & "' is missing SIS_Sequence / Sequence. Refresh cancelled."
        Exit Function
    End If

    If emSwitchCols.count = 0 Then warningText = warningText & vbCrLf & "Sheet '" & wsEM.name & "' is missing SwitchGroup or Power Group (SwitchGroup). SWITCHGROUP was not refreshed."
    If emPanelCol = 0 Then warningText = warningText & vbCrLf & "Sheet '" & wsEM.name & "' is missing Panel / PNL. Panel was not refreshed."

    lastExportRow = MaxLastRowFromSpecificColumns(wsExport, Array(colSeq, colArea, colSwitch, colElement, colPanel))
    lastEMRow = MaxLastRowFromSpecificColumns(wsEM, CollectionToArrayWithExtra(emSwitchCols, emSeqCol, emPanelCol))

    If lastExportRow < 2 Then
        FastRefreshExportPD6DesignedDefinitionValues = warningText & vbCrLf & "No rows found on '" & wsExport.name & "'."
        Exit Function
    End If

    If lastEMRow < 2 Then
        FastRefreshExportPD6DesignedDefinitionValues = warningText & vbCrLf & "No rows found on '" & wsEM.name & "'."
        Exit Function
    End If

    emSeqArr = GetColumnValues(wsEM, 2, lastEMRow, emSeqCol)

    If emPanelCol > 0 Then emPanelArr = GetColumnValues(wsEM, 2, lastEMRow, emPanelCol)

    If emSwitchCols.count > 0 Then
        ReDim emSwitchArrays(1 To emSwitchCols.count)
        For i = 1 To emSwitchCols.count
            emSwitchArrays(i) = GetColumnValues(wsEM, 2, lastEMRow, CLng(emSwitchCols(i)))
        Next i
    End If

    Set dictSwitch = CreateObject("Scripting.Dictionary")
    dictSwitch.CompareMode = vbTextCompare
    Set dictPanel = CreateObject("Scripting.Dictionary")
    dictPanel.CompareMode = vbTextCompare

    For r = 1 To UBound(emSeqArr, 1)
        PDPerf_Pulse "mod13_ExportPD6Power.FastRefreshExportPD6DesignedDefinitionValues [L367]" & " row " & CStr(r)
        seqText = TrimSafe(emSeqArr(r, 1))
        If Len(seqText) > 0 Then
            emRowsScanned = emRowsScanned + 1
            seqKey = SequenceKey(seqText)

            If emSwitchCols.count > 0 Then
                switchText = FirstUsableFromColumnArrays(emSwitchArrays, r)
                If IsUsableLookupValue(switchText) Then
                    If Not dictSwitch.Exists(seqKey) Then dictSwitch.Add seqKey, switchText
                End If
            End If

            If emPanelCol > 0 Then
                panelText = TrimSafe(emPanelArr(r, 1))
                If IsUsableLookupValue(panelText) Then
                    If Not dictPanel.Exists(seqKey) Then dictPanel.Add seqKey, panelText
                End If
            End If
        End If
    Next r

    exportSeqArr = GetColumnValues(wsExport, 2, lastExportRow, colSeq)
    If colArea > 0 Then exportAreaArr = GetColumnValues(wsExport, 2, lastExportRow, colArea)
    If colSwitch > 0 Then exportSwitchArr = GetColumnValues(wsExport, 2, lastExportRow, colSwitch)
    If colPanel > 0 Then exportPanelArr = GetColumnValues(wsExport, 2, lastExportRow, colPanel)
    If colElement > 0 Then exportElementArr = GetColumnValues(wsExport, 2, lastExportRow, colElement)

    For r = 1 To UBound(exportSeqArr, 1)
        PDPerf_Pulse "mod13_ExportPD6Power.FastRefreshExportPD6DesignedDefinitionValues [L395]" & " row " & CStr(r)
        seqText = TrimSafe(exportSeqArr(r, 1))
        If Len(seqText) > 0 Then
            seqKey = SequenceKey(seqText)

            If colSwitch > 0 Then
                If dictSwitch.Exists(seqKey) Then
                    exportSwitchArr(r, 1) = dictSwitch(seqKey)
                    switchUpdates = switchUpdates + 1
                End If
            End If

            If colPanel > 0 Then
                If dictPanel.Exists(seqKey) Then
                    exportPanelArr(r, 1) = dictPanel(seqKey)
                    panelUpdates = panelUpdates + 1
                End If
            End If

            If colElement > 0 And colArea > 0 Then
                switchText = vbNullString
                If colSwitch > 0 Then switchText = TrimSafe(exportSwitchArr(r, 1))
                exportElementArr(r, 1) = BuildPD6ElementNumberValue(exportAreaArr(r, 1), switchText, exportSeqArr(r, 1))
                elementUpdates = elementUpdates + 1
            End If
        End If
    Next r

    If colSwitch > 0 Then SetColumnValues wsExport, 2, lastExportRow, colSwitch, exportSwitchArr
    If colPanel > 0 Then SetColumnValues wsExport, 2, lastExportRow, colPanel, exportPanelArr
    If colElement > 0 And colArea > 0 Then SetColumnValues wsExport, 2, lastExportRow, colElement, exportElementArr

    FastRefreshExportPD6DesignedDefinitionValues = warningText & vbCrLf
    FastRefreshExportPD6DesignedDefinitionValues = FastRefreshExportPD6DesignedDefinitionValues & "EM MTR LIST rows scanned: " & Format$(emRowsScanned, "#,##0") & vbCrLf
    FastRefreshExportPD6DesignedDefinitionValues = FastRefreshExportPD6DesignedDefinitionValues & "SWITCHGROUP values refreshed: " & Format$(switchUpdates, "#,##0") & vbCrLf
    FastRefreshExportPD6DesignedDefinitionValues = FastRefreshExportPD6DesignedDefinitionValues & "Panel values refreshed: " & Format$(panelUpdates, "#,##0") & vbCrLf
    FastRefreshExportPD6DesignedDefinitionValues = FastRefreshExportPD6DesignedDefinitionValues & "SIS_ELEMENT_NUMBER values refreshed: " & Format$(elementUpdates, "#,##0")

End Function

Private Function ExportPD6Headers() As Variant
    ExportPD6Headers = Split("Area_Number|SIS_Sequence|SWITCHGROUP|SIS_ELEMENT_NUMBER|Type|Network_IP|LPN|X|Y|Z|Rotation_DEG|System Type|Panel|Conveyor Type|Motor Power (Main Drive)|Motor Voltage (Main Drive)|Motor Brake Voltage (Main Drive)|Motor Protection (Main Drive)", "|")
End Function

Private Function ResolveSourceWorkbook(ByVal sourceSheetName As String) As Workbook
    Dim wb As Workbook

    If Not GetWorksheetByNameLoose(ThisWorkbook, sourceSheetName) Is Nothing Then
        Set ResolveSourceWorkbook = ThisWorkbook
        Exit Function
    End If

    If Not ActiveWorkbook Is Nothing Then
        If Not GetWorksheetByNameLoose(ActiveWorkbook, sourceSheetName) Is Nothing Then
            Set ResolveSourceWorkbook = ActiveWorkbook
            Exit Function
        End If
    End If

    For Each wb In Application.Workbooks
        PDPerf_Pulse "mod13_ExportPD6Power.ResolveSourceWorkbook [L454]"
        If Not GetWorksheetByNameLoose(wb, sourceSheetName) Is Nothing Then
            Set ResolveSourceWorkbook = wb
            Exit Function
        End If
    Next wb
End Function

Private Function ResolveWorkbookContainingSheet(ByVal sheetName As String) As Workbook
    Dim wb As Workbook

    If Not ActiveWorkbook Is Nothing Then
        If Not GetWorksheetByNameLoose(ActiveWorkbook, sheetName) Is Nothing Then
            Set ResolveWorkbookContainingSheet = ActiveWorkbook
            Exit Function
        End If
    End If

    If Not GetWorksheetByNameLoose(ThisWorkbook, sheetName) Is Nothing Then
        Set ResolveWorkbookContainingSheet = ThisWorkbook
        Exit Function
    End If

    For Each wb In Application.Workbooks
        PDPerf_Pulse "mod13_ExportPD6Power.ResolveWorkbookContainingSheet [L477]"
        If Not GetWorksheetByNameLoose(wb, sheetName) Is Nothing Then
            Set ResolveWorkbookContainingSheet = wb
            Exit Function
        End If
    Next wb
End Function

Private Function OpenOrGetWorkbook(ByVal FilePath As String) As Workbook
    Dim wb As Workbook

    For Each wb In Application.Workbooks
        PDPerf_Pulse "mod13_ExportPD6Power.OpenOrGetWorkbook [L488]"
        If Len(wb.FullName) > 0 Then
            If StrComp(wb.FullName, FilePath, vbTextCompare) = 0 Then
                Set OpenOrGetWorkbook = wb
                Exit Function
            End If
        End If
    Next wb

    Set OpenOrGetWorkbook = Application.Workbooks.Open(FilePath)
End Function

Private Function GetWorksheetByNameLoose(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    If wb Is Nothing Then Exit Function

    For Each ws In wb.Worksheets
        PDPerf_Pulse "mod13_ExportPD6Power.GetWorksheetByNameLoose [L504]"
        If UCase$(Trim$(ws.name)) = UCase$(Trim$(sheetName)) Then
            Set GetWorksheetByNameLoose = ws
            Exit Function
        End If
    Next ws
End Function

Private Function EnsureWorksheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet

    Set ws = GetWorksheetByNameLoose(wb, sheetName)
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.count))
        ws.name = sheetName
        If wb Is ThisWorkbook Then mod23_WorksheetNavigation.NAV_Ensure_Worksheet_Navigation ws
    End If

    Set EnsureWorksheet = ws
End Function

Private Sub PrepareOutputSheetFast(ByVal ws As Worksheet, ByVal headers As Variant)
    Dim c As Long
    Dim headerCount As Long
    Dim headerArr() As Variant

    headerCount = UBound(headers) - LBound(headers) + 1
    ClearRowsBelowHeaderFast ws, headerCount

    ReDim headerArr(1 To 1, 1 To headerCount)
    For c = LBound(headers) To UBound(headers)
        headerArr(1, c + 1) = CStr(headers(c))
    Next c

    With ws.Cells(1, 1).Resize(1, headerCount)
        .Value = headerArr
        .Font.Bold = True
    End With
End Sub

Private Sub ClearRowsBelowHeaderFast(ByVal ws As Worksheet, ByVal headerCount As Long)
    Dim lastRow As Long
    Dim lastCol As Long

    lastRow = LastUsedRow(ws)
    lastCol = LastUsedColumn(ws)
    If lastCol < headerCount Then lastCol = headerCount

    If lastRow >= 2 Then ws.Range(ws.Cells(2, 1), ws.Cells(lastRow, lastCol)).ClearContents
End Sub

Private Function BuildHeaderMap(ByVal ws As Worksheet, ByVal headerRow As Long) As Object
    Dim dict As Object
    Dim lastCol As Long
    Dim c As Long
    Dim headers As Variant
    Dim key As String

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    lastCol = LastUsedColumn(ws)
    If lastCol = 0 Then
        Set BuildHeaderMap = dict
        Exit Function
    End If

    headers = ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, lastCol)).Value2

    For c = 1 To lastCol
        key = HeaderKey(TrimSafe(headers(1, c)))
        If Len(key) > 0 Then
            If Not dict.Exists(key) Then dict.Add key, c
        End If
    Next c

    Set BuildHeaderMap = dict
End Function

Private Function GetHeaderColumn(ByVal headerMap As Object, ByVal headerName As String) As Long
    Dim key As String
    key = HeaderKey(headerName)
    If headerMap.Exists(key) Then GetHeaderColumn = CLng(headerMap(key))
End Function

Private Function GetHeaderColumnAny(ByVal headerMap As Object, ByVal aliases As Variant) As Long
    Dim i As Long
    Dim testCol As Long

    For i = LBound(aliases) To UBound(aliases)
        testCol = GetHeaderColumn(headerMap, CStr(aliases(i)))
        If testCol > 0 Then
            GetHeaderColumnAny = testCol
            Exit Function
        End If
    Next i
End Function

Private Function GetHeaderColumnsAny(ByVal headerMap As Object, ByVal aliases As Variant) As Collection
    Dim cols As Collection
    Dim i As Long
    Dim testCol As Long

    Set cols = New Collection

    For i = LBound(aliases) To UBound(aliases)
        testCol = GetHeaderColumn(headerMap, CStr(aliases(i)))
        If testCol > 0 Then
            If Not CollectionContainsLong(cols, testCol) Then cols.Add testCol
        End If
    Next i

    Set GetHeaderColumnsAny = cols
End Function

Private Function CollectionContainsLong(ByVal values As Collection, ByVal wantedValue As Long) As Boolean
    Dim item As Variant
    For Each item In values
        PDPerf_Pulse "mod13_ExportPD6Power.CollectionContainsLong [L621]"
        If CLng(item) = wantedValue Then
            CollectionContainsLong = True
            Exit Function
        End If
    Next item
End Function

Private Function CollectionToArrayWithExtra(ByVal cols As Collection, ByVal extraOne As Long, ByVal extraTwo As Long) As Variant
    Dim arr() As Long
    Dim count As Long
    Dim item As Variant

    ReDim arr(0 To 0)
    count = -1

    If extraOne > 0 Then AddLongToDynamicArray arr, count, extraOne
    If extraTwo > 0 Then AddLongToDynamicArray arr, count, extraTwo

    For Each item In cols
        PDPerf_Pulse "mod13_ExportPD6Power.CollectionToArrayWithExtra [L640]"
        AddLongToDynamicArray arr, count, CLng(item)
    Next item

    If count < 0 Then
        ReDim arr(0 To 0)
        arr(0) = 0
    Else
        ReDim Preserve arr(0 To count)
    End If

    CollectionToArrayWithExtra = arr
End Function

Private Sub AddLongToDynamicArray(ByRef arr() As Long, ByRef count As Long, ByVal valueIn As Long)
    Dim i As Long
    If valueIn <= 0 Then Exit Sub

    For i = 0 To count
        If arr(i) = valueIn Then Exit Sub
    Next i

    count = count + 1
    ReDim Preserve arr(0 To count)
    arr(count) = valueIn
End Sub

Private Function FirstUsableFromColumnArrays(ByRef columnArrays As Variant, ByVal rowIndex As Long) As String
    Dim i As Long
    Dim arr As Variant
    Dim testValue As String

    If IsEmpty(columnArrays) Then Exit Function

    For i = LBound(columnArrays) To UBound(columnArrays)
        arr = columnArrays(i)
        testValue = TrimSafe(arr(rowIndex, 1))
        If IsUsableLookupValue(testValue) Then
            FirstUsableFromColumnArrays = testValue
            Exit Function
        End If
    Next i
End Function

Private Function HeaderKey(ByVal valueText As String) As String
    Dim i As Long
    Dim ch As String
    Dim result As String

    valueText = LCase$(Trim$(CStr(valueText)))
    valueText = Replace(valueText, Chr$(160), " ")
    valueText = Replace(valueText, vbCr, " ")
    valueText = Replace(valueText, vbLf, " ")
    valueText = Replace(valueText, vbTab, " ")

    For i = 1 To Len(valueText)
        ch = Mid$(valueText, i, 1)
        If ch Like "[a-z0-9]" Then result = result & ch
    Next i

    HeaderKey = result
End Function

Private Function SequenceKey(ByVal seqValue As Variant) As String
    SequenceKey = UCase$(TrimSafe(seqValue))
End Function

Private Function BuildPD6ElementNumberValue(ByVal areaValue As Variant, ByVal switchValue As Variant, ByVal seqValue As Variant) As String
    Dim areaText As String
    Dim switchText As String
    Dim seqText As String

    areaText = TrimSafe(areaValue)
    switchText = TrimSafe(switchValue)
    seqText = TrimSafe(seqValue)

    If Len(areaText) = 0 Or Len(seqText) = 0 Then Exit Function
    If Not IsUsableLookupValue(switchText) Then switchText = "0"

    BuildPD6ElementNumberValue = areaText & "-" & switchText & "-" & seqText
End Function

Private Function IsUsableLookupValue(ByVal valueIn As Variant) As Boolean
    Dim s As String
    Dim key As String

    s = TrimSafe(valueIn)
    key = UCase$(s)
    key = Replace(key, " ", "")
    key = Replace(key, "_", "")
    key = Replace(key, "-", "")

    IsUsableLookupValue = (Len(s) > 0 And key <> "NOTFOUND")
End Function

Private Function TrimSafe(ByVal valueIn As Variant) As String
    If IsError(valueIn) Then
        TrimSafe = vbNullString
    ElseIf IsNull(valueIn) Then
        TrimSafe = vbNullString
    ElseIf IsEmpty(valueIn) Then
        TrimSafe = vbNullString
    Else
        TrimSafe = Trim$(CStr(valueIn))
    End If
End Function

Private Function GetColumnValues(ByVal ws As Worksheet, ByVal firstRow As Long, ByVal lastRow As Long, ByVal colNum As Long) As Variant
    Dim rawValue As Variant
    Dim arr() As Variant

    If lastRow < firstRow Then
        ReDim arr(1 To 1, 1 To 1)
        GetColumnValues = arr
        Exit Function
    End If

    rawValue = ws.Range(ws.Cells(firstRow, colNum), ws.Cells(lastRow, colNum)).Value2

    If firstRow = lastRow Then
        ReDim arr(1 To 1, 1 To 1)
        arr(1, 1) = rawValue
        GetColumnValues = arr
    Else
        GetColumnValues = rawValue
    End If
End Function

Private Sub SetColumnValues(ByVal ws As Worksheet, ByVal firstRow As Long, ByVal lastRow As Long, ByVal colNum As Long, ByRef valuesIn As Variant)
    If lastRow < firstRow Then Exit Sub
    ws.Range(ws.Cells(firstRow, colNum), ws.Cells(lastRow, colNum)).Value = valuesIn
End Sub

Private Function LastUsedRow(ByVal ws As Worksheet) As Long
    Dim foundCell As Range

    On Error Resume Next
    Set foundCell = ws.Cells.Find("*", ws.Cells(1, 1), xlFormulas, xlPart, xlByRows, xlPrevious, False)
    On Error GoTo 0

    If foundCell Is Nothing Then LastUsedRow = 0 Else LastUsedRow = foundCell.Row
End Function

Private Function LastUsedColumn(ByVal ws As Worksheet) As Long
    Dim foundCell As Range

    On Error Resume Next
    Set foundCell = ws.Cells.Find("*", ws.Cells(1, 1), xlFormulas, xlPart, xlByColumns, xlPrevious, False)
    On Error GoTo 0

    If foundCell Is Nothing Then LastUsedColumn = 0 Else LastUsedColumn = foundCell.Column
End Function

Private Function MaxLastRowFromColumns(ByVal ws As Worksheet, ByVal colList As Variant) As Long
    Dim i As Long
    Dim testRow As Long
    Dim maxRow As Long
    Dim colNum As Long

    maxRow = 1

    For i = LBound(colList) To UBound(colList)
        colNum = CLng(colList(i))
        If colNum > 0 Then
            testRow = ws.Cells(ws.rows.count, colNum).End(xlUp).Row
            If testRow > maxRow Then maxRow = testRow
        End If
    Next i

    MaxLastRowFromColumns = maxRow
End Function

Private Function MaxLastRowFromSpecificColumns(ByVal ws As Worksheet, ByVal colList As Variant) As Long
    Dim i As Long
    Dim testRow As Long
    Dim maxRow As Long
    Dim colNum As Long

    maxRow = 1

    For i = LBound(colList) To UBound(colList)
        colNum = CLng(colList(i))
        If colNum > 0 Then
            testRow = ws.Cells(ws.rows.count, colNum).End(xlUp).Row
            If testRow > maxRow Then maxRow = testRow
        End If
    Next i

    MaxLastRowFromSpecificColumns = maxRow
End Function

Private Function MaxColumnFromArray(ByVal colList As Variant) As Long
    Dim i As Long
    Dim result As Long

    For i = LBound(colList) To UBound(colList)
        If CLng(colList(i)) > result Then result = CLng(colList(i))
    Next i

    MaxColumnFromArray = result
End Function

