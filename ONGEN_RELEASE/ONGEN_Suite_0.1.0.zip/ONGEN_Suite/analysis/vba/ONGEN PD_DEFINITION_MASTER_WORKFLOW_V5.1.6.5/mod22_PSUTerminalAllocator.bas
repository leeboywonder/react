Attribute VB_Name = "mod22_PSUTerminalAllocator"
Option Explicit

'===============================================================================
' PD MASTER V5.1.5 - 24V TERMINAL / CENTER-SPAN ENGINE
'
' Ported from ONGEN mod03_24V_Power_Generator V25.8.
'
' Engineering limits used by the estimate:
'   PSU estimate       : 40 A / 10668 mm (35 ft)
'   PSU terminal       : 20 A / 6096 mm (20 ft)
'   Terminal count     : 4
'
' BUS length rules:
'   BUS-1 : powered conveyor spans are measured from the estimated PSU position
'           at the CENTER (50%) of the first conveyor to the CENTER (50%) of
'           the last powered conveyor. Interior conveyor ML values are full.
'           Interface_Card does not add another ML span.
'   BUS-2 : the same center-span rule is used independently from BUS-1.
'           Interface_Card is excluded from BUS-2 entirely.
'
' Example: 1200 mm followed by 800 mm = 600 + 400 = 1000 mm.
' Example: 1200, 800, 1000 = 600 + 800 + 500 = 1900 mm.
'
' Terminal length is a CAPACITY bucket, not an absolute PSU-to-device reach.
' Each accepted center-span increment is charged to one terminal. This allows
' successive terminals to support a total PSU span up to 35 ft while each
' individual terminal remains limited to 20 A and 6096 mm / 20 ft capacity.
'
' Terminal codes/descriptions are data-driven from DATA_POWER using:
'   PSU TERM -> PSUDESC
' User-facing outputs show PSUDESC (DC1+/DC1-, DC2+/DC2-, ...).
'===============================================================================

Private Const TERM_COUNT As Long = 4
Private Const PSU_LIMIT_A As Double = 40#
Private Const PSU_LIMIT_MM As Double = 10668#
Private Const TERM_LIMIT_A As Double = 20#
Private Const TERM_LIMIT_MM As Double = 6096#

Private mNamesLoaded As Boolean
Private mTerminalCode(1 To TERM_COUNT) As String
Private mTerminalDesc(1 To TERM_COUNT) As String

Public Function PSUTerm_PsuLimitA() As Double
    PSUTerm_PsuLimitA = PSU_LIMIT_A
End Function

Public Function PSUTerm_PsuLimitMM() As Double
    PSUTerm_PsuLimitMM = PSU_LIMIT_MM
End Function

Public Function PSUTerm_TerminalLimitA() As Double
    PSUTerm_TerminalLimitA = TERM_LIMIT_A
End Function

Public Function PSUTerm_TerminalLimitMM() As Double
    PSUTerm_TerminalLimitMM = TERM_LIMIT_MM
End Function

Public Function PSUTerm_TerminalLimitFt() As Double
    PSUTerm_TerminalLimitFt = TERM_LIMIT_MM / 304.8
End Function

Public Function PSUTerm_TerminalCount() As Long
    PSUTerm_TerminalCount = TERM_COUNT
End Function

Public Sub PSUTerm_ResetState(ByRef termLoad() As Double, _
                              ByRef termLengthMM() As Double, _
                              ByRef termSequence() As String)
    Dim i As Long
    For i = 1 To TERM_COUNT
        termLoad(i) = 0#
        termLengthMM(i) = 0#
        termSequence(i) = vbNullString
    Next i
End Sub

Public Function PSUTerm_FindTerminal(ByRef termLoad() As Double, _
                                     ByRef termLengthMM() As Double, _
                                     ByVal loadA As Double, _
                                     ByVal lengthContributionMM As Double) As Long
    Dim i As Long

    If loadA < 0# Then loadA = 0#
    If lengthContributionMM < 0# Then lengthContributionMM = 0#

    'Each terminal receives up to 20 ft of the group's center-span increments.
    'The whole PSU still has its independent 35 ft center-span ceiling.
    If loadA > TERM_LIMIT_A Then Exit Function
    If lengthContributionMM > TERM_LIMIT_MM Then Exit Function

    For i = 1 To TERM_COUNT
        If termLoad(i) + loadA <= TERM_LIMIT_A Then
            If termLengthMM(i) + lengthContributionMM <= TERM_LIMIT_MM Then
                PSUTerm_FindTerminal = i
                Exit Function
            End If
        End If
    Next i
End Function

Public Sub PSUTerm_Reserve(ByRef termLoad() As Double, _
                           ByRef termLengthMM() As Double, _
                           ByRef termSequence() As String, _
                           ByVal terminalIndex As Long, _
                           ByVal loadA As Double, _
                           ByVal lengthContributionMM As Double, _
                           ByVal deviceLabel As String)
    If terminalIndex < 1 Or terminalIndex > TERM_COUNT Then Exit Sub

    If loadA < 0# Then loadA = 0#
    If lengthContributionMM < 0# Then lengthContributionMM = 0#

    termLoad(terminalIndex) = termLoad(terminalIndex) + loadA
    termLengthMM(terminalIndex) = termLengthMM(terminalIndex) + lengthContributionMM
    PSUTerm_AppendText termSequence(terminalIndex), deviceLabel, ", "
End Sub

Public Function PSUTerm_TerminalName(ByVal terminalIndex As Long) As String
    'Compatibility function retained for mod06; user-facing value is PSUDESC.
    PSUTerm_LoadTerminalNames
    If terminalIndex >= 1 And terminalIndex <= TERM_COUNT Then
        PSUTerm_TerminalName = mTerminalDesc(terminalIndex)
    End If
End Function

Public Function PSUTerm_TerminalCode(ByVal terminalIndex As Long) As String
    PSUTerm_LoadTerminalNames
    If terminalIndex >= 1 And terminalIndex <= TERM_COUNT Then
        PSUTerm_TerminalCode = mTerminalCode(terminalIndex)
    End If
End Function

Public Function PSUTerm_TerminalDescription(ByVal terminalIndex As Long) As String
    PSUTerm_TerminalDescription = PSUTerm_TerminalName(terminalIndex)
End Function

Public Function PSUTerm_ProjectCenteredSpanMM(ByVal sequenceCount As Long, _
                                                  ByVal currentSpanMM As Double, _
                                                  ByVal lastModuleMM As Double, _
                                                  ByVal newModuleMM As Double) As Double
    If currentSpanMM < 0# Then currentSpanMM = 0#
    If lastModuleMM < 0# Then lastModuleMM = 0#
    If newModuleMM < 0# Then newModuleMM = 0#

    If newModuleMM <= 0# Then
        PSUTerm_ProjectCenteredSpanMM = currentSpanMM
    ElseIf sequenceCount <= 0 Then
        'Single powered conveyor: PSU is at 50% of that conveyor.
        PSUTerm_ProjectCenteredSpanMM = newModuleMM / 2#
    ElseIf sequenceCount = 1 Then
        'First center -> second center = 50% first + 50% second.
        PSUTerm_ProjectCenteredSpanMM = currentSpanMM + (newModuleMM / 2#)
    Else
        'Each next center-to-center hop adds 50% old last + 50% new module.
        PSUTerm_ProjectCenteredSpanMM = currentSpanMM + (lastModuleMM / 2#) + (newModuleMM / 2#)
    End If
End Function

Public Sub PSUTerm_AcceptCenteredSpan(ByRef sequenceCount As Long, _
                                      ByRef currentSpanMM As Double, _
                                      ByRef lastModuleMM As Double, _
                                      ByVal newModuleMM As Double)
    currentSpanMM = PSUTerm_ProjectCenteredSpanMM(sequenceCount, currentSpanMM, lastModuleMM, newModuleMM)
    If newModuleMM > 0# Then
        sequenceCount = sequenceCount + 1
        lastModuleMM = newModuleMM
    End If
End Sub

Public Function PSUTerm_BusLengthMM(ByVal busText As String, _
                                    ByVal blockText As String, _
                                    ByVal moduleLengthValue As Variant, _
                                    ByRef includeRecord As Boolean) As Double
    Dim busKey As String
    Dim blockKey As String
    Dim mlMM As Double

    busKey = UCase$(Trim$(busText))
    busKey = Replace$(busKey, " ", vbNullString)
    If busKey = "BUS1" Then busKey = "BUS-1"
    If busKey = "BUS2" Then busKey = "BUS-2"

    blockKey = PSUTerm_BlockKey(blockText)
    mlMM = PSUTerm_LengthValueMM(moduleLengthValue)
    includeRecord = True

    If busKey = "BUS-1" Then
        If blockKey = "INTERFACE_CARD" Then
            'Mod03 rule: Interface Card receives BUS-1 power but does not consume
            'conveyor/module length in the BUS-1 estimate.
            PSUTerm_BusLengthMM = 0#
        Else
            PSUTerm_BusLengthMM = mlMM
        End If
    ElseIf busKey = "BUS-2" Then
        If blockKey = "INTERFACE_CARD" Then
            'Mod03 rule: Interface Card does not receive BUS-2 power.
            includeRecord = False
            PSUTerm_BusLengthMM = 0#
        Else
            PSUTerm_BusLengthMM = mlMM
        End If
    Else
        includeRecord = False
    End If
End Function

Public Function PSUTerm_LengthValueMM(ByVal valueIn As Variant) As Double
    Dim s As String
    Dim n As Double
    Dim hasMM As Boolean, hasFT As Boolean, hasIN As Boolean

    If IsError(valueIn) Or IsNull(valueIn) Or IsEmpty(valueIn) Then Exit Function

    If IsNumeric(valueIn) Then
        'The PD Master header is explicitly Module Length (ML), whose engineering
        'unit is millimetres. Numeric values are therefore treated as mm.
        n = CDbl(valueIn)
        If n > 0# Then PSUTerm_LengthValueMM = n
        Exit Function
    End If

    s = UCase$(Trim$(CStr(valueIn)))
    If Len(s) = 0 Then Exit Function

    hasMM = (InStr(1, s, "MM", vbTextCompare) > 0)
    hasFT = (InStr(1, s, "FT", vbTextCompare) > 0 Or InStr(1, s, "FEET", vbTextCompare) > 0 Or InStr(1, s, "FOOT", vbTextCompare) > 0 Or InStr(1, s, "'", vbTextCompare) > 0)
    hasIN = (InStr(1, s, "IN", vbTextCompare) > 0 Or InStr(1, s, "INCH", vbTextCompare) > 0 Or InStr(1, s, Chr$(34), vbTextCompare) > 0)

    s = Replace$(s, "MILLIMETERS", vbNullString)
    s = Replace$(s, "MILLIMETRES", vbNullString)
    s = Replace$(s, "MM", vbNullString)
    s = Replace$(s, "FEET", vbNullString)
    s = Replace$(s, "FOOT", vbNullString)
    s = Replace$(s, "FT", vbNullString)
    s = Replace$(s, "INCHES", vbNullString)
    s = Replace$(s, "INCH", vbNullString)
    s = Replace$(s, "IN", vbNullString)
    s = Replace$(s, "'", vbNullString)
    s = Replace$(s, Chr$(34), vbNullString)
    s = Replace$(s, ",", vbNullString)
    s = Trim$(s)

    If Not IsNumeric(s) Then Exit Function
    n = CDbl(s)
    If n <= 0# Then Exit Function

    If hasFT Then
        PSUTerm_LengthValueMM = n * 304.8
    ElseIf hasIN Then
        PSUTerm_LengthValueMM = n * 25.4
    Else
        'No explicit unit: PD Master ML is mm.
        PSUTerm_LengthValueMM = n
    End If
End Function

Public Function PSUTerm_BlockKey(ByVal valueIn As Variant) As String
    Dim s As String
    If IsError(valueIn) Or IsEmpty(valueIn) Then Exit Function
    s = UCase$(Trim$(CStr(valueIn)))
    s = Replace$(s, "-", "_")
    s = Replace$(s, " ", vbNullString)
    If s = "INTERFACECARD" Or s = "INTERFACE_CARD" Then s = "INTERFACE_CARD"
    PSUTerm_BlockKey = s
End Function

Public Sub PSUTerm_ResetTerminalNameCache()
    If PDPerf_IsYielding Then Exit Sub
    mNamesLoaded = False
End Sub

Private Sub PSUTerm_LoadTerminalNames()
    Dim defaultsCode As Variant, defaultsDesc As Variant
    Dim ws As Worksheet
    Dim cTerm As Long, cDesc As Long, lr As Long, r As Long, i As Long
    Dim codeText As String, descText As String
    Dim codeToDesc As Object, seen As Object

    If mNamesLoaded Then Exit Sub

    defaultsCode = Array("X1TERM05", "X1TERM07", "X1TERM09", "X1TERM11")
    defaultsDesc = Array("DC1+/DC1-", "DC2+/DC2-", "DC3+/DC3-", "DC4+/DC4-")
    For i = 1 To TERM_COUNT
        mTerminalCode(i) = CStr(defaultsCode(i - 1))
        mTerminalDesc(i) = CStr(defaultsDesc(i - 1))
    Next i

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("DATA_POWER")
    On Error GoTo 0

    If ws Is Nothing Then
        On Error Resume Next
        Set ws = ThisWorkbook.Worksheets("480v_DATA_POWER")
        On Error GoTo 0
    End If

    If ws Is Nothing Then
        mNamesLoaded = True
        Exit Sub
    End If

    cTerm = PSUTerm_FindHeader(ws, "PSU TERM")
    If cTerm = 0 Then cTerm = PSUTerm_FindHeader(ws, "PSU_TERMINAL")
    cDesc = PSUTerm_FindHeader(ws, "PSUDESC")
    If cDesc = 0 Then cDesc = PSUTerm_FindHeader(ws, "PSU DESC")
    If cTerm = 0 Then
        mNamesLoaded = True
        Exit Sub
    End If

    Set codeToDesc = CreateObject("Scripting.Dictionary")
    codeToDesc.CompareMode = vbTextCompare
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare

    lr = ws.Cells(ws.rows.count, cTerm).End(xlUp).Row
    For r = 2 To lr
        PDPerf_Pulse "mod22_PSUTerminalAllocator.PSUTerm_LoadTerminalNames [L321]" & " row " & CStr(r)
        codeText = Trim$(CStr(ws.Cells(r, cTerm).Value2))
        If Len(codeText) > 0 Then
            descText = vbNullString
            If cDesc > 0 Then descText = PSUTerm_CleanDescription(ws.Cells(r, cDesc).Value2)
            If Len(descText) > 0 Then codeToDesc(codeText) = descText
        End If
    Next r

    For i = 1 To TERM_COUNT
        If codeToDesc.Exists(mTerminalCode(i)) Then
            mTerminalDesc(i) = CStr(codeToDesc(mTerminalCode(i)))
        End If
    Next i

    'Fallback for a project using different terminal codes: preserve first-four
    'worksheet order and use the corresponding PSUDESC values.
    i = 0
    For r = 2 To lr
        PDPerf_Pulse "mod22_PSUTerminalAllocator.PSUTerm_LoadTerminalNames [L339]" & " row " & CStr(r)
        codeText = Trim$(CStr(ws.Cells(r, cTerm).Value2))
        If Len(codeText) > 0 Then
            If Not seen.Exists(codeText) Then
                seen(codeText) = True
                i = i + 1
                If i <= TERM_COUNT Then
                    If Not codeToDesc.Exists(CStr(defaultsCode(i - 1))) Then
                        mTerminalCode(i) = codeText
                        If cDesc > 0 Then
                            descText = PSUTerm_CleanDescription(ws.Cells(r, cDesc).Value2)
                            If Len(descText) > 0 Then mTerminalDesc(i) = descText
                        End If
                    End If
                End If
                If i >= TERM_COUNT Then Exit For
            End If
        End If
    Next r

    mNamesLoaded = True
End Sub

Private Function PSUTerm_CleanDescription(ByVal valueIn As Variant) As String
    Dim s As String
    If IsError(valueIn) Or IsEmpty(valueIn) Then Exit Function
    s = Trim$(CStr(valueIn))
    Do While Len(s) > 0 And Left$(s, 1) = "="
        s = Trim$(Mid$(s, 2))
    Loop
    If Len(s) > 1 Then
        If Left$(s, 1) = Chr$(34) And Right$(s, 1) = Chr$(34) Then
            s = Mid$(s, 2, Len(s) - 2)
        End If
    End If
    PSUTerm_CleanDescription = Trim$(s)
End Function

Private Function PSUTerm_FindHeader(ByVal ws As Worksheet, ByVal headerName As String) As Long
    Dim lc As Long, c As Long
    Dim target As String, cur As String

    If ws Is Nothing Then Exit Function
    lc = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    target = PSUTerm_HeaderKey(headerName)

    For c = 1 To lc
        cur = PSUTerm_HeaderKey(ws.Cells(1, c).Value2)
        If cur = target Then
            PSUTerm_FindHeader = c
            Exit Function
        End If
    Next c
End Function

Private Function PSUTerm_HeaderKey(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(v)))
    s = Replace$(s, " ", vbNullString)
    s = Replace$(s, "_", vbNullString)
    s = Replace$(s, "-", vbNullString)
    s = Replace$(s, "(", vbNullString)
    s = Replace$(s, ")", vbNullString)
    PSUTerm_HeaderKey = s
End Function

Private Sub PSUTerm_AppendText(ByRef target As String, ByVal valueText As String, ByVal delimiter As String)
    valueText = Trim$(valueText)
    If Len(valueText) = 0 Then Exit Sub
    If Len(target) = 0 Then
        target = valueText
    Else
        target = target & delimiter & valueText
    End If
End Sub
