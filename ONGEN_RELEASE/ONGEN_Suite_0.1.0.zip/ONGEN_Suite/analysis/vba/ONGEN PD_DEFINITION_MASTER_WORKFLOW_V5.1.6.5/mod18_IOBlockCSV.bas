Attribute VB_Name = "mod18_IOBlockCSV"
Option Explicit

Public Sub Export_IOBLOCK_To_CSV()
    If PDPerf_IsYielding Then Exit Sub

    Dim wsSrc As Worksheet
    Dim wbNew As Workbook
    Dim wsNew As Worksheet
    Dim savePath As Variant
    Dim lastRow As Long
    Dim lastCol As Long

    On Error Resume Next
    Set wsSrc = ThisWorkbook.Worksheets("IO DEVICE EM")
    On Error GoTo 0

    If wsSrc Is Nothing Then
        MsgBox "Worksheet 'IO DEVICE EM' not found.", vbCritical
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    lastRow = wsSrc.Cells.Find("*", SearchOrder:=xlByRows, SearchDirection:=xlPrevious).Row
    lastCol = wsSrc.Cells.Find("*", SearchOrder:=xlByColumns, SearchDirection:=xlPrevious).Column

    Set wbNew = Workbooks.Add(xlWBATWorksheet)
    Set wsNew = wbNew.Worksheets(1)

    wsNew.name = "EM_HARDWARE_IO_BLOCK"

    wsSrc.Range(wsSrc.Cells(1, 1), wsSrc.Cells(lastRow, lastCol)).Copy
    wsNew.Range("A1").PasteSpecial xlPasteValues

    ' V4.6.6: every PD Master CSV includes standardized traceability.
    ' Device/IO rows resolve their physical ML/ZL through their parent SIS
    ' when an exact SIS row is not available.
    mod23_WorksheetNavigation.NAV_Remove_Navigation_Controls wsNew

    mod21_CSVTraceability.CSVTrace_EnsureTraceColumns wsNew, _
        Array("SIS_SEQUENCE", "SEQUENCE", "DEVICE NAME", "BLOCK ID"), _
        Array("PARENT SIS_SEQUENCE", "BASE SIS_SEQUENCE", "SEQUENCE"), _
        Array("LPN")

    Application.CutCopyMode = False

    savePath = Application.GetSaveAsFilename( _
                InitialFileName:="EM_HARDWARE_IO_BLOCK.csv", _
                FileFilter:="CSV Files (*.csv), *.csv")

    If savePath <> False Then

        wbNew.SaveAs Filename:=CStr(savePath), _
                     FileFormat:=xlCSVUTF8

        MsgBox "CSV exported successfully:" & vbCrLf & savePath, vbInformation

    Else

        wbNew.Close SaveChanges:=False
        MsgBox "Export cancelled.", vbExclamation

    End If

    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

End Sub



