Attribute VB_Name = "mod23_WorksheetNavigation"
Option Explicit

'===============================================================================
' PD MASTER V4.7.6 - ONGEN FORM-CONTROL WORKSHEET NAVIGATION
'
' Corrected to match the worksheet-navigation control architecture used by
' ONGEN V25.7.8.26:
'   - Worksheet navigation controls are Excel FORMS BUTTONS (ws.Buttons.Add).
'   - The visible text is set with Button.Caption.
'   - The Worksheet Launcher itself remains the permanent frmPDLauncher UserForm.
'
' Every non-MAIN worksheet receives:
'   btnReturnToMAIN      -> NAV_Return_To_MAIN       -> "Return Home"
'   btnWorksheetLauncher -> NAV_Open_Worksheet_Launcher -> "Sheet Launcher"
'
' CSV/export routines can call NAV_Remove_Navigation_Controls on a temporary
' export worksheet so no navigation buttons are carried into the CSV copy.
'===============================================================================

Private Const HOME_SHEET As String = "MAIN"
Private Const LEGACY_LAUNCHER_SHEET As String = "WORKSHEET LAUNCHER"

Private Const BTN_HOME As String = "btnReturnToMAIN"
Private Const BTN_LAUNCHER As String = "btnWorksheetLauncher"

Private Const CAPTION_HOME As String = "Return Home"
Private Const CAPTION_LAUNCHER As String = "Sheet Launcher"

Private Const MACRO_HOME As String = "NAV_Return_To_MAIN"
Private Const MACRO_LAUNCHER As String = "NAV_Open_Worksheet_Launcher"

'Keep the established PD Master locations so existing worksheet layouts do not
'move. Only the CONTROL TYPE changes back to the ONGEN Forms Button architecture.
Private Const HOME_ANCHOR As String = "I2:K3"
Private Const LAUNCHER_ANCHOR As String = "L2:N3"

'-------------------------------------------------------------------------------
' PUBLIC NAVIGATION ACTIONS
'-------------------------------------------------------------------------------
Public Sub NAV_Open_Worksheet_Launcher()
    If PDPerf_IsYielding Then Exit Sub
    On Error GoTo Failed

    NAV_Remove_Legacy_Launcher_Worksheet False
    mod01_UI.UI_ShowLauncher
    Exit Sub

Failed:
    MsgBox "The worksheet launcher could not be opened." & vbCrLf & _
           "Confirm frmPDLauncher is installed in this PD Master." & vbCrLf & vbCrLf & _
           "Error " & Err.number & ": " & Err.description, _
           vbExclamation, "PD Master Worksheet Launcher"
End Sub

Public Sub NAV_Return_To_MAIN()
    If PDPerf_IsYielding Then Exit Sub
    Dim wsHome As Worksheet

    On Error GoTo Failed
    Set wsHome = NAV_GetSheet(HOME_SHEET)
    If wsHome Is Nothing Then Err.Raise vbObjectError + 2301, , "MAIN worksheet was not found."

    If wsHome.Visible <> xlSheetVisible Then wsHome.Visible = xlSheetVisible
    ThisWorkbook.Activate
    wsHome.Activate
    On Error Resume Next
    wsHome.Range("A1").Select
    On Error GoTo 0
    Exit Sub

Failed:
    MsgBox "The MAIN worksheet could not be opened." & vbCrLf & _
           Err.description, vbExclamation, "PD Master Navigation"
End Sub

'-------------------------------------------------------------------------------
' INSTALL / REPAIR
'-------------------------------------------------------------------------------
Public Sub NAV_Install_Worksheet_Navigation_All_Sheets( _
    Optional ByVal showMessage As Boolean = True)

    Dim ws As Worksheet
    Dim installed As Long
    Dim failedCount As Long
    Dim oldScreen As Boolean
    Dim oldEvents As Boolean

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents

    On Error GoTo FatalError
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    NAV_Remove_Legacy_Launcher_Worksheet False

    For Each ws In ThisWorkbook.Worksheets
        PDPerf_Pulse "mod23_WorksheetNavigation.NAV_Install_Worksheet_Navigation_All_Sheets [L96]"
        On Error Resume Next
        NAV_Ensure_Worksheet_Navigation ws
        If Err.number = 0 Then
            installed = installed + 1
        Else
            failedCount = failedCount + 1
            Err.Clear
        End If
        On Error GoTo FatalError
    Next ws

CleanExit:
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    If showMessage Then
        If failedCount = 0 Then
            MsgBox "Worksheet navigation was installed or repaired on " & _
                   CStr(installed) & " worksheet(s)." & vbCrLf & _
                   "Return Home controls are ONGEN-style Forms Buttons.", _
                   vbInformation, "PD Master Worksheet Navigation"
        Else
            MsgBox "Worksheet navigation completed with " & CStr(failedCount) & _
                   " worksheet failure(s).", vbExclamation, _
                   "PD Master Worksheet Navigation"
        End If
    End If
    Exit Sub

FatalError:
    failedCount = failedCount + 1
    Resume CleanExit
End Sub

'Backward-compatible MAIN button entry point.
Public Sub BTN_Install_Return_To_MAIN_Buttons()
    If PDPerf_IsYielding Then Exit Sub
    NAV_Install_Worksheet_Navigation_All_Sheets True
End Sub

'Use this once after importing V4.7.6. It removes every legacy blank AutoShape /
'Forms/OLE version of the two navigation controls and recreates ONGEN Forms
'Buttons with explicit captions.
Public Sub NAV_Repair_Return_HOME_Buttons()
    If PDPerf_IsYielding Then Exit Sub
    Dim ws As Worksheet
    Dim repaired As Long
    Dim Failed As Long
    Dim oldScreen As Boolean
    Dim oldEvents As Boolean

    oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents

    On Error GoTo Fatal
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    For Each ws In ThisWorkbook.Worksheets
        PDPerf_Pulse "mod23_WorksheetNavigation.NAV_Repair_Return_HOME_Buttons [L153]"
        On Error Resume Next
        If StrComp(ws.name, HOME_SHEET, vbTextCompare) <> 0 Then
            NAV_Remove_Home_Button_From_Worksheet ws
            NAV_Remove_Launcher_Button_From_Worksheet ws, False
            NAV_Ensure_Worksheet_Navigation ws
            If Err.number = 0 Then
                repaired = repaired + 1
            Else
                Failed = Failed + 1
                Err.Clear
            End If
        Else
            NAV_Remove_Home_Button_From_Worksheet ws
        End If
        On Error GoTo Fatal
    Next ws

done:
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen

    If Failed = 0 Then
        MsgBox CStr(repaired) & " worksheet(s) repaired." & vbCrLf & _
               "The button caption is now exactly: Return Home", _
               vbInformation, "PD Master Navigation"
    Else
        MsgBox CStr(repaired) & " worksheet(s) repaired; " & CStr(Failed) & _
               " worksheet(s) failed.", vbExclamation, "PD Master Navigation"
    End If
    Exit Sub

Fatal:
    Failed = Failed + 1
    Resume done
End Sub


'Called immediately whenever workflow code creates a worksheet.
Public Sub NAV_Ensure_Worksheet_Navigation(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    If Not (ws.parent Is ThisWorkbook) Then Exit Sub

    If StrComp(ws.name, HOME_SHEET, vbTextCompare) = 0 Then
        NAV_Remove_Home_Button_From_Worksheet ws

        'MAIN normally contains the large launcher button from the dashboard.
        'Only add the small ONGEN Forms Button when no launcher action exists.
        If Not NAV_Worksheet_HasLauncherAction(ws) Then
            NAV_Ensure_Launcher_Button ws, False
        End If
        Exit Sub
    End If

    NAV_Ensure_Home_Button ws
    NAV_Ensure_Launcher_Button ws, True
End Sub

'-------------------------------------------------------------------------------
' ONGEN-STYLE FORMS BUTTON CREATION
'-------------------------------------------------------------------------------
Private Sub NAV_Ensure_Home_Button(ByVal ws As Worksheet)
    Dim anchor As Range
    Dim btn As Button

    Set anchor = ws.Range(HOME_ANCHOR)

    'Always recreate. This guarantees that an old blank AutoShape, Forms
    'button, or OLE control can never survive and cover the new caption.
    NAV_Remove_Home_Button_From_Worksheet ws

    Set btn = ws.Buttons.Add(anchor.Left, anchor.Top, anchor.Width, anchor.Height)
    NAV_Format_Forms_Button btn, BTN_HOME, CAPTION_HOME, MACRO_HOME, RGB(0, 0, 0)
End Sub

Private Sub NAV_Ensure_Launcher_Button(ByVal ws As Worksheet, ByVal placeNormal As Boolean)
    Dim anchor As Range
    Dim btn As Button

    If placeNormal Then
        Set anchor = ws.Range(LAUNCHER_ANCHOR)
    Else
        Set anchor = ws.Range(LAUNCHER_ANCHOR)
    End If

    NAV_Remove_Launcher_Button_From_Worksheet ws, False

    Set btn = ws.Buttons.Add(anchor.Left, anchor.Top, anchor.Width, anchor.Height)
    NAV_Format_Forms_Button btn, BTN_LAUNCHER, CAPTION_LAUNCHER, MACRO_LAUNCHER, RGB(0, 102, 204)
End Sub

Private Sub NAV_Format_Forms_Button( _
    ByVal btn As Button, _
    ByVal buttonName As String, _
    ByVal buttonCaption As String, _
    ByVal macroName As String, _
    ByVal fillColor As Long)

    Dim shp As Shape

    If btn Is Nothing Then Exit Sub

    btn.name = buttonName
    btn.caption = buttonCaption
    btn.OnAction = NAV_QualifiedMacroName(macroName)
    btn.Placement = xlFreeFloating
    btn.PrintObject = False
    btn.Locked = True

    On Error Resume Next
    btn.Font.name = "Arial"
    btn.Font.Size = 9
    btn.Font.Bold = True
    btn.Font.Color = RGB(0, 0, 0)

    Set shp = btn.parent.Shapes(buttonName)
    If Not shp Is Nothing Then
        shp.AlternativeText = "PD Master workbook navigation control."
        shp.OnAction = NAV_QualifiedMacroName(macroName)
        shp.PrintObject = False
        shp.Placement = xlFreeFloating

        'The authoritative caption is Button.Caption. TextFrame is written as
        'a second compatibility layer, exactly as ONGEN does.
        shp.TextFrame.Characters.Text = buttonCaption
        shp.TextFrame.HorizontalAlignment = xlHAlignCenter
        shp.TextFrame.VerticalAlignment = xlVAlignCenter
        shp.TextFrame.Characters.Font.name = "Arial"
        shp.TextFrame.Characters.Font.Size = 9
        shp.TextFrame.Characters.Font.Bold = True
        shp.TextFrame.Characters.Font.Color = RGB(0, 0, 0)

        shp.Fill.Visible = msoTrue
        shp.Fill.ForeColor.RGB = fillColor
        shp.line.Visible = msoTrue
        shp.line.ForeColor.RGB = RGB(0, 0, 0)

        'Reassert the Form-Control caption LAST. This is the line Excel renders
        'for ws.Buttons controls and eliminates the blank-caption condition.
        btn.caption = buttonCaption
    End If
    Err.Clear
    On Error GoTo 0
End Sub

'-------------------------------------------------------------------------------
' CSV / EXPORT CLEANUP
'-------------------------------------------------------------------------------
Public Sub NAV_Remove_Navigation_Controls(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub

    NAV_Remove_Home_Button_From_Worksheet ws
    NAV_Remove_Launcher_Button_From_Worksheet ws, True
End Sub

Public Sub NAV_Remove_ONGEN_Navigation_Buttons_From_Worksheet(ByVal ws As Worksheet)
    NAV_Remove_Navigation_Controls ws
End Sub

Public Sub NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook(ByVal wb As Workbook)
    Dim ws As Worksheet
    If wb Is Nothing Then Exit Sub

    On Error Resume Next
    For Each ws In wb.Worksheets
        PDPerf_Pulse "mod23_WorksheetNavigation.NAV_Remove_ONGEN_Navigation_Buttons_From_Workbook [L317]"
        NAV_Remove_Navigation_Controls ws
    Next ws
    On Error GoTo 0
End Sub

'-------------------------------------------------------------------------------
' REMOVE LEGACY / DUPLICATE NAVIGATION CONTROLS
'-------------------------------------------------------------------------------
Private Sub NAV_Remove_Home_Button_From_Worksheet(ByVal ws As Worksheet)
    Dim i As Long
    Dim actionText As String
    Dim shapeName As String
    Dim captionText As String

    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Buttons(BTN_HOME).Delete
    ws.Shapes(BTN_HOME).Delete
    ws.OLEObjects(BTN_HOME).Delete

    For i = ws.Shapes.count To 1 Step -1
        shapeName = ws.Shapes(i).name
        actionText = ws.Shapes(i).OnAction
        captionText = NAV_ShapeCaption(ws.Shapes(i))

        If StrComp(shapeName, BTN_HOME, vbTextCompare) = 0 Or _
           NAV_ActionTargetsMacro(actionText, MACRO_HOME) Or _
           StrComp(Trim$(captionText), "Return Home", vbTextCompare) = 0 Or _
           StrComp(Trim$(captionText), "Return HOME", vbTextCompare) = 0 Or _
           StrComp(Trim$(captionText), "Return To Home", vbTextCompare) = 0 Or _
           StrComp(Trim$(captionText), "Return to MAIN", vbTextCompare) = 0 Then
            ws.Shapes(i).Delete
        End If
    Next i
    On Error GoTo 0
End Sub

Private Sub NAV_Remove_Launcher_Button_From_Worksheet( _
    ByVal ws As Worksheet, _
    ByVal removeAnyLauncherAction As Boolean)

    Dim i As Long
    Dim actionText As String
    Dim shapeName As String
    Dim captionText As String

    If ws Is Nothing Then Exit Sub

    On Error Resume Next
    ws.Buttons(BTN_LAUNCHER).Delete
    ws.Shapes(BTN_LAUNCHER).Delete
    ws.OLEObjects(BTN_LAUNCHER).Delete

    For i = ws.Shapes.count To 1 Step -1
        shapeName = ws.Shapes(i).name
        actionText = ws.Shapes(i).OnAction
        captionText = NAV_ShapeCaption(ws.Shapes(i))

        If StrComp(shapeName, BTN_LAUNCHER, vbTextCompare) = 0 Or _
           NAV_ActionTargetsMacro(actionText, MACRO_LAUNCHER) Or _
           StrComp(Trim$(captionText), CAPTION_LAUNCHER, vbTextCompare) = 0 Or _
           (removeAnyLauncherAction And NAV_IsAnyLauncherAction(actionText)) Then
            ws.Shapes(i).Delete
        End If
    Next i
    On Error GoTo 0
End Sub

'-------------------------------------------------------------------------------
' LEGACY WORKSHEET-LAUNCHER REMOVAL
'-------------------------------------------------------------------------------
Public Sub NAV_Remove_Legacy_Launcher_Worksheet( _
    Optional ByVal showMessage As Boolean = True)

    Dim ws As Worksheet
    Dim oldAlerts As Boolean

    Set ws = NAV_GetSheet(LEGACY_LAUNCHER_SHEET)
    If ws Is Nothing Then
        If showMessage Then
            MsgBox "No legacy WORKSHEET LAUNCHER sheet exists.", _
                   vbInformation, "PD Master Worksheet Launcher"
        End If
        Exit Sub
    End If

    If ThisWorkbook.ProtectStructure Then
        If showMessage Then
            MsgBox "The legacy WORKSHEET LAUNCHER sheet could not be removed because " & _
                   "workbook structure is protected.", vbExclamation, _
                   "PD Master Worksheet Launcher"
        End If
        Exit Sub
    End If

    oldAlerts = Application.DisplayAlerts
    On Error GoTo Failed
    Application.DisplayAlerts = False
    ws.Delete
    Application.DisplayAlerts = oldAlerts

    If showMessage Then
        MsgBox "The obsolete worksheet-based launcher was removed.", _
               vbInformation, "PD Master Worksheet Launcher"
    End If
    Exit Sub

Failed:
    Application.DisplayAlerts = oldAlerts
    If showMessage Then
        MsgBox "The legacy launcher worksheet could not be removed." & vbCrLf & _
               "Error " & Err.number & ": " & Err.description, _
               vbExclamation, "PD Master Worksheet Launcher"
    End If
End Sub

'-------------------------------------------------------------------------------
' AUDIT
'-------------------------------------------------------------------------------
Public Sub NAV_Audit_Worksheet_Navigation_Buttons()
    If PDPerf_IsYielding Then Exit Sub
    Dim ws As Worksheet
    Dim issues As String
    Dim checked As Long

    For Each ws In ThisWorkbook.Worksheets
        PDPerf_Pulse "mod23_WorksheetNavigation.NAV_Audit_Worksheet_Navigation_Buttons [L443]"
        checked = checked + 1

        If StrComp(ws.name, HOME_SHEET, vbTextCompare) = 0 Then
            If Not NAV_Worksheet_HasLauncherAction(ws) Then
                issues = issues & vbCrLf & "- MAIN: launcher action is missing"
            End If
        Else
            If Not NAV_Button_Is_Valid(ws, BTN_HOME, CAPTION_HOME, MACRO_HOME) Then
                issues = issues & vbCrLf & "- " & ws.name & ": Return Home missing/blank/invalid"
            End If
            If Not NAV_Button_Is_Valid(ws, BTN_LAUNCHER, CAPTION_LAUNCHER, MACRO_LAUNCHER) Then
                issues = issues & vbCrLf & "- " & ws.name & ": Sheet Launcher missing/invalid"
            End If
        End If
    Next ws

    If Not NAV_GetSheet(LEGACY_LAUNCHER_SHEET) Is Nothing Then
        issues = issues & vbCrLf & "- Obsolete WORKSHEET LAUNCHER worksheet still exists"
    End If

    If Len(issues) = 0 Then
        MsgBox CStr(checked) & " worksheets contain valid PD Master navigation controls." & vbCrLf & _
               "Return button caption: " & CAPTION_HOME & vbCrLf & _
               "Control type: Excel Forms Button (ONGEN architecture).", _
               vbInformation, "PD Master Navigation Audit"
    Else
        MsgBox "Navigation audit found:" & vbCrLf & issues, _
               vbExclamation, "PD Master Navigation Audit"
    End If
End Sub

Public Sub NAV_Audit_Return_To_MAIN_Buttons()
    If PDPerf_IsYielding Then Exit Sub
    NAV_Audit_Worksheet_Navigation_Buttons
End Sub

'-------------------------------------------------------------------------------
' INTERNAL HELPERS
'-------------------------------------------------------------------------------
Private Function NAV_Button_Is_Valid( _
    ByVal ws As Worksheet, _
    ByVal buttonName As String, _
    ByVal expectedCaption As String, _
    ByVal expectedMacro As String) As Boolean

    Dim btn As Button

    On Error Resume Next
    Set btn = ws.Buttons(buttonName)
    On Error GoTo 0

    If btn Is Nothing Then Exit Function
    If StrComp(Trim$(btn.caption), expectedCaption, vbTextCompare) <> 0 Then Exit Function
    If Not NAV_ActionTargetsMacro(btn.OnAction, expectedMacro) Then Exit Function

    NAV_Button_Is_Valid = True
End Function

Private Function NAV_Worksheet_HasLauncherAction(ByVal ws As Worksheet) As Boolean
    Dim i As Long
    Dim actionText As String

    If ws Is Nothing Then Exit Function

    On Error Resume Next
    For i = 1 To ws.Shapes.count
        actionText = ws.Shapes(i).OnAction
        If NAV_IsAnyLauncherAction(actionText) Then
            NAV_Worksheet_HasLauncherAction = True
            Exit Function
        End If
    Next i
    On Error GoTo 0
End Function

Private Function NAV_IsAnyLauncherAction(ByVal actionText As String) As Boolean
    NAV_IsAnyLauncherAction = _
        NAV_ActionTargetsMacro(actionText, MACRO_LAUNCHER) Or _
        NAV_ActionTargetsMacro(actionText, "UI_ShowLauncher") Or _
        NAV_ActionTargetsMacro(actionText, "BTN_Open_PD_Launcher")
End Function

Private Function NAV_ActionTargetsMacro( _
    ByVal actionText As String, _
    ByVal macroName As String) As Boolean

    Dim normalized As String
    Dim target As String

    normalized = UCase$(Trim$(actionText))
    normalized = Replace(normalized, "'", vbNullString)
    target = UCase$(Trim$(macroName))

    If Len(normalized) < Len(target) Then Exit Function
    NAV_ActionTargetsMacro = (Right$(normalized, Len(target)) = target)
End Function

Private Function NAV_QualifiedMacroName(ByVal macroName As String) As String
    NAV_QualifiedMacroName = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macroName
End Function

Private Function NAV_ShapeCaption(ByVal shp As Shape) As String
    Dim s As String

    If shp Is Nothing Then Exit Function

    On Error Resume Next
    If shp.Type = msoFormControl Then s = CStr(shp.DrawingObject.caption)
    If Len(Trim$(s)) = 0 Then s = CStr(shp.TextFrame.Characters.Text)
    If Len(Trim$(s)) = 0 Then s = CStr(shp.TextFrame2.TextRange.Text)
    On Error GoTo 0

    NAV_ShapeCaption = Trim$(s)
End Function

Private Function NAV_GetSheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet

    For Each ws In ThisWorkbook.Worksheets
        PDPerf_Pulse "mod23_WorksheetNavigation.NAV_GetSheet [L561]"
        If StrComp(Trim$(ws.name), Trim$(sheetName), vbTextCompare) = 0 Then
            Set NAV_GetSheet = ws
            Exit Function
        End If
    Next ws
End Function
