Attribute VB_Name = "mod01_UI"
Option Explicit

'===============================================================================
' PD MASTER V4.7.4 - PERMANENT ONGEN-STYLE WORKSHEET LAUNCHER
'
' frmPDLauncher is a normal embedded UserForm in this workbook.
' No VBProject copying, File Explorer installer, or Trust Center automation is used.
'===============================================================================

Public Sub UI_ShowLauncher()
    If PDPerf_IsYielding Then Exit Sub
    On Error GoTo EH

    frmPDLauncher.Show vbModal
    Exit Sub

EH:
    MsgBox "frmPDLauncher could not be opened." & vbCrLf & _
           "Confirm that frmPDLauncher.frm was imported with its matching frmPDLauncher.frx file." & vbCrLf & vbCrLf & _
           "Error " & Err.number & ": " & Err.description, _
           vbExclamation, "PD Master Worksheet Launcher"
End Sub

Public Sub BTN_Open_PD_Launcher()
    If PDPerf_IsYielding Then Exit Sub
    UI_ShowLauncher
End Sub

Public Sub UI_RefreshAll()
    If PDPerf_IsYielding Then Exit Sub
    Application.ScreenUpdating = False
    On Error Resume Next
    ThisWorkbook.RefreshAll
    Application.CalculateFull
    On Error GoTo 0
    Application.ScreenUpdating = True
End Sub

Public Sub UI_GoHome()
    If PDPerf_IsYielding Then Exit Sub
    mod23_WorksheetNavigation.NAV_Return_To_MAIN
End Sub
