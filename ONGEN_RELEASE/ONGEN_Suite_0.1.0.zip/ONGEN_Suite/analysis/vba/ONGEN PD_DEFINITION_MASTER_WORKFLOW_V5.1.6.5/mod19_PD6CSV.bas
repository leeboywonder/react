Attribute VB_Name = "mod19_PD6CSV"
Option Explicit

'===============================================================================
' PD6 AutoCAD CSV export - V4.8 / EAS V25.8 alignment
'
' The CAD contract is frozen to the current PD6 System Designed 41-column
' layout. EAS-only/calculation helper columns are NEVER appended to this CSV.
'===============================================================================

Public Sub Export_PD6_Export_System_To_CSV()
    If PDPerf_IsYielding Then Exit Sub
    Dim wsSrc As Worksheet, wbCSV As Workbook, wsCSV As Worksheet
    Dim headers As Variant, srcCols() As Long, headerOut() As Variant, dataOut() As Variant
    Dim lastRow As Long, r As Long, c As Long, n As Long, outRow As Long
    Dim saveFile As Variant

    On Error GoTo ErrHandler
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual

    On Error Resume Next
    Set wsSrc = ThisWorkbook.Worksheets("PD6 System Designed")
    On Error GoTo ErrHandler
    If wsSrc Is Nothing Then Err.Raise vbObjectError + 5900, , "Sheet 'PD6 System Designed' was not found."

    headers = CAD_PD6_Headers()
    n = UBound(headers) - LBound(headers) + 1
    ReDim srcCols(1 To n)
    ReDim headerOut(1 To 1, 1 To n)

    For c = 1 To n
        headerOut(1, c) = headers(LBound(headers) + c - 1)
        srcCols(c) = CAD_HeaderCol(wsSrc, CStr(headerOut(1, c)))
        If srcCols(c) = 0 Then
            Err.Raise vbObjectError + 5901, , "PD6 System Designed is missing required CAD header: " & CStr(headerOut(1, c))
        End If
    Next c

    lastRow = CAD_LastRow(wsSrc)
    If lastRow < 2 Then Err.Raise vbObjectError + 5902, , "PD6 System Designed does not contain data rows."

    ReDim dataOut(1 To lastRow - 1, 1 To n)
    For r = 2 To lastRow
        PDPerf_Pulse "mod19_PD6CSV.Export_PD6_Export_System_To_CSV [L45]" & " row " & CStr(r)
        If Len(Trim$(CStr(wsSrc.Cells(r, srcCols(1)).Value2))) > 0 Then
            outRow = outRow + 1
            For c = 1 To n
                dataOut(outRow, c) = wsSrc.Cells(r, srcCols(c)).Value2
            Next c
        End If
    Next r
    If outRow = 0 Then Err.Raise vbObjectError + 5903, , "No PD6 rows with SIS_SEQUENCE were found."

    saveFile = Application.GetSaveAsFilename( _
                InitialFileName:="PD6 System Designed.csv", _
                FileFilter:="CSV UTF-8 (Comma delimited) (*.csv), *.csv", _
                title:="Save AutoCAD Import CSV")
    If saveFile = False Then GoTo SafeExit
    If LCase$(Right$(CStr(saveFile), 4)) <> ".csv" Then saveFile = CStr(saveFile) & ".csv"

    Set wbCSV = Workbooks.Add(xlWBATWorksheet)
    Set wsCSV = wbCSV.Worksheets(1)
    wsCSV.name = "PD6 System Designed"
    wsCSV.Cells(1, 1).Resize(1, n).Value2 = headerOut
    wsCSV.Cells(2, 1).Resize(outRow, n).Value2 = dataOut

    'Remove workbook UI controls if the navigation module is available, but do
    'not add MODULE_LENGTH_ML, ZONE_LENGTH_ZL or any EAS-only export columns.
    On Error Resume Next
    mod23_WorksheetNavigation.NAV_Remove_Navigation_Controls wsCSV
    On Error GoTo ErrHandler

    wbCSV.SaveAs Filename:=CStr(saveFile), FileFormat:=xlCSVUTF8, CreateBackup:=False
    wbCSV.Close SaveChanges:=False
    Set wbCSV = Nothing

    MsgBox "AutoCAD PD6 CSV export complete." & vbCrLf & vbCrLf & _
           "Rows: " & Format$(outRow, "#,##0") & vbCrLf & _
           "Columns: " & CStr(n) & " (frozen CAD contract; no EAS-only headers)" & vbCrLf & _
           "Saved File: " & CStr(saveFile), vbInformation, "PD6 AutoCAD CSV"

SafeExit:
    On Error Resume Next
    If Not wbCSV Is Nothing Then wbCSV.Close SaveChanges:=False
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    If Not PDPerf_IsRunning Then Application.Calculation = xlCalculationAutomatic
    Exit Sub

ErrHandler:
    MsgBox "Error during PD6 CAD export: " & Err.description, vbCritical
    Resume SafeExit
End Sub

Private Function CAD_PD6_Headers() As Variant
    CAD_PD6_Headers = Array( _
        "SIS_SEQUENCE", "SIS_ELEMENT_NUMBER", "AREA_NUMBER", "SWITCHGROUP", "Panel", "TYPE", _
        "NETWORK_IP", "LPN", "LAYER", "BLOCK", "X", "Y", "Z", "ROTATION_DEG", "SYSTEM TYPE", _
        "CONTROL_FUNCTION_NUMBER", "CONTROL_FUNCTION_TAG", "CONVEYOR TYPE", "Module Length (ML)", _
        "Motor_Power_Main_Drive", "Motor_Voltage_Main_Drive", "Motor_Brake_Voltage_Main_Drive", _
        "CURRENT_LOAD", "Encoder Type (Main Drive)", "Total Qty of Sensors", "Control Card", _
        "Qty of Control Card", "Total Qty of Drives", "Motor Power (Main Drive)", _
        "Motor Voltage (Main Drive)", "Motor Brake Voltage (Main Drive)", _
        "PART_NUM_1", "MANUF_NAME_1", "PART_NUM_2", "MANUF_NAME_2", "PART_NUM_3", _
        "MANUF_NAME_3", "PART_NUM_4", "MANUF_NAME_4", "PART_NUM_5", "MANUF_NAME_5")
End Function

Private Function CAD_HeaderCol(ByVal ws As Worksheet, ByVal wanted As String) As Long
    Dim c As Long, lc As Long, a As String, b As String
    lc = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    b = CAD_Normalize(wanted)
    For c = 1 To lc
        a = CAD_Normalize(ws.Cells(1, c).Value2)
        If a = b Then CAD_HeaderCol = c: Exit Function
    Next c
End Function

Private Function CAD_Normalize(ByVal v As Variant) As String
    Dim s As String
    s = UCase$(Trim$(CStr(v)))
    s = Replace$(s, " ", vbNullString): s = Replace$(s, "_", vbNullString)
    s = Replace$(s, "-", vbNullString): s = Replace$(s, "(", vbNullString): s = Replace$(s, ")", vbNullString)
    CAD_Normalize = s
End Function

Private Function CAD_LastRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                          LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If f Is Nothing Then CAD_LastRow = 0 Else CAD_LastRow = f.Row
End Function
