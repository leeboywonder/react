Attribute VB_Name = "EXPORT_SAP_ORDER_LIST"
Option Explicit

'==========================================================
' Macro Name : Export_SAP_POR_Order_List_A_To_P_ONLY
'
' Purpose:
'   Export ONLY columns A:P from worksheet "SAP POR ORDER LIST"
'   into a new workbook.
'
' Export Rules:
'   - Copies ONLY columns A through P
'   - Copies values only
'   - Copies formatting only from A:P
'   - Does not export formulas
'   - Hides columns Q:XFD in the export workbook
'   - Sets print area to A:P only
'
' Exported Worksheet Name:
'   START-HERE!B7 value + "-300-POR ORDER LIST"
'==========================================================

Sub Export_SAP_POR_Order_List_A_To_P_ONLY()

    Dim wbSource As Workbook
    Dim wbExport As Workbook
    Dim wsSAP As Worksheet
    Dim wsStart As Worksheet
    Dim wsExport As Worksheet

    Dim projectValue As String
    Dim exportSheetName As String
    Dim exportFileName As String
    Dim savePath As Variant

    Dim lastRow As Long
    Dim srcRng As Range
    Dim outRng As Range

    Dim c As Long
    Dim oldCalc As XlCalculation

    On Error GoTo ExportError

    Set wbSource = ThisWorkbook
    Set wsSAP = wbSource.Worksheets("SAP POR ORDER LIST")
    Set wsStart = wbSource.Worksheets("START-HERE")

    projectValue = Trim(CStr(wsStart.Range("B7").Value))

    If projectValue = "" Then
        MsgBox "Cell B7 on worksheet 'START-HERE' is empty.", vbExclamation
        Exit Sub
    End If

    exportSheetName = CleanExcelSheetName(projectValue & "-300-POR ORDER LIST")
    exportFileName = CleanExcelFileName(exportSheetName) & ".xlsx"

    lastRow = GetLastRow_A_To_P(wsSAP)

    If lastRow = 0 Then
        MsgBox "No data found in columns A:P on 'SAP POR ORDER LIST'.", vbExclamation
        Exit Sub
    End If

    oldCalc = Application.Calculation

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Set wbExport = Workbooks.Add(xlWBATWorksheet)
    Set wsExport = wbExport.Worksheets(1)

    wsExport.Name = exportSheetName

    Set srcRng = wsSAP.Range("A1:P" & lastRow)
    Set outRng = wsExport.Range("A1:P" & lastRow)

    'Copy values only from A:P.
    outRng.Value = srcRng.Value

    'Copy formatting only from A:P.
    srcRng.Copy
    outRng.PasteSpecial Paste:=xlPasteFormats
    Application.CutCopyMode = False

    'Copy column widths only for A:P.
    For c = 1 To 16
        wsExport.Columns(c).ColumnWidth = wsSAP.Columns(c).ColumnWidth
    Next c

    'Remove anything past column P.
    wsExport.Range("Q:XFD").Clear

    'Hide all columns after P so the export only shows A:P.
    wsExport.Columns("Q:XFD").Hidden = True

    'Set print area to A:P only.
    wsExport.PageSetup.PrintArea = "$A$1:$P$" & lastRow

    Application.DisplayAlerts = True

    savePath = Application.GetSaveAsFilename( _
        InitialFileName:=exportFileName, _
        FileFilter:="Excel Workbook (*.xlsx), *.xlsx", _
        Title:="Save SAP POR Export Workbook")

    If savePath = False Then
        wbExport.Close SaveChanges:=False
        GoTo CleanExit
    End If

    wbExport.SaveAs fileName:=CStr(savePath), FileFormat:=xlOpenXMLWorkbook
    wbExport.Close SaveChanges:=False

    MsgBox "SAP POR Order List exported successfully." & vbCrLf & _
           "Only columns A:P were exported.", vbInformation

CleanExit:

    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.Calculation = oldCalc
    Application.CutCopyMode = False

    Exit Sub

ExportError:

    On Error Resume Next

    If Not wbExport Is Nothing Then
        wbExport.Close SaveChanges:=False
    End If

    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.Calculation = oldCalc
    Application.CutCopyMode = False

    MsgBox "Export failed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.Description, vbCritical

End Sub

Private Function GetLastRow_A_To_P(ByVal ws As Worksheet) As Long

    Dim lastCell As Range

    Set lastCell = ws.Range("A:P").Find( _
        What:="*", _
        LookIn:=xlFormulas, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious)

    If lastCell Is Nothing Then
        GetLastRow_A_To_P = 0
    Else
        GetLastRow_A_To_P = lastCell.Row
    End If

End Function

Private Function CleanExcelSheetName(ByVal sheetName As String) As String

    Dim invalidChars As Variant
    Dim i As Long

    invalidChars = Array("\", "/", "?", "*", "[", "]", ":")

    sheetName = Trim(sheetName)

    For i = LBound(invalidChars) To UBound(invalidChars)
        sheetName = Replace(sheetName, invalidChars(i), "-")
    Next i

    If Len(sheetName) > 31 Then
        sheetName = Left(sheetName, 31)
    End If

    CleanExcelSheetName = sheetName

End Function

Private Function CleanExcelFileName(ByVal fileName As String) As String

    Dim invalidChars As Variant
    Dim i As Long

    invalidChars = Array("\", "/", ":", "*", "?", """", "<", ">", "|")

    fileName = Trim(fileName)

    For i = LBound(invalidChars) To UBound(invalidChars)
        fileName = Replace(fileName, invalidChars(i), "-")
    Next i

    CleanExcelFileName = fileName

End Function

