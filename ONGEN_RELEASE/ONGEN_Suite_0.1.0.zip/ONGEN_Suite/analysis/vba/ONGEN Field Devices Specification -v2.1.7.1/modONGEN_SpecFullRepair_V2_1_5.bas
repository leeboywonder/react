Attribute VB_Name = "modONGEN_SpecFullRepair_V2_1_5"
Option Explicit

'===============================================================================
' ONGEN FIELD DEVICES SPECIFICATION - FULL REPAIR / PERFORMANCE MODULE
' Release: 2.1.5
' Created by: Lee Pierre
' Title: Principal Electrical Engineer
'
' IMPORTANT
' ---------
' Run this against the LAST KNOWN GOOD / OPENING workbook (for example V2.1.2).
' Do NOT run it against the corrupt V2.1.4 / V2.1.4.1 packages.
'
' What this module repairs using the Excel object model only:
'   1. Removes all worksheet/shape hyperlinks and HYPERLINK() formulas.
'   2. Removes the hard 5,000-row dependency from pricing / SAP lookups.
'   3. Replaces full-column XLOOKUP formulas in Pricing-Data with bounded dynamic
'      named ranges that are resized to the actual data on every workflow run.
'   4. Compacts SAP POR Order List and EE System Designed BOM so formulas exist
'      only to the current data size + automatic headroom.
'   5. Automatically grows formula capacity in chunks as the actual project grows.
'      There is NO fixed 5,000-row limit.
'   6. Repairs EM Designed function VARIANT validation so it grows with VARIANT LIST.
'   7. Rebinds the normal Specification buttons to optimized wrappers. The wrappers
'      call the original macros, then resize formulas/names and recalculate outputs.
'   8. Preserves native business macros. This module does NOT replace their logic.
'   9. Uses safe application-state wrappers so ScreenUpdating / Events / Calculation
'      are always restored after long macros.
'  10. Creates a timestamped backup before the one-time full repair.
'
' Normal one-time entry point:
'       ONGEN_SPEC_FULL_REPAIR
'
' Safe maintenance / catch-up entry point:
'       ONGEN_SPEC_REFRESH_DYNAMIC
'===============================================================================

Private Const SH_START As String = "START-HERE"
Private Const SH_VENDOR As String = "NEW VENDOR INFO"
Private Const SH_PRICE As String = "Pricing-Data"
Private Const SH_VARIANT As String = "VARIANT LIST"
Private Const SH_DESIGNED As String = "EM Designed function"
Private Const SH_EEBOM As String = "EE System Designed BOM"
Private Const SH_SAP As String = "SAP POR Order List"

Private Const MIN_HEADROOM_ROW As Long = 250
Private Const GROWTH_CHUNK As Long = 250
Private Const EXTRA_HEADROOM As Long = 150

Private mFastDepth As Long
Private mPrevScreenUpdating As Boolean
Private mPrevEnableEvents As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As XlCalculation
Private mPrevStatusBar As Variant

'===============================================================================
' PUBLIC - ONE TIME FULL REPAIR
'===============================================================================
Public Sub ONGEN_SPEC_FULL_REPAIR()
    Dim backupPath As String
    Dim repairSummary As String
    Dim started As Double
    Dim errText As String

    On Error GoTo RepairFail
    started = Timer

    If Not ONGEN_SPEC_RequiredSheetsExist() Then Exit Sub

    backupPath = ONGEN_SPEC_CreateBackup()

    ONGEN_SPEC_FastBegin "ONGEN Specification - repairing workbook..."

    ONGEN_SPEC_RemoveAllHyperlinks
    ONGEN_SPEC_RefreshDynamicInfrastructure True
    ONGEN_SPEC_RebindOptimizedButtons

    ' Rebuild Excel's dependency graph after millions of stale prefilled formulas
    ' have been removed. This is slow once, but prevents the old calc-chain blind spot.
    Application.StatusBar = "ONGEN Specification - rebuilding calculation dependencies..."
    Application.CalculateFullRebuild

    ' Touch UsedRange after the clear operations. Excel normally commits the smaller
    ' dimensions when the workbook is saved/closed.
    ONGEN_SPEC_TouchUsedRange ThisWorkbook.Worksheets(SH_VENDOR)
    ONGEN_SPEC_TouchUsedRange ThisWorkbook.Worksheets(SH_PRICE)
    ONGEN_SPEC_TouchUsedRange ThisWorkbook.Worksheets(SH_EEBOM)
    ONGEN_SPEC_TouchUsedRange ThisWorkbook.Worksheets(SH_SAP)

    ONGEN_SPEC_FastEnd

    On Error Resume Next
    ThisWorkbook.Save
    On Error GoTo RepairFail

    repairSummary = "ONGEN Specification full repair completed." & vbCrLf & vbCrLf & _
                    "- Hyperlinks removed" & vbCrLf & _
                    "- Fixed 5,000-row lookup limits removed" & vbCrLf & _
                    "- Report formulas compacted and set to auto-grow" & vbCrLf & _
                    "- Pricing/Vendor formulas optimized" & vbCrLf & _
                    "- Variant validation made dynamic" & vbCrLf & _
                    "- Specification buttons rebound to optimized wrappers" & vbCrLf & _
                    "- Calculation dependencies rebuilt" & vbCrLf & vbCrLf

    If Len(backupPath) > 0 Then
        repairSummary = repairSummary & "Backup created:" & vbCrLf & backupPath & vbCrLf & vbCrLf
    End If

    repairSummary = repairSummary & "Elapsed: " & Format$(ONGEN_SPEC_ElapsedSeconds(started), "0.0") & " sec"

    MsgBox repairSummary, vbInformation, "ONGEN Specification Repair"
    Exit Sub

RepairFail:
    errText = Err.Description
    ONGEN_SPEC_FastEnd
    MsgBox "ONGEN Specification repair stopped." & vbCrLf & vbCrLf & errText, _
           vbCritical, "ONGEN Specification Repair"
End Sub

'===============================================================================
' PUBLIC - SAFE REFRESH / AUTO-GROW
' Run this any time data was pasted/changed outside the normal buttons.
'===============================================================================
Public Sub ONGEN_SPEC_REFRESH_DYNAMIC()
    Dim errText As String

    On Error GoTo RefreshFail

    If Not ONGEN_SPEC_RequiredSheetsExist() Then Exit Sub

    ONGEN_SPEC_FastBegin "ONGEN Specification - refreshing dynamic ranges..."
    ONGEN_SPEC_RefreshDynamicInfrastructure False
    ONGEN_SPEC_CalculateOutputs
    ONGEN_SPEC_FastEnd
    Exit Sub

RefreshFail:
    errText = Err.Description
    ONGEN_SPEC_FastEnd
    MsgBox "Dynamic refresh did not complete." & vbCrLf & errText, _
           vbExclamation, "ONGEN Specification"
End Sub

'===============================================================================
' PUBLIC - PERFORMANCE / CAPACITY AUDIT
'===============================================================================
Public Sub ONGEN_SPEC_PERFORMANCE_AUDIT()
    Dim wsPrice As Worksheet
    Dim wsVendor As Worksheet
    Dim wsEE As Worksheet
    Dim wsSAP As Worksheet
    Dim priceLast As Long
    Dim vendorLast As Long
    Dim eeLast As Long
    Dim sapLast As Long
    Dim hyperlinkCount As Long
    Dim msg As String

    On Error GoTo AuditFail

    Set wsPrice = ThisWorkbook.Worksheets(SH_PRICE)
    Set wsVendor = ThisWorkbook.Worksheets(SH_VENDOR)
    Set wsEE = ThisWorkbook.Worksheets(SH_EEBOM)
    Set wsSAP = ThisWorkbook.Worksheets(SH_SAP)

    priceLast = ONGEN_SPEC_LastConstantRowAcross(wsPrice, Array("A", "B", "C", "D", "E", "F", "G"))
    vendorLast = ONGEN_SPEC_LastConstantRowAcross(wsVendor, Array("A", "B", "C", "D", "E", "F", "G"))
    eeLast = ONGEN_SPEC_EEBOMDataLastRow()
    sapLast = ONGEN_SPEC_LastConstantRowAcross(wsSAP, Array("D"))
    hyperlinkCount = ONGEN_SPEC_CountHyperlinks()

    msg = "ONGEN Specification Performance Audit" & vbCrLf & String$(44, "-") & vbCrLf & _
          "Pricing data last row: " & Format$(priceLast, "#,##0") & vbCrLf & _
          "Vendor data last row: " & Format$(vendorLast, "#,##0") & vbCrLf & _
          "EE BOM actual data last row: " & Format$(eeLast, "#,##0") & vbCrLf & _
          "SAP manual/data last row: " & Format$(sapLast, "#,##0") & vbCrLf & _
          "Active hyperlinks: " & Format$(hyperlinkCount, "#,##0") & vbCrLf & vbCrLf & _
          "Capacity model: AUTO-GROW (no fixed 5,000-row limit)." & vbCrLf & _
          "Formula headroom expands in " & GROWTH_CHUNK & "-row chunks."

    MsgBox msg, IIf(hyperlinkCount > 0, vbExclamation, vbInformation), _
           "ONGEN Specification"
    Exit Sub

AuditFail:
    MsgBox "Performance audit could not complete." & vbCrLf & Err.Description, _
           vbExclamation, "ONGEN Specification"
End Sub

'===============================================================================
' PUBLIC - RESTORE EXCEL STATE IF A NATIVE MACRO TERMINATED EARLY
'===============================================================================
Public Sub ONGEN_SPEC_RESET_EXCEL_STATE()
    On Error Resume Next
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    Application.DisplayAlerts = True
    Application.StatusBar = False
    If Application.Calculation = xlCalculationManual Then
        ' Do not force a user's global calculation preference. Recalculate only
        ' the three Specification output sheets instead.
        ONGEN_SPEC_CalculateOutputs
    End If
    On Error GoTo 0

    MsgBox "Excel display/events/status have been restored.", _
           vbInformation, "ONGEN Specification"
End Sub

'===============================================================================
' OPTIMIZED BUTTON WRAPPERS
' These call the existing native macros, then auto-grow / recalc safely.
'===============================================================================
Public Sub ONGEN_SPEC_RunPartVariant_Optimized()
    ONGEN_SPEC_RunNativeOptimized "Run Part Variant", Array("MapVariantData")
End Sub

Public Sub ONGEN_SPEC_ReArrangeEEData_Optimized()
    ONGEN_SPEC_RunNativeOptimized "Re-Arrange EE data", _
                                  Array("RearrangeDesignedExport_Fast")
End Sub

Public Sub ONGEN_SPEC_SplitManufacturer_Optimized()
    ONGEN_SPEC_RunNativeOptimized "Split System BOM per Manufacturer", _
                                  Array("SplitManufacturerData")
End Sub

Public Sub ONGEN_SPEC_CreateSAPPOR_Optimized()
    ONGEN_SPEC_RunNativeOptimized "CREATE SAP POR", _
                                  Array("CreateVendorSheets_FromBOM_Full")
End Sub

Public Sub ONGEN_SPEC_ExportSAPPOR_Optimized()
    ONGEN_SPEC_RunNativeOptimized "EXPORT SAP POR ORDER LIST", _
                                  Array("Export_SAP_POR_Order_List_A_To_P_ONLY")
End Sub

Public Sub ONGEN_SPEC_SyncMaster_Optimized()
    ONGEN_SPEC_RunNativeOptimized "SYNC MASTER LIBRARY", Array("ONGEN_SyncMasterLibrary")
End Sub

'===============================================================================
' CORE REFRESH ENGINE
'===============================================================================
Private Sub ONGEN_SPEC_RefreshDynamicInfrastructure(ByVal compactTail As Boolean)
    Dim eeActualLast As Long
    Dim eeTarget As Long
    Dim sapActualLast As Long
    Dim sapTarget As Long
    Dim vendorLast As Long
    Dim vendorTarget As Long

    Application.StatusBar = "ONGEN Specification - refreshing dynamic names..."
    ONGEN_SPEC_RefreshDynamicNames

    Application.StatusBar = "ONGEN Specification - repairing Pricing-Data lookup..."
    ONGEN_SPEC_RepairPricingFormula

    eeActualLast = ONGEN_SPEC_EEBOMDataLastRow()
    eeTarget = ONGEN_SPEC_NextCapacity(eeActualLast)

    Application.StatusBar = "ONGEN Specification - sizing EE System Designed BOM..."
    ONGEN_SPEC_RepairEEBOM eeTarget, compactTail

    ' Re-read names after EE BOM key/formula rows have been repaired.
    ONGEN_SPEC_RefreshDynamicNames

    sapActualLast = ONGEN_SPEC_LastConstantRowAcross(ThisWorkbook.Worksheets(SH_SAP), Array("D"))
    If eeActualLast > sapActualLast Then sapActualLast = eeActualLast
    sapTarget = ONGEN_SPEC_NextCapacity(sapActualLast)

    Application.StatusBar = "ONGEN Specification - sizing SAP POR Order List..."
    ONGEN_SPEC_RepairSAPPOR sapTarget, compactTail

    vendorLast = ONGEN_SPEC_LastConstantRowAcross(ThisWorkbook.Worksheets(SH_VENDOR), _
                                                  Array("A", "B", "C", "D", "E", "F", "G"))
    vendorTarget = ONGEN_SPEC_NextCapacity(vendorLast)
    If compactTail Then ONGEN_SPEC_CompactTail ThisWorkbook.Worksheets(SH_VENDOR), _
                                                 vendorTarget, "A", "G"

    Application.StatusBar = "ONGEN Specification - repairing dynamic VARIANT validation..."
    ONGEN_SPEC_RepairVariantValidation

    ONGEN_SPEC_RefreshDynamicNames
End Sub

'===============================================================================
' PRICING / VENDOR REPAIR
'===============================================================================
Private Sub ONGEN_SPEC_RepairPricingFormula()
    Dim ws As Worksheet
    Dim lastPrice As Long
    Dim oldLast As Long

    Set ws = ThisWorkbook.Worksheets(SH_PRICE)
    lastPrice = ONGEN_SPEC_LastConstantRowAcross(ws, Array("A", "B", "C", "D", "E", "F", "G"))
    If lastPrice < 2 Then lastPrice = 2

    oldLast = ONGEN_SPEC_LastUsedRow(ws)
    If oldLast < 2 Then oldLast = 2

    ' Remove the original XLOOKUP(E:E, B:B, A:A...) formulas. They repeated a
    ' full-column lookup thousands of times.
    ws.Range("H2:H" & oldLast).ClearContents

    ws.Range("H2:H" & lastPrice).FormulaR1C1 = _
        "=IF(RC[-3]="""","""",IFERROR(INDEX(ONGEN_VENDOR_CODES,MATCH(RC[-3],ONGEN_VENDOR_NAMES,0)),""""))"
End Sub

'===============================================================================
' EE SYSTEM DESIGNED BOM REPAIR
'===============================================================================
Private Sub ONGEN_SPEC_RepairEEBOM(ByVal targetRow As Long, ByVal compactTail As Boolean)
    Dim ws As Worksheet
    Dim lastUsed As Long

    Set ws = ThisWorkbook.Worksheets(SH_EEBOM)
    If targetRow < 2 Then targetRow = 2
    If targetRow > ws.rows.count Then targetRow = ws.rows.count

    ' Intended helper formulas only. Generated purchasing/material fields remain
    ' native-macro outputs; we do not overwrite them here.
    ws.Range("I2:I" & targetRow).FormulaR1C1 = _
        "=IF(RC[-8]="""","""",'START-HERE'!R15C3)"

    ws.Range("K2:K" & targetRow).FormulaR1C1 = _
        "=IF(RC[-10]="""","""",'START-HERE'!R16C3)"

    ' Key + Item # are required by SAP POR formulas. They are regenerated from
    ' actual BOM row content and therefore grow with the project.
    ws.Range("R2:R" & targetRow).FormulaR1C1 = "=ROW()-1"
    ws.Range("Q2:Q" & targetRow).FormulaR1C1 = _
        "=IF(RC[-16]="""","""",RC[1]&""-""&RC[-12]&RC[-16])"

    If compactTail Then
        lastUsed = ONGEN_SPEC_LastUsedRow(ws)
        If lastUsed > targetRow Then
            ONGEN_SPEC_CompactTail ws, targetRow, "A", "R"
        End If
    End If
End Sub

'===============================================================================
' SAP POR ORDER LIST REPAIR
' No fixed row ceiling. The target row is calculated from actual project rows.
'===============================================================================
Private Sub ONGEN_SPEC_RepairSAPPOR(ByVal targetRow As Long, ByVal compactTail As Boolean)
    Dim ws As Worksheet
    Dim lastUsed As Long

    Set ws = ThisWorkbook.Worksheets(SH_SAP)
    If targetRow < 2 Then targetRow = 2
    If targetRow > ws.rows.count Then targetRow = ws.rows.count

    ' Core sequential / constant fields.
    ws.Range("A2:A" & targetRow).FormulaR1C1 = "=ROW()-1"
    ws.Range("R2:R" & targetRow).FormulaR1C1 = "=ROW()-1"
    ONGEN_SPEC_FillBlankConstant ws.Range("B2:B" & targetRow), "P"
    ONGEN_SPEC_FillBlankConstant ws.Range("G2:G" & targetRow), "EA"

    ' C - item/part field from EE BOM, excluding already-purchased items.
    ws.Range("C2:C" & targetRow).FormulaR1C1 = _
        "=IF('EE System Designed BOM'!RC[2]="""","""",IF('EE System Designed BOM'!RC[5]=""Y"","""",'EE System Designed BOM'!RC[2]))"

    ' E - short text. Pricing description uses the dynamically resized names.
    ws.Range("E2:E" & targetRow).FormulaR1C1 = _
        "=IF(RC[-1]="""","""",""C.id-""&RC[13]&""-  ""&IFERROR(INDEX(ONGEN_PRICING_DESCRIPTIONS,MATCH(RC[-1],ONGEN_PRICING_PARTS,0)),""""))"

    ' F - quantity by EE BOM key.
    ws.Range("F2:F" & targetRow).FormulaR1C1 = _
        "=IFERROR(INDEX(ONGEN_EEBOM_QTY,MATCH(RC[14],ONGEN_EEBOM_KEYS,0)),0)"

    ' H / I - delivery date and currency.
    ws.Range("H2:H" & targetRow).FormulaR1C1 = _
        "=IF(RC[-4]="""","""",'START-HERE'!R16C3)"

    ws.Range("I2:I" & targetRow).FormulaR1C1 = _
        "=VLOOKUP('START-HERE'!R17C3,DATA!R3C10:R6C11,2,FALSE)"

    ' J - valuation price * quantity, excluding By EE Installer.
    ws.Range("J2:J" & targetRow).FormulaR1C1 = _
        "=IFERROR(IF(INDEX(ONGEN_EEBOM_PURCHASE_BY,MATCH(RC[-6],ONGEN_EEBOM_PARTS,0))=""By EE Installer"","""",IF(RC[-6]="""","""",INDEX(ONGEN_PRICING_COSTS,MATCH(RC[-6],ONGEN_PRICING_PARTS,0))*RC[-4])),"""")"

    ' K - materials group.
    ws.Range("K2:K" & targetRow).FormulaR1C1 = _
        "=IF(RC[-7]="""","""",IFERROR(INDEX(ONGEN_PRICING_MATGROUP,MATCH(RC[-7],ONGEN_PRICING_PARTS,0)),""""))"

    ' L / M / O - plant, purchasing group and purchasing organization.
    ws.Range("L2:L" & targetRow).FormulaR1C1 = _
        "=IF(RC[-2]="""","""",IF('START-HERE'!R17C3=""USA"",1110,""""))"

    ws.Range("M2:M" & targetRow).FormulaR1C1 = _
        "=VLOOKUP('START-HERE'!R20C4,DATA!R9C10:R12C11,2,FALSE)"

    ws.Range("O2:O" & targetRow).FormulaR1C1 = _
        "=IF(RC[-3]=1110,1100,"""")"

    ' N / P / S - vendor / Conv.ID-info / PLC Area by dynamic EE BOM key.
    ws.Range("N2:N" & targetRow).FormulaR1C1 = _
        "=IFERROR(INDEX(ONGEN_EEBOM_SAP_VENDOR,MATCH(RC[6],ONGEN_EEBOM_KEYS,0)),0)"

    ws.Range("P2:P" & targetRow).FormulaR1C1 = _
        "=IFERROR(INDEX(ONGEN_EEBOM_CONVID,MATCH(RC[4],ONGEN_EEBOM_KEYS,0)),0)"

    ws.Range("S2:S" & targetRow).FormulaR1C1 = _
        "=IFERROR(INDEX(ONGEN_EEBOM_PLC,MATCH(RC[1],ONGEN_EEBOM_KEYS,0)),0)"

    ' T - key directly from EE System Designed BOM.
    ws.Range("T2:T" & targetRow).FormulaR1C1 = _
        "='EE System Designed BOM'!RC[-3]"

    If compactTail Then
        lastUsed = ONGEN_SPEC_LastUsedRow(ws)
        If lastUsed > targetRow Then
            ONGEN_SPEC_CompactTail ws, targetRow, "A", "T"
        End If
    End If
End Sub

'===============================================================================
' VARIANT VALIDATION - GROWS WITH CURRENT PROJECT, NO 1,680/5,000 LIMIT
'===============================================================================
Private Sub ONGEN_SPEC_RepairVariantValidation()
    Dim ws As Worksheet
    Dim headerCell As Range
    Dim lastData As Long
    Dim targetRow As Long
    Dim validationRange As Range

    Set ws = ThisWorkbook.Worksheets(SH_DESIGNED)
    Set headerCell = ONGEN_SPEC_FindHeader(ws, "VARIANT", 1, 5)
    If headerCell Is Nothing Then Exit Sub

    lastData = ONGEN_SPEC_LastUsedRow(ws)
    If lastData < 2 Then lastData = 2
    targetRow = ONGEN_SPEC_NextCapacity(lastData)

    Set validationRange = ws.Range(ws.Cells(2, headerCell.Column), _
                                   ws.Cells(targetRow, headerCell.Column))

    On Error Resume Next
    validationRange.Validation.Delete
    On Error GoTo 0

    validationRange.Validation.Add Type:=xlValidateList, _
                                   AlertStyle:=xlValidAlertStop, _
                                   Operator:=xlBetween, _
                                   Formula1:="=ONGEN_VARIANT_CODES"
    validationRange.Validation.IgnoreBlank = True
    validationRange.Validation.InCellDropdown = True
    validationRange.Validation.ShowError = True
End Sub

'===============================================================================
' DYNAMIC NAMES - RESIZED TO ACTUAL DATA, NO HARD MAXIMUM
'===============================================================================
Private Sub ONGEN_SPEC_RefreshDynamicNames()
    Dim ws As Worksheet
    Dim lastRow As Long

    Set ws = ThisWorkbook.Worksheets(SH_VENDOR)
    lastRow = ONGEN_SPEC_LastConstantRowAcross(ws, Array("A", "B"))
    If lastRow < 2 Then lastRow = 2
    ONGEN_SPEC_SetNameRange "ONGEN_VENDOR_CODES", ws.Range("A2:A" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_VENDOR_NAMES", ws.Range("B2:B" & lastRow)

    Set ws = ThisWorkbook.Worksheets(SH_PRICE)
    lastRow = ONGEN_SPEC_LastConstantRowAcross(ws, Array("A", "B", "C", "D", "E", "F", "G"))
    If lastRow < 2 Then lastRow = 2
    ONGEN_SPEC_SetNameRange "ONGEN_PRICING_PARTS", ws.Range("A2:A" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_PRICING_DESCRIPTIONS", ws.Range("C2:C" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_PRICING_COSTS", ws.Range("D2:D" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_PRICING_MATGROUP", ws.Range("F2:F" & lastRow)

    Set ws = ThisWorkbook.Worksheets(SH_EEBOM)
    lastRow = ONGEN_SPEC_EEBOMDataLastRow()
    If lastRow < 2 Then lastRow = 2
    ONGEN_SPEC_SetNameRange "ONGEN_EEBOM_CONVID", ws.Range("A2:A" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_EEBOM_QTY", ws.Range("C2:C" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_EEBOM_PARTS", ws.Range("E2:E" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_EEBOM_PLC", ws.Range("G2:G" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_EEBOM_PURCHASE_BY", ws.Range("I2:I" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_EEBOM_SAP_VENDOR", ws.Range("O2:O" & lastRow)
    ONGEN_SPEC_SetNameRange "ONGEN_EEBOM_KEYS", ws.Range("Q2:Q" & lastRow)

    Set ws = ThisWorkbook.Worksheets(SH_VARIANT)
    lastRow = ONGEN_SPEC_LastConstantRowAcross(ws, Array("A"))
    If lastRow < 2 Then lastRow = 2
    ONGEN_SPEC_SetNameRange "ONGEN_VARIANT_CODES", ws.Range("A2:A" & lastRow)
End Sub

Private Sub ONGEN_SPEC_SetNameRange(ByVal definedName As String, ByVal targetRange As Range)
    On Error Resume Next
    ThisWorkbook.names(definedName).Delete
    On Error GoTo 0

    ThisWorkbook.names.Add Name:=definedName, _
                           RefersTo:="=" & targetRange.Address(External:=True), _
                           Visible:=False
End Sub

'===============================================================================
' HYPERLINK CLEANUP
'===============================================================================
Private Sub ONGEN_SPEC_RemoveAllHyperlinks()
    Dim ws As Worksheet
    Dim hit As Range
    Dim displayValue As Variant

    For Each ws In ThisWorkbook.Worksheets
        On Error Resume Next
        ws.Hyperlinks.Delete
        On Error GoTo 0

        ' Convert HYPERLINK() formulas to their displayed value so no live link remains.
        Do
            Set hit = Nothing
            On Error Resume Next
            Set hit = ws.Cells.Find(What:="HYPERLINK(", _
                                    After:=ws.Cells(1, 1), _
                                    LookIn:=xlFormulas, _
                                    LookAt:=xlPart, _
                                    SearchOrder:=xlByRows, _
                                    SearchDirection:=xlNext, _
                                    MatchCase:=False)
            On Error GoTo 0

            If hit Is Nothing Then Exit Do
            displayValue = hit.Value2
            hit.Value2 = displayValue
        Loop
    Next ws

    On Error Resume Next
    ThisWorkbook.BuiltinDocumentProperties("Hyperlink Base").Value = vbNullString
    On Error GoTo 0
End Sub

Private Function ONGEN_SPEC_CountHyperlinks() As Long
    Dim ws As Worksheet
    Dim total As Long

    For Each ws In ThisWorkbook.Worksheets
        total = total + ws.Hyperlinks.count
    Next ws

    ONGEN_SPEC_CountHyperlinks = total
End Function

'===============================================================================
' BUTTON REBINDING
'===============================================================================
Private Sub ONGEN_SPEC_RebindOptimizedButtons()
    Dim ws As Worksheet
    Dim shp As Shape
    Dim actionText As String
    Dim captionText As String
    Dim newAction As String

    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            actionText = vbNullString
            captionText = vbNullString
            newAction = vbNullString

            On Error Resume Next
            actionText = CStr(shp.OnAction)
            captionText = CStr(shp.TextFrame2.TextRange.Text)
            If Len(captionText) = 0 Then captionText = CStr(shp.TextFrame.Characters.Text)
            On Error GoTo 0

            newAction = ONGEN_SPEC_WrapperForAction(actionText, captionText)
            If Len(newAction) > 0 Then
                shp.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & newAction
            End If
        Next shp
    Next ws
End Sub

Private Function ONGEN_SPEC_WrapperForAction(ByVal actionText As String, _
                                              ByVal captionText As String) As String
    Dim a As String
    Dim c As String

    a = UCase$(actionText)
    c = UCase$(Replace(Replace(Replace(captionText, vbCr, " "), vbLf, " "), "  ", " "))

    If InStr(a, "MAPVARIANTDATA") > 0 Or InStr(c, "RUN PART VARIANT") > 0 Then
        ONGEN_SPEC_WrapperForAction = "ONGEN_SPEC_RunPartVariant_Optimized"
    ElseIf InStr(a, "REARRANGEDESIGNEDEXPORT_FAST") > 0 Or _
           InStr(a, "REARRANGE_DATA") > 0 Or _
           InStr(c, "RE-ARRANGE EE DATA") > 0 Then
        ONGEN_SPEC_WrapperForAction = "ONGEN_SPEC_ReArrangeEEData_Optimized"
    ElseIf InStr(a, "SPLITMANUFACTURERDATA") > 0 Or _
           InStr(c, "SPLIT SYSTEM BOM") > 0 Then
        ONGEN_SPEC_WrapperForAction = "ONGEN_SPEC_SplitManufacturer_Optimized"
    ElseIf InStr(a, "CREATEVENDORSHEETS_FROMBOM_FULL") > 0 Or _
           InStr(c, "CREATE SAP POR") > 0 Then
        ONGEN_SPEC_WrapperForAction = "ONGEN_SPEC_CreateSAPPOR_Optimized"
    ElseIf InStr(a, "EXPORT_SAP_POR_ORDER_LIST_A_TO_P_ONLY") > 0 Or _
           InStr(c, "EXPORT SAP POR ORDER LIST") > 0 Then
        ONGEN_SPEC_WrapperForAction = "ONGEN_SPEC_ExportSAPPOR_Optimized"
    ElseIf InStr(a, "ONGEN_SYNCMASTERLIBRARY") > 0 Or _
           InStr(c, "SYNC MASTER LIBRARY") > 0 Then
        ONGEN_SPEC_WrapperForAction = "ONGEN_SPEC_SyncMaster_Optimized"
    End If
End Function

'===============================================================================
' NATIVE MACRO WRAPPER ENGINE
'===============================================================================
Private Sub ONGEN_SPEC_RunNativeOptimized(ByVal operationName As String, _
                                           ByVal candidateMacros As Variant)
    Dim started As Double
    Dim errText As String

    On Error GoTo RunFail
    started = Timer

    ONGEN_SPEC_FastBegin "ONGEN Specification - " & operationName & "..."

    ' Refresh dynamic names/formula headroom before the native routine as well as
    ' after it. This protects routines that expect helper formulas to exist.
    ONGEN_SPEC_RefreshDynamicInfrastructure False

    If Not ONGEN_SPEC_RunFirstAvailable(candidateMacros, errText) Then
        Err.Raise vbObjectError + 2315, "ONGEN_SPEC_RunNativeOptimized", errText
    End If

    ONGEN_SPEC_RefreshDynamicInfrastructure True
    ONGEN_SPEC_CalculateOutputs
    ONGEN_SPEC_FastEnd
    Exit Sub

RunFail:
    errText = Err.Description
    ONGEN_SPEC_FastEnd
    MsgBox operationName & " did not complete." & vbCrLf & vbCrLf & errText, _
           vbExclamation, "ONGEN Specification"
End Sub

Private Function ONGEN_SPEC_RunFirstAvailable(ByVal candidates As Variant, _
                                               ByRef failureText As String) As Boolean
    Dim item As Variant
    Dim qualifiedMacro As String
    Dim lastError As String

    For Each item In candidates
        qualifiedMacro = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & CStr(item)

        Err.Clear
        On Error Resume Next
        Application.Run qualifiedMacro
        If Err.Number = 0 Then
            On Error GoTo 0
            ONGEN_SPEC_RunFirstAvailable = True
            Exit Function
        End If
        lastError = Err.Description
        On Error GoTo 0
    Next item

    failureText = "Could not run the native workbook macro." & vbCrLf & _
                  "Candidates: " & Join(candidates, ", ") & vbCrLf & _
                  "Last error: " & lastError
End Function

'===============================================================================
' TARGETED CALCULATION
'===============================================================================
Private Sub ONGEN_SPEC_CalculateOutputs()
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_PRICE).Calculate
    ThisWorkbook.Worksheets(SH_EEBOM).Calculate
    ThisWorkbook.Worksheets(SH_SAP).Calculate
    ThisWorkbook.Worksheets(SH_START).Calculate
    On Error GoTo 0
End Sub

'===============================================================================
' COMPACTION / CAPACITY HELPERS
'===============================================================================
Private Function ONGEN_SPEC_NextCapacity(ByVal actualLastRow As Long) As Long
    Dim requested As Long
    Dim chunked As Long

    If actualLastRow < 2 Then actualLastRow = 2

    requested = actualLastRow + EXTRA_HEADROOM
    If requested < MIN_HEADROOM_ROW Then requested = MIN_HEADROOM_ROW

    chunked = ((requested + GROWTH_CHUNK - 1) \ GROWTH_CHUNK) * GROWTH_CHUNK

    If chunked > ThisWorkbook.Worksheets(SH_SAP).rows.count Then
        chunked = ThisWorkbook.Worksheets(SH_SAP).rows.count
    End If

    ONGEN_SPEC_NextCapacity = chunked
End Function

Private Sub ONGEN_SPEC_CompactTail(ByVal ws As Worksheet, _
                                   ByVal keepThroughRow As Long, _
                                   ByVal firstColumn As String, _
                                   ByVal lastColumn As String)
    Dim lastUsed As Long

    lastUsed = ONGEN_SPEC_LastUsedRow(ws)
    If lastUsed <= keepThroughRow Then Exit Sub

    ws.Range(firstColumn & CStr(keepThroughRow + 1) & ":" & _
             lastColumn & CStr(lastUsed)).Clear
End Sub

Private Function ONGEN_SPEC_EEBOMDataLastRow() As Long
    ONGEN_SPEC_EEBOMDataLastRow = _
        ONGEN_SPEC_LastConstantRowAcross(ThisWorkbook.Worksheets(SH_EEBOM), _
                                         Array("A", "B", "C", "D", "E", "F", "G", "H"))
End Function

Private Function ONGEN_SPEC_LastConstantRowAcross(ByVal ws As Worksheet, _
                                                  ByVal columnLetters As Variant) As Long
    Dim item As Variant
    Dim searchRange As Range
    Dim constantsRange As Range
    Dim area As Range
    Dim candidate As Long
    Dim result As Long

    result = 1

    For Each item In columnLetters
        Set searchRange = Nothing
        Set constantsRange = Nothing

        On Error Resume Next
        Set searchRange = Intersect(ws.UsedRange, ws.Columns(CStr(item)))
        If Not searchRange Is Nothing Then
            Set constantsRange = searchRange.SpecialCells(xlCellTypeConstants)
        End If
        On Error GoTo 0

        If Not constantsRange Is Nothing Then
            For Each area In constantsRange.Areas
                candidate = area.Cells(area.Cells.count).Row
                If candidate > result Then result = candidate
            Next area
        End If
    Next item

    ONGEN_SPEC_LastConstantRowAcross = result
End Function

Private Function ONGEN_SPEC_LastRowAcross(ByVal ws As Worksheet, _
                                          ByVal columnLetters As Variant) As Long
    Dim item As Variant
    Dim candidate As Long
    Dim result As Long

    result = 1
    For Each item In columnLetters
        candidate = ws.Cells(ws.rows.count, CStr(item)).End(xlUp).Row
        If candidate > result Then result = candidate
    Next item

    ONGEN_SPEC_LastRowAcross = result
End Function

Private Function ONGEN_SPEC_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim hit As Range

    On Error Resume Next
    Set hit = ws.Cells.Find(What:="*", _
                            After:=ws.Cells(1, 1), _
                            LookIn:=xlFormulas, _
                            LookAt:=xlPart, _
                            SearchOrder:=xlByRows, _
                            SearchDirection:=xlPrevious, _
                            MatchCase:=False)
    On Error GoTo 0

    If hit Is Nothing Then
        ONGEN_SPEC_LastUsedRow = 1
    Else
        ONGEN_SPEC_LastUsedRow = hit.Row
    End If
End Function

Private Sub ONGEN_SPEC_FillBlankConstant(ByVal targetRange As Range, ByVal fillValue As Variant)
    Dim blanks As Range

    On Error Resume Next
    Set blanks = targetRange.SpecialCells(xlCellTypeBlanks)
    On Error GoTo 0

    If Not blanks Is Nothing Then blanks.Value = fillValue
End Sub

Private Sub ONGEN_SPEC_TouchUsedRange(ByVal ws As Worksheet)
    Dim tmp As Range
    Set tmp = ws.UsedRange
    Set tmp = Nothing
End Sub

'===============================================================================
' HEADER / SHEET VALIDATION
'===============================================================================
Private Function ONGEN_SPEC_FindHeader(ByVal ws As Worksheet, _
                                       ByVal headerText As String, _
                                       ByVal firstHeaderRow As Long, _
                                       ByVal lastHeaderRow As Long) As Range
    Dim searchArea As Range
    Dim hit As Range

    Set searchArea = ws.Range(ws.Cells(firstHeaderRow, 1), _
                              ws.Cells(lastHeaderRow, ws.Columns.count))

    Set hit = searchArea.Find(What:=headerText, _
                              After:=searchArea.Cells(1, 1), _
                              LookIn:=xlValues, _
                              LookAt:=xlWhole, _
                              SearchOrder:=xlByRows, _
                              SearchDirection:=xlNext, _
                              MatchCase:=False)

    Set ONGEN_SPEC_FindHeader = hit
End Function

Private Function ONGEN_SPEC_RequiredSheetsExist() As Boolean
    Dim required As Variant
    Dim item As Variant
    Dim missing As String

    required = Array(SH_START, SH_VENDOR, SH_PRICE, SH_VARIANT, _
                     SH_DESIGNED, SH_EEBOM, SH_SAP)

    For Each item In required
        If Not ONGEN_SPEC_SheetExists(CStr(item)) Then
            If Len(missing) > 0 Then missing = missing & vbCrLf
            missing = missing & "- " & CStr(item)
        End If
    Next item

    If Len(missing) > 0 Then
        MsgBox "The repair cannot run because these worksheets are missing:" & _
               vbCrLf & vbCrLf & missing, vbCritical, "ONGEN Specification"
        Exit Function
    End If

    ONGEN_SPEC_RequiredSheetsExist = True
End Function

Private Function ONGEN_SPEC_SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0

    ONGEN_SPEC_SheetExists = Not ws Is Nothing
End Function

'===============================================================================
' BACKUP / APPLICATION STATE
'===============================================================================
Private Function ONGEN_SPEC_CreateBackup() As String
    Dim folderPath As String
    Dim baseName As String
    Dim ext As String
    Dim dotPos As Long
    Dim backupPath As String

    On Error GoTo BackupFail

    If Len(ThisWorkbook.path) = 0 Then Exit Function

    folderPath = ThisWorkbook.path
    dotPos = InStrRev(ThisWorkbook.Name, ".")

    If dotPos > 0 Then
        baseName = Left$(ThisWorkbook.Name, dotPos - 1)
        ext = Mid$(ThisWorkbook.Name, dotPos)
    Else
        baseName = ThisWorkbook.Name
        ext = ".xlsm"
    End If

    backupPath = folderPath & Application.PathSeparator & _
                 baseName & "_PRE_REPAIR_" & Format$(Now, "yyyymmdd_hhnnss") & ext

    ThisWorkbook.SaveCopyAs backupPath
    ONGEN_SPEC_CreateBackup = backupPath
    Exit Function

BackupFail:
    ONGEN_SPEC_CreateBackup = vbNullString
End Function

Private Sub ONGEN_SPEC_FastBegin(ByVal statusText As String)
    If mFastDepth = 0 Then
        With Application
            mPrevScreenUpdating = .ScreenUpdating
            mPrevEnableEvents = .EnableEvents
            mPrevDisplayAlerts = .DisplayAlerts
            mPrevCalculation = .Calculation
            mPrevStatusBar = .StatusBar

            .ScreenUpdating = False
            .EnableEvents = False
            .DisplayAlerts = False
            .Calculation = xlCalculationManual
            .StatusBar = statusText
        End With
    End If

    mFastDepth = mFastDepth + 1
End Sub

Private Sub ONGEN_SPEC_FastEnd()
    If mFastDepth <= 0 Then
        mFastDepth = 0
        Exit Sub
    End If

    mFastDepth = mFastDepth - 1
    If mFastDepth > 0 Then Exit Sub

    On Error Resume Next
    With Application
        .ScreenUpdating = mPrevScreenUpdating
        .EnableEvents = mPrevEnableEvents
        .DisplayAlerts = mPrevDisplayAlerts
        .Calculation = mPrevCalculation
        .StatusBar = mPrevStatusBar
    End With
    On Error GoTo 0
End Sub

Private Function ONGEN_SPEC_ElapsedSeconds(ByVal startTimer As Double) As Double
    Dim finishTimer As Double
    finishTimer = Timer
    If finishTimer >= startTimer Then
        ONGEN_SPEC_ElapsedSeconds = finishTimer - startTimer
    Else
        ONGEN_SPEC_ElapsedSeconds = (86400# - startTimer) + finishTimer
    End If
End Function
