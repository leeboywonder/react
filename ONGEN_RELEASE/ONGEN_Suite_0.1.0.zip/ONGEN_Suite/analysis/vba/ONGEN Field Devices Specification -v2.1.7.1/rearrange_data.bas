Attribute VB_Name = "rearrange_data"
Sub RearrangeDesignedExport_NEW()

    Dim wsSrc As Worksheet, wsDest As Worksheet
    Dim lastRow As Long, srcRow As Long, destRow As Long
    Dim colPairs As Variant, i As Long
    
    Dim ComputerName, UserName As String, LDate As String


    'Getting computer name
    ComputerName = Environ("computername")
    LDate = Date
    
    'Getting user name
    UserName = Environ("username")
    
    'Assigning value to cell C14 and E7
    
    Range("C18").Value = UserName
    Range("E7").Value = Date


    ' Define source and destination sheets
    Set wsSrc = ThisWorkbook.Sheets("EE BOM IMPORT")
    On Error Resume Next
    Set wsDest = ThisWorkbook.Sheets("EE System Designed BOM")
    If wsDest Is Nothing Then
        Set wsDest = ThisWorkbook.Sheets.Add
        wsDest.Name = "EE System Designed BOM"
    End If
    On Error GoTo 0
    
    wsDest.Range("A1:E700").Clear ' clear destination before writing
    
    ' Write header
    wsDest.Range("A1").Value = "Conv.ID"
    wsDest.Range("B1").Value = "Items Type"
    wsDest.Range("C1").Value = "QTY"
    wsDest.Range("D1").Value = "Manufacturer"
    wsDest.Range("E1").Value = "Part Number"
    
    ' Column pairs to loop through
    colPairs = Array(4, 6, 8, 10, 12, 14) ' D, F, H, J, L, N
    
    lastRow = Application.Min(1000, wsSrc.Cells(wsSrc.rows.count, "A").End(xlUp).Row)
    destRow = 2
    
    ' Loop through each row in source sheet
    For srcRow = 2 To lastRow
        If Application.WorksheetFunction.CountA(wsSrc.Range("A" & srcRow & ":C" & srcRow)) > 0 Then
            ' Loop through each pair
            For i = LBound(colPairs) To UBound(colPairs)
                wsDest.Cells(destRow, 1).Value = wsSrc.Cells(srcRow, 1).Value
                wsDest.Cells(destRow, 2).Value = wsSrc.Cells(srcRow, 2).Value
                wsDest.Cells(destRow, 3).Value = wsSrc.Cells(srcRow, 3).Value
                
                ' Copy data from pair (col, col+1)
                If Application.WorksheetFunction.CountA(wsSrc.Cells(srcRow, colPairs(i)).Resize(1, 2)) > 0 Then
                    wsDest.Cells(destRow, 4).Value = wsSrc.Cells(srcRow, colPairs(i)).Value
                    wsDest.Cells(destRow, 5).Value = wsSrc.Cells(srcRow, colPairs(i) + 1).Value
                End If
                
                destRow = destRow + 1
            Next i
        End If
    Next srcRow
    
    MsgBox "Data rearrangement complete!", vbInformation

End Sub

