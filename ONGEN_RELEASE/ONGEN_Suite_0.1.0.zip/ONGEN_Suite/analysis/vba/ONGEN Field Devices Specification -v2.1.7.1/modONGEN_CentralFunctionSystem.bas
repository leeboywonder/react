Attribute VB_Name = "modONGEN_CentralFunctionSystem"
Option Explicit

' ============================================================================
' Author: Lee Pierre
' Module: modONGEN_CentralFunctionSystem
' Release: 2.1.2
' Purpose:
'   Centralize ONGEN engineering Function Codes across:
'     1) Master Function / Part Library [FUNCTION_CODE]
'     2) PD Master [CONTROL_FUNCTION_NUMBER]
'     3) Field Devices Specification [code variant]
'
' CORE RULE
'   FUNCTION_CODE = CONTROL_FUNCTION_NUMBER = code variant
'
'   The Master Library owns the Function Code. PD and Specification never
'   create independent engineering codes. No legacy code is used by the sync.
'
' THREE MODES
'   MODE 1 - Workbook open check for a changed Master Library.
'   MODE 2 - Manual SYNC MASTER LIBRARY button.
'   MODE 3 - Normal workbook operation against synchronized local views.
'
' PORTABLE ROOT
'   No absolute path is stored. The code walks upward from ThisWorkbook.Path
'   and finds sibling folders such as "Master Part Library" and
'   "Specification" within the portable ONGEN suite structure.
' ============================================================================

Private Const ONGEN_RELEASE As String = "2.1.2"
Private Const MAX_PARENT_LEVELS As Long = 12
Private Const MASTER_FOLDER As String = "Master Part Library"
Private Const SPEC_FOLDER As String = "Specification"
Private Const MASTER_FILE_PRIMARY As String = "ONGEN_EAS_MASTER_FUNCTION_LIBRARY.xlsx"
Private Const NAME_LOCAL_VERSION As String = "ONGEN_MASTER_LIBRARY_VERSION"
Private Const NAME_LOCAL_SIGNATURE As String = "ONGEN_MASTER_LIBRARY_SIGNATURE"
Private Const NAME_LAST_SYNC As String = "ONGEN_MASTER_LIBRARY_LAST_SYNC"
Private Const NAME_MASTER_LIBRARY_PATH As String = "ONGEN_MASTER_LIBRARY_PATH"
Private Const NAME_SPEC_WORKBOOK_PATH As String = "ONGEN_SPECIFICATION_WORKBOOK_PATH"

Private Const SHEET_PD As String = "FUNCTION DEFINITION"
Private Const SHEET_SPEC As String = "VARIANT LIST"
Private Const SHEET_FUNCTIONS As String = "FUNCTION_MASTER"
Private Const SHEET_COMPONENTS As String = "FUNCTION_COMPONENTS"
Private Const SHEET_BOM As String = "VARIANT_BOM"
Private Const SHEET_CONFIG As String = "CONFIG"
Private Const SHEET_GUIDE As String = "WORKBOOK GUIDE"

' ============================= PUBLIC ENTRY POINTS ===========================

Public Sub ONGEN_INSTALL_CENTRAL_FUNCTION_SYSTEM()
    Dim hookOK As Boolean
    Dim targetName As String

    On Error GoTo EH

    If ONGEN_IsPDWorkbook Then
        targetName = "PD Master"
    ElseIf ONGEN_IsSpecificationWorkbook Then
        targetName = "Field Devices Specification"
    Else
        MsgBox "This workbook is not a supported ONGEN PD or Specification workbook.", _
               vbExclamation, "ONGEN Central Function System"
        Exit Sub
    End If

    ONGEN_CreateOrRefreshButtons
    ONGEN_CreateWorkbookGuide
    If ONGEN_IsPDWorkbook Then ONGEN_RebindFunctionCSVExportButton
    hookOK = ONGEN_InstallWorkbookOpenHook()

    MsgBox targetName & " central Function Code controls are installed." & vbCrLf & vbCrLf & _
           "Master Function Code rule:" & vbCrLf & _
           "  Master FUNCTION_CODE = PD CONTROL_FUNCTION_NUMBER = Specification code variant" & vbCrLf & vbCrLf & _
           "Buttons have been placed at the requested worksheet positions." & vbCrLf & _
           IIf(hookOK, "Workbook-open library checking is active.", _
               "Workbook-open checking could not be installed. Manual SYNC still works."), _
           vbInformation, "ONGEN Central Function System"
    Exit Sub
EH:
    MsgBox "ONGEN installation failed:" & vbCrLf & Err.Description, vbCritical, "ONGEN Central Function System"
End Sub

' Compatibility alias for the previous installer name.
Public Sub ONGEN_INSTALL_MASTER_LIBRARY_LINK()
    ONGEN_INSTALL_CENTRAL_FUNCTION_SYSTEM
End Sub

Public Sub ONGEN_MasterLibrary_OpenCheck()
    On Error GoTo SafeExit
    If Not (ONGEN_IsPDWorkbook Or ONGEN_IsSpecificationWorkbook) Then Exit Sub
    ONGEN_CheckMasterLibraryVersion False, False
SafeExit:
End Sub

Public Sub ONGEN_ShowMasterLibraryStatus()
    ONGEN_CheckMasterLibraryVersion True, True
End Sub

Public Sub ONGEN_SyncMasterLibrary()
    Dim lib As Workbook
    Dim openedByUs As Boolean
    Dim masterPath As String
    Dim version As String, signature As String
    Dim oldCalc As XlCalculation
    Dim oldEvents As Boolean, oldScreen As Boolean

    On Error GoTo EH

    masterPath = ONGEN_MasterFunctionLibraryPath(True)
    If Len(masterPath) = 0 Then
        MsgBox "Master Library synchronization was canceled. No workbook data was changed.", _
               vbInformation, "ONGEN Master Library"
        Exit Sub
    End If
    Set lib = ONGEN_OpenMasterLibrary(masterPath, openedByUs)
    version = ONGEN_ReadLibraryVersion(lib)
    signature = ONGEN_MasterSignature(masterPath, version)

    oldCalc = Application.Calculation
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    If ONGEN_IsPDWorkbook Then
        ONGEN_SyncPDView ThisWorkbook.Worksheets(SHEET_PD), lib
        ONGEN_StampFunctionDescriptionsFromOpenLibrary lib
    ElseIf ONGEN_IsSpecificationWorkbook Then
        ONGEN_SyncSpecificationView ThisWorkbook.Worksheets(SHEET_SPEC), lib
    End If

    ONGEN_SetWorkbookTextName NAME_LOCAL_VERSION, version
    ONGEN_SetWorkbookTextName NAME_LOCAL_SIGNATURE, signature
    ONGEN_SetWorkbookTextName NAME_LAST_SYNC, Format$(Now, "yyyy-mm-dd hh:nn:ss")

CleanExit:
    Application.Calculation = oldCalc
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    If openedByUs Then
        If Not lib Is Nothing Then lib.Close SaveChanges:=False
    End If

    If Err.Number = 0 Then
        MsgBox "Master Library synchronization completed." & vbCrLf & vbCrLf & _
               IIf(ONGEN_IsPDWorkbook, "PD CONTROL_FUNCTION_NUMBER updated from Master FUNCTION_CODE.", _
                   "Specification code variant updated from Master FUNCTION_CODE.") & vbCrLf & _
               "Library version: " & version, vbInformation, "ONGEN Master Library"
    End If
    Exit Sub
EH:
    MsgBox "Master Library synchronization failed:" & vbCrLf & Err.Description, vbCritical, "ONGEN Master Library"
    Resume CleanExit
End Sub


Public Sub ONGEN_SelectMasterLibrary()
    Dim p As String
    Dim lib As Workbook
    Dim openedByUs As Boolean

    On Error GoTo EH

    p = ONGEN_BrowseForMasterFunctionLibrary()
    If Len(p) = 0 Then
        MsgBox "No Master Function Library was selected. No workbook data was changed.", _
               vbInformation, "ONGEN Master Library"
        Exit Sub
    End If

    Set lib = ONGEN_OpenMasterLibrary(p, openedByUs)
    If Not ONGEN_SheetExists(lib, SHEET_FUNCTIONS) Then
        Err.Raise vbObjectError + 2712, , _
                  "The selected workbook does not contain the required '" & SHEET_FUNCTIONS & "' worksheet."
    End If

    If openedByUs Then lib.Close SaveChanges:=False
    ONGEN_SetWorkbookTextName NAME_MASTER_LIBRARY_PATH, p

    MsgBox "Master Function Library path saved." & vbCrLf & vbCrLf & _
           p & vbCrLf & vbCrLf & _
           "Future Master Library status and synchronization commands will use this path while the file exists.", _
           vbInformation, "ONGEN Master Library"
    Exit Sub

EH:
    On Error Resume Next
    If openedByUs Then
        If Not lib Is Nothing Then lib.Close SaveChanges:=False
    End If
    On Error GoTo 0
    MsgBox "Master Library path could not be saved:" & vbCrLf & Err.Description, _
           vbExclamation, "ONGEN Master Library"
End Sub

Public Sub ONGEN_MasterLibrary_Diagnostics()
    Dim savedPath As String
    Dim autoPath As String
    Dim msg As String
    Dim tempWarning As String

    savedPath = Trim$(ONGEN_GetWorkbookTextName(NAME_MASTER_LIBRARY_PATH))
    autoPath = ONGEN_MasterFunctionLibraryPath(False)

    If ONGEN_IsTemporaryWorkbookPath(ThisWorkbook.path) Then
        tempWarning = vbCrLf & vbCrLf & _
                      "WARNING: This workbook appears to be running from a temporary folder." & vbCrLf & _
                      "This commonly happens when an XLSM is opened directly from inside a ZIP file." & vbCrLf & _
                      "Extract the COMPLETE ONGEN suite before opening the workbook."
    End If

    msg = "ONGEN Central Function System diagnostics" & vbCrLf & vbCrLf & _
          "Release: " & ONGEN_RELEASE & vbCrLf & _
          "Workbook: " & ThisWorkbook.FullName & vbCrLf & _
          "Saved Master path: " & IIf(Len(savedPath) > 0, savedPath, "<none>") & vbCrLf & _
          "Resolved Master path: " & IIf(Len(autoPath) > 0, autoPath, "<not found>") & _
          tempWarning

    MsgBox msg, vbInformation, "ONGEN Master Library Diagnostics"
End Sub

Public Sub ONGEN_OpenWorkbookGuide()
    On Error Resume Next
    ONGEN_CreateWorkbookGuide
    ThisWorkbook.Worksheets(SHEET_GUIDE).Activate
    On Error GoTo 0
End Sub

' PD-only: push finalized design-detail rows to the portable Specification workbook.
' The Function Code is always written to EM Designed function[VARIANT].
Public Sub ONGEN_PushDesignDetailToSpecification()
    Dim src As Worksheet, dst As Worksheet
    Dim specWB As Workbook
    Dim specPath As String
    Dim openedByUs As Boolean
    Dim lastSrc As Long, r As Long, tr As Long, slot As Long
    Dim cFunc As Long, cType As Long, cID As Long, cQty As Long
    Dim cIn As Long, cOut As Long, cSIn As Long, cSOut As Long
    Dim functionCode As String

    On Error GoTo EH
    If Not ONGEN_IsPDWorkbook Then
        MsgBox "This command must be run from the PD Master workbook.", vbExclamation, "ONGEN Push Design"
        Exit Sub
    End If

    ONGEN_StampFunctionDescriptionsForCAD

    If ONGEN_SheetExists(ThisWorkbook, "Specification Devices") Then
        Set src = ThisWorkbook.Worksheets("Specification Devices")
    ElseIf ONGEN_SheetExists(ThisWorkbook, "FUNCTION DEVICE pd2") Then
        Set src = ThisWorkbook.Worksheets("FUNCTION DEVICE pd2")
    Else
        Err.Raise vbObjectError + 2901, , "No Specification Devices or FUNCTION DEVICE pd2 worksheet exists. Run the PD design-detail build first."
    End If

    specPath = ONGEN_RequireSpecificationWorkbookPath(True)
    Set specWB = ONGEN_OpenWorkbookByPath(specPath, openedByUs, False)
    If Not ONGEN_SheetExists(specWB, "EM Designed function") Then
        Err.Raise vbObjectError + 2902, , "The Specification workbook is missing 'EM Designed function'."
    End If
    Set dst = specWB.Worksheets("EM Designed function")

    cFunc = ONGEN_FindHeaderByAliases(src, 1, Array("CONTROL_FUNCTION_NUMBER", "FUNCTION_CODE", "CODE VARIANT", "VARIANT"))
    cType = ONGEN_FindHeaderByAliases(src, 1, Array("CONTROL_FUNCTION_TAG", "TYPE", "ITEMS TYPE", "ITEM TYPE"))
    cID = ONGEN_FindHeaderByAliases(src, 1, Array("DEVICE NAME", "SIS_SEQUENCE", "SEQUENCE", "SIS_ELEMENT_NUMBER", "LPN"))
    cQty = ONGEN_FindHeaderByAliases(src, 1, Array("QTY", "QUANTITY"))
    cIn = ONGEN_FindHeaderByAliases(src, 1, Array("INPUT"))
    cOut = ONGEN_FindHeaderByAliases(src, 1, Array("OUTPUT"))
    cSIn = ONGEN_FindHeaderByAliases(src, 1, Array("S_IN"))
    cSOut = ONGEN_FindHeaderByAliases(src, 1, Array("S_OUT"))

    If cFunc = 0 Then Err.Raise vbObjectError + 2903, , "Source design-detail sheet is missing CONTROL_FUNCTION_NUMBER."

    ONGEN_ClearRowsBelowHeader dst, 1
    ONGEN_EnsureHeader dst, "FUNCTION DESCRIPTION"

    lastSrc = ONGEN_LastUsedRow(src)
    tr = 2
    For r = 2 To lastSrc
        functionCode = Trim$(CStr(ONGEN_CellValue(src, r, cFunc)))
        If Len(functionCode) > 0 Then
            ONGEN_SetByExistingHeader dst, tr, "Conv.ID", ONGEN_CellValue(src, r, cID)
            ONGEN_SetByExistingHeader dst, tr, "Items Type", ONGEN_CellValue(src, r, cType)
            ONGEN_SetByExistingHeader dst, tr, "VARIANT", functionCode
            ONGEN_SetByExistingHeader dst, tr, "QTY", IIf(cQty > 0 And Len(Trim$(CStr(ONGEN_CellValue(src, r, cQty)))) > 0, ONGEN_CellValue(src, r, cQty), 1)
            ONGEN_SetByExistingHeader dst, tr, "INPUT", ONGEN_CellValue(src, r, cIn)
            ONGEN_SetByExistingHeader dst, tr, "OUTPUT", ONGEN_CellValue(src, r, cOut)
            ONGEN_SetByExistingHeader dst, tr, "S_IN", ONGEN_CellValue(src, r, cSIn)
            ONGEN_SetByExistingHeader dst, tr, "S_OUT", ONGEN_CellValue(src, r, cSOut)
            ONGEN_SetByHeader dst, tr, "FUNCTION DESCRIPTION", ONGEN_GetByAliases(src, r, Array("FUNCTION_DESCRIPTION", "FUNCTION DESCRIPTION", "NOTE"))

            For slot = 1 To 99
                If ONGEN_FindHeaderByAliases(src, 1, Array("PART_NUM_" & slot, "PART NUMBER " & slot)) = 0 And _
                   ONGEN_FindHeaderByAliases(src, 1, Array("MANUF_NAME_" & slot, "MANUFACTURER " & slot)) = 0 Then Exit For
                ONGEN_SetByExistingHeader dst, tr, "Manufacturer " & slot, _
                    ONGEN_GetByAliases(src, r, Array("MANUF_NAME_" & slot, "MANUFACTURER " & slot))
                ONGEN_SetByExistingHeader dst, tr, "Part Number " & slot, _
                    ONGEN_GetByAliases(src, r, Array("PART_NUM_" & slot, "PART NUMBER " & slot))
            Next slot
            tr = tr + 1
        End If
    Next r

    specWB.Save
    If openedByUs Then specWB.Close SaveChanges:=True
    MsgBox CStr(tr - 2) & " design-detail row(s) pushed to the Specification workbook." & vbCrLf & _
           "Function Code was written to EM Designed function[VARIANT].", vbInformation, "ONGEN Push Design"
    Exit Sub
EH:
    On Error Resume Next
    If openedByUs Then If Not specWB Is Nothing Then specWB.Close SaveChanges:=False
    On Error GoTo 0
    MsgBox "PD to Specification push failed:" & vbCrLf & Err.Description, vbCritical, "ONGEN Push Design"
End Sub

' Ensures function descriptions exist on generated PD sheets before AutoCAD export.
Public Sub ONGEN_StampFunctionDescriptionsForCAD()
    Dim lib As Workbook, openedByUs As Boolean, p As String
    On Error GoTo EH
    p = ONGEN_RequireMasterFunctionLibrary(False)
    Set lib = ONGEN_OpenMasterLibrary(p, openedByUs)
    ONGEN_StampFunctionDescriptionsFromOpenLibrary lib
    If openedByUs Then lib.Close SaveChanges:=False
    Exit Sub
EH:
    On Error Resume Next
    If openedByUs Then If Not lib Is Nothing Then lib.Close SaveChanges:=False
    On Error GoTo 0
End Sub

Public Sub ONGEN_ExportFunctionDeviceCSV_WithDescription()
    On Error GoTo EH
    ONGEN_StampFunctionDescriptionsForCAD
    Application.Run "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!Export_Function_Device_PD2_To_CSV"
    Exit Sub
EH:
    MsgBox "Function-device export wrapper failed:" & vbCrLf & Err.Description, vbCritical, "ONGEN CAD Export"
End Sub

' ============================== PD SYNC ======================================

Private Sub ONGEN_SyncPDView(ByVal targetWS As Worksheet, ByVal lib As Workbook)
    Dim src As Worksheet, bomWS As Worksheet, fnWS As Worksheet
    Dim hdrRow As Long, fnHdr As Long
    Dim cFunction As Long, cComponent As Long, cVariant As Long
    Dim cType As Long, cBlock As Long, cConv As Long, cQty As Long
    Dim cIn As Long, cOut As Long, cSIn As Long, cSOut As Long, cRev As Long, cActive As Long
    Dim lastSrc As Long, r As Long, tr As Long, slot As Long
    Dim bom As Object, maxSlot As Object, descriptions As Object
    Dim functionCode As String, componentCode As String, variantCode As String, activeValue As String
    Dim arr As Variant, key As String

    Set src = lib.Worksheets(SHEET_COMPONENTS)
    Set bomWS = lib.Worksheets(SHEET_BOM)
    Set fnWS = lib.Worksheets(SHEET_FUNCTIONS)

    cFunction = ONGEN_FindHeaderInTopRows(src, "FUNCTION_CODE", hdrRow)
    cComponent = ONGEN_FindHeaderColumn(src, "COMPONENT_CODE", hdrRow)
    cVariant = ONGEN_FindHeaderColumn(src, "VARIANT_CODE", hdrRow)
    cType = ONGEN_FindHeaderColumn(src, "COMPONENT_TYPE", hdrRow)
    cBlock = ONGEN_FindHeaderColumn(src, "BLOCK", hdrRow)
    cConv = ONGEN_FindHeaderColumn(src, "CONVEYOR_TYPE", hdrRow)
    cQty = ONGEN_FindHeaderColumn(src, "QTY", hdrRow)
    cIn = ONGEN_FindHeaderColumn(src, "INPUT", hdrRow)
    cOut = ONGEN_FindHeaderColumn(src, "OUTPUT", hdrRow)
    cSIn = ONGEN_FindHeaderColumn(src, "S_IN", hdrRow)
    cSOut = ONGEN_FindHeaderColumn(src, "S_OUT", hdrRow)
    cRev = ONGEN_FindHeaderColumn(src, "REVISION", hdrRow)
    cActive = ONGEN_FindHeaderColumn(src, "ACTIVE", hdrRow)

    If cFunction = 0 Or cComponent = 0 Or cVariant = 0 Then
        Err.Raise vbObjectError + 2701, , "FUNCTION_COMPONENTS is missing FUNCTION_CODE / COMPONENT_CODE / VARIANT_CODE."
    End If

    Set descriptions = ONGEN_BuildFunctionDescriptionIndex(fnWS)
    ONGEN_BuildBOMIndex bomWS, bom, maxSlot

    ONGEN_EnsureHeader targetWS, "FUNCTION_CODE"
    ONGEN_EnsureHeader targetWS, "COMPONENT_CODE"
    ONGEN_EnsureHeader targetWS, "DEVICE_VARIANT_CODE"
    ONGEN_EnsureHeader targetWS, "COMPONENT_QTY"
    ONGEN_EnsureHeader targetWS, "MASTER_REVISION"
    ONGEN_EnsureHeader targetWS, "MASTER_ACTIVE"

    ONGEN_ClearPDManagedData targetWS
    lastSrc = src.Cells(src.rows.count, cFunction).End(xlUp).Row
    tr = 2

    For r = hdrRow + 1 To lastSrc
        functionCode = Trim$(CStr(ONGEN_CellValue(src, r, cFunction)))
        componentCode = Trim$(CStr(ONGEN_CellValue(src, r, cComponent)))
        variantCode = Trim$(CStr(ONGEN_CellValue(src, r, cVariant)))
        activeValue = UCase$(Trim$(CStr(ONGEN_CellValue(src, r, cActive))))

        If Len(functionCode) > 0 And activeValue <> "NO" And activeValue <> "FALSE" And activeValue <> "0" Then
            ' One and only engineering code standard.
            ONGEN_SetByHeader targetWS, tr, "CONTROL_FUNCTION_NUMBER", functionCode
            ONGEN_SetByHeader targetWS, tr, "FUNCTION_CODE", functionCode
            ONGEN_SetByHeader targetWS, tr, "CONTROL_FUNCTION_TAG", ONGEN_CellValue(src, r, cType)
            ONGEN_SetByHeader targetWS, tr, "BLOCK", ONGEN_CellValue(src, r, cBlock)
            If descriptions.Exists(UCase$(functionCode)) Then ONGEN_SetByHeader targetWS, tr, "NOTE", descriptions(UCase$(functionCode))
            ONGEN_SetByHeader targetWS, tr, "conveyor Type", ONGEN_CellValue(src, r, cConv)
            ONGEN_SetByHeader targetWS, tr, "INPUT", ONGEN_CellValue(src, r, cIn)
            ONGEN_SetByHeader targetWS, tr, "OUTPUT", ONGEN_CellValue(src, r, cOut)
            ONGEN_SetByHeader targetWS, tr, "S_IN", ONGEN_CellValue(src, r, cSIn)
            ONGEN_SetByHeader targetWS, tr, "S_OUT", ONGEN_CellValue(src, r, cSOut)
            ONGEN_SetByHeader targetWS, tr, "COMPONENT_CODE", componentCode
            ONGEN_SetByHeader targetWS, tr, "DEVICE_VARIANT_CODE", variantCode
            ONGEN_SetByHeader targetWS, tr, "COMPONENT_QTY", ONGEN_CellValue(src, r, cQty)
            ONGEN_SetByHeader targetWS, tr, "MASTER_REVISION", ONGEN_CellValue(src, r, cRev)
            ONGEN_SetByHeader targetWS, tr, "MASTER_ACTIVE", ONGEN_CellValue(src, r, cActive)

            If maxSlot.Exists(UCase$(variantCode)) Then
                For slot = 1 To CLng(maxSlot(UCase$(variantCode)))
                    key = UCase$(variantCode) & "|" & CStr(slot)
                    If bom.Exists(key) Then
                        arr = bom(key)
                        ONGEN_SetByHeader targetWS, tr, "PART_NUM_" & slot, arr(1)
                        ONGEN_SetByHeader targetWS, tr, "MANUF_NAME_" & slot, arr(0)
                        ONGEN_SetByHeader targetWS, tr, "PART_QTY_" & slot, arr(2)
                    End If
                Next slot
            End If
            tr = tr + 1
        End If
    Next r

    ONGEN_HideSystemColumns targetWS, Array("FUNCTION_CODE", "COMPONENT_CODE", "DEVICE_VARIANT_CODE", "COMPONENT_QTY", "MASTER_REVISION", "MASTER_ACTIVE")
End Sub

' =========================== SPECIFICATION SYNC ==============================

Private Sub ONGEN_SyncSpecificationView(ByVal targetWS As Worksheet, ByVal lib As Workbook)
    Dim fnWS As Worksheet, compWS As Worksheet, bomWS As Worksheet
    Dim fnHdr As Long, compHdr As Long
    Dim cFn As Long, cDesc As Long, cFnRev As Long, cFnActive As Long
    Dim ccFn As Long, ccVar As Long, ccType As Long, ccQty As Long
    Dim ccIn As Long, ccOut As Long, ccSIn As Long, ccSOut As Long, ccActive As Long
    Dim lastFn As Long, lastComp As Long, r As Long, cr As Long, tr As Long
    Dim functionCode As String, activeValue As String, variantCode As String
    Dim bom As Object, maxSlot As Object, key As String, arr As Variant
    Dim outSlot As Long, slot As Long
    Dim sumIn As Double, sumOut As Double, sumSIn As Double, sumSOut As Double
    Dim compQty As Double, variantsText As String, componentCount As Long

    Set fnWS = lib.Worksheets(SHEET_FUNCTIONS)
    Set compWS = lib.Worksheets(SHEET_COMPONENTS)
    Set bomWS = lib.Worksheets(SHEET_BOM)

    cFn = ONGEN_FindHeaderInTopRows(fnWS, "FUNCTION_CODE", fnHdr)
    cDesc = ONGEN_FindHeaderColumn(fnWS, "FUNCTION_DESCRIPTION", fnHdr)
    cFnRev = ONGEN_FindHeaderColumn(fnWS, "REVISION", fnHdr)
    cFnActive = ONGEN_FindHeaderColumn(fnWS, "ACTIVE", fnHdr)

    ccFn = ONGEN_FindHeaderInTopRows(compWS, "FUNCTION_CODE", compHdr)
    ccVar = ONGEN_FindHeaderColumn(compWS, "VARIANT_CODE", compHdr)
    ccType = ONGEN_FindHeaderColumn(compWS, "COMPONENT_TYPE", compHdr)
    ccQty = ONGEN_FindHeaderColumn(compWS, "QTY", compHdr)
    ccIn = ONGEN_FindHeaderColumn(compWS, "INPUT", compHdr)
    ccOut = ONGEN_FindHeaderColumn(compWS, "OUTPUT", compHdr)
    ccSIn = ONGEN_FindHeaderColumn(compWS, "S_IN", compHdr)
    ccSOut = ONGEN_FindHeaderColumn(compWS, "S_OUT", compHdr)
    ccActive = ONGEN_FindHeaderColumn(compWS, "ACTIVE", compHdr)

    If cFn = 0 Or ccFn = 0 Or ccVar = 0 Then Err.Raise vbObjectError + 2702, , "Master function/component headers are incomplete."

    ONGEN_BuildBOMIndex bomWS, bom, maxSlot
    ONGEN_ClearSpecificationManagedData targetWS
    ONGEN_EnsureHeader targetWS, "FUNCTION_CODE"
    ONGEN_EnsureHeader targetWS, "FUNCTION_DESCRIPTION"
    ONGEN_EnsureHeader targetWS, "DEVICE_VARIANT_CODE"
    ONGEN_EnsureHeader targetWS, "COMPONENT_COUNT"
    ONGEN_EnsureHeader targetWS, "MASTER_REVISION"
    ONGEN_EnsureHeader targetWS, "MASTER_ACTIVE"

    lastFn = fnWS.Cells(fnWS.rows.count, cFn).End(xlUp).Row
    lastComp = compWS.Cells(compWS.rows.count, ccFn).End(xlUp).Row
    tr = 2

    For r = fnHdr + 1 To lastFn
        functionCode = Trim$(CStr(fnWS.Cells(r, cFn).Value2))
        activeValue = UCase$(Trim$(CStr(ONGEN_CellValue(fnWS, r, cFnActive))))
        If Len(functionCode) > 0 And activeValue <> "NO" And activeValue <> "FALSE" And activeValue <> "0" Then
            outSlot = 1: sumIn = 0: sumOut = 0: sumSIn = 0: sumSOut = 0
            variantsText = "": componentCount = 0

            For cr = compHdr + 1 To lastComp
                If StrComp(Trim$(CStr(compWS.Cells(cr, ccFn).Value2)), functionCode, vbTextCompare) = 0 Then
                    If UCase$(Trim$(CStr(ONGEN_CellValue(compWS, cr, ccActive)))) <> "NO" Then
                        componentCount = componentCount + 1
                        variantCode = Trim$(CStr(ONGEN_CellValue(compWS, cr, ccVar)))
                        compQty = Val(ONGEN_CellValue(compWS, cr, ccQty)): If compQty <= 0 Then compQty = 1
                        If Len(variantCode) > 0 Then
                            If Len(variantsText) > 0 Then variantsText = variantsText & " | "
                            variantsText = variantsText & variantCode
                            If maxSlot.Exists(UCase$(variantCode)) Then
                                For slot = 1 To CLng(maxSlot(UCase$(variantCode)))
                                    key = UCase$(variantCode) & "|" & CStr(slot)
                                    If bom.Exists(key) Then
                                        arr = bom(key)
                                        ONGEN_SetByHeader targetWS, tr, "Manufacturer " & outSlot, arr(0)
                                        ONGEN_SetByHeader targetWS, tr, "Part Number " & outSlot, arr(1)
                                        ONGEN_SetByHeader targetWS, tr, "Part Qty " & outSlot, CDbl(arr(2)) * compQty
                                        outSlot = outSlot + 1
                                    End If
                                Next slot
                            End If
                        End If
                        sumIn = sumIn + Val(ONGEN_CellValue(compWS, cr, ccIn)) * compQty
                        sumOut = sumOut + Val(ONGEN_CellValue(compWS, cr, ccOut)) * compQty
                        sumSIn = sumSIn + Val(ONGEN_CellValue(compWS, cr, ccSIn)) * compQty
                        sumSOut = sumSOut + Val(ONGEN_CellValue(compWS, cr, ccSOut)) * compQty
                    End If
                End If
            Next cr

            ' One unique Specification row per engineering function.
            ONGEN_SetByHeader targetWS, tr, "code variant", functionCode
            ONGEN_SetByHeader targetWS, tr, "FUNCTION_CODE", functionCode
            ONGEN_SetByHeader targetWS, tr, "FUNCTION_DESCRIPTION", ONGEN_CellValue(fnWS, r, cDesc)
            ONGEN_SetByHeader targetWS, tr, "QTY", 1
            ONGEN_SetByHeader targetWS, tr, "INPUT", sumIn
            ONGEN_SetByHeader targetWS, tr, "OUTPUT", sumOut
            ONGEN_SetByHeader targetWS, tr, "S_IN", sumSIn
            ONGEN_SetByHeader targetWS, tr, "S_OUT", sumSOut
            ONGEN_SetByHeader targetWS, tr, "DEVICE_VARIANT_CODE", variantsText
            ONGEN_SetByHeader targetWS, tr, "COMPONENT_COUNT", componentCount
            ONGEN_SetByHeader targetWS, tr, "MASTER_REVISION", ONGEN_CellValue(fnWS, r, cFnRev)
            ONGEN_SetByHeader targetWS, tr, "MASTER_ACTIVE", ONGEN_CellValue(fnWS, r, cFnActive)
            tr = tr + 1
        End If
    Next r

    ONGEN_HideSystemColumns targetWS, Array("FUNCTION_CODE", "DEVICE_VARIANT_CODE", "COMPONENT_COUNT", "MASTER_REVISION", "MASTER_ACTIVE")
End Sub

' ============================= CAD DESCRIPTION ===============================

Private Sub ONGEN_StampFunctionDescriptionsFromOpenLibrary(ByVal lib As Workbook)
    Dim d As Object, ws As Worksheet, nm As Variant
    Dim cCode As Long, lastRow As Long, r As Long, code As String
    Set d = ONGEN_BuildFunctionDescriptionIndex(lib.Worksheets(SHEET_FUNCTIONS))

    For Each nm In Array("FUNCTION DEVICE pd2", "Specification Devices", "PD6 System Designed")
        If ONGEN_SheetExists(ThisWorkbook, CStr(nm)) Then
            Set ws = ThisWorkbook.Worksheets(CStr(nm))
            cCode = ONGEN_FindHeaderByAliases(ws, 1, Array("CONTROL_FUNCTION_NUMBER", "FUNCTION_CODE", "CODE VARIANT", "VARIANT"))
            If cCode > 0 Then
                ONGEN_EnsureHeader ws, "FUNCTION_DESCRIPTION"
                lastRow = ONGEN_LastUsedRow(ws)
                For r = 2 To lastRow
                    code = UCase$(Trim$(CStr(ws.Cells(r, cCode).Value2)))
                    If Len(code) > 0 And d.Exists(code) Then ONGEN_SetByHeader ws, r, "FUNCTION_DESCRIPTION", d(code)
                Next r
            End If
        End If
    Next nm
End Sub

Private Function ONGEN_BuildFunctionDescriptionIndex(ByVal ws As Worksheet) As Object
    Dim d As Object, hdr As Long, cCode As Long, cDesc As Long, lastRow As Long, r As Long
    Dim code As String
    Set d = CreateObject("Scripting.Dictionary"): d.CompareMode = vbTextCompare
    cCode = ONGEN_FindHeaderInTopRows(ws, "FUNCTION_CODE", hdr)
    cDesc = ONGEN_FindHeaderColumn(ws, "FUNCTION_DESCRIPTION", hdr)
    If cCode = 0 Or cDesc = 0 Then
        Set ONGEN_BuildFunctionDescriptionIndex = d
        Exit Function
    End If
    lastRow = ws.Cells(ws.rows.count, cCode).End(xlUp).Row
    For r = hdr + 1 To lastRow
        code = UCase$(Trim$(CStr(ws.Cells(r, cCode).Value2)))
        If Len(code) > 0 Then d(code) = CStr(ws.Cells(r, cDesc).Value2)
    Next r
    Set ONGEN_BuildFunctionDescriptionIndex = d
End Function

' ============================== BOM INDEX ====================================

Private Sub ONGEN_BuildBOMIndex(ByVal bomWS As Worksheet, ByRef bom As Object, ByRef maxSlot As Object)
    Dim hdrRow As Long, cVariant As Long, cSlot As Long, cMfg As Long, cPart As Long, cQty As Long
    Dim lastRow As Long, r As Long, slot As Long, variantCode As String, k As String
    Dim arr As Variant, q As Double

    Set bom = CreateObject("Scripting.Dictionary"): bom.CompareMode = vbTextCompare
    Set maxSlot = CreateObject("Scripting.Dictionary"): maxSlot.CompareMode = vbTextCompare

    cVariant = ONGEN_FindHeaderInTopRows(bomWS, "VARIANT_CODE", hdrRow)
    cSlot = ONGEN_FindHeaderColumn(bomWS, "BOM_SLOT", hdrRow)
    cMfg = ONGEN_FindHeaderColumn(bomWS, "MANUFACTURER", hdrRow)
    cPart = ONGEN_FindHeaderColumn(bomWS, "PART_NUMBER", hdrRow)
    cQty = ONGEN_FindHeaderColumn(bomWS, "QTY", hdrRow)
    If cVariant = 0 Or cSlot = 0 Or cMfg = 0 Or cPart = 0 Then Err.Raise vbObjectError + 2703, , "VARIANT_BOM is missing required headers."

    lastRow = bomWS.Cells(bomWS.rows.count, cVariant).End(xlUp).Row
    For r = hdrRow + 1 To lastRow
        variantCode = Trim$(CStr(bomWS.Cells(r, cVariant).Value2))
        slot = CLng(Val(bomWS.Cells(r, cSlot).Value2))
        q = Val(ONGEN_CellValue(bomWS, r, cQty)): If q <= 0 Then q = 1
        If Len(variantCode) > 0 And slot > 0 Then
            arr = Array(CStr(bomWS.Cells(r, cMfg).Value2), CStr(bomWS.Cells(r, cPart).Value2), q)
            k = UCase$(variantCode) & "|" & CStr(slot)
            bom(k) = arr
            If Not maxSlot.Exists(UCase$(variantCode)) Then
                maxSlot(UCase$(variantCode)) = slot
            ElseIf slot > CLng(maxSlot(UCase$(variantCode))) Then
                maxSlot(UCase$(variantCode)) = slot
            End If
        End If
    Next r
End Sub

' =============================== BUTTONS =====================================

Public Sub ONGEN_CreateOrRefreshButtons()
    Dim ws As Worksheet, a1 As Range, a2 As Range, a3 As Range

    If ONGEN_IsPDWorkbook Then
        Set ws = ThisWorkbook.Worksheets("MAIN")
        Set a1 = ws.Range("S2")
        Set a2 = ws.Range("S4")
        Set a3 = ws.Range("S6")
        ONGEN_AddActionButton ws, "btnONGENSyncMasterLibrary", "SYNC MASTER LIBRARY", "ONGEN_SyncMasterLibrary", a1.Left, a1.Top, 185, 28
        ONGEN_AddActionButton ws, "btnONGENMasterLibraryStatus", "MASTER LIBRARY STATUS", "ONGEN_ShowMasterLibraryStatus", a2.Left, a2.Top, 185, 28
        ONGEN_AddActionButton ws, "btnONGENPushSpecification", "PUSH DESIGN TO SPECIFICATION", "ONGEN_PushDesignDetailToSpecification", a3.Left, a3.Top, 185, 28
    ElseIf ONGEN_IsSpecificationWorkbook Then
        Set ws = ThisWorkbook.Worksheets("START-HERE")
        Set a1 = ws.Range("J1")
        Set a2 = ws.Range("J3")
        ONGEN_AddActionButton ws, "btnONGENSyncMasterLibrary", "SYNC MASTER LIBRARY", "ONGEN_SyncMasterLibrary", a1.Left, a1.Top, 185, 28
        ONGEN_AddActionButton ws, "btnONGENMasterLibraryStatus", "MASTER LIBRARY STATUS", "ONGEN_ShowMasterLibraryStatus", a2.Left, a2.Top, 185, 28
    End If
End Sub

Private Sub ONGEN_AddActionButton(ByVal ws As Worksheet, ByVal shapeName As String, ByVal caption As String, _
                                  ByVal macroName As String, ByVal leftPos As Double, ByVal topPos As Double, _
                                  ByVal widthVal As Double, ByVal heightVal As Double)
    Dim shp As Shape
    On Error Resume Next: ws.Shapes(shapeName).Delete: On Error GoTo 0
    Set shp = ws.Shapes.AddShape(5, leftPos, topPos, widthVal, heightVal)
    shp.Name = shapeName
    shp.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
    With shp
        .Fill.ForeColor.RGB = RGB(31, 78, 121)
        .Line.ForeColor.RGB = RGB(20, 55, 90)
        .TextFrame2.TextRange.Text = caption
        .TextFrame2.TextRange.Font.Name = "Arial"
        .TextFrame2.TextRange.Font.Size = 10
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .Placement = xlMoveAndSize
    End With
End Sub

Private Sub ONGEN_RebindFunctionCSVExportButton()
    Dim ws As Worksheet, shp As Shape, act As String
    If Not ONGEN_IsPDWorkbook Then Exit Sub
    Set ws = ThisWorkbook.Worksheets("MAIN")
    For Each shp In ws.Shapes
        On Error Resume Next: act = shp.OnAction: On Error GoTo 0
        If InStr(1, act, "Export_Function_Device_PD2_To_CSV", vbTextCompare) > 0 Then
            shp.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!ONGEN_ExportFunctionDeviceCSV_WithDescription"
        End If
    Next shp
End Sub

' ============================== GUIDE SHEET ==================================

Public Sub ONGEN_CreateWorkbookGuide()
    Dim ws As Worksheet, home As Worksheet, shp As Shape
    Dim rowNo As Long, act As String, cap As String

    On Error Resume Next
    Application.DisplayAlerts = False
    ThisWorkbook.Worksheets(SHEET_GUIDE).Delete
    Application.DisplayAlerts = True
    On Error GoTo 0

    Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
    ws.Name = SHEET_GUIDE
    ws.Tab.Color = RGB(68, 114, 196)

    ws.Range("A1:F1").Merge
    ws.Range("A1").Value = IIf(ONGEN_IsPDWorkbook, "ONGEN PD MASTER - WORKBOOK GUIDE", "ONGEN FIELD DEVICES SPECIFICATION - WORKBOOK GUIDE")
    With ws.Range("A1:F1")
        .Interior.Color = RGB(31, 78, 121): .Font.Color = vbWhite: .Font.Bold = True: .Font.Size = 16
    End With
    ws.Range("A3").Value = "Central Function Code Rule"
    ws.Range("B3").Value = "Master FUNCTION_CODE = PD CONTROL_FUNCTION_NUMBER = Specification code variant"
    ws.Range("A4").Value = "Mode 1"
    ws.Range("B4").Value = "Workbook open: checks whether the Master Library changed and offers synchronization."
    ws.Range("A5").Value = "Mode 2"
    ws.Range("B5").Value = "SYNC MASTER LIBRARY: refreshes controlled function/BOM data from the central Master Part Library."
    ws.Range("A6").Value = "Mode 3"
    ws.Range("B6").Value = "Normal engineering workflow uses the synchronized local worksheets."

    ONGEN_WriteHeaderRow ws, 8, 1, Array("BUTTON / CONTROL", "MACRO", "WHAT IT DOES", "WHERE")
    With ws.Range("A8:D8")
        .Interior.Color = RGB(217, 225, 242): .Font.Bold = True
    End With
    rowNo = 9

    If ONGEN_IsPDWorkbook Then Set home = ThisWorkbook.Worksheets("MAIN") Else Set home = ThisWorkbook.Worksheets("START-HERE")
    For Each shp In home.Shapes
        cap = ONGEN_ShapeCaption(shp)
        act = "": On Error Resume Next: act = shp.OnAction: On Error GoTo 0
        If Len(cap) > 0 Or Len(act) > 0 Then
            ws.Cells(rowNo, 1).Value = cap
            ws.Cells(rowNo, 2).Value = act
            ws.Cells(rowNo, 3).Value = ONGEN_ButtonDescription(cap, act)
            ws.Cells(rowNo, 4).Value = home.Name
            rowNo = rowNo + 1
        End If
    Next shp

    If ONGEN_IsPDWorkbook Then
        ws.Cells(rowNo + 1, 1).Value = "FUNCTION DEFINITION"
        ws.Cells(rowNo + 1, 3).Value = "Managed PD view. CONTROL_FUNCTION_NUMBER is the central Function Code. Multiple rows may share one Function Code when the function contains multiple devices. NOTE is the function description."
    Else
        ws.Cells(rowNo + 1, 1).Value = "VARIANT LIST"
        ws.Cells(rowNo + 1, 3).Value = "Managed Specification view. code variant is the central Function Code. One row represents the complete function assembly BOM."
        ws.Cells(rowNo + 2, 1).Value = "EM Designed function"
        ws.Cells(rowNo + 2, 3).Value = "PD design-detail destination. VARIANT receives the same central Function Code."
    End If

    ws.Columns("A").ColumnWidth = 32
    ws.Columns("B").ColumnWidth = 42
    ws.Columns("C").ColumnWidth = 75
    ws.Columns("D").ColumnWidth = 22
    ws.Range("A1:F" & rowNo + 4).WrapText = True
    ws.rows("1:" & rowNo + 4).AutoFit
    ws.Range("A3:A6").Font.Bold = True
    ws.Activate
    ws.Range("A1").Select
End Sub

Private Function ONGEN_ShapeCaption(ByVal shp As Shape) As String
    On Error Resume Next
    ONGEN_ShapeCaption = Trim$(shp.TextFrame2.TextRange.Text)
    If Len(ONGEN_ShapeCaption) = 0 Then ONGEN_ShapeCaption = Trim$(shp.TextFrame.Characters.Text)
    On Error GoTo 0
End Function

Private Function ONGEN_ButtonDescription(ByVal caption As String, ByVal actionName As String) As String
    Dim s As String
    s = UCase$(caption & " " & actionName)
    Select Case True
        Case InStr(s, "SYNC MASTER") > 0: ONGEN_ButtonDescription = "Synchronizes the workbook from the portable Master Function / Part Library."
        Case InStr(s, "MASTER LIBRARY STATUS") > 0: ONGEN_ButtonDescription = "Shows the resolved Master Library path, version, and synchronization status."
        Case InStr(s, "PUSH DESIGN") > 0: ONGEN_ButtonDescription = "Pushes finalized PD design detail to the Specification workbook; Function Code is written to VARIANT."
        Case InStr(s, "BUILD FUNCTION") > 0: ONGEN_ButtonDescription = "Builds device rows from FUNCTION DEFINITION for the PD workflow."
        Case InStr(s, "EXPORT FUNCTION") > 0: ONGEN_ButtonDescription = "Exports function-device CAD data; the ONGEN wrapper also stamps FUNCTION_DESCRIPTION before export."
        Case InStr(s, "SPECIFICATION") > 0: ONGEN_ButtonDescription = "Opens, rebuilds, or updates specification-related engineering data."
        Case InStr(s, "RETURN") > 0 And InStr(s, "HOME") > 0: ONGEN_ButtonDescription = "Returns to the main/home worksheet."
        Case InStr(s, "LAUNCH") > 0: ONGEN_ButtonDescription = "Opens the worksheet launcher/navigation control."
        Case InStr(s, "EXPORT") > 0: ONGEN_ButtonDescription = "Exports the related engineering dataset for the next workflow stage."
        Case InStr(s, "IMPORT") > 0: ONGEN_ButtonDescription = "Imports the related engineering dataset into this workbook."
        Case InStr(s, "VALID") > 0: ONGEN_ButtonDescription = "Runs workflow/data validation checks."
        Case Else: ONGEN_ButtonDescription = "Runs the workbook macro shown in the MACRO column."
    End Select
End Function

' =============================== MODE 1 ======================================

Private Sub ONGEN_CheckMasterLibraryVersion(ByVal ShowIfCurrent As Boolean, Optional ByVal AllowBrowse As Boolean = False)
    Dim masterPath As String, lib As Workbook, openedByUs As Boolean
    Dim masterVersion As String, masterSignature As String, localVersion As String, localSignature As String
    Dim answer As VbMsgBoxResult

    On Error GoTo EH

    masterPath = ONGEN_MasterFunctionLibraryPath(AllowBrowse)

    'V2.1.0: A missing portable Master Library is not a PD-workflow failure.
    'Workbook-open checks remain silent. A manual status check may browse once.
    If Len(masterPath) = 0 Then
        If ShowIfCurrent Then
            Dim missingMsg As String
            missingMsg = "The ONGEN Master Function Library was not found automatically and no library file was selected." & vbCrLf & vbCrLf & _
                         "The local workbook can continue to use its synchronized local data." & vbCrLf & _
                         "Use ONGEN_SelectMasterLibrary to select the library once."

            If ONGEN_IsTemporaryWorkbookPath(ThisWorkbook.path) Then
                missingMsg = missingMsg & vbCrLf & vbCrLf & _
                             "This workbook appears to be running from a temporary folder. " & _
                             "If it was opened directly from inside ONGEN SUITE C02.zip, close Excel, extract the COMPLETE ZIP, then open the XLSM from the extracted folder."
            End If

            MsgBox missingMsg, vbInformation, "ONGEN Master Library Status"
        End If
        Exit Sub
    End If

    Set lib = ONGEN_OpenMasterLibrary(masterPath, openedByUs)
    masterVersion = ONGEN_ReadLibraryVersion(lib)
    masterSignature = ONGEN_MasterSignature(masterPath, masterVersion)
    localVersion = ONGEN_GetWorkbookTextName(NAME_LOCAL_VERSION)
    localSignature = ONGEN_GetWorkbookTextName(NAME_LOCAL_SIGNATURE)
    If openedByUs Then lib.Close SaveChanges:=False

    If Len(localSignature) = 0 Or StrComp(localSignature, masterSignature, vbBinaryCompare) <> 0 Then
        answer = MsgBox("A different ONGEN Master Library revision is available." & vbCrLf & vbCrLf & _
                        "Workbook version: " & IIf(Len(localVersion) > 0, localVersion, "<not synchronized>") & vbCrLf & _
                        "Master version: " & masterVersion & vbCrLf & _
                        "Path: " & masterPath & vbCrLf & vbCrLf & _
                        "Synchronize now?", vbYesNo + vbQuestion, "ONGEN Master Library")
        If answer = vbYes Then ONGEN_SyncMasterLibrary
    ElseIf ShowIfCurrent Then
        MsgBox "This workbook is synchronized with the current Master Library." & vbCrLf & vbCrLf & _
               "Version: " & masterVersion & vbCrLf & _
               "Last sync: " & ONGEN_GetWorkbookTextName(NAME_LAST_SYNC) & vbCrLf & _
               "Path: " & masterPath, vbInformation, "ONGEN Master Library Status"
    End If
    Exit Sub

EH:
    On Error Resume Next
    If openedByUs Then
        If Not lib Is Nothing Then lib.Close SaveChanges:=False
    End If
    On Error GoTo 0

    If ShowIfCurrent Then
        MsgBox "Master Library status could not be checked." & vbCrLf & vbCrLf & _
               Err.Description & vbCrLf & vbCrLf & _
               "PD workflow data was not changed.", _
               vbExclamation, "ONGEN Master Library Status"
    End If
End Sub

' ============================= PATH RESOLUTION ===============================

Private Function ONGEN_MasterFunctionLibraryPath(Optional ByVal AllowBrowse As Boolean = False) As String
    Dim cachedPath As String, foundPath As String
    Dim wb As Workbook

    '1) If the Master Library is already open, use it immediately.
    For Each wb In Application.Workbooks
        If Not wb Is ThisWorkbook Then
            If ONGEN_SheetExists(wb, SHEET_FUNCTIONS) Then
                If InStr(1, UCase$(wb.Name), "MASTER", vbTextCompare) > 0 Or _
                   InStr(1, UCase$(wb.Name), "LIBRARY", vbTextCompare) > 0 Then
                    ONGEN_MasterFunctionLibraryPath = wb.FullName
                    Exit Function
                End If
            End If
        End If
    Next wb

    '2) A previously selected library wins when it still exists.
    cachedPath = Trim$(ONGEN_GetWorkbookTextName(NAME_MASTER_LIBRARY_PATH))
    If Len(cachedPath) > 0 Then
        If ONGEN_FileExists(cachedPath) Then
            ONGEN_MasterFunctionLibraryPath = cachedPath
            Exit Function
        End If
    End If

    '3) Portable automatic search from the workbook location upward.
    foundPath = ONGEN_SearchMasterFunctionLibrary(ThisWorkbook.path)
    If Len(foundPath) > 0 Then
        ONGEN_MasterFunctionLibraryPath = foundPath
        Exit Function
    End If

    '4) Also search the current Excel/Windows working directory. This helps
    '   when a user launched the suite from a shortcut or changed folders.
    On Error Resume Next
    foundPath = ONGEN_SearchMasterFunctionLibrary(CurDir$)
    On Error GoTo 0
    If Len(foundPath) > 0 Then
        ONGEN_MasterFunctionLibraryPath = foundPath
        Exit Function
    End If

    '5) Manual commands may select the library once. The selected path is
    '   stored as a hidden workbook name so future status/sync calls can find it.
    If AllowBrowse Then
        foundPath = ONGEN_BrowseForMasterFunctionLibrary()
        If Len(foundPath) > 0 Then
            ONGEN_SetWorkbookTextName NAME_MASTER_LIBRARY_PATH, foundPath
            ONGEN_MasterFunctionLibraryPath = foundPath
        End If
    End If
End Function

Private Function ONGEN_SearchMasterFunctionLibrary(ByVal startPath As String) As String
    Dim currentPath As String, parentPath As String
    Dim folderAliases As Variant, i As Long, level As Long
    Dim candidateFolder As String, foundPath As String

    folderAliases = Array( _
        MASTER_FOLDER, _
        "Master Function Library", _
        "Master Library", _
        "ONGEN Master Library", _
        "ONGEN Master Part Library", _
        "ONGEN_MASTER_LIBRARY", _
        "Library")

    currentPath = ONGEN_NormalizeFolder(startPath)

    For level = 0 To MAX_PARENT_LEVELS
        If Len(currentPath) = 0 Then Exit For

        'The Master workbook may be directly beside the PD workbook or
        'directly in a common suite/root folder.
        foundPath = ONGEN_FindMasterWorkbookInFolder(currentPath)
        If Len(foundPath) > 0 Then
            ONGEN_SearchMasterFunctionLibrary = foundPath
            Exit Function
        End If

        'Check several portable sibling/subfolder naming conventions.
        For i = LBound(folderAliases) To UBound(folderAliases)
            candidateFolder = ONGEN_CombinePath(currentPath, CStr(folderAliases(i)))
            If ONGEN_FolderExists(candidateFolder) Then
                foundPath = ONGEN_FindMasterWorkbookInFolder(candidateFolder)
                If Len(foundPath) > 0 Then
                    ONGEN_SearchMasterFunctionLibrary = foundPath
                    Exit Function
                End If
            End If
        Next i

        parentPath = ONGEN_ParentFolder(currentPath)
        If Len(parentPath) = 0 Or StrComp(parentPath, currentPath, vbTextCompare) = 0 Then Exit For
        currentPath = parentPath
    Next level
End Function

Private Function ONGEN_FindMasterWorkbookInFolder(ByVal folderPath As String) As String
    Dim candidate As String, names As Variant, i As Long, f As String
    Dim upperName As String

    If Len(folderPath) = 0 Then Exit Function
    If Not ONGEN_FolderExists(folderPath) Then Exit Function

    names = Array( _
        MASTER_FILE_PRIMARY, _
        "ONGEN_EAS_MASTER_FUNCTION_LIBRARY.xlsm", _
        "ONGEN_MASTER_FUNCTION_LIBRARY.xlsm", _
        "ONGEN_MASTER_FUNCTION_LIBRARY.xlsx")

    For i = LBound(names) To UBound(names)
        candidate = ONGEN_CombinePath(folderPath, CStr(names(i)))
        If ONGEN_FileExists(candidate) Then
            ONGEN_FindMasterWorkbookInFolder = candidate
            Exit Function
        End If
    Next i

    'Compatibility fallback for renamed/versioned ONGEN master workbooks.
    On Error Resume Next
    f = Dir$(ONGEN_CombinePath(folderPath, "*.xls*"))
    On Error GoTo 0

    Do While Len(f) > 0
        upperName = UCase$(f)
        If InStr(1, upperName, "MASTER", vbTextCompare) > 0 And _
           (InStr(1, upperName, "FUNCTION", vbTextCompare) > 0 Or _
            InStr(1, upperName, "LIBRARY", vbTextCompare) > 0) Then
            ONGEN_FindMasterWorkbookInFolder = ONGEN_CombinePath(folderPath, f)
            Exit Function
        End If
        f = Dir$()
    Loop
End Function


Private Function ONGEN_IsTemporaryWorkbookPath(ByVal p As String) As Boolean
    Dim u As String
    u = UCase$(Replace(p, "/", "\"))

    ONGEN_IsTemporaryWorkbookPath = _
        (InStr(1, u, "\APPDATA\LOCAL\TEMP\", vbTextCompare) > 0 Or _
         InStr(1, u, "\WINDOWS\TEMP\", vbTextCompare) > 0 Or _
         InStr(1, u, "\CONTENT.MSO\", vbTextCompare) > 0 Or _
         InStr(1, u, "\INETCACHE\", vbTextCompare) > 0)
End Function

Private Function ONGEN_BrowseForMasterFunctionLibrary() As String
    Dim picked As Variant

    picked = Application.GetOpenFilename( _
                FileFilter:="Excel Workbooks (*.xls;*.xlsx;*.xlsm;*.xlsb),*.xls;*.xlsx;*.xlsm;*.xlsb", _
                Title:="Select ONGEN Master Function Library")

    If VarType(picked) = vbBoolean Then Exit Function
    If Len(Trim$(CStr(picked))) = 0 Then Exit Function
    If Not ONGEN_FileExists(CStr(picked)) Then Exit Function

    ONGEN_BrowseForMasterFunctionLibrary = CStr(picked)
End Function

Private Function ONGEN_RequireMasterFunctionLibrary(Optional ByVal AllowBrowse As Boolean = False) As String
    ONGEN_RequireMasterFunctionLibrary = ONGEN_MasterFunctionLibraryPath(AllowBrowse)

    If Len(ONGEN_RequireMasterFunctionLibrary) = 0 Then
        Err.Raise vbObjectError + 2710, , _
                  "Master Function Library could not be located. " & _
                  "Run MASTER LIBRARY STATUS or SYNC MASTER LIBRARY and select the library workbook when prompted."
    End If
End Function

Private Function ONGEN_RequireSpecificationWorkbookPath(Optional ByVal AllowBrowse As Boolean = False) As String
    Dim p As String

    p = ONGEN_SpecificationWorkbookPath(AllowBrowse)
    If Len(p) = 0 Then
        Err.Raise vbObjectError + 2910, , _
                  "Field Devices Specification workbook could not be located. " & _
                  "Keep the complete ONGEN suite together or select the Specification workbook when prompted."
    End If

    ONGEN_RequireSpecificationWorkbookPath = p
End Function

Private Function ONGEN_SpecificationWorkbookPath(Optional ByVal AllowBrowse As Boolean = False) As String
    Dim cachedPath As String, foundPath As String
    Dim wb As Workbook

    '1) Already-open Specification workbook.
    For Each wb In Application.Workbooks
        If Not wb Is ThisWorkbook Then
            If ONGEN_SheetExists(wb, SHEET_SPEC) Then
                If InStr(1, UCase$(wb.Name), "SPECIFICATION", vbTextCompare) > 0 Then
                    ONGEN_SpecificationWorkbookPath = wb.FullName
                    Exit Function
                End If
            End If
        End If
    Next wb

    '2) Previously selected path.
    cachedPath = Trim$(ONGEN_GetWorkbookTextName(NAME_SPEC_WORKBOOK_PATH))
    If Len(cachedPath) > 0 Then
        If ONGEN_FileExists(cachedPath) Then
            ONGEN_SpecificationWorkbookPath = cachedPath
            Exit Function
        End If
    End If

    '3) Workbook hierarchy.
    foundPath = ONGEN_SearchSpecificationWorkbook(ThisWorkbook.path)
    If Len(foundPath) > 0 Then
        ONGEN_SpecificationWorkbookPath = foundPath
        Exit Function
    End If

    '4) Current directory hierarchy.
    On Error Resume Next
    foundPath = ONGEN_SearchSpecificationWorkbook(CurDir$)
    On Error GoTo 0
    If Len(foundPath) > 0 Then
        ONGEN_SpecificationWorkbookPath = foundPath
        Exit Function
    End If

    '5) Manual browse.
    If AllowBrowse Then
        foundPath = ONGEN_BrowseForSpecificationWorkbook()
        If Len(foundPath) > 0 Then
            ONGEN_SetWorkbookTextName NAME_SPEC_WORKBOOK_PATH, foundPath
            ONGEN_SpecificationWorkbookPath = foundPath
        End If
    End If
End Function

Private Function ONGEN_SearchSpecificationWorkbook(ByVal startPath As String) As String
    Dim currentPath As String, parentPath As String
    Dim folderAliases As Variant, i As Long, level As Long
    Dim candidateFolder As String, foundPath As String

    folderAliases = Array( _
        SPEC_FOLDER, _
        "Field Devices Specification", _
        "Specifications", _
        "ONGEN Specification", _
        "ONGEN Specifications")

    currentPath = ONGEN_NormalizeFolder(startPath)

    For level = 0 To MAX_PARENT_LEVELS
        If Len(currentPath) = 0 Then Exit For

        foundPath = ONGEN_FindSpecificationWorkbookInFolder(currentPath)
        If Len(foundPath) > 0 Then
            ONGEN_SearchSpecificationWorkbook = foundPath
            Exit Function
        End If

        For i = LBound(folderAliases) To UBound(folderAliases)
            candidateFolder = ONGEN_CombinePath(currentPath, CStr(folderAliases(i)))
            If ONGEN_FolderExists(candidateFolder) Then
                foundPath = ONGEN_FindSpecificationWorkbookInFolder(candidateFolder)
                If Len(foundPath) > 0 Then
                    ONGEN_SearchSpecificationWorkbook = foundPath
                    Exit Function
                End If
            End If
        Next i

        parentPath = ONGEN_ParentFolder(currentPath)
        If Len(parentPath) = 0 Or StrComp(parentPath, currentPath, vbTextCompare) = 0 Then Exit For
        currentPath = parentPath
    Next level
End Function

Private Function ONGEN_FindSpecificationWorkbookInFolder(ByVal folderPath As String) As String
    Dim f As String, fullPath As String

    If Len(folderPath) = 0 Then Exit Function
    If Not ONGEN_FolderExists(folderPath) Then Exit Function

    On Error Resume Next
    f = Dir$(ONGEN_CombinePath(folderPath, "*.xls*"))
    On Error GoTo 0

    Do While Len(f) > 0
        If InStr(1, UCase$(f), "SPECIFICATION", vbTextCompare) > 0 Then
            fullPath = ONGEN_CombinePath(folderPath, f)
            If ONGEN_FileExists(fullPath) Then
                ONGEN_FindSpecificationWorkbookInFolder = fullPath
                Exit Function
            End If
        End If
        f = Dir$()
    Loop
End Function

Private Function ONGEN_BrowseForSpecificationWorkbook() As String
    Dim picked As Variant

    picked = Application.GetOpenFilename( _
                FileFilter:="Excel Workbooks (*.xls;*.xlsx;*.xlsm;*.xlsb),*.xls;*.xlsx;*.xlsm;*.xlsb", _
                Title:="Select ONGEN Field Devices Specification workbook")

    If VarType(picked) = vbBoolean Then Exit Function
    If Len(Trim$(CStr(picked))) = 0 Then Exit Function
    If Not ONGEN_FileExists(CStr(picked)) Then Exit Function

    ONGEN_BrowseForSpecificationWorkbook = CStr(picked)
End Function

Private Function ONGEN_FindSuiteSubfolder(ByVal targetFolder As String, ByVal startPath As String) As String
    Dim currentPath As String, candidate As String, parentPath As String, level As Long
    currentPath = ONGEN_NormalizeFolder(startPath)
    For level = 0 To MAX_PARENT_LEVELS
        If StrComp(ONGEN_LeafName(currentPath), targetFolder, vbTextCompare) = 0 And ONGEN_FolderExists(currentPath) Then ONGEN_FindSuiteSubfolder = currentPath: Exit Function
        candidate = ONGEN_CombinePath(currentPath, targetFolder)
        If ONGEN_FolderExists(candidate) Then ONGEN_FindSuiteSubfolder = candidate: Exit Function
        parentPath = ONGEN_ParentFolder(currentPath)
        If Len(parentPath) = 0 Or StrComp(parentPath, currentPath, vbTextCompare) = 0 Then Exit For
        currentPath = parentPath
    Next level
End Function

Private Function ONGEN_OpenMasterLibrary(ByVal fullPath As String, ByRef openedByUs As Boolean) As Workbook
    Set ONGEN_OpenMasterLibrary = ONGEN_OpenWorkbookByPath(fullPath, openedByUs, True)
End Function

Private Function ONGEN_OpenWorkbookByPath(ByVal fullPath As String, ByRef openedByUs As Boolean, ByVal readOnlyMode As Boolean) As Workbook
    Dim wb As Workbook
    openedByUs = False
    For Each wb In Application.Workbooks
        If StrComp(wb.FullName, fullPath, vbTextCompare) = 0 Then Set ONGEN_OpenWorkbookByPath = wb: Exit Function
    Next wb
    Set ONGEN_OpenWorkbookByPath = Application.Workbooks.Open(fileName:=fullPath, UpdateLinks:=False, ReadOnly:=readOnlyMode, AddToMru:=False)
    openedByUs = True
End Function

' ============================= VERSION STATE =================================

Private Function ONGEN_ReadLibraryVersion(ByVal lib As Workbook) As String
    Dim ws As Worksheet, hdr As Long, cSetting As Long, cValue As Long, r As Long, lastRow As Long
    Set ws = lib.Worksheets(SHEET_CONFIG)
    cSetting = ONGEN_FindHeaderInTopRows(ws, "SETTING", hdr)
    cValue = ONGEN_FindHeaderColumn(ws, "VALUE", hdr)
    If cSetting = 0 Or cValue = 0 Then ONGEN_ReadLibraryVersion = "UNVERSIONED": Exit Function
    lastRow = ws.Cells(ws.rows.count, cSetting).End(xlUp).Row
    For r = hdr + 1 To lastRow
        If StrComp(Trim$(CStr(ws.Cells(r, cSetting).Value2)), "LIBRARY_VERSION", vbTextCompare) = 0 Then
            ONGEN_ReadLibraryVersion = Trim$(CStr(ws.Cells(r, cValue).Value2))
            If Len(ONGEN_ReadLibraryVersion) = 0 Then ONGEN_ReadLibraryVersion = "UNVERSIONED"
            Exit Function
        End If
    Next r
    ONGEN_ReadLibraryVersion = "UNVERSIONED"
End Function

Private Function ONGEN_MasterSignature(ByVal p As String, ByVal version As String) As String
    On Error Resume Next
    ONGEN_MasterSignature = version & "|" & Format$(FileDateTime(p), "yyyy-mm-dd hh:nn:ss")
    On Error GoTo 0
End Function

Private Sub ONGEN_SetWorkbookTextName(ByVal nameText As String, ByVal valueText As String)
    Dim safeText As String
    safeText = Replace(valueText, """", """""")
    On Error Resume Next: ThisWorkbook.names(nameText).Delete: On Error GoTo 0
    ThisWorkbook.names.Add Name:=nameText, RefersTo:="=""" & safeText & """", Visible:=False
End Sub

Private Function ONGEN_GetWorkbookTextName(ByVal nameText As String) As String
    Dim s As String
    On Error Resume Next: s = ThisWorkbook.names(nameText).RefersTo: On Error GoTo 0
    If Len(s) = 0 Then Exit Function
    If Left$(s, 2) = "=""" And Right$(s, 1) = """" Then s = Mid$(s, 3, Len(s) - 3): s = Replace(s, """""", """")
    ONGEN_GetWorkbookTextName = s
End Function

' =========================== WORKBOOK OPEN HOOK ==============================

Private Function ONGEN_InstallWorkbookOpenHook() As Boolean
    Dim vbComp As Object, codeMod As Object, startLine As Long, lineCount As Long, i As Long, txt As String
    On Error GoTo EH
    Set vbComp = ThisWorkbook.VBProject.VBComponents("ThisWorkbook")
    Set codeMod = vbComp.CodeModule
    On Error Resume Next
    startLine = codeMod.ProcStartLine("Workbook_Open", 0)
    lineCount = codeMod.ProcCountLines("Workbook_Open", 0)
    On Error GoTo EH
    If startLine > 0 And lineCount > 0 Then
        For i = startLine To startLine + lineCount - 1
            txt = codeMod.Lines(i, 1)
            If InStr(1, txt, "ONGEN_MasterLibrary_OpenCheck", vbTextCompare) > 0 Then ONGEN_InstallWorkbookOpenHook = True: Exit Function
        Next i
        codeMod.InsertLines startLine + 1, "    ONGEN_MasterLibrary_OpenCheck"
    Else
        codeMod.AddFromString vbCrLf & "Private Sub Workbook_Open()" & vbCrLf & "    ONGEN_MasterLibrary_OpenCheck" & vbCrLf & "End Sub" & vbCrLf
    End If
    ONGEN_InstallWorkbookOpenHook = True
    Exit Function
EH:
    ONGEN_InstallWorkbookOpenHook = False
End Function

' ================================ HELPERS ====================================

Private Function ONGEN_IsPDWorkbook() As Boolean
    ONGEN_IsPDWorkbook = ONGEN_SheetExists(ThisWorkbook, SHEET_PD) And ONGEN_SheetExists(ThisWorkbook, "MAIN")
End Function

Private Function ONGEN_IsSpecificationWorkbook() As Boolean
    ONGEN_IsSpecificationWorkbook = ONGEN_SheetExists(ThisWorkbook, SHEET_SPEC) And ONGEN_SheetExists(ThisWorkbook, "START-HERE")
End Function

Private Function ONGEN_SheetExists(ByVal wb As Workbook, ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next: Set ws = wb.Worksheets(sheetName): On Error GoTo 0
    ONGEN_SheetExists = Not ws Is Nothing
End Function

Private Function ONGEN_FindHeaderInTopRows(ByVal ws As Worksheet, ByVal headerText As String, ByRef headerRow As Long) As Long
    Dim r As Long, c As Long
    For r = 1 To 10
        c = ONGEN_FindHeaderColumn(ws, headerText, r)
        If c > 0 Then headerRow = r: ONGEN_FindHeaderInTopRows = c: Exit Function
    Next r
End Function

Private Function ONGEN_FindHeaderColumn(ByVal ws As Worksheet, ByVal headerText As String, Optional ByVal headerRow As Long = 1) As Long
    Dim lastCol As Long, c As Long
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lastCol
        If StrComp(Trim$(CStr(ws.Cells(headerRow, c).Value2)), Trim$(headerText), vbTextCompare) = 0 Then ONGEN_FindHeaderColumn = c: Exit Function
    Next c
End Function

Private Function ONGEN_FindHeaderByAliases(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal aliases As Variant) As Long
    Dim v As Variant, c As Long
    For Each v In aliases
        c = ONGEN_FindHeaderColumn(ws, CStr(v), headerRow)
        If c > 0 Then ONGEN_FindHeaderByAliases = c: Exit Function
    Next v
End Function

Private Function ONGEN_EnsureHeader(ByVal ws As Worksheet, ByVal headerText As String) As Long
    Dim c As Long, lastCol As Long
    c = ONGEN_FindHeaderColumn(ws, headerText, 1)
    If c > 0 Then ONGEN_EnsureHeader = c: Exit Function
    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    c = lastCol + 1
    If lastCol >= 1 Then On Error Resume Next: ws.Cells(1, lastCol).Copy Destination:=ws.Cells(1, c): On Error GoTo 0
    ws.Cells(1, c).Value = headerText
    ONGEN_EnsureHeader = c
End Function

Private Sub ONGEN_SetByHeader(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal headerText As String, ByVal valueData As Variant)
    ws.Cells(rowNo, ONGEN_EnsureHeader(ws, headerText)).Value = valueData
End Sub

Private Sub ONGEN_SetByExistingHeader(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal headerText As String, ByVal valueData As Variant)
    Dim c As Long: c = ONGEN_FindHeaderColumn(ws, headerText, 1)
    If c > 0 Then ws.Cells(rowNo, c).Value = valueData
End Sub

Private Function ONGEN_GetByAliases(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal aliases As Variant) As Variant
    Dim c As Long: c = ONGEN_FindHeaderByAliases(ws, 1, aliases)
    If c > 0 Then ONGEN_GetByAliases = ws.Cells(rowNo, c).Value Else ONGEN_GetByAliases = vbNullString
End Function

Private Function ONGEN_CellValue(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal colNo As Long) As Variant
    If colNo <= 0 Then ONGEN_CellValue = vbNullString Else ONGEN_CellValue = ws.Cells(rowNo, colNo).Value
End Function

Private Sub ONGEN_ClearRowsBelowHeader(ByVal ws As Worksheet, ByVal headerRow As Long)
    Dim lastRow As Long: lastRow = ONGEN_LastUsedRow(ws)
    If lastRow > headerRow Then ws.rows((headerRow + 1) & ":" & lastRow).ClearContents
End Sub

Private Sub ONGEN_ClearPDManagedData(ByVal ws As Worksheet)
    Dim lastRow As Long, lastCol As Long, c As Long, h As String
    lastRow = ONGEN_LastUsedRow(ws): If lastRow < 2 Then Exit Sub
    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lastCol
        h = UCase$(Trim$(CStr(ws.Cells(1, c).Value2)))
        If h = "CONTROL_FUNCTION_NUMBER" Or h = "CONTROL_FUNCTION_TAG" Or h = "BLOCK" Or h = "NOTE" Or h = "CONVEYOR TYPE" Or _
           h = "INPUT" Or h = "OUTPUT" Or h = "S_IN" Or h = "S_OUT" Or h = "FUNCTION_CODE" Or h = "COMPONENT_CODE" Or _
           h = "DEVICE_VARIANT_CODE" Or h = "VARIANT_CODE" Or h = "COMPONENT_QTY" Or h = "MASTER_REVISION" Or h = "MASTER_ACTIVE" Or _
           Left$(h, 9) = "PART_NUM_" Or Left$(h, 11) = "MANUF_NAME_" Or Left$(h, 9) = "PART_QTY_" Then
            ws.Range(ws.Cells(2, c), ws.Cells(lastRow, c)).ClearContents
        End If
    Next c
End Sub

Private Sub ONGEN_ClearSpecificationManagedData(ByVal ws As Worksheet)
    Dim lastRow As Long, lastCol As Long, c As Long, h As String
    lastRow = ONGEN_LastUsedRow(ws): If lastRow < 2 Then Exit Sub
    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    For c = 1 To lastCol
        h = UCase$(Trim$(CStr(ws.Cells(1, c).Value2)))
        If h = "CODE VARIANT" Or h = "QTY" Or h = "INPUT" Or h = "OUTPUT" Or h = "S_IN" Or h = "S_OUT" Or _
           h = "FUNCTION_CODE" Or h = "FUNCTION_DESCRIPTION" Or h = "DEVICE_VARIANT_CODE" Or h = "COMPONENT_COUNT" Or _
           h = "MASTER_REVISION" Or h = "MASTER_ACTIVE" Or Left$(h, 13) = "MANUFACTURER " Or Left$(h, 12) = "PART NUMBER " Or Left$(h, 9) = "PART QTY " Then
            ws.Range(ws.Cells(2, c), ws.Cells(lastRow, c)).ClearContents
        End If
    Next c
End Sub

Private Sub ONGEN_HideSystemColumns(ByVal ws As Worksheet, ByVal headers As Variant)
    Dim h As Variant, c As Long
    For Each h In headers
        c = ONGEN_FindHeaderColumn(ws, CStr(h), 1)
        If c > 0 Then ws.Columns(c).Hidden = True
    Next h
End Sub


Private Sub ONGEN_WriteHeaderRow(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal startCol As Long, ByVal items As Variant)
    Dim i As Long
    For i = LBound(items) To UBound(items)
        ws.Cells(rowNo, startCol + i - LBound(items)).Value = items(i)
    Next i
End Sub

Private Function ONGEN_LastUsedRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If f Is Nothing Then ONGEN_LastUsedRow = 1 Else ONGEN_LastUsedRow = f.Row
End Function

Private Function ONGEN_NormalizeFolder(ByVal p As String) As String
    p = Replace(Trim$(p), "/", "\")
    Do While Len(p) > 3 And Right$(p, 1) = "\": p = Left$(p, Len(p) - 1): Loop
    ONGEN_NormalizeFolder = p
End Function

Private Function ONGEN_CombinePath(ByVal parentPath As String, ByVal childName As String) As String
    If Right$(parentPath, 1) = "\" Then ONGEN_CombinePath = parentPath & childName Else ONGEN_CombinePath = parentPath & "\" & childName
End Function

Private Function ONGEN_ParentFolder(ByVal p As String) As String
    Dim pos As Long: p = ONGEN_NormalizeFolder(p): pos = InStrRev(p, "\")
    If pos <= 0 Then Exit Function
    If pos = 3 And Mid$(p, 2, 1) = ":" Then ONGEN_ParentFolder = Left$(p, 3) Else ONGEN_ParentFolder = Left$(p, pos - 1)
End Function

Private Function ONGEN_LeafName(ByVal p As String) As String
    Dim pos As Long: p = ONGEN_NormalizeFolder(p): pos = InStrRev(p, "\")
    If pos > 0 Then ONGEN_LeafName = Mid$(p, pos + 1) Else ONGEN_LeafName = p
End Function

Private Function ONGEN_FolderExists(ByVal p As String) As Boolean
    On Error Resume Next: ONGEN_FolderExists = ((GetAttr(p) And vbDirectory) = vbDirectory): On Error GoTo 0
End Function

Private Function ONGEN_FileExists(ByVal p As String) As Boolean
    On Error Resume Next: ONGEN_FileExists = (Len(Dir$(p, vbNormal Or vbReadOnly Or vbHidden Or vbSystem)) > 0): On Error GoTo 0
End Function
