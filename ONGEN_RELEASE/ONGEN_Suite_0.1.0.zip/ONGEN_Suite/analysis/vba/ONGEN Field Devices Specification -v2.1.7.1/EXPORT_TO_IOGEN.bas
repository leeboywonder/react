Attribute VB_Name = "EXPORT_TO_IOGEN"
Option Explicit

Sub Export_IO_Device_List()

    Dim srcWB As Workbook, destWB As Workbook
    Dim srcWS As Worksheet, destWS As Worksheet
    Dim destFile As Variant
    Dim srcLastRow As Long, destLastRow As Long
    Dim srcHeaders As Variant, destHeaders As Variant
    Dim srcColIndex() As Long, destColIndex() As Long
    Dim i As Long, j As Long
    Dim overwriteChoice As VbMsgBoxResult
    Dim foundHeader As Range
    Dim destRow As Long
    Dim existing As Range
    Dim hasExistingData As Boolean
    
    Set srcWB = ThisWorkbook
    
    On Error Resume Next
    Set srcWS = srcWB.Worksheets("EM Designed function")
    On Error GoTo 0
    
    If srcWS Is Nothing Then
        MsgBox "Source sheet 'EM Designed function' not found.", vbCritical
        Exit Sub
    End If
    
    ' Ask user to select destination workbook
    destFile = Application.GetOpenFilename("Excel Files (*.xls*), *.xls*", , "Select Destination Workbook")
    If destFile = False Then Exit Sub
    
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    
    Set destWB = Workbooks.Open(destFile)
    
    On Error Resume Next
    Set destWS = destWB.Worksheets("IO_DEVICE_LIST")
    On Error GoTo 0
    
    If destWS Is Nothing Then
        MsgBox "The worksheet 'IO_DEVICE_LIST' does not exist in the selected workbook.", vbExclamation
        destWB.Close SaveChanges:=False
        Application.DisplayAlerts = True
        Application.ScreenUpdating = True
        Exit Sub
    End If
    
    ' Matching headers
    srcHeaders = Array("Conv.ID", "Items Type", "INPUT", "OUTPUT", "S_IN", "S_OUT")
    destHeaders = Array("Conv.ID", "Items Type", "INPUT", "OUTPUT", "S_IN", "S_OUT")
    
    ' Resize index arrays to match 0-based header arrays
    ReDim srcColIndex(LBound(srcHeaders) To UBound(srcHeaders))
    ReDim destColIndex(LBound(destHeaders) To UBound(destHeaders))
    
    ' Find source headers
    For i = LBound(srcHeaders) To UBound(srcHeaders)
        Set foundHeader = srcWS.rows(1).Find(What:=srcHeaders(i), LookIn:=xlValues, LookAt:=xlWhole, MatchCase:=False)
        If Not foundHeader Is Nothing Then
            srcColIndex(i) = foundHeader.Column
        Else
            MsgBox "Header '" & srcHeaders(i) & "' not found in source sheet.", vbCritical
            destWB.Close SaveChanges:=False
            Application.DisplayAlerts = True
            Application.ScreenUpdating = True
            Exit Sub
        End If
    Next i
    
    ' Find destination headers
    For i = LBound(destHeaders) To UBound(destHeaders)
        Set foundHeader = destWS.rows(1).Find(What:=destHeaders(i), LookIn:=xlValues, LookAt:=xlWhole, MatchCase:=False)
        If Not foundHeader Is Nothing Then
            destColIndex(i) = foundHeader.Column
        Else
            MsgBox "Header '" & destHeaders(i) & "' not found in destination sheet.", vbCritical
            destWB.Close SaveChanges:=False
            Application.DisplayAlerts = True
            Application.ScreenUpdating = True
            Exit Sub
        End If
    Next i
    
    ' Get last source row using first mapped source column
    srcLastRow = srcWS.Cells(srcWS.rows.count, srcColIndex(LBound(srcColIndex))).End(xlUp).Row
    
    ' Get last destination row using first mapped destination column
    destLastRow = destWS.Cells(destWS.rows.count, destColIndex(LBound(destColIndex))).End(xlUp).Row
    
    ' Check whether destination already has data below header
    hasExistingData = (destLastRow > 1)
    
    If hasExistingData Then
        overwriteChoice = MsgBox( _
            "Data already exists in 'IO_DEVICE_LIST'." & vbCrLf & vbCrLf & _
            "Yes = overwrite matching existing rows" & vbCrLf & _
            "No = append only new rows and skip matches" & vbCrLf & _
            "Cancel = stop", _
            vbYesNoCancel + vbQuestion, "Existing Data Found")
        
        If overwriteChoice = vbCancel Then
            destWB.Close SaveChanges:=False
            Application.DisplayAlerts = True
            Application.ScreenUpdating = True
            Exit Sub
        End If
    Else
        overwriteChoice = vbNo
    End If
    
    ' Copy data row by row
    For i = 2 To srcLastRow
        
        ' Skip blank key values in Conv.ID
        If Trim(CStr(srcWS.Cells(i, srcColIndex(LBound(srcColIndex))).Value)) <> "" Then
            
            Set existing = destWS.Columns(destColIndex(LBound(destColIndex))).Find( _
                What:=srcWS.Cells(i, srcColIndex(LBound(srcColIndex))).Value, _
                LookIn:=xlValues, LookAt:=xlWhole, MatchCase:=False)
            
            If Not existing Is Nothing Then
                If overwriteChoice = vbYes Then
                    destRow = existing.Row
                Else
                    GoTo NextRow
                End If
            Else
                destLastRow = destWS.Cells(destWS.rows.count, destColIndex(LBound(destColIndex))).End(xlUp).Row
                destRow = destLastRow + 1
            End If
            
            For j = LBound(srcHeaders) To UBound(srcHeaders)
                destWS.Cells(destRow, destColIndex(j)).Value = srcWS.Cells(i, srcColIndex(j)).Value
            Next j
        End If
        
NextRow:
    Next i
    
    destWB.Save
    destWB.Close SaveChanges:=True
    
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    
    MsgBox "Data export completed successfully!", vbInformation

End Sub

