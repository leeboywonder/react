Attribute VB_Name = "ARRANGE_EE_DATA"
Option Explicit

Sub RearrangeDesignedExport_Fast()

    Dim wsSrc As Worksheet
    Dim wsDest As Worksheet
    Dim wsPricing As Worksheet
    Dim wsVendor As Worksheet
    
    Dim lastRowSrc As Long
    Dim lastColSrc As Long
    Dim lastDestRow As Long
    Dim lastPricingRow As Long
    Dim lastVendorRow As Long
    
    Dim srcData As Variant
    Dim pricingData As Variant
    Dim vendorData As Variant
    Dim outData() As Variant
    
    Dim i As Long, pairIndex As Long, outRow As Long
    Dim maxOutRows As Long
    Dim pairCount As Long
    
    Dim colConvID As Long
    Dim colItemType As Long
    Dim colQty As Long
    
    Dim manufCols() As Long
    Dim partCols() As Long
    
    Dim destColConvID As Long
    Dim destColItemType As Long
    Dim destColQty As Long
    Dim destColManufacturer As Long
    Dim destColPartNumber As Long
    Dim destColDescription As Long
    Dim destColValuationPrice As Long
    Dim destColMaterialsGroup As Long
    Dim destColMaterialsGroupDesc As Long
    Dim destColVendorName As Long
    Dim destColSAPVendorCode As Long
    
    Dim pricingPartCol As Long
    Dim pricingDescCol As Long
    Dim pricingValPriceCol As Long
    Dim pricingMatGroupCol As Long
    Dim pricingMatGroupDescCol As Long
    Dim pricingVendorNameCol As Long
    
    Dim vendorVendorNameCol As Long
    Dim vendorSAPVendorCol As Long
    
    Dim pricingDict As Object
    Dim vendorDict As Object
    
    Dim partKey As String
    Dim vendorKey As String
    Dim pricingArr As Variant
    
    Dim oldCalc As XlCalculation
    Dim oldScreenUpdating As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldDisplayAlerts As Boolean
    
    On Error GoTo SafeExit
    
    oldCalc = Application.Calculation
    oldScreenUpdating = Application.ScreenUpdating
    oldEnableEvents = Application.EnableEvents
    oldDisplayAlerts = Application.DisplayAlerts
    
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "Building EE System Designed BOM..."
    
    
    Dim ComputerName, UserName As String, LDate As String


    'Getting computer name
    ComputerName = Environ("computername")
    LDate = Date
    
    'Getting user name
    UserName = Environ("username")
    
    'Assigning value to cell C14 and E7
    
    Range("C18").Value = UserName
    Range("E7").Value = Date
    
    '-----------------------------
    ' Get sheets safely
    '-----------------------------
    Set wsSrc = GetWorksheetIfExists(ThisWorkbook, "EM Designed function")
    If wsSrc Is Nothing Then
        MsgBox "Sheet not found: EM Designed function", vbCritical
        GoTo SafeExit
    End If
    
    ' Try common spelling variations for pricing sheet
    Set wsPricing = GetWorksheetIfExists(ThisWorkbook, "Princing-data")
    If wsPricing Is Nothing Then Set wsPricing = GetWorksheetIfExists(ThisWorkbook, "Princing-Data")
    If wsPricing Is Nothing Then Set wsPricing = GetWorksheetIfExists(ThisWorkbook, "Pricing-Data")
    If wsPricing Is Nothing Then Set wsPricing = GetWorksheetIfExists(ThisWorkbook, "Pricing-data")
    
    If wsPricing Is Nothing Then
        MsgBox "Pricing sheet not found." & vbCrLf & _
               "Tried: Princing-data, Princing-Data, Pricing-Data, Pricing-data", vbCritical
        GoTo SafeExit
    End If
    
    Set wsVendor = GetWorksheetIfExists(ThisWorkbook, "NEW VENDOR INFO")
    If wsVendor Is Nothing Then
        MsgBox "Sheet not found: NEW VENDOR INFO", vbCritical
        GoTo SafeExit
    End If
    
    Set wsDest = GetWorksheetIfExists(ThisWorkbook, "EE System Designed BOM")
    If wsDest Is Nothing Then
        Set wsDest = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        wsDest.Name = "EE System Designed BOM"
    End If
    
    lastRowSrc = wsSrc.Cells(wsSrc.rows.count, 1).End(xlUp).Row
    lastColSrc = wsSrc.Cells(1, wsSrc.Columns.count).End(xlToLeft).Column
    
    If lastRowSrc < 2 Then
        MsgBox "No source data found in 'EM Designed function'.", vbExclamation
        GoTo SafeExit
    End If
    
    srcData = wsSrc.Range(wsSrc.Cells(1, 1), wsSrc.Cells(lastRowSrc, lastColSrc)).Value2
    
    colConvID = FindHeaderInArray(srcData, Array("Conv.ID", "Conv ID", "CONV_ID", "CONVEYOR ID", "SIS_Sequence"))
    colItemType = FindHeaderInArray(srcData, Array("Items Type", "Item Type", "ITEMS TYPE", "TYPE"))
    colQty = FindHeaderInArray(srcData, Array("QTY", "Qty", "QUANTITY"))
    
    If colConvID = 0 Or colItemType = 0 Or colQty = 0 Then
        MsgBox "Missing required headers in 'EM Designed function': Conv.ID, Items Type, or QTY", vbCritical
        GoTo SafeExit
    End If
    
    '------------------------------------------
    ' Detect all Manufacturer / Part Number pairs dynamically
    '------------------------------------------
    DetectManufacturerPartPairs srcData, manufCols, partCols, pairCount
    
    If pairCount = 0 Then
        MsgBox "No Manufacturer / Part Number pairs were found in 'EM Designed function'.", vbExclamation
        GoTo SafeExit
    End If
    
    destColConvID = EnsureHeader(wsDest, "Conv.ID")
    destColItemType = EnsureHeader(wsDest, "Items Type")
    destColQty = EnsureHeader(wsDest, "QTY")
    destColManufacturer = EnsureHeader(wsDest, "Manufacturer")
    destColPartNumber = EnsureHeader(wsDest, "Part Number")
    destColDescription = EnsureHeader(wsDest, "Description")
    destColValuationPrice = EnsureHeader(wsDest, "Valuation Price")
    destColMaterialsGroup = EnsureHeader(wsDest, "Materials Group")
    destColMaterialsGroupDesc = EnsureHeader(wsDest, "Materials Group Desc.")
    destColVendorName = EnsureHeader(wsDest, "Vendor Name")
    destColSAPVendorCode = EnsureHeader(wsDest, "SAP Vendor Code")
    
    lastDestRow = wsDest.Cells(wsDest.rows.count, 1).End(xlUp).Row
    If lastDestRow < 2 Then lastDestRow = 2
    
    ClearColumnData wsDest, destColConvID, 2, lastDestRow
    ClearColumnData wsDest, destColItemType, 2, lastDestRow
    ClearColumnData wsDest, destColQty, 2, lastDestRow
    ClearColumnData wsDest, destColManufacturer, 2, lastDestRow
    ClearColumnData wsDest, destColPartNumber, 2, lastDestRow
    ClearColumnData wsDest, destColDescription, 2, lastDestRow
    ClearColumnData wsDest, destColValuationPrice, 2, lastDestRow
    ClearColumnData wsDest, destColMaterialsGroup, 2, lastDestRow
    ClearColumnData wsDest, destColMaterialsGroupDesc, 2, lastDestRow
    ClearColumnData wsDest, destColVendorName, 2, lastDestRow
    ClearColumnData wsDest, destColSAPVendorCode, 2, lastDestRow
    
    lastPricingRow = wsPricing.Cells(wsPricing.rows.count, 1).End(xlUp).Row
    If lastPricingRow < 2 Then
        MsgBox "No data found in pricing sheet.", vbExclamation
        GoTo SafeExit
    End If
    
    pricingData = wsPricing.Range( _
        wsPricing.Cells(1, 1), _
        wsPricing.Cells(lastPricingRow, wsPricing.Cells(1, wsPricing.Columns.count).End(xlToLeft).Column) _
    ).Value2
    
    pricingPartCol = FindHeaderInArray(pricingData, Array("Part Number", "Part number", "PART NUMBER", "PART_NUM", "Material", "Material Number"))
    pricingDescCol = FindHeaderInArray(pricingData, Array("Description", "DESCRIPTION"))
    pricingValPriceCol = FindHeaderInArray(pricingData, Array("Valuation Price", "VALUATION PRICE"))
    pricingMatGroupCol = FindHeaderInArray(pricingData, Array("Materials Group", "Material Group", "MATERIALS GROUP"))
    pricingMatGroupDescCol = FindHeaderInArray(pricingData, Array( _
        "Materials Group Desc.", _
        "Materials Group Desc", _
        "Material Group Desc.", _
        "Material Group Desc", _
        "Materials Group Description", _
        "Material Group Description", _
        "MATERIALS GROUP DESC", _
        "MATERIAL GROUP DESC"))
    pricingVendorNameCol = FindHeaderInArray(pricingData, Array( _
        "Vendor Name", _
        "VENDOR NAME", _
        "Provider", _
        "PROVIDER", _
        "Vendor", _
        "VENDOR"))
    
    If pricingPartCol = 0 Then
        MsgBox "Could not find 'Part Number' in pricing sheet.", vbCritical
        GoTo SafeExit
    End If
    
    If pricingVendorNameCol = 0 Then
        MsgBox "Could not find 'Vendor Name' in pricing sheet.", vbCritical
        GoTo SafeExit
    End If
    
    Set pricingDict = CreateObject("Scripting.Dictionary")
    pricingDict.CompareMode = vbTextCompare
    
    For i = 2 To UBound(pricingData, 1)
        partKey = NormalizeKey(GetArrayValue(pricingData, i, pricingPartCol))
        If Len(partKey) > 0 Then
            If Not pricingDict.Exists(partKey) Then
                pricingDict.Add partKey, Array( _
                    GetArrayValue(pricingData, i, pricingDescCol), _
                    GetArrayValue(pricingData, i, pricingValPriceCol), _
                    GetArrayValue(pricingData, i, pricingMatGroupCol), _
                    GetArrayValue(pricingData, i, pricingMatGroupDescCol), _
                    GetArrayValue(pricingData, i, pricingVendorNameCol))
            End If
        End If
    Next i
    
    lastVendorRow = wsVendor.Cells(wsVendor.rows.count, 1).End(xlUp).Row
    If lastVendorRow < 2 Then
        MsgBox "No data found in 'NEW VENDOR INFO'.", vbExclamation
        GoTo SafeExit
    End If
    
    vendorData = wsVendor.Range( _
        wsVendor.Cells(1, 1), _
        wsVendor.Cells(lastVendorRow, wsVendor.Cells(1, wsVendor.Columns.count).End(xlToLeft).Column) _
    ).Value2
    
    vendorVendorNameCol = FindHeaderInArray(vendorData, Array( _
        "Vendor Name", _
        "VENDOR NAME", _
        "Provider", _
        "PROVIDER", _
        "Vendor", _
        "VENDOR"))
    vendorSAPVendorCol = FindHeaderInArray(vendorData, Array("SAP Vendor Code", "SAP VENDOR CODE", "Vendor Code", "VENDOR CODE"))
    
    If vendorVendorNameCol = 0 Or vendorSAPVendorCol = 0 Then
        MsgBox "Could not find 'Vendor Name' or 'SAP Vendor Code' in 'NEW VENDOR INFO'.", vbCritical
        GoTo SafeExit
    End If
    
    Set vendorDict = CreateObject("Scripting.Dictionary")
    vendorDict.CompareMode = vbTextCompare
    
    For i = 2 To UBound(vendorData, 1)
        vendorKey = NormalizeKey(GetArrayValue(vendorData, i, vendorVendorNameCol))
        If Len(vendorKey) > 0 Then
            If Not vendorDict.Exists(vendorKey) Then
                vendorDict.Add vendorKey, GetArrayValue(vendorData, i, vendorSAPVendorCol)
            End If
        End If
    Next i
    
    maxOutRows = (UBound(srcData, 1) - 1) * pairCount
    If maxOutRows < 1 Then maxOutRows = 1
    
    ReDim outData(1 To maxOutRows, 1 To 11)
    outRow = 0
    
    For i = 2 To UBound(srcData, 1)
        For pairIndex = 1 To pairCount
            If manufCols(pairIndex) > 0 Or partCols(pairIndex) > 0 Then
                If Trim$(CStr(GetArrayValue(srcData, i, manufCols(pairIndex)))) <> "" Or _
                   Trim$(CStr(GetArrayValue(srcData, i, partCols(pairIndex)))) <> "" Then
                    
                    outRow = outRow + 1
                    
                    outData(outRow, 1) = GetArrayValue(srcData, i, colConvID)
                    outData(outRow, 2) = GetArrayValue(srcData, i, colItemType)
                    outData(outRow, 3) = GetArrayValue(srcData, i, colQty)
                    outData(outRow, 4) = GetArrayValue(srcData, i, manufCols(pairIndex))
                    outData(outRow, 5) = GetArrayValue(srcData, i, partCols(pairIndex))
                    
                    partKey = NormalizeKey(outData(outRow, 5))
                    
                    If Len(partKey) > 0 Then
                        If pricingDict.Exists(partKey) Then
                            pricingArr = pricingDict(partKey)
                            outData(outRow, 6) = pricingArr(0)
                            outData(outRow, 7) = pricingArr(1)
                            outData(outRow, 8) = pricingArr(2)
                            outData(outRow, 9) = pricingArr(3)
                            outData(outRow, 10) = pricingArr(4)
                            
                            vendorKey = NormalizeKey(pricingArr(4))
                            If Len(vendorKey) > 0 Then
                                If vendorDict.Exists(vendorKey) Then
                                    outData(outRow, 11) = vendorDict(vendorKey)
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        Next pairIndex
    Next i
    
    If outRow > 0 Then
        WriteOutputColumn wsDest, destColConvID, outData, outRow, 1
        WriteOutputColumn wsDest, destColItemType, outData, outRow, 2
        WriteOutputColumn wsDest, destColQty, outData, outRow, 3
        WriteOutputColumn wsDest, destColManufacturer, outData, outRow, 4
        WriteOutputColumn wsDest, destColPartNumber, outData, outRow, 5
        WriteOutputColumn wsDest, destColDescription, outData, outRow, 6
        WriteOutputColumn wsDest, destColValuationPrice, outData, outRow, 7
        WriteOutputColumn wsDest, destColMaterialsGroup, outData, outRow, 8
        WriteOutputColumn wsDest, destColMaterialsGroupDesc, outData, outRow, 9
        WriteOutputColumn wsDest, destColVendorName, outData, outRow, 10
        WriteOutputColumn wsDest, destColSAPVendorCode, outData, outRow, 11
    End If
    
    MsgBox "EE System Designed BOM completed successfully." & vbCrLf & _
           "Detected " & pairCount & " Manufacturer / Part Number pair(s).", vbInformation

SafeExit:
    Application.ScreenUpdating = oldScreenUpdating
    Application.EnableEvents = oldEnableEvents
    Application.DisplayAlerts = oldDisplayAlerts
    Application.Calculation = oldCalc
    Application.StatusBar = False
    
    If Err.Number <> 0 Then
        MsgBox "Error: " & Err.Description, vbCritical
    End If
End Sub

Private Sub DetectManufacturerPartPairs(ByRef dataArr As Variant, _
                                        ByRef manufCols() As Long, _
                                        ByRef partCols() As Long, _
                                        ByRef pairCount As Long)
    
    Dim headerMap As Object
    Dim c As Long
    Dim hdrNorm As String
    Dim n As Long
    Dim maxPair As Long
    
    Set headerMap = CreateObject("Scripting.Dictionary")
    headerMap.CompareMode = vbTextCompare
    
    maxPair = 0
    
    For c = LBound(dataArr, 2) To UBound(dataArr, 2)
        hdrNorm = NormalizeHeader(CStr(dataArr(1, c)))
        
        n = ExtractTrailingNumber(hdrNorm)
        If n > 0 Then
            If IsManufacturerHeader(hdrNorm) Then
                If Not headerMap.Exists("M" & n) Then headerMap.Add "M" & n, c
                If n > maxPair Then maxPair = n
            ElseIf IsPartNumberHeader(hdrNorm) Then
                If Not headerMap.Exists("P" & n) Then headerMap.Add "P" & n, c
                If n > maxPair Then maxPair = n
            End If
        End If
    Next c
    
    If maxPair = 0 Then
        pairCount = 0
        Exit Sub
    End If
    
    ReDim manufCols(1 To maxPair)
    ReDim partCols(1 To maxPair)
    
    pairCount = 0
    
    For n = 1 To maxPair
        If headerMap.Exists("M" & n) Or headerMap.Exists("P" & n) Then
            pairCount = pairCount + 1
            
            If headerMap.Exists("M" & n) Then
                manufCols(pairCount) = CLng(headerMap("M" & n))
            Else
                manufCols(pairCount) = 0
            End If
            
            If headerMap.Exists("P" & n) Then
                partCols(pairCount) = CLng(headerMap("P" & n))
            Else
                partCols(pairCount) = 0
            End If
        End If
    Next n
    
    If pairCount = 0 Then Exit Sub
    
    ReDim Preserve manufCols(1 To pairCount)
    ReDim Preserve partCols(1 To pairCount)
End Sub

Private Function IsManufacturerHeader(ByVal normHeader As String) As Boolean
    IsManufacturerHeader = _
           (Left$(normHeader, 12) = "MANUFACTURER" Or _
            Left$(normHeader, 9) = "MANUFNAME" Or _
            Left$(normHeader, 5) = "MANUF")
End Function

Private Function IsPartNumberHeader(ByVal normHeader As String) As Boolean
    IsPartNumberHeader = _
           (Left$(normHeader, 10) = "PARTNUMBER" Or _
            Left$(normHeader, 7) = "PARTNUM" Or _
            Left$(normHeader, 4) = "PART")
End Function

Private Function ExtractTrailingNumber(ByVal txt As String) As Long
    Dim i As Long
    Dim digits As String
    
    digits = ""
    
    For i = Len(txt) To 1 Step -1
        If Mid$(txt, i, 1) Like "#" Then
            digits = Mid$(txt, i, 1) & digits
        Else
            Exit For
        End If
    Next i
    
    If Len(digits) > 0 Then
        ExtractTrailingNumber = CLng(digits)
    Else
        ExtractTrailingNumber = 0
    End If
End Function

Private Function GetWorksheetIfExists(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set GetWorksheetIfExists = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Sub WriteOutputColumn(ByVal ws As Worksheet, ByVal destCol As Long, ByRef srcData As Variant, ByVal rowCount As Long, ByVal srcColIndex As Long)
    Dim arr() As Variant
    Dim r As Long
    
    If destCol <= 0 Or rowCount <= 0 Then Exit Sub
    
    ReDim arr(1 To rowCount, 1 To 1)
    
    For r = 1 To rowCount
        arr(r, 1) = srcData(r, srcColIndex)
    Next r
    
    ws.Range(ws.Cells(2, destCol), ws.Cells(rowCount + 1, destCol)).Value = arr
End Sub

Private Sub ClearColumnData(ByVal ws As Worksheet, ByVal colNum As Long, ByVal firstRow As Long, ByVal lastRow As Long)
    If colNum > 0 And lastRow >= firstRow Then
        ws.Range(ws.Cells(firstRow, colNum), ws.Cells(lastRow, colNum)).ClearContents
    End If
End Sub

Private Function FindHeaderInArray(ByRef dataArr As Variant, ByVal headerNames As Variant) As Long
    Dim c As Long, i As Long
    Dim testHeader As String
    
    On Error GoTo Fail
    
    For c = LBound(dataArr, 2) To UBound(dataArr, 2)
        testHeader = NormalizeHeader(dataArr(1, c))
        For i = LBound(headerNames) To UBound(headerNames)
            If testHeader = NormalizeHeader(CStr(headerNames(i))) Then
                FindHeaderInArray = c
                Exit Function
            End If
        Next i
    Next c
    
Fail:
    FindHeaderInArray = 0
End Function

Private Function EnsureHeader(ByVal ws As Worksheet, ByVal headerText As String) As Long
    Dim existingCol As Long
    Dim lastCol As Long
    
    existingCol = FindHeaderAny(ws, 1, Array(headerText))
    If existingCol > 0 Then
        EnsureHeader = existingCol
        Exit Function
    End If
    
    lastCol = ws.Cells(1, ws.Columns.count).End(xlToLeft).Column
    If lastCol < 1 Then lastCol = 1
    
    EnsureHeader = lastCol + 1
    ws.Cells(1, EnsureHeader).Value = headerText
End Function

Private Function FindHeaderAny(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal headerNames As Variant) As Long
    Dim lastCol As Long
    Dim c As Long, i As Long
    Dim testHeader As String
    
    lastCol = ws.Cells(headerRow, ws.Columns.count).End(xlToLeft).Column
    
    For c = 1 To lastCol
        testHeader = NormalizeHeader(ws.Cells(headerRow, c).Value)
        For i = LBound(headerNames) To UBound(headerNames)
            If testHeader = NormalizeHeader(CStr(headerNames(i))) Then
                FindHeaderAny = c
                Exit Function
            End If
        Next i
    Next c
    
    FindHeaderAny = 0
End Function

Private Function NormalizeHeader(ByVal txt As String) As String
    txt = Trim$(CStr(txt))
    txt = Replace(txt, vbCr, " ")
    txt = Replace(txt, vbLf, " ")
    txt = Replace(txt, ".", "")
    txt = Replace(txt, "_", "")
    txt = Replace(txt, "-", "")
    
    Do While InStr(txt, "  ") > 0
        txt = Replace(txt, "  ", " ")
    Loop
    
    txt = Replace(txt, " ", "")
    
    NormalizeHeader = UCase$(txt)
End Function

Private Function NormalizeKey(ByVal v As Variant) As String
    Dim txt As String
    
    txt = Trim$(CStr(v))
    txt = Replace(txt, vbCr, "")
    txt = Replace(txt, vbLf, "")
    txt = Replace(txt, Chr(160), " ")
    
    Do While InStr(txt, "  ") > 0
        txt = Replace(txt, "  ", " ")
    Loop
    
    NormalizeKey = UCase$(txt)
End Function

Private Function GetArrayValue(ByRef dataArr As Variant, ByVal rowNum As Long, ByVal colNum As Long) As Variant
    If colNum > 0 Then
        GetArrayValue = dataArr(rowNum, colNum)
    Else
        GetArrayValue = ""
    End If
End Function

