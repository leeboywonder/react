Attribute VB_Name = "modONGEN_SpecMaintenance"
Option Explicit

'===============================================================================
' ONGEN Field Devices Specification - Dynamic Performance / Maintenance Support
' Version: 2.1.4
' Author: Lee Pierre
'
' This module has NO fixed 5,000-row capacity. It works to Excel's worksheet limit
' and uses last-row detection from actual data.
'===============================================================================

Private Const XL_CALC_MANUAL As Long = -4135
Private Const XL_CALC_AUTOMATIC As Long = -4105

Private mFastMode As Boolean
Private mPrevScreenUpdating As Boolean
Private mPrevEnableEvents As Boolean
Private mPrevDisplayAlerts As Boolean
Private mPrevCalculation As Long
Private mPrevStatusBar As Variant

Public Sub ONGEN_SPEC_FastBegin(Optional ByVal statusText As String = "ONGEN processing...")
    If mFastMode Then Exit Sub

    With Application
        mPrevScreenUpdating = .ScreenUpdating
        mPrevEnableEvents = .EnableEvents
        mPrevDisplayAlerts = .DisplayAlerts
        mPrevCalculation = .Calculation
        mPrevStatusBar = .StatusBar
        .ScreenUpdating = False
        .EnableEvents = False
        .DisplayAlerts = False
        .Calculation = XL_CALC_MANUAL
        .StatusBar = statusText
    End With

    mFastMode = True
End Sub

Public Sub ONGEN_SPEC_FastEnd(Optional ByVal recalcOutputs As Boolean = True)
    On Error Resume Next

    If recalcOutputs Then
        ThisWorkbook.Worksheets("Pricing-Data").Calculate
        ThisWorkbook.Worksheets("EE System Designed BOM").Calculate
        ThisWorkbook.Worksheets("SAP POR Order List").Calculate
    End If

    If mFastMode Then
        With Application
            .ScreenUpdating = mPrevScreenUpdating
            .EnableEvents = mPrevEnableEvents
            .DisplayAlerts = mPrevDisplayAlerts
            .Calculation = mPrevCalculation
            .StatusBar = mPrevStatusBar
        End With
    Else
        Application.ScreenUpdating = True
        Application.EnableEvents = True
        Application.DisplayAlerts = True
        Application.Calculation = XL_CALC_AUTOMATIC
        Application.StatusBar = False
    End If

    mFastMode = False
    On Error GoTo 0
End Sub

Public Sub ONGEN_SPEC_RecalculateOutputs()
    On Error GoTo Failed
    ONGEN_SPEC_FastBegin "Recalculating Specification outputs..."
    Application.CalculateFull
    ONGEN_SPEC_FastEnd False
    Exit Sub
Failed:
    Dim errText As String
    errText = Err.Description
    ONGEN_SPEC_FastEnd False
    MsgBox "Specification recalculation did not complete." & vbCrLf & errText, vbExclamation, "ONGEN Specification"
End Sub

Public Sub ONGEN_SPEC_ResetExcelState()
    On Error Resume Next
    With Application
        .ScreenUpdating = True
        .EnableEvents = True
        .DisplayAlerts = True
        .Calculation = XL_CALC_AUTOMATIC
        .StatusBar = False
    End With
    On Error GoTo 0
    MsgBox "Excel state restored. Calculation is Automatic.", vbInformation, "ONGEN Specification"
End Sub

Public Sub ONGEN_SPEC_RemoveAllHyperlinks()
    Dim ws As Worksheet
    Dim n As Long

    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        n = n + ws.Hyperlinks.count
        ws.Hyperlinks.Delete
    Next ws
    On Error GoTo 0

    MsgBox Format$(n, "#,##0") & " hyperlink(s) removed.", vbInformation, "ONGEN Specification"
End Sub

Public Sub ONGEN_SPEC_RefreshDynamicVariantName()
    Dim f As String

    f = "='VARIANT LIST'!$A$2:INDEX('VARIANT LIST'!$A:$A," & _
        "MAX(2,IFERROR(LOOKUP(2,1/('VARIANT LIST'!$A:$A<>""""),ROW('VARIANT LIST'!$A:$A)),2)))"

    On Error Resume Next
    ThisWorkbook.names("ONGEN_VARIANT_CODES").Delete
    On Error GoTo 0

    ThisWorkbook.names.Add Name:="ONGEN_VARIANT_CODES", RefersTo:=f
End Sub

Public Sub ONGEN_SPEC_PerformanceAudit()
    Dim ws As Worksheet
    Dim msg As String
    Dim usedRows As Long
    Dim maxRows As Long
    Dim hyperlinkCount As Long
    Dim calcModeText As String

    maxRows = ThisWorkbook.Worksheets("SAP POR Order List").rows.count

    msg = "ONGEN Specification V2.1.4 Audit" & vbCrLf & String(44, "-") & vbCrLf

    For Each ws In ThisWorkbook.Worksheets
        usedRows = ONGEN_SPEC_LastUsedValueRow(ws)
        hyperlinkCount = hyperlinkCount + ws.Hyperlinks.count
        msg = msg & ws.Name & ": " & Format$(usedRows, "#,##0") & " used row(s)" & vbCrLf
    Next ws

    calcModeText = IIf(Application.Calculation = XL_CALC_AUTOMATIC, "Automatic", "Not Automatic")

    msg = msg & vbCrLf & _
          "Worksheet row capacity: " & Format$(maxRows, "#,##0") & vbCrLf & _
          "Calculation mode: " & calcModeText & vbCrLf & _
          "Active hyperlinks: " & Format$(hyperlinkCount, "#,##0") & vbCrLf & _
          "Dynamic variant name: " & IIf(ONGEN_SPEC_NameExists("ONGEN_VARIANT_CODES"), "Present", "Missing")

    MsgBox msg, vbInformation, "ONGEN Specification"
End Sub

Private Function ONGEN_SPEC_LastUsedValueRow(ByVal ws As Worksheet) As Long
    Dim lastCell As Range

    On Error Resume Next
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlValues, _
                                 LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                                 MatchCase:=False)
    On Error GoTo 0

    If lastCell Is Nothing Then
        ONGEN_SPEC_LastUsedValueRow = 1
    Else
        ONGEN_SPEC_LastUsedValueRow = lastCell.Row
    End If
End Function

Private Function ONGEN_SPEC_NameExists(ByVal nameText As String) As Boolean
    Dim nm As Name
    On Error Resume Next
    Set nm = ThisWorkbook.names(nameText)
    ONGEN_SPEC_NameExists = Not nm Is Nothing
    On Error GoTo 0
End Function
