Attribute VB_Name = "Import_EE_data"
Sub Data_Import_EE_BOM()

Dim vFile As Variant
Dim wbCopyTo As Workbook
Dim wsCopyTo As Worksheet
Dim wbCopyFrom As Workbook
Dim wsCopyFrom As Worksheet

Set wbCopyTo = ActiveWorkbook
Set wsCopyTo = ActiveSheet



Dim ComputerName, UserName As String, LDate As String


'Getting computer name
ComputerName = Environ("computername")
LDate = Date

'Getting user name
UserName = Environ("username")

'Assigning value to cell C14 and E7

Range("C18").Value = UserName
Range("E7").Value = Date

    '-------------------------------------------------------------
    'Open file with data to be copied
    
    vFile = Application.GetOpenFilename("Excel Files (*.xl*)," & _
   "*.xl*", 1, "Select Excel File", "Open", False)
   
   'get the user File location for the field devices

   Range("C19").Value = vFile

   
    
   'formula to unhide and remove filters columns and rows
     Columns.EntireColumn.Hidden = False
     rows.EntireRow.Hidden = False
     ActiveSheet.AutoFilterMode = False
     
     
     
    'If Cancel then Exit
    If TypeName(vFile) = "Boolean" Then
        Exit Sub
    
    Else
    Set wbCopyFrom = Workbooks.Open(vFile)
    Set wsCopyFrom = wbCopyFrom.Worksheets(1)
    
    End If
    
    '--------------------------------------------------------------
         Application.ScreenUpdating = False
    '--------------------------------------------------------------
    'Copy Range
    'formula to unhide and remove filters columns and rows
     Columns.EntireColumn.Hidden = False
     'Rows.EntireRow.Hidden = False
     'ActiveSheet.AutoFilterMode = False
     
       
    wbCopyFrom.Sheets("Definition").Range("A:AI").Copy
    
    'wbCopyFrom.Sheets("Sheet1").range("A").Copy
    
    wbCopyTo.Sheets("Designed Export").Range("A:AI").PasteSpecial xlPasteValues, _
            Operation:=xlNone, SkipBlanks:=False, Transpose:=False
    
    'Close file that was opened
    wbCopyFrom.Close SaveChanges:=False
    
    MsgBox ("Design Definition import complete")

End Sub

