Attribute VB_Name = "ProgressForm"
Attribute VB_Base = "0{02A011EB-1B64-458C-B609-9BC7E456B4DF}{C72C82AF-4A7A-4386-8C07-5B350D3C5E98}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit

Public CancelPressed As Boolean

Private Sub BtnCancel_Click()
    CancelPressed = True
    Me.LabelStatus.caption = "Cancelling..."
End Sub

Public Sub UpdateProgress(ByVal current As Long, ByVal total As Long, Optional ByVal msg As String)
    Dim pct As Double
    If total = 0 Then Exit Sub
    pct = current / total
    Me.LabelProgress.Width = pct * Me.FrameProgress.Width
    Me.LabelPercent.caption = Format(pct, "0%")
    Me.LabelStatus.caption = msg
    DoEvents
End Sub

