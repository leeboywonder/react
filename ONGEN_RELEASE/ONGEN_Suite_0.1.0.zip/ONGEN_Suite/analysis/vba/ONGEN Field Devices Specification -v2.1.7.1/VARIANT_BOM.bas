Attribute VB_Name = "VARIANT_BOM"
Option Explicit

Sub MapVariantData()
    Dim wsSource As Worksheet, wsVariant As Worksheet
    Dim srcLastRow As Long, varLastRow As Long
    Dim srcVarCol As Long, varCodeCol As Long
    Dim headers As Variant, h As Variant
    Dim srcColDict As Object, varColDict As Object
    Dim i As Long, srcRow As Long, varRow As Long
    Dim variantCode As String, response As VbMsgBoxResult
    Dim destCell As Range, found As Range
    Dim progressForm As progressForm
    
    ' Initialize Progress Form
    Set progressForm = New progressForm
    progressForm.Show
    
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    
    '------------------------------------
    ' SETUP SHEETS
    '------------------------------------
    On Error Resume Next
    Set wsSource = ThisWorkbook.Sheets("EM Designed function")
    Set wsVariant = ThisWorkbook.Sheets("VARIANT LIST")
    On Error GoTo 0
    
    If wsSource Is Nothing Or wsVariant Is Nothing Then
        MsgBox "Missing sheets: 'EM Designed function' or 'VARIANT LIST'.", vbCritical
        Unload progressForm
        Exit Sub
    End If
    
    '------------------------------------
    ' DEFINE HEADERS
    '------------------------------------
    headers = Array("QTY", _
                    "Manufacturer 1", "Part Number 1", _
                    "Manufacturer 2", "Part Number 2", _
                    "Manufacturer 3", "Part Number 3", _
                    "Manufacturer 4", "Part Number 4", _
                    "Manufacturer 5", "Part Number 5", _
                    "Manufacturer 6", "Part Number 6", _
                    "Manufacturer 7", "Part Number 7", _
                    "Manufacturer 8", "Part Number 8", _
                    "Manufacturer 9", "Part Number 9", _
                    "INPUT", "OUTPUT", _
                    "S_IN", "S_OUT")
    
    '------------------------------------
    ' MAP HEADER LOCATIONS
    '------------------------------------
    Set srcColDict = CreateObject("Scripting.Dictionary")
    Set varColDict = CreateObject("Scripting.Dictionary")
    
    For i = 1 To wsSource.Cells(1, wsSource.Columns.count).End(xlToLeft).Column
        srcColDict(wsSource.Cells(1, i).Value) = i
    Next i
    
    For i = 1 To wsVariant.Cells(1, wsVariant.Columns.count).End(xlToLeft).Column
        varColDict(wsVariant.Cells(1, i).Value) = i
    Next i
    
    ' Validate required headers
    If Not srcColDict.Exists("VARIANT") Then
        MsgBox "Missing 'VARIANT' header in 'EM Designed function'.", vbCritical
        Unload progressForm
        Exit Sub
    End If
    
    If Not varColDict.Exists("code variant") Then
        MsgBox "Missing 'code variant' header in 'VARIANT LIST'.", vbCritical
        Unload progressForm
        Exit Sub
    End If
    
    srcVarCol = srcColDict("VARIANT")
    varCodeCol = varColDict("code variant")
    
    srcLastRow = wsSource.Cells(wsSource.rows.count, 1).End(xlUp).Row
    varLastRow = wsVariant.Cells(wsVariant.rows.count, 1).End(xlUp).Row
    
    '------------------------------------
    ' MAIN LOOP
    '------------------------------------
    For srcRow = 2 To srcLastRow
        If progressForm.CancelPressed Then Exit For
        
        If Trim(wsSource.Cells(srcRow, 1).Value) <> "" Then
            variantCode = Trim(wsSource.Cells(srcRow, srcVarCol).Value)
            
            progressForm.UpdateProgress srcRow, srcLastRow, _
                "Row " & srcRow & " of " & srcLastRow & _
                " | Variant: " & IIf(variantCode = "", "(none)", variantCode)
            
            ' Missing variant
            If variantCode = "" Then
                response = MsgBox("Row " & srcRow & ": Variant is empty for Item '" & wsSource.Cells(srcRow, 1).Value & "'. " & _
                                  "Do you want to add a variant (Yes) or skip (No)?", vbYesNoCancel + vbQuestion, "Missing Variant")
                If response = vbYes Then
                    variantCode = InputBox("Enter variant code for row " & srcRow & ":", "Add Variant")
                    wsSource.Cells(srcRow, srcVarCol).Value = variantCode
                ElseIf response = vbCancel Then
                    Exit For
                Else
                    GoTo SkipNext
                End If
            End If
            
            ' Find variant in VARIANT LIST
            Set found = wsVariant.Columns(varCodeCol).Find(What:=variantCode, LookIn:=xlValues, LookAt:=xlWhole)
            
            If Not found Is Nothing Then
                varRow = found.Row
                For Each h In headers
                    If varColDict.Exists(h) And srcColDict.Exists(h) Then
                        Set destCell = wsSource.Cells(srcRow, srcColDict(h))
                        
                        If Trim(destCell.Value) <> "" Then
                            response = MsgBox("Row " & srcRow & " (" & h & "): Data already exists. Overwrite?", vbYesNoCancel + vbQuestion, "Overwrite Confirmation")
                            If response = vbYes Then
                                destCell.Value = wsVariant.Cells(varRow, varColDict(h)).Value
                            ElseIf response = vbCancel Then
                                Exit For
                            End If
                        Else
                            destCell.Value = wsVariant.Cells(varRow, varColDict(h)).Value
                        End If
                    End If
                Next h
            Else
                MsgBox "Variant '" & variantCode & "' not found in VARIANT LIST.", vbExclamation
            End If
        End If
SkipNext:
    Next srcRow
    
    Unload progressForm
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    
    MsgBox "Variant mapping complete!", vbInformation
End Sub


