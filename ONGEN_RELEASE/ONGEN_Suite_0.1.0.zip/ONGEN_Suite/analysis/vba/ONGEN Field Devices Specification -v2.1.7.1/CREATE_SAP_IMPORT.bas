Attribute VB_Name = "CREATE_SAP_IMPORT"
Option Explicit

'-------------------------------
' Helper: Parse text quantities like "2 EA"
'-------------------------------
Private Function ParseQty(ByVal v As Variant) As Double
    Dim s As String, i As Long, ch As String, out As String
    s = CStr(v)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If (ch >= "0" And ch <= "9") Or ch = "." Or ch = "-" Then out = out & ch
    Next i
    If out = "" Or out = "-" Or out = "." Or out = "-." Then
        ParseQty = 0
    Else
        ParseQty = CDbl(out)
    End If
End Function

'-------------------------------
' Helper: Get sheet by two possible names
'-------------------------------
Private Function GetSheet(ByVal wb As Workbook, ByVal name1 As String, ByVal name2 As String) As Worksheet
    On Error Resume Next
    Set GetSheet = wb.Sheets(name1)
    If GetSheet Is Nothing Then Set GetSheet = wb.Sheets(name2)
    On Error GoTo 0
End Function

'-------------------------------
' Helper: Check if sheet exists
'-------------------------------
Private Function SheetExists(ByVal wb As Workbook, ByVal sheetName As String) As Boolean
    On Error Resume Next
    SheetExists = Not wb.Sheets(sheetName) Is Nothing
    On Error GoTo 0
End Function

'-------------------------------
' MAIN MACRO
'-------------------------------
Public Sub CreateVendorSheets_FromBOM_Full()
    Dim wb As Workbook: Set wb = ThisWorkbook
    Dim wsBOM As Worksheet, wsStart As Worksheet
    Dim h As Object: Set h = CreateObject("Scripting.Dictionary")
    Dim vendorDict As Object, specialDict As Object
    Dim headerRow As Long: headerRow = 1
    Dim lastRow As Long, lastCol As Long, r As Long, c As Long

    ' ===== Get sheets =====
    Set wsBOM = wb.Sheets("EE System Designed BOM")
    Set wsStart = GetSheet(wb, "Start-Here", "Start-HERE")
    If wsStart Is Nothing Then
        MsgBox "Couldn't find sheet 'Start-Here' or 'Start-HERE'.", vbCritical
        Exit Sub
    End If

    ' ===== Build header map =====
    lastCol = wsBOM.Cells(headerRow, wsBOM.Columns.count).End(xlToLeft).Column
    For c = 1 To lastCol
        If Len(Trim$(wsBOM.Cells(headerRow, c).Value)) > 0 Then
            h(Trim$(CStr(wsBOM.Cells(headerRow, c).Value))) = c
        End If
    Next c

    ' ===== Check required headers =====
    Dim req As Variant
    req = Array("Vendor Name", "SAP Vendor Code", "Part Number", "Manufacturer", "QTY", _
                "Valuation Price", "Materials Group", "Purchase By", "Already Purch.")
    For r = LBound(req) To UBound(req)
        If Not h.Exists(req(r)) Then
            MsgBox "Missing column header: " & req(r), vbCritical
            Exit Sub
        End If
    Next r

    lastRow = wsBOM.Cells(wsBOM.rows.count, h("Part Number")).End(xlUp).Row
    If lastRow <= headerRow Then
        MsgBox "No data rows found in 'EE System Designed BOM'.", vbExclamation
        Exit Sub
    End If

    ' ===== Read Start-HERE values =====
    Dim deliveryDate As Variant, plant As Variant, purchGroup As Variant, purchOrg As String
    deliveryDate = wsStart.Range("C16").Value
    plant = wsStart.Range("C19").Value
    purchGroup = wsStart.Range("D20").Value
    purchOrg = wsStart.Range("C21").Value

    ' ===== Create main dictionaries =====
    Set vendorDict = CreateObject("Scripting.Dictionary")
    Set specialDict = CreateObject("Scripting.Dictionary")

    ' ===== Process rows =====
    Dim vendorName As String, vendorID As String, partNum As String, manuf As String
    Dim qty As Double, valPrice As Variant, matGroup As Variant
    Dim purchaseBy As String, alreadyPurch As String
    Dim vKey As Variant, pKey As String, arr As Variant
    Dim groupName As String

    For r = headerRow + 1 To lastRow
        vendorName = Trim$(CStr(wsBOM.Cells(r, h("Vendor Name")).Value))
        vendorID = Trim$(CStr(wsBOM.Cells(r, h("SAP Vendor Code")).Value))
        partNum = Trim$(CStr(wsBOM.Cells(r, h("Part Number")).Value))
        manuf = Trim$(CStr(wsBOM.Cells(r, h("Manufacturer")).Value))
        qty = ParseQty(wsBOM.Cells(r, h("QTY")).Value)
        valPrice = wsBOM.Cells(r, h("Valuation Price")).Value
        matGroup = wsBOM.Cells(r, h("Materials Group")).Value
        purchaseBy = UCase$(Trim$(CStr(wsBOM.Cells(r, h("Purchase By")).Value)))
        alreadyPurch = UCase$(Trim$(CStr(wsBOM.Cells(r, h("Already Purch.")).Value)))

        ' Determine group
        If alreadyPurch = "Y" Then
            groupName = "Already Purchased"
        ElseIf purchaseBy = "BY EE INSTALLER" Then
            groupName = "By EE Installer"
        Else
            groupName = "MAIN"
        End If

        ' Pick dictionary
        Dim targetDict As Object
        If groupName = "MAIN" Then
            Set targetDict = vendorDict
        Else
            Set targetDict = specialDict
            If Not targetDict.Exists(groupName) Then
                targetDict.Add groupName, CreateObject("Scripting.Dictionary")
            End If
        End If

        ' Skip blank vendor or part
        If Len(vendorName) = 0 Or Len(partNum) = 0 Then GoTo SkipRow

        ' Create vendor-level subdict
        Dim partDict As Object
        If groupName = "MAIN" Then
            If Not vendorDict.Exists(vendorName) Then
                Set partDict = CreateObject("Scripting.Dictionary")
                vendorDict.Add vendorName, partDict
            Else
                Set partDict = vendorDict(vendorName)
            End If
        Else
            Dim grpDict As Object
            Set grpDict = specialDict(groupName)
            If Not grpDict.Exists(vendorName) Then
                Set partDict = CreateObject("Scripting.Dictionary")
                grpDict.Add vendorName, partDict
            Else
                Set partDict = grpDict(vendorName)
            End If
        End If

        ' ==== Add or update part ====
        pKey = partNum
        If partDict.Exists(pKey) Then
            arr = partDict(pKey)
            arr(0) = arr(0) + qty ' ? sum QTY
            partDict(pKey) = arr
        Else
            partDict.Add pKey, Array(qty, partNum, manuf, valPrice, matGroup, vendorID)
        End If

SkipRow:
    Next r

    ' ===== Output routine =====
    Application.ScreenUpdating = False

    Dim outHeaders As Variant
    outHeaders = Array("Item of requisition", "Acct Assignment Cat.", "Item Category", "Material", "Short Text", _
                       "Quantity requested", "Unit of Measure", "Delivery Date", "Currency", "Valuation Price", _
                       "Materials Group", "Plant", "Purchasing Group", "Desired Vendor", "Purch. Organization")

    ' Main vendor sheets
    Call CreateSheetsFromDict_Prompt(wb, vendorDict, outHeaders, deliveryDate, plant, purchGroup, purchOrg)

    ' Special sheets
    Dim spKey As Variant
    For Each spKey In specialDict.keys
        Call CreateSheetsFromDict_Special_Prompt(wb, specialDict(spKey), outHeaders, deliveryDate, plant, purchGroup, purchOrg, spKey)
    Next spKey

    Application.ScreenUpdating = True
    MsgBox "? Vendor sheets created successfully (Main, By EE Installer, Already Purchased).", vbInformation
End Sub

'-------------------------------
' Sub: Create sheets for normal vendors with user prompt
'-------------------------------
Private Sub CreateSheetsFromDict_Prompt(wb As Workbook, dict As Object, headers As Variant, _
                                        deliveryDate As Variant, plant As Variant, _
                                        purchGroup As Variant, purchOrg As String)
    Dim vKey As Variant, key As Variant, arr As Variant, wsOut As Worksheet
    Dim NextRow As Long, iH As Long, answer As VbMsgBoxResult
    For Each vKey In dict.keys
        Dim sName As String: sName = Left$(CStr(vKey), 31)
        If SheetExists(wb, sName) Then
            answer = MsgBox("Sheet '" & sName & "' already exists." & vbCrLf & _
                            "Do you want to regenerate it?", vbYesNoCancel + vbQuestion, "Existing Sheet Found")
            If answer = vbCancel Then Exit Sub
            If answer = vbNo Then GoTo SkipThisVendor
            ' If Yes, delete and recreate
            Application.DisplayAlerts = False
            wb.Sheets(sName).Delete
            Application.DisplayAlerts = True
        End If
        Set wsOut = wb.Sheets.Add(After:=wb.Sheets(wb.Sheets.count))
        wsOut.Name = sName
        For iH = 0 To UBound(headers)
            wsOut.Cells(1, iH + 1).Value = headers(iH)
        Next iH
        NextRow = 2
        For Each key In dict(vKey).keys
            arr = dict(vKey)(key)
            With wsOut
                .Cells(NextRow, 1).Value = NextRow - 1
                .Cells(NextRow, 2).Value = "P"
                .Cells(NextRow, 3).Value = ""
                .Cells(NextRow, 4).Value = ""
                .Cells(NextRow, 5).Value = "P#" & arr(1) & " " & arr(2)
                .Cells(NextRow, 6).Value = arr(0)
                .Cells(NextRow, 7).Value = "EA"
                .Cells(NextRow, 8).Value = deliveryDate
                .Cells(NextRow, 9).Value = "USD"
                .Cells(NextRow, 10).Value = arr(3)
                .Cells(NextRow, 11).Value = arr(4)
                .Cells(NextRow, 12).Value = plant
                .Cells(NextRow, 13).Value = purchGroup
                .Cells(NextRow, 14).Value = arr(5)
                .Cells(NextRow, 15).Value = purchOrg
            End With
            NextRow = NextRow + 1
        Next key
        wsOut.Columns("A:O").AutoFit
SkipThisVendor:
    Next vKey
End Sub

'-------------------------------
' Sub: Create sheets for special categories (By EE Installer, Already Purchased)
'-------------------------------
Private Sub CreateSheetsFromDict_Special_Prompt(wb As Workbook, dict As Object, headers As Variant, _
                                                deliveryDate As Variant, plant As Variant, _
                                                purchGroup As Variant, purchOrg As String, _
                                                ByVal prefix As Variant)
    Dim vKey As Variant, key As Variant, arr As Variant, wsOut As Worksheet
    Dim NextRow As Long, iH As Long, answer As VbMsgBoxResult
    Dim sName As String
    For Each vKey In dict.keys
        sName = Left$(CStr(prefix) & " - " & CStr(vKey), 31)
        If SheetExists(wb, sName) Then
            answer = MsgBox("Sheet '" & sName & "' already exists." & vbCrLf & _
                            "Do you want to regenerate it?", vbYesNoCancel + vbQuestion, "Existing Sheet Found")
            If answer = vbCancel Then Exit Sub
            If answer = vbNo Then GoTo SkipThisVendor
            Application.DisplayAlerts = False
            wb.Sheets(sName).Delete
            Application.DisplayAlerts = True
        End If
        Set wsOut = wb.Sheets.Add(After:=wb.Sheets(wb.Sheets.count))
        wsOut.Name = sName
        For iH = 0 To UBound(headers)
            wsOut.Cells(1, iH + 1).Value = headers(iH)
        Next iH
        NextRow = 2
        For Each key In dict(vKey).keys
            arr = dict(vKey)(key)
            With wsOut
                .Cells(NextRow, 1).Value = NextRow - 1
                .Cells(NextRow, 2).Value = "P"
                .Cells(NextRow, 3).Value = ""
                .Cells(NextRow, 4).Value = ""
                .Cells(NextRow, 5).Value = "P#" & arr(1) & " " & arr(2)
                .Cells(NextRow, 6).Value = arr(0)
                .Cells(NextRow, 7).Value = "EA"
                .Cells(NextRow, 8).Value = deliveryDate
                .Cells(NextRow, 9).Value = "USD"
                .Cells(NextRow, 10).Value = arr(3)
                .Cells(NextRow, 11).Value = arr(4)
                .Cells(NextRow, 12).Value = plant
                .Cells(NextRow, 13).Value = purchGroup
                .Cells(NextRow, 14).Value = arr(5)
                .Cells(NextRow, 15).Value = purchOrg
            End With
            NextRow = NextRow + 1
        Next key
        wsOut.Columns("A:O").AutoFit
SkipThisVendor:
    Next vKey
End Sub


