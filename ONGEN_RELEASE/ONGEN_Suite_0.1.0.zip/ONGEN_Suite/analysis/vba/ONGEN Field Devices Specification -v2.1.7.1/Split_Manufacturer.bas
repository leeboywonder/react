Attribute VB_Name = "Split_Manufacturer"
Sub SplitManufacturerData()
    Dim wsSource As Worksheet
    Dim wsNew As Worksheet
    Dim rng As Range, cell As Range
    Dim dict As Object
    Dim key As Variant
    Dim header As Range
    Dim lastRow As Long, lastCol As Long
    Dim nameValue As String
    
    ' Set reference to source worksheet
    Set wsSource = ThisWorkbook.Sheets("EE System Designed BOM")
    
    ' Find the last used row and column
    lastRow = wsSource.Cells(wsSource.rows.count, "D").End(xlUp).Row
    lastCol = wsSource.Cells(1, wsSource.Columns.count).End(xlToLeft).Column
    
    ' Create a dictionary to store unique names
    Set dict = CreateObject("Scripting.Dictionary")
    
    ' Read all names in column D
    For Each cell In wsSource.Range("D2:D" & lastRow)
        nameValue = Trim(cell.Value)
        If nameValue <> "" Then
            If Not dict.Exists(nameValue) Then
                dict.Add nameValue, 1
            End If
        End If
    Next cell
    
    ' Store header range
    Set header = wsSource.Range(wsSource.Cells(1, 1), wsSource.Cells(1, lastCol))
    
    ' Loop through each unique name
    For Each key In dict.keys
        ' Check if the sheet already exists
        On Error Resume Next
        Set wsNew = ThisWorkbook.Sheets(key)
        On Error GoTo 0
        
        ' If not, create a new sheet
        If wsNew Is Nothing Then
            Set wsNew = ThisWorkbook.Sheets.Add(After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.count))
            wsNew.Name = key
        Else
            wsNew.Cells.Clear
        End If
        
        ' Copy header to new sheet
        header.Copy Destination:=wsNew.Range("A1")
        
        ' Filter and copy matching rows
        wsSource.Range("A1").AutoFilter Field:=4, Criteria1:=key
        wsSource.Range("A1").CurrentRegion.Offset(1, 0).SpecialCells(xlCellTypeVisible).Copy _
            Destination:=wsNew.Range("A2")
        wsSource.AutoFilterMode = False
        
        ' Auto-fit columns
        wsNew.Columns.AutoFit
        
        ' Reset for next iteration
        Set wsNew = Nothing
    Next key
    
    MsgBox "Data successfully split into " & dict.count & " sheets.", vbInformation
End Sub




