Attribute VB_Name = "modCoverPage_KPI_AutoUpgrade"
Option Explicit

'====================================================================================
' Module: modCoverPage_KPI_AutoUpgrade
' Purpose:
'   Automatically refresh Cover Page KPI values using VBA instead of worksheet formulas.
'
' What it updates:
'   1) Panel Output Sheets KPI
'   2) Workbook Sheets KPI
'   3) Input Devices KPI
'
' Default KPI cells used by the current Cover Page UI:
'   B6 = Panel Output Sheets
'   F6 = Workbook Sheets
'   J6 = Input Devices
'
' Notes:
'   - This module does not use formulas.
'   - This module does not delete or overwrite existing workbook macros.
'   - It safely creates/updates a Workbook_Open event that calls Refresh_CoverPage_KPIs.
'   - Programmatic access to VBA project must be enabled for automatic Workbook_Open install.
'====================================================================================

Private Const COVER_SHEET_NAME As String = "Cover Page"

Private Const KPI_PANEL_CELL As String = "F6"
Private Const KPI_WORKBOOK_CELL As String = "J6"
Private Const KPI_INPUT_CELL As String = "B6"

Private Const KPI_LAST_REFRESH_CELL As String = "B7"

'Sheets that should not be counted as generated panel/output sheets.
Private Function ExcludedSheetNames() As Object
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    d("Cover Page") = True
    d("MAIN") = True
    d("TEST") = True
    d("TEMPLATE") = True
    d("DATA") = True
    d("PD5_IMPORT") = True
    d("IO_DEVICE_LST") = True
    d("IO_DEVICE_LIST") = True
    d("PWG_Summary") = True
    d("EtherCAT_IO_Address") = True
    d("IO_Block_Summary") = True
    d("BOM Import INTERROLL") = True
    d("BOM import Interroll") = True
    d("Interroll BOM Count") = True
    d("SIS_TAG_EXPORT") = True
    d("SIS_TAG_PD5") = True
    d("SIS_TAG_IMPORT_PD2") = True
    d("FUNCTION DEVICE pd2") = True
    d("Function Definition") = True
    d("Specification Devices") = True
    d("Field Device IO ONGEN") = True
    d("Power Device Total") = True
    d("PSU_Breakout") = True
    d("ESTIMATE_PWR_DEVICE") = True

    Set ExcludedSheetNames = d
End Function

'====================================================================================
' MAIN KPI REFRESH MACRO
'====================================================================================
Public Sub Refresh_CoverPage_KPIs()
    Dim wb As Workbook
    Dim wsCover As Worksheet
    Dim panelCount As Long
    Dim workbookSheetCount As Long
    Dim inputDeviceCount As Long

    Set wb = ThisWorkbook
    Set wsCover = GetWorksheetSafe(wb, COVER_SHEET_NAME)

    If wsCover Is Nothing Then
        MsgBox "Cover Page sheet was not found. KPI update cancelled.", vbExclamation, "Cover Page KPI"
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.EnableEvents = False

    panelCount = CountPanelOutputSheets(wb)
    workbookSheetCount = CountWorkbookSheets(wb)
    inputDeviceCount = CountInputDevices(wb)

    With wsCover
        .Range(KPI_PANEL_CELL).Value = panelCount
        .Range(KPI_WORKBOOK_CELL).Value = workbookSheetCount
        .Range(KPI_INPUT_CELL).Value = inputDeviceCount

        .Range(KPI_PANEL_CELL).NumberFormat = "0"
        .Range(KPI_WORKBOOK_CELL).NumberFormat = "0"
        .Range(KPI_INPUT_CELL).NumberFormat = "0"

        On Error Resume Next
        .Range(KPI_LAST_REFRESH_CELL).Value = "Last Update Refreshed: " & Format(Now, "m/d/yyyy h:mm AM/PM")
        On Error GoTo 0
    End With

CleanExit:
    Application.EnableEvents = True
    Application.ScreenUpdating = True
End Sub

'====================================================================================
' INSTALLER - RUN ONCE
'====================================================================================
Public Sub Install_CoverPage_KPI_AutoUpgrade()
    Dim ok As Boolean

    Refresh_CoverPage_KPIs
    ok = InstallWorkbookOpenRefresh()

    If ok Then
        MsgBox "Cover Page KPI auto-upgrade installed." & vbCrLf & _
               "KPI values will refresh when the workbook opens.", vbInformation, "Cover Page KPI"
    Else
        MsgBox "KPI refresh macro was installed, but Workbook_Open could not be updated automatically." & vbCrLf & vbCrLf & _
               "To enable auto-refresh, paste this code into ThisWorkbook:" & vbCrLf & vbCrLf & _
               "Private Sub Workbook_Open()" & vbCrLf & _
               "    Refresh_CoverPage_KPIs" & vbCrLf & _
               "End Sub", vbExclamation, "Cover Page KPI"
    End If
End Sub

'====================================================================================
' OPTIONAL: ADD A BUTTON ON THE COVER PAGE
'====================================================================================
Public Sub Add_Refresh_KPI_Button_To_CoverPage()
    Dim ws As Worksheet
    Dim shp As Shape

    Set ws = GetWorksheetSafe(ThisWorkbook, COVER_SHEET_NAME)
    If ws Is Nothing Then
        MsgBox "Cover Page sheet was not found.", vbExclamation, "Cover Page KPI"
        Exit Sub
    End If

    On Error Resume Next
    ws.Shapes("btnRefreshCoverPageKPI").Delete
    On Error GoTo 0

    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, ws.Range("N4").Left, ws.Range("N4").Top, 180, 38)

    With shp
        .Name = "btnRefreshCoverPageKPI"
        .TextFrame2.TextRange.Text = "REFRESH KPI"
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.TextRange.Font.Size = 12
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
        .Fill.ForeColor.RGB = RGB(0, 112, 192)
        .Line.ForeColor.RGB = RGB(0, 72, 120)
        .OnAction = "Refresh_CoverPage_KPIs"
    End With

    MsgBox "Refresh KPI button added to the Cover Page.", vbInformation, "Cover Page KPI"
End Sub

'====================================================================================
' KPI COUNT LOGIC
'====================================================================================
Private Function CountPanelOutputSheets(ByVal wb As Workbook) As Long
    Dim ws As Worksheet
    Dim excludes As Object
    Dim n As Long

    Set excludes = ExcludedSheetNames()

    For Each ws In wb.Worksheets
        If Not excludes.Exists(ws.Name) Then
            If IsLikelyPanelOutputSheet(ws) Then
                n = n + 1
            End If
        End If
    Next ws

    CountPanelOutputSheets = n
End Function

Private Function CountWorkbookSheets(ByVal wb As Workbook) As Long
    CountWorkbookSheets = wb.Worksheets.Count
End Function

Private Function CountInputDevices(ByVal wb As Workbook) As Long
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim colDevice As Long
    Dim colItemType As Long
    Dim r As Long
    Dim n As Long

    Set ws = FindFirstExistingSheet(wb, Array("IO_DEVICE_LIST", "IO_Device_List", "IO_Device_list", "IO_DEVICE_LST", "Field Device IO ONGEN"))

    If ws Is Nothing Then
        CountInputDevices = 0
        Exit Function
    End If

    colDevice = FindHeaderColumn(ws, Array("Device name", "Device", "DEVICE NAME", "SIS_SEQUENCE", "SEQUENCE"), 1, 20)
    colItemType = FindHeaderColumn(ws, Array("Item Type", "TYPE", "Device Type"), 1, 20)

    If colDevice = 0 Then colDevice = 1

    lastRow = ws.Cells(ws.Rows.Count, colDevice).End(xlUp).Row
    If lastRow < 2 Then
        CountInputDevices = 0
        Exit Function
    End If

    For r = 2 To lastRow
        If Len(Trim$(CStr(ws.Cells(r, colDevice).Value))) > 0 Then
            If colItemType = 0 Then
                n = n + 1
            ElseIf Len(Trim$(CStr(ws.Cells(r, colItemType).Value))) > 0 Then
                n = n + 1
            Else
                n = n + 1
            End If
        End If
    Next r

    CountInputDevices = n
End Function

Private Function IsLikelyPanelOutputSheet(ByVal ws As Worksheet) As Boolean
    Dim cDevice As Long
    Dim cChannel As Long
    Dim cBlockID As Long
    Dim cPanel As Long
    Dim cPWG As Long

    cDevice = FindHeaderColumn(ws, Array("Device", "Device name", "DEVICE NAME"), 1, 15)
    cChannel = FindHeaderColumn(ws, Array("Channel IO", "Port Location", "Signal Name"), 1, 15)
    cBlockID = FindHeaderColumn(ws, Array("Block ID", "IO Block"), 1, 15)
    cPanel = FindHeaderColumn(ws, Array("Panel", "PNL"), 1, 15)
    cPWG = FindHeaderColumn(ws, Array("PWG", "SwitchGroup", "SWITCHGROUP"), 1, 15)

    If cDevice > 0 And (cChannel > 0 Or cBlockID > 0 Or cPanel > 0 Or cPWG > 0) Then
        IsLikelyPanelOutputSheet = True
    Else
        IsLikelyPanelOutputSheet = False
    End If
End Function

'====================================================================================
' WORKBOOK_OPEN INSTALLER
'====================================================================================
Private Function InstallWorkbookOpenRefresh() As Boolean
    On Error GoTo FailHandler

    Dim vbProj As Object
    Dim vbComp As Object
    Dim codeMod As Object
    Dim startLine As Long
    Dim procLines As Long
    Dim insertCode As String

    Set vbProj = ThisWorkbook.VBProject
    Set vbComp = vbProj.VBComponents("ThisWorkbook")
    Set codeMod = vbComp.CodeModule

    On Error Resume Next
    startLine = codeMod.ProcStartLine("Workbook_Open", 0)
    procLines = codeMod.ProcCountLines("Workbook_Open", 0)
    On Error GoTo FailHandler

    If startLine > 0 And procLines > 0 Then
        codeMod.DeleteLines startLine, procLines
    End If

    insertCode = "Private Sub Workbook_Open()" & vbCrLf & _
                 "    On Error Resume Next" & vbCrLf & _
                 "    Refresh_CoverPage_KPIs" & vbCrLf & _
                 "    On Error GoTo 0" & vbCrLf & _
                 "End Sub"

    codeMod.InsertLines codeMod.CountOfLines + 1, insertCode
    InstallWorkbookOpenRefresh = True
    Exit Function

FailHandler:
    InstallWorkbookOpenRefresh = False
End Function

'====================================================================================
' HELPERS
'====================================================================================
Private Function GetWorksheetSafe(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set GetWorksheetSafe = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function FindFirstExistingSheet(ByVal wb As Workbook, ByVal names As Variant) As Worksheet
    Dim i As Long
    Dim ws As Worksheet

    For i = LBound(names) To UBound(names)
        Set ws = GetWorksheetSafe(wb, CStr(names(i)))
        If Not ws Is Nothing Then
            Set FindFirstExistingSheet = ws
            Exit Function
        End If
    Next i
End Function

Private Function FindHeaderColumn(ByVal ws As Worksheet, ByVal headerNames As Variant, ByVal firstRow As Long, ByVal lastHeaderRow As Long) As Long
    Dim r As Long
    Dim c As Long
    Dim lastCol As Long
    Dim i As Long
    Dim cellText As String
    Dim targetText As String

    For r = firstRow To lastHeaderRow
        lastCol = ws.Cells(r, ws.Columns.Count).End(xlToLeft).Column
        If lastCol < 1 Then lastCol = 1

        For c = 1 To lastCol
            cellText = NormalizeHeader(CStr(ws.Cells(r, c).Value))
            If Len(cellText) > 0 Then
                For i = LBound(headerNames) To UBound(headerNames)
                    targetText = NormalizeHeader(CStr(headerNames(i)))
                    If cellText = targetText Then
                        FindHeaderColumn = c
                        Exit Function
                    End If
                Next i
            End If
        Next c
    Next r

    FindHeaderColumn = 0
End Function

Private Function NormalizeHeader(ByVal s As String) As String
    s = Trim$(s)
    s = Replace(s, Chr$(160), " ")
    s = Replace(s, "_", " ")
    s = Replace(s, "-", " ")
    Do While InStr(1, s, "  ", vbBinaryCompare) > 0
        s = Replace(s, "  ", " ")
    Loop
    NormalizeHeader = UCase$(s)
End Function
