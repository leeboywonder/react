Attribute VB_Name = "export_panel_for_generation"
Option Explicit

Sub Export_All_Sheets_Except_Excluded()

    Dim srcWB As Workbook
    Dim destWB As Workbook
    Dim ws As Worksheet
    Dim destFile As Variant
    Dim excludedSheets As Object
    Dim sheetExists As Boolean
    Dim userChoice As VbMsgBoxResult
    Dim copiedCount As Long
    Dim skippedCount As Long
    
    Set srcWB = ThisWorkbook
    Set excludedSheets = CreateObject("Scripting.Dictionary")
    
    'Sheets to NOT export
    excludedSheets.Add UCase("COVER PAGE"), True
    excludedSheets.Add UCase("IO_DEVICE_LIST"), True
    excludedSheets.Add UCase("PWG_Summary"), True
    excludedSheets.Add UCase("EtherCAT_IO_Address"), True
    excludedSheets.Add UCase("IO_Block_Summary"), True
    
    'Ask user to select destination workbook
    destFile = Application.GetOpenFilename( _
        FileFilter:="Excel Files (*.xls; *.xlsx; *.xlsm), *.xls; *.xlsx; *.xlsm", _
        Title:="Select Destination Workbook")
    
    If destFile = False Then Exit Sub
    
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    
    Set destWB = Workbooks.Open(destFile)
    
    For Each ws In srcWB.Worksheets
        
        If Not excludedSheets.Exists(UCase(ws.Name)) Then
            
            sheetExists = WorksheetExists(destWB, ws.Name)
            
            If sheetExists Then
                
                Application.DisplayAlerts = True
                
                userChoice = MsgBox( _
                    "Worksheet '" & ws.Name & "' already exists in the destination workbook." & vbCrLf & vbCrLf & _
                    "Click YES to overwrite it." & vbCrLf & _
                    "Click NO to ignore it and continue.", _
                    vbYesNo + vbQuestion, _
                    "Worksheet Already Exists")
                
                Application.DisplayAlerts = False
                
                If userChoice = vbYes Then
                    destWB.Worksheets(ws.Name).Delete
                    ws.Copy After:=destWB.Worksheets(destWB.Worksheets.Count)
                    copiedCount = copiedCount + 1
                Else
                    skippedCount = skippedCount + 1
                End If
                
            Else
                ws.Copy After:=destWB.Worksheets(destWB.Worksheets.Count)
                copiedCount = copiedCount + 1
            End If
            
        End If
        
    Next ws
    
    destWB.Save
    
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    
    MsgBox "Export complete." & vbCrLf & vbCrLf & _
           "Worksheets copied: " & copiedCount & vbCrLf & _
           "Worksheets skipped: " & skippedCount, vbInformation

End Sub

Function WorksheetExists(wb As Workbook, sheetName As String) As Boolean

    Dim ws As Worksheet
    
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0
    
    WorksheetExists = Not ws Is Nothing

End Function

