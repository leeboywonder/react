Attribute VB_Name = "modCoverPage_KPI_Update"
Option Explicit

'============================================================
' ONGEN V5 Cover Page KPI Macro Upgrade
' Purpose:
'   Updates Cover Page KPI values by macro instead of formulas.
'
' KPI cells updated:
'   B6 = Input Devices
'   F6 = Panel Output Sheets
'   J6 = Workbook Sheets
'

'============================================================

Public Sub Update_CoverPage_KPIs()
    Dim wb As Workbook
    Dim wsCover As Worksheet
    Dim inputCount As Long
    Dim panelCount As Long
    Dim workbookSheetCount As Long

    Set wb = ThisWorkbook
    Set wsCover = GetWorksheetIfExists(wb, "Cover Page")

    If wsCover Is Nothing Then
        MsgBox "Cover Page worksheet was not found.", vbExclamation, "Update KPIs"
        Exit Sub
    End If

    inputCount = CountInputDevices(wb)
    panelCount = CountPanelOutputSheets(wb)
    workbookSheetCount = wb.Worksheets.Count

    Application.ScreenUpdating = False

    With wsCover
        .Range("B6").Value = inputCount
        .Range("F6").Value = panelCount
        .Range("J6").Value = workbookSheetCount

        .Range("B7").Value = "Updated by macro: " & Format(Now, "m/d/yyyy h:mm AM/PM")
        .Range("F7").Value = "Generated panel/output sheets counted by macro"
        .Range("J7").Value = "Workbook worksheets counted by macro"

        .Range("B6,F6,J6").NumberFormat = "0"
        .Range("B6,F6,J6").Font.Bold = True
    End With

    Application.ScreenUpdating = True

    MsgBox "Cover Page KPI values updated successfully.", vbInformation, "Update KPIs"
End Sub

Private Function CountInputDevices(ByVal wb As Workbook) As Long
    Dim ws As Worksheet
    Dim deviceCol As Long
    Dim lastRow As Long
    Dim r As Long
    Dim cnt As Long

    Set ws = GetWorksheetIfExists(wb, "IO_DEVICE_LIST")
    If ws Is Nothing Then Set ws = GetWorksheetIfExists(wb, "IO_Device_List")
    If ws Is Nothing Then Set ws = GetWorksheetIfExists(wb, "IO_Device_list")
    If ws Is Nothing Then
        CountInputDevices = 0
        Exit Function
    End If

    deviceCol = FindHeaderColumn(ws, "DEVICE NAME", 1)
    If deviceCol = 0 Then deviceCol = 1

    lastRow = ws.Cells(ws.Rows.Count, deviceCol).End(xlUp).Row
    If lastRow < 2 Then
        CountInputDevices = 0
        Exit Function
    End If

    For r = 2 To lastRow
        If Len(Trim$(CStr(ws.Cells(r, deviceCol).Value))) > 0 Then cnt = cnt + 1
    Next r

    CountInputDevices = cnt
End Function

Private Function CountPanelOutputSheets(ByVal wb As Workbook) As Long
    Dim ws As Worksheet
    Dim cnt As Long

    For Each ws In wb.Worksheets
        If IsPanelOutputSheet(ws.Name) Then cnt = cnt + 1
    Next ws

    CountPanelOutputSheets = cnt
End Function

Private Function IsPanelOutputSheet(ByVal sheetName As String) As Boolean
    Dim nm As String
    nm = UCase$(Trim$(sheetName))

    Select Case nm
        Case "COVER PAGE", "MAIN", "IO_DEVICE_LIST", "IO_DEVICE_LST", _
             "IO_DEVICE_LIST", "PWG_SUMMARY", "ETHERCAT_IO_ADDRESS", _
             "IO_BLOCK_SUMMARY", "DATA", "TEMPLATE", "PD5_IMPORT", _
             "VBA_PATCH_UPDATE_KPIS"
            IsPanelOutputSheet = False
            Exit Function
    End Select

    If Left$(nm, 10) = "VBA_PATCH" Then
        IsPanelOutputSheet = False
    Else
        IsPanelOutputSheet = True
    End If
End Function

Private Function GetWorksheetIfExists(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set GetWorksheetIfExists = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function FindHeaderColumn(ByVal ws As Worksheet, ByVal headerText As String, ByVal headerRow As Long) As Long
    Dim lastCol As Long
    Dim c As Long
    Dim target As String

    target = UCase$(Trim$(headerText))
    lastCol = ws.Cells(headerRow, ws.Columns.Count).End(xlToLeft).Column

    For c = 1 To lastCol
        If UCase$(Trim$(CStr(ws.Cells(headerRow, c).Value))) = target Then
            FindHeaderColumn = c
            Exit Function
        End If
    Next c

    FindHeaderColumn = 0
End Function
