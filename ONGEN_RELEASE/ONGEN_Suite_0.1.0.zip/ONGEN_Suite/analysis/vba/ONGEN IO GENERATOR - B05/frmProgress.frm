Attribute VB_Name = "frmProgress"
Attribute VB_Base = "0{FAC9D7D1-2861-436E-B66C-E3B5AAF283DD}{A97658C0-FA98-4B93-AE7D-6D0A3488DAD9}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit

Public Sub SetProgress(ByVal progressValue As Double, Optional ByVal statusText As String)
    On Error Resume Next
    If progressValue < 0 Then progressValue = 0
    If progressValue > 1 Then progressValue = 1

    Me.LabelProgress.Width = Me.FrameProgress.Width * progressValue
    Me.lblPercent.Caption = Format(progressValue * 100, "0") & "%"
    If Len(statusText) > 0 Then Me.lblStatus.Caption = statusText
    DoEvents
End Sub

