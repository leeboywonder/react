Attribute VB_Name = "OPTION_IO_V6_RELEASED"
Option Explicit

'============================================================
' RELEASED MODULE
' Name: OPTION_IO_V6_RELEASED
' Author: Lee Pierre
' Version: V6.9 Released
' Date: 2026-06-25
'
' PURPOSE:
'   Generates IO layout sheets from IO_Device_list / IO_Device_List.
'   Supports protocol-based IO module selection using frmIOBlockSelector.
'
' NETWORK / MODULE OPTIONS:
'   Ethernet/IP:
'       1) MVK Fusion CIP Safety 55514 + Murr IMPACT67 54631
'       2) MVK Fusion CIP Safety 55514 Only
'
'   EtherCAT:
'       1) Murr IMPACT67 54632
'       2) Beckhoff EP2339-0022 + Beckhoff EP1957-0022
'
' REQUIRED INPUT HEADERS:
'   DEVICE NAME | Item Type | INPUT | OUTPUT | S_IN | S_OUT | PNL | PWG | LOCATION
'
' OPTIONAL INPUT HEADERS:
'   Standard Block | Safety Block
'
' OUTPUT SHEETS:
'   - One panel worksheet per PNL value
'   - PWG_Summary
'   - Network_IO_Address
'   - IO_Block_Summary
'
' V6 NOTES:
'   - Added Network Protocol selector: Ethernet/IP or EtherCAT.
'   - Dynamic module options based on protocol.
'   - MVK Fusion 55514 Only uses a shared physical block for standard IO and safety IO.
'   - If one device needs both standard and safety IO in MVK-only mode, the code tries to place
'     those signals on the same available MVK Fusion block before creating another block.
'   - V6.1: In Ethernet/IP MVK + IMPACT67 mode, any device with safety IO is routed
'     completely to MVK 55514, including its standard IO, to keep the device on one block.
'   - V6.2: Updated MVK 55514 port allocation:
'       X0-X2 = two safety inputs each, X3 = two safety outputs, X4-X7 = two DIO each.
'     Updated IMPACT67 54631/54632 to use Beckhoff-style dual-signal port allocation.
'   - V6.3: Added NO-SPLIT device routing. If the active IO module does not have
'     enough available points for the whole device, a new module is created before
'     placing any signals from that device. A device is never split across modules.
'   - V6.5: Active modules are separated by Block ID. Module fit checks use effective
'     capacity with 10% spare reserve where practical.
'   - V6.6: IO Block column restored to previous format: Part# Ref. + PG/PWG.
'     If the same Block ID needs an extension in the same PWG, the IO Block label
'     adds (x2), (x3), etc. Example: EP2339-0022 PG2330 (x2).
'   - V6.9: Added 2-signal port alignment. If a device needs exactly two
'     points on a dual-signal port and the active port has only one point left,
'     that open point is reserved and the device starts on the next full port.
'     Applies to Beckhoff EP2339 standard IO, EP1957 safety inputs, Murr
'     IMPACT67 standard IO, and MVK Fusion standard/safety input port pairs.
'============================================================

'-----------------------------
' Profile constants
'-----------------------------
Private Const PROFILE_ETHERNET_MVK_IMPACT As String = "ETHERNET_MVK_IMPACT"
Private Const PROFILE_ETHERNET_MVK_ONLY As String = "ETHERNET_MVK_ONLY"
Private Const PROFILE_ETHERCAT_IMPACT As String = "ETHERCAT_IMPACT"
Private Const PROFILE_ETHERCAT_BECKHOFF As String = "ETHERCAT_BECKHOFF"

'-----------------------------
' Module/global settings
'-----------------------------
Private progressMax As Long
Private blockIDMap As Object
Private blockExpansionMap As Object
Private blockLabelMap As Object
Private stdSeedDeviceMap As Object
Private safeSeedDeviceMap As Object
Private combinedSeedDeviceMap As Object

Private gProfile As String
Private gNetworkProtocol As String

Private gStdPart As String
Private gSafePart As String
Private gCombinedPart As String

Private gStdModuleName As String
Private gSafeModuleName As String
Private gCombinedModuleName As String

Private gStdCapacity As Long
Private gCombinedStdCapacity As Long
Private gSafeInCapacity As Long
Private gSafeOutCapacity As Long

Private gUseSafety As Boolean
Private gCombinedMVKMode As Boolean

'============================================================
' MAIN MACRO
'============================================================
Public Sub Beckhoff_IOGenerate_ONGEN_Based_Optimized()
    Run_IO_Generator_V6
End Sub

Public Sub Beckhoff_IOGenerate_ONGEN_Based_Optimized_OPTION()
    Run_IO_Generator_V6
End Sub

Public Sub Run_IO_Generator_V6()

    Const NET_STD_START As Long = 1000
    Const NET_SAFE_START As Long = 2000
    Const NET_COMBINED_START As Long = 3000

    Dim tStart As Double
    tStart = Timer

    Dim oldCalc As XlCalculation
    oldCalc = Application.Calculation

    On Error GoTo ErrHandler

    With Application
        .ScreenUpdating = False
        .EnableEvents = False
        .Calculation = xlCalculationManual
        .StatusBar = "Initializing IO Map generator V6..."
    End With

    If Not SelectIOHardwareProfile() Then GoTo Cleanup

    Dim wsIn As Worksheet
    Set wsIn = FindSheetInsensitive("IO_Device_list")
    If wsIn Is Nothing Then Set wsIn = FindSheetInsensitive("IO_Device_List")

    If wsIn Is Nothing Then
        MsgBox "Missing input sheet 'IO_Device_list'.", vbCritical
        GoTo Cleanup
    End If

    Dim colMap As Object
    Set colMap = HeaderMap(wsIn, 1)

    Dim cDevice As Long, cType As Long, cIn As Long, cOut As Long
    Dim cSIn As Long, cSOut As Long, cPNL As Long, cPWG As Long, cLoc As Long
    Dim cStdBlk As Long, cSafeBlk As Long

    cDevice = GetHeaderCol(colMap, "device name")
    cType = GetHeaderCol(colMap, "item type")
    cIn = GetHeaderCol(colMap, "input")
    cOut = GetHeaderCol(colMap, "output")
    cSIn = GetHeaderCol(colMap, "s_in")
    cSOut = GetHeaderCol(colMap, "s_out")
    cPNL = GetHeaderCol(colMap, "pnl")
    cPWG = GetHeaderCol(colMap, "pwg")
    cLoc = GetHeaderCol(colMap, "location")
    cStdBlk = GetHeaderCol(colMap, "standard block")
    cSafeBlk = GetHeaderCol(colMap, "safety block")

    If cDevice * cType * cIn * cOut * cSIn * cSOut * cPNL * cPWG * cLoc = 0 Then
        MsgBox "Missing headers." & vbCrLf & _
               "Required: DEVICE NAME | Item Type | INPUT | OUTPUT | S_IN | S_OUT | PNL | PWG | LOCATION", vbCritical
        GoTo Cleanup
    End If

    Dim lastRow As Long
    lastRow = wsIn.Cells(wsIn.Rows.Count, cDevice).End(xlUp).Row

    If lastRow < 2 Then
        MsgBox "No data rows found.", vbExclamation
        GoTo Cleanup
    End If

    Dim lastCol As Long
    lastCol = wsIn.Cells(1, wsIn.Columns.Count).End(xlToLeft).Column

    Dim dataArr As Variant
    dataArr = wsIn.Range(wsIn.Cells(1, 1), wsIn.Cells(lastRow, lastCol)).Value

    Dim overwriteChoice As VbMsgBoxResult
    overwriteChoice = MsgBox("Overwrite existing output sheets?" & vbCrLf & _
                             "Yes = Overwrite" & vbCrLf & _
                             "No = Append panel sheets / refresh summaries" & vbCrLf & _
                             "Cancel = Abort", _
                             vbYesNoCancel + vbQuestion, _
                             "IO Generator V6")

    If overwriteChoice = vbCancel Then GoTo Cleanup

    Dim dictPanels As Object, dictPWG As Object
    Set dictPanels = CreateObject("Scripting.Dictionary")
    Set dictPWG = CreateObject("Scripting.Dictionary")

    Dim gStdIn As Object, gStdOut As Object, gSafeIn As Object, gSafeOut As Object
    Set gStdIn = CreateObject("Scripting.Dictionary")
    Set gStdOut = CreateObject("Scripting.Dictionary")
    Set gSafeIn = CreateObject("Scripting.Dictionary")
    Set gSafeOut = CreateObject("Scripting.Dictionary")

    Dim StdBlockIndex As Object, StdChanUsed As Object, StdActiveKey As Object
    Set StdBlockIndex = CreateObject("Scripting.Dictionary")
    Set StdChanUsed = CreateObject("Scripting.Dictionary")
    Set StdActiveKey = CreateObject("Scripting.Dictionary")

    Dim SafeBlockIndex As Object, SafeActive As Object
    Set SafeBlockIndex = CreateObject("Scripting.Dictionary")
    Set SafeActive = CreateObject("Scripting.Dictionary")

    Dim CmbBlockIndex As Object, CmbActive As Object
    Set CmbBlockIndex = CreateObject("Scripting.Dictionary")
    Set CmbActive = CreateObject("Scripting.Dictionary")

    Dim usedStdBlocks As Object, usedSafeBlocks As Object, usedCombinedBlocks As Object
    Set usedStdBlocks = CreateObject("Scripting.Dictionary")
    Set usedSafeBlocks = CreateObject("Scripting.Dictionary")
    Set usedCombinedBlocks = CreateObject("Scripting.Dictionary")

    Set blockIDMap = CreateObject("Scripting.Dictionary")
    Set blockExpansionMap = CreateObject("Scripting.Dictionary")
    Set blockLabelMap = CreateObject("Scripting.Dictionary")
    Set stdSeedDeviceMap = CreateObject("Scripting.Dictionary")
    Set safeSeedDeviceMap = CreateObject("Scripting.Dictionary")
    Set combinedSeedDeviceMap = CreateObject("Scripting.Dictionary")

    PB_Init lastRow - 1, "Building IO Map V6..."

    Dim r As Long
    Dim rawPNL As String, cleanPNL As String
    Dim wsPanel As Worksheet

    'Create panel sheets first.
    For r = 2 To lastRow
        rawPNL = Trim$(CStr(dataArr(r, cPNL)))
        If Len(rawPNL) = 0 Then rawPNL = "UNASSIGNED"

        cleanPNL = CleanSheetName(rawPNL)

        If Not dictPanels.Exists(cleanPNL) Then
            Set wsPanel = GetOrCreateSheet(cleanPNL, overwriteChoice = vbYes)
            dictPanels.Add cleanPNL, wsPanel
            SetupPanelHeader wsPanel
        End If
    Next r

    Dim device As String, deviceType As String, pwg As String, loc As String, prefix As String
    Dim inN As Long, outN As Long, sInN As Long, sOutN As Long
    Dim nxt As Long, keyBase As String
    Dim stdBlkRaw As String, safeBlkRaw As String
    Dim stdTag As String, safeTag As String

    For r = 2 To lastRow

        device = Trim$(CStr(dataArr(r, cDevice)))
        If Len(device) = 0 Then device = "UNNAMED_" & CStr(r)

        deviceType = Trim$(CStr(dataArr(r, cType)))

        rawPNL = Trim$(CStr(dataArr(r, cPNL)))
        If Len(rawPNL) = 0 Then rawPNL = "UNASSIGNED"

        cleanPNL = CleanSheetName(rawPNL)

        pwg = Trim$(CStr(dataArr(r, cPWG)))
        If Len(pwg) = 0 Then pwg = "N/A"

        loc = Trim$(CStr(dataArr(r, cLoc)))
        prefix = CleanTagPrefix(rawPNL)

        inN = CLng(Val(dataArr(r, cIn)))
        outN = CLng(Val(dataArr(r, cOut)))
        sInN = CLng(Val(dataArr(r, cSIn)))
        sOutN = CLng(Val(dataArr(r, cSOut)))

        If inN + outN + sInN + sOutN = 0 Then GoTo SkipRow

        stdBlkRaw = ""
        safeBlkRaw = ""

        If cStdBlk > 0 Then stdBlkRaw = Trim$(CStr(dataArr(r, cStdBlk)))
        If cSafeBlk > 0 Then safeBlkRaw = Trim$(CStr(dataArr(r, cSafeBlk)))

        stdTag = NormalizeBlockTag(stdBlkRaw, "STD")
        safeTag = NormalizeBlockTag(safeBlkRaw, "SAFE")

        If Not dictPWG.Exists(pwg) Then dictPWG.Add pwg, True
        EnsurePWGGlobal gStdIn, gStdOut, gSafeIn, gSafeOut, pwg

        Set wsPanel = dictPanels(cleanPNL)
        nxt = wsPanel.Cells(wsPanel.Rows.Count, "A").End(xlUp).Row + 1

        keyBase = cleanPNL & "|" & pwg & "|STD_ACTIVE"

        Dim totalEst As Long
        totalEst = MaxLng(1, inN + outN + sInN + sOutN + 30)

        Dim buf() As Variant
        ReDim buf(1 To totalEst, 1 To 14)

        Dim n As Long
        n = 1

        '============================================================
        ' V6.1 DEVICE ROUTING LOGIC
        '============================================================
        ' Ethernet/IP + IMPACT67 54631 + MVK Fusion 55514:
        '   - Devices with STANDARD IO ONLY go to IMPACT67 54631.
        '   - Devices with ANY SAFETY IO go entirely to MVK Fusion 55514.
        '     This keeps standard and safety signals for the same device on the same physical MVK block.
        '
        ' Example:
        '   Device 1152-EST: OUT = 1 and S_IN = 2
        '   Result: OUT + S_IN both land on MVK Fusion 55514.
        '   The standard OUT is NOT placed on IMPACT67.
        '============================================================
        If gProfile = PROFILE_ETHERNET_MVK_IMPACT Then

            If sInN + sOutN > 0 Then
                GenerateCombinedMVKRows buf, n, device, deviceType, prefix, rawPNL, cleanPNL, pwg, loc, _
                                        inN, outN, sInN, sOutN, safeTag, _
                                        CmbBlockIndex, CmbActive, usedCombinedBlocks
            Else
                GenerateStandardIORows buf, n, device, deviceType, prefix, rawPNL, cleanPNL, pwg, loc, _
                                       inN, outN, stdTag, keyBase, _
                                       StdBlockIndex, StdChanUsed, StdActiveKey, usedStdBlocks
            End If

        ElseIf gCombinedMVKMode Then

            GenerateCombinedMVKRows buf, n, device, deviceType, prefix, rawPNL, cleanPNL, pwg, loc, _
                                    inN, outN, sInN, sOutN, safeTag, _
                                    CmbBlockIndex, CmbActive, usedCombinedBlocks

        Else

            GenerateStandardIORows buf, n, device, deviceType, prefix, rawPNL, cleanPNL, pwg, loc, _
                                   inN, outN, stdTag, keyBase, _
                                   StdBlockIndex, StdChanUsed, StdActiveKey, usedStdBlocks

            If gUseSafety Then
                GenerateSafetyIORows buf, n, device, deviceType, prefix, rawPNL, cleanPNL, pwg, loc, _
                                     sInN, sOutN, safeTag, SafeBlockIndex, SafeActive, usedSafeBlocks
            ElseIf sInN + sOutN > 0 Then
                FillRow buf, n, device, deviceType, "", "NOTE", _
                        "Safety IO requested but selected module profile has no safety IO", _
                        "", "", "", "", pwg, rawPNL, loc
            End If

        End If

        If inN > 0 Then Bump gStdIn, pwg, inN
        If outN > 0 Then Bump gStdOut, pwg, outN
        If sInN > 0 Then Bump gSafeIn, pwg, sInN
        If sOutN > 0 Then Bump gSafeOut, pwg, sOutN

        If n > 1 Then
            WriteBufferToSheet wsPanel, nxt, buf, n - 1, 14
        End If

SkipRow:
        PB_Update r - 1, Format((r - 1) / (lastRow - 1), "0%")

    Next r

    Dim wsSummary As Worksheet, wsNetwork As Worksheet

    GeneratePWGSummary dictPWG, wsSummary, usedStdBlocks, usedSafeBlocks, usedCombinedBlocks, _
                       gStdIn, gStdOut, gSafeIn, gSafeOut, overwriteChoice

    GenerateNetworkAddressSheet dictPWG, wsNetwork, usedStdBlocks, usedSafeBlocks, usedCombinedBlocks, _
                                overwriteChoice, NET_STD_START, NET_SAFE_START, NET_COMBINED_START

    GenerateIOBlockSummary usedStdBlocks, usedSafeBlocks, usedCombinedBlocks, overwriteChoice

    PB_Done "Layout complete."

    MsgBox "IO generation completed." & vbCrLf & _
           "Network: " & gNetworkProtocol & vbCrLf & _
           "Selected Profile: " & gProfile & vbCrLf & _
           "Runtime: " & Format(Timer - tStart, "0.0") & " seconds.", vbInformation

Cleanup:
    With Application
        .ScreenUpdating = True
        .EnableEvents = True
        .Calculation = oldCalc
        .StatusBar = False
    End With

    Exit Sub

ErrHandler:
    MsgBox "Error " & Err.Number & ": " & Err.Description, vbCritical, "IO Generator V6"
    Resume Cleanup

End Sub

'============================================================
' USERFORM PROFILE SELECTION
'============================================================
Private Function SelectIOHardwareProfile() As Boolean

    frmIOBlockSelector.Show vbModal

    If frmIOBlockSelector.Cancelled Then
        SelectIOHardwareProfile = False
        Unload frmIOBlockSelector
        Exit Function
    End If

    gNetworkProtocol = frmIOBlockSelector.SelectedProtocol
    gProfile = frmIOBlockSelector.SelectedProfile
    Unload frmIOBlockSelector

    Select Case gProfile

        Case PROFILE_ETHERNET_MVK_IMPACT
            gNetworkProtocol = "Ethernet/IP"
            gStdPart = "54631"
            gSafePart = "55514"
            gCombinedPart = "55514"
            gStdModuleName = "Murr IMPACT67 Pro E DIO8 IOL8 Standard IO"
            gSafeModuleName = "Murr MVK Fusion CIP Safety FDI6/3 FDO2/1"
            gCombinedModuleName = "Murr MVK Fusion CIP Safety 55514 Combined IO"
            gStdCapacity = 16                 'IMPACT67 has 8 ports x 2 signals = 16 physical points; 10% spare leaves 14 usable
            gCombinedStdCapacity = 8          'MVK 55514 DIO: X4-X7, two signals each
            gSafeInCapacity = 6
            gSafeOutCapacity = 2
            gUseSafety = True
            gCombinedMVKMode = False

        Case PROFILE_ETHERNET_MVK_ONLY
            gNetworkProtocol = "Ethernet/IP"
            gStdPart = "55514"
            gSafePart = "55514"
            gCombinedPart = "55514"
            gStdModuleName = "Murr MVK Fusion CIP Safety DIO4 / IOL2"
            gSafeModuleName = "Murr MVK Fusion CIP Safety FDI6/3 FDO2/1"
            gCombinedModuleName = "Murr MVK Fusion CIP Safety 55514 Combined IO"
            gStdCapacity = 8
            gCombinedStdCapacity = 8
            gSafeInCapacity = 6
            gSafeOutCapacity = 2
            gUseSafety = True
            gCombinedMVKMode = True

        Case PROFILE_ETHERCAT_IMPACT
            gNetworkProtocol = "EtherCAT"
            gStdPart = "54632"
            gSafePart = ""
            gCombinedPart = ""
            gStdModuleName = "Murr IMPACT67 EtherCAT DIO8 IOL8 Standard IO"
            gSafeModuleName = ""
            gCombinedModuleName = ""
            gStdCapacity = 16                 'IMPACT67 has 8 ports x 2 signals = 16 physical points; 10% spare leaves 14 usable
            gCombinedStdCapacity = 0
            gSafeInCapacity = 0
            gSafeOutCapacity = 0
            gUseSafety = False
            gCombinedMVKMode = False

        Case PROFILE_ETHERCAT_BECKHOFF
            gNetworkProtocol = "EtherCAT"
            gStdPart = "EP2339-0022"
            gSafePart = "EP1957-0022"
            gCombinedPart = ""
            gStdModuleName = "Beckhoff EP2339-0022 Standard IO"
            gSafeModuleName = "Beckhoff EP1957-0022 Safety IO"
            gCombinedModuleName = ""
            gStdCapacity = 16                 'EP2339 has 8 ports x 2 signals = 16 physical points; 10% spare leaves 14 usable
            gCombinedStdCapacity = 0
            gSafeInCapacity = 8                 'EP1957 has 8 physical safety inputs; 10% spare leaves 7 usable
            gSafeOutCapacity = 4                'EP1957 has 4 physical safety outputs; 10% spare leaves 3 usable
            gUseSafety = True
            gCombinedMVKMode = False

        Case Else
            SelectIOHardwareProfile = False
            Exit Function

    End Select

    SelectIOHardwareProfile = True

End Function

'============================================================
' STANDARD IO GENERATION
'============================================================
Private Sub GenerateStandardIORows(ByRef buf As Variant, ByRef n As Long, _
                                   ByVal device As String, ByVal deviceType As String, _
                                   ByVal prefix As String, ByVal rawPNL As String, ByVal cleanPNL As String, _
                                   ByVal pwg As String, ByVal loc As String, _
                                   ByVal inN As Long, ByVal outN As Long, ByVal stdTag As String, _
                                   ByVal keyBase As String, _
                                   ByRef StdBlockIndex As Object, ByRef StdChanUsed As Object, ByRef StdActiveKey As Object, _
                                   ByRef usedStdBlocks As Object)

    '============================================================
    ' V6.3 NO-SPLIT RULE - STANDARD IO
    '============================================================
    ' The same device must never be split across two standard IO modules.
    ' If the active module does not have enough free points for the whole
    ' device, create a new module first, then place all of that device's
    ' standard IO on the new module.
    '============================================================

    Dim reqStd As Long
    reqStd = inN + outN

    If reqStd = 0 Then Exit Sub

    Dim effStdCapacity As Long
    effStdCapacity = EffectiveCapacity(gStdCapacity)

    If reqStd > effStdCapacity Then
        FillRow buf, n, device, deviceType, "", "ERROR", _
                "Device standard IO count exceeds one module capacity. Device was not split.", _
                gStdPart, gStdModuleName, "", "", pwg, rawPNL, loc
        Exit Sub
    End If

    Dim seedDevice As String
    If stdSeedDeviceMap Is Nothing Then Set stdSeedDeviceMap = CreateObject("Scripting.Dictionary")
    If Not stdSeedDeviceMap.Exists(keyBase) Then stdSeedDeviceMap.Add keyBase, device
    seedDevice = CStr(stdSeedDeviceMap(keyBase))

    Dim stdKey As String
    stdKey = keyBase & IIf(Len(stdTag) > 0, "|" & stdTag, "|AUTO_STD")

    If Not StdActiveKey.Exists(keyBase) Then
        StartNewStdBlock StdBlockIndex, StdChanUsed, usedStdBlocks, cleanPNL, pwg, stdTag, stdKey, seedDevice
        StdActiveKey.Add keyBase, stdKey
    Else
        stdKey = StdActiveKey(keyBase)
    End If

    'If the active block cannot fit the whole device, open a new block BEFORE placing any signal.
    'V6.9 PORT-PAIR RULE:
    '  If a device needs exactly 2 standard signals and the next available point is
    '  the second point of a port, reserve that single leftover point and place the
    '  device on the next full 2-point port. If that cannot fit, start a new block.
    Dim alignedStdUsed As Long
    alignedStdUsed = AlignedUsedForTwoSignalDevice(CLng(StdChanUsed(stdKey)), reqStd)

    If effStdCapacity - alignedStdUsed < reqStd Then
        stdKey = NextStdKey(keyBase, stdKey, stdTag, StdBlockIndex)
        StartNewStdBlock StdBlockIndex, StdChanUsed, usedStdBlocks, cleanPNL, pwg, stdTag, stdKey, seedDevice
        StdActiveKey(keyBase) = stdKey
    End If

    'Reserve one leftover point when needed so 2-signal devices stay on one physical port.
    StdChanUsed(stdKey) = AlignedUsedForTwoSignalDevice(CLng(StdChanUsed(stdKey)), reqStd)

    Dim displayLabel As String
    displayLabel = CurrentStdDisplayLabel(cleanPNL, pwg, StdBlockIndex, stdTag, stdKey)

    Dim diLeft As Long, doLeft As Long
    diLeft = inN
    doLeft = outN

    Do While diLeft + doLeft > 0

        Dim chanIndex As Long
        chanIndex = CLng(StdChanUsed(stdKey)) + 1

        Dim chLabel As String, portLabel As String
        GetStandardLabels chanIndex, chLabel, portLabel

        If diLeft >= doLeft And diLeft > 0 Then
            FillRow buf, n, device, deviceType, chLabel, "DI", _
                    prefix & "_DI" & Format(inN - diLeft + 1, "000"), _
                    gStdPart, gStdModuleName, displayLabel, portLabel, pwg, rawPNL, loc
            diLeft = diLeft - 1
        ElseIf doLeft > 0 Then
            FillRow buf, n, device, deviceType, chLabel, "DO", _
                    prefix & "_DO" & Format(outN - doLeft + 1, "000"), _
                    gStdPart, gStdModuleName, displayLabel, portLabel, pwg, rawPNL, loc
            doLeft = doLeft - 1
        End If

        StdChanUsed(stdKey) = CLng(StdChanUsed(stdKey)) + 1

    Loop

End Sub

Private Function NextStdKey(ByVal keyBase As String, ByVal currentKey As String, ByRef stdTag As String, ByVal StdBlockIndex As Object) As String

    Dim currTag As String
    currTag = TagFromKey(currentKey, "STD")

    If Len(currTag) > 0 Then
        currTag = BumpTag(currTag, "STD")
        stdTag = currTag
        NextStdKey = keyBase & "|" & currTag
    Else
        NextStdKey = keyBase & "|AUTO_STD_" & CStr(CountKeysByPrefix(StdBlockIndex, keyBase) + 1)
    End If

End Function

Private Sub StartNewStdBlock(ByRef StdBlockIndex As Object, ByRef StdChanUsed As Object, _
                             ByRef usedStdBlocks As Object, _
                             ByVal panel As String, ByVal pwg As String, ByVal stdTag As String, _
                             ByRef stdKey As String, ByVal firstDevice As String)

    EnsureKey StdBlockIndex, stdKey, 0
    EnsureKey StdChanUsed, stdKey, 0

    StdBlockIndex(stdKey) = StdBlockIndex(stdKey) + 1
    StdChanUsed(stdKey) = 0

    Dim displayLabel As String
    displayLabel = NextExpansionIOBlockLabel(pwg, panel, "STD", firstDevice)

    AddUsedBlock usedStdBlocks, pwg, panel, displayLabel, gStdPart
    SetBlockID panel, pwg, displayLabel, "STD", firstDevice

    If blockLabelMap.Exists(stdKey) Then
        blockLabelMap(stdKey) = displayLabel
    Else
        blockLabelMap.Add stdKey, displayLabel
    End If

End Sub

Private Function CurrentStdDisplayLabel(ByVal panel As String, ByVal pwg As String, _
                                        ByRef StdBlockIndex As Object, _
                                        ByVal stdTag As String, ByVal stdKey As String) As String

    EnsureKey StdBlockIndex, stdKey, 1

    If blockLabelMap.Exists(stdKey) Then
        CurrentStdDisplayLabel = CStr(blockLabelMap(stdKey))
    Else
        CurrentStdDisplayLabel = NextExpansionIOBlockLabel(pwg, panel, "STD", "")
    End If

End Function

Private Sub GetStandardLabels(ByVal chanIndex As Long, ByRef chLabel As String, ByRef portLabel As String)

    'V6.2:
    '  Beckhoff EP2339-0022 and Murr IMPACT67 54631/54632 use the same
    '  dual-signal port allocation format.
    '  Example: channel 1 -> X01.1, channel 2 -> X01.2, channel 3 -> X02.1.
    Dim pairIdx As Long, subIdx As Long

    pairIdx = ((chanIndex - 1) \ 2) + 1
    subIdx = ((chanIndex - 1) Mod 2) + 1

    If gProfile = PROFILE_ETHERCAT_BECKHOFF Then
        chLabel = CStr(chanIndex - 1)
    Else
        chLabel = "DIO" & CStr(chanIndex)
    End If

    portLabel = "X" & Format(pairIdx, "00") & "." & CStr(subIdx)

End Sub

'============================================================
' SAFETY IO GENERATION - Separate safety module mode
'============================================================
Private Sub GenerateSafetyIORows(ByRef buf As Variant, ByRef n As Long, _
                                 ByVal device As String, ByVal deviceType As String, _
                                 ByVal prefix As String, ByVal rawPNL As String, ByVal cleanPNL As String, _
                                 ByVal pwg As String, ByVal loc As String, _
                                 ByVal sInN As Long, ByVal sOutN As Long, ByVal safeTag As String, _
                                 ByRef SafeBlockIndex As Object, ByRef SafeActive As Object, _
                                 ByRef usedSafeBlocks As Object)

    '============================================================
    ' V6.3 NO-SPLIT RULE - SAFETY IO
    '============================================================
    ' The same device must never be split across two safety modules.
    ' If the active safety module cannot fit all safety IO for the device,
    ' a new safety module is created before any safety signal is placed.
    '============================================================

    If sInN + sOutN = 0 Then Exit Sub

    Dim effSafeInCapacity As Long
    Dim effSafeOutCapacity As Long
    effSafeInCapacity = EffectiveCapacity(gSafeInCapacity)
    effSafeOutCapacity = EffectiveCapacity(gSafeOutCapacity)

    If sInN > effSafeInCapacity Or sOutN > effSafeOutCapacity Then
        FillRow buf, n, device, deviceType, "", "ERROR", _
                "Device safety IO count exceeds one safety module capacity. Device was not split.", _
                gSafePart, gSafeModuleName, "", "", pwg, rawPNL, loc
        Exit Sub
    End If

    Dim keyAP As String
    keyAP = cleanPNL & "|" & pwg & "|SAFE_ACTIVE"

    Dim act As Object
    Set act = GetActiveSafeDevice(SafeActive, SafeBlockIndex, cleanPNL, pwg, safeTag, usedSafeBlocks, device)

    'If current block does not have enough room for the whole device, start a new one first.
    'V6.9 PORT-PAIR RULE for Beckhoff EP1957 safety inputs:
    '  A 2-signal safety-input device must start on the first point of an input pair.
    '  If only the second point is open, reserve it and use the next full input port.
    Dim alignedSafeInUsed As Long
    alignedSafeInUsed = AlignedUsedForTwoSignalDevice(CLng(act("inUsed")), sInN)

    If effSafeInCapacity - alignedSafeInUsed < sInN Or effSafeOutCapacity - CLng(act("outUsed")) < sOutN Then
        If SafeActive.Exists(keyAP) Then SafeActive.Remove keyAP
        Set act = GetActiveSafeDevice(SafeActive, SafeBlockIndex, cleanPNL, pwg, safeTag, usedSafeBlocks, device)
    End If

    'Reserve one leftover safety-input point when needed so 2 S_IN signals stay on one port.
    act("inUsed") = AlignedUsedForTwoSignalDevice(CLng(act("inUsed")), sInN)

    Dim i As Long

    If gProfile = PROFILE_ETHERCAT_BECKHOFF Then
        'EP1957-0022 safety inputs share ports in pairs:
        'Port 1 = In1-In2, Port 2 = In3-In4, Port 3 = In5-In6, Port 4 = In7-In8.
        'A device with 2 safety inputs is written as ONE row: Channel IO = In1-In2, Port Location = 1.
        Do While sInN > 0
            Dim firstInChan As Long
            Dim inputPairUse As Long
            Dim chLabel As String
            Dim portLabel As String
            Dim pointsLeftOnPort As Long

            firstInChan = CLng(act("inUsed")) + 1
            pointsLeftOnPort = 2 - ((firstInChan - 1) Mod 2)
            inputPairUse = MinLng(pointsLeftOnPort, sInN)

            GetSafetyInputLabelsByCount firstInChan, inputPairUse, chLabel, portLabel

            FillRow buf, n, device, deviceType, chLabel, "S_DI", _
                    prefix & "_S_DI" & Format(firstInChan, "000"), _
                    gSafePart, gSafeModuleName, act("displayLabel"), portLabel, pwg, rawPNL, loc

            act("inUsed") = CLng(act("inUsed")) + inputPairUse
            sInN = sInN - inputPairUse
        Loop
    Else
        For i = 1 To sInN
            Dim inChan As Long
            inChan = CLng(act("inUsed")) + 1

            Dim chLabel2 As String, portLabel2 As String
            GetSafetyInputLabels inChan, chLabel2, portLabel2

            FillRow buf, n, device, deviceType, chLabel2, "S_DI", _
                    prefix & "_S_DI" & Format(i, "000"), _
                    gSafePart, gSafeModuleName, act("displayLabel"), portLabel2, pwg, rawPNL, loc

            act("inUsed") = CLng(act("inUsed")) + 1
        Next i
    End If

    For i = 1 To sOutN
        Dim outChan As Long
        outChan = CLng(act("outUsed")) + 1

        Dim outLabel As String, outPort As String
        GetSafetyOutputLabels outChan, outLabel, outPort

        FillRow buf, n, device, deviceType, outLabel, "S_DO", _
                prefix & "_S_DO" & Format(i, "000"), _
                gSafePart, gSafeModuleName, act("displayLabel"), outPort, pwg, rawPNL, loc

        act("outUsed") = CLng(act("outUsed")) + 1
    Next i

    If CLng(act("inUsed")) >= effSafeInCapacity And CLng(act("outUsed")) >= effSafeOutCapacity Then
        If SafeActive.Exists(keyAP) Then SafeActive.Remove keyAP
    End If

End Sub

Private Function GetActiveSafeDevice(ByRef SafeActive As Object, ByRef SafeBlockIndex As Object, _
                                     ByVal panel As String, ByVal pwg As String, ByRef safeTag As String, _
                                     ByRef usedSafeBlocks As Object, ByVal firstDevice As String) As Object

    Dim keyAP As String
    keyAP = panel & "|" & pwg & "|SAFE_ACTIVE"

    If safeSeedDeviceMap Is Nothing Then Set safeSeedDeviceMap = CreateObject("Scripting.Dictionary")
    If Not safeSeedDeviceMap.Exists(keyAP) Then safeSeedDeviceMap.Add keyAP, firstDevice

    Dim seedDevice As String
    seedDevice = CStr(safeSeedDeviceMap(keyAP))

    If SafeActive.Exists(keyAP) Then
        Set GetActiveSafeDevice = SafeActive(keyAP)
        Exit Function
    End If

    Dim tagForThis As String
    tagForThis = IIf(Len(safeTag) > 0, safeTag, "AUTO_SAFE")

    Dim safeKey As String
    safeKey = panel & "|" & pwg & "|" & MakeBlockIDByDevice(seedDevice, "SAFE") & "|" & tagForThis

    EnsureKey SafeBlockIndex, safeKey, 0
    SafeBlockIndex(safeKey) = SafeBlockIndex(safeKey) + 1

    Dim displayLabel As String
    displayLabel = NextExpansionIOBlockLabel(pwg, panel, "SAFE", seedDevice)

    AddUsedBlock usedSafeBlocks, pwg, panel, displayLabel, gSafePart
    SetBlockID panel, pwg, displayLabel, "SAFE", seedDevice

    Dim actNew As Object
    Set actNew = CreateObject("Scripting.Dictionary")
    actNew("panel") = panel
    actNew("pwg") = pwg
    actNew("key") = safeKey
    actNew("displayLabel") = displayLabel
    actNew("inUsed") = 0
    actNew("outUsed") = 0

    SafeActive.Add keyAP, actNew
    Set GetActiveSafeDevice = actNew

End Function

Private Sub GetSafetyInputLabels(ByVal chanIndex As Long, ByRef chLabel As String, ByRef portLabel As String)

    Select Case gProfile
        Case PROFILE_ETHERCAT_BECKHOFF
            GetSafetyInputLabelsByCount chanIndex, 1, chLabel, portLabel

        Case Else
            chLabel = "FDI" & CStr(chanIndex)
            portLabel = "X-FDI" & CStr(chanIndex)
    End Select

End Sub

Private Sub GetSafetyInputLabelsByCount(ByVal firstChan As Long, ByVal signalCount As Long, _
                                        ByRef chLabel As String, ByRef portLabel As String)

    'EP1957-0022 input port pattern:
    'Port Location 1 = In1-In2
    'Port Location 2 = In3-In4
    'Port Location 3 = In5-In6
    'Port Location 4 = In7-In8
    '
    'For one safety input, show the exact input used, for example In1.
    'For two safety inputs on the same port, show the paired input, for example In1-In2.
    Dim portNum As Long

    portNum = ((firstChan - 1) \ 2) + 1

    If signalCount >= 2 Then
        chLabel = "In" & CStr(firstChan) & "-In" & CStr(firstChan + 1)
    Else
        chLabel = "In" & CStr(firstChan)
    End If

    portLabel = CStr(portNum)

End Sub

Private Sub GetSafetyOutputLabels(ByVal chanIndex As Long, ByRef chLabel As String, ByRef portLabel As String)

    Select Case gProfile
        Case PROFILE_ETHERCAT_BECKHOFF
            'EP1957-0022 output port pattern:
            'Port Location 5 = Out1
            'Port Location 6 = Out2
            'Port Location 7 = Out3
            'Port Location 8 = Out4
            chLabel = "Out" & CStr(chanIndex)
            portLabel = CStr(chanIndex + 4)

        Case Else
            chLabel = "FDO" & CStr(chanIndex)
            portLabel = "X-FDO" & CStr(chanIndex)
    End Select

End Sub

'============================================================
' MVK FUSION 55514 COMBINED STANDARD + SAFETY GENERATION
'============================================================
Private Sub GenerateCombinedMVKRows(ByRef buf As Variant, ByRef n As Long, _
                                    ByVal device As String, ByVal deviceType As String, _
                                    ByVal prefix As String, ByVal rawPNL As String, ByVal cleanPNL As String, _
                                    ByVal pwg As String, ByVal loc As String, _
                                    ByVal inN As Long, ByVal outN As Long, ByVal sInN As Long, ByVal sOutN As Long, _
                                    ByVal safeTag As String, _
                                    ByRef CmbBlockIndex As Object, ByRef CmbActive As Object, _
                                    ByRef usedCombinedBlocks As Object)

    '============================================================
    ' V6.3 NO-SPLIT RULE - MVK FUSION 55514 COMBINED IO
    '============================================================
    ' The same device must never be split across two MVK 55514 modules.
    ' The device must fit in one MVK block using these resources:
    '   Safety Inputs : X0-X2 = 6 total points
    '   Safety Outputs: X3    = 2 total points
    '   Standard DIO  : X4-X7 = 8 total points
    '
    ' If the active MVK block cannot fit the full device, a new MVK block
    ' is created before placing any of that device's signals.
    '============================================================

    Dim reqDIO As Long
    reqDIO = inN + outN

    If reqDIO + sInN + sOutN = 0 Then Exit Sub

    Dim effCombinedStdCapacity As Long
    Dim effCombinedSafeInCapacity As Long
    Dim effCombinedSafeOutCapacity As Long
    effCombinedStdCapacity = EffectiveCapacity(gCombinedStdCapacity)
    effCombinedSafeInCapacity = EffectiveCapacity(gSafeInCapacity)
    effCombinedSafeOutCapacity = EffectiveCapacity(gSafeOutCapacity)

    If reqDIO > effCombinedStdCapacity Or sInN > effCombinedSafeInCapacity Or sOutN > effCombinedSafeOutCapacity Then
        FillRow buf, n, device, deviceType, "", "ERROR", _
                "Device IO count exceeds one MVK 55514 capacity. Device was not split.", _
                gCombinedPart, gCombinedModuleName, "", "", pwg, rawPNL, loc
        Exit Sub
    End If

    Dim keyAP As String
    keyAP = cleanPNL & "|" & pwg & "|COMBINED_ACTIVE"

    Dim act As Object
    Set act = GetActiveCombinedMVK(CmbBlockIndex, CmbActive, cleanPNL, pwg, safeTag, usedCombinedBlocks, device)

    'If current MVK does not have enough room for the whole device, start a new MVK before placing any signal.
    'V6.9 PORT-PAIR RULE for MVK Fusion:
    '  Exactly 2 DIO, FDI, or FDO signals must start on the first point of a 2-point port.
    '  If only one point is left in the active port, reserve it and use the next full port.
    Dim alignedDIOUsed As Long
    Dim alignedFDIUsed As Long
    Dim alignedFDOUsed As Long

    alignedDIOUsed = AlignedUsedForTwoSignalDevice(CLng(act("dioUsed")), reqDIO)
    alignedFDIUsed = AlignedUsedForTwoSignalDevice(CLng(act("fdiUsed")), sInN)
    alignedFDOUsed = AlignedUsedForTwoSignalDevice(CLng(act("fdoUsed")), sOutN)

    If effCombinedStdCapacity - alignedDIOUsed < reqDIO _
       Or effCombinedSafeInCapacity - alignedFDIUsed < sInN _
       Or effCombinedSafeOutCapacity - alignedFDOUsed < sOutN Then

        If CmbActive.Exists(keyAP) Then CmbActive.Remove keyAP
        Set act = GetActiveCombinedMVK(CmbBlockIndex, CmbActive, cleanPNL, pwg, safeTag, usedCombinedBlocks, device)
    End If

    'Reserve one leftover point when needed so 2-signal MVK devices stay on one physical port.
    act("dioUsed") = AlignedUsedForTwoSignalDevice(CLng(act("dioUsed")), reqDIO)
    act("fdiUsed") = AlignedUsedForTwoSignalDevice(CLng(act("fdiUsed")), sInN)
    act("fdoUsed") = AlignedUsedForTwoSignalDevice(CLng(act("fdoUsed")), sOutN)

    Dim i As Long

    'Safety inputs first: X0.1, X0.2, X1.1, X1.2, X2.1, X2.2
    For i = 1 To sInN
        Dim fdiChan As Long
        fdiChan = CLng(act("fdiUsed")) + 1

        FillRow buf, n, device, deviceType, "FDI" & CStr(fdiChan), "S_DI", _
                prefix & "_S_DI" & Format(i, "000"), _
                gCombinedPart, gCombinedModuleName, act("displayLabel"), _
                GetMVK55514SafetyInputPort(fdiChan), pwg, rawPNL, loc

        act("fdiUsed") = CLng(act("fdiUsed")) + 1
    Next i

    'Safety outputs: X3.1, X3.2
    For i = 1 To sOutN
        Dim fdoChan As Long
        fdoChan = CLng(act("fdoUsed")) + 1

        FillRow buf, n, device, deviceType, "FDO" & CStr(fdoChan), "S_DO", _
                prefix & "_S_DO" & Format(i, "000"), _
                gCombinedPart, gCombinedModuleName, act("displayLabel"), _
                GetMVK55514SafetyOutputPort(fdoChan), pwg, rawPNL, loc

        act("fdoUsed") = CLng(act("fdoUsed")) + 1
    Next i

    'Standard DIO: X4.1, X4.2, X5.1, X5.2, X6.1, X6.2, X7.1, X7.2
    Dim diLeft As Long, doLeft As Long
    diLeft = inN
    doLeft = outN

    Do While diLeft + doLeft > 0
        Dim dioChan As Long
        dioChan = CLng(act("dioUsed")) + 1

        If diLeft >= doLeft And diLeft > 0 Then
            FillRow buf, n, device, deviceType, "DIO" & CStr(dioChan), "DI", _
                    prefix & "_DI" & Format(inN - diLeft + 1, "000"), _
                    gCombinedPart, gCombinedModuleName, act("displayLabel"), _
                    GetMVK55514DIOPort(dioChan), pwg, rawPNL, loc
            diLeft = diLeft - 1
        ElseIf doLeft > 0 Then
            FillRow buf, n, device, deviceType, "DIO" & CStr(dioChan), "DO", _
                    prefix & "_DO" & Format(outN - doLeft + 1, "000"), _
                    gCombinedPart, gCombinedModuleName, act("displayLabel"), _
                    GetMVK55514DIOPort(dioChan), pwg, rawPNL, loc
            doLeft = doLeft - 1
        End If

        act("dioUsed") = CLng(act("dioUsed")) + 1
    Loop

    If CLng(act("dioUsed")) >= effCombinedStdCapacity _
       And CLng(act("fdiUsed")) >= effCombinedSafeInCapacity _
       And CLng(act("fdoUsed")) >= effCombinedSafeOutCapacity Then
        If CmbActive.Exists(keyAP) Then CmbActive.Remove keyAP
    End If

End Sub

Private Function GetMVK55514SafetyInputPort(ByVal chanIndex As Long) As String

    'MVK Fusion CIP Safety 55514 safety input ports:
    '  X0 = X0.1 and X0.2
    '  X1 = X1.1 and X1.2
    '  X2 = X2.1 and X2.2
    Dim portNum As Long
    Dim pointNum As Long

    portNum = (chanIndex - 1) \ 2
    pointNum = ((chanIndex - 1) Mod 2) + 1

    GetMVK55514SafetyInputPort = "X" & CStr(portNum) & "." & CStr(pointNum)

End Function

Private Function GetMVK55514SafetyOutputPort(ByVal chanIndex As Long) As String

    'MVK Fusion CIP Safety 55514 safety output port:
    '  X3 = X3.1 and X3.2
    GetMVK55514SafetyOutputPort = "X3." & CStr(chanIndex)

End Function

Private Function GetMVK55514DIOPort(ByVal chanIndex As Long) As String

    'MVK Fusion CIP Safety 55514 standard DIO ports:
    '  X4 = X4.1 and X4.2
    '  X5 = X5.1 and X5.2
    '  X6 = X6.1 and X6.2
    '  X7 = X7.1 and X7.2
    Dim portNum As Long
    Dim pointNum As Long

    portNum = 4 + ((chanIndex - 1) \ 2)
    pointNum = ((chanIndex - 1) Mod 2) + 1

    GetMVK55514DIOPort = "X" & CStr(portNum) & "." & CStr(pointNum)

End Function

Private Function GetActiveCombinedMVK(ByRef CmbBlockIndex As Object, ByRef CmbActive As Object, _
                                      ByVal panel As String, ByVal pwg As String, ByVal tagText As String, _
                                      ByRef usedCombinedBlocks As Object, ByVal firstDevice As String) As Object

    Dim keyAP As String
    keyAP = panel & "|" & pwg & "|COMBINED_ACTIVE"

    If combinedSeedDeviceMap Is Nothing Then Set combinedSeedDeviceMap = CreateObject("Scripting.Dictionary")
    If Not combinedSeedDeviceMap.Exists(keyAP) Then combinedSeedDeviceMap.Add keyAP, firstDevice

    Dim seedDevice As String
    seedDevice = CStr(combinedSeedDeviceMap(keyAP))

    If CmbActive.Exists(keyAP) Then
        Set GetActiveCombinedMVK = CmbActive(keyAP)
        Exit Function
    End If

    Dim tagForThis As String
    tagForThis = IIf(Len(tagText) > 0, tagText, "AUTO_MVK")

    Dim cmbKey As String
    cmbKey = panel & "|" & pwg & "|" & MakeBlockIDByDevice(seedDevice, "COMBINED") & "|" & tagForThis

    EnsureKey CmbBlockIndex, cmbKey, 0
    CmbBlockIndex(cmbKey) = CmbBlockIndex(cmbKey) + 1

    Dim displayLabel As String
    displayLabel = NextExpansionIOBlockLabel(pwg, panel, "COMBINED", seedDevice)

    AddUsedBlock usedCombinedBlocks, pwg, panel, displayLabel, gCombinedPart
    SetBlockID panel, pwg, displayLabel, "COMBINED", seedDevice

    Dim actNew As Object
    Set actNew = CreateObject("Scripting.Dictionary")
    actNew("panel") = panel
    actNew("pwg") = pwg
    actNew("key") = cmbKey
    actNew("displayLabel") = displayLabel
    actNew("dioUsed") = 0
    actNew("fdiUsed") = 0
    actNew("fdoUsed") = 0

    CmbActive.Add keyAP, actNew
    Set GetActiveCombinedMVK = actNew

End Function

'============================================================
' OUTPUT HELPERS
'============================================================
Private Sub SetupPanelHeader(ByVal ws As Worksheet)

    If Len(CStr(ws.Cells(1, 1).Value)) = 0 Then
        ws.Range("A1:N1").Value = Array("Device", "Device Type", "Channel IO", "Type", _
                                        "Signal Name", "Port Location", "Part# Ref.", "Module Type", _
                                        "IO Block", "Block ID", "PWG", "Panel", "Location", "Notes")
    End If

    With ws.Rows(1)
        .Font.Bold = True
        .Interior.Color = RGB(220, 220, 220)
    End With

    ws.Columns("A:N").AutoFit

End Sub

Private Sub WriteBufferToSheet(ByVal ws As Worksheet, ByVal startRow As Long, _
                               ByRef buf As Variant, ByVal rowCount As Long, ByVal colCount As Long)

    Dim outArr() As Variant
    ReDim outArr(1 To rowCount, 1 To colCount)

    Dim r As Long, c As Long
    For r = 1 To rowCount
        For c = 1 To colCount
            outArr(r, c) = buf(r, c)
        Next c
    Next r

    ws.Cells(startRow, 1).Resize(rowCount, colCount).Value = outArr

End Sub

Private Sub FillRow(ByRef buf As Variant, ByRef n As Long, _
                    ByVal device As String, ByVal devType As String, ByVal chLabel As String, _
                    ByVal ioType As String, ByVal sigName As String, _
                    ByVal partNum As String, ByVal modType As String, _
                    ByVal ioBlockDisplay As String, ByVal portLabel As String, _
                    ByVal pwg As String, ByVal pnl As String, ByVal loc As String)

    Dim blkKey As String, blkID As String
    blkKey = pwg & "|" & CleanSheetName(pnl) & "|" & ioBlockDisplay

    If blockIDMap.Exists(blkKey) Then
        blkID = blockIDMap(blkKey)
    Else
        blkID = ""
    End If

    buf(n, 1) = device
    buf(n, 2) = devType
    buf(n, 3) = chLabel
    buf(n, 4) = ioType
    buf(n, 5) = sigName
    buf(n, 6) = portLabel
    buf(n, 7) = partNum
    buf(n, 8) = modType
    buf(n, 9) = ioBlockDisplay
    buf(n, 10) = blkID
    buf(n, 11) = pwg
    buf(n, 12) = pnl
    buf(n, 13) = loc
    buf(n, 14) = ""

    n = n + 1

End Sub

'============================================================
' SUMMARY SHEETS
'============================================================
Private Sub GeneratePWGSummary(ByVal dictPWG As Object, ByRef wsSummary As Worksheet, _
                               ByVal usedStdBlocks As Object, ByVal usedSafeBlocks As Object, ByVal usedCombinedBlocks As Object, _
                               ByVal gStdIn As Object, ByVal gStdOut As Object, _
                               ByVal gSafeIn As Object, ByVal gSafeOut As Object, _
                               ByVal overwriteChoice As VbMsgBoxResult)

    Set wsSummary = GetOrCreateSheet("PWG_Summary", True)
    wsSummary.Cells.Clear

    wsSummary.Range("A1:J1").Value = Array("Power Group", "Network", "Profile", "Std IN", "Std OUT", "Safe IN", "Safe OUT", _
                                           "Std Blocks", "Safe Blocks", "Total Physical Blocks")

    With wsSummary.Rows(1)
        .Font.Bold = True
        .Interior.Color = RGB(220, 220, 220)
    End With

    Dim rowSum As Long
    rowSum = 2

    Dim pwgKey As Variant
    For Each pwgKey In dictPWG.Keys
        Dim stdCount As Long, safeCount As Long, cmbCount As Long, totalCount As Long
        stdCount = CountKeysByPrefix(usedStdBlocks, CStr(pwgKey))
        safeCount = CountKeysByPrefix(usedSafeBlocks, CStr(pwgKey))
        cmbCount = CountKeysByPrefix(usedCombinedBlocks, CStr(pwgKey))

        totalCount = stdCount + safeCount + cmbCount

        wsSummary.Cells(rowSum, 1).Resize(1, 10).Value = Array(pwgKey, gNetworkProtocol, gProfile, _
            Nz(gStdIn(pwgKey)), Nz(gStdOut(pwgKey)), Nz(gSafeIn(pwgKey)), Nz(gSafeOut(pwgKey)), _
            stdCount + cmbCount, safeCount + cmbCount, totalCount)
        rowSum = rowSum + 1
    Next pwgKey

    wsSummary.Columns("A:J").AutoFit

End Sub

Private Sub GenerateNetworkAddressSheet(ByVal dictPWG As Object, ByRef wsNetwork As Worksheet, _
                                        ByVal usedStdBlocks As Object, ByVal usedSafeBlocks As Object, ByVal usedCombinedBlocks As Object, _
                                        ByVal overwriteChoice As VbMsgBoxResult, _
                                        ByVal NET_STD_START As Long, ByVal NET_SAFE_START As Long, ByVal NET_COMBINED_START As Long)

    Set wsNetwork = GetOrCreateSheet("Network_IO_Address", True)
    wsNetwork.Cells.Clear

    wsNetwork.Range("A1:I1").Value = Array("Network", "Power Group", "Panel", "IO Block", "Module Part Number", _
                                           "Start Addr", "End Addr", "Channel Count", "Comments")

    With wsNetwork.Rows(1)
        .Font.Bold = True
        .Interior.Color = RGB(220, 220, 220)
    End With

    Dim addrRow As Long
    addrRow = 2

    Dim pwgKey As Variant, k As Variant, parts() As String
    Dim stdStart As Long, safeStart As Long, cmbStart As Long

    For Each pwgKey In dictPWG.Keys

        stdStart = NET_STD_START
        safeStart = NET_SAFE_START
        cmbStart = NET_COMBINED_START

        For Each k In usedCombinedBlocks.Keys
            If StartsWith(CStr(k), CStr(pwgKey) & "|") Then
                parts = Split(CStr(k), "|")
                wsNetwork.Cells(addrRow, 1).Resize(1, 9).Value = Array(gNetworkProtocol, parts(0), parts(1), parts(2), _
                    CStr(usedCombinedBlocks(k)), cmbStart, cmbStart + 11, 12, "Combined standard/safety MVK block")
                addrRow = addrRow + 1
                cmbStart = cmbStart + 12
            End If
        Next k

        For Each k In usedStdBlocks.Keys
            If StartsWith(CStr(k), CStr(pwgKey) & "|") Then
                parts = Split(CStr(k), "|")
                wsNetwork.Cells(addrRow, 1).Resize(1, 9).Value = Array(gNetworkProtocol, parts(0), parts(1), parts(2), _
                    CStr(usedStdBlocks(k)), stdStart, stdStart + gStdCapacity - 1, gStdCapacity, "Standard IO")
                addrRow = addrRow + 1
                stdStart = stdStart + gStdCapacity
            End If
        Next k

        For Each k In usedSafeBlocks.Keys
            If StartsWith(CStr(k), CStr(pwgKey) & "|") Then
                parts = Split(CStr(k), "|")
                wsNetwork.Cells(addrRow, 1).Resize(1, 9).Value = Array(gNetworkProtocol, parts(0), parts(1), parts(2), _
                    CStr(usedSafeBlocks(k)), safeStart, safeStart + 11, 12, "Safety IO")
                addrRow = addrRow + 1
                safeStart = safeStart + 12
            End If
        Next k
    Next pwgKey

    wsNetwork.Columns("A:I").AutoFit

End Sub

Private Sub GenerateIOBlockSummary(ByVal usedStdBlocks As Object, ByVal usedSafeBlocks As Object, ByVal usedCombinedBlocks As Object, _
                                   ByVal overwriteChoice As VbMsgBoxResult)

    Dim ws As Worksheet
    Set ws = GetOrCreateSheet("IO_Block_Summary", True)
    ws.Cells.Clear

    ws.Range("A1:H1").Value = Array("Network", "Power Group", "Panel", "IO Block", "Block ID", "Module Part Number", "Module Type", "Profile")

    With ws.Rows(1)
        .Font.Bold = True
        .Interior.Color = RGB(220, 220, 220)
    End With

    Dim rowOut As Long
    rowOut = 2

    Dim k As Variant
    For Each k In usedCombinedBlocks.Keys
        WriteBlockSummaryRow ws, rowOut, CStr(k), CStr(usedCombinedBlocks(k)), gCombinedModuleName, gProfile
    Next k

    For Each k In usedStdBlocks.Keys
        WriteBlockSummaryRow ws, rowOut, CStr(k), CStr(usedStdBlocks(k)), gStdModuleName, gProfile
    Next k

    For Each k In usedSafeBlocks.Keys
        WriteBlockSummaryRow ws, rowOut, CStr(k), CStr(usedSafeBlocks(k)), gSafeModuleName, gProfile
    Next k

    ws.Columns("A:H").AutoFit

End Sub

Private Sub WriteBlockSummaryRow(ByVal ws As Worksheet, ByRef rowOut As Long, ByVal keyText As String, _
                                 ByVal partNum As String, ByVal moduleType As String, ByVal profileText As String)

    Dim parts() As String
    parts = Split(keyText, "|")

    If UBound(parts) < 2 Then Exit Sub

    Dim pwg As String, panel As String, displayLabel As String, blkKey As String, blkID As String
    pwg = parts(0)
    panel = parts(1)
    displayLabel = parts(2)
    blkKey = pwg & "|" & panel & "|" & displayLabel

    blkID = ""
    If blockIDMap.Exists(blkKey) Then blkID = blockIDMap(blkKey)

    ws.Cells(rowOut, 1).Resize(1, 8).Value = Array(gNetworkProtocol, pwg, panel, displayLabel, blkID, partNum, moduleType, profileText)
    rowOut = rowOut + 1

End Sub

'============================================================
' BLOCK ID / LABEL HELPERS
'============================================================
Private Function MakeBlockIDByDevice(ByVal firstDevice As String, ByVal blockKind As String) As String

    Dim prefix As String
    prefix = Trim$(firstDevice)

    If Len(prefix) >= 4 Then
        prefix = Left$(prefix, 4)
    ElseIf Len(prefix) > 0 Then
        prefix = prefix & String(4 - Len(prefix), "_")
    Else
        prefix = "UNKN"
    End If

    Select Case UCase$(blockKind)
        Case "SAFE"
            MakeBlockIDByDevice = prefix & "-IO/S"
        Case "COMBINED"
            MakeBlockIDByDevice = prefix & "-IO/C"
        Case Else
            MakeBlockIDByDevice = prefix & "-IO/D"
    End Select

End Function

Private Function NextExpansionIOBlockLabel(ByVal pwg As String, ByVal panel As String, _
                                           ByVal blockKind As String, ByVal firstDevice As String) As String

    'V6.6 CORRECTION:
    '  IO Block display label must keep the previous format:
    '       Part# Ref. + PG/PWG
    '  Example:
    '       EP2339-0022 PG2330
    '
    '  The expansion suffix is ONLY added when the SAME Block ID needs
    '  another physical IO module within the SAME PWG:
    '       EP2339-0022 PG2330 (x2)
    '       EP2339-0022 PG2330 (x3)
    '
    '  Block ID remains stored separately in the Block ID column.

    Dim blockID As String
    blockID = MakeBlockIDByDevice(firstDevice, blockKind)

    Dim modulePart As String
    modulePart = ModulePartByKind(blockKind)

    If Len(modulePart) = 0 Then modulePart = "IO_BLOCK"

    Dim baseLabel As String
    baseLabel = modulePart & " PG" & CStr(pwg)

    Dim expKey As String
    expKey = CStr(pwg) & "|" & blockID

    Dim expNum As Long
    If blockExpansionMap Is Nothing Then Set blockExpansionMap = CreateObject("Scripting.Dictionary")

    If blockExpansionMap.Exists(expKey) Then
        expNum = CLng(blockExpansionMap(expKey)) + 1
        blockExpansionMap(expKey) = expNum
    Else
        expNum = 1
        blockExpansionMap.Add expKey, expNum
    End If

    If expNum <= 1 Then
        NextExpansionIOBlockLabel = baseLabel
    Else
        NextExpansionIOBlockLabel = baseLabel & " (x" & CStr(expNum) & ")"
    End If

End Function

Private Function ModulePartByKind(ByVal blockKind As String) As String

    Select Case UCase$(Trim$(blockKind))
        Case "SAFE"
            ModulePartByKind = gSafePart
        Case "COMBINED"
            ModulePartByKind = gCombinedPart
        Case Else
            ModulePartByKind = gStdPart
    End Select

End Function

Private Sub SetBlockID(ByVal panel As String, ByVal pwg As String, ByVal displayLabel As String, _
                       ByVal blockKind As String, ByVal firstDevice As String)

    If Len(firstDevice) = 0 Then Exit Sub

    Dim k As String
    k = pwg & "|" & panel & "|" & displayLabel

    If blockIDMap.Exists(k) Then Exit Sub

    blockIDMap.Add k, MakeBlockIDByDevice(firstDevice, blockKind)

End Sub

Private Sub AddUsedBlock(ByRef dict As Object, ByVal pwg As String, ByVal panel As String, _
                         ByVal displayLabel As String, ByVal modulePart As String)

    Dim key As String
    key = pwg & "|" & panel & "|" & displayLabel

    If Not dict.Exists(key) Then dict.Add key, modulePart

End Sub

Private Function NormalizeBlockTag(ByVal raw As String, ByVal kind As String) As String

    raw = Trim$(raw)
    If Len(raw) = 0 Then Exit Function

    If IsNumeric(raw) Then
        If CLng(raw) >= 1 Then NormalizeBlockTag = kind & CLng(raw)
        Exit Function
    End If

    If UCase$(Left$(raw, Len(kind))) = kind Then
        NormalizeBlockTag = kind & ExtractTrailingNumber(raw)
    End If

End Function

Private Function ExtractTrailingNumber(ByVal s As String) As Long

    Dim i As Long, num As String, ch As String

    For i = Len(s) To 1 Step -1
        ch = Mid$(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            num = ch & num
        Else
            Exit For
        End If
    Next i

    If Len(num) > 0 Then ExtractTrailingNumber = CLng(num)

End Function

Private Function BumpTag(ByVal tag As String, ByVal kind As String) As String

    Dim n As Long
    n = ExtractTrailingNumber(tag)

    If n <= 0 Then
        BumpTag = kind & "1"
    Else
        BumpTag = kind & CStr(n + 1)
    End If

End Function

Private Function TagFromKey(ByVal k As String, ByVal kind As String) As String

    Dim p As Long
    p = InStrRev(k, "|")

    If p > 0 Then
        Dim tail As String
        tail = Mid$(k, p + 1)
        If UCase$(Left$(tail, Len(kind))) = kind Then TagFromKey = tail
    End If

End Function

Private Function EffectiveCapacity(ByVal fullCapacity As Long) As Long

    '============================================================
    ' Effective capacity used for placement.
    '
    ' The module's full physical capacity must be stored in gStdCapacity /
    ' gSafeInCapacity / gSafeOutCapacity. This function then reserves
    ' approximately 10% spare capacity.
    '
    ' Important examples:
    '   EP2339-0022 standard IO: 16 physical points -> 14 usable points
    '   Murr IMPACT67 standard IO: 16 physical points -> 14 usable points
    '   EP1957 safety input: 8 physical inputs -> 7 usable inputs
    '   EP1957 safety output: 4 physical outputs -> 3 usable outputs
    '============================================================

    Dim spare As Long

    If fullCapacity <= 0 Then
        EffectiveCapacity = 0
    ElseIf fullCapacity < 4 Then
        EffectiveCapacity = fullCapacity
    Else
        spare = CeilDblToLong(CDbl(fullCapacity) * 0.1)
        EffectiveCapacity = fullCapacity - spare
        If EffectiveCapacity < 1 Then EffectiveCapacity = 1
    End If

End Function

Private Function CeilDblToLong(ByVal valueIn As Double) As Long

    Dim whole As Long
    whole = CLng(Fix(valueIn))

    If valueIn > CDbl(whole) Then
        CeilDblToLong = whole + 1
    Else
        CeilDblToLong = whole
    End If

End Function

'============================================================
' GENERAL HELPERS
'============================================================
Private Function HeaderMap(ws As Worksheet, headerRow As Long) As Object

    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim lastCol As Long
    lastCol = ws.Cells(headerRow, ws.Columns.Count).End(xlToLeft).Column

    Dim c As Long, key As String
    For c = 1 To lastCol
        key = LCase$(Trim$(CStr(ws.Cells(headerRow, c).Value)))
        If Len(key) > 0 Then
            If Not dict.Exists(key) Then dict.Add key, c
        End If
    Next c

    Set HeaderMap = dict

End Function

Private Function GetHeaderCol(ByVal dict As Object, ByVal headerName As String) As Long

    headerName = LCase$(Trim$(headerName))

    If dict.Exists(headerName) Then
        GetHeaderCol = CLng(dict(headerName))
    Else
        GetHeaderCol = 0
    End If

End Function

Private Function GetOrCreateSheet(ByVal sheetName As String, ByVal clearIfExists As Boolean) As Worksheet

    Dim ws As Worksheet

    On Error Resume Next
    Set ws = ThisWorkbook.Sheets(sheetName)
    On Error GoTo 0

    If ws Is Nothing Then
        Set ws = ThisWorkbook.Sheets.Add(After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.Count))
        ws.Name = sheetName
    ElseIf clearIfExists Then
        ws.Cells.Clear
    End If

    Set GetOrCreateSheet = ws

End Function

Private Function FindSheetInsensitive(ByVal nameLike As String) As Worksheet

    Dim sh As Worksheet

    For Each sh In ThisWorkbook.Worksheets
        If StrComp(sh.Name, nameLike, vbTextCompare) = 0 Then
            Set FindSheetInsensitive = sh
            Exit Function
        End If
    Next sh

End Function

Private Function CleanSheetName(nameStr As String) As String

    Dim invalidChars As Variant
    invalidChars = Array("/", "\", "[", "]", "*", "?", ":", "'")

    Dim c As Variant
    For Each c In invalidChars
        nameStr = Replace(nameStr, c, "_")
    Next c

    nameStr = Trim$(nameStr)

    If Len(nameStr) > 31 Then nameStr = Left$(nameStr, 31)
    If Len(nameStr) = 0 Then nameStr = "Panel"

    CleanSheetName = nameStr

End Function

Private Function CleanTagPrefix(pnlName As String) As String

    Dim r As String
    r = Trim$(pnlName)

    r = Replace(r, " ", "_")
    r = Replace(r, "-", "_")
    r = Replace(r, "/", "_")
    r = Replace(r, "\", "_")
    r = Replace(r, ":", "_")
    r = Replace(r, ".", "_")

    If Len(r) > 20 Then r = Left$(r, 20)

    CleanTagPrefix = UCase$(r)

End Function

Private Sub EnsurePWGGlobal(ByRef gStdIn As Object, ByRef gStdOut As Object, _
                            ByRef gSafeIn As Object, ByRef gSafeOut As Object, _
                            ByVal pwg As String)

    If Not gStdIn.Exists(pwg) Then gStdIn.Add pwg, 0
    If Not gStdOut.Exists(pwg) Then gStdOut.Add pwg, 0
    If Not gSafeIn.Exists(pwg) Then gSafeIn.Add pwg, 0
    If Not gSafeOut.Exists(pwg) Then gSafeOut.Add pwg, 0

End Sub

Private Sub EnsureKey(ByRef dict As Object, ByVal key As String, ByVal init As Long)
    If Not dict.Exists(key) Then dict.Add key, init
End Sub

Private Sub Bump(ByRef dict As Object, ByVal key As String, ByVal delta As Long)
    If dict.Exists(key) Then
        dict(key) = dict(key) + delta
    Else
        dict.Add key, delta
    End If
End Sub

Private Function CountKeysByPrefix(ByVal dict As Object, ByVal prefix As String) As Long

    Dim k As Variant, cnt As Long

    For Each k In dict.Keys
        If StartsWith(CStr(k), prefix & "|") Then cnt = cnt + 1
    Next k

    CountKeysByPrefix = cnt

End Function

Private Function StartsWith(ByVal s As String, ByVal pre As String) As Boolean
    StartsWith = Len(s) >= Len(pre) And StrComp(Left$(s, Len(pre)), pre, vbBinaryCompare) = 0
End Function


Private Function AlignedUsedForTwoSignalDevice(ByVal usedCount As Long, ByVal requestedSignals As Long) As Long

    '============================================================
    ' V6.9 PORT-PAIR ALIGNMENT HELPER
    '============================================================
    ' Dual-signal port modules use two points per physical port:
    '   Channel 1 = Port .1
    '   Channel 2 = Port .2
    '   Channel 3 = Next Port .1
    '
    ' If the next available point is the second point of a port and the
    ' device requires exactly two signals, this reserves the leftover point
    ' so the device starts on the next full port.
    '
    ' This is intentionally applied ONLY to exactly 2-signal devices.
    ' Devices with more than 2 signals are allowed to continue across ports.
    '============================================================

    If requestedSignals = 2 And (usedCount Mod 2 = 1) Then
        AlignedUsedForTwoSignalDevice = usedCount + 1
    Else
        AlignedUsedForTwoSignalDevice = usedCount
    End If

End Function

Private Function MinLng(ByVal a As Long, ByVal b As Long) As Long

    If a <= b Then
        MinLng = a
    Else
        MinLng = b
    End If

End Function

Private Function MaxLng(ByVal a As Long, ByVal b As Long) As Long
    If a >= b Then MaxLng = a Else MaxLng = b
End Function

Private Function Nz(v As Variant) As Long
    If IsEmpty(v) Or VarType(v) = vbEmpty Or Trim$(CStr(v)) = "" Then
        Nz = 0
    Else
        Nz = CLng(v)
    End If
End Function

'============================================================
' STATUS BAR PROGRESS
'============================================================
Private Sub PB_Init(total As Long, msg As String)
    progressMax = total
    Application.StatusBar = msg
End Sub

Private Sub PB_Update(current As Long, Optional statusText As String = "")

    If progressMax <= 0 Then Exit Sub

    Dim p As Double
    p = CDbl(current) / CDbl(progressMax)

    Application.StatusBar = "Progress: " & Format(p, "0%") & IIf(Len(statusText) > 0, " | " & statusText, "")
    DoEvents

End Sub

Private Sub PB_Done(Optional msg As String)
    Application.StatusBar = IIf(Len(msg) > 0, msg, "Done.")
End Sub
