Attribute VB_Name = "frmIOBlockSelector"
Attribute VB_Base = "0{C7809D9A-D820-47A1-A887-B3D1109A4D70}{CFD7297F-CC06-4F6C-85B5-C614318EA17F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit

'============================================================
' UserForm: frmIOBlockSelector
' Author: Lee Pierre
'
' PURPOSE:
'   Lets the user select the network protocol and IO module profile
'   before running OPTION_IO_V6_RELEASED.
'
' RETURN VALUES USED BY MAIN CODE:
'   SelectedProtocol
'   SelectedProfile
'   Cancelled
'
' IMPORTANT:
'   These are Public variables, not Property Get procedures.
'============================================================

Public SelectedProtocol As String
Public SelectedProfile As String
Public Cancelled As Boolean

Private Sub UserForm_Initialize()

    Me.Caption = "Select IO Network / Module"

    'Lock form size
    Me.Width = 560
    Me.Height = 330
    Me.StartUpPosition = 1
    Me.BorderStyle = fmBorderStyleSingle

    'Default return values
    SelectedProtocol = ""
    SelectedProfile = ""
    Cancelled = True

    'Frame captions
    fraNetwork.Caption = "Network Protocol"
    fraModule.Caption = "IO Block Module"

    'Network options
    optEtherNetIP.Caption = "Ethernet/IP"
    optEtherCAT.Caption = "EtherCAT"

    'Buttons
    cmdOK.Caption = "Generate IO"
    cmdCancel.Caption = "Cancel"

    'Default selection
    optEtherNetIP.Value = True

    ApplyLayout
    UpdateModuleOptions

End Sub

Private Sub UserForm_Activate()

    'Force size again for Windows display scaling
    Me.Width = 560
    Me.Height = 330

End Sub

Private Sub UserForm_Resize()

    'Prevents Excel/Windows scaling from shrinking the form
    Static resizing As Boolean

    If resizing Then Exit Sub

    resizing = True
    Me.Width = 560
    Me.Height = 330
    resizing = False

End Sub

Private Sub optEtherNetIP_Click()
    UpdateModuleOptions
End Sub

Private Sub optEtherCAT_Click()
    UpdateModuleOptions
End Sub

Private Sub UpdateModuleOptions()

    If optEtherNetIP.Value = True Then

        SelectedProtocol = "Ethernet/IP"

        optModule1.Caption = "Option 1: MVK Fusion CIP Safety 55514 + Murr Impact67 54631"
        optModule2.Caption = "Option 2: MVK Fusion CIP Safety 55514 Only"

        optModule1.Value = True

    ElseIf optEtherCAT.Value = True Then

        SelectedProtocol = "EtherCAT"

        optModule1.Caption = "Option 1: Murr Impact67 54632 + [NO SAFETY MODULE]"
        optModule2.Caption = "Option 2: Beckhoff EP2339-0022 + EP1957-0022"

        optModule1.Value = True

    End If

End Sub

Private Sub cmdOK_Click()

    If optEtherNetIP.Value = True Then

        SelectedProtocol = "Ethernet/IP"

        If optModule1.Value = True Then
            SelectedProfile = "ETHERNET_MVK_IMPACT"
        ElseIf optModule2.Value = True Then
            SelectedProfile = "ETHERNET_MVK_ONLY"
        End If

    ElseIf optEtherCAT.Value = True Then

        SelectedProtocol = "EtherCAT"

        If optModule1.Value = True Then
            SelectedProfile = "ETHERCAT_IMPACT"
        ElseIf optModule2.Value = True Then
            SelectedProfile = "ETHERCAT_BECKHOFF"
        End If

    End If

    If Len(SelectedProfile) = 0 Then
        MsgBox "Please select an IO block module option.", vbExclamation, "Missing Selection"
        Exit Sub
    End If

    Cancelled = False
    Me.Hide

End Sub

Private Sub cmdCancel_Click()

    SelectedProtocol = ""
    SelectedProfile = ""
    Cancelled = True
    Me.Hide

End Sub

Private Sub ApplyLayout()

    'Main form
    Me.Width = 560
    Me.Height = 330

    'Network frame
    fraNetwork.Left = 18
    fraNetwork.Top = 18
    fraNetwork.Width = 510
    fraNetwork.Height = 85
    fraNetwork.Font.Size = 10
    fraNetwork.Font.Bold = True

    optEtherNetIP.Left = 18
    optEtherNetIP.Top = 28
    optEtherNetIP.Width = 170
    optEtherNetIP.Height = 24
    optEtherNetIP.Font.Size = 10

    optEtherCAT.Left = 220
    optEtherCAT.Top = 28
    optEtherCAT.Width = 170
    optEtherCAT.Height = 24
    optEtherCAT.Font.Size = 10

    'Module frame
    fraModule.Left = 18
    fraModule.Top = 115
    fraModule.Width = 510
    fraModule.Height = 125
    fraModule.Font.Size = 10
    fraModule.Font.Bold = True

    optModule1.Left = 18
    optModule1.Top = 30
    optModule1.Width = 465
    optModule1.Height = 34
    optModule1.Font.Size = 10

    optModule2.Left = 18
    optModule2.Top = 72
    optModule2.Width = 465
    optModule2.Height = 34
    optModule2.Font.Size = 10

    'Buttons
    cmdOK.Left = 155
    cmdOK.Top = 260
    cmdOK.Width = 110
    cmdOK.Height = 34
    cmdOK.Font.Size = 10
    cmdOK.Font.Bold = True

    cmdCancel.Left = 285
    cmdCancel.Top = 260
    cmdCancel.Width = 110
    cmdCancel.Height = 34
    cmdCancel.Font.Size = 10

End Sub
