Attribute VB_Name = "export_io_to_pd"
Option Explicit

Sub Export_IO_Block_Summary_To_IO_DEVICE_EM()

    Dim srcWB As Workbook, dstWb As Workbook
    Dim wsSrc As Worksheet, wsDst As Worksheet
    Dim filePath As Variant
    Dim cBlockID As Long, cSeq As Long, cType As Long
    Dim lastRow As Long, dstRow As Long
    Dim r As Long
    Dim blockID As String, seqVal As String, typeVal As String
    Dim p As Long
    
    Set srcWB = ThisWorkbook
    
    On Error Resume Next
    Set wsSrc = srcWB.Worksheets("IO_Block_Summary")
    On Error GoTo 0
    
    If wsSrc Is Nothing Then
        MsgBox "Source worksheet 'IO_Block_Summary' was not found.", vbCritical
        Exit Sub
    End If
    
    cBlockID = FindHeaderColumn(wsSrc, "BLOCK ID")
    If cBlockID = 0 Then
        MsgBox "Header 'BLOCK ID' was not found in 'IO_Block_Summary'.", vbCritical
        Exit Sub
    End If
    
    filePath = Application.GetOpenFilename( _
        FileFilter:="Excel Files (*.xlsx;*.xlsm;*.xls),*.xlsx;*.xlsm;*.xls", _
        Title:="Open Destination Workbook")
        
    If filePath = False Then Exit Sub
    
    Set dstWb = Workbooks.Open(CStr(filePath))
    
    On Error Resume Next
    Set wsDst = dstWb.Worksheets("IO DEVICE EM")
    On Error GoTo 0
    
    If wsDst Is Nothing Then
        Set wsDst = dstWb.Worksheets.Add(After:=dstWb.Worksheets(dstWb.Worksheets.Count))
        wsDst.Name = "IO DEVICE EM"
    End If
    
    cSeq = FindHeaderColumn(wsDst, "SEQUENCE")
    If cSeq = 0 Then
        cSeq = wsDst.Cells(1, wsDst.Columns.Count).End(xlToLeft).Column
        If wsDst.Cells(1, cSeq).Value <> "" Then cSeq = cSeq + 1
        wsDst.Cells(1, cSeq).Value = "SEQUENCE"
    End If
    
    cType = FindHeaderColumn(wsDst, "TYPE")
    If cType = 0 Then
        cType = wsDst.Cells(1, wsDst.Columns.Count).End(xlToLeft).Column + 1
        wsDst.Cells(1, cType).Value = "TYPE"
    End If
    
    lastRow = wsSrc.Cells(wsSrc.Rows.Count, cBlockID).End(xlUp).Row
    dstRow = wsDst.Cells(wsDst.Rows.Count, cSeq).End(xlUp).Row + 1
    If dstRow < 2 Then dstRow = 2
    
    For r = 2 To lastRow
        
        blockID = Trim(CStr(wsSrc.Cells(r, cBlockID).Value))
        
        If blockID <> "" Then
            
            p = InStrRev(blockID, "-")
            
            If p > 0 Then
                seqVal = Left(blockID, p - 1)
                typeVal = Mid(blockID, p + 1)
            Else
                seqVal = blockID
                typeVal = ""
            End If
            
            wsDst.Cells(dstRow, cSeq).Value = seqVal
            wsDst.Cells(dstRow, cType).Value = typeVal
            
            dstRow = dstRow + 1
            
        End If
        
    Next r
    
    wsDst.Columns.AutoFit
    dstWb.Save
    
    MsgBox "Export complete to 'IO DEVICE EM'.", vbInformation

End Sub

Private Function FindHeaderColumn(ws As Worksheet, headerName As String) As Long
    
    Dim lastCol As Long
    Dim c As Long
    
    lastCol = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column
    
    For c = 1 To lastCol
        If UCase(Trim(CStr(ws.Cells(1, c).Value))) = UCase(Trim(headerName)) Then
            FindHeaderColumn = c
            Exit Function
        End If
    Next c
    
    FindHeaderColumn = 0

End Function



