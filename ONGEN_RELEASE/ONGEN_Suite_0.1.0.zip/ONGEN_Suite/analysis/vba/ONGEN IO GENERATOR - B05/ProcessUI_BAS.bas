Attribute VB_Name = "ProcessUI_BAS"
' Author: Lee Pierre
' Version: V6.9 Released
' Date: 2026-06-25

'=========================================
Option Explicit
Public progressMax As Long
Public startTime As Double

Public Sub PB_Init(total As Long, msg As String)
    startTime = Timer
    progressMax = total
    Application.StatusBar = msg
End Sub

Public Sub PB_Update(current As Long, Optional statusText As String = "")
    If progressMax <= 0 Then Exit Sub
    Dim pct As Double: pct = current / progressMax
    Application.StatusBar = "Progress: " & Format(pct, "0%") & _
                            IIf(Len(statusText) > 0, " | " & statusText, "")
    DoEvents
End Sub

Public Sub PB_Done(Optional msg As String = "")
    Application.StatusBar = IIf(Len(msg) > 0, msg, "Done.")
End Sub


