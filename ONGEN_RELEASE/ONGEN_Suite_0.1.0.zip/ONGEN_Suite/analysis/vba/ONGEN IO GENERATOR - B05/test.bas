Attribute VB_Name = "test"
Sub TestForm()

    frmIOBlockSelector.Show

    MsgBox frmIOBlockSelector.SelectedProfile

End Sub
