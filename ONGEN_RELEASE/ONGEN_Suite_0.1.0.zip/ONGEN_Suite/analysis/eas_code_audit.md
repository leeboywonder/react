# EAS supporting workbook: static audit

Read-only OOXML structure/control actions and VBA-source static analysis; macros not executed; no Microsoft Excel runtime.

Coverage: 192 components inventoried; 40 substantive components; 1493 procedure declarations. All modules were included in structural/code-pattern scans. Focused manual review covered import, state restoration, error propagation, sort/lookup hotspots, saved buttons and output dependencies. This is not line-by-line runtime verification.

## Findings

### EAS-01 — Three saved buttons reference missing procedures
Severity: high. Evidence class: confirmed-static-control-binding-defect.

The target names do not exist among extracted Public Sub/Function declarations. Clicking an affected button cannot resolve its saved workbook macro target as delivered. No click was executed.

Evidence: [{"file": "xl/drawings/drawing2.xml", "shape": "ONGEN_UI_BTN_15I_Export_480V_Queue", "target": "BTN_VFD_Export_480V_Queue"}, {"file": "xl/drawings/drawing2.xml", "shape": "ONGEN_ADMIN_VFD_SETUP_BTN", "target": "ONGEN_VFD_SETUP", "hidden": true}, {"file": "xl/drawings/drawing2.xml", "shape": "ONGEN_ADMIN_INSTALL_UI_BTN", "target": "ONGEN_EAS_INSTALL_UI", "hidden": true}]

Recommended correction: Choose maintained replacement commands, bind using this-workbook-qualified names, then compile and test each button in Excel.

### EAS-02 — Shared reset helper does not restore caller application state
Severity: high. Evidence class: confirmed-static-state-management-defect.

Nested or manual-calculation workflows lose their prior application settings; switching to automatic may trigger unrelated workbook calculation and event execution. This is a deterministic mismatch with preserve/restore semantics, but its contribution to a particular freeze was not timed.

Evidence: [{"module": "mod00_ONGEN_Common.bas", "procedure": "ResetApplicationState", "line": 718}, {"module": "mod00_ONGEN_Common.bas", "line": 722, "detail": "sets ScreenUpdating=True"}, {"module": "mod00_ONGEN_Common.bas", "line": 724, "detail": "sets EnableEvents=True"}, {"module": "mod00_ONGEN_Common.bas", "line": 726, "detail": "sets Calculation=Automatic"}]

Recommended correction: Use a nesting-aware, capture-and-restore state guard; restore computation, events, redraw, alerts and status in one cleanup path.

### EAS-03 — Outer UI can log success after inner operation has failed or been cancelled
Severity: high. Evidence class: confirmed-static-error-propagation-defect.

A handled inner error returns normally to the runner, which writes SUCCESS. Cancellation also returns normally. Workbook logs therefore cannot prove the underlying work completed.

Evidence: [{"module": "mod00_UI_Buttons_ProgressBar.bas", "procedure": "UI_RunOneStep", "line": 1076, "detail": "UI_RunMacro call"}, {"module": "mod00_UI_Buttons_ProgressBar.bas", "procedure": "UI_RunOneStep", "line": 1081, "detail": "unconditional SUCCESS log after return"}, {"module": "mod02_PD6_Import.bas", "procedure": "Step05_Import_SIS_TAG_PD6_From_PD_Workbook", "line": 234, "detail": "ErrHandler catches error and does not rethrow"}]

Recommended correction: Return explicit completed/cancelled/failed outcomes or rethrow captured errors; log completion only after output validation.

### EAS-04 — IO import clears almost an entire sheet before validating useful source data
Severity: high. Evidence class: static-performance-and-data-loss-risk.

Clear covers all columns from row2 to row1048576. Invalid but openable input can erase prior destination data before proving replacement rows exist. Per-cell reads/writes add COM overhead. Actual duration depends on workbook state and Excel version.

Evidence: [{"module": "mod01_IO_Block_Workflow.bas", "procedure": "Step01_Import_ONGEN_Generated_IO", "line": 139, "detail": "wsDest.rows(\"2:\" & wsDest.rows.count).ClearContents"}, {"module": "mod01_IO_Block_Workflow.bas", "line": 143, "detail": "source-sheet scan begins after clearing"}, {"module": "mod01_IO_Block_Workflow.bas", "line": 153, "detail": "14 separate cell assignments per data row through line166"}]

Recommended correction: Stage and validate rows in arrays; reject zero-row sources; clear bounded existing data only at commit; bulk-write one rectangular range with rollback backup.

### EAS-05 — Three public command names are declared in multiple standard modules
Severity: medium. Evidence class: static-public-name-collision-risk.

Duplicate public names increase compile/name-resolution ambiguity, especially unqualified or Application.Run calls. Duplicate declarations alone are not a verified VBA compile failure; Excel compilation is outstanding.

Evidence: [{"name": "ONGEN_REPAIR_SECURITY_AND_NAV_BUTTONS", "locations": ["mod00_ONGEN_Access_Control.bas:242", "ONGEN_REPAIR_SECURITY.bas:24"]}, {"name": "ONGEN_REPAIR_FUNCTION_HEADERS", "locations": ["ONGEN_REPAIR_CURRENT_FEATURES.bas:77", "ONGEN_RESTORE_REFERENCE_MAIN.bas:196"]}, {"name": "ONGEN_REPAIR_READ_ME", "locations": ["ONGEN_REPAIR_CURRENT_FEATURES.bas:127", "ONGEN_RESTORE_REFERENCE_MAIN.bas:241"]}]

Recommended correction: Use one public entry point per command; make module-local helpers Private or rename and qualify them, then Debug > Compile VBAProject.

### EAS-06 — Quadratic sorts remain in the 24V generator
Severity: medium. Evidence class: static-performance-risk.

These sorts perform about n(n-1)/2 comparisons; large missing-device groups scale quadratically. No actual runtime benchmark was possible.

Evidence: [{"module": "mod03_24V_Power_Generator.bas", "procedure": "Sort24VMissingDeviceKeys", "line": 1256, "detail": "nested i/j comparison loops"}, {"module": "mod03_24V_Power_Generator.bas", "procedure": "Sort24VRecordsCollection", "line": 1588, "detail": "nested i/j comparison loops"}]

Recommended correction: Use a tested O(n log n) stable sort preserving the existing comparator and deterministic tie ordering.

### EAS-07 — Label generation repeatedly scans PD6 for panel-to-area lookups
Severity: medium. Evidence class: static-performance-risk.

Repeated lookups can cost label-count × PD6-row-count cell reads and recreate header maps.

Evidence: [{"module": "mod08_Label_List_Exporter.bas", "procedure": "LABEL_AreaFromPD6Panel", "line": 1811, "detail": "loops over all PD6 rows per lookup"}, {"module": "mod08_Label_List_Exporter.bas", "procedure": "LABEL_AreaFromPanelOrSheet", "line": 1776, "detail": "calls full scan"}, {"module": "mod08_Label_List_Exporter.bas", "line": 677, "detail": "caller inside label collection"}]

Recommended correction: Build a validated panel-to-area dictionary once per run and flag panels mapping to multiple areas.

### EAS-08 — Progress events occur around synchronous jobs rather than within long engineering loops
Severity: medium. Evidence class: static-responsiveness-risk.

A visible progress screen does not make long single-threaded VBA operations responsive. Lack of DoEvents does not prove an infinite loop.

Evidence: [{"module": "mod00_UI_Buttons_ProgressBar.bas", "procedure": "UI_RunOneStep", "line": 1073, "detail": "DoEvents immediately before running macro"}, {"module": "mod02_PD6_Import.bas", "detail": "no DoEvents across 5160 noncomment code lines"}, {"module": "mod03_24V_Power_Generator.bas", "detail": "no DoEvents across 2801 noncomment code lines"}]

Recommended correction: Batch long work, rate-limit progress/cancellation checks, guard reentry if yielding, or perform data transforms in a background application worker.

### EAS-09 — Full-workbook rebuild is reachable from the refresh command
Severity: medium. Evidence class: static-recalculation-risk.

Rebuild affects all open Excel workbooks and can be expensive; the command also does not explicitly await asynchronous query refresh completion before announcing return. No live query behavior was tested.

Evidence: [{"module": "modPD_UI.bas", "line": 114, "detail": "ThisWorkbook.RefreshAll"}, {"module": "modPD_UI.bas", "line": 116, "detail": "Application.CalculateFullRebuild"}]

Recommended correction: Refresh required connections/ranges, await supported completion with timeout, calculate only dependent ranges, and reserve FullRebuild for diagnosed dependency repair.

## Interface contracts

### PD import

{
  "name": "PD import",
  "entry": "mod02_PD6_Import.bas:75",
  "sources": [
    "PD6 System Designed",
    "SIS_TAG_IMPORT_PD6",
    "PD6_IMPORT",
    "PD6 Import"
  ],
  "destination": "PD6_IMPORT",
  "destination_header_line": 908,
  "headers": [
    "SIS_sequence",
    "AREA_Number",
    "SwitchGroup",
    "TYPE",
    "SIS_Element_Number",
    "Control_ID",
    "Load",
    "Load BUS-1",
    "Load BUS-2",
    "Conveyor Type",
    "Module Length (ML)",
    "Motor Power (Main Drive)",
    "Motor Voltage (Main Drive)",
    "Total Qty of Sensors",
    "Control Card",
    "Total Qty of Drives",
    "System Type",
    "Bus Power",
    "Power Supply",
    "Power BUS-1 Terminal",
    "Power BUS-2 Terminal",
    "PNL",
    "NETWORK_IP",
    "LPN",
    "X",
    "Y",
    "Z",
    "ROTATION_DEG",
    "NOTES"
  ],
  "key": "normalized SIS_sequence + TYPE",
  "merge": "fill blank destinations only; Control_ID remains EAS-owned; parent ONGEN_MECH geometry omitted when electrical child exists; one best source per key",
  "gap": "No automatic conflict-review stage when duplicate same-key source records differ; blank destination type fallback must consume a row only once."
}

### Power assignment import from PD

{
  "name": "Power assignment import from PD",
  "entry": "mod02_PD6_Import.bas:431",
  "sources": [
    "PSU_Terminal_Assignment",
    "Power Supply Bus"
  ],
  "terminal_headers": [
    "PSU_SIS_SEQUENCE",
    "SOURCE_SIS_SEQUENCE",
    "BLOCK_NAME",
    "BUS",
    "PSU_TERMINAL"
  ],
  "bus_headers": [
    "Device 1",
    "BUS",
    "PSU SIS Element Number"
  ],
  "destination_fields": [
    "Bus Power",
    "Power Supply",
    "Power BUS-1 Terminal",
    "Power BUS-2 Terminal"
  ],
  "merge": "fill blanks; matches normalized sequence+bus+block, then conveyor-root fallback; first indexed match retained",
  "gap": "Missing source sheet or header silently skips enrichment; unmatched or conflicting power records require explicit reconciliation report."
}

### Generated IO import

{
  "name": "Generated IO import",
  "entry": "mod01_IO_Block_Workflow.bas:118",
  "sources": "worksheets with Device/Device Name and Part# Ref. aliases",
  "destination": "IO_DEVICE_LIST",
  "gap": "No source staging before full-sheet clear; no transaction rollback."
}

### Coordinate import

{
  "name": "Coordinate import",
  "entry": "mod02A_PD6_Coordinate_Import.bas:37",
  "required_headers": [
    "SIS_SEQUENCE",
    "X",
    "Y",
    "Z"
  ],
  "merge": "explicit matched/unmatched/invalid/conflicting/repeated-identical counters; subsequent Step05D recalculation requested",
  "positive": "conflicting coordinates already distinguished rather than silently overwritten"
}

### CAD drawings

{
  "name": "CAD drawings",
  "entry": "mod07_VFD_Drawing_Workflow.bas",
  "dependencies": [
    "Microsoft Excel/VBA",
    "external DWG circuit/device/seed libraries",
    "AutoCAD/compatible AutoLISP execution for generated drawing workflow"
  ],
  "gap": "Workbook code/export can be statically inspected; CAD output cannot be certified without the referenced external DWG libraries and CAD runtime."
}

## Existing optimizations worth keeping

- 24V generator bulk-reads source ranges into Variant arrays (mod03:201,786).
- PD6 header, K-rule and geometry caches exist and should be preserved.
- 24V generator has source-signature/session-cache machinery (mod03:94-98).
- VFD drawing fast-mode helper captures and restores application settings with nesting depth (mod07:4943-4967).
- Coordinate import distinguishes conflicts and invalid/missing coordinates.
- Step05 explicitly preserves nonblank EAS-owned data and Control_ID ownership.

## Limits

- No Excel/VBA execution, compilation, hang timing or Windows/CAD acceptance test.
- Static hotspots identify plausible bottlenecks, not measured speedups or a proven cause of a specific freeze.
- Power Calculation workbook not transferred because it exceeds 32 MiB; its contents were not inspected.