#!/usr/bin/env python3
"""Read-only OOXML/CSV inventory. Does not execute macros or recalculate formulas."""
import argparse, collections, csv, hashlib, json, posixpath, re, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
NS = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
S='{'+NS['s']+'}'
R='{'+NS['r']+'}'
PKG='{http://schemas.openxmlformats.org/package/2006/relationships}'
VOLATILE=re.compile(r'(?i)(?<![A-Z_])(?:NOW|TODAY|RAND|RANDBETWEEN|OFFSET|INDIRECT|CELL|INFO)\s*\(')
WHOLE_COL=re.compile(r'(?<![A-Z0-9_])\$?[A-Z]{1,3}:\$?[A-Z]{1,3}(?![0-9A-Z_])')
WHOLE_ROW=re.compile(r'(?<![A-Z0-9_])\$?\d+:\$?\d+(?![0-9A-Z_])')
EXTERNAL=re.compile(r'\[[^\]]+\][^!]*!')

def readxml(z,name):
    return ET.fromstring(z.read(name))

def relationships(z, base):
    name=posixpath.join(posixpath.dirname(base),'_rels',posixpath.basename(base)+'.rels')
    if name not in z.namelist(): return {}
    return {r.attrib['Id']:{**r.attrib,'resolved':posixpath.normpath(posixpath.join(posixpath.dirname(base),r.attrib['Target'])) if not r.attrib['Target'].startswith('/') else r.attrib['Target'].lstrip('/')} for r in readxml(z,name)}

def colnum(addr):
    n=0
    for c in re.match(r'[A-Z]+',addr).group(): n=n*26+ord(c)-64
    return n

def cell_text(c,ss):
    typ=c.get('t','n'); v=c.find(S+'v')
    if typ=='inlineStr': return ''.join(t.text or '' for t in c.findall('.//'+S+'t'))
    if v is None:return None
    value=v.text or ''
    if typ=='s':
        try:return ss[int(value)]
        except (ValueError,IndexError): return value
    return value

def sha256(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def inspect_workbook(p):
    with zipfile.ZipFile(p) as z:
        members=z.namelist(); wb=readxml(z,'xl/workbook.xml'); wr=relationships(z,'xl/workbook.xml')
        ss=[]
        if 'xl/sharedStrings.xml' in members:
            ss=[''.join(t.text or '' for t in si.findall('.//'+S+'t')) for si in readxml(z,'xl/sharedStrings.xml')]
        styles={}
        if 'xl/styles.xml' in members:
            st=readxml(z,'xl/styles.xml')
            styles={tag:len(st.find(S+tag)) if st.find(S+tag) is not None else 0 for tag in ('cellXfs','cellStyleXfs','fonts','fills','borders','numFmts','dxfs')}
        defined=[dict(n.attrib,formula=n.text or '',invalid_ref='#REF!' in (n.text or '')) for n in wb.findall('s:definedNames/s:definedName',NS)]
        links=[]
        for name in members:
            if not name.endswith('.rels'):continue
            for rel in readxml(z,name):
                if rel.get('TargetMode')=='External':
                    target=rel.get('Target','')
                    # URLs/file paths are evidence, but do not retain URI user info or query strings.
                    target=re.sub(r'(https?://)[^/@]+:[^/@]+@',r'\1[redacted]@',target).split('?')[0]
                    links.append({'part':name,'type':rel.get('Type','').split('/')[-1],'target':target})
        out={'filename':p.name,'path':str(p),'size_bytes':p.stat().st_size,'sha256':sha256(p),'zip_uncompressed_bytes':sum(x.file_size for x in z.infolist()),'calc_properties':dict(wb.find('s:calcPr',NS).attrib) if wb.find('s:calcPr',NS) is not None else {},'workbook_properties':dict(wb.find('s:workbookPr',NS).attrib) if wb.find('s:workbookPr',NS) is not None else {},'styles':styles,'defined_names':defined,'external_relationships':links,'drawing_parts':len([n for n in members if re.match(r'xl/drawings/drawing\d+\.xml$',n)]),'vba_project_bytes':z.getinfo('xl/vbaProject.bin').file_size if 'xl/vbaProject.bin' in members else 0,'sheets':[]}
        for sh in wb.findall('s:sheets/s:sheet',NS):
            part=wr[sh.get(R+'id')]['resolved']; root=readxml(z,part); rels=relationships(z,part)
            cells=root.findall('s:sheetData/s:row/s:c',NS); forms=[]; issues=collections.defaultdict(list); errors=collections.Counter(); valuecells=[]; row_values=collections.defaultdict(list); nonempty=0; styled_empty=0; actual_max_row=0; actual_max_col=0; cached=0; formula_nocache=0; shared=0
            for c in cells:
                addr=c.get('r'); value=cell_text(c,ss); f=c.find(S+'f'); content=value not in (None,'') or f is not None
                if not content:
                    if c.get('s') is not None:styled_empty+=1
                    continue
                nonempty+=1; rn=int(re.search(r'\d+',addr).group()); actual_max_row=max(actual_max_row,rn); actual_max_col=max(actual_max_col,colnum(addr))
                if value not in (None,''):row_values[rn].append({'cell':addr,'value':value[:300]})
                if c.get('t')=='e':errors[value]+=1
                if f is not None:
                    formula=f.text or ''; forms.append({'cell':addr,'formula':formula[:1000],'cached':value})
                    if value is None:formula_nocache+=1
                    else:cached+=1
                    if f.get('t')=='shared':shared+=1
                    for label,pattern in [('volatile',VOLATILE),('whole_column',WHOLE_COL),('whole_row',WHOLE_ROW),('external',EXTERNAL)]:
                        if pattern.search(formula):issues[label].append({'cell':addr,'formula':formula[:400]})
            row_nums=sorted(row_values)
            # Preserve text-heavy schema rows and first data rows without copying entire workbook.
            head_rows=[{'row':rn,'cells':row_values[rn][:60]} for rn in row_nums[:20]]
            tables=[]
            for tp in root.findall('s:tableParts/s:tablePart',NS):
                rid=tp.get(R+'id'); tablepart=rels.get(rid,{}).get('resolved')
                if tablepart in members:
                    tr=readxml(z,tablepart); tables.append({'part':tablepart,'name':tr.get('name'),'display_name':tr.get('displayName'),'ref':tr.get('ref'),'columns':[col.get('name') for col in tr.findall('s:tableColumns/s:tableColumn',NS)]})
            validations=[{'sqref':v.get('sqref'),'type':v.get('type'),'formula1':v.findtext('s:formula1',default='',namespaces=NS),'formula2':v.findtext('s:formula2',default='',namespaces=NS)} for v in root.findall('s:dataValidations/s:dataValidation',NS)]
            cf=[{'sqref':v.get('sqref'),'rules':len(v)} for v in root.findall('s:conditionalFormatting',NS)]
            drawing_objects=[]
            for rel in rels.values():
                rp=rel['resolved']
                if '/drawing' in rp and rp.endswith('.xml') and rp in members:
                    dr=readxml(z,rp)
                    drawing_objects.append({'part':rp,'objects':len(dr)})
            dim=root.find('s:dimension',NS)
            so={'name':sh.get('name'),'sheet_id':sh.get('sheetId'),'state':sh.get('state','visible'),'part':part,'dimension':dim.get('ref') if dim is not None else None,'allocated_cell_count':len(cells),'nonempty_cells':nonempty,'styled_empty_cells':styled_empty,'actual_max_row':actual_max_row,'actual_max_col':actual_max_col,'formula_count':len(forms),'formulas_with_cached_values':cached,'formulas_without_cached_values':formula_nocache,'shared_formula_cells':shared,'error_values':dict(errors),'formula_risks':{k:{'count':len(v),'examples':v[:8]} for k,v in issues.items()},'formula_examples':forms[:8],'tables':tables,'validation_count':len(validations),'validations':validations[:30],'conditional_format_blocks':len(cf),'conditional_format_rules':sum(x['rules'] for x in cf),'conditional_formats':cf[:20],'merged_ranges':[m.get('ref') for m in root.findall('s:mergeCells/s:mergeCell',NS)],'drawing_objects':drawing_objects,'sheet_protection':dict(root.find('s:sheetProtection',NS).attrib) if root.find('s:sheetProtection',NS) is not None else None,'top_nonempty_rows':head_rows}
            out['sheets'].append(so)
        out['totals']={'sheets':len(out['sheets']),'allocated_cells':sum(s['allocated_cell_count'] for s in out['sheets']),'nonempty_cells':sum(s['nonempty_cells'] for s in out['sheets']),'formula_cells':sum(s['formula_count'] for s in out['sheets']),'formula_cells_without_cached_values':sum(s['formulas_without_cached_values'] for s in out['sheets']),'cached_error_cells':sum(sum(s['error_values'].values()) for s in out['sheets']),'invalid_defined_names':sum(n['invalid_ref'] for n in defined),'external_relationships':len(links),'tables':sum(len(s['tables']) for s in out['sheets'])}
        return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',default='/workspace/attachments');ap.add_argument('--out',default='/workspace/ongen/analysis');args=ap.parse_args();outdir=Path(args.out);outdir.mkdir(parents=True,exist_ok=True)
    result={'method':'Read-only ZIP/OOXML inspection; macros not executed; formulas not recalculated. Counts include hidden sheets. Formula patterns are static risk indicators, not measured freeze causes.','unavailable':[{'filename':'ONGEN Power Calculation -V4.6.xlsm','reason':'Uploaded file exceeds 32 MiB transfer limit; contents not inspected.'}],'workbooks':[],'csvs':[]}
    for p in sorted(Path(args.input).rglob('*.xlsm')):
        result['workbooks'].append(inspect_workbook(p));print(p.name,result['workbooks'][-1]['totals'],flush=True)
    for p in Path(args.input).rglob('*.csv'):
        with p.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.reader(f))
        result['csvs'].append({'filename':p.name,'sha256':sha256(p),'rows':rows,'row_count':len(rows),'width_counts':dict(collections.Counter(len(r) for r in rows))})
    (outdir/'inventory.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    schema={'method':result['method'],'workbooks':[{'filename':w['filename'],'sheets':[{'name':s['name'],'state':s['state'],'tables':s['tables'],'top_nonempty_rows':s['top_nonempty_rows'],'validations':s['validations']} for s in w['sheets']]} for w in result['workbooks']],'csvs':result['csvs']}
    (outdir/'schema.json').write_text(json.dumps(schema,indent=2,ensure_ascii=False))
    md=['# ONGEN workbook structure and formula inventory','','Read-only package inspection. Macros were not executed and formulas were not recalculated. Static indicators do not prove a runtime freeze.','', '| Workbook | Sheets | Allocated cells | Nonempty | Formulas | Cached errors | Invalid names |','|---|---:|---:|---:|---:|---:|---:|']
    for w in result['workbooks']:
        t=w['totals'];md.append(f"| {w['filename']} | {t['sheets']} | {t['allocated_cells']} | {t['nonempty_cells']} | {t['formula_cells']} | {t['cached_error_cells']} | {t['invalid_defined_names']} |")
    md+=['','Power Calculation V4.6 is unavailable because its upload exceeds the file-transfer limit. No claim about its contents is made.']
    for w in result['workbooks']:
        md+=['',f"## {w['filename']}",'',f"SHA-256: `{w['sha256']}`",f"Calculation settings: `{w['calc_properties']}`. Styles: `{w['styles']}`.",'','| Sheet | State | Dimension | Allocated | Nonempty | Formulas | No formula cache | Errors |','|---|---|---|---:|---:|---:|---:|---:|']
        for s in w['sheets']:md.append(f"| {s['name']} | {s['state']} | {s['dimension']} | {s['allocated_cell_count']} | {s['nonempty_cells']} | {s['formula_count']} | {s['formulas_without_cached_values']} | {sum(s['error_values'].values())} |")
        invalid=[n for n in w['defined_names'] if n['invalid_ref']]
        if invalid:md+=['','Invalid defined names: '+', '.join(f"`{n['name']}` = `{n['formula']}`" for n in invalid)+'.']
        for s in w['sheets']:
            if s['formula_risks']:md+=['',f"`{s['name']}` formula indicators: "+'; '.join(f"{k}: {v['count']} (example {v['examples'][0]['cell']}: `{v['examples'][0]['formula']}`)" for k,v in s['formula_risks'].items())+'.']
            if s['error_values']:md += ['',f"`{s['name']}` cached errors: `{s['error_values']}`. These are saved cached values, not a fresh calculation."]
    (outdir/'inventory.md').write_text('\n'.join(md)+'\n')
if __name__=='__main__':main()
