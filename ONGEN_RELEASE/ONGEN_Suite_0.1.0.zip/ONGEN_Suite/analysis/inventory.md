# ONGEN workbook structure and formula inventory

Read-only package inspection. Macros were not executed and formulas were not recalculated. Static indicators do not prove a runtime freeze.

| Workbook | Sheets | Allocated cells | Nonempty | Formulas | Cached errors | Invalid names |
|---|---:|---:|---:|---:|---:|---:|
| ONGEN Field Devices Specification -v2.1.7.1.xlsm | 12 | 73640 | 34406 | 5689 | 1 | 0 |
| ONGEN IO GENERATOR - B05.xlsm | 4 | 7342 | 98 | 1 | 0 | 0 |
| ONGEN_EAS_MASTER_FUNCTION_LIBRARY.xlsm | 16 | 34048 | 12911 | 0 | 0 | 0 |
| ONGEN PD_DEFINITION_MASTER_WORKFLOW_V5.1.6.5.xlsm | 11 | 285292 | 284320 | 0 | 0 | 0 |
| ONGEN EAS - V2.5.3.xlsm | 44 | 131268 | 5467 | 593 | 0 | 0 |

Power Calculation V4.6 is unavailable because its upload exceeds the file-transfer limit. No claim about its contents is made.

## ONGEN Field Devices Specification -v2.1.7.1.xlsm

SHA-256: `8ab68cf3ac063a2fb2d16ec620036e1252cec13ae312fa52a4fab6df7d560aa0`
Calculation settings: `{'calcId': '191029'}`. Styles: `{'cellXfs': 180, 'cellStyleXfs': 4, 'fonts': 36, 'fills': 25, 'borders': 26, 'numFmts': 2, 'dxfs': 14}`.

| Sheet | State | Dimension | Allocated | Nonempty | Formulas | No formula cache | Errors |
|---|---|---|---:|---:|---:|---:|---:|
| START-HERE | visible | A1:K24 | 212 | 67 | 3 | 0 | 1 |
| Revisions | hidden | A1:D5 | 20 | 20 | 0 | 0 | 0 |
| Vendor INFO | hidden | A1:K173 | 716 | 640 | 0 | 0 | 0 |
| NEW VENDOR INFO | hidden | A1:G3140 | 21119 | 18623 | 0 | 0 | 0 |
| Pricing-Data | hidden | A1:H208 | 1623 | 1605 | 207 | 0 | 0 |
| DATA | hidden | A1:K12 | 49 | 32 | 0 | 0 | 0 |
| EE BOM IMPORT_test | hidden | A1:S3067 | 41872 | 6463 | 0 | 0 | 0 |
| VARIANT LIST | visible | A1:AX31 | 925 | 872 | 0 | 0 | 0 |
| EM Designed function | visible | A1:Z1 | 26 | 26 | 0 | 0 | 0 |
| EE System Designed BOM | visible | A1:R250 | 2169 | 1263 | 1245 | 0 | 0 |
| SAP POR Order List | visible | A1:T250 | 4813 | 4750 | 4234 | 0 | 0 |
| WORKBOOK GUIDE | hidden | A1:F18 | 96 | 45 | 0 | 0 | 0 |

`START-HERE` cached errors: `{'#VALUE!': 1}`. These are saved cached values, not a fresh calculation.

## ONGEN IO GENERATOR - B05.xlsm

SHA-256: `018509e79925c7af5508df56de82d20f0b8b25cf885ca67b5f565adb454bcdcf`
Calculation settings: `{'calcId': '191029', 'forceFullCalc': '1'}`. Styles: `{'cellXfs': 80, 'cellStyleXfs': 3, 'fonts': 33, 'fills': 25, 'borders': 25, 'numFmts': 0, 'dxfs': 0}`.

| Sheet | State | Dimension | Allocated | Nonempty | Formulas | No formula cache | Errors |
|---|---|---|---:|---:|---:|---:|---:|
| Cover Page | visible | A1:S37 | 684 | 51 | 1 | 0 | 0 |
| IO_DEVICE_LIST | visible | A1:K814 | 6322 | 11 | 0 | 0 | 0 |
| DATA | hidden | A50:AA93 | 16 | 4 | 0 | 0 | 0 |
| Revisions | hidden | A1:D80 | 320 | 32 | 0 | 0 | 0 |

## ONGEN_EAS_MASTER_FUNCTION_LIBRARY.xlsm

SHA-256: `c470f126bc53907c0d9804bdf470d0f9f6118c3f25d5b3bed73bcbb0d8612a2f`
Calculation settings: `{'calcId': '191029'}`. Styles: `{'cellXfs': 80, 'cellStyleXfs': 2, 'fonts': 8, 'fills': 24, 'borders': 11, 'numFmts': 5, 'dxfs': 131}`.

| Sheet | State | Dimension | Allocated | Nonempty | Formulas | No formula cache | Errors |
|---|---|---|---:|---:|---:|---:|---:|
| 00_LIBRARY_GUIDE | visible | A1:Z100 | 2600 | 32 | 0 | 0 | 0 |
| 01_ADD_NEW_PART | visible | A1:Z100 | 2600 | 111 | 0 | 0 | 0 |
| 02_BUILD_FUNCTION_ASSEMBLY | visible | A1:Z97 | 2522 | 114 | 0 | 0 | 0 |
| 03_BULK_PART_IMPORT | visible | A1:Z216 | 4688 | 59 | 0 | 0 | 0 |
| 04_LIBRARY_BROWSER | visible | A1:Z224 | 3308 | 1456 | 0 | 0 | 0 |
| 05_CHANGE_REVIEW | visible | A1:Z100 | 2600 | 120 | 0 | 0 | 0 |
| FUNCTION_MASTER | visible | A1:V35 | 716 | 391 | 0 | 0 | 0 |
| FUNCTION_COMPONENTS | visible | A1:V48 | 920 | 490 | 0 | 0 | 0 |
| VARIANT_MASTER | visible | A1:V213 | 2484 | 1844 | 0 | 0 | 0 |
| VARIANT_BOM | visible | A1:V339 | 4533 | 2354 | 0 | 0 | 0 |
| PART_MASTER | visible | A1:W222 | 4562 | 4235 | 0 | 0 | 0 |
| COST_HISTORY | hidden | A1:V186 | 2253 | 1461 | 0 | 0 | 0 |
| TYPE_CODES | hidden | A1:D29 | 56 | 53 | 0 | 0 | 0 |
| REVISION_HISTORY | hidden | A1:F23 | 126 | 121 | 0 | 0 | 0 |
| CONFIG | hidden | A1:D15 | 40 | 37 | 0 | 0 | 0 |
| IMPORT_LOG | hidden | A1:H9 | 40 | 33 | 0 | 0 | 0 |

## ONGEN PD_DEFINITION_MASTER_WORKFLOW_V5.1.6.5.xlsm

SHA-256: `797e303a2225881ec3c5bb2325bd208c3368b4ebc87afaf3f94dbfd045b58a03`
Calculation settings: `{'calcId': '191029'}`. Styles: `{'cellXfs': 67, 'cellStyleXfs': 3, 'fonts': 16, 'fills': 13, 'borders': 11, 'numFmts': 1, 'dxfs': 21}`.

| Sheet | State | Dimension | Allocated | Nonempty | Formulas | No formula cache | Errors |
|---|---|---|---:|---:|---:|---:|---:|
| MAIN | visible | A1:AI55 | 4 | 0 | 0 | 0 | 0 |
| DATA_POWER | hidden | A1:BF41 | 591 | 365 | 0 | 0 | 0 |
| Revisions | visible | A1:D80 | 320 | 24 | 0 | 0 | 0 |
| FUNCTION DEFINITION | visible | A1:AK168 | 1188 | 907 | 0 | 0 | 0 |
| SIS_TAG_EXPORT | visible | A1:BJ4411 | 155509 | 155509 | 0 | 0 | 0 |
| BUILD_INFO | hidden | A1:B12 | 24 | 24 | 0 | 0 | 0 |
| BOQ | visible | A1:W2745 | 34637 | 34637 | 0 | 0 | 0 |
| UI_Config | hidden | A1:B2 | 4 | 4 | 0 | 0 | 0 |
| WORKBOOK GUIDE | visible | A1:F59 | 354 | 189 | 0 | 0 | 0 |
| MISSING_LPN | visible | A1:C321 | 963 | 963 | 0 | 0 | 0 |
| SIS_TAG_PD5 | visible | A1:AB4560 | 91698 | 91698 | 0 | 0 | 0 |

## ONGEN EAS - V2.5.3.xlsm

SHA-256: `3eb7af35877b307b3a85a59060b198e854c2214d085feb1650529676e92527cd`
Calculation settings: `{'calcId': '191029'}`. Styles: `{'cellXfs': 144, 'cellStyleXfs': 1, 'fonts': 10, 'fills': 25, 'borders': 16, 'numFmts': 2, 'dxfs': 65}`.

| Sheet | State | Dimension | Allocated | Nonempty | Formulas | No formula cache | Errors |
|---|---|---|---:|---:|---:|---:|---:|
| READ ME | hidden | A1:F30 | 27 | 22 | 0 | 0 | 0 |
| MAIN | visible | A1:T48 | 1 | 1 | 0 | 0 | 0 |
| REVISION_HISTORY | hidden | A1:G7 | 49 | 49 | 0 | 0 | 0 |
| ONGEN_WORKFLOW_GUIDE | visible | A1:I38 | 342 | 212 | 0 | 0 | 0 |
| PD6_IMPORT | visible | A1:AC292 | 29 | 29 | 0 | 0 | 0 |
| IO_DEVICE_LIST | visible | A1:N1 | 14 | 14 | 0 | 0 | 0 |
| IO_BLOCK_GENERATOR | visible | A1:S1 | 19 | 19 | 0 | 0 | 0 |
| 24V_OVERLOAD_TERMINALS | visible | A1:R24 | 355 | 25 | 0 | 0 | 0 |
| 24V_NOT_GENERATED | visible | A1:P5 | 52 | 21 | 0 | 0 | 0 |
| AREA | visible | A1:A2 | 2 | 1 | 0 | 0 | 0 |
| IO_Topology | visible | A1:B1 | 2 | 2 | 0 | 0 | 0 |
| EtherCAT Safety (EtherCAT) | visible | A1 | 0 | 0 | 0 | 0 | 0 |
| VFD_DWG_QUEUE | visible | A1:EL151 | 16138 | 142 | 0 | 0 | 0 |
| VFD_480V_Generator | visible | A1:AY82 | 185 | 0 | 0 | 0 | 0 |
| STEP10A_SYNC_AUDIT | visible | A1:O9 | 117 | 28 | 0 | 0 | 0 |
| UI_BUTTON_AUDIT | hidden | A1:F48 | 288 | 288 | 0 | 0 | 0 |
| SWG_DEFINITION | hidden | A2:U603 | 1700 | 971 | 593 | 0 | 0 |
| BLOCK_EDIT | hidden | A4:K33 | 330 | 49 | 0 | 0 | 0 |
| CTRL_FUNCTION | hidden | A1:Y171 | 559 | 386 | 0 | 0 | 0 |
| DATA_POWER | hidden | A1:BF41 | 595 | 369 | 0 | 0 | 0 |
| DATA | hidden | A1:R36 | 346 | 191 | 0 | 0 | 0 |
| DATA_IO_BLOCK | hidden | A1:AM59 | 632 | 605 | 0 | 0 | 0 |
| 480v_DATA_POWER | hidden | A1:BH39 | 688 | 353 | 0 | 0 | 0 |
| PROCESS_LOG | hidden | A1:E1497 | 1509 | 15 | 0 | 0 | 0 |
| EXPORT_LOG | hidden | A1:E836 | 840 | 5 | 0 | 0 | 0 |
| VALIDATION | visible | A1:D1 | 4 | 4 | 0 | 0 | 0 |
| VFD_DWG_README | visible | A1:D20 | 72 | 57 | 0 | 0 | 0 |
| VFD_DWG_CONFIG | hidden | A1:D103 | 412 | 409 | 0 | 0 | 0 |
| VFD_DWG_CIRCUIT_LIBRARY | visible | A1:O21 | 315 | 78 | 0 | 0 | 0 |
| VFD_DWG_DEVICE_LIBRARY | hidden | A1:T112 | 2240 | 122 | 0 | 0 | 0 |
| VFD_DWG_DEVICE_PLACEMENT | hidden | A1:AE6 | 181 | 109 | 0 | 0 | 0 |
| VFD_DWG_ATTRIBUTE_MAP | hidden | A1:G7 | 49 | 37 | 0 | 0 | 0 |
| VFD_DWG_SEED_LIBRARY | hidden | A1:E4 | 20 | 20 | 0 | 0 | 0 |
| VFD_DWG_SHEET_PLAN | visible | A1:Y4 | 100 | 99 | 0 | 0 | 0 |
| VFD_DWG_CIRCUIT_PLACEMENT | visible | A1:N2 | 28 | 24 | 0 | 0 | 0 |
| VFD DWG MPWR GROUPS | visible | A1:T11 | 24 | 20 | 0 | 0 | 0 |
| VFD DWG PANEL CABLE REPORT | visible | A1:L1 | 12 | 12 | 0 | 0 | 0 |
| VFD_DWG_PANEL_CABLE_REPORT | visible | A1:L1 | 12 | 12 | 0 | 0 | 0 |
| VFD_DWG_FUNCTION_DEVICE_MAP | visible | A1:M12 | 156 | 15 | 0 | 0 | 0 |
| VFD_FUNCTION_ASSIGNMENT | visible | A1:M1 | 13 | 13 | 0 | 0 | 0 |
| CABLE_ID_REGISTRY | visible | A1:I5782 | 11571 | 9 | 0 | 0 | 0 |
| CABLE_TAG_OUTPUT | visible | A1:S4774 | 90636 | 26 | 0 | 0 | 0 |
| VFD_NETWORK_BACKFILL_AUDIT | visible | A1:J1 | 10 | 10 | 0 | 0 | 0 |
| ADMIN_BUTTON_AUDIT | hidden | A1:F99 | 594 | 594 | 0 | 0 | 0 |

## Key interpretation and interface gaps

- The master has **no worksheet formula cells**. Its freezes cannot be attributed to a large worksheet formula graph from the saved package alone. VBA execution, external-link refresh, drawing/UI logic, file access, and Excel runtime behavior need separate examination.
- Master `UI_Config!B2` stores an absolute Windows/OneDrive path to **Power Calculation V4.3**, whereas the supplied inaccessible upload is **V4.6**. This is a verified configuration/version mismatch; whether an existing fallback successfully resolves it requires VBA/runtime checks.
- The master retains one external-link XML part with three external-path relationships to an older **ONGEN Engineering Automation Schematic V25.8.3** file. These are saved package relationships, not three independently verified reachable workbooks. No worksheet formulas use them in the saved package.
- Field Devices `START-HERE!B2` contains a saved `#VALUE!` error (a literal cached error cell, not a fresh recalculation failure). Cause is unverified.
- IO Generator `IO_DEVICE_LIST` has **headers only** (11 content cells), despite its dimension reaching row 814. EAS `PD6_IMPORT` has **headers only** (29 cells), EAS `IO_DEVICE_LIST` has **headers only** (14 cells), and Field Devices `EM Designed function` has **headers only** (26 cells). The submitted suite is not demonstrably populated end-to-end.
- EAS has **131,268 allocated cells versus 5,467 content cells**; IO Generator has **7,342 versus 98**. This is saved cell/formatting allocation overhead and suggests avoiding full UsedRange scans. It does not establish measured Excel latency.
- No invalid `#REF!` defined names or whole-column/whole-row/volatile function formula patterns were found in the inspected worksheet formula text. Empty templates and macro-generated calculations still require execution validation.
- BOQ header row is 1, row 2 is units, and data begins at row 3. The master PD5 schema reorders SIS_SEQUENCE/SIS_ELEMENT_NUMBER and has only 28 columns compared with the original SIS export's 62-column dimension. Import/export must map normalized headers rather than assume column positions.

CSV lookup has 31 rows including its header: 30 function code/description records. No formulas or macros were executed during this audit.
