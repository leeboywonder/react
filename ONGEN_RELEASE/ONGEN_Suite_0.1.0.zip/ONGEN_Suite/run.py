#!/usr/bin/env python3
"""Start the local ONGEN browser app. Never exposes the engineering workspace to the network."""
import argparse, threading, webbrowser

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--browser',action='store_true')
    args=parser.parse_args()
    if args.browser:threading.Timer(1.5,lambda:webbrowser.open(f'http://127.0.0.1:{args.port}')).start()
    import uvicorn
    uvicorn.run('app.server:app',host='127.0.0.1',port=args.port,log_level='info')
if __name__=='__main__':main()
