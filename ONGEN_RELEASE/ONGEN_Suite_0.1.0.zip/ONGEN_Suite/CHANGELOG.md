# ONGEN 0.1.0 — engineering preview

New: combined local browser UI; Windows desktop host and launch/build source; shared SQLite workspace; immutable workbook intake; source-row provenance; indexed PD5/BOQ/function enrichment; device identity review; normalized assembly BOM; transparent power estimates; explicit Power/B05 contracts; reviewed return preview/apply; XLSX/CSV/JSON/HTML review exports and issue register.

Proposed VBA source changes: bounded Phase 3A stale-row clearing (mod09); Phase 5A VFD counter/data-loss correction (mod20); Phase 4D error propagation (mod14); Field→B05 aliases/composite identity/validation/bulk-write/state restoration replacement (EXPORT_TO_IOGEN). Diffs and acceptance instructions included. Originals unchanged; VBA uncompiled.

Confirmed gaps remain documented: unavailable Power V4.6; 5A function-code contract; component-specific BOM fallback; Field quantity propagation; native IO/panel/terminal allocation; EAS missing controls and state/error handling; library identity/approval and lookup gaps; downstream CAD acceptance. No complete native-macro parity, Excel freeze-elimination claim or released electrical design is made.
