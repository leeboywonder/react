# Validation scopes

Run `python -m unittest discover -s tests -v` from the suite root after installing test-requirements.txt. test_engine.py/test_api.py/test_library.py execute the new engine and API against temporary synthetic workbooks. test_field_export_model.py executes a Python model/source expectations for the proposed Field exporter; it does not execute VBA.

The additional analysis/test_vba_patch_models.py and analysis/test_vba_power_patch.py use the extracted originals and proposed replacements. They test source/algorithm properties, not Excel compilation/runtime.

validate_real_data.py imports the supplied originals into a temporary database, checks hashes and verifies generated review schemas/row counts. Its timing scope is Python/Linux, not Excel.

browser_check.py expects a disposable seeded server at loopback port8766 and system Chromium at /usr/bin/chromium (adapt that executable path for another OS). It intentionally writes a test review note, so never run against a live project. Back up a test database using sqlite's backup API, set ONGEN_DATA_DIR to that disposable directory, run `python run.py --port 8766`, then run the browser script. Browser results and screenshot are recorded under analysis/. Runtime UI checks used the real input data in a disposable database.

Windows/Excel acceptance requirements are in the report and vba/patched notes. They remain unexecuted here. Do not count model checks as Excel tests.
