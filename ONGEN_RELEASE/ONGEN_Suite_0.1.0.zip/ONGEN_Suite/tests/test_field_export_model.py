"""Regression model for proposed Field→B05 transfer contract.

These tests execute Python, not VBA or Excel. They validate the planned contract,
identity/conflict policy and value conservation. Desktop VBA acceptance is separate.
"""
from copy import deepcopy
from decimal import Decimal, InvalidOperation
import unittest

B05_HEADERS = ['DEVICE NAME','ITEM TYPE','INPUT','OUTPUT','S_IN','S_OUT','PNL','PWG','LOCATION','Standard Block','Safety Block']
SOURCE_ALIASES = [('Conv.ID','DEVICE NAME','CONV ID'),('Items Type','ITEM TYPE','ITEMS TYPE'),('INPUT',),('OUTPUT',),('S_IN',),('S_OUT',)]
TARGET_ALIASES = [('DEVICE NAME','Conv.ID','CONV ID'),('ITEM TYPE','Items Type','ITEMS TYPE'),('INPUT',),('OUTPUT',),('S_IN',),('S_OUT',)]

def header_key(value):
    return str(value).replace('\u00a0',' ').strip().upper().replace(' ','').replace('_','').replace('.','')

def columns(headers, aliases):
    found = [i for i,h in enumerate(headers) if header_key(h) in {header_key(a) for a in aliases}]
    if len(found) != 1:
        raise ValueError('missing or ambiguous header')
    return found[0]

def count(value):
    if value is None or str(value).strip() == '':
        return None
    if isinstance(value,bool):
        raise ValueError('invalid count')
    try:
        n=Decimal(str(value))
    except InvalidOperation as e:
        raise ValueError('invalid count') from e
    if not n.is_finite() or n < 0 or n > 2147483647 or n != n.to_integral_value():
        raise ValueError('invalid count')
    return int(n)

def text(value):
    return '' if value is None else str(value).replace('\u00a0',' ').strip()

def key(device,item_type):
    if not text(device) or not text(item_type):
        raise ValueError('missing identity')
    return text(device).upper(),text(item_type).upper()

def export_model(source_headers,source_rows,target_headers,target_rows,overwrite=True):
    """Stage a value-only export; caller data is immutable even on validation failure."""
    sc=[columns(source_headers,a) for a in SOURCE_ALIASES]
    tc=[columns(target_headers,a) for a in TARGET_ALIASES]
    for name in B05_HEADERS[6:]:
        columns(target_headers,[name])
    source=[]; source_seen=set()
    for row in source_rows:
        values=[row[c] if c<len(row) else None for c in sc]
        if not any(text(v) for v in values):
            continue
        k=key(*values[:2])
        if k in source_seen:
            raise ValueError('duplicate source identity')
        source_seen.add(k)
        values[2:]=[count(v) for v in values[2:]]
        source.append((k,values))
    out=deepcopy(target_rows); target_seen={}
    for idx,row in enumerate(out):
        if any(text(row[c]) for c in tc[:2]):
            k=key(row[tc[0]],row[tc[1]])
            if k in target_seen:
                raise ValueError('duplicate destination identity')
            target_seen[k]=idx
    stats={'added':0,'updated':0,'skipped':0}
    for k,values in source:
        if k in target_seen:
            if not overwrite:
                stats['skipped']+=1
                continue
            idx=target_seen[k];stats['updated']+=1
        else:
            idx=len(out);out.append([None]*len(target_headers));stats['added']+=1
        for j,c in enumerate(tc):
            out[idx][c]=values[j]
    return out,stats

class FieldExportContractTests(unittest.TestCase):
    def setUp(self):
        self.sh=['Conv.ID','Items Type','INPUT','OUTPUT','S_IN','S_OUT']
    def test_actual_b05_alias_mapping_and_eleven_columns(self):
        result,stats=export_model(self.sh,[['001-A','PE',1,0,0,0]],B05_HEADERS,[])
        self.assertEqual(result,[['001-A','PE',1,0,0,0,None,None,None,None,None]])
        self.assertEqual(stats,{'added':1,'updated':0,'skipped':0})
    def test_header_variations_and_reordering(self):
        target=['pwg','output','DEVICE_NAME','location','s_out','Standard_Block','input','item.type','Safety Block','s_in','pnl']
        result,_=export_model(['s out','ITEM TYPE','device name','input','output','s in'],[[0,'PE','0001',2,1,0]],target,[])
        self.assertEqual(result[0][2],'0001')
        self.assertEqual(result[0][6],2)
        self.assertEqual(result[0][1],1)
    def test_same_conveyor_different_types_preserved(self):
        result,stats=export_model(self.sh,[['1001','PE',1,0,0,0],['1001','EST',0,1,2,0]],B05_HEADERS,[])
        self.assertEqual(len(result),2)
        self.assertEqual(stats['added'],2)
    def test_existing_assignments_and_other_rows_preserved(self):
        target=[['1001','PE',1,0,0,0,'RCP01','G01','L1','STD-001','SAFE-1'],['2001','PE',3,0,0,0,'RCP02','G02','L2','STD-002',None]]
        before=deepcopy(target)
        result,stats=export_model(self.sh,[['1001','PE',2,0,0,0]],B05_HEADERS,target)
        self.assertEqual(result[0][2],2)
        self.assertEqual(result[0][6:],before[0][6:])
        self.assertEqual(result[1],before[1])
        self.assertEqual(target,before)
        self.assertEqual(stats['updated'],1)
    def test_rerun_updates_without_duplicates_and_skip_policy(self):
        row=['1001','PE',1,0,0,0]
        first,_=export_model(self.sh,[row],B05_HEADERS,[])
        second,stats=export_model(self.sh,[row],B05_HEADERS,first)
        self.assertEqual(first,second)
        self.assertEqual(stats['added'],0)
        result,stats=export_model(self.sh,[['1001','PE',9,0,0,0]],B05_HEADERS,first,False)
        self.assertEqual(result,first)
        self.assertEqual(stats['skipped'],1)
    def test_duplicate_source_and_variants_require_review(self):
        with self.assertRaisesRegex(ValueError,'duplicate source'):
            export_model(self.sh+['VARIANT'],[['1001','PE',1,0,0,0,'A'],['1001','PE',2,0,0,0,'B']],B05_HEADERS,[])
    def test_duplicate_destination_requires_review(self):
        row=['1001','PE',1,0,0,0,None,None,None,None,None]
        with self.assertRaisesRegex(ValueError,'duplicate destination'):
            export_model(self.sh,[row[:6]],B05_HEADERS,[row,row])
    def test_missing_id_rejected_never_fabricated(self):
        for row in [[None,'PE',1,0,0,0],['1001',None,1,0,0,0]]:
            with self.assertRaisesRegex(ValueError,'missing identity'):
                export_model(self.sh,[row],B05_HEADERS,[])
    def test_invalid_counts_leave_caller_inputs_unchanged(self):
        for value in [-1,1.5,'2signals','NaN','Infinity',True,2147483648]:
            target=[['X','PE',1,0,0,0,'P','G','L','STD',None]]; before=deepcopy(target)
            with self.assertRaisesRegex(ValueError,'invalid count'):
                export_model(self.sh,[['1001','PE',value,0,0,0]],B05_HEADERS,target)
            self.assertEqual(target,before)
    def test_blank_counts_and_zero_preserved_distinct(self):
        out,_=export_model(self.sh,[['00001','PE',None,0,'',0]],B05_HEADERS,[])
        self.assertEqual(out[0][:6],['00001','PE',None,0,None,0])
    def test_ambiguous_or_missing_headers_rejected(self):
        for headers in [self.sh[:-1],self.sh+['device name']]:
            with self.assertRaises(ValueError):
                export_model(headers,[['1','PE',1,0,0,0,None]],B05_HEADERS,[])
    def test_case_whitespace_match_preserves_full_device_name(self):
        target=[['a-00001','pe',1,0,0,0,'P','G','L',None,None]]
        out,stats=export_model(self.sh,[[' A-00001 ','PE',2,0,0,0]],B05_HEADERS,target)
        self.assertEqual(len(out),1); self.assertEqual(stats['updated'],1)
        self.assertEqual(out[0][0],' A-00001 ')

if __name__=='__main__':unittest.main(verbosity=2)
