"""HTTP integration checks for background import/build/export and review state."""
import io,os,tempfile,time,unittest
from pathlib import Path
_TEMP=tempfile.TemporaryDirectory()
os.environ['ONGEN_DATA_DIR']=str(Path(_TEMP.name)/'data')
os.environ['ONGEN_EMPTY_PROJECT']='1'
from fastapi.testclient import TestClient
from app.server import app,workspace
from test_engine import fixture

class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client=TestClient(app);path=Path(_TEMP.name)/'master.xlsm';fixture(path)
        with path.open('rb') as file:response=cls.client.post('/api/import',files={'file':('master.xlsm',file,'application/vnd.ms-excel.sheet.macroEnabled.12')})
        assert response.status_code==200,response.text
        cls.finish(response.json()['job_id'])
    @classmethod
    def finish(cls,identity):
        for _ in range(300):
            r=cls.client.get('/api/jobs/'+identity).json()
            if r['status'] in ('completed','failed','cancelled'):
                assert r['status']=='completed',r
                return r
            time.sleep(.01)
        raise AssertionError('background job timed out')
    def test_01_project_and_imported_records(self):
        p=self.client.get('/api/project').json();self.assertEqual(p['summary']['sources'],1)
        r=self.client.get('/api/records',params={'sheet':'SIS_TAG_PD5','q':'001A'}).json();self.assertEqual(r['total'],1)
    def test_02_background_validation_and_build(self):
        for endpoint in ('validate','build/phase3'):
            r=self.client.post('/api/'+endpoint);self.assertEqual(r.status_code,200);self.finish(r.json()['job_id'])
    def test_03_export_xlsx_and_csv(self):
        self.finish(self.client.post('/api/build/phase3').json()['job_id'])
        r=self.client.get('/api/export/engineering.xlsx');self.assertEqual(r.status_code,200);self.assertTrue(r.content.startswith(b'PK'))
        r=self.client.get('/api/export/phase4.csv');self.assertEqual(r.status_code,200);self.assertIn('SIS_sequence',r.text)
    def test_04_cross_origin_writes_rejected(self):
        r=self.client.post('/api/validate',headers={'Origin':'https://untrusted.example'});self.assertEqual(r.status_code,403)
        r=self.client.get('/api/project',headers={'Host':'evil.example'});self.assertEqual(r.status_code,403)
    def test_05_engineering_math_and_errors(self):
        self.assertEqual(self.client.post('/api/power/calculate',json={'voltage_v':24,'power_kw':.24}).json()['current_a'],10)
        self.assertEqual(self.client.post('/api/power/calculate',json={'voltage_v':0,'power_kw':1}).status_code,422)
    def test_06_device_review_requires_note_and_records_choice(self):
        self.finish(self.client.post('/api/build/phase3').json()['job_id'])
        d=self.client.get('/api/generated/devices').json()['rows'][0]
        payload={'device_key':d['DEVICE_KEY'],'device_name':'0001-PE','include_in_io':True,'review_note':''}
        self.assertEqual(self.client.post('/api/devices/review',json=payload).status_code,422)
        payload['review_note']='fixture identity confirmed';self.assertEqual(self.client.post('/api/devices/review',json=payload).status_code,200)
        history=self.client.get('/api/history').json()['rows'];self.assertEqual(history[0]['action'],'review_device')
    def test_07_apply_requires_explicit_confirmation(self):
        self.assertEqual(self.client.post('/api/returns/apply',json={'plan_id':'invalid','confirm':False}).status_code,422)

if __name__=='__main__':unittest.main()
