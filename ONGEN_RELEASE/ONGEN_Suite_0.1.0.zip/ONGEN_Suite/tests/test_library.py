import tempfile,unittest
from pathlib import Path
from openpyxl import Workbook
from app.engine import Workspace
from app.library import expand

class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();root=Path(self.tmp.name);self.w=Workspace(root/'data')
        w=Workbook();s=w.active;s.title='FUNCTION_MASTER';s.append(['FUNCTION_CODE','STATUS']);s.append(['CF-X','MIGRATION - REVIEW BEFORE PRODUCTION'])
        s=w.create_sheet('FUNCTION_COMPONENTS');s.append(['FUNCTION_CODE','COMPONENT_CODE','VARIANT_CODE','QTY','ACTIVE']);s.append(['CF-X','C1','V1',3,'YES']);s.append(['CF-X','C2','V1',1,'YES'])
        s=w.create_sheet('VARIANT_BOM');s.append(['VARIANT_CODE','PART_KEY','QTY'])
        for n in range(12):s.append(['V1',f'PK{n}',2])
        s=w.create_sheet('PART_MASTER');s.append(['PART_KEY','MANUFACTURER','PART_NUMBER','COST_CURRENCY','CURRENT_COST'])
        for n in range(12):s.append([f'PK{n}','M1',f'PN{n}','USD',1])
        p=root/'Master Library.xlsx';w.save(p);self.w.import_file(p)
    def tearDown(self):self.tmp.cleanup()
    def test_components_are_selected_not_assumed(self):
        r=expand(self.w,{'function_code':'CF-X'});self.assertTrue(r['requires_selection']);self.assertEqual(len(r['components']),2)
    def test_more_than_nine_parts_and_quantity_conservation(self):
        r=expand(self.w,{'function_code':'CF-X','component_codes':['C1'],'quantity':4});self.assertEqual(len(r['rows']),12)
        self.assertTrue(all(row['TOTAL_QTY']==24 for row in r['rows']));self.assertIn('REVIEW',r['rows'][0]['LIBRARY_STATUS'])
    def test_unknown_duplicate_components_rejected(self):
        for codes in (['missing'],['C1','C1'],[]):
            with self.subTest(codes=codes),self.assertRaises(ValueError):expand(self.w,{'function_code':'CF-X','component_codes':codes})

if __name__=='__main__':unittest.main()
