"""Behavior regressions for the new Python engine. These do not execute Excel/VBA."""
import csv, hashlib, io, json, math, tempfile, unittest, zipfile
from pathlib import Path
from openpyxl import Workbook,load_workbook
from app.engine import Workspace
from app import exports
from app.power import calculate
from app.library import expand


def fixture(path, duplicate_boq=False, duplicate_seq=False, sparse=True):
    w=Workbook();s=w.active;s.title='SIS_TAG_PD5'
    s.append(['HANDLE','SIS_SEQUENCE','LPN','TYPE','CONTROL_FUNCTION_NUMBER','AREA_NUMBER','SWITCHGROUP'])
    s.append(['001A','0001','L1','MC','CF-X',11,'G1'])
    s.append(['001B','0001' if duplicate_seq else '0002','L2','MC','CF-X',11,'G1'])
    if sparse:s['XFD1048576'].number_format='0.00'
    s=w.create_sheet('BOQ');s.append(['Layout Position Number','Module Length (ML)','Motor Power (Main Drive)']);s.append([None,'[mm]','[kW]']);s.append(['L1',1200,.035]);s.append(['L2',2400,.07])
    if duplicate_boq:s.append(['L1',9999,999])
    s=w.create_sheet('FUNCTION DEFINITION');s.append(['CONTROL_FUNCTION_NUMBER','CONTROL_FUNCTION_TAG','BLOCK','PART_NUM_1','MANUF_NAME_1','INPUT','conveyor Type'])
    s.append(['CF-X','PE','SENSOR','P1','M1',1,'Straight']);s.append(['CF-X','PE','SENSOR','P1','M1',1,'Curve']);s.append(['CF-X','EST','ESTOP','P2','M2',0,None])
    w.save(path)

class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.w=Workspace(self.root/'data');self.file=self.root/'master.xlsm';fixture(self.file)
    def tearDown(self):self.temp.cleanup()
    def load(self):return self.w.import_file(self.file)
    def test_sparse_formatting_and_boq_units_do_not_create_phantom_records(self):
        self.load()
        with self.w.connect() as db:
            rows,_=self.w._rows(db,'SIS_TAG_PD5','pd_master');boq,_=self.w._rows(db,'BOQ','pd_master')
        self.assertEqual(len(rows),2);self.assertEqual(len(boq),2);self.assertEqual(rows[0]['HANDLE'],'001A')
    def test_same_file_import_is_idempotent_and_original_unchanged(self):
        digest=hashlib.sha256(self.file.read_bytes()).hexdigest();a=self.load();b=self.load()
        self.assertEqual(a['source_id'],b['source_id']);self.assertTrue(b['duplicate']);self.assertEqual(len(self.w.sources()),1)
        self.assertEqual(hashlib.sha256(self.file.read_bytes()).hexdigest(),digest)
    def test_build_joins_once_preserves_identifiers_and_deduplicates_repeated_definition(self):
        self.load();r=self.w.build_phase3();self.assertEqual(r['rows'],2);self.assertEqual(r['devices'],4)
        rows=self.w.generated('phase3')['rows'];self.assertEqual(rows[0]['SIS_SEQUENCE'],'0001');self.assertEqual(rows[0]['Module Length (ML)'],1200)
        self.assertEqual(rows[1]['Motor Power (Main Drive)'],.07);self.assertEqual(rows[0]['SOURCE_ROW'],2)
    def test_duplicate_boq_lpn_is_not_arbitrarily_enriched(self):
        fixture(self.file,duplicate_boq=True);self.load();self.w.validate();self.w.build_phase3()
        self.assertNotIn('Module Length (ML)',self.w.generated('phase3')['rows'][0])
        self.assertIn('DUPLICATE_BOQ_LPN',{r['code'] for r in self.w.issues()['issues']})
    def test_cancellation_rolls_back_entire_source(self):
        def cancel(*args):raise InterruptedError('cancelled')
        with self.assertRaises(InterruptedError):self.w.import_file(self.file,progress=cancel)
        self.assertEqual(self.w.sources(),[])
        with self.w.connect() as db:self.assertEqual(db.execute('SELECT count(*) FROM records').fetchone()[0],0)
    def test_formula_missing_cache_is_flagged_not_evaluated(self):
        w=Workbook();s=w.active;s.append(['FUNCTION_CODE','Value']);s.append(['CF-A','=1+1']);p=self.root/'formulas.xlsx';w.save(p);self.w.import_file(p)
        self.assertIn('FORMULA_CACHE_MISSING',{r['code'] for r in self.w.issues()['issues']})
    def test_actual_b05_io_header_order_and_values(self):
        self.load();self.w.build_phase3();r=exports.io_packet(self.w)
        self.assertEqual(r['columns'],['DEVICE NAME','ITEM TYPE','INPUT','OUTPUT','S_IN','S_OUT','PNL','PWG','LOCATION','Standard Block','Safety Block'])
        self.assertEqual(r['rows'][0]['DEVICE NAME'],'0001-PE');self.assertEqual(r['rows'][0]['PWG'],'G1');self.assertEqual(r['rows'][0]['LOCATION'],11)
    def test_duplicate_io_identity_blocks_export(self):
        fixture(self.file,duplicate_seq=True);self.load();self.w.build_phase3()
        with self.assertRaisesRegex(ValueError,'Ambiguous IO identity'):exports.io_packet(self.w)
    def test_power_packet_forty_one_headers_no_invented_load(self):
        self.load();self.w.build_phase3();r=exports.phase4(self.w)
        self.assertEqual(len(r['columns']),41);self.assertEqual(r['rows'][0]['SIS_sequence'],'0001');self.assertIsNone(r['rows'][0]['Load'])
    def test_return_preview_sparse_row_trace_and_protected_fields(self):
        self.load();w=Workbook();s=w.active;s.title='Return';s.append(['HANDLE','NETWORK_IP','CONTROL_FUNCTION_NUMBER','X']);s.cell(5,1,'001A');s.cell(5,2,'10.1.1.5');s.cell(5,3,'WRONG');s.cell(5,4,999)
        p=self.root/'return.xlsx';w.save(p);source=self.w.import_file(p);self.w.build_phase3();plan=self.w.plan_return(source['source_id'],'Return')
        self.assertEqual(plan['updates'][0]['return_row'],5);self.assertEqual(set(plan['updates'][0]['changes']),{'NETWORK_IP'})
        result=self.w.apply_return(plan);self.assertEqual(result['fields_updated'],1);self.assertEqual(self.w.generated('phase3')['rows'][0]['NETWORK_IP'],'10.1.1.5')
    def test_duplicate_return_target_blocks_all_edits(self):
        self.load();w=Workbook();s=w.active;s.title='Return';s.append(['HANDLE','NETWORK_IP']);s.append(['001A','10.0.0.1']);s.append(['001A','10.0.0.2']);p=self.root/'return.xlsx';w.save(p);source=self.w.import_file(p);self.w.build_phase3()
        plan=self.w.plan_return(source['source_id'],'Return');self.assertTrue(plan['updates'][0]['blocked']);self.assertEqual(self.w.apply_return(plan)['fields_updated'],0)
    def test_stale_return_plan_rejected(self):
        self.load();w=Workbook();s=w.active;s.title='Return';s.append(['HANDLE','NETWORK_IP']);s.append(['001A','10.0.0.1']);p=self.root/'return.xlsx';w.save(p);src=self.w.import_file(p);self.w.build_phase3();plan=self.w.plan_return(src['source_id'],'Return')
        with self.w.connect() as db:
            rows=self.w.generated('phase3')['rows'];rows[0]['NETWORK_IP']='changed';self.w._put_generated(db,'phase3',rows)
        with self.assertRaisesRegex(ValueError,'changed since preview'):self.w.apply_return(plan)
    def test_xlsx_export_preserves_identifier_text_and_literals(self):
        self.load();self.w.build_phase3()
        with self.w.connect() as db:
            rows=self.w.generated('phase3')['rows'];rows[0]['=BADHEADER']='=1+1';self.w._put_generated(db,'phase3',rows)
        w=load_workbook(io.BytesIO(exports.xlsx_bytes(self.w)),data_only=False)
        s=w['SIS_TAG_IMPORT_PD2'];headers=[c.value for c in s[1]];col=headers.index('=BADHEADER')+1
        self.assertEqual(s.cell(1,col).data_type,'s');self.assertEqual(s.cell(2,col).data_type,'s');self.assertEqual(s.cell(2,col).value,'=1+1')
        self.assertEqual(s.cell(2,headers.index('SIS_SEQUENCE')+1).value,'0001')
    def test_validation_flags_missing_power_and_unknown_function(self):
        self.load();self.w.validate();self.assertIn('POWER_WORKBOOK_UNAVAILABLE',{r['code'] for r in self.w.issues()['issues']})

class ExportMathTests(unittest.TestCase):
    def test_csv_protects_headers_and_values(self):
        raw=exports.csv_bytes([{'=HEADER':'  =WEBSERVICE("bad")','ID':'0001'}]);rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
        self.assertEqual(rows[0][0],"'=HEADER");self.assertTrue(rows[1][0].startswith("'"));self.assertEqual(rows[1][1],'0001')
    def test_dc_and_three_phase_math(self):
        a=calculate({'voltage_v':24,'power_kw':.24,'phase':1,'efficiency':1,'power_factor':1,'reserve_fraction':.2,'psu_rating_a':5})
        self.assertEqual(a['current_a'],10);self.assertEqual(a['design_current_a'],12);self.assertEqual(a['psu_count'],3)
        b=calculate({'voltage_v':400,'power_kw':math.sqrt(3)*4,'phase':3,'reserve_fraction':0});self.assertAlmostEqual(b['current_a'],10)
    def test_invalid_and_extreme_math_rejected(self):
        for field,value in [('voltage_v',0),('power_kw',float('nan')),('efficiency',0),('power_factor',1.1),('quantity',1.5),('phase',2),('power_kw',1e308),('voltage_v',True)]:
            with self.subTest(field=field,value=value),self.assertRaises(ValueError):calculate({'voltage_v':24,'power_kw':.24,field:value})
        with self.assertRaises(ValueError):calculate({'voltage_v':1e-308,'power_kw':1,'efficiency':1e-308})

if __name__=='__main__':unittest.main()
