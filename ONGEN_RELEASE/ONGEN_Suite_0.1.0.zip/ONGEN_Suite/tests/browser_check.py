"""End-to-end UI checks. Point at a disposable seeded workspace, not a live engineering project."""
import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
results={'runtime':'Linux system Chromium via Playwright','native_windows_verified':False,'checks':[],'javascript_errors':[]}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1500,'height':1000},accept_downloads=True)
    page.on('pageerror',lambda e:results['javascript_errors'].append(str(e)))
    page.goto('http://127.0.0.1:8766');page.locator('.hero h1').wait_for()
    results['checks'].append('Connected dashboard shows actual seeded project counts')
    for view in ['sources','workflow','power','library','issues','exports','devices','assembly']:
        page.locator(f'nav [data-view="{view}"]').click();page.locator('main h1').wait_for();page.wait_for_timeout(150)
    results['checks'].append('All nine navigation views render without JavaScript errors')
    page.locator('nav [data-view="power"]').click()
    assert page.locator('#power-form').evaluate('(f)=>f.checkValidity()')
    page.locator('#phase').select_option('1')
    for field,value in {'voltage_v':'24','power_kw':'0.24','quantity':'1','efficiency':'1','power_factor':'1','diversity':'1','reserve_fraction':'0.2','psu_rating_a':'5'}.items():page.locator('#'+field).fill(value)
    page.locator('#power-form button[type="submit"]').click();page.locator('#power-result .result-number').wait_for()
    assert '12' in page.locator('#power-result .result-number').inner_text()
    results['checks'].append('Power form submits valid defaults and calculates a 24V 240W load as 10A, 12A with reserve')
    page.locator('nav [data-view="assembly"]').click();page.locator('#assembly-form button').click()
    page.locator('[data-component]').first.wait_for();page.locator('[data-component]').first.check();page.locator('#expand-assembly').click()
    page.locator('#assembly-result table').wait_for();assert page.locator('#assembly-result tbody tr').count()==4
    with page.expect_download() as download:page.locator('#bom-download').click()
    assert download.value.suggested_filename=='ONGEN_assembly_BOM.csv'
    results['checks'].append('Actual CF-B-010 selected component yields four BOM child rows and a downloadable CSV')
    page.locator('nav [data-view="sources"]').click();page.locator('#records-table tbody tr').first.wait_for()
    results['checks'].append('Source table retrieves actual data rows')
    page.locator('nav [data-view="devices"]').click();page.locator('[data-device-row]').first.wait_for()
    row=page.locator('[data-device-row]').first;row.locator('[data-note]').fill('AUTOMATED UI TEST — not engineering approval');row.locator('[data-device-save]').click()
    page.get_by_text('Device review saved',exact=True).wait_for()
    results['checks'].append('Device review saves an explicit note in a disposable test workspace')
    with page.expect_response('**/api/export/engineering.xlsx') as response:
        page.evaluate("fetch('/api/export/engineering.xlsx')")
    assert response.value.status==200
    results['checks'].append('Real project XLSX review package downloads successfully; unresolved IO remains excluded')
    response=page.request.get('http://127.0.0.1:8766/api/export/io.csv');assert response.status==422
    results['checks'].append('Ambiguous real IO identity returns a visible validation error instead of a partial success')
    page.goto('http://127.0.0.1:8766/#overview');page.locator('.hero h1').wait_for();page.screenshot(path='analysis/ONGEN_browser_preview.png',full_page=True)
    page.set_viewport_size({'width':1100,'height':800});page.goto('http://127.0.0.1:8766/#power');page.locator('#power-form').wait_for()
    assert page.locator('#power-form').is_visible()
    results['checks'].append('1100px viewport retains the power form')
    assert not results['javascript_errors'],results['javascript_errors']
    browser.close()
results['passed']=len(results['checks'])
Path('analysis/browser_validation.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
