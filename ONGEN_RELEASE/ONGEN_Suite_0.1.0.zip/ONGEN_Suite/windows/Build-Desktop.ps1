$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot
$Runtime = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
if (!(Test-Path $Runtime)) {
    & py -3 -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11+ and retry.' }
}
& $Runtime -m pip install -r desktop-requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
$BuildArguments = @('--noconfirm','--clean','--onedir','--windowed','--name','ONGEN',
    '--collect-all','webview','--collect-submodules','uvicorn',
    '--add-data','app\static;app\static',
    '--add-data','analysis\ONGEN_AUDIT_REPORT.md;analysis')
if (Test-Path 'sample_project') { $BuildArguments += @('--add-data','sample_project;sample_project') }
$BuildArguments += 'desktop.py'
& $Runtime -m PyInstaller @BuildArguments
if ($LASTEXITCODE -ne 0) { throw 'Desktop build failed. Inspect PyInstaller output.' }
Write-Host 'Build produced dist\ONGEN\ONGEN.exe. Distribute the entire dist\ONGEN folder.'
Write-Host 'Run Windows acceptance tests before engineering use. This script does not code-sign the executable.'
