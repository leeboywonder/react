param([switch]$Desktop, [switch]$NoInstall)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot
$Runtime = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
if (!(Test-Path $Runtime)) {
    if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 -m venv .venv }
    elseif (Get-Command python -ErrorAction SilentlyContinue) { & python -m venv .venv }
    else { throw 'Install Python 3.11 or newer from python.org, then rerun this script.' }
    if ($LASTEXITCODE -ne 0) { throw 'Virtual environment creation failed.' }
}
if (!$NoInstall) {
    $Requirements = if ($Desktop) { 'desktop-requirements.txt' } else { 'requirements.txt' }
    & $Runtime -m pip install -r $Requirements
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check Internet access and pip output.' }
}
# Both launch modes share one persistent user workspace.
if (!$env:ONGEN_DATA_DIR) { $env:ONGEN_DATA_DIR = Join-Path $env:LOCALAPPDATA 'ONGEN\data' }
if ($Desktop) { & $Runtime desktop.py }
else { & $Runtime run.py --browser }
if ($LASTEXITCODE -ne 0) { throw 'ONGEN exited with an error. Read the output or %LOCALAPPDATA%\ONGEN\desktop.log.' }
