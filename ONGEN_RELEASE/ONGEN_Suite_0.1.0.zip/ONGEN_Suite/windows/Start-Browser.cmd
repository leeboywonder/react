@echo off
powershell -NoProfile -File "%~dp0Start-ONGEN.ps1"
pause
