"""Import originals from an explicit local folder and validate. No Office macros run."""
import argparse,json,time
from pathlib import Path
from app.engine import Workspace
p=argparse.ArgumentParser();p.add_argument('input_dir');p.add_argument('--data',default='data');a=p.parse_args()
w=Workspace(a.data);results=[]
for f in sorted(Path(a.input_dir).rglob('*')):
    if f.suffix.lower() in ('.xlsm','.xlsx','.csv'):
        result=w.import_file(f);results.append(result)
        print(json.dumps({'file':f.name,'result':result},ensure_ascii=False))
w.validate();results.append({'phase3':w.build_phase3()})
Path('analysis/import_validation.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
print(json.dumps(w.project()['summary']))
