"""Verify retained original-file hashes without opening Excel or executing macros."""
import csv,hashlib
from pathlib import Path
base=Path(__file__).resolve().parent
with (base/'analysis/original_hashes.csv').open(newline='') as f:
    rows=list(csv.DictReader(f))
for row in rows:
    matches=list((base/'sample_project/inputs').glob(row['sha256']+'.*'))
    if len(matches)!=1:raise SystemExit('Missing/ambiguous retained input: '+row['name'])
    path=matches[0]
    if path.stat().st_size!=int(row['size_bytes']) or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
        raise SystemExit('Hash mismatch: '+row['name'])
    print('Verified:',row['name'])
print(f'{len(rows)} retained inputs verified. Power V4.6 was not available and is not included.')
