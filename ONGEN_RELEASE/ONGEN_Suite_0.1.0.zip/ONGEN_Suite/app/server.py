"""Local-only ONGEN API; single engine for browser and Windows desktop."""
from __future__ import annotations
import asyncio, hashlib, json, os, shutil, sys, tempfile, threading, time, uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from .engine import Workspace
from .power import calculate
from . import exports

BASE=Path(__file__).resolve().parent.parent
DATA=Path(os.environ.get('ONGEN_DATA_DIR',str(BASE/'data'))).resolve()
SAMPLE=BASE/'sample_project'
if os.environ.get('ONGEN_EMPTY_PROJECT') != '1' and not (DATA/'ongen.sqlite3').exists() and (SAMPLE/'ongen.sqlite3').exists():
    DATA.mkdir(parents=True,exist_ok=True)
    for path in SAMPLE.iterdir():
        dest=DATA/path.name
        if not dest.exists():
            shutil.copytree(path,dest) if path.is_dir() else shutil.copy2(path,dest)
workspace=Workspace(DATA)
app=FastAPI(title='ONGEN Engineering Workspace',version='0.1.0')
pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='ongen-engineering')
jobs={};plans={};joblock=threading.Lock()
STATIC=Path(__file__).parent/'static'
if STATIC.exists():app.mount('/static',StaticFiles(directory=STATIC),name='static')

@app.middleware('http')
async def local_requests(request:Request,call_next):
    # Reject browser cross-origin writes and DNS-rebinding hostnames. Bind loopback only.
    host=request.url.hostname
    if host not in ('127.0.0.1','localhost','::1','testserver'):
        return JSONResponse({'detail':'ONGEN accepts loopback hosts only'},status_code=403)
    origin=request.headers.get('origin')
    if request.method not in ('GET','HEAD','OPTIONS') and origin:
        from urllib.parse import urlparse
        parsed=urlparse(origin)
        if parsed.netloc!=request.url.netloc or parsed.scheme!=request.url.scheme:
            return JSONResponse({'detail':'Cross-origin write rejected'},status_code=403)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Cache-Control']='no-store'
    return response

@app.exception_handler(ValueError)
async def bad_input(request,exc):return JSONResponse({'detail':str(exc)},status_code=422)

@app.get('/')
def index():
    p=STATIC/'index.html'
    if not p.exists():return JSONResponse({'name':'ONGEN','docs':'/docs'})
    return FileResponse(p)

@app.get('/api/project')
def project():return workspace.project()

@app.get('/api/records')
def records(source_id:str|None=None,sheet:str|None=None,q:str='',offset:int=0,limit:int=100):
    return workspace.records(source_id,sheet,q,offset,limit)

@app.get('/api/issues')
def issues():return workspace.issues()

@app.get('/api/functions')
def functions():return workspace.functions()

@app.get('/api/generated/{name}')
def generated(name:str):return workspace.generated(name)

@app.get('/api/history')
def history():
    with workspace.connect() as db:return {'rows':[dict(r) for r in db.execute('SELECT * FROM changes ORDER BY id DESC LIMIT 200')]}

def submit(title,operation):
    identity=uuid.uuid4().hex
    job={'id':identity,'status':'queued','progress':0,'message':title,'cancel_requested':False}
    with joblock:
        if len(jobs)>200:
            for key in list(jobs):
                if jobs[key]['status'] in ('completed','failed','cancelled'):jobs.pop(key)
        jobs[identity]=job
    def update(percent,message):
        if job['cancel_requested']:raise InterruptedError('Cancelled; changes rolled back')
        if percent is not None:job['progress']=percent
        if message:job['message']=message
    def run():
        started=time.perf_counter();job['status']='running'
        try:
            update(1,title)
            result=operation(update)
            job.update(status='completed',progress=100,message='Completed',result=result)
        except InterruptedError as e:job.update(status='cancelled',message=str(e))
        except Exception as e:job.update(status='failed',message='Operation failed',error=str(e))
        finally:job['seconds']=round(time.perf_counter()-started,4)
    pool.submit(run)
    return {'job_id':identity}

@app.get('/api/jobs/{identity}')
def job(identity:str):
    if identity not in jobs:raise HTTPException(404,'Job not found')
    return jobs[identity]

@app.post('/api/jobs/{identity}/cancel')
def cancel(identity:str):
    if identity not in jobs:raise HTTPException(404,'Job not found')
    jobs[identity]['cancel_requested']=True
    return {'requested':True}

@app.post('/api/import')
async def upload(file:UploadFile=File(...)):
    name=Path(file.filename or '').name
    if Path(name).suffix.lower() not in ('.xlsm','.xlsx','.csv'):raise HTTPException(422,'Choose an XLSM, XLSX or CSV file')
    staging=DATA/'staging';staging.mkdir(exist_ok=True)
    dest=staging/(uuid.uuid4().hex+Path(name).suffix.lower())
    try:
        size=0
        with dest.open('wb') as out:
            while chunk:=await file.read(1024*1024):
                size+=len(chunk)
                if size>256*1024*1024:raise HTTPException(413,'Local import limit is 256 MiB')
                out.write(chunk)
    except BaseException:
        dest.unlink(missing_ok=True);raise
    finally:await file.close()
    def operation(update):
        try:return workspace.import_file(dest,name,update)
        finally:dest.unlink(missing_ok=True)
    return submit('Importing '+name,operation)

@app.post('/api/validate')
def validate():return submit('Validating source identities and cross-references',workspace.validate)

@app.post('/api/build/phase3')
def build():return submit('Building function device workspace',workspace.build_phase3)

@app.post('/api/power/calculate')
def power(data:dict):return calculate(data)

@app.post('/api/returns/preview')
def preview(data:dict):
    if not data.get('source_id') or not data.get('sheet'):raise ValueError('Choose return source and sheet')
    plan=workspace.plan_return(data['source_id'],data['sheet']);identity=uuid.uuid4().hex
    plans[identity]=plan
    return {'plan_id':identity,**plan}

@app.post('/api/returns/apply')
def apply(data:dict):
    identity=data.get('plan_id')
    if data.get('confirm') is not True:raise ValueError('Review the plan and explicitly confirm applying changes')
    if identity not in plans:raise HTTPException(404,'Plan not found; create a new preview')
    result=workspace.apply_return(plans[identity]);plans.pop(identity)
    return result

@app.get('/api/export/{kind}')
def export(kind:str):
    if kind=='project.json':content=json.dumps(workspace.snapshot(),ensure_ascii=False,indent=2).encode();mime='application/json'
    elif kind=='report.html':content=exports.report_html(workspace,BASE/'analysis'/'ONGEN_AUDIT_REPORT.md');mime='text/html'
    elif kind=='engineering.xlsx':content=exports.xlsx_bytes(workspace);mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    elif kind in ('issues.csv','devices.csv','phase3.csv','phase4.csv','phase5.csv','io.csv','phase3_review.csv'):
        if kind=='issues.csv':packet=workspace.issues()
        elif kind in ('io.csv','phase5.csv'):packet=exports.io_packet(workspace)
        elif kind=='phase4.csv':packet=exports.phase4(workspace)
        elif kind=='phase3.csv':packet=exports.phase3(workspace)
        else:packet=workspace.generated(kind[:-4])
        if not packet.get('rows') and kind!='issues.csv':raise ValueError('No generated rows; build and review Phase 3 first')
        content=exports.csv_bytes(packet.get('rows',packet.get('issues',[])),packet.get('columns'));mime='text/csv'
    else:raise HTTPException(404,'Unknown export')
    return Response(content,media_type=mime,headers={'Content-Disposition':f'attachment; filename="ONGEN_{kind}"'})

@app.post('/api/bom/expand')
def expand_bom(data:dict):
    from .library import expand
    return expand(workspace,data)

@app.post('/api/devices/review')
def review_device(data:dict):
    with workspace.lock,workspace.connect() as db:
        result=workspace.generated('devices')
        matches=[d for d in result['rows'] if d.get('DEVICE_KEY')==data.get('device_key')]
        if len(matches)!=1:raise ValueError('Device identity is missing or ambiguous; rebuild and review')
        if not isinstance(data.get('include_in_io'),bool):raise ValueError('include_in_io must be true or false')
        name=str(data.get('device_name','')).strip()
        if data['include_in_io'] and (not name or len(name)>128 or name[0] in '=+-@'):raise ValueError('Enter a usable device name up to 128 characters')
        note=str(data.get('review_note','')).strip()
        if not note:raise ValueError('A review note is required')
        item=matches[0];item.update(DEVICE_NAME_OVERRIDE=name,INCLUDE_IN_IO=data['include_in_io'],REVIEW_NOTE=note,REVIEW_STATUS='reviewed by user')
        workspace._put_generated(db,'devices',result['rows'])
        workspace._log(db,'review_device',{'device_key':data['device_key'],'device_name':name,'include_in_io':data['include_in_io'],'note':note})
    return {'updated':True,'device_key':data['device_key']}
