"""Transparent load estimates. Not a protection, cable, safety, or compliance design."""
import math


def calculate(data):
    def number(name, default=None, low=0, high=None, strictly=False):
        value = data.get(name, default)
        if isinstance(value, bool):
            raise ValueError(f'{name} must be numeric')
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ValueError(f'{name} must be numeric') from None
        if not math.isfinite(value) or value < low or (strictly and value == low) or (high is not None and value > high):
            raise ValueError(f'{name} outside permitted range')
        return value
    voltage = number('voltage_v', strictly=True)
    phase = number('phase', 1)
    if phase not in (1, 3):
        raise ValueError('phase must be 1 or 3')
    power = number('power_kw')
    efficiency = number('efficiency', 1, high=1, strictly=True)
    pf = number('power_factor', 1, high=1, strictly=True)
    qty = number('quantity', 1, strictly=True)
    if not qty.is_integer():
        raise ValueError('quantity must be an integer')
    diversity = number('diversity', 1, high=1, strictly=True)
    reserve = number('reserve_fraction', .2, high=10)
    denominator = voltage * efficiency * pf * (math.sqrt(3) if phase == 3 else 1)
    if not math.isfinite(denominator) or denominator <= 0:
        raise ValueError('Electrical denominator exceeds supported numeric range')
    current = power * 1000 * qty * diversity / denominator
    design = current * (1 + reserve)
    if not math.isfinite(current) or not math.isfinite(design):
        raise ValueError('Calculated current exceeds supported numeric range')
    result = {'current_a': round(current, 6), 'design_current_a': round(design, 6),
              'status': 'estimate', 'input': data,
              'formula': 'I = P[kW] × 1000 × quantity × diversity / (V × efficiency × PF × phase_factor)',
              'assumptions': ['Power is mechanical/output power; efficiency is applied once.',
                 'For three-phase loads, voltage is line-to-line and loads are balanced.',
                 'For DC, select phase=1 and power_factor=1.',
                 'Reserve is a multiplier: design current = current × (1 + reserve).',
                 'PSU count is arithmetic capacity only; does not allocate terminals, redundancy, inrush, cables or safety protection.',
                 'These are new transparent estimates, not validated equivalents of the unavailable Power Calculation workbook.']}
    if data.get('psu_rating_a') not in (None, ''):
        rating = number('psu_rating_a', strictly=True)
        result['psu_count'] = math.ceil(design / rating)
    return result
