"""Normalized, uncapped library assembly preview with explicit component selection."""
import math
from collections import defaultdict
from .engine import get, text

def expand(workspace,request):
    code=text(request.get('function_code')).upper()
    try:quantity=float(request.get('quantity',1))
    except (TypeError,ValueError):raise ValueError('quantity must be a positive integer') from None
    if not math.isfinite(quantity) or quantity<=0 or not quantity.is_integer():raise ValueError('quantity must be a positive integer')
    with workspace.connect() as db:
        functions,_=workspace._rows(db,'FUNCTION_MASTER','function_library')
        components,_=workspace._rows(db,'FUNCTION_COMPONENTS','function_library')
        bom,_=workspace._rows(db,'VARIANT_BOM','function_library')
        parts,_=workspace._rows(db,'PART_MASTER','function_library')
    fm=[r for r in functions if text(get(r,'FUNCTION_CODE')).upper()==code]
    if len(fm)!=1:raise ValueError('Choose one unique library FUNCTION_CODE')
    component_codes=request.get('component_codes')
    candidates=[r for r in components if text(get(r,'FUNCTION_CODE')).upper()==code and text(get(r,'ACTIVE')).upper()=='YES']
    if component_codes is None:
        return {'function':fm[0],'components':candidates,'requires_selection':True,
                'note':'Select component codes explicitly. Conveyor-dependent components are not assumed to be simultaneously installed.'}
    if not isinstance(component_codes,list) or not component_codes or len(set(component_codes))!=len(component_codes):raise ValueError('Select distinct component_codes')
    available={text(get(r,'COMPONENT_CODE')):r for r in candidates}
    if any(c not in available for c in component_codes):raise ValueError('Selected component not an active member of this function')
    byvariant=defaultdict(list);bykey=defaultdict(list)
    for r in bom:byvariant[text(get(r,'VARIANT_CODE'))].append(r)
    for r in parts:bykey[text(get(r,'PART_KEY'))].append(r)
    output=[]
    for cc in component_codes:
        c=available[cc];variant=text(get(c,'VARIANT_CODE'))
        if not byvariant[variant]:raise ValueError(f'{cc}: variant has no BOM')
        for part in byvariant[variant]:
            key=text(get(part,'PART_KEY'))
            if len(bykey[key])!=1:raise ValueError(f'{key}: missing or ambiguous part identity')
            p=bykey[key][0]
            try:cqty=float(get(c,'QTY'));pqty=float(get(part,'QTY'))
            except (TypeError,ValueError):raise ValueError(f'{cc}/{key}: invalid component/part quantity') from None
            total=quantity*cqty*pqty
            if not all(math.isfinite(v) and v>0 for v in (cqty,pqty,total)):raise ValueError(f'{cc}/{key}: quantities must be positive and finite')
            output.append({'FUNCTION_CODE':code,'COMPONENT_CODE':cc,'VARIANT_CODE':variant,'PART_KEY':key,
                           'MANUFACTURER':get(p,'MANUFACTURER'),'PART_NUMBER':get(p,'PART_NUMBER'),
                           'INSTANCE_QTY':quantity,'COMPONENT_QTY':cqty,'PART_QTY':pqty,'TOTAL_QTY':total,
                           'COST_CURRENCY':get(p,'COST_CURRENCY'),'UNIT_COST':get(p,'CURRENT_COST'),
                           'COST_AS_OF_DATE':get(p,'COST_AS_OF_DATE'),'LIBRARY_STATUS':get(fm[0],'STATUS'),
                           'FUNCTION_SOURCE_ROW':fm[0]['_row'],'COMPONENT_SOURCE_ROW':c['_row'],
                           'BOM_SOURCE_ROW':part['_row'],'PART_SOURCE_ROW':p['_row']})
    return {'rows':output,'status':'assembly preview','requires_selection':False,
            'note':'Quantities are instance × component × part. No currency conversion or procurement approval is performed. Migrated/review library status remains visible.'}
