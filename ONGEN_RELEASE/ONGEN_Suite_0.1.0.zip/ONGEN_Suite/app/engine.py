"""Auditable local engineering workspace. Imports values without executing Office code."""
from __future__ import annotations
import csv, hashlib, io, json, math, os, re, shutil, sqlite3, threading, time, uuid, zipfile
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET
from .power import calculate

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
MAX_ZIP_BYTES = 750 * 1024 * 1024
MAX_ROWS = 250000

def norm(value):
    return re.sub(r'[^A-Z0-9]+', '_', str(value or '').strip().upper()).strip('_')

def text(value):
    return '' if value is None else str(value).strip()

def usable(value):
    return value is not None and text(value) not in ('', '-', 'N/A', '#N/A')

def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def colindex(ref):
    n = 0
    for ch in re.match(r'[A-Z]+', ref).group():
        n = n * 26 + ord(ch) - 64
    return n - 1

def cell_value(cell, shared):
    typ = cell.get('t')
    value = cell.find(NS+'v')
    if typ == 'inlineStr':
        return ''.join(x.text or '' for x in cell.findall('.//'+NS+'t'))
    if value is None or value.text is None:
        return None
    raw = value.text
    if typ == 's':
        return shared[int(raw)]
    if typ in ('str', 'e', 'd'):
        return raw
    if typ == 'b':
        return raw == '1'
    try:
        n = float(raw)
        return int(n) if n.is_integer() else n
    except ValueError:
        return raw

def sheet_stream(archive, path, shared, checkpoint):
    """Visit serialized cells only; never iterate a formatted million-row UsedRange."""
    with archive.open(path) as stream:
        for event, elem in ET.iterparse(stream, events=('end',)):
            if elem.tag != NS+'row':
                continue
            rowno = int(elem.get('r', '1'))
            values, formulas, errors = {}, {}, []
            for cell in elem.findall(NS+'c'):
                index = colindex(cell.get('r'))
                value = cell_value(cell, shared)
                if index > 2047 and (value is not None or cell.find(NS+'f') is not None):
                    raise ValueError('Sheet exceeds the supported 2048-column engineering import limit')
                if value is not None:
                    values[index] = value
                formula = cell.find(NS+'f')
                if formula is not None:
                    formulas[index] = formula.text or '[shared formula]'
                if cell.get('t') == 'e':
                    errors.append((index, value))
            if values or formulas:
                checkpoint()
                yield rowno, values, formulas, errors
            elem.clear()

class Workspace:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.inputs = self.root / 'inputs'; self.inputs.mkdir(exist_ok=True)
        self.db = self.root / 'ongen.sqlite3'
        self.lock = threading.RLock()
        with self.connect() as db:
            db.executescript('''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
                CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,name TEXT,kind TEXT,sha256 TEXT UNIQUE,path TEXT,created TEXT,metadata TEXT);
                CREATE TABLE IF NOT EXISTS sheets(id INTEGER PRIMARY KEY,source_id TEXT,name TEXT,columns_json TEXT,header_row INTEGER,metadata TEXT,UNIQUE(source_id,name));
                CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY,sheet_id INTEGER,row_no INTEGER,data TEXT,UNIQUE(sheet_id,row_no));
                CREATE INDEX IF NOT EXISTS records_sheet ON records(sheet_id);
                CREATE TABLE IF NOT EXISTS issues(id INTEGER PRIMARY KEY,severity TEXT,code TEXT,message TEXT,source TEXT,sheet TEXT,row_no INTEGER,field TEXT,category TEXT);
                CREATE TABLE IF NOT EXISTS generated(name TEXT PRIMARY KEY,columns_json TEXT,rows_json TEXT,created TEXT);
                CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY,created TEXT,action TEXT,details TEXT);
            ''')
            db.execute('INSERT OR IGNORE INTO meta VALUES (?,?)', ('project_id', str(uuid.uuid4())))
            db.execute('INSERT OR IGNORE INTO meta VALUES (?,?)', ('project_name', 'ONGEN Engineering Workspace'))

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.db, timeout=60)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def issue(self, db, severity, code, message, source='', sheet='', row=None, field='', category='validation'):
        db.execute('INSERT INTO issues(severity,code,message,source,sheet,row_no,field,category) VALUES(?,?,?,?,?,?,?,?)',
                   (severity,code,message,source,sheet,row,field,category))

    def _log(self, db, action, details):
        db.execute('INSERT INTO changes(created,action,details) VALUES(?,?,?)', (timestamp(), action, json.dumps(details)))

    def _kind(self, name, sheets):
        keys = {norm(s) for s in sheets}
        if 'SIS_TAG_PD5' in keys or 'SIS_TAG_EXPORT' in keys:
            return 'pd_master'
        if 'MASTER_FUNCTIONS' in keys or ('MASTER' in name.upper() and 'LIBRARY' in name.upper()):
            return 'function_library'
        if 'VARIANT_LIST' in keys or 'FIELD' in name.upper():
            return 'field_devices'
        if 'POWER' in name.upper():
            return 'power'
        if 'EAS' in name.upper():
            return 'eas'
        if name.lower().endswith('.csv'):
            return 'csv'
        if 'IO' in name.upper():
            return 'io_generator'
        return 'workbook'

    def import_file(self, path, original_name=None, progress=None):
        path = Path(path)
        name = Path(original_name or path.name).name
        suffix = Path(name).suffix.lower()
        if suffix not in ('.xlsm', '.xlsx', '.csv'):
            raise ValueError('Import .xlsm, .xlsx or .csv files')
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        with self.lock, self.connect() as db:
            existing = db.execute('SELECT id FROM sources WHERE sha256=?', (digest,)).fetchone()
            if existing:
                return {'source_id': existing['id'], 'duplicate': True}
            source_id = uuid.uuid4().hex
            final = self.inputs / f'{digest}{suffix}'
            staged = final.with_suffix(final.suffix+'.part')
            shutil.copyfile(path, staged)
            os.replace(staged, final)
            try:
                return self._import(db, final, name, source_id, digest, progress)
            except Exception:
                # DB context rolls back the entire source; retained copy can be retried safely.
                raise

    def _import(self, db, path, name, source_id, digest, progress):
        started = time.perf_counter(); sheets_meta = []; formula_total = 0
        db.execute('INSERT INTO sources VALUES (?,?,?,?,?,?,?)', (source_id,name,'pending',digest,str(path.relative_to(self.root)),timestamp(),'{}'))
        def checkpoint():
            if progress:
                progress(None, None)
        if path.suffix.lower() == '.csv':
            with path.open(encoding='utf-8-sig', newline='') as f:
                sample = f.read(8192); f.seek(0)
                try: dialect = csv.Sniffer().sniff(sample, delimiters=',;\t')
                except csv.Error: dialect = csv.excel
                reader = csv.reader(f, dialect)
                rows = ((i, {c:v for c,v in enumerate(row) if v != ''}, {}, []) for i,row in enumerate(reader,1))
                sheets_meta.append(self._store_sheet(db,source_id,name,'CSV',rows))
        else:
            with zipfile.ZipFile(path) as archive:
                if sum(x.file_size for x in archive.infolist()) > MAX_ZIP_BYTES:
                    raise ValueError('Uncompressed workbook exceeds 750 MiB import limit')
                for n in archive.namelist():
                    if n.startswith('/') or '..' in Path(n).parts:
                        raise ValueError('Unsafe workbook archive path')
                shared=[]
                if 'xl/sharedStrings.xml' in archive.namelist():
                    with archive.open('xl/sharedStrings.xml') as f:
                        for _,e in ET.iterparse(f,events=('end',)):
                            if e.tag == NS+'si':
                                shared.append(''.join(x.text or '' for x in e.iter(NS+'t'))); e.clear()
                wb=ET.fromstring(archive.read('xl/workbook.xml'))
                relations=ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))
                rels={r.get('Id'):r.get('Target') for r in relations if r.get('TargetMode') != 'External'}
                sheets=wb.find(NS+'sheets')
                for i,sheet in enumerate(sheets):
                    target=rels.get(sheet.get(REL+'id'),'')
                    target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
                    if target not in archive.namelist():
                        raise ValueError(f'Missing sheet part for {sheet.get("name")}')
                    if progress: progress(int(i/max(1,len(sheets))*85),f'Reading {name} / {sheet.get("name")}')
                    meta=self._store_sheet(db,source_id,name,sheet.get('name'),sheet_stream(archive,target,shared,checkpoint))
                    sheets_meta.append(meta); formula_total+=meta['formulas']
                calc = wb.find(NS+'calcPr')
                source_meta={'formulas':formula_total,'calc_properties':dict(calc.attrib) if calc is not None else {},
                             'macro_execution':'never','integrity':'original bytes retained','seconds':round(time.perf_counter()-started,4)}
                if any('externalLink' in x for x in archive.namelist()):
                    self.issue(db,'warning','EXTERNAL_LINKS','Workbook contains external links; they were not refreshed.',name,category='import')
        kind=self._kind(name,[s['name'] for s in sheets_meta])
        if suffix_is_csv(path): source_meta={'macro_execution':'never','seconds':round(time.perf_counter()-started,4)}
        db.execute('UPDATE sources SET kind=?,metadata=? WHERE id=?',(kind,json.dumps(source_meta),source_id))
        # Any new input invalidates derived outputs; never present stale calculations as current.
        db.execute('DELETE FROM generated')
        db.execute("DELETE FROM issues WHERE category='validation'")
        self._log(db,'import',{'source_id':source_id,'name':name,'sha256':digest,'kind':kind})
        return {'source_id':source_id,'name':name,'kind':kind,'sheets':sheets_meta,'seconds':round(time.perf_counter()-started,4)}

    def _store_sheet(self,db,source_id,source_name,name,rows):
        # Header selection: first of the first 30 populated rows with engineering-header evidence.
        iterator=iter(rows); preview=[]
        for _ in range(30):
            try: preview.append(next(iterator))
            except StopIteration: break
        scores=[]
        for index,(rowno,values,_,_) in enumerate(preview):
            known={'SIS_SEQUENCE','CONTROL_FUNCTION_NUMBER','FUNCTION_CODE','DEVICE_NAME','ITEM_TYPE','LAYOUT_POSITION_NUMBER','CONV_ID','VARIANT','PART_KEY','FUNCTION_KEY','HANDLE','PART_NO','PART_NUMBER'}
            score=sum(norm(v) in known for v in values.values())*20+min(len(values),15)
            scores.append((score,-index,index))
        chosen=max(scores)[2] if scores else 0
        headerno=preview[chosen][0] if preview else 1
        header=preview[chosen][1] if preview else {}
        width=max(header.keys(),default=-1)+1
        # Keep header-only shapes without inventing data from allocated dimensions.
        columns=[]; seen=Counter()
        for col in range(width):
            value=text(header.get(col)) or f'Column_{col+1}'
            seen[value]+=1
            columns.append(value if seen[value]==1 else f'{value} [{seen[value]}]')
        sid=db.execute('INSERT INTO sheets(source_id,name,columns_json,header_row,metadata) VALUES(?,?,?,?,?)',
                       (source_id,name,json.dumps(columns),headerno,'{}')).lastrowid
        count=0; formulas=0; missing=0; formula_examples=[]; errors=0
        import itertools
        for rowno,values,rowformulas,rowerrors in itertools.chain(preview,iterator):
            formulas+=len(rowformulas)
            for col,formula in rowformulas.items():
                if values.get(col) is None: missing+=1
                if len(formula_examples)<8: formula_examples.append({'row':rowno,'column':col+1,'formula':formula,'cached':values.get(col)})
            for col,value in rowerrors:
                errors+=1
                if errors<=30: self.issue(db,'error','EXCEL_ERROR',f'Cached Excel error: {value}',source_name,name,rowno,columns[col] if col<len(columns) else str(col+1),'import')
            if rowno<=headerno or not any(usable(v) for v in values.values()): continue
            # BOQ row 2 contains units, not a conveyor record.
            if norm(name)=='BOQ' and not usable(values.get(0)) and rowno==headerno+1: continue
            if count>=MAX_ROWS: raise ValueError(f'{name} exceeds {MAX_ROWS:,} imported-row limit')
            row={columns[c] if c<len(columns) else f'Column_{c+1}':value for c,value in values.items()}
            db.execute('INSERT INTO records(sheet_id,row_no,data) VALUES(?,?,?)',(sid,rowno,json.dumps(row,ensure_ascii=False)))
            count+=1
        if missing:
            self.issue(db,'warning','FORMULA_CACHE_MISSING',f'{missing} formulas have no saved value. This app does not calculate Excel formulas.',source_name,name,category='import')
        if formulas:
            self.issue(db,'info','FORMULA_CACHE_USED',f'{formulas} formulas are imported as saved values; freshness is not certified.',source_name,name,category='import')
        metadata={'rows':count,'formulas':formulas,'missing_cached_values':missing,'formula_examples':formula_examples,'errors':errors}
        db.execute('UPDATE sheets SET metadata=? WHERE id=?',(json.dumps(metadata),sid))
        return {'name':name,'rows':count,'columns':columns,**metadata}

    def sources(self):
        with self.connect() as db:
            result=[]
            for source in db.execute('SELECT * FROM sources ORDER BY created,id'):
                s=dict(source);s['metadata']=json.loads(s['metadata']);s.pop('path')
                s['sheets']=[{'name':r['name'],'columns':json.loads(r['columns_json']),**json.loads(r['metadata'])} for r in db.execute('SELECT * FROM sheets WHERE source_id=? ORDER BY id',(s['id'],))]
                result.append(s)
            return result

    def _sheet(self,db,name,kind=None):
        candidates=db.execute('SELECT sh.*,s.kind,s.name AS source_name,s.created FROM sheets sh JOIN sources s ON s.id=sh.source_id ORDER BY sh.id DESC').fetchall()
        return next((r for r in candidates if norm(r['name'])==norm(name) and (kind is None or r['kind']==kind)),None)

    def _rows(self,db,name,kind=None):
        sh=self._sheet(db,name,kind)
        if not sh: return [],None
        rows=[{'_row':r['row_no'],'_source':sh['source_name'],'_sheet':sh['name'],**json.loads(r['data'])} for r in db.execute('SELECT * FROM records WHERE sheet_id=? ORDER BY row_no',(sh['id'],))]
        return rows,sh

    def records(self,source_id=None,sheet=None,q='',offset=0,limit=100):
        offset=max(0,offset);limit=min(500,max(1,limit))
        with self.connect() as db:
            if source_id:
                sh=db.execute('SELECT * FROM sheets WHERE source_id=? AND name=?',(source_id,sheet)).fetchone()
            else:
                sh=self._sheet(db,sheet or 'SIS_TAG_PD5','pd_master')
            if not sh:return {'columns':[],'rows':[],'total':0,'offset':offset}
            clause='sheet_id=?';args=[sh['id']]
            if q:clause+=' AND data LIKE ?';args.append('%'+q.replace('%','\\%').replace('_','\\_')+'%');clause+=" ESCAPE '\\'"
            total=db.execute(f'SELECT count(*) FROM records WHERE {clause}',args).fetchone()[0]
            rows=[{'_row':r['row_no'],**json.loads(r['data'])} for r in db.execute(f'SELECT * FROM records WHERE {clause} ORDER BY row_no LIMIT ? OFFSET ?',(*args,limit,offset))]
            return {'columns':json.loads(sh['columns_json']),'rows':rows,'total':total,'offset':offset}

    def issues(self):
        with self.connect() as db:
            rows=[dict(r) for r in db.execute("SELECT severity,code,message,source,sheet,row_no AS row,field FROM issues ORDER BY CASE severity WHEN 'error' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END,id")]
            return {'issues':rows,'total':len(rows)}

    def validate(self,progress=None):
        with self.lock,self.connect() as db:
            db.execute("DELETE FROM issues WHERE category='validation'")
            sources=db.execute('SELECT * FROM sources').fetchall()
            if not any(r['kind']=='power' for r in sources):
                self.issue(db,'warning','POWER_WORKBOOK_UNAVAILABLE','Power Calculation V4.6 was not inspected: original upload exceeded the 32 MiB transfer limit. Native round-trip parity remains unverified.')
            pd5,sh=self._rows(db,'SIS_TAG_PD5','pd_master')
            boq,bs=self._rows(db,'BOQ','pd_master')
            definitions,ds=self._rows(db,'FUNCTION DEFINITION','pd_master')
            if not sh:
                self.issue(db,'error','MASTER_MISSING','Import a PD master containing SIS_TAG_PD5 before building outputs.')
            bindex=defaultdict(list)
            for b in boq:
                key=text(get(b,'Layout Position Number')).upper()
                if key:bindex[key].append(b)
            for key,items in bindex.items():
                if len(items)>1:self.issue(db,'warning','DUPLICATE_BOQ_LPN',f'{key}: {len(items)} BOQ records; automatic enrichment will not choose a winner.',bs['source_name'],'BOQ',items[0]['_row'],'Layout Position Number')
            sequences=defaultdict(list); handles=defaultdict(list); codes={text(get(d,'CONTROL_FUNCTION_NUMBER')).upper() for d in definitions if usable(get(d,'CONTROL_FUNCTION_NUMBER'))}
            for i,r in enumerate(pd5):
                if progress and i%200==0:progress(int(i/max(1,len(pd5))*85),'Checking engineering identities and references')
                seq=text(get(r,'SIS_SEQUENCE')); handle=text(get(r,'HANDLE'));lpn=text(get(r,'LPN'))
                if seq:sequences[seq.upper()].append(r)
                else:self.issue(db,'warning','MISSING_SEQUENCE','PD5 record has no SIS_SEQUENCE; excluded from power exchange.',r['_source'],r['_sheet'],r['_row'],'SIS_SEQUENCE')
                if handle:handles[handle.upper()].append(r)
                if lpn and lpn.upper() not in bindex:self.issue(db,'warning','LPN_NOT_IN_BOQ',f'{lpn}: no BOQ match. CAD-only devices may be intentional.',r['_source'],r['_sheet'],r['_row'],'LPN')
                code=text(get(r,'CONTROL_FUNCTION_NUMBER'))
                if code and code.upper() not in codes:self.issue(db,'error','UNKNOWN_FUNCTION_CODE',f'{code}: missing from local FUNCTION DEFINITION.',r['_source'],r['_sheet'],r['_row'],'CONTROL_FUNCTION_NUMBER')
            for seq,items in sequences.items():
                if len(items)>1:self.issue(db,'warning','SHARED_SEQUENCE',f'{seq}: {len(items)} PD5 records share this sequence. Use HANDLE/device type for identity; sequence-only returns can be ambiguous.',items[0]['_source'],items[0]['_sheet'],items[0]['_row'],'SIS_SEQUENCE')
            for handle,items in handles.items():
                if len(items)>1:self.issue(db,'error','DUPLICATE_HANDLE',f'{handle}: {len(items)} records share a CAD HANDLE.',items[0]['_source'],items[0]['_sheet'],items[0]['_row'],'HANDLE')
            # Detect ambiguous function definitions: multiple lines per code may be valid child devices.
            lookup,_=self._rows(db,'CSV')
            csvcodes={text(get(r,'FUNCTION_CODE')).upper() for r in lookup}
            if csvcodes:
                for code in sorted(codes-csvcodes):self.issue(db,'warning','LOOKUP_CODE_GAP',f'{code}: present in local definitions but absent from CSV lookup.')
            for source in sources:
                config=self._sheet(db,'UI_Config',source['kind'])
                if config and config['source_id']==source['id']:
                    for r in db.execute('SELECT * FROM records WHERE sheet_id=?',(config['id'],)):
                        obj=json.loads(r['data'])
                        if any(re.match(r'^[A-Za-z]:\\',text(v)) for v in obj.values()):self.issue(db,'warning','LOCAL_WORKBOOK_PATH','Saved workbook path depends on a specific Windows user/location; select and validate the current workbook.',source['name'],'UI_Config',r['row_no'])
            for r in definitions:
                for field in ('INPUT','OUTPUT','S_IN','S_OUT'):
                    value=get(r,field)
                    if not usable(value):continue
                    try:
                        n=float(value)
                        valid=math.isfinite(n) and n>=0 and n.is_integer() and not isinstance(value,bool)
                    except (ValueError,TypeError):valid=False
                    if not valid:self.issue(db,'error','INVALID_IO_COUNT','IO count must be a nonnegative integer.',r['_source'],r['_sheet'],r['_row'],field)
            parts,_=self._rows(db,'PART_MASTER','function_library')
            partidentity=defaultdict(list)
            for r in parts:
                key=(text(get(r,'MANUFACTURER')).upper(),text(get(r,'PART_NUMBER')).upper())
                if all(key):partidentity[key].append(r)
            for key,items in partidentity.items():
                if len(items)>1:self.issue(db,'error','DUPLICATE_PART_IDENTITY',f'{key[0]} / {key[1]} maps to multiple PART_KEY values: '+', '.join(text(get(x,'PART_KEY')) for x in items),items[0]['_source'],items[0]['_sheet'],items[0]['_row'])
            functions,_=self._rows(db,'FUNCTION_MASTER','function_library')
            if csvcodes:
                for r in functions:
                    code=text(get(r,'FUNCTION_CODE')).upper()
                    if code and code not in csvcodes:self.issue(db,'warning','LIBRARY_LOOKUP_GAP',f'{code}: library function is absent from supplied lookup CSV.',r['_source'],r['_sheet'],r['_row'],'FUNCTION_CODE')
            for r in functions:
                status=text(get(r,'STATUS'))
                if text(get(r,'ACTIVE')).upper()=='YES' and ('REVIEW' in status.upper() or 'MIGRATION' in status.upper()):
                    self.issue(db,'warning','LIBRARY_REVIEW_REQUIRED',f'{get(r,"FUNCTION_CODE")}: active function retains status {status}.',r['_source'],r['_sheet'],r['_row'],'STATUS')
            self._log(db,'validate',{'pd5_records':len(pd5),'boq_records':len(boq)})
        return self.issues()

    def build_phase3(self,progress=None):
        """O(n+m) BOQ lookup; preserve identities; emit unresolved assignments explicitly."""
        with self.lock,self.connect() as db:
            pd5,sh=self._rows(db,'SIS_TAG_PD5','pd_master')
            boq,_=self._rows(db,'BOQ','pd_master')
            defs,_=self._rows(db,'FUNCTION DEFINITION','pd_master')
            if not pd5:raise ValueError('No PD5 records: import a master workbook first')
            index=defaultdict(list)
            for r in boq:
                key=text(get(r,'Layout Position Number')).upper()
                if key:index[key].append(r)
            dtype=defaultdict(set); bycode=defaultdict(list)
            inherited=''
            for d in defs:
                code=text(get(d,'CONTROL_FUNCTION_NUMBER'))
                if code:inherited=code
                # Legacy merged/continuation rows use last explicit code, limited to this source table.
                code=code or inherited
                if code:
                    dd=dict(d);dd['CONTROL_FUNCTION_NUMBER']=code
                    bycode[code.upper()].append(dd)
                    conv=text(get(d,'conveyor Type')).upper()
                    if conv:dtype[conv].add(code)
            output=[];devices=[]; unresolved=[]
            enrich=['System Type','Conveyor Type','Module Length (ML)','Motor Power (Main Drive)','Motor Voltage (Main Drive)',
                    'Total Qty of Sensors','Control Card','Total Qty of Drives','Motor Brake Voltage (Main Drive)',
                    'Motor Protection (Main Drive)','Encoder Type (Main Drive)','Zone Length (ZL)']
            for i,r in enumerate(pd5):
                if progress and i%100==0:progress(int(i/len(pd5)*90),'Joining PD5 and BOQ; expanding explicit function definitions')
                out={k:v for k,v in r.items() if not k.startswith('_')}
                matches=index.get(text(get(r,'LPN')).upper(),[])
                if len(matches)==1:
                    for field in enrich:
                        val=get(matches[0],field)
                        if not usable(get(out,field)) and usable(val):out[field]=val
                code=text(get(out,'CONTROL_FUNCTION_NUMBER'))
                if not code:
                    candidates=dtype.get(text(get(out,'Conveyor Type')).upper(),set())
                    if len(candidates)==1:
                        code=next(iter(candidates));out['CONTROL_FUNCTION_NUMBER']=code
                    elif len(candidates)>1:unresolved.append({'row':r['_row'],'reason':'ambiguous conveyor-to-function mapping','candidates':sorted(candidates)})
                out['SOURCE_FILE']=r['_source'];out['SOURCE_SHEET']=r['_sheet'];out['SOURCE_ROW']=r['_row']
                output.append(out)
                if not code:
                    unresolved.append({'row':r['_row'],'reason':'no function code assigned; may be intentional for direct or mechanical devices','handle':get(r,'HANDLE'),'sequence':get(r,'SIS_SEQUENCE'),'type':get(r,'TYPE')})
                    continue
                matched=bycode.get(code.upper(),[])
                unique={}; merged=[]
                for definition in matched:
                    signature=tuple(text(get(definition,k)).upper() for k in ['CONTROL_FUNCTION_TAG','BLOCK','INPUT','OUTPUT','S_IN','S_OUT','COMPONENT_QTY']+[x for n in range(1,11) for x in (f'PART_NUM_{n}',f'MANUF_NAME_{n}',f'PART_QTY_{n}')])
                    if not usable(get(definition,'BLOCK')):continue
                    if signature not in unique:
                        definition=dict(definition);definition['_definition_rows']=[definition['_row']];definition['_component_candidates']=[text(get(definition,'COMPONENT_CODE'))] if usable(get(definition,'COMPONENT_CODE')) else []
                        unique[signature]=definition; merged.append(definition)
                    else:
                        unique[signature]['_definition_rows'].append(definition['_row'])
                        cc=text(get(definition,'COMPONENT_CODE'))
                        if cc and cc not in unique[signature]['_component_candidates']:unique[signature]['_component_candidates'].append(cc)
                matched=merged
                if not matched:unresolved.append({'row':r['_row'],'reason':f'unknown function {code}'});continue
                # Every child record is retained, rather than overwriting by sequence or function code.
                for j,d in enumerate(matched,1):
                    dev={'DEVICE_KEY':f'{text(get(r,"HANDLE")) or r["_row"]}:{code}:{j}',
                         'HANDLE':get(r,'HANDLE'),'SIS_SEQUENCE':get(r,'SIS_SEQUENCE'),'LPN':get(r,'LPN'),
                         'CONTROL_FUNCTION_NUMBER':code,'CONTROL_FUNCTION_TAG':get(d,'CONTROL_FUNCTION_TAG'),
                         'COMPONENT_CODE':d['_component_candidates'][0] if len(d['_component_candidates'])==1 else None,'COMPONENT_CODE_CANDIDATES':' | '.join(d['_component_candidates']),'VARIANT_CODE':get(d,'VARIANT_CODE'),'COMPONENT_QTY':get(d,'COMPONENT_QTY'),
                         'BLOCK':get(d,'BLOCK'),'AREA_NUMBER':get(r,'AREA_NUMBER'),'SWITCHGROUP':get(r,'SWITCHGROUP'),'PANEL':get(r,'PANEL'),'X':get(r,'X'),'Y':get(r,'Y'),'Z':get(r,'Z'),'ROTATION_DEG':get(r,'ROTATION_DEG'),
                         'SOURCE_FILE':r['_source'],'SOURCE_SHEET':r['_sheet'],'SOURCE_ROW':r['_row'],
                         'FUNCTION_SOURCE_ROW':d['_row'],'FUNCTION_SOURCE_ROWS':','.join(map(str,d['_definition_rows'])),'REVIEW_STATUS':'engineering review required'}
                    for key in ['INPUT','OUTPUT','S_IN','S_OUT']+[x for n in range(1,11) for x in (f'PART_NUM_{n}',f'MANUF_NAME_{n}',f'PART_QTY_{n}')]:dev[key]=get(d,key)
                    devices.append(dev)
            self._put_generated(db,'phase3',output)
            self._put_generated(db,'devices',devices)
            self._put_generated(db,'phase3_review',unresolved)
            self._log(db,'build_phase3',{'rows':len(output),'devices':len(devices),'unresolved':len(unresolved),'algorithm':'indexed lookup; no source writes'})
            return {'rows':len(output),'devices':len(devices),'unresolved':len(unresolved),'status':'review required'}

    def _put_generated(self,db,name,rows,columns=None):
        columns=columns or list(dict.fromkeys(k for r in rows for k in r))
        db.execute('INSERT OR REPLACE INTO generated VALUES(?,?,?,?)',(name,json.dumps(columns),json.dumps(rows,ensure_ascii=False),timestamp()))

    def generated(self,name):
        with self.connect() as db:
            r=db.execute('SELECT * FROM generated WHERE name=?',(name,)).fetchone()
            return {'columns':json.loads(r['columns_json']),'rows':json.loads(r['rows_json']),'created':r['created']} if r else {'columns':[],'rows':[]}

    def functions(self):
        with self.connect() as db:
            rows,_=self._rows(db,'FUNCTION DEFINITION','pd_master')
            return {'rows':rows,'total':len(rows),'authority':'Master workbook local FUNCTION DEFINITION; library reconciliation is review-only.'}

    def project(self):
        sources=self.sources();issues=self.issues()['issues']
        pd5=next((s for s in sources if s['kind']=='pd_master'),None)
        generated=self.generated('phase3')
        return {'id':self._meta('project_id'),'name':self._meta('project_name'),
                'summary':{'sources':len(sources),'records':sum(sh['rows'] for s in sources for sh in s['sheets']),
                           'issues':len(issues),'errors':sum(i['severity']=='error' for i in issues),'warnings':sum(i['severity']=='warning' for i in issues)},
                'sources':sources,
                'phases':[{'id':'1','title':'CAD + BOQ','status':'imported' if pd5 else 'waiting','detail':'Immutable source import and identity checks'},
                          {'id':'2','title':'Power estimates','status':'available','detail':'Transparent user-input estimates; original Power VBA not validated'},
                          {'id':'3','title':'Function devices','status':'review' if generated['rows'] else 'available','detail':'Indexed BOQ enrichment and function child expansion'},
                          {'id':'4','title':'Power exchange','status':'unverified','detail':'41-column PD5_IMPORT packet; original V4.6 inaccessible'},
                          {'id':'5','title':'Field devices + IO','status':'review','detail':'Explicit 11-column IO packet and reviewed return merge'},
                          {'id':'6','title':'Engineering handoff','status':'available','detail':'Traceable JSON, CSV, XLSX exchange + issue register'}],
                'capabilities':{'macros_executed':False,'excel_runtime_verified':False,'windows_desktop_verified':False,
                                'power_workbook_verified':False,'status':'engineering preview; review export data before production use'},
                'generated':{'phase3':len(generated['rows']),'devices':len(self.generated('devices')['rows'])}}

    def _meta(self,key):
        with self.connect() as db:return db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()[0]

    def snapshot(self):
        with self.connect() as db:
            return {'format':'ONGEN-project-1','created':timestamp(),'project':self.project(),
                    'tables':{name:[dict(r) for r in db.execute(f'SELECT * FROM {name}')] for name in ('sources','sheets','records','issues','generated','changes')},
                    'note':'JSON audit backup. Original uploaded workbook bytes remain in data/inputs; JSON alone does not contain VBA.'}

    def plan_return(self,source_id,sheet):
        """Preview permitted return columns. Never choose a duplicate sequence arbitrarily."""
        allowed={'NETWORK_IP','FEEDING_PANEL','LOAD','CURRENT_LOAD','PSU_TERMINAL_ASSIGNMENTS','IO_BLOCK','IO_PORT','PORT','TERMINAL'}
        current=self.generated('phase3')['rows']
        if not current:raise ValueError('Build Phase 3 first')
        with self.connect() as db:
            sh=db.execute('SELECT * FROM sheets WHERE source_id=? AND name=?',(source_id,sheet)).fetchone()
            if not sh:raise ValueError('Return source sheet not found')
            returns=[(r['row_no'],json.loads(r['data'])) for r in db.execute('SELECT * FROM records WHERE sheet_id=? ORDER BY row_no',(sh['id'],))]
        handle_index=defaultdict(list);seq_index=defaultdict(list)
        for i,r in enumerate(current):
            h=text(get(r,'HANDLE')).upper();s=text(get(r,'SIS_SEQUENCE')).upper();t=text(get(r,'TYPE')).upper()
            if h:handle_index[h].append(i)
            if s:seq_index[(s,t)].append(i)
        updates=[];rejected=[];seen={}
        for no,r in returns:
            h=text(get(r,'HANDLE')).upper();s=text(get(r,'SIS_SEQUENCE') or get(r,'SEQUENCE')).upper();t=text(get(r,'TYPE') or get(r,'ITEM TYPE')).upper()
            matches=handle_index.get(h,[]) if h else seq_index.get((s,t),[])
            if len(matches)!=1:
                rejected.append({'return_row':no,'reason':'unmatched or ambiguous identity','handle':h,'sequence':s,'type':t});continue
            i=matches[0];changes={}
            for key,val in r.items():
                normalized=norm(key)
                if normalized not in allowed or not usable(val):continue
                target=next((k for k in current[i] if norm(k)==normalized),key)
                if current[i].get(target)!=val:changes[target]={'old':current[i].get(target),'new':val}
            if i in seen:
                rejected.append({'return_row':no,'reason':'duplicate return target; all edits to this target blocked','target':i})
                seen[i]['blocked']=True
                continue
            item={'target_index':i,'return_row':no,'changes':changes,'blocked':False};seen[i]=item;updates.append(item)
        return {'updates':updates,'rejected':rejected,'permitted_fields':sorted(allowed),'fingerprint':hashlib.sha256(json.dumps(current,sort_keys=True).encode()).hexdigest(),
                'source_id':source_id,'sheet':sheet}

    def apply_return(self,plan):
        with self.lock,self.connect() as db:
            current=self.generated('phase3')['rows']
            fingerprint=hashlib.sha256(json.dumps(current,sort_keys=True).encode()).hexdigest()
            if fingerprint!=plan['fingerprint']:raise ValueError('Project changed since preview; create a new return plan')
            count=0
            for item in plan['updates']:
                if item['blocked']:continue
                for key,change in item['changes'].items():current[item['target_index']][key]=change['new'];count+=1
            self._put_generated(db,'phase3',current)
            self._log(db,'apply_reviewed_return',{'source_id':plan['source_id'],'sheet':plan['sheet'],'fields_updated':count,'rejected':len(plan['rejected'])})
            return {'fields_updated':count,'rejected':len(plan['rejected'])}

def suffix_is_csv(path):return path.suffix.lower()=='.csv'

def get(row,field,default=None):
    if field in row:return row[field]
    key=norm(field)
    return next((v for k,v in row.items() if norm(k)==key),default)
