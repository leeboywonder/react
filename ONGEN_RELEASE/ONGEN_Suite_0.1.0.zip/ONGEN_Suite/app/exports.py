"""Explicit engineering exchange contracts. Sources and Office projects are never rewritten."""
import csv, io, json, html
from datetime import datetime, timezone
from pathlib import Path
from .engine import get, text, usable

POWER_HEADERS = ['SIS_sequence','AREA_Number','SwitchGroup','TYPE','SIS_Element_Number','Control_ID','Load',
'Module Length (ML)','Motor Power (Main Drive)','Motor Voltage (Main Drive)','Total Qty of Sensors',
'Control Card','Total Qty of Drives','System Type','Conveyor Type','Motor Brake Voltage (Main Drive)',
'Motor Protection (Main Drive)','Encoder Type (Main Drive)','Qty of Control Card','NETWORK_IP','LPN',
'X','Y','Z','ROTATION_DEG','SOURCE_SIS_SEQUENCE','CURRENT_LOAD','Feeding Panel','PSU_POWERED_SEQUENCES',
'PSU_RANGE','PSU_TOTAL_CONTROLLER','PSU_BUS','PSU_GROUP_NO','PSU_CLOSE_REASON','PSU_TERMINAL_1_SEQUENCE',
'PSU_TERMINAL_2_SEQUENCE','PSU_TERMINAL_3_SEQUENCE','PSU_TERMINAL_4_SEQUENCE','PSU_TERMINAL_ASSIGNMENTS',
'PSU_ESTIMATED_LENGTH_MM','ZONE_LENGTH_ZL']
IO_HEADERS=['DEVICE NAME','ITEM TYPE','INPUT','OUTPUT','S_IN','S_OUT','PNL','PWG','LOCATION','Standard Block','Safety Block']

def safe_csv(value):
    if value is None:return ''
    if isinstance(value,str) and value.lstrip().startswith(('=','+','-','@','\t','\r')):return "'"+value
    return value

def csv_bytes(rows,columns=None):
    columns=columns or list(dict.fromkeys(k for r in rows for k in r))
    stream=io.StringIO(newline='')
    w=csv.writer(stream);w.writerow(safe_csv(c) for c in columns)
    for r in rows:w.writerow(safe_csv(r.get(c)) for c in columns)
    return ('\ufeff'+stream.getvalue()).encode('utf-8')

def phase3(workspace):
    result=workspace.generated('phase3')
    if not result['rows']:raise ValueError('Build Phase 3 before exporting derived data')
    return result

def phase4(workspace):
    rows=phase3(workspace)['rows'];output=[]
    for r in rows:
        seq=text(get(r,'SIS_SEQUENCE'))
        if not seq:continue
        record={h:get(r,h) for h in POWER_HEADERS}
        if not usable(record['ZONE_LENGTH_ZL']):record['ZONE_LENGTH_ZL']=get(r,'Zone Length (ZL)')
        # Electrical loading / PSU allocation are retained only if explicit input exists.
        output.append(record)
    if not output:raise ValueError('No sequenced records for power exchange')
    return {'columns':POWER_HEADERS,'rows':output}

def io_packet(workspace):
    devices=workspace.generated('devices')['rows']
    if not devices:raise ValueError('Build Phase 3 and resolve function assignments first')
    rows=[];identities=set();blocked=[]
    for d in devices:
        if d.get('INCLUDE_IN_IO') is False:continue
        base=text(get(d,'SIS_SEQUENCE'));typ=text(get(d,'CONTROL_FUNCTION_TAG'))
        if not base or not typ:
            blocked.append(f'{d.get("DEVICE_KEY")}: missing sequence or item type');continue
        name=text(d.get('DEVICE_NAME_OVERRIDE')) or base+'-'+typ
        if (name.upper(),typ.upper()) in identities:
            # Multiple real components cannot be hidden behind the same legacy device identity.
            raise ValueError(f'Ambiguous IO identity {name}/{typ}; review function components before exporting. Use devices.csv to inspect every child.')
        identities.add((name.upper(),typ.upper()))
        r={'DEVICE NAME':name,'ITEM TYPE':typ,'PNL':get(d,'PANEL'),
           'LOCATION':get(d,'AREA_NUMBER'),'PWG':get(d,'SWITCHGROUP'),
           'Standard Block':get(d,'Standard Block'),'Safety Block':get(d,'Safety Block')}
        for k in ('INPUT','OUTPUT','S_IN','S_OUT'):
            v=get(d,k)
            if not usable(v):v=0
            try:n=float(v)
            except (ValueError,TypeError):raise ValueError(f'{name}: {k} must be a nonnegative integer') from None
            if isinstance(v,bool) or not n.is_integer() or n<0 or n>2147483647:raise ValueError(f'{name}: {k} must be a nonnegative integer')
            r[k]=int(n)
        rows.append(r)
    if blocked:raise ValueError(f'{len(blocked)} device records lack a usable identity. Review devices.csv; no partial IO export generated.')
    if not rows:raise ValueError('No devices included in IO export')
    return {'columns':IO_HEADERS,'rows':rows}

def xlsx_bytes(workspace):
    from openpyxl import Workbook
    from openpyxl.cell import WriteOnlyCell
    wb=Workbook(write_only=True)
    info=wb.create_sheet('READ_ME')
    for row in [
        ['ONGEN engineering exchange','Review package; not a released electrical design'],
        ['Created',datetime.now(timezone.utc).isoformat()],
        ['PD5_IMPORT','41-column contract transcribed from master Phase4A. Original Power V4.6 not inspected.'],
        ['Function expansion','Local PD function definitions; canonical child rows and original trace retained.'],
        ['Function coverage',f'{len(workspace.generated("phase3_review")["rows"])} parent records require review or have no function assignment. IO packet contains function-derived devices only, not all direct PD5 equipment.'],
        ['IO_DEVICE_LIST','11-column B05 contract only when identity/count checks pass.'],
        ['Blank electrical fields','Not inferred. Complete/review within approved engineering process.'],
        ['Original files','Unchanged; embedded macros are not executed or copied into this XLSX.']]:info.append(row)
    packets=[('SIS_TAG_IMPORT_PD2',phase3(workspace)),('FUNCTION_DEVICES',workspace.generated('devices')),('PD5_IMPORT',phase4(workspace)),('ISSUES',{'rows':workspace.issues()['issues']})]
    try:packets.append(('IO_DEVICE_LIST',io_packet(workspace)))
    except ValueError as e:info.append(['IO export blocked',str(e)])
    for name,packet in packets:
        ws=wb.create_sheet(name)
        cols=packet.get('columns') or list(dict.fromkeys(k for r in packet['rows'] for k in r))
        headers=[]
        for column in cols:
            cell=WriteOnlyCell(ws,value=column);cell.data_type="s";headers.append(cell)
        ws.append(headers)
        for row in packet['rows']:
            cells=[]
            for k in cols:
                val=row.get(k)
                if isinstance(val,(dict,list)):val=json.dumps(val,ensure_ascii=False)
                cell=WriteOnlyCell(ws,value=val)
                if isinstance(val,str):cell.data_type='s'
                cells.append(cell)
            ws.append(cells)
    out=io.BytesIO();wb.save(out);return out.getvalue()

def report_html(workspace,analysis_path=None):
    p=workspace.project();e=html.escape
    issues=workspace.issues()['issues']
    rows=''.join('<tr>'+''.join(f'<td>{e(str(i.get(k) or ""))}</td>' for k in ['severity','code','message','source','sheet','row','field'])+'</tr>' for i in issues)
    audit=''
    if analysis_path and Path(analysis_path).exists():
        audit='<h2>Source audit report</h2><pre>'+e(Path(analysis_path).read_text())+'</pre>'
    return ('<!doctype html><meta charset="utf-8"><title>ONGEN engineering report</title><style>body{font:15px system-ui;max-width:1300px;margin:40px auto;color:#13243a;padding:20px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #ccd5e1;padding:7px;text-align:left;vertical-align:top}pre{white-space:pre-wrap;font:13px/1.5 system-ui}.notice{background:#fff3da;padding:20px}h1{color:#12334a}</style>'
        +f'<h1>ONGEN engineering workspace</h1><p>Generated {e(datetime.now(timezone.utc).isoformat())}</p>'
        +'<p class="notice">Engineering preview. Microsoft Excel/VBA and a Windows desktop executable were not run in this Linux environment. Original Power Calculation V4.6 could not be transferred. Source audit findings and Python engine results are distinguished below. No macro performance timings or production approval are claimed.</p>'
        +f'<p>{p["summary"]["sources"]} sources · {p["summary"]["records"]:,} imported rows · {len(issues):,} validation items</p>'
        +audit+'<h2>Current project issue register</h2><table><tr><th>Severity</th><th>Code</th><th>Finding</th><th>Source</th><th>Sheet</th><th>Row</th><th>Field</th></tr>'+rows+'</table>').encode()
